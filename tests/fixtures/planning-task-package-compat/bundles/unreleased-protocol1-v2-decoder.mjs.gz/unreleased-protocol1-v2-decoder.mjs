var PS=Object.defineProperty;var ES=(X)=>X;function CS(X,Y){this[X]=ES.bind(null,Y)}var k6=(X,Y)=>{for(var Q in Y)PS(X,Q,{get:Y[Q],enumerable:!0,configurable:!0,set:CS.bind(Y,Q)})};import{readFileSync as oQ0}from"node:fs";var b1={};k6(b1,{pick:()=>zk,omit:()=>qk,mutate:()=>Ok,mergeAll:()=>zG,merge:()=>b5,makeUnsafe:()=>M8,make:()=>U6,isReference:()=>DG,isKey:()=>Uk,isContext:()=>e7,getUnsafe:()=>PX,getReferenceUnsafe:()=>VG,getOrUndefined:()=>NG,getOrElse:()=>Vk,getOption:()=>BG,get:()=>S1,empty:()=>k1,addOrOmit:()=>Nk,add:()=>i1,ServiceTypeId:()=>a7,Service:()=>yX,Reference:()=>L0});var _0=(X,Y)=>{switch(Y.length){case 0:return X;case 1:return Y[0](X);case 2:return Y[1](Y[0](X));case 3:return Y[2](Y[1](Y[0](X)));case 4:return Y[3](Y[2](Y[1](Y[0](X))));case 5:return Y[4](Y[3](Y[2](Y[1](Y[0](X)))));case 6:return Y[5](Y[4](Y[3](Y[2](Y[1](Y[0](X))))));case 7:return Y[6](Y[5](Y[4](Y[3](Y[2](Y[1](Y[0](X)))))));case 8:return Y[7](Y[6](Y[5](Y[4](Y[3](Y[2](Y[1](Y[0](X))))))));case 9:return Y[8](Y[7](Y[6](Y[5](Y[4](Y[3](Y[2](Y[1](Y[0](X)))))))));default:{let Q=X;for(let J=0,$=Y.length;J<$;J++)Q=Y[J](Q);return Q}}},wS={pipe(){return _0(this,arguments)}},L4=function(){function X(){}return X.prototype=wS,X}();var B=function(X,Y){if(typeof X==="function")return function(){return X(arguments)?Y.apply(this,arguments):(Q)=>Y(Q,...arguments)};switch(X){case 0:case 1:throw RangeError(`Invalid arity ${X}`);case 2:return function(Q,J){if(arguments.length>=2)return Y(Q,J);return function($){return Y($,Q)}};case 3:return function(Q,J,$){if(arguments.length>=3)return Y(Q,J,$);return function(G){return Y(G,Q,J)}};default:return function(){if(arguments.length>=X)return Y.apply(this,arguments);let Q=arguments;return function(J){return Y(J,...Q)}}}};var u=(X)=>X;var W1=(X)=>()=>X,b6=W1(!0),A7=W1(!1),P7=W1(null),TX=W1(void 0),E7=TX;function d_(X,...Y){return _0(X,Y)}function X1(X){let Y=new WeakMap;return(Q)=>{if(Y.has(Q))return Y.get(Q);let J=X(Q);return Y.set(Q,J),J}}var a9=(X)=>{let Y=new Set(Reflect.ownKeys(X));if(X.constructor===Object)return Y;if(X instanceof Error)Y.delete("stack");let Q=Object.getPrototypeOf(X),J=Q;while(J!==null&&J!==Object.prototype){let $=Reflect.ownKeys(J);for(let G=0;G<$.length;G++)Y.add($[G]);J=Object.getPrototypeOf(J)}if(Y.has("constructor")&&typeof X.constructor==="function"&&Q===X.constructor.prototype)Y.delete("constructor");return Y},C5=new WeakSet;function bX(X){return typeof X==="string"}function t9(X){return typeof X==="number"}function rD(X){return typeof X==="boolean"}function nD(X){return typeof X==="bigint"}function u_(X){return typeof X==="symbol"}function C7(X){return bX(X)||t9(X)||u_(X)}function l1(X){return typeof X==="function"}function sD(X){return X===void 0}function B1(X){return X!==void 0}function w7(X){return X!=null}function aD(X){return!1}function c_(X){return!0}function x1(X){return typeof X==="object"&&X!==null&&!Array.isArray(X)}function l_(X){return typeof X==="object"&&X!==null||l1(X)}var j=B(2,(X,Y)=>l_(X)&&(Y in X)),g6=B(2,(X,Y)=>j(X,"_tag")&&X._tag===Y);function tD(X){return X instanceof Error}function y6(X){return j(X,Symbol.iterator)||bX(X)}var D0="~effect/interfaces/Hash",X0=(X)=>{switch(typeof X){case"number":return h6(X);case"bigint":return g0(X.toString(10));case"boolean":return g0(String(X));case"symbol":return g0(String(X));case"string":return g0(X);case"undefined":return g0("undefined");case"function":case"object":if(X===null)return g0("null");else if(X instanceof Date)return g0(X.toISOString());else if(X instanceof RegExp)return g0(X.toString());else{if(C5.has(X))return M7(X);if(i_.has(X))return i_.get(X);let Y=vS(X,()=>{if(jS(X))return X[D0]();else if(typeof X==="function")return M7(X);else if(Array.isArray(X)||ArrayBuffer.isView(X))return e9(X);else if(X instanceof Map)return IS(X);else if(X instanceof Set)return xS(X);return s_(X)});return i_.set(X,Y),Y}default:throw Error(`BUG: unhandled typeof ${typeof X} - please report an issue at https://github.com/Effect-TS/effect/issues`)}},M7=(X)=>{if(!o_.has(X))o_.set(X,h6(Math.floor(Math.random()*Number.MAX_SAFE_INTEGER)));return o_.get(X)},_1=B(2,(X,Y)=>X*53^Y),j7=(X)=>X&3221225471|X>>>1&1073741824,jS=(X)=>j(X,D0),h6=(X)=>{if(X!==X)return g0("NaN");if(X===1/0)return g0("Infinity");if(X===-1/0)return g0("-Infinity");let Y=X|0;if(Y!==X)Y^=X*4294967295;while(X>4294967295)Y^=X/=4294967295;return j7(Y)},g0=(X)=>{let Y=5381,Q=X.length;while(Q)Y=Y*33^X.charCodeAt(--Q);return j7(Y)},n_=(X,Y)=>{let Q=12289;for(let J of Y)Q^=_1(X0(J),X0(X[J]));return j7(Q)},s_=(X)=>n_(X,a9(X)),a_=(X,Y)=>(Q)=>{let J=X;for(let $ of Q)J^=Y($);return j7(J)},e9=a_(6151,X0),IS=a_(g0("Map"),([X,Y])=>_1(X0(X),X0(Y))),xS=a_(g0("Set"),X0),o_=new WeakMap,i_=new WeakMap,r_=new WeakSet;function vS(X,Y){if(r_.has(X))return g0("[Circular]");r_.add(X);let Q=Y();return r_.delete(X),Q}var N0="~effect/interfaces/Equal";function o(){if(arguments.length===1)return(X)=>T4(X,arguments[0]);return T4(arguments[0],arguments[1])}function T4(X,Y){if(X===Y)return!0;if(X==null||Y==null)return!1;let Q=typeof X;if(Q!==typeof Y)return!1;if(Q==="number"&&X!==X&&Y!==Y)return!0;if(Q!=="object"&&Q!=="function")return!1;if(C5.has(X)||C5.has(Y))return!1;return bS(X,Y,kS)}function SS(X,Y,Q){let J=t_.has(X),$=e_.has(Y);if(J&&$)return!0;if(J||$)return!1;t_.add(X),e_.add(Y);let G=Q();return t_.delete(X),e_.delete(Y),G}var t_=new WeakSet,e_=new WeakSet;function kS(X,Y){if(X0(X)!==X0(Y))return!1;else if(X instanceof Date){if(!(Y instanceof Date))return!1;return X.toISOString()===Y.toISOString()}else if(X instanceof RegExp){if(!(Y instanceof RegExp))return!1;return X.toString()===Y.toString()}let Q=eD(X),J=eD(Y);if(Q!==J)return!1;let $=Q&&J;if(typeof X==="function"&&!$)return!1;return SS(X,Y,()=>{if($)return X[N0](Y);else if(Array.isArray(X)){if(!Array.isArray(Y)||X.length!==Y.length)return!1;return gS(X,Y)}else if(ArrayBuffer.isView(X)){if(!ArrayBuffer.isView(Y)||X.byteLength!==Y.byteLength)return!1;return yS(X,Y)}else if(X instanceof Map){if(!(Y instanceof Map)||X.size!==Y.size)return!1;return mS(X,Y)}else if(X instanceof Set){if(!(Y instanceof Set)||X.size!==Y.size)return!1;return fS(X,Y)}return hS(X,Y)})}function bS(X,Y,Q){let J=I7.get(X);if(!J)J=new WeakMap,I7.set(X,J);else if(J.has(Y))return J.get(Y);let $=Q(X,Y);J.set(Y,$);let G=I7.get(Y);if(!G)G=new WeakMap,I7.set(Y,G);return G.set(X,$),$}var I7=new WeakMap;function gS(X,Y){for(let Q=0;Q<X.length;Q++)if(!T4(X[Q],Y[Q]))return!1;return!0}function yS(X,Y){if(X.length!==Y.length)return!1;for(let Q=0;Q<X.length;Q++)if(X[Q]!==Y[Q])return!1;return!0}function hS(X,Y){let Q=a9(X),J=a9(Y);if(Q.size!==J.size)return!1;for(let $ of Q)if(!J.has($)||!T4(X[$],Y[$]))return!1;return!0}function x7(X,Y){return function(J,$){for(let[G,Z]of J){let K=!1;for(let[H,W]of $)if(X(G,H)&&Y(Z,W)){K=!0;break}if(!K)return!1}return!0}}var mS=x7(T4,T4);function v7(X){return function(Q,J){for(let $ of Q){let G=!1;for(let Z of J)if(X($,Z)){G=!0;break}if(!G)return!1}return!0}}var fS=v7(T4),eD=(X)=>j(X,N0);var XN=(X)=>{return C5.add(X),X};var S7=Symbol.for("~effect/Redactable"),pS=(X)=>j(X,S7);function XY(X){if(pS(X))return XG(X);return X}function XG(X){return X[S7](globalThis[w5]?.context??dS)}var w5="~effect/Fiber/currentFiber",dS={"~effect/Context":{},mapUnsafe:new Map,pipe(){return _0(this,arguments)}};function P(X,Y){let Q=Y?.space??0,J=new WeakSet,$=!Q?"":typeof Q==="number"?" ".repeat(Q):Q,G=(W)=>$.repeat(W),Z=(W,D)=>{let U=W?.constructor;return U&&U!==Object.prototype.constructor&&U.name?`${U.name}(${D})`:D},K=(W)=>{try{return Reflect.ownKeys(W)}catch{return["[ownKeys threw]"]}};function H(W,D=0){if(Array.isArray(W)){if(J.has(W))return YN;if(J.add(W),!$||W.length<=1)return`[${W.map((N)=>H(N,D)).join(",")}]`;let U=W.map((N)=>H(N,D+1)).join(`,
`+G(D+1));return`[
${G(D+1)}${U}
${G(D)}]`}if(W instanceof Date)return YG(W);if(!Y?.ignoreToString&&j(W,"toString")&&typeof W.toString==="function"&&W.toString!==Object.prototype.toString&&W.toString!==Array.prototype.toString){let U=uS(W);if(W instanceof Error&&W.cause)return`${U} (cause: ${H(W.cause,D)})`;return U}if(typeof W==="string")return JSON.stringify(W);if(typeof W==="number"||W==null||typeof W==="boolean"||typeof W==="symbol")return String(W);if(typeof W==="bigint")return String(W)+"n";if(typeof W==="object"||typeof W==="function"){if(J.has(W))return YN;if(J.add(W),S7 in W)return P(XG(W));if(Symbol.iterator in W)return`${W.constructor.name}(${H(Array.from(W),D)})`;let U=K(W);if(!$||U.length<=1){let V=`{${U.map((z)=>`${m6(z)}:${H(W[z],D)}`).join(",")}}`;return Z(W,V)}let N=`{
${U.map((V)=>`${G(D+1)}${m6(V)}: ${H(W[V],D+1)}`).join(`,
`)}
${G(D)}}`;return Z(W,N)}return String(W)}return H(X,0)}var YN="[Circular]";function m6(X){return typeof X==="string"?JSON.stringify(X):String(X)}function k7(X){return X.map((Y)=>`[${m6(Y)}]`).join("")}function YG(X){try{return X.toISOString()}catch{return"Invalid Date"}}function uS(X){try{let Y=X.toString();return typeof Y==="string"?Y:String(Y)}catch{return"[toString threw]"}}function F4(X,Y){let Q=[];return JSON.stringify(X,function(J,$){let G=XY($);if(typeof G!=="object"||G===null)return G;while(Q.length>0&&Q[Q.length-1]!==this)Q.pop();if(Q.includes(G))return;return Q.push(G),G},Y?.space)}var U1=Symbol.for("nodejs.util.inspect.custom"),A1=(X)=>{try{if(j(X,"toJSON")&&l1(X.toJSON)&&X.toJSON.length===0)return X.toJSON();else if(Array.isArray(X))return X.map(A1)}catch{return"[toJSON threw]"}return XY(X)},QN=(X,Y=2)=>{if(typeof X==="string")return X;try{return typeof X==="object"?F4(X,{space:Y}):String(X)}catch{return String(X)}},W70={toJSON(){return A1(this)},[U1](){return this.toJSON()},toString(){return P(this.toJSON())}};class F8{called=!1;self;constructor(X){this.self=X}next(X){return this.called?{value:X,done:!0}:(this.called=!0,{value:this.self,done:!1})}[Symbol.iterator](){return new F8(this.self)}}var lS=()=>{let Y={["~effect/Utils/internal"]:($)=>{return $()}},Q={["~effect/Utils/internal"]:($)=>{try{return $()}finally{}}};return Y["~effect/Utils/internal"](()=>Error().stack)?.includes("~effect/Utils/internal")===!0?Y["~effect/Utils/internal"]:Q["~effect/Utils/internal"]},W0=lS();function k(X,Y,Q){if(Y==="__proto__")Object.defineProperty(X,Y,{value:Q,writable:!0,enumerable:!0,configurable:!0});else X[Y]=Q}function b7(X,Y){for(let Q of Reflect.ownKeys(Y))if(Object.prototype.propertyIsEnumerable.call(Y,Q))k(X,Q,Y[Q])}var Z6="~effect/Effect",R4="~effect/Exit",oS={_A:u,_E:u,_R:u},$N=`${Z6}/identifier`,G0=`${Z6}/args`,o0=`${Z6}/evaluate`,v1=`${Z6}/successCont`,FX=`${Z6}/failureCont`,R8=`${Z6}/ensureCont`,A4=Symbol.for("effect/Effect/Yield"),f6={pipe(){return _0(this,arguments)},toJSON(){return{...this}},toString(){return P(this.toJSON(),{ignoreToString:!0,space:2})},[U1](){return this.toJSON()}},_N={[D0](){return n_(this,Object.keys(this))},[N0](X){let Y=Object.keys(this),Q=Object.keys(X);if(Y.length!==Q.length)return!1;for(let J=0;J<Y.length;J++)if(Y[J]!==Q[J]||!o(this[Y[J]],X[Y[J]]))return!1;return!0}},iS={[Z6]:oS,...f6,[Symbol.iterator](){return new F8(this)},toJSON(){return{_id:"Effect",op:this[$N],...G0 in this?{args:this[G0]}:void 0}}},i=(X)=>j(X,Z6),QG=(X)=>j(X,R4),YY="~effect/Cause",QY="~effect/Cause/Reason",j5=(X)=>j(X,YY),GN=(X)=>j(X,QY);class p6{[YY];reasons;constructor(X){this[YY]=YY,this.reasons=X}pipe(){return _0(this,arguments)}toJSON(){return{_id:"Cause",failures:this.reasons.map((X)=>X.toJSON())}}toString(){return`Cause(${P(this.reasons)})`}[U1](){return this.toJSON()}[N0](X){return j5(X)&&this.reasons.length===X.reasons.length&&this.reasons.every((Y,Q)=>o(Y,X.reasons[Q]))}[D0](){return e9(this.reasons)}}var JN=new WeakMap;class JY{[QY];annotations;_tag;constructor(X,Y,Q){if(this[QY]=QY,this._tag=X,Y!==$Y&&typeof Q==="object"&&Q!==null&&Y.size>0){let J=JN.get(Q);if(J)Y=new Map([...J,...Y]);JN.set(Q,Y)}this.annotations=Y}annotate(X,Y){if(X.mapUnsafe.size===0)return this;let Q=new Map(this.annotations);X.mapUnsafe.forEach(($,G)=>{if(Y?.overwrite!==!0&&Q.has(G))return;Q.set(G,$)});let J=Object.assign(Object.create(Object.getPrototypeOf(this)),this);return J.annotations=Q,J}pipe(){return _0(this,arguments)}toString(){return P(this)}[U1](){return this.toString()}}var $Y=new Map;class I5 extends JY{error;constructor(X,Y=$Y){super("Fail",Y,X);this.error=X}toString(){return`Fail(${P(this.error)})`}toJSON(){return{_tag:"Fail",error:this.error}}[N0](X){return P4(X)&&o(this.error,X.error)&&o(this.annotations,X.annotations)}[D0](){return _1(g0(this._tag))(_1(X0(this.error))(X0(this.annotations)))}}var d6=(X)=>new p6(X),y7=new p6([]),ZN=(X)=>new p6([new I5(X)]);class h7 extends JY{defect;constructor(X,Y=$Y){super("Die",Y,X);this.defect=X}toString(){return`Die(${P(this.defect)})`}toJSON(){return{_tag:"Die",defect:this.defect}}[N0](X){return GY(X)&&o(this.defect,X.defect)&&o(this.annotations,X.annotations)}[D0](){return _1(g0(this._tag))(_1(X0(this.defect))(X0(this.annotations)))}}var KN=(X)=>new p6([new h7(X)]),_Y=B((X)=>j5(X[0]),(X,Y,Q)=>{if(Y.mapUnsafe.size===0)return X;return new p6(X.reasons.map((J)=>J.annotate(Y,Q)))}),P4=(X)=>X._tag==="Fail",GY=(X)=>X._tag==="Die",m7=(X)=>X._tag==="Interrupt";function rS(X){return H6("Effect.evaluate: Not implemented")}var u6=(X)=>({...iS,[$N]:X.op,[o0]:X[o0]??rS,[v1]:X[v1],[FX]:X[FX],[R8]:X[R8]}),RX=(X)=>{let Y=u6(X);return function(){let Q=Object.create(Y);return Q[G0]=X.single===!1?arguments:arguments[0],Q}},HN=(X)=>{let Y={...u6(X),[R4]:R4,_tag:X.op,get[X.prop](){return this[G0]},toString(){return`${X.op}(${P(this[G0])})`},toJSON(){return{_id:"Exit",_tag:X.op,[X.prop]:this[G0]}},[N0](Q){return QG(Q)&&Q._tag===this._tag&&o(this[G0],Q[G0])},[D0](){return _1(g0(X.op),X0(this[G0]))}};return function(Q){let J=Object.create(Y);return J[G0]=Q,J}},G1=HN({op:"Success",prop:"value",[o0](X){let Y=X.getCont(v1);return Y?Y[v1](this[G0],X,this):X.yieldWith(this)}}),f7={key:"effect/Cause/StackTrace"},JG={key:"effect/Cause/InterruptorStackTrace"},_X=HN({op:"Failure",prop:"cause",[o0](X){let Y=this[G0],Q=!1;if(X.currentStackFrame)Y=_Y(Y,{mapUnsafe:new Map([[f7.key,X.currentStackFrame]])}),Q=!0;let J=X.getCont(FX);while(X.interruptible&&X._interruptedCause&&J)J=X.getCont(FX);return J?J[FX](Y,X,Q?void 0:this):X.yieldWith(Q?_X(Y):this)}}),K6=(X)=>_X(ZN(X)),H6=(X)=>_X(KN(X)),t=RX({op:"WithFiber",[o0](X){return this[G0](X)}}),nS=function(){class X extends globalThis.Error{}let Y=u6({op:"YieldableError",[o0](){return K6(this)}});return delete Y.toString,Object.assign(X.prototype,Y),X}(),ZY=function(){let X=Symbol.for("effect/Data/Error/plainArgs");return class extends nS{constructor(Q){super(Q?.message,Q?.cause?{cause:Q.cause}:void 0);if(Q)b7(this,Q),Object.defineProperty(this,X,{value:Q,enumerable:!1})}toJSON(){return{...this[X],...this}}}}(),A8=(X)=>{class Y extends ZY{_tag=X}return Y.prototype.name=X,Y},g7="~effect/Cause/NoSuchElementError",$G=(X)=>j(X,g7);class c6 extends A8("NoSuchElementError"){[g7]=g7;constructor(X){super({message:X})}}var M5="~effect/Cause/Done",KY=(X)=>j(X,M5),WN={[M5]:M5,_tag:"Done",value:void 0},UN=(X)=>{if(X===void 0)return WN;return{[M5]:M5,_tag:"Done",value:X}},sS=K6(WN),DN=(X)=>{if(X===void 0)return sS;return K6(UN(X))};var NN=(X)=>u6({op:X.label,[o0]:X.evaluate});var tS=()=>{let X=Object.getOwnPropertyDescriptor(Error,"stackTraceLimit");if(X===void 0)return Object.isExtensible(Error);return Object.hasOwn(X,"writable")?X.writable===!0:X.set!==void 0},eS=tS(),W6=()=>Error.stackTraceLimit,P1=(X)=>{if(eS)Error.stackTraceLimit=X};function VN(X){return{combine:X}}function l6(X,Y,Q){return{combine:X,initialValue:Y,combineAll:Q??((J)=>{let $=Y;for(let G of J)$=X($,G);return $})}}var D1=(X)=>(Y,Q)=>Y===Q||X(Y,Q),Yk=(X,Y)=>X===Y,BN=()=>Yk;function zN(X){return D1((Y,Q)=>{if(Y.length!==Q.length)return!1;for(let J=0;J<Y.length;J++)if(!X(Y[J],Q[J]))return!1;return!0})}var d7=(X)=>B(3,(Y,Q,J)=>X(Y,($)=>({...$,[Q]:J($)}))),u7=(X)=>B(2,(Y,Q)=>X(Y,(J)=>({[Q]:J}))),c7=(X,Y)=>B(3,(Q,J,$)=>Y(Q,(G)=>X($(G),(Z)=>({...G,[J]:Z}))));var ON="~effect/data/Option",LN={[ON]:{_A:(X)=>X},...f6,[Symbol.iterator](){return new F8(this)}},Qk=Object.defineProperty(Object.assign(Object.create(LN),{_tag:"Some",_op:"Some",[N0](X){return l7(X)&&_G(X)&&o(this.value,X.value)},[D0](){return _1(X0(this._tag))(X0(this.value))},toString(){return`some(${P(this.value)})`},toJSON(){return{_id:"Option",_tag:this._tag,value:A1(this.value)}}}),"valueOrUndefined",{get(){return this.value}}),Jk=X0("None"),$k=Object.assign(Object.create(LN),{_tag:"None",_op:"None",valueOrUndefined:void 0,[N0](X){return l7(X)&&C8(X)},[D0](){return Jk},toString(){return"none()"},toJSON(){return{_id:"Option",_tag:this._tag}}}),l7=(X)=>j(X,ON),C8=(X)=>X._tag==="None",_G=(X)=>X._tag==="Some",E4=Object.create($k),o6=(X)=>{let Y=Object.create(Qk);return Y.value=X,Y};var TN="~effect/data/Result",FN={[TN]:{_A:(X)=>X,_E:(X)=>X},...f6,[Symbol.iterator](){return new F8(this)}},_k=Object.assign(Object.create(FN),{_tag:"Success",_op:"Success",[N0](X){return o7(X)&&r7(X)&&o(this.success,X.success)},[D0](){return _1(X0(this._tag))(X0(this.success))},toString(){return`success(${P(this.success)})`},toJSON(){return{_id:"Result",_tag:this._tag,value:A1(this.success)}}}),Gk=Object.assign(Object.create(FN),{_tag:"Failure",_op:"Failure",[N0](X){return o7(X)&&i7(X)&&o(this.failure,X.failure)},[D0](){return _1(X0(this._tag))(X0(this.failure))},toString(){return`failure(${P(this.failure)})`},toJSON(){return{_id:"Result",_tag:this._tag,failure:A1(this.failure)}}}),o7=(X)=>j(X,TN),i7=(X)=>X._tag==="Failure",r7=(X)=>X._tag==="Success",ZG=(X)=>{let Y=Object.create(Gk);return Y.failure=X,Y},KG=(X)=>{let Y=Object.create(_k);return Y.success=X,Y},RN=(X)=>r7(X)?E4:o6(X.failure),AN=(X)=>i7(X)?E4:o6(X.success),PN=B(2,(X,Y)=>C8(X)?ZG(Y()):KG(X.value));function C4(X){return(Y,Q)=>Y===Q?0:X(Y,Q)}var O1=C4((X,Y)=>{if(globalThis.Number.isNaN(X)&&globalThis.Number.isNaN(Y))return 0;if(globalThis.Number.isNaN(X))return-1;if(globalThis.Number.isNaN(Y))return 1;return X<Y?-1:1});var AX=C4((X,Y)=>X<Y?-1:1);var HG=B(2,(X,Y)=>C4((Q,J)=>X(Y(Q),Y(J)))),w4=HG(O1,(X)=>X.getTime());var x5=(X)=>B(2,(Y,Q)=>X(Y,Q)===-1),w8=(X)=>B(2,(Y,Q)=>X(Y,Q)===1),HY=(X)=>B(2,(Y,Q)=>X(Y,Q)!==1),WY=(X)=>B(2,(Y,Q)=>X(Y,Q)!==-1);var p=()=>E4,T=o6,n7=l7,P0=C8,N1=_G,gX=B(2,(X,{onNone:Y,onSome:Q})=>P0(X)?Y():Q(X.value));var s7=B(2,(X,Y)=>P0(X)?Y():X.value);var EN=(X)=>X==null?p():T(X),CN=(X)=>X===void 0?p():T(X),wN=(X)=>X===null?p():T(X);var WG=s7(P7),M4=s7(TX),j4=(X)=>(...Y)=>{try{return T(X(...Y))}catch{return p()}};var i6=B(2,(X,Y)=>P0(X)?p():T(Y(X.value)));var Kk=B(2,(X,Y)=>P0(X)?p():Y(X.value));var S5=Kk(u);var k5=B(2,(X,Y)=>P0(X)?p():Y(X.value)?T(X.value):p()),MN=(X)=>D1((Y,Q)=>P0(Y)?P0(Q):P0(Q)?!1:X(Y.value,Q.value));var a7="~effect/Context/Service",yX=function(){let X=W6();P1(2);let Y=Error();P1(X);function Q(){}let J=Q;if(Object.setPrototypeOf(J,Hk),Object.defineProperty(J,"stack",{get(){return Y.stack}}),arguments.length>0){if(J.key=arguments[0],arguments[1]?.defaultValue)J[t7]=t7,J.defaultValue=arguments[1].defaultValue;return J}return function($,G){if(J.key=$,G?.make)J.make=G.make;return J}},Hk={[a7]:a7,...NN({label:"Service",evaluate(X){return G1(S1(X.context,this))}}),toJSON(){return{_id:"Service",key:this.key,stack:this.stack}},of(X){return X},context(X){return U6(this,X)},use(X){return t((Y)=>X(S1(Y.context,this)))},useSync(X){return t((Y)=>G1(X(S1(Y.context,this))))}},t7="~effect/Context/Reference",jN="~effect/Context",M8=(X)=>{let Y=Object.create(Wk);return Y.mapUnsafe=X,Y.mutable=!1,Y},Wk={...f6,[jN]:{_Services:(X)=>X},toJSON(){return{_id:"Context",services:Array.from(this.mapUnsafe).map(([X,Y])=>({key:X,value:Y}))}},[N0](X){if(!e7(X)||this.mapUnsafe.size!==X.mapUnsafe.size)return!1;for(let Y of this.mapUnsafe.keys())if(!X.mapUnsafe.has(Y)||!o(this.mapUnsafe.get(Y),X.mapUnsafe.get(Y)))return!1;return!0},[D0](){return h6(this.mapUnsafe.size)}},e7=(X)=>j(X,jN),Uk=(X)=>j(X,a7),DG=(X)=>j(X,t7),k1=()=>Dk,Dk=M8(new Map),U6=(X,Y)=>M8(new Map([[X.key,Y]])),i1=B(3,(X,Y,Q)=>UY(X,(J)=>{J.set(Y.key,Q)})),Nk=B(3,(X,Y,Q)=>UY(X,(J)=>{if(Q._tag==="None")J.delete(Y.key);else J.set(Y.key,Q.value)})),Vk=B(3,(X,Y,Q)=>{if(X.mapUnsafe.has(Y.key))return X.mapUnsafe.get(Y.key);return DG(Y)?X3(Y):Q()}),NG=B(2,(X,Y)=>X.mapUnsafe.get(Y.key)),PX=B(2,(X,Y)=>{if(!X.mapUnsafe.has(Y.key)){if(t7 in Y)return X3(Y);throw Bk(Y)}return X.mapUnsafe.get(Y.key)}),S1=PX,VG=(X,Y)=>{if(!X.mapUnsafe.has(Y.key))return X3(Y);return X.mapUnsafe.get(Y.key)},UG="~effect/Context/defaultValue",X3=(X)=>{if(UG in X)return X[UG];return X[UG]=X.defaultValue()},Bk=(X)=>{let Y=Error(`Service not found${X.key?`: ${String(X.key)}`:""}`);if(X.stack){let Q=X.stack.split(`
`);if(Q.length>2){let J=Q[2].match(/at (.*)/);if(J)Y.message=Y.message+` (defined at ${J[1]})`}}if(Y.stack){let Q=Y.stack.split(`
`);Q.splice(1,3),Y.stack=Q.join(`
`)}return Y},BG=B(2,(X,Y)=>{if(X.mapUnsafe.has(Y.key))return T(X.mapUnsafe.get(Y.key));return DG(Y)?T(X3(Y)):p()}),b5=B(2,(X,Y)=>{if(X.mapUnsafe.size===0)return Y;if(Y.mapUnsafe.size===0)return X;return UY(X,(Q)=>{Y.mapUnsafe.forEach((J,$)=>Q.set($,J))})}),zG=(...X)=>{let Y=new Map;for(let Q=0;Q<X.length;Q++)X[Q].mapUnsafe.forEach((J,$)=>{Y.set($,J)});return M8(Y)},zk=(...X)=>(Y)=>UY(Y,(Q)=>{let J=new Set(X.map(($)=>$.key));Q.forEach(($,G)=>{if(J.has(G))return;Q.delete(G)})}),qk=(...X)=>(Y)=>UY(Y,(Q)=>{for(let J=0;J<X.length;J++)Q.delete(X[J].key)}),Ok=B(2,(X,Y)=>{let Q=M8(new Map(X.mapUnsafe));Q.mutable=!0;let J=Y(Q);return J.mutable=!1,J}),UY=(X,Y)=>{if(X.mutable)return Y(X.mapUnsafe),X;let Q=new Map(X.mapUnsafe);return Y(Q),M8(Q)},L0=yX;var D6={};k6(D6,{taggedEnum:()=>Tk,TaggedError:()=>DY,TaggedClass:()=>Lk,Error:()=>Rk,Class:()=>Y3});var Y3=class extends L4{constructor(X){super();if(X)b7(this,X)}},Lk=(X)=>class extends Y3{_tag=X},Tk=()=>new Proxy({},{get(X,Y,Q){if(Y==="$is")return g6;else if(Y==="$match")return Fk;return(J)=>({...J,_tag:Y})}});function Fk(){if(arguments.length===1){let Q=arguments[0];return function(J){return Q[J._tag](J)}}let X=arguments[0];return arguments[1][X._tag](X)}var Rk=ZY,DY=A8;var i0={};k6(i0,{zipWith:()=>Ah,zip:()=>Rh,yieldNowWith:()=>Wh,yieldNow:()=>Hh,withTracerTiming:()=>Df,withTracerEnabled:()=>Uf,withTracer:()=>Wf,withSpanScoped:()=>Pf,withSpan:()=>Af,withParentSpan:()=>Ef,withLogger:()=>Yp,withLogSpan:()=>$p,withFiber:()=>aq,withExecutionPlan:()=>rh,withErrorReporting:()=>nh,whileLoop:()=>iq,when:()=>Bm,void:()=>uY,validate:()=>ny,useSpan:()=>Rf,updateServiceScoped:()=>Sm,updateService:()=>vm,updateContext:()=>xm,unwrapReason:()=>jh,uninterruptibleMask:()=>$O,uninterruptible:()=>Xf,undefined:()=>Xh,txRetry:()=>Vp,tx:()=>Wp,tryPromise:()=>O2,try:()=>J9,transposeOption:()=>Dh,trackSuccesses:()=>Gp,trackErrors:()=>Zp,trackDuration:()=>Hp,trackDefects:()=>Kp,track:()=>_p,tracer:()=>Hf,timeoutOrElse:()=>Xm,timeoutOption:()=>eh,timeout:()=>th,timed:()=>Jm,tapErrorTag:()=>mh,tapError:()=>eq,tapDefect:()=>YO,tapCauseIf:()=>fh,tapCauseFilter:()=>ph,tapCause:()=>XO,tap:()=>tq,sync:()=>nq,suspend:()=>rq,succeedSome:()=>dY,succeedNone:()=>pX,succeed:()=>d,spanLinks:()=>Of,spanAnnotations:()=>qf,sleep:()=>Qm,setContext:()=>Mm,serviceOption:()=>Im,service:()=>jm,scopedWith:()=>ym,scoped:()=>gm,scope:()=>bm,scheduleFrom:()=>_O,schedule:()=>Kf,satisfiesSuccessType:()=>zp,satisfiesServicesType:()=>Op,satisfiesErrorType:()=>qp,sandbox:()=>lh,runSyncWith:()=>df,runSyncExitWith:()=>uf,runSyncExit:()=>p8,runSync:()=>pf,runPromiseWith:()=>mf,runPromiseExitWith:()=>ff,runPromiseExit:()=>YJ,runPromise:()=>hf,runForkWith:()=>bf,runFork:()=>P2,runCallbackWith:()=>gf,runCallback:()=>yf,retryOrElse:()=>ch,retry:()=>uh,result:()=>zh,requestUnsafe:()=>wf,request:()=>Cf,replicateEffect:()=>Zf,replicate:()=>Gf,repeatOrElse:()=>_f,repeat:()=>$f,reduce:()=>ry,raceFirst:()=>Zm,raceAllFirst:()=>_m,raceAll:()=>$m,race:()=>Gm,provideServiceEffect:()=>km,provideService:()=>QO,provideContext:()=>wm,provide:()=>Cm,promise:()=>ey,partition:()=>iy,orElseSucceed:()=>sh,orDie:()=>hh,option:()=>qh,onInterrupt:()=>em,onExitPrimitive:()=>om,onExitIf:()=>im,onExitFilter:()=>rm,onExit:()=>A2,onErrorIf:()=>cm,onErrorFilter:()=>lm,onError:()=>um,never:()=>Yh,matchEffect:()=>Fm,matchEager:()=>zm,matchCauseEffectEager:()=>Lm,matchCauseEffect:()=>Tm,matchCauseEager:()=>Om,matchCause:()=>qm,match:()=>R2,mapErrorEager:()=>$9,mapError:()=>gh,mapEager:()=>r4,mapBothEager:()=>V1,mapBoth:()=>yh,map:()=>F2,makeSpanScoped:()=>Ff,makeSpan:()=>Tf,logWithLevel:()=>of,logWarning:()=>sf,logTrace:()=>Xp,logInfo:()=>tf,logFatal:()=>nf,logError:()=>af,logDebug:()=>ef,log:()=>rf,linkSpans:()=>Lf,let:()=>$h,isSuccess:()=>Am,isFailure:()=>Rm,isEffect:()=>l4,interruptibleMask:()=>Yf,interruptible:()=>tm,interrupt:()=>JO,ignoreCause:()=>ih,ignore:()=>oh,gen:()=>Gh,fromResult:()=>T2,fromOption:()=>Uh,fromNullishOr:()=>Nh,forkScoped:()=>If,forkIn:()=>jf,forkDetach:()=>xf,forkChild:()=>Mf,forever:()=>Jf,forEach:()=>ty,fnUntracedEager:()=>oY,fnUntraced:()=>cf,fn:()=>lf,flip:()=>Fh,flatten:()=>Vh,flatMapEager:()=>EX,flatMap:()=>cY,firstSuccessOf:()=>ah,findFirstFilter:()=>ay,findFirst:()=>sy,filterOrFail:()=>Nm,filterOrElse:()=>Um,filterMapOrFail:()=>Vm,filterMapOrElse:()=>Dm,filterMapEffect:()=>Wm,filterMap:()=>Hm,filter:()=>Km,fiberId:()=>kf,fiber:()=>Sf,failSync:()=>Zh,failCauseSync:()=>o4,failCause:()=>Kh,fail:()=>f,exit:()=>lY,eventually:()=>dh,ensuring:()=>dm,effectify:()=>Bp,die:()=>sq,delay:()=>Ym,currentSpan:()=>Bf,currentParentSpan:()=>zf,contextWith:()=>Em,context:()=>Pm,clockWith:()=>GO,catchTags:()=>Ch,catchTag:()=>Eh,catchReasons:()=>Mh,catchReason:()=>wh,catchNoSuchElement:()=>Sh,catchIf:()=>xh,catchFilter:()=>vh,catchEager:()=>QJ,catchDefect:()=>Ih,catchCauseIf:()=>kh,catchCauseFilter:()=>bh,catchCause:()=>i4,catch:()=>Ph,callback:()=>L2,cachedWithTTL:()=>sm,cachedInvalidateWithTTL:()=>am,cached:()=>nm,bindTo:()=>Jh,bind:()=>_h,awaitAllChildren:()=>vf,asVoid:()=>Th,asSome:()=>Lh,as:()=>Oh,annotateSpans:()=>Nf,annotateLogsScoped:()=>Jp,annotateLogs:()=>Qp,annotateCurrentSpan:()=>Vf,andThen:()=>Bh,all:()=>oy,addFinalizer:()=>pm,acquireUseRelease:()=>fm,acquireRelease:()=>hm,acquireDisposable:()=>mm,abortSignal:()=>Qf,TypeId:()=>ly,Transaction:()=>pY,Do:()=>Qh});var Q3="~effect/time/Duration",Ak=BigInt(0),Pk=BigInt(1);var Ek=BigInt(1000);var J3=(X)=>BigInt(X<0?Math.ceil(X-0.5):Math.floor(X+0.5)),SN=(X)=>J3(X*1e6),IN=(X,Y)=>X.includes(".")?J3(Number(X)*Number(Y)):BigInt(X)*Y;var Ck=/^(-?\d+(?:\.\d+)?)\s+(nanos?|micros?|millis?|seconds?|minutes?|hours?|days?|weeks?)$/,GX=(X)=>{switch(typeof X){case"number":return j8(X);case"bigint":return N6(X);case"string":{if(X==="Infinity")return r6;if(X==="-Infinity")return I4;let Y=Ck.exec(X);if(!Y)break;let[Q,J,$]=Y;if($==="nano"||$==="nanos")return N6(IN(J,Pk));if($==="micro"||$==="micros")return N6(IN(J,Ek));let G=Number(J);switch($){case"milli":case"millis":return j8(G);case"second":case"seconds":return Ik(G);case"minute":case"minutes":return xk(G);case"hour":case"hours":return vk(G);case"day":case"days":return Sk(G);case"week":case"weeks":return kk(G)}break}case"object":{if(X===null)break;if(Q3 in X)return X;if(Array.isArray(X)){if(X.length!==2||!X.every(t9))return xN(X);if(Number.isNaN(X[0])||Number.isNaN(X[1]))return g5;if(X[0]===-1/0||X[1]===-1/0)return I4;if(X[0]===1/0||X[1]===1/0)return r6;return g1(J3(X[0]*1e9+X[1]))}let Y=X,Q=0;if(Y.weeks)Q+=Y.weeks*604800000;if(Y.days)Q+=Y.days*86400000;if(Y.hours)Q+=Y.hours*3600000;if(Y.minutes)Q+=Y.minutes*60000;if(Y.seconds)Q+=Y.seconds*1000;if(Y.milliseconds)Q+=Y.milliseconds;if(!Y.microseconds&&!Y.nanoseconds)return g1(Q);return g1(J3(Q*1e6+(Y.microseconds??0)*1000+(Y.nanoseconds??0)))}}return xN(X)},xN=(X)=>{throw Error(`Invalid Input: ${X}`)},kN=j4(GX),vN={_tag:"Millis",millis:0},wk={_tag:"Infinity"},Mk={_tag:"NegativeInfinity"},jk={[Q3]:Q3,[D0](){return s_(this.value)},[N0](X){return OG(X)&&gk(this,X)},toString(){switch(this.value._tag){case"Infinity":return"Infinity";case"NegativeInfinity":return"-Infinity";case"Nanos":return`${this.value.nanos} nanos`;case"Millis":return`${this.value.millis} millis`}},toJSON(){switch(this.value._tag){case"Millis":return{_id:"Duration",_tag:"Millis",millis:this.value.millis};case"Nanos":return{_id:"Duration",_tag:"Nanos",nanos:String(this.value.nanos)};case"Infinity":return{_id:"Duration",_tag:"Infinity"};case"NegativeInfinity":return{_id:"Duration",_tag:"NegativeInfinity"}}},[U1](){return this.toJSON()},pipe(){return _0(this,arguments)}},g1=(X)=>{let Y=Object.create(jk);if(typeof X==="number")if(isNaN(X)||X===0||Object.is(X,-0))Y.value=vN;else if(!Number.isFinite(X))Y.value=X>0?wk:Mk;else if(!Number.isInteger(X))Y.value={_tag:"Nanos",nanos:SN(X)};else Y.value={_tag:"Millis",millis:X};else if(X===Ak)Y.value=vN;else Y.value={_tag:"Nanos",nanos:X};return Y},OG=(X)=>j(X,Q3);var g5=g1(0),r6=g1(1/0),I4=g1(-1/0),N6=(X)=>g1(X);var j8=(X)=>g1(X),Ik=(X)=>g1(X*1000),xk=(X)=>g1(X*60000),vk=(X)=>g1(X*3600000),Sk=(X)=>g1(X*86400000),kk=(X)=>g1(X*604800000),I8=(X)=>bk(GX(X),{onMillis:u,onNanos:(Y)=>Number(Y)/1e6,onInfinity:()=>1/0,onNegativeInfinity:()=>-1/0});var qG=(X)=>{let Y=GX(X);switch(Y.value._tag){case"Infinity":case"NegativeInfinity":throw Error("Cannot convert infinite duration to nanos");case"Nanos":return Y.value.nanos;case"Millis":return SN(Y.value.millis)}},bN=j4(qG);var bk=B(2,(X,Y)=>{switch(X.value._tag){case"Millis":return Y.onMillis(X.value.millis);case"Nanos":return Y.onNanos(X.value.nanos);case"Infinity":return Y.onInfinity();case"NegativeInfinity":return(Y.onNegativeInfinity??Y.onInfinity)()}}),gN=B(3,(X,Y,Q)=>{if(X.value._tag==="Infinity"||X.value._tag==="NegativeInfinity"||Y.value._tag==="Infinity"||Y.value._tag==="NegativeInfinity")return Q.onInfinity(X,Y);if(X.value._tag==="Millis")return Y.value._tag==="Millis"?Q.onMillis(X.value.millis,Y.value.millis):Q.onNanos(qG(X),Y.value.nanos);else return Q.onNanos(X.value.nanos,qG(Y))});var LG=(X,Y)=>gN(X,Y,{onMillis:(Q,J)=>Q===J,onNanos:(Q,J)=>Q===J,onInfinity:(Q,J)=>Q.value._tag===J.value._tag});var yN=B(2,(X,Y)=>gN(X,Y,{onMillis:(Q,J)=>g1(Q-J),onNanos:(Q,J)=>g1(Q-J),onInfinity:(Q,J)=>{let $=Q.value._tag,G=J.value._tag;if($==="Infinity")return G==="Infinity"?g5:r6;if($==="NegativeInfinity")return G==="NegativeInfinity"?g5:I4;return G==="Infinity"?I4:r6}}));var gk=B(2,(X,Y)=>LG(X,Y));var TG=(X)=>X.length>0;var k0={};k6(k0,{void:()=>hk,try:()=>FG,transposeOption:()=>_b,transposeMapOption:()=>Gb,tap:()=>Kb,succeedSome:()=>Zb,succeedNone:()=>AG,succeed:()=>m,orElse:()=>sk,merge:()=>ok,match:()=>r1,mapError:()=>x4,mapBoth:()=>hN,map:()=>ZX,makeEquivalence:()=>RG,liftPredicate:()=>ck,let:()=>$b,isSuccess:()=>Y1,isResult:()=>$3,isFailure:()=>J0,getSuccess:()=>dk,getOrUndefined:()=>rk,getOrThrowWith:()=>mN,getOrThrow:()=>nk,getOrNull:()=>ik,getOrElse:()=>x8,getFailure:()=>uk,gen:()=>Xb,fromOption:()=>pk,fromNullishOr:()=>fk,flip:()=>ek,flatMap:()=>v8,filterOrFail:()=>lk,failVoid:()=>mk,fail:()=>c,bindTo:()=>Jb,bind:()=>Qb,andThen:()=>ak,all:()=>tk,Do:()=>Yb});var m=KG,c=ZG,hk=m(void 0);var mk=c(void 0),fk=B(2,(X,Y)=>X==null?c(Y(X)):m(X)),pk=PN,FG=(X)=>{if(l1(X))try{return m(X())}catch(Y){return c(Y)}else try{return m(X.try())}catch(Y){return c(X.catch(Y))}};var $3=o7,J0=i7,Y1=r7,dk=AN,uk=RN,RG=(X,Y)=>D1((Q,J)=>J0(Q)?J0(J)&&Y(Q.failure,J.failure):Y1(J)&&X(Q.success,J.success)),hN=B(2,(X,{onFailure:Y,onSuccess:Q})=>J0(X)?c(Y(X.failure)):m(Q(X.success))),x4=B(2,(X,Y)=>J0(X)?c(Y(X.failure)):m(X.success)),ZX=B(2,(X,Y)=>Y1(X)?m(Y(X.success)):c(X.failure)),r1=B(2,(X,{onFailure:Y,onSuccess:Q})=>J0(X)?Y(X.failure):Q(X.success)),ck=B(3,(X,Y,Q)=>Y(X)?m(X):c(Q(X))),lk=B(3,(X,Y,Q)=>v8(X,(J)=>Y(J)?m(J):c(Q(J)))),ok=r1({onFailure:u,onSuccess:u}),x8=B(2,(X,Y)=>J0(X)?Y(X.failure):X.success),ik=x8(P7),rk=x8(TX),mN=B(2,(X,Y)=>{if(Y1(X))return X.success;throw Y(X.failure)}),nk=mN(u),sk=B(2,(X,Y)=>J0(X)?Y(X.failure):m(X.success)),v8=B(2,(X,Y)=>J0(X)?c(X.failure):Y(X.success)),ak=B(2,(X,Y)=>v8(X,(Q)=>{let J=l1(Y)?Y(Q):Y;return $3(J)?J:m(J)})),tk=(X)=>{if(Symbol.iterator in X){let Q=[];for(let J of X){if(J0(J))return J;Q.push(J.success)}return m(Q)}let Y={};for(let Q of Object.keys(X)){let J=X[Q];if(J0(J))return J;k(Y,Q,J.success)}return m(Y)},ek=(X)=>J0(X)?m(X.failure):c(X.success),Xb=(...X)=>{let Q=(X.length===1?X[0]:X[1].bind(X[0]))(),J=Q.next();while(!J.done){let $=J.value;if(J0($))return $;J=Q.next($.success)}return m(J.value)},Yb=m({}),Qb=c7(ZX,v8),Jb=u7(ZX),$b=d7(ZX);var _b=(X)=>{return C8(X)?AG:ZX(X.value,o6)},Gb=B(2,(X,Y)=>C8(X)?AG:ZX(Y(X.value),o6)),AG=m(E4),Zb=(X)=>m(o6(X)),Kb=B(2,(X,Y)=>{if(Y1(X))Y(X.success);return X});var i70={[Symbol.iterator](){return Hb}},Hb={next(){return{done:!0,value:void 0}}};var fN=B(2,(X,Y)=>({[Symbol.iterator](){let Q=X[Symbol.iterator](),J=0;return{next(){let $=Q.next();while(!$.done){if(Y($.value,J++))return{done:!1,value:$.value};$=Q.next()}return{done:!0,value:void 0}}}}}));var _3=B(2,(X,Y)=>{let Q={...X};for(let J of Ub(X))k(Q,J,Y(X[J],J));return Q});var Ub=(X)=>Object.keys(X);var h5=globalThis.Array;var PG=(X)=>new h5(X);var C1=(X)=>h5.isArray(X)?X:h5.from(X),dN=(X)=>h5.isArray(X)?X:[X];var G3=B(2,(X,Y)=>[...X,Y]),Db=B(2,(X,Y)=>C1(X).concat(C1(Y)));var t70=h5.isArray;var V6=TG,S8=TG;var NY=B(2,(X,Y)=>{let Q=h5.from(X);return Q.sort(Y),Q});var Nb=(X,Y)=>{let Q=X0(Y),J=X.get(Q);if(J===void 0)return X.set(Q,[Y]),!0;for(let $ of J)if(o($,Y))return!1;return J.push(Y),!0};var EG=B(2,(X,Y)=>{let Q=C1(X),J=C1(Y);if(S8(Q))return S8(J)?K3(Db(Q,J)):Q;return J});var Z3=()=>[];var B6=B(2,(X,Y)=>X.map(Y));var CG=(X)=>{let Y=[];for(let Q of X)if(N1(Q))Y.push(Q.value);return Y};var wG=B(2,(X,Y)=>{let Q=[],J=[],$=0;for(let G of X){let Z=Y(G,$++);if(Y1(Z))J.push(Z.success);else Q.push(Z.failure)}return[Q,J]});var K3=(X)=>{let Y=C1(X);if(Y.length<2)return[...Y];let Q=new Map,J=[];for(let $ of Y)if(Nb(Q,$))J.push($);return J};var Vb=l6((X,Y)=>X.concat(Y),[]);function uN(){return Vb}var MG=B(2,(X,Y)=>(Q)=>{let J=X(Q);if(J0(J))return c(Q);let $=Y(J.success);if(J0($))return c(Q);return $});var VY=L0("effect/Scheduler",{defaultValue:()=>new m5}),cN="setImmediate"in globalThis?(X)=>{let Y=globalThis.setImmediate(X);return()=>globalThis.clearImmediate(Y)}:(X)=>{let Y=setTimeout(X,0);return()=>clearTimeout(Y)};class lN{buckets=[];scheduleTask(X,Y){let Q=this.buckets,J=Q.length,$,G=0;for(;G<J;G++){if(Q[G][0]>Y)break;$=Q[G]}if($&&$[0]===Y)$[1].push(X);else if(G===J)Q.push([Y,[X]]);else Q.splice(G,0,[Y,[X]])}drain(){let X=this.buckets;return this.buckets=[],X}}class m5{executionMode;setImmediate;constructor(X="async",Y=cN){this.executionMode=X,this.setImmediate=Y}shouldYield(X){return X.currentOpCount>=X.maxOpsBeforeYield}makeDispatcher(){return new oN(this.setImmediate)}}class oN{tasks=new lN;running=void 0;setImmediate;constructor(X=cN){this.setImmediate=X}scheduleTask(X,Y){if(this.tasks.scheduleTask(X,Y),this.running===void 0)this.running=this.setImmediate(this.afterScheduled)}afterScheduled=()=>{this.running=void 0,this.runTasks()};runTasks(){let X=this.tasks.drain();for(let Y=0;Y<X.length;Y++){let Q=X[Y][1];for(let J=0;J<Q.length;J++)Q[J]()}}flush(){while(this.tasks.buckets.length>0){if(this.running!==void 0)this.running(),this.running=void 0;this.runTasks()}}}var iN=L0("effect/Scheduler/MaxOpsBeforeYield",{defaultValue:()=>2048}),rN=L0("effect/Scheduler/PreventSchedulerYield",{defaultValue:()=>!1});var jG="effect/Tracer/ParentSpan";class v4 extends yX()(jG){}var zb=(X)=>X;var H3=L0("effect/Tracer/DisablePropagation",{defaultValue:A7}),aN=L0("effect/Tracer/CurrentTraceLevel",{defaultValue:()=>"Info"}),tN=L0("effect/Tracer/MinimumTraceLevel",{defaultValue:()=>"All"}),IG="effect/Tracer",W3=L0(IG,{defaultValue:()=>zb({span:(X)=>new eN(X)})});class eN{_tag="Span";spanId;traceId="native";sampled;name;parent;annotations;links;startTime;kind;status;attributes;events=[];constructor(X){this.name=X.name,this.parent=X.parent,this.annotations=X.annotations,this.links=X.links,this.startTime=X.startTime,this.kind=X.kind,this.sampled=X.sampled,this.status={_tag:"Started",startTime:X.startTime},this.attributes=new Map,this.traceId=M4(X.parent)?.traceId??sN(32),this.spanId=sN(16)}end(X,Y){this.status={_tag:"Ended",endTime:X,exit:Y,startTime:this.status.startTime}}attribute(X,Y){this.attributes.set(X,Y)}event(X,Y,Q){this.events.push([X,Y,Q??{}])}addLinks(X){this.links.push(...X)}}var sN=function(){return function(Q){let J="";for(let $=0;$<Q;$++)J+="abcdef0123456789".charAt(Math.floor(Math.random()*16));return J}}();var YV="effect/observability/Metric/FiberRuntimeMetricsKey";var QV=L0("effect/ErrorReporter/CurrentErrorReporters",{defaultValue:()=>new Set}),f5=L0("effect/References/CurrentStackFrame",{defaultValue:TX}),U3=L0("effect/References/TracerEnabled",{defaultValue:b6}),BY=L0("effect/References/TracerTimingEnabled",{defaultValue:b6}),zY=L0("effect/References/TracerSpanAnnotations",{defaultValue:()=>({})}),qY=L0("effect/References/TracerSpanLinks",{defaultValue:()=>[]}),n6=L0("effect/References/CurrentLogAnnotations",{defaultValue:()=>({})}),xG=L0("effect/References/CurrentLogLevel",{defaultValue:()=>"Info"}),vG=L0("effect/References/MinimumLogLevel",{defaultValue:()=>"Info"});var D3=L0("effect/References/CurrentLogSpans",{defaultValue:()=>[]});var k8=(X)=>{if(X?.captureStackTrace===!1)return X;else if(X?.captureStackTrace!==void 0&&typeof X.captureStackTrace!=="boolean")return X;let Y=W6();P1(3);let Q=Error();return P1(Y),{...X,captureStackTrace:Lb(()=>Q.stack)}},SG=(X)=>(Y)=>{let Q;return()=>{if(Q!==void 0)return Q;let J=Y();if(!J)return;let $=J.split(`
`);if($[X]!==void 0)return Q=$[X].trim(),Q}},Lb=SG(3);var JV="dev";class oG extends JY{fiberId;constructor(X,Y=$Y){super("Interrupt",Y,"Interrupted");this.fiberId=X}toString(){return`Interrupt(${this.fiberId})`}toJSON(){return{_tag:"Interrupt",fiberId:this.fiberId}}[N0](X){return m7(X)&&this.fiberId===X.fiberId&&this.annotations===X.annotations}[D0](){return _1(g0(`${this._tag}:${this.fiberId}`))(M7(this.annotations))}}var WV=(X)=>new oG(X),V3=(X)=>new p6([new oG(X)]);var UV=(X)=>{let Y=X.reasons.find(P4);return Y?m(Y):c(X)},O6=(X)=>{for(let Y=0;Y<X.reasons.length;Y++){let Q=X.reasons[Y];if(Q._tag==="Fail")return m(Q.error)}return c(X)};var DV=(X)=>X.reasons.some(GY);var iG=(X)=>{let Y=X.reasons.find(GY);return Y?m(Y.defect):c(X)},NV=(X)=>X.reasons.some(m7);var VV=(X)=>{let Y;for(let Q=0;Q<X.reasons.length;Q++){let J=X.reasons[Q];if(J._tag!=="Interrupt")continue;if(Y??=new Set,J.fiberId!==void 0)Y.add(J.fiberId)}return Y?m(Y):c(X)};var BV=B(2,(X,Y)=>{if(X.reasons.length===0)return Y;else if(Y.reasons.length===0)return X;let Q=new p6(EG(X.reasons,Y.reasons));return o(X,Q)?X:Q}),zV=B(2,(X,Y)=>{let Q=!1,J=X.reasons.map(($)=>{if(P4($))return Q=!0,new I5(Y($.error));return $});return Q?d6(J):X}),Fb=(X)=>{let Y={Fail:[],Die:[],Interrupt:[]};for(let Q=0;Q<X.reasons.length;Q++)Y[X.reasons[Q]._tag].push(X.reasons[Q]);return Y},rG=(X)=>{let Y=Fb(X);if(Y.Fail.length>0)return Y.Fail[0].error;else if(Y.Die.length>0)return Y.Die[0].defect;else if(Y.Interrupt.length>0)return new globalThis.Error("All fibers interrupted without error");return new globalThis.Error("Empty cause")},qV=(X,Y)=>{let Q=[],J=[];if(X.reasons.length===0)return Q;let $=W6();P1(1);for(let G of X.reasons){if(G._tag==="Interrupt"){J.push(G);continue}Q.push(bG(G._tag==="Die"?G.defect:G.error,G.annotations,Y))}if(Q.length===0){let G=Error("The fiber was interrupted by:");G.name="InterruptCause",G.stack=Eb(G,J);let Z=new globalThis.Error("All fibers interrupted without error",{cause:G});Z.name="InterruptError",Z.stack=`${Z.name}: ${Z.message}`,Q.push(bG(Z,J[0].annotations,Y))}return P1($),Q},bG=(X,Y,Q)=>{let J=typeof X,$;if(X&&J==="object"){if($=new globalThis.Error(Rb(X),{cause:X.cause?bG(X.cause):void 0}),typeof X.name==="string")$.name=X.name;if(typeof X.stack==="string")$.stack=Pb(X.stack,$,Y);else{let G=`${$.name}: ${$.message}`;$.stack=Y?OV(G,Y):G}if(Q?.includeCauseInStack)$.stack=TV($);for(let G of Object.keys(X))if(!(G in $))$[G]=X[G]}else $=new globalThis.Error(!X?`Unknown error: ${X}`:J==="string"?X:F4(X));return $},Rb=(X)=>{if(typeof X.message==="string")return X.message;else if(typeof X.toString==="function"&&X.toString!==Object.prototype.toString&&X.toString!==Array.prototype.toString)try{return X.toString()}catch{}return F4(X)},Ab=/\((.*)\)/g,Pb=(X,Y,Q)=>{let J=`${Y.name}: ${Y.message}`,$=(X.startsWith(J)?X.slice(J.length):X).split(`
`),G=[J];for(let Z=1;Z<$.length;Z++){if(/(?:Generator\.next|~effect\/Effect)/.test($[Z]))break;G.push($[Z])}return Q?OV(G.join(`
`),Q):G.join(`
`)},OV=(X,Y)=>{let Q=Y?.get(f7.key);if(Q)X=`${X}
${LV(Q)}`;return X},Eb=(X,Y)=>{let Q=[`${X.name}: ${X.message}`];for(let J of Y){let $=J.fiberId!==void 0?`#${J.fiberId}`:"unknown",G=J.annotations.get(JG.key);if(Q.push(`    at fiber (${$})`),G)Q.push(LV(G))}return Q.join(`
`)},LV=(X)=>{let Y=[],Q=X,J=0;while(Q&&J<10){let $=Q.stack();if($){let G=$.matchAll(Ab),Z=!1;for(let[,K]of G)Z=!0,Y.push(`    at ${Q.name} (${K})`);if(!Z)Y.push(`    at ${Q.name} (${$.replace(/^at /,"")})`)}else Y.push(`    at ${Q.name}`);Q=Q.parent,J++}return Y.join(`
`)},B3=(X)=>qV(X).map(TV).join(`
`),TV=(X)=>X.cause?`${X.stack} {
${FV(X.cause,"  ")}
}`:X.stack,FV=(X,Y)=>{let Q=X.stack.split(`
`),J=`${Y}[cause]: ${Q[0]}`;for(let $=1,G=Q.length;$<G;$++)J+=`
${Y}${Q[$]}`;if(X.cause)J+=` {
${FV(X.cause,`${Y}  `)}
${Y}}`;return J},gG=`~effect/Fiber/${JV}`,Cb={_A:u,_E:u},wb={id:0},z3=()=>globalThis[w5];class nG{constructor(X,Y=!0){this[gG]=Cb,this.setContext(X),this.id=++wb.id,this.currentOpCount=0,this.interruptible=Y,this._stack=[],this._observers=[],this._exit=void 0,this._children=void 0,this._interruptedCause=void 0,this._yielded=void 0,this._running=!1,this._deferredInterrupt=!1,this.runtimeMetrics?.recordFiberStart(this.context)}[gG];id;interruptible;currentOpCount;_stack;_observers;_exit;_children;_interruptedCause;_yielded;_running;_deferredInterrupt;context;currentScheduler;currentTracerContext;currentSpan;currentLogLevel;minimumLogLevel;currentStackFrame;runtimeMetrics;maxOpsBeforeYield;currentPreventYield;_dispatcher=void 0;get currentDispatcher(){return this._dispatcher??=this.currentScheduler.makeDispatcher()}getRef(X){return VG(this.context,X)}addObserver(X){if(this._exit)return X(this._exit),E7;return this._observers.push(X),()=>{let Y=this._observers.indexOf(X);if(Y>=0)this._observers.splice(Y,1)}}interruptUnsafe(X,Y){if(this._exit)return;let Q=V3(X);if(this.currentStackFrame)Q=_Y(Q,U6(f7,this.currentStackFrame));if(Y)Q=_Y(Q,Y);if(this._interruptedCause=this._interruptedCause?BV(this._interruptedCause,Q):Q,this.interruptible)if(this._running)this._deferredInterrupt=!0;else this.evaluate(A0(this._interruptedCause))}pollUnsafe(){return this._exit}evaluate(X){if(this._exit)return;else if(this._yielded!==void 0){let J=this._yielded;this._yielded=void 0,J()}let Y=this.runLoop(X);if(Y===A4)return;let Q=yG.interruptChildren&&yG.interruptChildren(this);if(Q!==void 0)return this.evaluate(v(Q,()=>Y));this._exit=Y,this.runtimeMetrics?.recordFiberEnd(this.context,this._exit);for(let J=0;J<this._observers.length;J++)this._observers[J](Y);this._observers.length=0,this._stack.length=0,this._children=void 0,this.context=k1()}runLoop(X){let Y=globalThis[w5];globalThis[w5]=this;let Q=this._running;this._running=!0;let J=!1,$=X;this.currentOpCount=0;try{while(!0){if(this._deferredInterrupt)this._deferredInterrupt=!1,$=A0(this._interruptedCause);if(this.currentOpCount++,!J&&!this.currentPreventYield&&this.currentScheduler.shouldYield(this)){J=!0;let G=$;$=v(c5,()=>G)}if($=this.currentTracerContext?this.currentTracerContext($,this):$[o0](this),$===A4){let G=this._yielded;if(R4 in G)return this._deferredInterrupt=!1,this._yielded=void 0,G;else if(this._deferredInterrupt){this._yielded=void 0,G();continue}return A4}}}catch(G){if(!j($,o0))return H6(`Fiber.runLoop: Not a valid effect: ${String($)}`);return this.runLoop(H6(G))}finally{this._running=Q,globalThis[w5]=Y}}getCont(X){if(this._deferredInterrupt)return this._deferredInterrupt=!1,Mb;while(!0){let Y=this._stack.pop();if(!Y)return;let Q=Y[R8]&&Y[R8](this);if(Q)return Q[X]=Q,Q;if(Y[X])return Y}}yieldWith(X){return this._yielded=X,A4}children(){return this._children??=new Set}pipe(){return _0(this,arguments)}setContext(X){this.context=X;let Y=this.getRef(VY);if(Y!==this.currentScheduler)this.currentScheduler=Y,this._dispatcher=void 0;this.currentSpan=X.mapUnsafe.get(jG),this.currentLogLevel=this.getRef(xG),this.minimumLogLevel=this.getRef(vG),this.currentStackFrame=X.mapUnsafe.get(f5.key),this.maxOpsBeforeYield=this.getRef(iN),this.currentPreventYield=this.getRef(rN),this.runtimeMetrics=X.mapUnsafe.get(YV);let Q=X.mapUnsafe.get(IG);this.currentTracerContext=Q?Q.context:void 0}get currentSpanLocal(){return this.currentSpan?._tag==="Span"?this.currentSpan:void 0}}var Mb={[v1](X,Y){return A0(Y._interruptedCause)},[FX](X,Y){return A0(Y._interruptedCause)}},yG={interruptChildren:void 0},q3=(X)=>{if(!X.currentStackFrame)return;let Y=new Map;return Y.set(JG.key,X.currentStackFrame),M8(Y)},jb=(X)=>{if(X._children===void 0||X._children.size===0)return;return k4(X._children)},Ib=(X)=>{let Y=X;if(Y._exit)return M(Y._exit);return n1((Q)=>{if(Y._exit)return Q(M(Y._exit));return Y0(X.addObserver((J)=>Q(M(J))))})},sG=(X)=>n1((Y)=>{let Q=X[Symbol.iterator](),J=[],$=void 0;function G(){let Z=Q.next();while(!Z.done){if(Z.value._exit){J.push(Z.value._exit),Z=Q.next();continue}$=Z.value.addObserver((K)=>{J.push(K),G()});return}Y(M(J))}return G(),Y0(()=>$?.())});var xb=(X)=>t((Y)=>vb(X,Y.id)),vb=B((X)=>j(X[0],gG),(X,Y,Q)=>t((J)=>{let $=q3(J);return $=$&&Q?b5($,Q):$??Q,X.interruptUnsafe(Y,$),FY(Ib(X))})),k4=(X)=>t((Y)=>{let Q=q3(Y),J=Z3();for(let $ of X)$.interruptUnsafe(Y.id,Q),J.push($);return FY(sG(J))});var M=G1,A0=_X,w0=K6,Y0=RX({op:"Sync",[o0](X){let Y=this[G0](),Q=X.getCont(v1);return Q?Q[v1](Y,X):X.yieldWith(G1(Y))}}),e=RX({op:"Suspend",[o0](X){return this[G0]()}}),RV=B((X)=>X.length>=2||n7(X[0]),(X,Y)=>P0(X)?w0(Y?Y():new c6("Effect.fromOption: Option.none")):M(X.value)),u5=r1({onFailure:w0,onSuccess:M}),AV=(X)=>X==null?w0(new c6):M(X),aG=RX({op:"Yield",[o0](X){let Y=!1;return X.currentDispatcher.scheduleTask(()=>{if(Y)return;X.evaluate(HX)},this[G0]??0),X.yieldWith(()=>{Y=!0})}}),c5=aG(0),tG=(X)=>M(T(X)),LY=M(p()),PV=(X)=>P0(X)?LY:z0(X.value,T),EV=(X)=>e(()=>A0(W0(X))),s6=(X)=>H6(X),O3=(X)=>e(()=>w0(W0(X))),$0=M(void 0);var CV=(X)=>{let Y=typeof X==="function"?X:X.try,Q=typeof X==="function"?(J)=>new b3(J,"An error occurred in Effect.try"):X.catch;return e(()=>{try{return M(W0(Y))}catch(J){return w0(W0(()=>Q(J)))}})};var eG=(X)=>XZ(function(Y,Q){W0(()=>X(Q)).then((J)=>Y(M(J)),(J)=>Y(s6(J)))},X.length!==0),wV=(X)=>{let Y=typeof X==="function"?X:X.try,Q=typeof X==="function"?(J)=>new b3(J,"An error occurred in Effect.tryPromise"):X.catch;return XZ(function(J,$){let G=(Z)=>{try{J(w0(W0(()=>Q(Z))))}catch(K){J(s6(K))}};try{W0(()=>Y($)).then((Z)=>J(M(Z)),G)}catch(Z){G(Z)}},Y.length!==0)},MV=(X)=>t((Y)=>X(Y.id)),jV=t(M),IV=MV(M),XZ=RX({op:"Async",single:!1,[o0](X){let Y=W0(()=>this[G0][0].bind(X.currentScheduler)),Q=!1,J=!1,$=this[G0][1]?new AbortController:void 0,G=Y((Z)=>{if(Q)return;if(Q=!0,J)X.evaluate(Z);else J=Z},$?.signal);if(J!==!1)return J;if(J=!0,X._yielded=()=>{Q=!0},$===void 0&&G===void 0)return A4;return X._stack.push(Sb(()=>{return Q=!0,$?.abort(),G??HX})),A4}}),Sb=RX({op:"AsyncFinalizer",[R8](X){if(X.interruptible)X.interruptible=!1,X._stack.push(v3)},[FX](X,Y){return NV(X)?v(this[G0](),()=>A0(X)):A0(X)}}),n1=(X)=>XZ(X,X.length>=2),TY=n1(E7),xV=(...X)=>e(()=>p5(X.length===1?X[0]():X[1].call(X[0].self))),YZ=(X,...Y)=>{let Q=Y.length===0?function(){return e(()=>p5(X.apply(this,arguments)))}:function(){let J=e(()=>p5(X.apply(this,arguments)));for(let $=0;$<Y.length;$++)J=Y[$](J,...arguments);return J};return QZ(X.length,Q)},QZ=(X,Y)=>Object.defineProperty(Y,"length",{value:X,configurable:!0}),$V=SG(2),vV=function(){let X=typeof arguments[0]==="string",Y=X?arguments[0]:"Effect.fn",Q=X?arguments[1]:void 0,J=W6();P1(2);let $=new globalThis.Error;if(P1(J),X)return(G,...Z)=>_V(Y,G,$,Z,X,Q);return _V(Y,arguments[0],$,Array.prototype.slice.call(arguments,1),X,Q)},_V=(X,Y,Q,J,$,G)=>{let Z=typeof Y==="function"?Y:J.pop().bind(Y.self);return QZ(Z.length,function(...K){let H=e(()=>{let U=Z.apply(this,arguments);return i(U)?U:p5(U)});for(let U=0;U<J.length;U++)H=J[U](H,...K);if(!i(H))return H;let W=W6();P1(2);let D=new globalThis.Error;return P1(W),a6($?OY(X,G,(U)=>pG(H,U)):H,f5,(U)=>({name:X,stack:$V(()=>D.stack),parent:{name:`${X} (definition)`,stack:$V(()=>Q.stack),parent:U}}))})},SV=(X,...Y)=>QZ(X.length,Y.length===0?function(){return GV(()=>X.apply(this,arguments))}:function(){let Q=GV(()=>X.apply(this,arguments));for(let J of Y)Q=J(Q);return Q}),GV=(X)=>{try{let Y=X(),Q=void 0;while(!0){let J=Y.next(Q);if(J.done)return M(J.value);let $=J.value;if($&&$._tag==="Success"){Q=$.value;continue}else if($&&$._tag==="Failure")return J.value;else{let G=!0;return e(()=>{if(G)return G=!1,v(J.value,(Z)=>p5(Y,Z));else return e(()=>p5(X()))})}}}catch(Y){return s6(Y)}},p5=RX({op:"Iterator",single:!1,[v1](X,Y){let Q=this[G0][0];while(!0){let J=Q.next(X);if(J.done)return M(J.value);if(!w1(J.value))return Y._stack.push(this),J.value;else if(J.value._tag==="Failure")return J.value;X=J.value.value}},[o0](X){return this[v1](this[G0][1],X)}}),y1=B(2,(X,Y)=>{let Q=M(Y);return v(X,(J)=>Q)}),L3=(X)=>z0(X,T),kV=(X)=>b4(X,{onFailure:M,onSuccess:w0}),mX=B(2,(X,Y)=>v(X,(Q)=>i(Y)?Y:W0(()=>Y(Q)))),L6=B(2,(X,Y)=>v(X,(Q)=>y1(i(Y)?Y:W0(()=>Y(Q)),Q))),FY=(X)=>v(X,(Y)=>HX),bV=(X)=>s1(X,w0),JZ=(X,Y)=>t((Q)=>n1((J)=>{let $=C1(X),G=$.length,Z=0,K=!1,H=new Set,W=[],D=(U,N,V)=>{if(Z++,U._tag==="Failure"){if(W.push(...U.cause.reasons),Z>=G)J(A0(d6(W)));return}let z=!K;if(K=!0,J(H.size===0?U:v(X8(k4(H)),()=>U)),z&&Y?.onWinner)Y.onWinner({fiber:N,index:V,parentFiber:Q})};for(let U=0;U<G;U++){let N=g4(Q,$[U],!0,!0,!1);if(H.add(N),N.addObserver((V)=>{H.delete(N),D(V,N,U)}),K)break}return k4(H)})),$Z=(X,Y)=>t((Q)=>n1((J)=>{let $=!1,G=new Set,Z=(H)=>{$=!0,J(G.size===0?H:v(X8(k4(G)),()=>H))},K=0;for(let H of X){if($)break;let W=K++,D=g4(Q,H,!0,!0,!1);G.add(D),D.addObserver((U)=>{G.delete(D);let N=!$;if(Z(U),N&&Y?.onWinner)Y.onWinner({fiber:D,index:W,parentFiber:Q})})}return k4(G)})),gV=B((X)=>i(X[1]),(X,Y,Q)=>JZ([X,Y],Q)),T3=B((X)=>i(X[1]),(X,Y,Q)=>$Z([X,Y],Q)),v=B(2,(X,Y)=>{let Q=Object.create(kb);return Q[G0]=X,Q[v1]=Y.length!==1?(J)=>Y(J):Y,Q}),kb=u6({op:"OnSuccess",[o0](X){return X._stack.push(this),this[G0]}}),yV=B(2,(X,Y)=>{if(w1(X))return X._tag==="Success"?Y.onSuccess(X.value):Y.onFailure(X.cause);return q6(X,Y)}),w1=(X)=>(R4 in X),hV=B(2,(X,Y)=>{if(w1(X))return X._tag==="Success"?Y(X.value):X;return v(X,Y)}),mV=(X)=>v(X,u),z0=B(2,(X,Y)=>v(X,(Q)=>M(W0(()=>Y(Q))))),fV=B(2,(X,Y)=>w1(X)?oV(X,Y):z0(X,Y)),pV=B(2,(X,Y)=>w1(X)?iV(X,Y):UZ(X,Y)),dV=B(2,(X,Y)=>w1(X)?rV(X,Y):DZ(X,Y)),uV=B(2,(X,Y)=>{if(w1(X)){if(X._tag==="Success")return X;let Q=O6(X.cause);if(J0(Q))return X;return Y(Q.success)}return m1(X,Y)});var _Z=(X)=>X._tag==="Success";var cV=(X)=>X._tag==="Failure";var lV=(X)=>X._tag==="Failure"?m(X.cause):c(X);var HX=G1(void 0),oV=B(2,(X,Y)=>X._tag==="Success"?G1(Y(X.value)):X),iV=B(2,(X,Y)=>{if(X._tag==="Success")return X;let Q=O6(X.cause);if(J0(Q))return X;return K6(Y(Q.success))}),rV=B(2,(X,Y)=>{if(X._tag==="Success")return G1(Y.onSuccess(X.value));let Q=O6(X.cause);if(J0(Q))return X;return K6(Y.onFailure(Q.success))});var nV=(X)=>{let Y=[];for(let Q of X)if(Q._tag==="Failure")Y.push(...Q.cause.reasons);return Y.length===0?HX:_X(d6(Y))};var sV=(X)=>X,aV=(X)=>t((Y)=>M(BG(Y.context,X))),bb=(X)=>t((Y)=>Y.context.mapUnsafe.has(X.key)?M(PX(Y.context,X)):w0(new c6)),l5=B(2,(X,Y)=>t((Q)=>{let J=Q.context,$=Y(J);if(J===$)return X;return Q.setContext($),r5(X,()=>{Q.setContext(J);return})})),a6=B(3,(X,Y,Q)=>l5(X,(J)=>{let $=PX(J,Y),G=Q($);if($===G)return J;return i1(J,Y,G)})),tV=(X,Y,Q)=>X8(t((J)=>{let $=PX(J.context,X),G=Y($);return J.setContext(i1(J.context,X,G)),e6(PX(J.context,y8),(Z)=>{let K=PX(J.context,X),H;if(Q?.reset===void 0){if(K!==G)return $0;H=$}else H=Q.reset($,G,K);return J.setContext(i1(J.context,X,H)),$0})})),GZ=()=>gb,gb=t((X)=>M(X.context)),g8=(X)=>t((Y)=>X(Y.context)),eV=B(2,(X,Y)=>l5(X,W1(Y))),t6=B(2,(X,Y)=>{if(w1(X))return X;return l5(X,b5(Y))}),h1=function(){if(arguments.length===1)return B(2,(X,Y)=>ZV(X,arguments[0],Y));return B(3,(X,Y,Q)=>ZV(X,Y,Q)).apply(this,arguments)},ZV=(X,Y,Q)=>l5(X,(J)=>{if(J.mapUnsafe.get(Y.key)===Q)return J;return i1(J,Y,Q)}),F3=B(3,(X,Y,Q)=>v(Q,(J)=>h1(X,Y,J))),XB=B((X)=>i(X[1]),(X,Y,Q)=>ZZ(X,Y,(J,$)=>[J,$],Q)),ZZ=B((X)=>i(X[1]),(X,Y,Q,J)=>J?.concurrent?z0(MY([X,Y],{concurrency:2}),([$,G])=>W0(()=>Q($,G))):v(X,($)=>z0(Y,(G)=>W0(()=>Q($,G))))),YB=B((X)=>i(X[0]),(X,Y,Q)=>EZ(X,Y,Q?(J)=>w0(Q(J)):()=>w0(new c6))),QB=B(2,(X,Y)=>v(Y,(Q)=>Q?L3(X):LY)),KZ=B(2,(X,Y)=>Array.from({length:Y},()=>X)),JB=B((X)=>i(X[0]),(X,Y,Q)=>MY(KZ(X,Y),Q)),R3=B((X)=>i(X[0]),(X,Y)=>Y8({while:b6,body:W1(Y?.disableYield?X:v(X,(Q)=>c5)),step:E7})),s1=B(2,(X,Y)=>{let Q=Object.create(yb);return Q[G0]=X,Q[FX]=Y.length!==1?(J)=>Y(J):Y,Q}),yb=u6({op:"OnFailure",[o0](X){return X._stack.push(this),this[G0]}}),HZ=B(3,(X,Y,Q)=>s1(X,(J)=>{if(!Y(J))return A0(J);return W0(()=>Q(J))})),o5=B(3,(X,Y,Q)=>s1(X,(J)=>{let $=Y(J);return J0($)?A0($.failure):W0(()=>Q($.success,J))})),m1=B(2,(X,Y)=>o5(X,O6,(Q)=>Y(Q))),$B=(X)=>b4(X,{onFailure:(Y)=>$G(Y)?LY:w0(Y),onSuccess:tG}),_B=B(2,(X,Y)=>o5(X,iG,Y)),GB=B(2,(X,Y)=>s1(X,(Q)=>mX(W0(()=>Y(Q)),A0(Q)))),ZB=B(3,(X,Y,Q)=>HZ(X,Y,(J)=>mX(W0(()=>Q(J)),A0(J)))),A3=B(3,(X,Y,Q)=>s1(X,(J)=>{let $=Y(J);if(J0($))return A0(J);return mX(W0(()=>Q($.success,J)),A0(J))})),WZ=B(2,(X,Y)=>A3(X,O6,(Q)=>Y(Q))),KB=B(3,(X,Y,Q)=>{let J=Array.isArray(Y)?($)=>j($,"_tag")&&Y.includes($._tag):g6(Y);return WZ(X,($)=>J($)?Q($):$0)}),HB=B(2,(X,Y)=>A3(X,iG,(Q)=>Y(Q))),RY=B((X)=>i(X[0]),(X,Y,Q,J)=>s1(X,($)=>{let G=O6($);if(J0(G))return A0(G.failure);if(!Y(G.success))return J?W0(()=>J(G.success)):A0($);return W0(()=>Q(G.success))})),P3=B((X)=>i(X[0]),(X,Y,Q,J)=>s1(X,($)=>{let G=O6($);if(J0(G))return A0(G.failure);let Z=Y(G.success);if(J0(Z))return J?W0(()=>J(Z.failure)):A0($);return W0(()=>Q(Z.success))})),E3=B((X)=>i(X[0]),(X,Y,Q,J)=>{let $=Array.isArray(Y)?(G)=>j(G,"_tag")&&Y.includes(G._tag):g6(Y);return RY(X,$,Q,J)}),WB=B((X)=>i(X[0]),(X,Y,Q)=>{let J;return P3(X,($)=>{return J??=Object.keys(Y),j($,"_tag")&&bX($._tag)&&J.includes($._tag)?m($):c($)},($)=>W0(()=>Y[$._tag]($)),Q)}),UB=B((X)=>i(X[0]),(X,Y,Q,J,$)=>RY(X,(G)=>g6(G,Y)&&j(G,"reason"),(G)=>{let Z=G.reason;if(g6(Z,Q))return J(Z,G);return $?W0(()=>$(Z,G)):w0(G)})),DB=B((X)=>i(X[0]),(X,Y,Q,J)=>{let $;return RY(X,(G)=>g6(G,Y)&&j(G,"reason")&&j(G.reason,"_tag")&&bX(G.reason._tag),(G)=>{let Z=G.reason;if($??=Object.keys(Q),$.includes(Z._tag))return W0(()=>Q[Z._tag](Z,G));return J?W0(()=>J(Z,G)):w0(G)})}),NB=B(2,(X,Y)=>P3(X,(Q)=>{if(g6(Q,Y)&&j(Q,"reason"))return m(Q.reason);return c(Q)},w0)),UZ=B(2,(X,Y)=>m1(X,(Q)=>O3(()=>Y(Q)))),DZ=B(2,(X,Y)=>b4(X,{onFailure:(Q)=>O3(()=>Y.onFailure(Q)),onSuccess:(Q)=>Y0(()=>Y.onSuccess(Q))})),C3=(X)=>m1(X,s6),VB=B(2,(X,Y)=>m1(X,(Q)=>Y0(Y))),BB=(X)=>e(()=>{let Y=X[Symbol.iterator](),Q=Y.next();if(Q.done)return s6(Error("Received an empty collection of effects"));function J($){let G=Y.next();if(G.done)return $.value;return m1($.value,(Z)=>J(G))}return J(Q)}),NZ=(X)=>m1(X,(Y)=>v(c5,()=>NZ(X))),zB=B((X)=>i(X[0]),(X,Y)=>{if(!Y?.log)return b4(X,{onFailure:(J)=>$0,onSuccess:(J)=>$0});let Q=fX(Y.log===!0?void 0:Y.log);return q6(X,{onFailure(J){let $=UV(J);return J0($)?A0($.failure):Y.message===void 0?Q(J):Q(Y.message,J)},onSuccess:(J)=>$0})}),qB=B((X)=>i(X[0]),(X,Y)=>{if(!Y?.log)return q6(X,{onFailure:(J)=>$0,onSuccess:(J)=>$0});let Q=fX(Y.log===!0?void 0:Y.log);return q6(X,{onFailure:(J)=>Y.message===void 0?Q(J):Q(Y.message,J),onSuccess:(J)=>$0})}),OB=(X)=>w3(X,{onFailure:p,onSuccess:T}),b8=(X)=>AY(X,{onFailure:c,onSuccess:m}),q6=B(2,(X,Y)=>{let Q=Object.create(hb);return Q[G0]=X,Q[v1]=Y.onSuccess.length!==1?(J)=>Y.onSuccess(J):Y.onSuccess,Q[FX]=Y.onFailure.length!==1?(J)=>Y.onFailure(J):Y.onFailure,Q}),hb=u6({op:"OnSuccessAndFailure",[o0](X){return X._stack.push(this),this[G0]}}),VZ=B(2,(X,Y)=>q6(X,{onFailure:(Q)=>Y0(()=>Y.onFailure(Q)),onSuccess:(Q)=>Y0(()=>Y.onSuccess(Q))})),b4=B(2,(X,Y)=>q6(X,{onFailure:(Q)=>{let J=Q.reasons.find(P4);return J?W0(()=>Y.onFailure(J.error)):A0(Q)},onSuccess:Y.onSuccess})),w3=B(2,(X,Y)=>b4(X,{onFailure:(Q)=>Y0(()=>Y.onFailure(Q)),onSuccess:(Q)=>Y0(()=>Y.onSuccess(Q))})),AY=B(2,(X,Y)=>{if(w1(X)){if(X._tag==="Success")return G1(Y.onSuccess(X.value));let Q=O6(X.cause);if(J0(Q))return X;return G1(Y.onFailure(Q.success))}return w3(X,Y)}),LB=B(2,(X,Y)=>{if(w1(X)){if(X._tag==="Success")return G1(Y.onSuccess(X.value));return G1(Y.onFailure(X.cause))}return VZ(X,Y)}),PY=(X)=>w1(X)?G1(X):mb(X),mb=RX({op:"Exit",[o0](X){return X._stack.push(this),this[G0]},[v1](X,Y,Q){return M(Q??G1(X))},[FX](X,Y,Q){return M(Q??_X(X))}}),TB=AY({onFailure:()=>!0,onSuccess:()=>!1}),FB=AY({onFailure:()=>!1,onSuccess:()=>!0}),RB=B(2,(X,Y)=>mX(h4(Y),X)),BZ=B(2,(X,Y)=>T3(X,v(h4(Y.duration),Y.orElse))),AB=B(2,(X,Y)=>BZ(X,{duration:Y,orElse:()=>w0(new vZ)})),PB=B(2,(X,Y)=>T3(L3(X),y1(h4(Y),p()))),EB=(X)=>y4((Y)=>{let Q=Y.currentTimeNanosUnsafe();return z0(X,(J)=>[N6(Y.currentTimeNanosUnsafe()-Q),J])}),hG="~effect/Scope",mG="~effect/Scope/Closeable",y8=yX("effect/Scope"),zZ=(X,Y)=>e(()=>M3(X,Y)??$0),M3=(X,Y)=>{if(X.state._tag==="Closed")return;let Q={_tag:"Closed",exit:Y};if(X.state._tag==="Empty"){X.state=Q;return}let{finalizers:J}=X.state;if(X.state=Q,J.size===0)return;else if(J.size===1)return J.values().next().value(Y);return fb(X,J,Y)},fb=YZ(function*(X,Y,Q){let J=[],$=[],G=Array.from(Y.values()),Z=z3();for(let K=G.length-1;K>=0;K--){let H=G[K];if(X.strategy==="sequential")J.push(yield*PY(H(Q)));else $.push(g4(Z,H(Q),!0,!0,"inherit"))}if($.length>0)J=yield*sG($);return yield*nV(J)});var CB=(X,Y)=>{let Q=EY(Y);if(X.state._tag==="Closed")return Q.state=X.state,Q;let J={};return N3(X,J,($)=>zZ(Q,$)),N3(Q,J,($)=>Y0(()=>wB(X,J))),Q},e6=(X,Y)=>{return e(()=>{if(X.state._tag==="Closed")return Y(X.state.exit);return N3(X,{},Y),$0})};var N3=(X,Y,Q)=>{if(X.state._tag==="Empty")X.state={_tag:"Open",finalizers:new Map([[Y,Q]])};else if(X.state._tag==="Open")X.state.finalizers.set(Y,Q)},wB=(X,Y)=>{if(X.state._tag==="Open")X.state.finalizers.delete(Y)},EY=(X="sequential")=>({[mG]:mG,[hG]:hG,strategy:X,state:pb}),pb={_tag:"Empty"};var CY=y8,MB=h1(y8),j3=(X)=>t((Y)=>{let Q=Y.context,J=EY();return Y.setContext(i1(Y.context,y8,J)),r5(X,($)=>{return Y.setContext(Q),M3(J,$)})});var I3=(X)=>e(()=>{let Y=EY();return f1(X(Y),(Q)=>e(()=>M3(Y,Q)??$0))}),x3=(X,Y,Q)=>g8((J)=>wY(($)=>v(CY,(G)=>L6(Q?.interruptible?$(X):X,(Z)=>e6(G,(K)=>t6(Y(Z,K),J)))))),i5=(X)=>v(CY,(Y)=>g8((Q)=>e6(Y,(J)=>t6(X(J),Q)))),r5=RX({op:"OnExit",single:!1,[o0](X){return X._stack.push(this),this[G0][0]},[R8](X){if(X.interruptible&&this[G0][2]!==!0)X._stack.push(v3),X.interruptible=!1},[v1](X,Y,Q){Q??=G1(X);let J=this[G0][1](Q);return J?v(J,($)=>Q):Q},[FX](X,Y,Q){Q??=_X(X);let J=this[G0][1](Q);return J?v(J,($)=>Q):Q}}),f1=B(2,r5),jB=B(2,(X,Y)=>f1(X,(Q)=>Y)),qZ=B(3,(X,Y,Q)=>f1(X,(J)=>{if(!Y(J))return $0;return Q(J)})),OZ=B(3,(X,Y,Q)=>f1(X,(J)=>{let $=Y(J);return J0($)?$0:Q($.success,J)})),LZ=B(2,(X,Y)=>OZ(X,lV,Y)),IB=B(3,(X,Y,Q)=>qZ(X,(J)=>{if(J._tag!=="Failure")return!1;return Y(J.cause)},(J)=>Q(J.cause))),TZ=B(3,(X,Y,Q)=>f1(X,(J)=>{if(J._tag!=="Failure")return $0;let $=Y(J.cause);return J0($)?$0:Q($.success,J.cause)})),xB=B(2,(X,Y)=>TZ(VV,Y)(X)),vB=(X,Y,Q)=>wY((J)=>v(X,($)=>r5(J(Y($)),(G)=>Q($,G),!0))),SB=(X)=>x3(X,(Y)=>j(Y,Symbol.asyncDispose)?eG(()=>Y[Symbol.asyncDispose]()):Y0(()=>Y[Symbol.dispose]())),FZ=B(2,(X,Y)=>Y0(()=>{let Q=I8(GX(Y)),J=Number.isFinite(Q),$=lb(!1),G=0,Z=!1,K,H=v($.await,()=>K);return[t((W)=>{let D=W.getRef(T6),U=J?D.currentTimeMillisUnsafe():0;if(Z||U<G)return K??H;return Z=!0,$.closeUnsafe(),K=void 0,f1(X,(N)=>Y0(()=>{Z=!1,G=D.currentTimeMillisUnsafe()+Q,K=N,$.openUnsafe()}))}),Y0(()=>{G=0,$.closeUnsafe(),K=void 0})]})),RZ=B(2,(X,Y)=>z0(FZ(X,Y),(Q)=>Q[0])),kB=(X)=>RZ(X,r6),bB=t((X)=>A0(V3(X.id))),X8=(X)=>t((Y)=>{if(!Y.interruptible)return X;return Y.interruptible=!1,Y._stack.push(v3),X}),gB=RX({op:"SetInterruptible",[R8](X){if(X.interruptible=this[G0],X._interruptedCause&&X.interruptible)return()=>A0(X._interruptedCause)}}),v3=gB(!0),db=gB(!1),yB=(X)=>{if(X.interruptible=!0,X._stack.push(db),X._interruptedCause)return A0(X._interruptedCause)},AZ=(X)=>t((Y)=>{if(Y.interruptible)return X;return yB(Y)??X}),wY=(X)=>t((Y)=>{if(!Y.interruptible)return X(u);return Y.interruptible=!1,Y._stack.push(v3),X(AZ)}),hB=(X)=>t((Y)=>{if(Y.interruptible)return X(u);let Q=yB(Y),J=X(X8);return Q??J}),mB=z0(x3(Y0(()=>new AbortController),(X)=>Y0(()=>X.abort())),(X)=>X.signal),MY=(X,Y)=>{if(y6(X))return Y?.mode==="result"?KX(X,b8,Y):KX(X,u,Y);else if(Y?.discard)return Y.mode==="result"?KX(Object.values(X),b8,Y):KX(Object.values(X),u,Y);return e(()=>{let Q={};return y1(KX(Object.entries(X),([J,$])=>z0(Y?.mode==="result"?b8($):$,(G)=>{k(Q,J,G)}),{discard:!0,concurrency:Y?.concurrency}),Q)})},PZ=B((X)=>y6(X[0])&&!i(X[0]),(X,Y,Q)=>z0(KX(X,(J,$)=>b8(Y(J,$)),Q),(J)=>wG(J,u))),fB=B(3,(X,Y,Q)=>{let J=C1(X);if(J.length===0)return Y0(Y);return e(()=>{let $=0,G=Y();return z0(Y8({while:()=>$<J.length,body:()=>Q(G,J[$],$),step(Z){G=Z,$++}}),()=>G)})}),pB=B((X)=>y6(X[0])&&!i(X[0]),(X,Y,Q)=>v(PZ(X,Y,{concurrency:Q?.concurrency}),([J,$])=>{if(V6(J))return w0(J);return Q?.discard?$0:M($)})),dB=B((X)=>y6(X[0])&&!i(X[0]),(X,Y)=>e(()=>{let Q=X[Symbol.iterator](),J=Q.next();if(!J.done)return uB(Q,0,Y,J.value);return M(p())})),uB=(X,Y,Q,J)=>v(Q(J,Y),($)=>{if($)return M(T(J));let G=X.next();if(!G.done)return uB(X,Y+1,Q,G.value);return M(p())}),cB=B((X)=>y6(X[0])&&!i(X[0]),(X,Y)=>e(()=>{let Q=X[Symbol.iterator](),J=Q.next();if(!J.done)return lB(Q,0,Y,J.value);return M(p())})),lB=(X,Y,Q,J)=>v(Q(J,Y),($)=>{if(Y1($))return M(T($.success));let G=X.next();if(!G.done)return lB(X,Y+1,Q,G.value);return M(p())}),Y8=RX({op:"While",[v1](X,Y){if(this[G0].step(X),this[G0].while())return Y._stack.push(this),this[G0].body();return HX},[o0](X){if(this[G0].while())return X._stack.push(this),this[G0].body();return HX}}),KX=B((X)=>typeof X[1]==="function",(X,Y,Q)=>e(()=>{let J=Q?.concurrency??1,$=J==="unbounded"?Number.POSITIVE_INFINITY:Math.max(1,J);if($===1)return ub(X,Y,Q);let G=C1(X),Z=G.length;if(Z===0)return Q?.discard?$0:M([]);let K=Q?.discard?void 0:Array(Z),H=cb({f:Y,out:K},G,{concurrency:$});return H?y1(H,K):M(K)})),ub=(X,Y,Q)=>e(()=>{let J=Q?.discard?void 0:[],$=X[Symbol.iterator](),G=$.next(),Z=0;return y1(Y8({while:()=>!G.done,body:()=>Y(G.value,Z++),step:(K)=>{if(J)J.push(K);G=$.next()}}),J)}),oB=(X)=>{let{onItem:Y,step:Q}=X;return(J,$,G)=>{let Z=G?.start??0,K=G?.end??$.length,H=G?.concurrency??1,W=G?.orderedStep===!0&&H>1,D=!1,U,N,V,z=!1,q,F,R=Z,C=W?Array(K):void 0,w=(E)=>{let A=H6(E);return q=A,D=!0,z=!0,N&&N.size>0?v(X8(k4(Array.from(N))),()=>A):A},a=(E,A,x)=>{if(!W)return Q(J,E,A,x);if(q)return q;C[x]=A;while(R<K){let n=C[R];if(n===void 0)return;C[R]=void 0;let x0=R++,f0=Q(J,$[x0],n,x0);if(f0)return f0}},O=()=>{let E=!1;for(;!q&&Z<K;Z++){let A=$[Z],x=F??Y(J,A,Z);if(w1(x)){if(q=a(A,x,Z),q)break}else if(H===1)return v(PY(x),(n)=>{return q=a(A,n,Z),Z++,q??O()??$0});else if(!U)return n1((n)=>{U=z3(),N=new Set,F=x,V=n;let x0;try{x0=O()}catch(f0){return n(w(f0))}if(x0)return n(x0);return e(()=>{return q=HX,z=!0,N?k4(N):$0})});else{F=void 0;let n=g4(U,x,!0,!0,"inherit");if(n._exit){if(q=a(A,n._exit,Z),q)break;continue}N.add(n);let x0=Z;if(n.addObserver((f0)=>{N.delete(n);try{if(q){if(!z&&f0._tag==="Failure")for(let B0 of f0.cause.reasons)if(B0._tag==="Interrupt")continue;else if(q._tag==="Failure")q.cause.reasons.push(B0);else q=_X(d6([B0]))}else{let B0=a(A,f0,x0);if(B0)q=B0._tag==="Failure"?_X(d6(B0.cause.reasons.slice())):B0,O()}if(E){let B0=O();if(B0)V(B0)}else if(D&&N.size===0)V(q??$0)}catch(B0){V(w(B0))}}),N.size<H)continue;E=!0,Z++;return}}if(D=!0,q){if(N&&N.size>0){let A=q3(U);N.forEach((x)=>x.interruptUnsafe(U.id,A));return}if(V||q._tag==="Failure")return q}else if(V){if(!N)return HX;else if(N.size===0)V($0)}};return O()}},jY=()=>oB,cb=oB({onItem(X,Y,Q){return X.f(Y,Q)},step(X,Y,Q,J){if(Q._tag==="Failure")return Q;else if(X.out)X.out[J]=Q.value}}),EZ=B(3,(X,Y,Q)=>v(X,(J)=>Y(J)?M(J):Q(J))),CZ=B(3,(X,Y,Q)=>v(X,(J)=>{let $=Y(J);return J0($)?Q($.failure):M($.success)})),iB=B((X)=>i(X[0]),(X,Y,Q)=>CZ(X,Y,Q?(J)=>w0(Q(J)):()=>w0(new c6))),rB=B((X)=>y6(X[0])&&!i(X[0]),(X,Y,Q)=>e(()=>{let J=[];return y1(KX(X,($,G)=>{let Z=Y($,G);if(typeof Z==="boolean"){if(Z)J.push($);return $0}return z0(Z,(K)=>{if(K)J.push($)})},{discard:!0,concurrency:Q?.concurrency}),J)})),nB=B((X)=>y6(X[0])&&!i(X[0]),(X,Y)=>e(()=>{let Q=[];for(let J of X){let $=Y(J);if(Y1($))Q.push($.success)}return M(Q)})),sB=B((X)=>y6(X[0])&&!i(X[0]),(X,Y,Q)=>e(()=>{let J=[];return y1(KX(X,($)=>z0(Y($),(G)=>{if(Y1(G))J.push(G.success)}),{discard:!0,concurrency:Q?.concurrency}),J)})),aB=M({}),tB=u7(z0),eB=c7(z0,v),Xz=d7(z0);var Yz=B((X)=>i(X[0]),(X,Y)=>t((Q)=>{return Hg(),M(g4(Q,X,Y?.startImmediately,!1,Y?.uninterruptible??!1))})),g4=(X,Y,Q=!1,J=!1,$=!1)=>{let G=$==="inherit"?X.interruptible:!$,Z=new nG(X.context,G);if(Q)Z.evaluate(Y);else X.currentDispatcher.scheduleTask(()=>Z.evaluate(Y),0);if(!J&&!Z._exit)X.children().add(Z),Z.addObserver(()=>X._children.delete(Z));return Z},Qz=B((X)=>i(X[0]),(X,Y)=>t((Q)=>M(g4(Q,X,Y?.startImmediately,!0,Y?.uninterruptible)))),Jz=(X)=>t((Y)=>{let Q=Y._children&&new Set(Y._children);return f1(X,(J)=>{let $=Y._children;if($===void 0||$.size===0)return $0;else if(Q)$=fN($,(G)=>!Q.has(G));return FY(sG($))})}),wZ=B((X)=>i(X[0]),(X,Y,Q)=>t((J)=>{let $=g4(J,X,Q?.startImmediately,!0,Q?.uninterruptible);if(!$._exit)if(Y.state._tag!=="Closed"){let G={};N3(Y,G,()=>MV((K)=>K===$.id?$0:xb($))),$.addObserver(()=>wB(Y,G))}else $.interruptUnsafe(J.id,q3(J));return M($)})),$z=B((X)=>i(X[0]),(X,Y)=>v(CY,(Q)=>wZ(X,Q,Y))),Q8=(X)=>(Y,Q)=>{let J=new nG(Q?.scheduler?i1(X,VY,Q.scheduler):X,Q?.uninterruptible!==!0);if(J.evaluate(Y),J._exit)return J;if(Q?.signal)if(Q.signal.aborted)J.interruptUnsafe();else{let $=()=>J.interruptUnsafe();Q.signal.addEventListener("abort",$,{once:!0}),J.addObserver(()=>Q.signal.removeEventListener("abort",$))}if(Q?.onFiberStart)Q.onFiberStart(J);return J};var _z=Q8(k1()),MZ=(X)=>{let Y=Q8(X);return(Q,J)=>{let $=Y(Q,J);if(J?.onExit)$.addObserver(J.onExit);return(G)=>{return $.interruptUnsafe(G)}}},Gz=MZ(k1()),S3=(X)=>{let Y=Q8(X);return(Q,J)=>{let $=Y(Q,J);return new Promise((G)=>{$.addObserver((Z)=>G(Z))})}},Zz=S3(k1()),jZ=(X)=>{let Y=S3(X);return(Q,J)=>Y(Q,J).then(($)=>{if($._tag==="Failure")throw rG($.cause);return $.value})},Kz=jZ(k1()),k3=(X)=>{let Y=Q8(X);return(Q)=>{if(w1(Q))return Q;let J=new m5("sync"),$=Y(Q,{scheduler:J});return $._dispatcher?.flush(),$._exit??H6(new kZ($))}},Hz=k3(k1()),IZ=(X)=>{let Y=k3(X);return(Q)=>{let J=Y(Q);if(J._tag==="Failure")throw rG(J.cause);return J.value}},Wz=IZ(k1()),KV=M(!0),HV=M(!1);class Uz{waiters=[];scheduled=void 0;_isOpen;constructor(X){this._isOpen=X}scheduleUnsafe(X){if(this.waiters.length===0)return KV;if(this.scheduled===void 0)this.scheduled=this.waiters,X.currentDispatcher.scheduleTask(this.flushScheduled,0);else for(let Y=0;Y<this.waiters.length;Y++)this.scheduled.push(this.waiters[Y]);return this.waiters=[],KV}flushScheduled=()=>{if(this.scheduled===void 0)return;let X=this.scheduled;this.scheduled=void 0;for(let Y=0;Y<X.length;Y++)X[Y](HX)};flushWaiters(){let X=this.waiters;this.waiters=[],this.flushScheduled();for(let Y=0;Y<X.length;Y++)X[Y](HX)}open=t((X)=>{if(this._isOpen)return HV;return this._isOpen=!0,this.scheduleUnsafe(X)});release=t((X)=>this._isOpen?HV:this.scheduleUnsafe(X));openUnsafe(){if(this._isOpen)return!1;return this._isOpen=!0,this.flushWaiters(),!0}await=n1((X)=>{if(this._isOpen)return X($0);return this.waiters.push(X),Y0(()=>{let Y=this.waiters.indexOf(X);if(Y!==-1)this.waiters.splice(Y,1);else if(this.scheduled!==void 0){if(Y=this.scheduled.indexOf(X),Y!==-1)this.scheduled.splice(Y,1)}})});closeUnsafe(){if(!this._isOpen)return!1;return this._isOpen=!1,!0}close=Y0(()=>this.closeUnsafe());whenOpen=(X)=>v(this.await,()=>X);isOpen(){return this._isOpen}}var lb=(X)=>new Uz(X??!1);var Dz=t((X)=>M(X.getRef(W3))),Nz=B(2,(X,Y)=>h1(X,W3,Y)),Vz=h1(U3),Bz=h1(BY),fG=BigInt(0),ob={_tag:"Span",spanId:"noop",traceId:"noop",sampled:!1,status:{_tag:"Ended",startTime:fG,endTime:fG,exit:HX},attributes:new Map,links:[],kind:"internal",attribute(){},event(){},end(){},addLinks(){}},ib=(X)=>Object.assign(Object.create(ob),X),zz=(X)=>{if(!X)return p();return S1(X.annotations,H3)?X._tag==="Span"?zz(M4(X.parent)):p():T(X)},xZ=(X,Y,Q)=>{let J=!X.getRef(U3)||Q?.annotations&&S1(Q.annotations,H3),$=Q?.parent!==void 0?T(Q.parent):Q?.root?p():zz(X.currentSpan),G;if(J)G=ib({name:Y,parent:$,annotations:i1(Q?.annotations??k1(),H3,!0)});else{let Z=X.getRef(W3),K=X.getRef(T6),H=X.getRef(BY),W=X.getRef(zY),D=X.getRef(qY),U=Q?.level??X.getRef(aN),N=Q?.links!==void 0?[...D,...Q.links]:D.slice();G=Z.span({name:Y,parent:$,annotations:Q?.annotations??k1(),links:N,startTime:H?K.currentTimeNanosUnsafe():BigInt(0),kind:Q?.kind??"internal",root:Q?.root??P0($),sampled:Q?.sampled??(N1($)&&$.value.sampled===!1?!1:!jz(X.getRef(tN),U))});for(let[V,z]of Object.entries(W))G.attribute(V,z);if(Q?.attributes!==void 0)for(let[V,z]of Object.entries(Q.attributes))G.attribute(V,z)}return G},qz=(X,Y)=>t((Q)=>M(xZ(Q,X,Y))),hX=(X,Y)=>X8(t((Q)=>{let J=PX(Q.context,y8),$=xZ(Q,X,Y??{}),G=Q.getRef(T6),Z=Q.getRef(BY);return y1(e6(J,(K)=>nb($,K,G,Z)),$)})),Oz=function(){let X=typeof arguments[0]!=="string",Y=X?arguments[1]:arguments[0],Q=k8(X?arguments[2]:arguments[1]);if(X){let J=arguments[0];return v(hX(Y,Q),($)=>d5(J,$,Q))}return(J)=>v(hX(Y,Q),($)=>d5(J,$,Q))},rb=(X,Y)=>{return Y=typeof Y==="function"?Y:TX,a6(f5,(Q)=>({name:X,stack:Y,parent:Q}))},Lz=zY,Tz=qY,Fz=B((X)=>i(X[0]),(X,Y,Q={})=>{let $=(Array.isArray(Y)?Y:[Y]).map((G)=>({span:G,attributes:Q}));return a6(X,qY,(G)=>[...G,...$])}),nb=(X,Y,Q,J)=>Y0(()=>{if(X.status._tag==="Ended")return;X.end(J?Q.currentTimeNanosUnsafe():fG,Y)}),OY=(X,...Y)=>{let Q=Y.length===1?void 0:Y[0],J=Y[Y.length-1];return t(($)=>{let G=xZ($,X,Q),Z=$.getRef(T6);return f1(W0(()=>J(G)),(K)=>Y0(()=>{if(G.status._tag==="Ended")return;G.end(Z.currentTimeNanosUnsafe(),K)}))})},pG=h1(v4),d5=function(){let X=i(arguments[0]),Y=X?arguments[1]:arguments[0],Q=X?arguments[2]:arguments[1],J=u;if(Y._tag==="Span")Q=k8(Q),J=rb(Y.name,Q?.captureStackTrace);if(X)return pG(J(arguments[0]),Y);return($)=>pG(J($),Y)},Rz=function(){let X=typeof arguments[0]!=="string",Y=X?arguments[1]:arguments[0],Q=k8(arguments[2]);if(X){let G=arguments[0];return OY(Y,arguments[2],(Z)=>d5(G,Z,Q))}let J=typeof arguments[1]==="function"?arguments[1]:void 0,$=J?void 0:arguments[1];return(G,...Z)=>OY(Y,J?J(...Z):$,(K)=>d5(G,K,Q))},Az=B((X)=>i(X[0]),(X,...Y)=>a6(X,zY,(Q)=>{let J=Y.length===1?{...Q,...Y[0]}:{...Q};if(Y.length===1)return J;else k(J,Y[0],Y[1]);return J})),Pz=(...X)=>t((Y)=>{let Q=Y.currentSpanLocal;if(Q)if(X.length===1)for(let[J,$]of Object.entries(X[0]))Q.attribute(J,$);else Q.attribute(X[0],X[1]);return $0}),Ez=t((X)=>{let Y=X.currentSpanLocal;return Y?M(Y):w0(new c6)}),Cz=bb(v4),T6=L0("effect/Clock",{defaultValue:()=>new wz}),kG=2147483647;class wz{currentTimeMillisUnsafe(){return Date.now()}currentTimeMillis=Y0(()=>this.currentTimeMillisUnsafe());currentTimeNanosUnsafe(){return ab()}currentTimeNanos=Y0(()=>this.currentTimeNanosUnsafe());sleep(X){return this.sleepMillis(I8(X))}sleepMillis(X){if(X<=0)return c5;else if(!Number.isFinite(X))return TY;return n1((Y)=>{let Q=X>kG?this.sleepMillis(X-kG):$0,J=setTimeout(()=>Y(Q),Math.min(X,kG));return Y0(()=>clearTimeout(J))})}}var sb=function(){let X=BigInt(1e6);if(typeof performance>"u"||typeof performance.now>"u")return()=>BigInt(Date.now())*X;let Y;return()=>{return Y??=BigInt(Date.now())*X-BigInt(Math.round(performance.now()*1e6)),Y+BigInt(Math.round(performance.now()*1e6))}}(),ab=function(){let X=typeof process==="object"&&"hrtime"in process&&typeof process.hrtime.bigint==="function"?process.hrtime:void 0;if(!X)return sb;let Y=BigInt(Date.now())*BigInt(1e6)-X.bigint();return()=>Y+X.bigint()}(),y4=(X)=>t((Y)=>X(Y.getRef(T6))),h4=(X)=>y4((Y)=>Y.sleep(GX(X))),Mz=y4((X)=>X.currentTimeMillis);var dG="~effect/Cause/TimeoutError";class vZ extends A8("TimeoutError"){[dG]=dG;constructor(X){super({message:X})}}var uG="~effect/Cause/IllegalArgumentError";class SZ extends A8("IllegalArgumentError"){[uG]=uG;constructor(X){super({message:X})}}var cG="~effect/Cause/AsyncFiberError";class kZ extends A8("AsyncFiberError"){[cG]=cG;constructor(X){super({message:"An asynchronous Effect was executed with Effect.runSync",fiber:X})}}var lG="~effect/Cause/UnknownError";class b3 extends A8("UnknownError"){[lG]=lG;constructor(X,Y){super({message:Y,cause:X})}}var tb=L0("effect/Console/CurrentConsole",{defaultValue:()=>globalThis.console}),eb=(X)=>{switch(X){case"All":return Number.MIN_SAFE_INTEGER;case"Fatal":return 50000;case"Error":return 40000;case"Warn":return 30000;case"Info":return 20000;case"Debug":return 1e4;case"Trace":return 0;case"None":return Number.MAX_SAFE_INTEGER}},Xg=HG(O1,eb),jz=w8(Xg),bZ=L0("effect/Loggers/CurrentLoggers",{defaultValue:()=>new Set([Zg,Kg])}),Yg=L0("effect/Logger/LogToStderr",{defaultValue:A7}),Iz=function(){let X=typeof arguments[0]==="string"?[[arguments[0],arguments[1]]]:Object.entries(arguments[0]);return X8(t((Y)=>{let Q=Y.getRef(n6),J={...Q};for(let $=0;$<X.length;$++){let[G,Z]=X[$];k(J,G,Z)}return Y.setContext(i1(Y.context,n6,J)),e6(PX(Y.context,y8),($)=>{let G=Y.getRef(n6),Z={...G};for(let K=0;K<X.length;K++){let[H,W]=X[K];if(G[H]!==W)continue;if(Object.hasOwn(Q,H))k(Z,H,Q[H]);else delete Z[H]}return Y.setContext(i1(Y.context,n6,Z)),$0})}))},Qg="~effect/Logger",Jg={[Qg]:{_Message:u,_Output:u},pipe(){return _0(this,arguments)}},xz=(X)=>{let Y=Object.create(Jg);return Y.log=X,Y},$g=(X)=>X.replace(/[\s="]/g,"_"),_g=(X,Y)=>{return`${$g(X[0])}=${Y-X[1]}ms`};var fX=(X)=>(...Y)=>{let Q=void 0;for(let J=0,$=Y.length;J<$;J++){let G=Y[J];if(j5(G)){if(Q)Y.splice(J,1);else Y=Y.slice(0,J).concat(Y.slice(J+1));Q=Q?d6(Q.reasons.concat(G.reasons)):G,J--}}if(Q===void 0)Q=y7;return t((J)=>{let $=X??J.currentLogLevel;if(jz(J.minimumLogLevel,$))return $0;let G=J.getRef(T6),Z=J.getRef(bZ);if(Z.size>0){let K=new Date(G.currentTimeMillisUnsafe());for(let H of Z)H.log({cause:Q,fiber:J,date:K,logLevel:$,message:Y})}return $0})};var S4={bold:"1",red:"31",green:"32",yellow:"33",blue:"34",cyan:"36",white:"37",gray:"90",black:"30",bgBrightRed:"101"},z30={None:[],All:[],Trace:[S4.gray],Debug:[S4.blue],Info:[S4.green],Warn:[S4.yellow],Error:[S4.red],Fatal:[S4.bgBrightRed,S4.black]};var Gg=(X)=>`${X.getHours().toString().padStart(2,"0")}:${X.getMinutes().toString().padStart(2,"0")}:${X.getSeconds().toString().padStart(2,"0")}.${X.getMilliseconds().toString().padStart(3,"0")}`;var Zg=xz(({cause:X,date:Y,fiber:Q,logLevel:J,message:$})=>{let G=Array.isArray($)?$.slice():[$];if(X.reasons.length>0)G.push(B3(X));let Z=Y.getTime(),K=Q.getRef(D3),H="";for(let N of K)H+=` ${_g(N,Z)}`;let W=Q.getRef(n6);if(Object.keys(W).length>0)G.push(W);let D=Q.getRef(tb);(Q.getRef(Yg)?D.error:D.log)(`[${Gg(Y)}] ${J.toUpperCase()} (#${Q.id})${H}:`,...G)}),Kg=xz(({cause:X,fiber:Y,logLevel:Q,message:J})=>{let $=Y.getRef(T6),G=Y.getRef(n6),Z=Y.currentSpan;if(Z===void 0||Z._tag==="ExternalSpan")return;let K={};for(let[H,W]of Object.entries(G))k(K,H,W);if(K["effect.fiberId"]=Y.id,K["effect.logLevel"]=Q.toUpperCase(),X.reasons.length>0)K["effect.cause"]=B3(X);Z.event(QN(Array.isArray(J)&&J.length===1?J[0]:J),$.currentTimeNanosUnsafe(),K)});function Hg(){yG.interruptChildren??=jb}var gZ=M(void 0);var vz=B((X)=>i(X[0]),(X,Y)=>LZ(X,(Q)=>t((J)=>{return Wg(J,Q,Y?.defectsOnly),$0}))),Wg=(X,Y,Q)=>{let J=X.getRef(QV);if(J.size===0)return;if(Q&&!DV(Y))return;let $={cause:Y,fiber:X,timestamp:X.getRef(T6).currentTimeNanosUnsafe()};J.forEach((G)=>G.report($))};var Sz=QG,n5=G1,h8=_X,IY=K6;var kz=HX;var M1=_Z,bz=cV;var t5={};k6(t5,{withSpan:()=>ug,withParentSpan:()=>fZ,updateService:()=>Xq,unwrap:()=>mZ,tapError:()=>jg,tapCause:()=>Ig,tap:()=>Mg,syncContext:()=>hZ,sync:()=>Ag,suspend:()=>Eg,succeedContext:()=>f4,succeed:()=>sz,span:()=>dg,satisfiesSuccessType:()=>mg,satisfiesServicesType:()=>pg,satisfiesErrorType:()=>fg,provideMerge:()=>wg,provide:()=>s5,parentSpan:()=>Yq,orDie:()=>xg,mock:()=>yg,mergeAll:()=>d3,merge:()=>Cg,makeMemoMapUnsafe:()=>a5,makeMemoMap:()=>Tg,launch:()=>gg,isLayer:()=>m3,fromBuildMemo:()=>f3,fromBuild:()=>m8,fresh:()=>bg,forkMemoMapUnsafe:()=>dZ,forkMemoMap:()=>Fg,flatMap:()=>ez,empty:()=>Rg,effectDiscard:()=>Pg,effectContext:()=>cZ,effect:()=>p3,catchTag:()=>Sg,catchCause:()=>kg,catch:()=>vg,buildWithScope:()=>uZ,buildWithMemoMap:()=>vY,build:()=>nz,CurrentMemoMap:()=>m4});var Ug="~effect/Deferred";var Dg={[Ug]:{_A:u,_E:u},pipe(){return _0(this,arguments)}},gz=()=>{let X=Object.create(Dg);return X.resumes=void 0,X.effect=void 0,X};var yz=(X)=>n1((Y)=>{if(X.effect)return Y(X.effect);return X.resumes??=[],X.resumes.push(Y),Y0(()=>{let Q=X.resumes.indexOf(Y);X.resumes.splice(Q,1)})});var Ng=B(2,(X,Y)=>Y0(()=>Vg(X,Y))),hz=Ng;var Vg=(X,Y)=>{if(X.effect)return!1;if(X.effect=Y,X.resumes){for(let Q=0;Q<X.resumes.length;Q++)X.resumes[Q](Y);X.resumes=void 0}return!0};var mz=n6;var fz=D3,pz=f5;var dz=y8;var uz=EY,xY=MB;var y3=CB,yZ=zZ;var rz="~effect/Layer",cz="~effect/Layer/MemoMap",qg=(X,Y)=>{return X.observers++,mX(e6(Y,(Q)=>X.finalizer(Q)),X.effect)},m3=(X)=>j(X,rz),Og={[rz]:{_ROut:u,_E:u,_RIn:u},pipe(){return _0(this,arguments)}},p4=(X)=>{let Y=Object.create(Og);return Y.build=X,Y},m8=(X)=>p4((Y,Q)=>{let J=y3(Q);return f1(X(Y,J),($)=>$._tag==="Failure"?yZ(J,$):$0)}),f3=(X)=>{let Y=m8((Q,J)=>Q.getOrElseMemoize(Y,J,X));return Y},Lg=(X,Y,Q,J)=>{let $=uz(),G=gz(),Z={observers:1,effect:yz(G),finalizer:(K)=>e(()=>{if(Z.observers--,Z.observers===0)return X.map.delete(Y),yZ($,K);return $0})};return X.map.set(Y,Z),e6(Q,Z.finalizer).pipe(v(()=>J(X,$)),f1((K)=>{return Z.effect=K,hz(G,K)}))};class pZ{get[cz](){return cz}parent;constructor(X){this.parent=X}map=new Map;get(X,Y){let Q=this.map.get(X);if(Q)return qg(Q,Y);return this.parent?.get(X,Y)}getOrElseMemoize(X,Y,Q){let J=this.get(X,Y);if(J)return J;return Lg(this,X,Y,Q)}}var a5=()=>new pZ,dZ=(X)=>new pZ(X),Tg=Y0(a5),Fg=(X)=>Y0(()=>dZ(X));class m4 extends yX()("effect/Layer/CurrentMemoMap"){static forkOrCreate(X){let Y=NG(X,m4);return Y?dZ(Y):a5()}}var vY=B(3,(X,Y,Q)=>h1(z0(X.build(Y,Q),i1(m4,Y)),m4,Y)),nz=(X)=>t((Y)=>vY(X,m4.forkOrCreate(Y.context),PX(Y.context,dz))),uZ=B(2,(X,Y)=>t((Q)=>vY(X,m4.forkOrCreate(Q.context),Y))),sz=function(){if(arguments.length===1)return(X)=>f4(U6(arguments[0],X));return f4(U6(arguments[0],arguments[1]))},f4=(X)=>p4(W1(M(X))),Rg=f4(k1()),Ag=function(){if(arguments.length===1)return(X)=>hZ(()=>U6(arguments[0],X()));return hZ(()=>U6(arguments[0],arguments[1]()))},hZ=(X)=>f3(W1(Y0(X))),p3=function(){if(arguments.length===1)return(X)=>lz(arguments[0],X);return lz(arguments[0],arguments[1])},lz=(X,Y)=>cZ(z0(Y,(Q)=>U6(X,Q))),cZ=(X)=>f3((Y,Q)=>xY(X,Q)),Pg=(X)=>cZ(y1(X,k1())),Eg=(X)=>f3((Y,Q)=>e(()=>X().build(Y,Q))),mZ=(X)=>{let Y=yX("effect/Layer/unwrap");return ez(p3(Y)(X),S1(Y))},az=(X,Y,Q)=>{let J=y3(Q,"parallel");return KX(X,($)=>$.build(Y,y3(J,"sequential")),{concurrency:X.length}).pipe(z0(($)=>zG(...$)))},d3=(...X)=>m8((Y,Q)=>az(X,Y,Q)),Cg=B(2,(X,Y)=>d3(X,...Array.isArray(Y)?Y:[Y])),tz=(X,Y,Q)=>m8((J,$)=>v(Array.isArray(Y)?az(Y,J,$):Y.build(J,$),(G)=>X.build(J,$).pipe(t6(G),z0((Z)=>Q(Z,G))))),s5=B(2,(X,Y)=>tz(X,Y,u)),wg=B(2,(X,Y)=>tz(X,Y,(Q,J)=>b5(J,Q))),ez=B(2,(X,Y)=>m8((Q,J)=>v(X.build(Q,J),($)=>Y($).build(Q,J)))),Mg=B(2,(X,Y)=>m8((Q,J)=>v(X.build(Q,J),($)=>xY(y1(Y($),$),J)))),jg=B(2,(X,Y)=>m8((Q,J)=>m1(X.build(Q,J),($)=>xY(mX(Y($),w0($)),J)))),Ig=B(2,(X,Y)=>m8((Q,J)=>s1(X.build(Q,J),($)=>xY(mX(Y($),A0($)),J)))),xg=(X)=>p4((Y,Q)=>C3(X.build(Y,Q))),vg=B(2,(X,Y)=>p4((Q,J)=>m1(X.build(Q,J),($)=>Y($).build(Q,J))));var Sg=B(3,(X,Y,Q)=>p4((J,$)=>E3(X.build(J,$),Y,(G)=>Q(G).build(J,$)))),kg=B(2,(X,Y)=>p4((Q,J)=>s1(X.build(Q,J),($)=>Y($).build(Q,J)))),Xq=B(3,(X,Y,Q)=>s5(X,p3(Y,z0(Y,Q)))),bg=(X)=>p4((Y,Q)=>X.build(a5(),Q)),gg=(X)=>j3(mX(nz(X),TY)),yg=function(){if(arguments.length===1)return(X)=>oz(arguments[0],X);return oz(arguments[0],arguments[1])},oz=(X,Y)=>sz(X)(new Proxy({...Y},{get(Q,J,$){if(J in Q)return Q[J];let G=W6();P1(2);let Z=Error(`${X.key}: Unimplemented method "${J.toString()}"`);return P1(G),Z.name="UnimplementedError",hg(Z)},has:b6})),hg=(X)=>{let Y=Object.assign(s6(X),{[iz]:iz,channel:{[h3]:h3,transform:()=>M(Y),pipe(){return _0(this,arguments)}},[h3]:h3,transform:()=>M(Y)});function Q(){return Y}return Object.assign(Q,Y),Object.setPrototypeOf(Q,Object.getPrototypeOf(Y)),Q},iz="~effect/Stream",h3="~effect/Channel",mg=()=>(X)=>X,fg=()=>(X)=>X,pg=()=>(X)=>X,dg=(X,Y)=>{return Y=k8(Y),p3(v4,Y?.onEnd?L6(hX(X,Y),(Q)=>i5((J)=>Y.onEnd(Q,J))):hX(X,Y))},Yq=(X)=>f4(v4.context(X)),ug=function(){let X=typeof arguments[0]!=="string",Y=X?arguments[1]:arguments[0],Q=k8(X?arguments[2]:arguments[1]);if(X){let J=arguments[0];return mZ(z0(Q?.onEnd!==void 0?L6(hX(Y,Q),($)=>i5((G)=>Q.onEnd($,G))):hX(Y,Q),($)=>fZ(J,$)))}return(J)=>mZ(z0(Q?.onEnd!==void 0?L6(hX(Y,Q),($)=>i5((G)=>Q.onEnd($,G))):hX(Y,Q),($)=>fZ(J,$)))},fZ=function(){let X=m3(arguments[0]),Y=X?arguments[1]:arguments[0],Q=X?arguments[2]:arguments[1],J=u;if(Y._tag==="Span")Q=k8(Q),J=cg(Y.name,Q?.captureStackTrace);let $=Yq(Y);if(X)return s5(J(arguments[0]),$);return(G)=>s5(J(G),$)},cg=(X,Y)=>{return Y=typeof Y==="function"?Y:TX,Xq(pz,(Q)=>({name:X,stack:Y,parent:Q}))};var Qq="~effect/ExecutionPlan";var lg={[Qq]:Qq,get captureRequirements(){let X=this;return g8((Y)=>M(og(X.steps.map((Q)=>({...Q,provide:m3(Q.provide)?s5(Q.provide,f4(Y)):Q.provide})))))},pipe(){return _0(this,arguments)}},og=(X)=>{let Y=Object.create(lg);return Y.steps=X,Y};var Jq=L0("effect/ExecutionPlan/CurrentMetadata",{defaultValue:W1({attempt:0,stepIndex:0})});var $q=j5,_q=GN,u3=P4;var c3=d6,Gq=y7;var l3=(X)=>new I5(X),o3=(X)=>new h7(X),i3=WV;var J8=zV;var lZ=O6;var Zq=B3;var oZ=KY;var iZ=DN;var r3=SZ;var n3="~effect/time/DateTime",s3="~effect/time/DateTime/TimeZone",Hq={[n3]:n3,pipe(){return _0(this,arguments)},[U1](){return this.toString()},toJSON(){return gY(this).toJSON()}},tg={...Hq,_tag:"Utc",[D0](){return h6(this.epochMilliseconds)},[N0](X){return X9(X)&&X._tag==="Utc"&&this.epochMilliseconds===X.epochMilliseconds},toString(){return`DateTime.Utc(${gY(this).toJSON()})`}},eg={...Hq,_tag:"Zoned",[D0](){return _1(h6(this.epochMilliseconds))(X0(this.zone))},[N0](X){return X9(X)&&X._tag==="Zoned"&&this.epochMilliseconds===X.epochMilliseconds&&o(this.zone,X.zone)},toString(){return`DateTime.Zoned(${Z2(this)})`}},Wq={[s3]:s3,[U1](){return this.toString()}},Xy={...Wq,_tag:"Named",[D0](){return g0(`Named:${this.id}`)},[N0](X){return u4(X)&&X._tag==="Named"&&this.id===X.id},toString(){return`TimeZone.Named(${this.id})`},toJSON(){return{_id:"TimeZone",_tag:"Named",id:this.id}}},Yy={...Wq,_tag:"Offset",[D0](){return g0(`Offset:${this.offset}`)},[N0](X){return u4(X)&&X._tag==="Offset"&&this.offset===X.offset},toString(){return`TimeZone.Offset(${$2(this.offset)})`},toJSON(){return{_id:"TimeZone",_tag:"Offset",offset:this.offset}}},F6=(X,Y,Q)=>{let J=Object.create(eg);return J.epochMilliseconds=X,J.zone=Y,Object.defineProperty(J,"partsUtc",{value:Q,enumerable:!1,writable:!0}),Object.defineProperty(J,"adjustedEpochMillis",{value:void 0,enumerable:!1,writable:!0}),Object.defineProperty(J,"partsAdjusted",{value:void 0,enumerable:!1,writable:!0}),J},X9=(X)=>j(X,n3);var u4=(X)=>j(X,s3),Uq=(X)=>u4(X)&&X._tag==="Offset",Dq=(X)=>u4(X)&&X._tag==="Named",Nq=(X)=>X._tag==="Utc",sZ=(X)=>X._tag==="Zoned",Vq=D1((X,Y)=>X.epochMilliseconds===Y.epochMilliseconds),Bq=C4((X,Y)=>X.epochMilliseconds<Y.epochMilliseconds?-1:X.epochMilliseconds>Y.epochMilliseconds?1:0);var aZ=(X)=>{let Y=Object.create(tg);return Y.epochMilliseconds=X,Object.defineProperty(Y,"partsUtc",{value:void 0,enumerable:!1,writable:!0}),Y},e5=(X)=>{let Y=X.getTime();if(Number.isNaN(Y))throw new r3("Invalid date");return aZ(Y)},tZ=(X)=>{if(X9(X))return X;else if(X instanceof Date)return e5(X);else if(typeof X==="object"){if("epochMilliseconds"in X)return aZ(X.epochMilliseconds);let Y=new Date(0);return Hy(Y,X),e5(Y)}else if(typeof X==="string"&&!Qy(X))return e5(new Date(X+"Z"));return e5(new Date(X))},Qy=(X)=>/Z|GMT|[+-]\d{2}$|[+-]\d{2}:?\d{2}$|\]$/.test(X),Jy=-8639999956800000,$y=8639999949600000,eZ=(X,Y)=>{let Q=Y?.timeZone;if(Q===void 0&&X9(X)&&sZ(X))return X;let J=tZ(X);if(J.epochMilliseconds<Jy||J.epochMilliseconds>$y)throw RangeError(`Epoch millis out of range: ${J.epochMilliseconds}`);if(Q===void 0&&typeof X==="object"&&"timeZoneId"in X)Q=X.timeZoneId;let $;if(Q===void 0){let G=new Date(J.epochMilliseconds).getTimezoneOffset()*-60*1000;$=bY(G)}else if(u4(Q))$=Q;else if(typeof Q==="number")$=bY(Q);else{let G=Q2(Q);if(P0(G))throw new r3(`Invalid time zone: ${Q}`);$=G.value}if(Y?.adjustForTimeZone!==!0)return F6(J.epochMilliseconds,$,J.partsUtc);return Wy(J.epochMilliseconds,$,Y?.disambiguation??"compatible")},rZ=j4(eZ),zq=j4(tZ),_y=/^(.{17,35})\[(.+)\]$/,qq=(X)=>{let Y=_y.exec(X);if(Y===null){let $=G2(X);return $!==null?rZ(X,{timeZone:$}):p()}let[,Q,J]=Y;return rZ(Q,{timeZone:J})};var Oq=(X)=>aZ(X.epochMilliseconds);var kY=new Map,Gy={day:"numeric",month:"numeric",year:"numeric",hour:"numeric",minute:"numeric",second:"numeric",timeZoneName:"longOffset",fractionalSecondDigits:3,hourCycle:"h23"},Zy=(X)=>{let Y=X.resolvedOptions().timeZone;if(kY.has(Y))return kY.get(Y);let Q=Object.create(Xy);return Q.id=Y,Q.format=X,kY.set(Y,Q),Q},X2=(X)=>{if(kY.has(X))return kY.get(X);try{return Zy(new Intl.DateTimeFormat("en-US",{...Gy,timeZone:X}))}catch{throw new r3(`Invalid time zone: ${X}`)}},bY=(X)=>{let Y=Object.create(Yy);return Y.offset=X,Y},Y2=j4(X2);var Ky=/^(?:GMT|[+-])/,Q2=(X)=>{if(Ky.test(X)){let Y=G2(X);return Y===null?p():T(bY(Y))}return Y2(X)},Lq=(X)=>{if(X._tag==="Offset")return $2(X.offset);return X.id};var gY=(X)=>new Date(X.epochMilliseconds),a3=(X)=>{if(X._tag==="Utc")return new Date(X.epochMilliseconds);else if(X.zone._tag==="Offset")return new Date(X.epochMilliseconds+X.zone.offset);else if(X.adjustedEpochMilliseconds!==void 0)return new Date(X.adjustedEpochMilliseconds);let Y=X.zone.format.formatToParts(X.epochMilliseconds).filter((J)=>J.type!=="literal"),Q=new Date(0);return Q.setUTCFullYear(Number(Y[2].value),Number(Y[0].value)-1,Number(Y[1].value)),Q.setUTCHours(Number(Y[3].value),Number(Y[4].value),Number(Y[5].value),Number(Y[6].value)),X.adjustedEpochMilliseconds=Q.getTime(),Q},J2=(X)=>{return a3(X).getTime()-_2(X)},$2=(X)=>{let Y=Math.abs(X),Q=Math.floor(Y/3600000),J=Math.round(Y%3600000/60000);if(J===60)Q+=1,J=0;return`${X<0?"-":"+"}${String(Q).padStart(2,"0")}:${String(J).padStart(2,"0")}`},Tq=(X)=>$2(J2(X)),_2=(X)=>X.epochMilliseconds;var Hy=(X,Y)=>{if(Y.year!==void 0)X.setUTCFullYear(Y.year);if(Y.month!==void 0)X.setUTCMonth(Y.month-1);if(Y.day!==void 0)X.setUTCDate(Y.day);if(Y.weekDay!==void 0){let Q=Y.weekDay-X.getUTCDay();X.setUTCDate(X.getUTCDate()+Q)}if(Y.hour!==void 0)X.setUTCHours(Y.hour);if(Y.minute!==void 0)X.setUTCMinutes(Y.minute);if(Y.second!==void 0)X.setUTCSeconds(Y.second);if(Y.millisecond!==void 0)X.setUTCMilliseconds(Y.millisecond)};var Kq=86400000,Wy=(X,Y,Q)=>{if(Y._tag==="Offset")return F6(X-Y.offset,Y);let J=SY(X-Kq,X,Y),$=SY(X+Kq,X,Y);if(J===$)return F6(X-J,Y);let G=J<$,Z=J-$;if(G){if(SY(X-$,X,Y)===$)return F6(X-$,Y);let W=F6(X-J,Y),D=a3(W).getTime();if(X!==D)switch(Q){case"reject":{let U=new Date(X).toISOString();throw RangeError(`Gap time: ${U} does not exist in time zone ${Y.id}`)}case"earlier":return F6(X-$,Y);case"compatible":case"later":return W}return W}if(SY(X-J,X,Y)===J){if(Q==="earlier"||Q==="compatible")return F6(X-J,Y);if(SY(X-J+Z,X+Z,Y)===J)return F6(X-J,Y);if(Q==="reject"){let W=new Date(X).toISOString();throw RangeError(`Ambiguous time: ${W} occurs twice in time zone ${Y.id}`)}}return F6(X-$,Y)},Uy=/([+-])(\d{2}):(\d{2})$/,G2=(X)=>{let Y=Uy.exec(X);if(Y===null)return null;let[,Q,J,$]=Y;return(Q==="+"?1:-1)*(Number(J)*60+Number($))*60*1000},SY=(X,Y,Q)=>{let J=Q.format.formatToParts(X).find((G)=>G.type==="timeZoneName")?.value??"";if(J==="GMT")return 0;let $=G2(J);if($===null)return J2(F6(Y,Q));return $};var Fq=(X)=>gY(X).toISOString();var nZ=(X)=>{let Y=a3(X);return X._tag==="Utc"?Y.toISOString():`${Y.toISOString().slice(0,-1)}${Tq(X)}`},Z2=(X)=>X.zone._tag==="Offset"?nZ(X):`${nZ(X)}[${X.zone.id}]`;var WJ0=globalThis.Number;var Aq=B(2,(X,Y)=>{let Q=X.toString(),J=Y.toString();if(Q.includes("e")||J.includes("e")){if(!globalThis.Number.isFinite(X)||!globalThis.Number.isFinite(Y)||Y===0)return NaN;return Ny(X,Y)}let $=(Q.split(".")[1]||"").length,G=(J.split(".")[1]||"").length,Z=$>G?$:G,K=parseInt(X.toFixed(Z).replace(".","")),H=parseInt(Y.toFixed(Z).replace(".",""));return K%H/Math.pow(10,Z)});function Ny(X,Y){let[Q,J]=Rq(X),[$,G]=Rq(Y),Z=Math.min(J,G),K=Q*BigInt(10)**BigInt(J-Z),H=$*BigInt(10)**BigInt(G-Z),W=K%H;if(W===BigInt(0))return X<0||Object.is(X,-0)?-0:0;let D=globalThis.Number(`${W}e${Z}`);return D===0?Math.sign(X)*globalThis.Number.MIN_VALUE:D}function Rq(X){let Y=Math.abs(X).toExponential(),Q=Y.indexOf("e"),J=Y.slice(0,Q).replace(".","");return[BigInt(J)*(X<0?-BigInt(1):BigInt(1)),globalThis.Number(Y.slice(Q+1))-J.length+1]}var Pq=l6((X,Y)=>Math.max(X,Y),-1/0),Eq=l6((X,Y)=>Math.min(X,Y),1/0);var UJ0=globalThis.String;var Cq=(X)=>X.trim();var K2=B(2,(X,Y)=>o5(X,qy,(Q)=>Y(Q)));var zy=MG(lZ,(X)=>oZ(X)?m(X):c(X));var qy=MG(lZ,(X)=>oZ(X)?m(X.value):c(X));var wq=B(2,(X,Y)=>q6(X,{onSuccess:Y.onSuccess,onFailure:(Q)=>{let J=zy(Q);return!J0(J)?Y.onDone(J.success.value):Y.onFailure(J.failure)}}));var jq="~effect/Schedule";var c4=L0("effect/Schedule/CurrentMetadata",{defaultValue:W1({input:void 0,output:void 0,duration:g5,attempt:0,start:0,now:0,elapsed:0,elapsedSincePrevious:0})}),Oy={[jq]:{_Out:u,_In:u,_Env:u},pipe(){return _0(this,arguments)}},H2=(X)=>j(X,jq),W2=(X)=>{let Y=Object.create(Oy);return Y.step=X,Y},U2=()=>{let X=0,Y,Q;return(J,$)=>{if(Q===void 0)Q=J;let G=J-Q,Z=Y===void 0?0:J-Y;return Y=J,{input:$,attempt:++X,start:Q,now:J,elapsed:G,elapsedSincePrevious:Z}}},Ly=(X)=>W2(z0(X,(Y)=>{let Q=U2();return(J,$)=>Y(Q(J,$))})),D2=(X)=>s1(X.step,(Y)=>M(()=>A0(Y))),t3=(X)=>y4((Y)=>z0(D2(X),(Q)=>{let J=U2();return($)=>e(()=>{let G=Y.currentTimeMillisUnsafe();return v(Q(G,$),([Z,K])=>{let H=J(G,$);return H.output=Z,H.duration=K,y1(h4(K),H)})})}));var N2=(X)=>W2(z0(D2(X),(Y)=>(Q,J)=>wq(Y(Q,J),{onSuccess:($)=>M([J,$[1]]),onFailure:A0,onDone:()=>iZ(J)}))),Iq=(X)=>yY(V2,({attempt:Y})=>M(Y<=X)),Ty=(X)=>{let Y=GX(X);return Ly(M((Q)=>M([Q.attempt-1,Y])))};var yY=B(2,(X,Y)=>W2(z0(D2(X),(Q)=>{let J=U2();return($,G)=>v(Q($,G),(Z)=>{let[K,H]=Z,W=Y({...J($,G),output:K,duration:H});return v(i(W)?W:M(W),(D)=>D?M(Z):iZ(K))})})));var V2=Ty(g5);var Fy=(X,Y,Q)=>I3((J)=>v(Q?.local?vY(Y,a5(),J):uZ(Y,J),($)=>t6(X,$))),e3=B((X)=>i(X[0]),(X,Y,Q)=>e7(Y)?t6(X,Y):Fy(X,Array.isArray(Y)?d3(...Y):Y,Q));var B2=B(3,(X,Y,Q)=>v(t3(Y),(J)=>{let $=c4.defaultValue();return m1(R3(L6(v(e(()=>h1(X,c4,$)),J),(G)=>Y0(()=>{$=G})),{disableYield:!0}),(G)=>KY(G)?M(G.value):Q(G,$.attempt===0?p():T($)))})),z2=B(3,(X,Y,Q)=>v(t3(Y),(J)=>{let $=c4.defaultValue(),G,Z=m1(e(()=>h1(X,c4,$)),(K)=>{return G=K,v(J(K),(H)=>{return $=H,Z})});return K2(Z,(K)=>W0(()=>Q(G,K)))})),Sq=B(2,(X,Y)=>{let Q=typeof Y==="function"?Y(u):H2(Y)?Y:mY(Y);return B2(X,Q,w0)}),hY=B(2,(X,Y)=>{let Q=typeof Y==="function"?Y(u):H2(Y)?Y:mY(Y);return z2(X,Q,w0)}),kq=B(3,(X,Y,Q)=>v(t3(Q),(J)=>{let $=c4.defaultValue(),G=e(()=>h1(X,c4,$));return m1(v(J(Y),(Z)=>{$=Z;let K=W1(v(G,J));return Y8({while:b6,body:K,step(H){$=H}})}),(Z)=>KY(Z)?M(Z.value):w0(Z))})),Ry=N2(V2),mY=(X)=>{let Y=X.schedule?N2(X.schedule):Ry;if(X.while)Y=yY(Y,({input:Q})=>{let J=X.while(Q);return i(J)?J:M(J)});if(X.until)Y=yY(Y,({input:Q})=>{let J=X.until(Q);return i(J)?z0(J,($)=>!$):M(!J)});if(X.times!==void 0)Y=yY(Y,({attempt:Q})=>M(Q<=X.times));return Y};var yq=B(2,(X,Y)=>e(()=>{let Q=0,J={attempt:0,stepIndex:0},$=F3(Jq,Y0(()=>{return J={attempt:J.attempt+1,stepIndex:Q},J})),G;return v(Y8({while:()=>Q<Y.steps.length&&(G===void 0||J0(G)),body(){let Z=Y.steps[Q],K=$(e3(X,Z.provide));if(G){let H=!1,W=K;K=e(()=>{if(H)return W;return H=!0,u5(G)}),K=hY(K,gq(Z,!1))}else{let H=gq(Z,!0);K=H?hY(K,H):K}return b8(K)},step(Z){G=Z,Q++}}),()=>u5(G))})),gq=(X,Y)=>{if(!Y)return mY({schedule:X.schedule?X.schedule:X.attempts?void 0:Ay,times:X.attempts,while:X.while});else if(X.attempts===1||!(X.schedule||X.attempts))return;return mY({schedule:X.schedule,while:X.while,times:X.attempts?X.attempts-1:void 0})},Ay=Iq(1);var Ey="~effect/Request",Cy=XN({_E:(X)=>X,_A:(X)=>X,_R:(X)=>X}),wJ0={..._N,[Ey]:Cy};var hq=(X)=>X;var fq=B(2,(X,Y)=>{let Q=(J)=>n1(($)=>{let G=dq(J,X,$,z3());return wy(J,G)});return i(Y)?v(Y,Q):Q(Y)}),pq=(X,Y)=>{let Q=dq(Y.resolver,X,Y.onExit,{context:Y.context,currentScheduler:S1(Y.context,VY)});return()=>uq(Y.resolver,Q)},XJ=[],q2=new WeakMap,dq=(X,Y,Q,J)=>{let $=q2.get(X);if(!$)$=new Map,q2.set(X,$);let G,Z=!1,K=hq({request:Y,context:J.context,uninterruptible:!1,completeUnsafe(W){if(Z)return;Z=!0,Q(W),G?.entrySet.delete(K)}});if(X.preCheck!==void 0&&!X.preCheck(K))return K;let H=X.batchKey(K);if(G=$.get(H),!G){if(XJ.length>0)G=XJ.pop(),G.key=H,G.resolver=X,G.map=$;else{let W={key:H,resolver:X,map:$,entrySet:new Set,entries:new Set,delayEffect:v(e(()=>W.resolver.delay),(D)=>mq(W)),run:f1(e(()=>W.resolver.runAll(Array.from(W.entries),W.key)),(D)=>{for(let U of W.entrySet)U.completeUnsafe(D._tag==="Success"?H6(Error("Effect.request: RequestResolver did not complete request",{cause:U.request})):D);if(W.entries.clear(),XJ.length<128)W.entrySet.clear(),W.key=void 0,W.fiber=void 0,W.resolver=void 0,W.map=void 0,XJ.push(W);return $0})};G=W}$.set(H,G),G.fiber=Q8(J.context)(G.delayEffect,{scheduler:J.currentScheduler})}if(G.entrySet.add(K),G.entries.add(K),G.resolver.collectWhile(G.entries))return K;return G.fiber.interruptUnsafe(J.id),G.fiber=Q8(J.context)(mq(G),{scheduler:J.currentScheduler}),K},uq=(X,Y)=>{if(Y.uninterruptible)return;let Q=q2.get(X);if(!Q)return;let J=X.batchKey(Y),$=Q.get(J);if(!$)return;if($.entries.delete(Y),$.entrySet.delete(Y),$.entries.size===0)Q.delete(J),$.fiber?.interruptUnsafe()},wy=(X,Y)=>Y0(()=>uq(X,Y));function mq(X){if(!X.map.has(X.key))return $0;return X.map.delete(X.key),X.run}var xy="effect/Metric/CurrentMetricAttributes",vy=L0(xy,{defaultValue:()=>({})}),Sy="~effect/observability/Metric/MetricRegistryKey",ky=L0(Sy,{defaultValue:()=>new Map}),cq="~effect/observability/Metric";class Y9{[cq]=cq;#X=new WeakMap;#Y;id;description;attributes;constructor(X,Y,Q){this.id=X,this.description=Y,this.attributes=Q}valueUnsafe(X){return this.hook(X).get(X)}modifyUnsafe(X,Y){return this.hook(Y).modify(X,Y)}updateUnsafe(X,Y){return this.hook(Y).update(X,Y)}hook(X){let Y=S1(X,vy);if(Object.keys(Y).length===0){if(B1(this.#Y))return this.#Y.hooks;return this.#Y=this.getOrCreate(X,this.attributes),this.#Y.hooks}let Q=uy(this.attributes,Y),J=this.#X.get(Q);if(B1(J))return J.hooks;return J=this.getOrCreate(X,Q),this.#X.set(Q,J),J.hooks}getOrCreate(X,Y){let Q=fy(this,Y),J=S1(X,ky);if(J.has(Q))return J.get(Q);let $=this.createHooks(),G={id:this.id,type:this.type,description:this.description,attributes:f8(Y),hooks:$};return J.set(Q,G),G}pipe(){return _0(this,arguments)}}var lq=BigInt(0);class by extends Y9{type="Counter";#X;#Y;constructor(X,Y){super(X,Y?.description,f8(Y?.attributes));this.#X=Y?.bigint??!1,this.#Y=Y?.incremental??!1}createHooks(){let X=this.#X?lq:0,Y=this.#Y?this.#X?(J)=>J>=lq:(J)=>J>=0:(J)=>!0;return fY(()=>({count:X,incremental:this.#Y}),(J)=>{if(Y(J))X=X+J})}}class gy extends Y9{type="Gauge";#X;constructor(X,Y){super(X,Y?.description,f8(Y?.attributes));this.#X=Y?.bigint??!1}createHooks(){let X=this.#X?BigInt(0):0;return fY(()=>({value:X}),(J)=>{X=J},(J)=>{X=X+J})}}class yy extends Y9{type="Frequency";#X;constructor(X,Y){super(X,Y?.description,f8(Y?.attributes));this.#X=Y?.preregisteredWords}createHooks(){let X=new Map;if(B1(this.#X))for(let Q of this.#X)X.set(Q,0);return fY(()=>({occurrences:X}),(Q)=>{let J=X.get(Q)??0;X.set(Q,J+1)})}}class hy extends Y9{type="Histogram";#X;constructor(X,Y){super(X,Y?.description,f8(Y?.attributes));this.#X=Y.boundaries}createHooks(){let X=this.#X,Y=X.length,Q=new Uint32Array(Y+1),J=new Float64Array(Y),$=0,G=0,Z=Number.MAX_VALUE,K=-Number.MAX_VALUE;B6(NY(X,O1),(D,U)=>{J[U]=D});let H=(D)=>{let U=0,N=Y;while(U!==N){let V=Math.floor(U+(N-U)/2),z=J[V];if(D<=z)N=V;else U=V;if(N===U+1)if(D<=J[U])N=U;else U=N}if(Q[U]=Q[U]+1,$=$+1,G=G+D,D<Z)Z=D;if(D>K)K=D},W=()=>{let D=PG(Y),U=0;for(let N=0;N<Y;N++){let V=J[N],z=Q[N];U=U+z,D[N]=[V,U]}return D};return fY(()=>({buckets:W(),count:$,min:Z,max:K,sum:G}),H)}}class my extends Y9{type="Summary";#X;#Y;#Q;constructor(X,Y){super(X,Y?.description,f8(Y?.attributes));this.#X=Math.max(I8(GX(Y.maxAge)),0),this.#Y=Y.maxSize,this.#Q=Y.quantiles}createHooks(){let X=NY(this.#Q,O1),Y=PG(this.#Y);for(let U of this.#Q)if(U<0||U>1)throw Error(`Quantile must be between 0 and 1, found: ${U}`);let Q=0,J=0,$=0,G=Number.MAX_VALUE,Z=-Number.MAX_VALUE,K=(U)=>{let N=[],V=0;while(V<this.#Y){let F=Y[V];if(B1(F)){let[R,C]=F,w=U-R;if(w>=0&&w<=this.#X)N.push(C)}V=V+1}let z=NY(N,O1),q=z.length;if(q===0)return X.map((F)=>[F,void 0]);return X.map((F)=>{if(F<=0)return[F,z[0]];if(F>=1)return[F,z[q-1]];let R=Math.ceil(F*q)-1;return[F,z[R]]})},H=(U,N)=>{if(this.#Y>0){let V=Q%this.#Y;Y[V]=[N,U],Q=Q+1}if(J=J+1,$=$+U,U<G)G=U;if(U>Z)Z=U};return fY((U)=>{let N=S1(U,T6);return{quantiles:K(N.currentTimeMillisUnsafe()),count:J,min:G,max:Z,sum:$}},([U,N])=>H(U,N))}}var Q9=B(2,(X,Y)=>g8((Q)=>Y0(()=>X.updateUnsafe(Y,Q))));function fy(X,Y){let Q=`${X.type}:${X.id}`;if(B1(X.description))Q+=`:${X.description}`;if(B1(Y))Q+=`:${py(Y)}`;return Q}function fY(X,Y,Q){return{get:X,update:Y,modify:Q??Y}}function py(X){return dy(Array.isArray(X)?X:Object.entries(X))}function dy(X){return X.map(([Y,Q])=>`${Y}=${Q}`).join(",")}function uy(X,Y){return{...f8(X),...f8(Y)}}function f8(X){if(B1(X)&&Array.isArray(X))return X.reduce((Y,[Q,J])=>{return k(Y,Q,J),Y},{});return X}var ly=Z6,l4=i,oy=MY,iy=PZ,ry=fB,ny=pB,sy=dB,ay=cB,ty=KX,iq=Y8,ey=eG,O2=wV,d=M,pX=LY,dY=tG,rq=e,nq=Y0,uY=$0;var Xh=gZ;var L2=n1,Yh=TY,Qh=aB,Jh=tB,$h=Xz;var _h=eB,Gh=xV,f=w0,Zh=O3,Kh=A0,o4=EV,sq=s6,J9=CV;var Hh=c5,Wh=aG,aq=t,T2=u5,Uh=RV,Dh=PV,Nh=AV,cY=v,Vh=mV,Bh=mX,tq=L6,zh=b8,qh=OB,lY=PY,F2=z0,Oh=y1,Lh=L3,Th=FY,Fh=kV,Rh=XB,Ah=ZZ,Ph=m1;var Eh=E3,Ch=WB,wh=UB,Mh=DB,jh=NB,i4=s1,Ih=_B,xh=RY,vh=P3,Sh=$B,kh=HZ,bh=o5,gh=UZ,yh=DZ,hh=C3,eq=WZ,mh=KB,XO=GB,fh=ZB,ph=A3,YO=HB,dh=NZ,uh=hY,ch=z2,lh=bV,oh=zB,ih=qB,rh=yq,nh=vz,sh=VB,ah=BB,th=AB,eh=PB,Xm=BZ,Ym=RB,Qm=h4,Jm=EB,$m=JZ,_m=$Z,Gm=gV,Zm=T3,Km=rB,Hm=nB,Wm=sB,Um=EZ,Dm=CZ,Nm=YB,Vm=iB,Bm=QB,R2=w3,zm=AY,qm=VZ,Om=LB,Lm=yV,Tm=q6,Fm=b4,Rm=TB,Am=FB,Pm=GZ,Em=g8,Cm=e3,wm=t6,Mm=eV,jm=sV,Im=aV,xm=l5,vm=a6,Sm=tV,QO=h1,km=F3,bm=CY,gm=j3,ym=I3,hm=x3,mm=SB,fm=vB,pm=i5,dm=jB,um=LZ,cm=IB,lm=TZ,om=r5,A2=f1,im=qZ,rm=OZ,nm=kB,sm=RZ,am=FZ,JO=bB,tm=AZ,em=xB,Xf=X8,$O=wY,Yf=hB,Qf=mB,Jf=R3,$f=Sq,_f=B2,Gf=KZ,Zf=JB,Kf=B(2,(X,Y)=>_O(X,void 0,Y)),_O=kq,Hf=Dz,Wf=Nz,Uf=Vz,Df=Bz,Nf=Az,Vf=Pz,Bf=Ez,zf=Cz,qf=Lz,Of=Tz,Lf=Fz,Tf=qz,Ff=hX,Rf=OY,Af=Rz,Pf=Oz,Ef=d5,Cf=fq,wf=pq,Mf=Yz,jf=wZ,If=$z,xf=Qz,vf=Jz,Sf=jV,kf=IV,P2=_z,bf=Q8,gf=MZ,yf=Gz,hf=Kz,mf=jZ,YJ=Zz,ff=S3,pf=Wz,df=IZ,p8=Hz,uf=k3,cf=YZ,lf=vV,GO=y4,of=fX,rf=fX(),nf=fX("Fatal"),sf=fX("Warn"),af=fX("Error"),tf=fX("Info"),ef=fX("Debug"),Xp=fX("Trace"),Yp=B(2,(X,Y)=>a6(X,bZ,(Q)=>new Set([...Q,Y]))),Qp=B((X)=>l4(X[0]),(X,...Y)=>a6(X,mz,(Q)=>{let J=Y.length===1?{...Q,...Y[0]}:{...Q};if(Y.length===1)return J;else k(J,Y[0],Y[1]);return J})),Jp=Iz,$p=B(2,(X,Y)=>v(Mz,(Q)=>a6(X,fz,(J)=>{return[[Y,Q],...J]}))),_p=B((X)=>l4(X[0]),(X,Y,Q)=>A2(X,(J)=>{let $=Q===void 0?J:W0(()=>Q(J));return Q9(Y,$)})),Gp=B((X)=>l4(X[0]),(X,Y,Q)=>tq(X,(J)=>{let $=Q===void 0?J:Q(J);return Q9(Y,$)})),Zp=B((X)=>l4(X[0]),(X,Y,Q)=>eq(X,(J)=>{let $=Q===void 0?J:W0(()=>Q(J));return Q9(Y,$)})),Kp=B((X)=>l4(X[0]),(X,Y,Q)=>YO(X,(J)=>{let $=Q===void 0?J:W0(()=>Q(J));return Q9(Y,$)})),Hp=B((X)=>l4(X[0]),(X,Y,Q)=>GO((J)=>{let $=J.currentTimeNanosUnsafe();return A2(X,()=>{let G=J.currentTimeNanosUnsafe(),Z=yN(GX(G),GX($)),K=Q===void 0?Z:W0(()=>Q(Z));return Q9(Y,K)})}));class pY extends yX()("effect/Effect/Transaction"){}var Wp=(X)=>aq((Y)=>{if(Y.context.mapUnsafe.has(pY.key))return X;let Q={journal:new Map,retry:!1},J;return $O(($)=>cY(iq({while:()=>!J,body:W1($(X).pipe(QO(pY,Q),XO(()=>{if(!Q.retry)return uY;return $(Dp(Q))}),lY)),step(G){if(Q.retry||!Up(Q))return oq(Q);if(M1(G))Np(Y,Q);else oq(Q);J=G}}),()=>J))}),Up=(X)=>{for(let[Y,{version:Q}]of X.journal)if(Y.version!==Q)return!1;return!0},Dp=(X)=>rq(()=>{let Y={},Q=Array.from(X.journal.keys()),J=()=>{for(let $ of Q)$.pending.delete(Y)};return L2(($)=>{let G=()=>{J(),$(uY)};for(let Z of Q)Z.pending.set(Y,G);return nq(J)})});function Np(X,Y){for(let[Q,{value:J}]of Y.journal){if(J!==Q.value)Q.version=Q.version+1,Q.value=J;for(let $ of Q.pending.values())X.currentDispatcher.scheduleTask($,0);Q.pending.clear()}}function oq(X){X.retry=!1,X.journal.clear()}var Vp=cY(pY,(X)=>{return X.retry=!0,JO}),Bp=(X,Y,Q)=>(...J)=>L2(($)=>{try{X(...J,(G,Z)=>{if(G)$(f(Y?Y(G,J):G));else $(d(Z))})}catch(G){$(Q?f(Q(G,J)):sq(G))}}),zp=()=>(X)=>X,qp=()=>(X)=>X,Op=()=>(X)=>X,r4=fV,$9=pV,V1=dV,EX=hV,QJ=uV,oY=SV;var XQ={};k6(XQ,{values:()=>xO,union:()=>fp,toValues:()=>Sp,toEntries:()=>eY,some:()=>tp,size:()=>b2,setMany:()=>up,set:()=>xp,removeMany:()=>dp,remove:()=>pp,reduce:()=>ip,mutate:()=>gp,modifyHash:()=>hp,modifyAt:()=>yp,modify:()=>mp,map:()=>cp,make:()=>Ap,keys:()=>vp,isHashMap:()=>k2,isEmpty:()=>Pp,hasHash:()=>jp,hasBy:()=>Ip,has:()=>Mp,getUnsafe:()=>wp,getHash:()=>Cp,get:()=>Ep,fromIterable:()=>tY,forEach:()=>op,flatMap:()=>lp,findFirst:()=>ap,filterMap:()=>sp,filter:()=>rp,every:()=>ep,entries:()=>vO,endMutation:()=>bp,empty:()=>Rp,compact:()=>np,beginMutation:()=>kp});var $J="~effect/collections/HashMap",dX=5,sY=1<<dX,Lp=sY/4,ZO=sY/2,Tp=sY-1,Fp=(X)=>{return X=X-(X>>>1&1431655765),X=(X&858993459)+(X>>>2&858993459),(X+(X>>>4)&252645135)*16843009>>>24},iY=(X,Y)=>X>>>Y&Tp,d8=(X,Y)=>1<<iY(X,Y),JJ=(X,Y)=>Fp(X&Y-1);function KO(X,Y,Q,J,$,G){if(Y>32)throw Error("HashMap: max depth exceeded");let Z=d8(Q,Y),K=d8($,Y);if(Z===K){let D=KO(X,Y+dX,Q,J,$,G);return new R6(X,Z,[D])}let H=Z|K,W=Z>>>0<K>>>0?[J,G]:[G,J];return new R6(X,H,W)}class _9{canEdit(X){return this.edit===X}}class HO extends _9{_tag="EmptyNode";edit=0;get size(){return 0}get(X,Y,Q){return p()}has(X,Y,Q){return!1}set(X,Y,Q,J,$,G){return G.value=!0,new $8(X,Q,J,$)}remove(X,Y,Q,J,$){return this}iterator(){return[][Symbol.iterator]()}[Symbol.iterator](){return this.iterator()}canEdit(X){return!1}}class $8 extends _9{_tag="LeafNode";edit;hash;key;value;constructor(X,Y,Q,J){super();this.edit=X,this.hash=Y,this.key=Q,this.value=J}get size(){return 1}get(X,Y,Q){if(this.hash===Y&&o(this.key,Q))return T(this.value);return p()}has(X,Y,Q){return this.hash===Y&&o(this.key,Q)}set(X,Y,Q,J,$,G){if(this.hash===Q&&o(this.key,J)){if(o(this.value,$))return this;if(this.canEdit(X))return this.value=$,this;return new $8(X,Q,J,$)}if(G.value=!0,this.hash===Q)return new rY(X,Q,[[this.key,this.value],[J,$]]);let Z=d8(Q,Y),K=d8(this.hash,Y);if(Z===K)return new R6(X,Z,[this.set(X,Y+dX,Q,J,$,G)]);let H=Z|K,W=Z>>>0<K>>>0?[new $8(X,Q,J,$),this]:[this,new $8(X,Q,J,$)];return new R6(X,H,W)}remove(X,Y,Q,J,$){if(this.hash===Q&&o(this.key,J)){$.value=!0;return}return this}iterator(){return[[this.key,this.value]][Symbol.iterator]()}[Symbol.iterator](){return this.iterator()}}class rY extends _9{_tag="CollisionNode";edit;hash;entries;constructor(X,Y,Q){super();this.edit=X,this.hash=Y,this.entries=Q}get size(){return this.entries.length}get(X,Y,Q){if(this.hash!==Y)return p();for(let[J,$]of this.entries)if(o(J,Q))return T($);return p()}has(X,Y,Q){if(this.hash!==Y)return!1;for(let[J]of this.entries)if(o(J,Q))return!0;return!1}set(X,Y,Q,J,$,G){if(this.hash!==Q)return G.value=!0,KO(X,Y,this.hash,this,Q,new $8(X,Q,J,$));for(let Z=0;Z<this.entries.length;Z++)if(o(this.entries[Z][0],J)){if(o(this.entries[Z][1],$))return this;if(this.canEdit(X))return this.entries[Z]=[J,$],this;let K=[...this.entries];return K[Z]=[J,$],new rY(X,this.hash,K)}if(G.value=!0,this.canEdit(X))return this.entries.push([J,$]),this;return new rY(X,this.hash,[...this.entries,[J,$]])}remove(X,Y,Q,J,$){if(this.hash!==Q)return this;let G=this.entries.findIndex(([K])=>o(K,J));if(G===-1)return this;if($.value=!0,this.entries.length===1)return;if(this.entries.length===2){let K=this.entries[G===0?1:0];return new $8(X,this.hash,K[0],K[1])}if(this.canEdit(X))return this.entries.splice(G,1),this;let Z=[...this.entries];return Z.splice(G,1),new rY(X,this.hash,Z)}iterator(){return this.entries[Symbol.iterator]()}[Symbol.iterator](){return this.iterator()}}class R6 extends _9{_tag="IndexedNode";edit;_size;bitmap;children;constructor(X,Y,Q){super();this.edit=X,this.bitmap=Y,this.children=Q}get size(){if(this._size===void 0)this._size=this.children.reduce((X,Y)=>X+Y.size,0);return this._size}get(X,Y,Q){let J=d8(Y,X);if((this.bitmap&J)===0)return p();let $=JJ(this.bitmap,J);return this.children[$].get(X+dX,Y,Q)}has(X,Y,Q){let J=d8(Y,X);if((this.bitmap&J)===0)return!1;let $=JJ(this.bitmap,J);return this.children[$].has(X+dX,Y,Q)}set(X,Y,Q,J,$,G){let Z=d8(Q,Y),K=JJ(this.bitmap,Z);if((this.bitmap&Z)!==0){let H=this.children[K],W=H.set(X,Y+dX,Q,J,$,G);if(H===W)return this;if(this.canEdit(X))return this.children[K]=W,this;let D=[...this.children];return D[K]=W,new R6(X,this.bitmap,D)}else{G.value=!0;let H=new $8(X,Q,J,$),W=this.bitmap|Z;if(this.canEdit(X)){if(this.children.splice(K,0,H),this.bitmap=W,this._size=void 0,this.children.length>ZO)return this.expand(X,W,this.children);return this}let D=[...this.children];if(D.splice(K,0,H),D.length>ZO)return this.expand(X,W,D);return new R6(X,W,D)}}remove(X,Y,Q,J,$){let G=d8(Q,Y);if((this.bitmap&G)===0)return this;let Z=JJ(this.bitmap,G),K=this.children[Z],H=K.remove(X,Y+dX,Q,J,$);if(!$.value)return this;if(H===void 0){let D=this.bitmap^G;if(D===0)return;if(this.children.length===2){let N=this.children[Z===0?1:0];if(N._tag==="LeafNode")return N}if(this.canEdit(X))return this.children.splice(Z,1),this.bitmap=D,this._size=void 0,this;let U=[...this.children];return U.splice(Z,1),new R6(X,D,U)}if(K===H)return this;if(this.canEdit(X))return this.children[Z]=H,this;let W=[...this.children];return W[Z]=H,new R6(X,this.bitmap,W)}expand(X,Y,Q){let J=new globalThis.Array(sY),$=0;for(let G=0;G<sY;G++)if((Y&1<<G)!==0)J[G]=Q[$++];return new nY(X,Q.length,J)}iterator(){let X=0,Y;return{next:()=>{while(X<this.children.length){if(!Y)Y=this.children[X].iterator();let Q=Y.next();if(!Q.done)return Q;Y=void 0,X++}return{done:!0,value:void 0}}}}[Symbol.iterator](){return this.iterator()}}class nY extends _9{_tag="ArrayNode";edit;_size;count;children;constructor(X,Y,Q){super();this.edit=X,this.count=Y,this.children=Q}get size(){if(this._size===void 0)this._size=this.children.reduce((X,Y)=>X+(Y?.size??0),0);return this._size}get(X,Y,Q){let J=iY(Y,X),$=this.children[J];return $?$.get(X+dX,Y,Q):p()}has(X,Y,Q){let J=iY(Y,X),$=this.children[J];return $?$.has(X+dX,Y,Q):!1}set(X,Y,Q,J,$,G){let Z=iY(Q,Y),K=this.children[Z];if(K){let H=K.set(X,Y+dX,Q,J,$,G);if(K===H)return this;if(this.canEdit(X))return this.children[Z]=H,this;let W=[...this.children];return W[Z]=H,new nY(X,this.count,W)}else{G.value=!0;let H=new $8(X,Q,J,$);if(this.canEdit(X))return this.children[Z]=H,this.count++,this._size=void 0,this;let W=[...this.children];return W[Z]=H,new nY(X,this.count+1,W)}}remove(X,Y,Q,J,$){let G=iY(Q,Y),Z=this.children[G];if(!Z)return this;let K=Z.remove(X,Y+dX,Q,J,$);if(!$.value)return this;let H=this.count-(K?0:1);if(H<Lp)return this.pack(X,G,K);if(Z===K)return this;if(this.canEdit(X)){if(this.children[G]=K,!K)this.count=H;return this._size=void 0,this}let W=[...this.children];return W[G]=K,new nY(X,H,W)}pack(X,Y,Q){let J=[],$=0,G=1;for(let Z=0;Z<this.children.length;Z++){let K=Z===Y?Q:this.children[Z];if(K)J.push(K),$|=G;G<<=1}return new R6(X,$,J)}iterator(){let X=0,Y;return{next:()=>{while(X<this.children.length){let Q=this.children[X];if(!Q){X++;continue}if(!Y)Y=Q.iterator();let J=Y.next();if(!J.done)return J;Y=void 0,X++}return{done:!0,value:void 0}}}}[Symbol.iterator](){return this.iterator()}}class G9{[$J]=$J;_editable;_edit;_root;_size;constructor(X,Y,Q,J){this._editable=X,this._edit=Y,this._root=Q,this._size=J}get size(){return this._size}[Symbol.iterator](){return this._root.iterator()}[N0](X){if(C2(X)){let Y=X;if(this.size!==Y.size)return!1;for(let[Q,J]of this){let $=d_(X,aY(Q));if(P0($)||!o(J,$.value))return!1}return!0}return!1}[D0](){let X=g0("HashMap");for(let[Y,Q]of this)X=X^X0(Y)+X0(Q);return X}[U1](){return A1(this)}toString(){return`HashMap(${P(Array.from(this))})`}toJSON(){return{_id:"HashMap",values:Array.from(this).map(([X,Y])=>[A1(X),A1(Y)])}}pipe(){return _0(this,arguments)}}var E2=new HO,C2=(X)=>j(X,$J),t1=()=>new G9(!1,0,E2,0),WO=(...X)=>w2(X),w2=(X)=>{let Y=E2,Q=0,J={value:!1};for(let[$,G]of X){let Z=X0($);if(J.value=!1,Y=Y.set(NaN,0,Z,$,G,J),J.value)Q++}return new G9(!1,0,Y,Q)},_J=(X)=>X.size===0,aY=B(2,(X,Y)=>{return X._root.get(0,X0(Y),Y)}),M2=B(3,(X,Y,Q)=>{return X._root.get(0,Q,Y)}),UO=B(2,(X,Y)=>{let Q=aY(X,Y);if(N1(Q))return Q.value;throw Error(`HashMap.getUnsafe: key not found: ${Y}`)}),n4=B(2,(X,Y)=>{return X._root.has(0,X0(Y),Y)}),j2=B(3,(X,Y,Q)=>{return X._root.has(0,Q,Y)}),DO=B(2,(X,Y)=>{for(let[Q,J]of X)if(Y(J,Q))return!0;return!1}),L1=B(3,(X,Y,Q)=>{let J=X,$=X0(Y),G={value:!1},Z=J._editable?J._edit:NaN,K=J._root.set(Z,0,$,Y,Q,G);if(J._editable){if(J._root=K,G.value)J._size++;return X}if(J._root===K)return X;return new G9(!1,J._edit,K,J._size+(G.value?1:0))}),GJ=(X)=>{let Y=X[Symbol.iterator]();return{[Symbol.iterator](){return this},next(){let Q=Y.next();if(Q.done)return{done:!0,value:void 0};return{done:!1,value:Q.value[0]}}}},NO=(X)=>{let Y=X[Symbol.iterator]();return{[Symbol.iterator](){return this},next(){let Q=Y.next();if(Q.done)return{done:!0,value:void 0};return{done:!1,value:Q.value[1]}}}},VO=(X)=>{let Y=X[Symbol.iterator]();return{[Symbol.iterator](){return this},next(){return Y.next()}}},ZJ=(X)=>X.size,I2=(X)=>{let Y=X;return new G9(!0,Y._edit+1,Y._root,Y._size)},x2=(X)=>{let Y=X;return Y._editable=!1,X},BO=B(2,(X,Y)=>{let Q=I2(X);return Y(Q),x2(Q)}),v2=B(3,(X,Y,Q)=>{let J=aY(X,Y),$=Q(J);if(P0($))return n4(X,Y)?s4(X,Y):X;return L1(X,Y,$.value)}),zO=B(4,(X,Y,Q,J)=>{let $=M2(X,Y,Q),G=J($);if(P0(G))return j2(X,Y,Q)?s4(X,Y):X;return L1(X,Y,G.value)}),qO=B(3,(X,Y,Q)=>{return v2(X,Y,i6(Q))}),S2=B(2,(X,Y)=>{let Q=X;for(let[J,$]of Y)Q=L1(Q,J,$);return Q}),s4=B(2,(X,Y)=>{let Q=X,J=X0(Y),$={value:!1},G=Q._editable?Q._edit:NaN,Z=Q._root.remove(G,0,J,Y,$);if(!$.value)return X;if(Q._editable)return Q._root=Z??E2,Q._size--,X;if(Z===void 0)return t1();return new G9(!1,Q._edit,Z,Q._size-1)}),OO=B(2,(X,Y)=>{let Q=X;for(let J of Y)Q=s4(Q,J);return Q}),LO=B(2,(X,Y)=>{let Q=X;for(let[J,$]of Y)Q=L1(Q,J,$);return Q}),TO=B(2,(X,Y)=>{let Q=t1();for(let[J,$]of X)Q=L1(Q,J,Y($,J));return Q}),FO=B(2,(X,Y)=>{let Q=t1();for(let[J,$]of X)Q=S2(Q,Y($,J));return Q}),RO=B(2,(X,Y)=>{for(let[Q,J]of X)Y(J,Q)}),AO=B(3,(X,Y,Q)=>{let J=Y;for(let[$,G]of X)J=Q(J,G,$);return J}),PO=B(2,(X,Y)=>{let Q=t1();for(let[J,$]of X)if(Y($,J))Q=L1(Q,J,$);return Q}),EO=(X)=>{let Y=t1();for(let[Q,J]of X)if(N1(J))Y=L1(Y,Q,J.value);return Y},CO=B(2,(X,Y)=>{let Q=t1();for(let[J,$]of X){let G=Y($,J);if(Y1(G))Q=L1(Q,J,G.success)}return Q}),wO=B(2,(X,Y)=>{for(let[Q,J]of X)if(Y(J,Q))return T([Q,J]);return p()}),MO=B(2,(X,Y)=>{for(let[Q,J]of X)if(Y(J,Q))return!0;return!1}),jO=B(2,(X,Y)=>{for(let[Q,J]of X)if(!Y(J,Q))return!1;return!0});var k2=C2,Rp=t1,Ap=WO,tY=w2,Pp=_J,Ep=aY,Cp=M2,wp=UO,Mp=n4,jp=j2,Ip=DO,xp=L1,vp=GJ,xO=NO,Sp=(X)=>Array.from(xO(X)),vO=VO,eY=(X)=>Array.from(vO(X)),b2=ZJ,kp=I2,bp=x2,gp=BO,yp=v2,hp=zO,mp=qO,fp=S2,pp=s4,dp=OO,up=LO,cp=TO,lp=FO,op=RO,ip=AO,rp=PO,np=EO,sp=CO,ap=wO,tp=MO,ep=jO;var WX={};k6(WX,{union:()=>Kd,some:()=>Vd,size:()=>f2,remove:()=>Gd,reduce:()=>zd,map:()=>Dd,make:()=>Jd,isSubset:()=>Ud,isHashSet:()=>m2,isEmpty:()=>Zd,intersection:()=>Hd,has:()=>_d,fromIterable:()=>QQ,filter:()=>Nd,every:()=>Bd,empty:()=>Qd,difference:()=>Wd,add:()=>$d});var YQ="~effect/collections/HashSet",Xd={[D0](){return X0(YQ)},[N0](X){return g2(X)&&KJ(this)===KJ(X)&&h2(this,(Y)=>Z9(X,Y))},[Symbol.iterator](){return GJ(a4(this))},toString(){return`HashSet(${P(Array.from(this))})`},toJSON(){return{_id:"HashSet",values:A1(Array.from(this))}},[U1](){return this.toJSON()},pipe(){return _0(this,arguments)}},u8=(X)=>{let Y=Object.create(Xd);return Y[YQ]=YQ,Y.keyMap=X,Y},g2=(X)=>j(X,YQ),a4=(X)=>X.keyMap,SO=()=>u8(t1()),kO=(...X)=>y2(X),y2=(X)=>{let Y=t1();for(let Q of X)Y=L1(Y,Q,!0);return u8(Y)},Z9=(X,Y)=>n4(a4(X),Y),bO=(X,Y)=>{let Q=a4(X);return n4(Q,Y)?X:u8(L1(Q,Y,!0))},gO=(X,Y)=>{let Q=a4(X);return n4(Q,Y)?u8(s4(Q,Y)):X},KJ=(X)=>ZJ(a4(X)),yO=(X)=>_J(a4(X)),hO=(X,Y)=>{let Q=t1();for(let J of X)if(Y(J))Q=L1(Q,J,!0);return u8(Q)},mO=(X,Y)=>{let J=a4(X);for(let $ of Y)J=L1(J,$,!0);return u8(J)},fO=(X,Y)=>{let Q=t1();for(let J of X)if(Z9(Y,J))Q=L1(Q,J,!0);return u8(Q)},pO=(X,Y)=>hO(X,(Q)=>!Z9(Y,Q)),dO=(X,Y)=>{for(let Q of X)if(!Z9(Y,Q))return!1;return!0},uO=(X,Y)=>{let Q=t1();for(let J of X)Q=L1(Q,Y(J),!0);return u8(Q)},cO=(X,Y)=>hO(X,Y),lO=(X,Y)=>{for(let Q of X)if(Y(Q))return!0;return!1},h2=(X,Y)=>{for(let Q of X)if(!Y(Q))return!1;return!0},oO=(X,Y,Q)=>{let J=Y;for(let $ of X)J=Q(J,$);return J};var Qd=SO,Jd=kO,QQ=y2,m2=g2,$d=B(2,bO),_d=B(2,Z9),Gd=B(2,gO),f2=KJ,Zd=yO,Kd=B(2,mO),Hd=B(2,fO),Wd=B(2,pO),Ud=B(2,dO),Dd=B(2,uO),Nd=B(2,cO),Vd=B(2,lO),Bd=B(2,h2),zd=B(3,oO);var _={};k6(_,{withDecodingDefaultTypeKey:()=>P00,withDecodingDefaultType:()=>E00,withDecodingDefaultKey:()=>nW,withDecodingDefault:()=>Iw,withConstructorDefault:()=>jw,toType:()=>u1,toTaggedUnion:()=>xw,toStandardSchemaV1:()=>ve,toStandardJSONSchemaV1:()=>Se,toRepresentation:()=>tX0,toJsonSchemaDocument:()=>tM,toIsoSource:()=>A60,toIsoFocus:()=>P60,toIso:()=>R60,toFormatter:()=>nX0,toEquivalence:()=>aX0,toEncoderXml:()=>$60,toEncoded:()=>h9,toDifferJsonPatch:()=>C60,toCodecStringTree:()=>$j,toCodecJsonAST:()=>e$,toCodecJson:()=>eM,toCodecIso:()=>Qj,toCodecArrayFromSingle:()=>J60,toArbitraryLazy:()=>aM,toArbitrary:()=>iX0,tagDefaultOmit:()=>C00,tag:()=>B5,suspend:()=>Pw,revealCodec:()=>xe,revealBottom:()=>we,resolveAnnotationsKey:()=>v60,resolveAnnotations:()=>x60,requiredKey:()=>re,required:()=>ne,refine:()=>O00,redact:()=>JU,readonlyKey:()=>ae,overrideToFormatter:()=>rX0,overrideToEquivalence:()=>sX0,overrideToCodecIso:()=>E60,optionalKey:()=>H4,optional:()=>xX,mutableKey:()=>se,mutable:()=>z00,middlewareEncoding:()=>Cw,middlewareDecoding:()=>oW,makeIsMultipleOf:()=>iw,makeIsLessThanOrEqualTo:()=>eQ,makeIsLessThan:()=>tQ,makeIsGreaterThanOrEqualTo:()=>aQ,makeIsGreaterThan:()=>sQ,makeIsBetween:()=>X7,makeFilterGroup:()=>j00,makeFilter:()=>j0,make:()=>S,link:()=>S0,isUppercasedReviver:()=>l00,isUppercased:()=>dw,isUniqueReviver:()=>T10,isUnique:()=>YU,isUncapitalizedReviver:()=>r00,isUncapitalized:()=>lw,isUint32:()=>$10,isUUIDReviver:()=>y00,isUUID:()=>bw,isULIDReviver:()=>m00,isULID:()=>yw,isTrimmedReviver:()=>I00,isTrimmed:()=>sW,isStringSymbolReviver:()=>b00,isStringSymbol:()=>kw,isStringFiniteReviver:()=>S00,isStringFinite:()=>vw,isStringBigIntReviver:()=>k00,isStringBigInt:()=>Sw,isStartsWithReviver:()=>d00,isStartsWith:()=>mw,isSizeBetweenReviver:()=>B10,isSizeBetween:()=>DM,isSchemaError:()=>eK,isSchema:()=>o$,isPropertyNamesReviver:()=>L10,isPropertyNames:()=>zM,isPropertiesLengthBetweenReviver:()=>O10,isPropertiesLengthBetween:()=>BM,isPatternReviver:()=>v00,isPattern:()=>z5,isNonEmpty:()=>KM,isMultipleOfReviver:()=>Y10,isMultipleOf:()=>aw,isMinSizeReviver:()=>N10,isMinSize:()=>WM,isMinPropertiesReviver:()=>z10,isMinProperties:()=>NM,isMinLengthReviver:()=>W10,isMinLength:()=>eW,isMaxSizeReviver:()=>V10,isMaxSize:()=>UM,isMaxPropertiesReviver:()=>q10,isMaxProperties:()=>VM,isMaxLengthReviver:()=>U10,isMaxLength:()=>HM,isLowercasedReviver:()=>o00,isLowercased:()=>uw,isLessThanReviver:()=>t00,isLessThanOrEqualToReviver:()=>e00,isLessThanOrEqualToDateReviver:()=>B60,isLessThanOrEqualToDate:()=>YM,isLessThanOrEqualToBigIntReviver:()=>T60,isLessThanOrEqualToBigInt:()=>GM,isLessThanOrEqualToBigDecimal:()=>K10,isLessThanOrEqualTo:()=>sw,isLessThanDateReviver:()=>V60,isLessThanDate:()=>XM,isLessThanBigIntReviver:()=>L60,isLessThanBigInt:()=>_M,isLessThanBigDecimal:()=>Z10,isLessThan:()=>nw,isLengthBetweenReviver:()=>D10,isLengthBetween:()=>XU,isIntReviver:()=>Q10,isInt32:()=>J10,isInt:()=>Y7,isIncludesReviver:()=>c00,isIncludes:()=>pw,isGreaterThanReviver:()=>s00,isGreaterThanOrEqualToReviver:()=>a00,isGreaterThanOrEqualToDateReviver:()=>N60,isGreaterThanOrEqualToDate:()=>ew,isGreaterThanOrEqualToBigIntReviver:()=>O60,isGreaterThanOrEqualToBigInt:()=>$M,isGreaterThanOrEqualToBigDecimal:()=>G10,isGreaterThanOrEqualTo:()=>tW,isGreaterThanDateReviver:()=>D60,isGreaterThanDate:()=>tw,isGreaterThanBigIntReviver:()=>q60,isGreaterThanBigInt:()=>JM,isGreaterThanBigDecimal:()=>_10,isGreaterThan:()=>rw,isGUIDReviver:()=>h00,isGUID:()=>gw,isFiniteReviver:()=>n00,isFinite:()=>ow,isEndsWithReviver:()=>u00,isEndsWith:()=>fw,isCapitalizedReviver:()=>i00,isCapitalized:()=>cw,isBetweenReviver:()=>X10,isBetweenDateReviver:()=>z60,isBetweenDate:()=>QM,isBetweenBigIntReviver:()=>F60,isBetweenBigInt:()=>ZM,isBetweenBigDecimal:()=>H10,isBetween:()=>a$,isBase64UrlReviver:()=>p00,isBase64Url:()=>hw,isBase64Reviver:()=>f00,isBase64:()=>aW,is:()=>Jw,instanceOf:()=>W4,fromURLSearchParams:()=>zX0,fromJsonString:()=>pM,fromFormData:()=>VX0,fromBrand:()=>L00,flip:()=>mW,fieldsAssign:()=>Z00,extendTo:()=>W00,encodeUnknownSync:()=>zw,encodeUnknownResult:()=>Vw,encodeUnknownPromise:()=>Bw,encodeUnknownOption:()=>ue,encodeUnknownExit:()=>Nw,encodeUnknownEffect:()=>l$,encodeTo:()=>iW,encodeSync:()=>ie,encodeResult:()=>le,encodePromise:()=>oe,encodeOption:()=>ce,encodeKeys:()=>H00,encodeExit:()=>de,encodeEffect:()=>Dw,encode:()=>A00,decodeUnknownSync:()=>Uw,decodeUnknownResult:()=>Hw,decodeUnknownPromise:()=>Ww,decodeUnknownOption:()=>ye,decodeUnknownExit:()=>Zw,decodeUnknownEffect:()=>c$,decodeTo:()=>l,decodeSync:()=>pe,decodeResult:()=>me,decodePromise:()=>fe,decodeOption:()=>he,decodeExit:()=>ge,decodeEffect:()=>be,decode:()=>R00,declareConstructor:()=>qX,declare:()=>vX,check:()=>q00,catchEncodingWithContext:()=>Mw,catchEncoding:()=>F00,catchDecodingWithContext:()=>ww,catchDecoding:()=>T00,brand:()=>Ew,asserts:()=>ke,annotateKey:()=>Ie,annotateEncoded:()=>je,annotate:()=>Me,Void:()=>$00,UnknownFromJsonString:()=>UX0,Unknown:()=>dW,UniqueSymbol:()=>G00,UniqueArray:()=>B00,Union:()=>J1,UndefinedOr:()=>n$,Undefined:()=>uW,Uint8ArrayReviver:()=>wX0,Uint8ArrayFromHex:()=>IX0,Uint8ArrayFromBase64Url:()=>jX0,Uint8ArrayFromBase64:()=>MX0,Uint8Array:()=>J7,URLSearchParamsReviver:()=>BX0,URLSearchParams:()=>HU,URLReviver:()=>r10,URLFromString:()=>n10,URL:()=>$U,TupleWithRest:()=>D00,Tuple:()=>k9,Trimmed:()=>dM,Trim:()=>TX0,Tree:()=>w60,TimeZoneReviver:()=>hX0,TimeZoneOffsetReviver:()=>bX0,TimeZoneOffset:()=>cM,TimeZoneNamedReviver:()=>gX0,TimeZoneNamedFromString:()=>yX0,TimeZoneNamed:()=>WU,TimeZoneFromString:()=>mX0,TimeZone:()=>UU,TemplateLiteralParser:()=>X00,TemplateLiteral:()=>ee,TaggedUnion:()=>w00,TaggedStruct:()=>s$,TaggedErrorClass:()=>oX0,TaggedClass:()=>lX0,Symbol:()=>Lw,StructWithRest:()=>U00,Struct:()=>h,StringFromUriComponent:()=>PX0,StringFromHex:()=>AX0,StringFromBase64Url:()=>RX0,StringFromBase64:()=>FX0,String:()=>r,StandardSchemaV1FailureResult:()=>EX0,SchemaError:()=>X4,ResultReviver:()=>I10,Result:()=>qM,RegExpReviver:()=>i10,RegExp:()=>bM,RedactedReviver:()=>S10,RedactedFromValue:()=>k10,Redacted:()=>QU,Record:()=>Tw,ReadonlySetReviver:()=>c10,ReadonlySet:()=>vM,ReadonlyMapReviver:()=>d10,ReadonlyMap:()=>IM,PropertyKey:()=>pW,OptionReviver:()=>A10,OptionFromUndefinedOr:()=>E10,OptionFromOptionalNullOr:()=>j10,OptionFromOptionalKey:()=>w10,OptionFromOptional:()=>M10,OptionFromNullishOr:()=>C10,OptionFromNullOr:()=>P10,Option:()=>U4,Opaque:()=>M00,ObjectKeyword:()=>_00,NumberFromString:()=>qX0,Number:()=>i$,NullishOr:()=>Aw,NullOr:()=>lW,Null:()=>T0,NonEmptyString:()=>F10,NonEmptyArray:()=>N00,Never:()=>Q00,Natural:()=>zX,MutableJsonReviver:()=>I60,MutableJson:()=>Hj,Literals:()=>r$,Literal:()=>c0,JsonReviver:()=>M60,Json:()=>X_,Int:()=>q5,HashSetReviver:()=>l10,HashSet:()=>SM,HashMapReviver:()=>u10,HashMap:()=>xM,FormDataReviver:()=>NX0,FormData:()=>KU,FiniteFromString:()=>OX0,Finite:()=>Y6,FileReviver:()=>DX0,File:()=>ZU,ExitReviver:()=>p10,Exit:()=>wM,ErrorReviver:()=>m10,ErrorClass:()=>sM,Error:()=>CM,Enum:()=>Y00,DurationReviver:()=>e10,DurationFromString:()=>YX0,DurationFromNanos:()=>QX0,DurationFromMillis:()=>JX0,Duration:()=>Q7,Defect:()=>f10,DateTimeZonedReviver:()=>fX0,DateTimeZonedFromString:()=>pX0,DateTimeZoned:()=>DU,DateTimeUtcReviver:()=>xX0,DateTimeUtcFromString:()=>SX0,DateTimeUtcFromMillis:()=>kX0,DateTimeUtcFromDate:()=>vX0,DateTimeUtc:()=>$7,DateReviver:()=>s10,DateFromString:()=>a10,DateFromMillis:()=>t10,Date:()=>Q6,Class:()=>nM,ChunkReviver:()=>o10,Chunk:()=>kM,Char:()=>R10,CauseReviver:()=>g10,CauseReasonReviver:()=>b10,CauseReason:()=>p$,Cause:()=>d$,BooleanFromBit:()=>CX0,Boolean:()=>Ow,BigIntFromString:()=>LX0,BigInt:()=>j6,BigDecimalReviver:()=>KX0,BigDecimalFromString:()=>HX0,BigDecimal:()=>GU,ArrayEnsure:()=>V00,Array:()=>Q1,Any:()=>J00});var iO=/^[+-]?\d+$/,p2="~effect/BigDecimal",qd={[p2]:p2,[D0](){let X=d2(this);return _1(X0(X.value),h6(X.scale))},[N0](X){return WJ(X)&&Ad(this,X)},toString(){return`BigDecimal(${A6(this)})`},toJSON(){return{_id:"BigDecimal",value:String(this.value),scale:this.scale}},[U1](){return this.toJSON()},pipe(){return _0(this,arguments)}},WJ=(X)=>j(X,p2),e1=(X,Y)=>{let Q=Object.create(qd);return Q.value=X,Q.scale=Y,Q},nO=(X,Y)=>{if(X!==UX&&X%HJ===UX)throw RangeError("Value must be normalized");let Q=e1(X,Y);return Q.normalized=Q,Q},UX=BigInt(0),Od=BigInt(1),Ld=BigInt(-1);var HJ=BigInt(10),sO=nO(UX,0);var d2=(X)=>{if(X.normalized===void 0)if(X.value===UX)X.normalized=sO;else{let Y=`${X.value}`,Q=0;for(let G=Y.length-1;G>=0;G--)if(Y[G]==="0")Q++;else break;if(Q===0)X.normalized=X;let J=BigInt(Y.substring(0,Y.length-Q)),$=X.scale-Q;X.normalized=nO(J,$)}return X.normalized},c8=B(2,(X,Y)=>{if(Y>X.scale)return e1(X.value*HJ**BigInt(Y-X.scale),Y);if(Y<X.scale)return e1(X.value/HJ**BigInt(X.scale-Y),Y);return X}),aO=B(2,(X,Y)=>{if(Y.value===UX)return X;if(X.value===UX)return Y;if(X.scale>Y.scale)return e1(c8(Y,X.scale).value+X.value,X.scale);if(X.scale<Y.scale)return e1(c8(X,Y.scale).value+Y.value,Y.scale);return e1(X.value+Y.value,X.scale)});var _8=C4((X,Y)=>{let Q=O1(rO(X),rO(Y));if(Q!==0)return Q;if(X.scale>Y.scale)return AX(X.value,c8(Y,X.scale).value);if(X.scale<Y.scale)return AX(c8(X,Y.scale).value,Y.value);return AX(X.value,Y.value)}),Td=x5(_8);var Fd=w8(_8);var rO=(X)=>X.value===UX?0:X.value<UX?-1:1,Rd=(X)=>X.value<UX?e1(-X.value,X.scale):X;var u2=D1((X,Y)=>{if(X.scale>Y.scale)return c8(Y,X.scale).value===X.value;if(X.scale<Y.scale)return c8(X,Y.scale).value===Y.value;return X.value===Y.value}),Ad=B(2,(X,Y)=>u2(X,Y));var tO=(X)=>{if(X==="")return T(sO);let Y,Q,J=X.search(/[eE]/);if(J!==-1){let H=X.slice(J+1);if(Y=X.slice(0,J),Q=Number(H),Y===""||!Number.isSafeInteger(Q)||!iO.test(H))return p()}else Y=X,Q=0;let $,G,Z=Y.search(/\./);if(Z!==-1){let H=Y.slice(0,Z),W=Y.slice(Z+1);$=`${H}${W}`,G=W.length}else $=Y,G=0;if(!iO.test($))return p();let K=G-Q;if(!Number.isSafeInteger(K))return p();return T(e1(BigInt($),K))};var A6=(X)=>{let Y=d2(X);if(Math.abs(Y.scale)>=16)return Pd(Y);let Q=Y.value<UX,J=Q?`${Y.value}`.substring(1):`${Y.value}`,$,G;if(Y.scale>=J.length)$="0",G="0".repeat(Y.scale-J.length)+J;else{let K=J.length-Y.scale;if(K>J.length){let H=K-J.length;$=`${J}${"0".repeat(H)}`,G=""}else G=J.slice(K),$=J.slice(0,K)}let Z=G===""?$:`${$}.${G}`;return Q?`-${Z}`:Z},Pd=(X)=>{if(Ed(X))return"0e+0";let Y=d2(X),Q=`${Rd(Y).value}`,J=Q.slice(0,1),$=Q.slice(1),G=`${eO(Y)?"-":""}${J}`;if($!=="")G+=`.${$}`;let Z=$.length-Y.scale;return`${G}e${Z>=0?"+":""}${Z}`};var Ed=(X)=>X.value===UX,eO=(X)=>X.value<UX,Cd=(X)=>X.value>UX,c2=(X)=>WJ(X[0]);var XL=B(c2,(X,Y=0)=>{if(X.scale<=Y)return X;return e1(X.value/HJ**BigInt(X.scale-Y),Y)}),l2=B(c2,(X,Y=0)=>{let Q=XL(X,Y);if(Cd(X)&&Td(Q,X))return aO(Q,e1(Od,Y));return Q});var o2=B(c2,(X,Y=0)=>{let Q=XL(X,Y);if(eO(X)&&Fd(Q,X))return aO(Q,e1(Ld,Y));return Q});var QL="~effect/collections/Chunk";function wd(X,Y,Q,J,$){for(let G=Y;G<Math.min(X.length,Y+$);G++)Q[J+G-Y]=X[G];return Q}var JL=[],r2=(X)=>D1((Y,Q)=>Y.length===Q.length&&JQ(Y).every((J,$)=>X(J,$Q(Q,$)))),Md=r2(o),jd={[QL]:{_A:(X)=>X},toString(){return`Chunk(${P(JQ(this))})`},toJSON(){return{_id:"Chunk",values:A1(JQ(this))}},[U1](){return this.toJSON()},[N0](X){return UJ(X)&&Md(this,X)},[D0](){return e9(JQ(this))},[Symbol.iterator](){switch(this.backing._tag){case"IArray":return this.backing.array[Symbol.iterator]();case"IEmpty":return JL[Symbol.iterator]();default:return JQ(this)[Symbol.iterator]()}},pipe(){return _0(this,arguments)}},n2=(X)=>{let Y=Object.create(jd);switch(Y.backing=X,X._tag){case"IEmpty":{Y.length=0,Y.depth=0,Y.left=Y,Y.right=Y;break}case"IConcat":{Y.length=X.left.length+X.right.length,Y.depth=1+Math.max(X.left.depth,X.right.depth),Y.left=X.left,Y.right=X.right;break}case"IArray":{Y.length=X.array.length,Y.depth=0,Y.left=G8,Y.right=G8;break}case"ISingleton":{Y.length=1,Y.depth=0,Y.left=G8,Y.right=G8;break}case"ISlice":{Y.length=X.length,Y.depth=X.chunk.depth+1,Y.left=G8,Y.right=G8;break}}return Y},UJ=(X)=>j(X,QL),G8=n2({_tag:"IEmpty"}),Id=()=>G8;var xd=(X)=>n2({_tag:"ISingleton",a:X}),DJ=(X)=>UJ(X)?X:Sd(C1(X)),i2=(X,Y,Q)=>{switch(X.backing._tag){case"IArray":{wd(X.backing.array,0,Y,Q,X.length);break}case"IConcat":{i2(X.left,Y,Q),i2(X.right,Y,Q+X.left.length);break}case"ISingleton":{Y[Q]=X.backing.a;break}case"ISlice":{let J=0,$=Q;while(J<X.length)Y[$]=$Q(X,J),J+=1,$+=1;break}}};var vd=(X)=>{switch(X.backing._tag){case"IEmpty":return JL;case"IArray":return X.backing.array;default:{let Y=Array(X.length);return i2(X,Y,0),X.backing={_tag:"IArray",array:Y},X.left=G8,X.right=G8,X.depth=0,Y}}},JQ=vd;var Sd=(X)=>X.length===0?Id():X.length===1?xd(X[0]):n2({_tag:"IArray",array:X});var $Q=B(2,(X,Y)=>{let Q=Math.floor(Y);switch(X.backing._tag){case"IEmpty":throw Error(`Index out of bounds: ${Q}`);case"ISingleton":{if(Y!==0)throw Error(`Index out of bounds: ${Q}`);return X.backing.a}case"IArray":{if(Q>=X.length||Q<0)throw Error(`Index out of bounds: ${Q}`);return X.backing.array[Q]}case"IConcat":return Q<X.left.length?$Q(X.left,Q):$Q(X.right,Q-X.left.length);case"ISlice":return $Q(X.backing.chunk,Q+X.backing.offset)}});var $L=(X)=>X.length;var s2=X9,_L=u4,GL=Uq,ZL=Dq,KL=Nq,HL=sZ,a2=Vq,t2=Bq;var WL=e5;var UL=eZ;var NJ=zq,DL=qq;var VJ=Oq;var e2=X2,_Q=bY,NL=Y2;var VL=Q2,l8=Lq;var BJ=gY;var BL=_2;var zL=Fq;var zJ=Z2;var qL="~effect/encoding/EncodingError";class o8 extends DY("EncodingError"){[qL]=qL}var OJ=(X)=>typeof X==="string"?YK($K.encode(X)):YK(X),K9=(X)=>{let Y=wL(X),Q=Y.length;if(Q%4!==0)return c(new o8({kind:"Decode",module:"Base64",input:Y,message:`Length must be a multiple of 4, but is ${Q}`}));let J=Y.indexOf("=");if(J!==-1&&(J<Q-2||J===Q-2&&Y[Q-1]!=="="))return c(new o8({kind:"Decode",module:"Base64",input:Y,message:"Found a '=' character, but it is not at the end"}));try{let $=Y.endsWith("==")?2:Y.endsWith("=")?1:0,G=new Uint8Array(3*(Q/4)-$);for(let Z=0,K=0;Z<Q;Z+=4,K+=3){let H=qJ(Y.charCodeAt(Z))<<18|qJ(Y.charCodeAt(Z+1))<<12|qJ(Y.charCodeAt(Z+2))<<6|qJ(Y.charCodeAt(Z+3));G[K]=H>>16,G[K+1]=H>>8&255,G[K+2]=H&255}return m(G)}catch($){return c(new o8({kind:"Decode",module:"Base64",input:Y,message:$ instanceof Error?$.message:"Invalid input"}))}},RL=(X)=>ZX(K9(X),(Y)=>_K.decode(Y)),AL=(X)=>typeof X==="string"?LL($K.encode(X)):LL(X),QK=(X)=>{let Y=wL(X),Q=Y.length;if(Q%4===1)return c(new o8({module:"Base64Url",kind:"Decode",input:Y,message:`Length should be a multiple of 4, but is ${Q}`}));if(!/^[-_A-Z0-9]*?={0,2}$/i.test(Y))return c(new o8({module:"Base64Url",kind:"Decode",input:Y,message:"Invalid input"}));let J=Q%4===2?`${Y}==`:Q%4===3?`${Y}=`:Y;return J=J.replace(/-/g,"+").replace(/_/g,"/"),K9(J)},PL=(X)=>ZX(QK(X),(Y)=>_K.decode(Y)),EL=(X)=>typeof X==="string"?TL($K.encode(X)):TL(X),JK=(X)=>{let Y=new TextEncoder().encode(X);if(Y.length%2!==0)return c(new o8({module:"Hex",kind:"Decode",input:X,message:`Length must be a multiple of 2, but is ${Y.length}`}));try{let Q=Y.length/2,J=new Uint8Array(Q);for(let $=0;$<Q;$++){let G=FL(Y[$*2]),Z=FL(Y[$*2+1]);J[$]=G<<4|Z}return m(J)}catch(Q){return c(new o8({module:"Hex",kind:"Decode",input:X,message:Q instanceof Error?Q.message:"Invalid input"}))}},CL=(X)=>ZX(JK(X),(Y)=>_K.decode(Y)),$K=new TextEncoder,_K=new TextDecoder,wL=(X)=>X.replace(/[\n\r]/g,""),YK=(X)=>{let Y=X.length,Q="",J;for(J=2;J<Y;J+=3)Q+=Z8[X[J-2]>>2],Q+=Z8[(X[J-2]&3)<<4|X[J-1]>>4],Q+=Z8[(X[J-1]&15)<<2|X[J]>>6],Q+=Z8[X[J]&63];if(J===Y+1)Q+=Z8[X[J-2]>>2],Q+=Z8[(X[J-2]&3)<<4],Q+="==";if(J===Y)Q+=Z8[X[J-2]>>2],Q+=Z8[(X[J-2]&3)<<4|X[J-1]>>4],Q+=Z8[(X[J-1]&15)<<2],Q+="=";return Q};function qJ(X){if(X>=OL.length)throw TypeError(`Invalid character ${String.fromCharCode(X)}`);let Y=OL[X];if(Y===255)throw TypeError(`Invalid character ${String.fromCharCode(X)}`);return Y}var Z8=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","0","1","2","3","4","5","6","7","8","9","+","/"],OL=[255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,62,255,255,255,63,52,53,54,55,56,57,58,59,60,61,255,255,255,0,255,255,255,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,255,255,255,255,255,255,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51],LL=(X)=>YK(X).replace(/=/g,"").replace(/\+/g,"-").replace(/\//g,"_"),TL=(X)=>{let Y="";for(let Q=0;Q<X.length;++Q)Y+=bd[X[Q]];return Y},FL=(X)=>{if(48<=X&&X<=57)return X-48;if(97<=X&&X<=102)return X-97+10;if(65<=X&&X<=70)return X-65+10;throw TypeError("Invalid input")},bd=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];function K8(X){return X.checks?X.checks[X.checks.length-1].annotations:X.annotations}function GQ(X){return(Y)=>K8(Y)?.[X]}var XX="~structural",ZQ="~identifier",KQ="~sentinels",jL=["title","description","default","examples","readOnly","writeOnly","format","contentEncoding","contentMediaType","contentSchema"],i8=GQ("identifier"),LJ=GQ(ZQ),GK=GQ("title");var IL=GQ("brands"),TJ=X1((X)=>{let Y=i8(X);if(typeof Y==="string")return Y;return X.getExpected(TJ)});var xL=new Set([KQ,XX,"representation","arbitrary","brands","toJsonSchema","toCode","toArbitrary","toEquivalence","toFormatter","toCodec","toCodecJson","toCodecStringTree","toCodecIso"]);var e4=new WeakMap,vL=(X)=>{if(e4.has(X))return e4.get(X);else throw Error("Unable to get redacted value"+(X.label?` with label: "${X.label}"`:""))};var SL="~effect/data/Redacted",ZK=(X)=>j(X,SL),P6=(X,Y)=>{let Q=Object.create(yd);if(Y?.label)Q.label=Y.label;return e4.set(Q,X),Q},yd={[SL]:{_A:(X)=>X},label:void 0,...f6,toJSON(){return this.toString()},toString(){return`<redacted${bX(this.label)?":"+this.label:""}>`},[D0](){return X0(e4.get(this))},[N0](X){return ZK(X)&&o(e4.get(this),e4.get(X))}},H9=vL;var kL=(X)=>D1((Y,Q)=>X(H9(Y),H9(Q)));var WQ="~effect/SchemaIssue/Issue";function WK(X){return j(X,WQ)&&X[WQ]===WQ}class CX{[WQ]=WQ;toString(){return md(this)}}class RJ extends CX{_tag="Filter";actual;filter;issue;constructor(X,Y,Q){super();this.actual=X,this.filter=Y,this.issue=Q}}class UK extends CX{_tag="Encoding";ast;actual;issue;constructor(X,Y,Q){super();this.ast=X,this.actual=Y,this.issue=Q}}class v0 extends CX{_tag="Pointer";path;issue;constructor(X,Y){super();this.path=X,this.issue=Y}}class DQ extends CX{_tag="MissingKey";annotations;constructor(X){super();this.annotations=X}}class AJ extends CX{_tag="UnexpectedKey";ast;actual;constructor(X,Y){super();this.ast=X,this.actual=Y}}class F0 extends CX{_tag="Composite";ast;actual;issues;constructor(X,Y,Q){super();this.ast=X,this.actual=Y,this.issues=Q}}class r0 extends CX{_tag="InvalidType";ast;actual;constructor(X,Y){super();this.ast=X,this.actual=Y}}class U0 extends CX{_tag="InvalidValue";actual;annotations;constructor(X,Y){super();this.actual=X,this.annotations=Y}}class W9 extends CX{_tag="Forbidden";actual;annotations;constructor(X,Y){super();this.actual=X,this.annotations=Y}}class PJ extends CX{_tag="AnyOf";ast;actual;issues;constructor(X,Y,Q){super();this.ast=X,this.actual=Y,this.issues=Q}}class DK extends CX{_tag="OneOf";ast;actual;successes;constructor(X,Y,Q){super();this.ast=X,this.actual=Y,this.successes=Q}}function KK(X,Y){if(WK(Y))return Y;if(typeof Y==="string")return new U0(T(X),{message:Y});let Q=typeof Y.issue==="string"?new U0(T(X),{message:Y.issue}):Y.issue;return new v0(Y.path,Q)}function yL(X,Y){if(Y===void 0)return;if(typeof Y==="boolean")return Y?void 0:new U0(T(X));return KK(X,Y)}function hL(X,Y,Q){if(Array.isArray(Q)){if(S8(Q)){if(Q.length===1)return KK(X,Q[0]);return new F0(Y,T(X),B6(Q,(J)=>KK(X,J)))}return}return yL(X,Q)}var mL=(X)=>{let Y=UQ(X);if(Y!==void 0)return Y;switch(X._tag){case"InvalidType":return HK(TJ(X.ast),gL(X.actual));case"InvalidValue":return`Invalid data ${gL(X.actual)}`;case"MissingKey":return"Missing key";case"UnexpectedKey":return`Unexpected key with value ${P(X.actual)}`;case"Forbidden":return"Forbidden operation";case"OneOf":return`Expected exactly one member to match the input ${P(X.actual)}`}},fL=(X)=>{return UQ(X.issue)??UQ(X)};function pL(X){return(Y)=>({issues:X5(Y,[],X?.leafHook??mL,X?.checkHook??fL)})}function HK(X,Y){return`Expected ${X}, got ${Y}`}function X5(X,Y,Q,J){switch(X._tag){case"Filter":{let $=J(X);if($!==void 0)return[{path:Y,message:$}];switch(X.issue._tag){case"InvalidValue":return[{path:Y,message:HK(dL(X.filter),P(X.actual))}];default:return X5(X.issue,Y,Q,J)}}case"Encoding":return X5(X.issue,Y,Q,J);case"Pointer":return X5(X.issue,[...Y,...X.path],Q,J);case"Composite":return X.issues.flatMap(($)=>X5($,Y,Q,J));case"AnyOf":{let $=UQ(X);if(X.issues.length===0){if($!==void 0)return[{path:Y,message:$}];let G=HK(TJ(X.ast),P(X.actual));return[{path:Y,message:G}]}return X.issues.flatMap((G)=>X5(G,Y,Q,J))}default:return[{path:Y,message:Q(X)}]}}function dL(X){let Y=X.annotations?.expected;if(typeof Y==="string")return Y;switch(X._tag){case"Filter":return"<filter>";case"FilterGroup":return X.checks.map((Q)=>dL(Q)).join(" & ")}}function hd(){return(X)=>X5(X,[],mL,fL).map(fd).join(`
`)}var md=hd();function fd(X){let Y=X.message;if(X.path&&X.path.length>0){let Q=k7(X.path);Y+=`
  at ${Q}`}return Y}function UQ(X){switch(X._tag){case"InvalidType":case"OneOf":case"Composite":case"AnyOf":return HQ(X.ast.annotations);case"InvalidValue":case"Forbidden":return HQ(X.annotations);case"MissingKey":return HQ(X.annotations,"messageMissingKey");case"UnexpectedKey":return HQ(X.ast.annotations,"messageUnexpectedKey");case"Filter":return HQ(X.filter.annotations);case"Encoding":return UQ(X.issue)}}function HQ(X,Y="message"){let Q=X?.[Y];if(typeof Q==="string")return Q}function gL(X){if(P0(X))return"no value provided";return P(X.value)}function FJ(X){switch(X._tag){case"MissingKey":return X;case"Forbidden":return new W9(i6(X.actual,P6),X.annotations);case"Filter":return new RJ(P6(X.actual),X.filter,FJ(X.issue));case"Pointer":return new v0(X.path,FJ(X.issue));case"Encoding":case"InvalidType":case"InvalidValue":case"Composite":return new U0(i6(X.actual,P6));case"AnyOf":case"OneOf":case"UnexpectedKey":return new U0(T(P6(X.actual)))}}function EJ(X){let Y;for(let Q of X.reasons){if(!u3(Q)||!WK(Q.error))return;Y??=Q.error}return Y}function H8(X,Y){let Q=EJ(X);if(Q===void 0)throw Error(Y,{cause:X});return Q}class W8 extends L4{run;constructor(X){super();this.run=X}map(X){return new W8((Y,Q)=>this.run(Y,Q).pipe(r4(i6(X))))}compose(X){if(cL(this))return X;if(cL(X))return this;return new W8((Y,Q)=>this.run(Y,Q).pipe(EX((J)=>X.run(J,Q))))}}function pd(X){return new W8((Y)=>f(X(Y)))}function NK(X){return pd((Y)=>new W9(Y,{message:X(Y)}))}var lL=new W8(d);function cL(X){return X.run===lL.run}function uX(){return lL}function VK(X){return new W8((Y,Q)=>P0(Y)?pX:X(Y.value,Q))}function Q0(X){return CJ(i6(X))}function YX(X){return VK((Y,Q)=>X(Y,Q).pipe(r4(T)))}function CJ(X){return new W8((Y)=>d(X(Y)))}function BK(){return new W8(()=>pX)}function NQ(X){return new W8((Y)=>{let Q=k5(Y,B1);return N1(Q)?d(Q):r4(X,T)})}function Y5(){return Q0(globalThis.String)}function wJ(){return Q0(globalThis.Number)}function oL(){return Q0(globalThis.BigInt)}function zK(){return Q0((X)=>new globalThis.Date(X))}function iL(){return Q0(Cq)}function rL(X){return VK((Y)=>J9({try:()=>T(JSON.parse(Y,X?.reviver)),catch:(Q)=>new U0(T(Y),{message:globalThis.String(Q)})}))}function nL(X){return VK((Y)=>J9({try:()=>{let Q=JSON.stringify(Y,X?.replacer,X?.space);if(Q===void 0)throw TypeError("Value cannot be represented as JSON");return T(Q)},catch:(Q)=>new U0(T(Y),{message:globalThis.String(Q)})}))}function qK(){return Q0(OJ)}function MJ(){return Q0(AL)}function jJ(){return Q0(EL)}function sL(){return YX((X)=>$9(T2(K9(X)),(Y)=>new U0(T(X),{message:Y.message})))}function aL(){return YX((X)=>r1(RL(X),{onFailure:(Y)=>f(new U0(T(X),{message:Y.message})),onSuccess:d}))}function tL(){return YX((X)=>r1(QK(X),{onFailure:(Y)=>f(new U0(T(X),{message:Y.message})),onSuccess:d}))}function eL(){return YX((X)=>r1(PL(X),{onFailure:(Y)=>f(new U0(T(X),{message:Y.message})),onSuccess:d}))}function XT(){return YX((X)=>r1(JK(X),{onFailure:(Y)=>f(new U0(T(X),{message:Y.message})),onSuccess:d}))}function YT(){return YX((X)=>r1(CL(X),{onFailure:(Y)=>f(new U0(T(X),{message:Y.message})),onSuccess:d}))}function QT(){return Q0(encodeURIComponent)}function JT(){return YX((X)=>{try{return d(globalThis.decodeURIComponent(X))}catch(Y){return f(new U0(T(X),{message:Y instanceof URIError?Y.message:"Invalid URI component"}))}})}function OK(){return YX((X)=>{return gX(NJ(X),{onNone:()=>f(new U0(T(X),{message:"Invalid DateTime input"})),onSome:(Y)=>d(VJ(Y))})})}function $T(){return Q0((X)=>KT(Array.from(X.entries())))}var dd=HT((X)=>typeof X==="string"||typeof Blob<"u"&&X instanceof Blob);function _T(){return Q0((X)=>{let Y=new FormData;if(typeof X==="object"&&X!==null)dd(X).forEach(([J,$])=>{Y.append(J,$)});return Y})}function GT(){return Q0((X)=>KT(Array.from(X.entries())))}var ud=HT(bX);function ZT(){return Q0((X)=>{if(typeof X==="object"&&X!==null)return new URLSearchParams(ud(X));return new URLSearchParams})}var cd=/^\d+$/;function ld(X){if(X==="")return[""];let Y=X.replace(/\[(.*?)\]/g,".$1"),Q=Y.split("."),J=Y.startsWith(".")?1:0;return Q.slice(J).map(($)=>cd.test($)?globalThis.Number($):$)}function KT(X){let Y={},Q=new WeakSet;function J($,G,Z){let K=Object.hasOwn($,G)?$[G]:void 0;if(Q.has(K)&&Array.isArray(K)===Z)return K;let H=Z?[]:{};return Q.add(H),k($,G,H),H}return X.forEach(([$,G])=>{let Z=ld($),K=Y;Z.forEach((H,W)=>{let D=W===Z.length-1;if(Array.isArray(K)&&H==="")if(D)K.push(G);else{let U=Z[W+1],N=typeof U==="number"||U==="",V=K.length;K=J(K,V,N)}else if(D){let U=Object.hasOwn(K,H);if(U&&Array.isArray(K[H]))K[H].push(G);else if(U)k(K,H,[K[H],G]);else k(K,H,G)}else{let U=Z[W+1];K=J(K,H,typeof U==="number"||U==="")}})}),Y}function HT(X){return(Y)=>{let Q=[];function J($,G){if(X(G))Q.push([$,G]);else if(Array.isArray(G))if(G.every(X))G.forEach((K)=>{Q.push([$,K])});else G.forEach((K,H)=>{J(`${$}[${H}]`,K)});else if(typeof G==="object"&&G!==null)for(let[Z,K]of Object.entries(G))J(`${$}[${Z}]`,K)}for(let[$,G]of Object.entries(Y))J($,G);return Q}}class BQ{_tag="Middleware";decode;encode;constructor(X,Y){this.decode=X,this.encode=Y}flip(){return new BQ(this.encode,this.decode)}}var VQ="~effect/SchemaTransformation/Transformation";class q0{[VQ]=VQ;_tag="Transformation";decode;encode;constructor(X,Y){this.decode=X,this.encode=Y}flip(){return new q0(this.encode,this.decode)}compose(X){return new q0(this.decode.compose(X.decode),X.encode.compose(this.encode))}}function od(X){return j(X,VQ)&&X[VQ]===VQ}var IJ=(X)=>{if(od(X))return X;return new q0(X.decode,X.encode)};function wX(X){return new q0(YX(X.decode),YX(X.encode))}function p0(X){return new q0(Q0(X.decode),Q0(X.encode))}function xJ(X){return new q0(CJ(X.decode),CJ(X.encode))}function WT(){return new q0(iL(),uX())}var id=new q0(uX(),uX());function D9(){return id}var N9=new q0(wJ(),Y5()),vJ=new q0(oL(),Y5()),TK=new q0(zK(),Q0(YG)),UT=new q0(zK(),Q0((X)=>X.getTime())),DT=wX({decode:(X)=>gX(kN(X),{onNone:()=>f(new U0(T(X),{message:`Invalid Duration string: ${X}`})),onSome:d}),encode:(X)=>d(globalThis.String(X))}),NT=wX({decode:(X)=>d(N6(X)),encode:(X)=>gX(bN(X),{onNone:()=>f(new U0(T(X),{message:`Unable to encode ${X} into a bigint`})),onSome:(Y)=>d(Y)})}),VT=p0({decode:(X)=>j8(X),encode:(X)=>I8(X)}),rd=(X)=>x1(X)&&typeof X.message==="string",BT=(X)=>{let Q=Object.hasOwn(X,"cause")?Error(X.message,{cause:qT(X.cause)}):Error(X.message);if(typeof X.name==="string"&&X.name!=="Error")Q.name=X.name;if(typeof X.stack==="string")Q.stack=X.stack;return Q},nd=(X)=>{try{let Y=F4(X);return Y===void 0?P(X):JSON.parse(Y)}catch{return P(X)}},sd=(X,Y,Q)=>{let J={name:X.name,message:typeof X.message==="string"?X.message:""};if(Y?.includeStack&&typeof X.stack==="string")J.stack=X.stack;if(!Y?.excludeCause&&X.cause!==void 0)J.cause=Q(X.cause);return J},zT=(X)=>{let Y=new WeakSet,Q=(J)=>{if(tD(J)){if(Y.has(J))return"[Circular]";Y.add(J);let $=sd(J,X,Q);return Y.delete(J),$}return nd(J)};return Q},qT=(X)=>rd(X)?BT(X):X,OT=(X)=>p0({decode:BT,encode:(Y)=>zT(X)(Y)}),LT=(X)=>p0({decode:qT,encode:zT(X)});function TT(){return p0({decode:wN,encode:WG})}function FT(){return p0({decode:CN,encode:M4})}function RT(X){return p0({decode:EN,encode:X?.onNoneEncoding===null?WG:M4})}function AT(){return xJ({decode:T,encode:S5})}function PT(){return xJ({decode:(X)=>X.pipe(k5(B1),T),encode:S5})}var FK=wX({decode:(X)=>URL.canParse(X)?d(new URL(X)):f(new U0(T(X),{message:`Invalid URL string: ${X}`})),encode:(X)=>d(X.href)}),RK=wX({decode:(X)=>{let Y=tO(X);return P0(Y)?f(new U0(T(X),{message:`Invalid BigDecimal string: ${X}`})):d(Y.value)},encode:(X)=>d(A6(X))}),AK=new q0(sL(),qK()),ET=new q0(aL(),qK()),CT=new q0(eL(),MJ()),wT=new q0(YT(),jJ()),MT=new q0(JT(),QT()),jT=new q0(rL(),nL()),IT=new q0($T(),_T()),xT=new q0(GT(),ZT()),vT=p0({decode:(X)=>_Q(X),encode:(X)=>X.offset}),PK=wX({decode:(X)=>{return gX(NL(X),{onNone:()=>f(new U0(T(X),{message:`Invalid IANA time zone: ${X}`})),onSome:d})},encode:(X)=>d(X.id)}),EK=wX({decode:(X)=>{return gX(VL(X),{onNone:()=>f(new U0(T(X),{message:`Invalid time zone: ${X}`})),onSome:d})},encode:(X)=>d(l8(X))}),CK=wX({decode:(X)=>{return gX(NJ(X),{onNone:()=>f(new U0(T(X),{message:`Invalid UTC DateTime string: ${X}`})),onSome:(Y)=>d(VJ(Y))})},encode:(X)=>d(zL(X))}),wK=wX({decode:(X)=>{return gX(DL(X),{onNone:()=>f(new U0(T(X),{message:`Invalid Zoned DateTime string: ${X}`})),onSome:d})},encode:(X)=>d(zJ(X))});function J5(X){return(Y)=>Y._tag===X}var $5=J5("Declaration");var ad=J5("Never");var SJ=J5("Literal"),td=J5("UniqueSymbol");var qQ=J5("Arrays"),SK=J5("Objects"),OQ=J5("Union");class d0{to;transformation;constructor(X,Y){this.to=X,this.transformation=Y}}var _5={};class lX{isOptional;isMutable;defaultValue;annotations;constructor(X,Y,Q=void 0,J=void 0){this.isOptional=X,this.isMutable=Y,this.defaultValue=Q,this.annotations=J}}var kT="~effect/Schema";class n0{[kT]=kT;annotations;checks;encoding;context;constructor(X=void 0,Y=void 0,Q=void 0,J=void 0){this.annotations=X,this.checks=Y,this.encoding=Q,this.context=J}toString(){return`<${this._tag}>`}}class G5 extends n0{_tag="Declaration";typeParameters;run;encodingChecks;constructor(X,Y,Q,J,$,G,Z){super(Q,J,$,G);this.typeParameters=X,this.run=Y,this.encodingChecks=Z}getParser(){let X=this.run(this.typeParameters);return(Y,Q)=>{if(P0(Y))return pX;return r4(X(Y.value,this,Q),T)}}_rebuild(X,Y,Q){let J=V9(this.typeParameters,X);return J===this.typeParameters&&Y===this.checks&&Q===this.encodingChecks?this:new G5(J,this.run,this.annotations,Y,void 0,this.context,Q)}recur(X){return this._rebuild(X,this.checks,this.encodingChecks)}flip(X){return this._rebuild(X,this.encodingChecks,this.checks)}getExpected(){let X=this.annotations?.expected;if(typeof X==="string")return X;return"<Declaration>"}}class pT extends n0{_tag="Null";getParser(){return rJ(this,null)}getExpected(){return"null"}}var kK=new pT;class dT extends n0{_tag="Undefined";getParser(){return rJ(this,void 0)}toCodecJson(){return R0(this,[uT])}getExpected(){return"undefined"}}var uT=new d0(kK,new q0(Q0(()=>{return}),Q0(()=>null))),cT=new dT;class lT extends n0{_tag="Void";getParser(){return Uu(void 0)}toCodecJson(){return R0(this,[uT])}getExpected(){return"void"}}var oT=new lT;class iT extends n0{_tag="Never";getParser(){return rX(this,aD)}getExpected(){return"never"}}var rT=new iT;class nT extends n0{_tag="Any";getParser(){return rX(this,c_)}getExpected(){return"any"}}var sT=new nT;class aT extends n0{_tag="Unknown";getParser(){return rX(this,c_)}getExpected(){return"unknown"}}var Q5=new aT;class tT extends n0{_tag="ObjectKeyword";getParser(){return rX(this,l_)}getExpected(){return"object | array | function"}}var eT=new tT;class bK extends n0{_tag="Enum";enums;constructor(X,Y,Q,J,$){super(Y,Q,J,$);this.enums=X}getParser(){let X=new Set(this.enums.map(([,Y])=>Y));return rX(this,(Y)=>X.has(Y))}toCodecStringTree(){if(this.enums.some(([X,Y])=>typeof Y==="number")){let X=Object.fromEntries(this.enums.map(([Y,Q])=>[globalThis.String(Q),Q]));return R0(this,[new d0(new QX(Object.keys(X).map((Y)=>new DX(Y)),"anyOf"),new q0(Q0((Y)=>X[Y]),Y5()))])}return this}getExpected(){return this.enums.map(([X,Y])=>JSON.stringify(Y)).join(" | ")}}function XF(X){switch(X._tag){case"String":case"Number":case"BigInt":return!0;case"Literal":case"TemplateLiteral":return X.checks===void 0;case"Union":return X.checks===void 0&&X.types.every(XF);default:return!1}}class gK extends n0{_tag="TemplateLiteral";parts;encodedParts;constructor(X,Y,Q,J,$){super(Y,Q,J,$);let G=[];for(let Z of X){let K=F1(Z);if(XF(K))G.push(K);else throw Error(`Invalid TemplateLiteral part ${K._tag}`)}this.parts=X,this.encodedParts=G}getParser(X){let Y=X(this.asTemplateLiteralParser());return(Q,J)=>V1(Y(Q,J),{onSuccess:()=>Q,onFailure:($)=>new F0(this,Q,[$])})}getExpected(){return"string"}matchPart(X,Y){return fT(this.encodedParts,X,Y)===void 0?void 0:X}asTemplateLiteralParser(){let X=new oX(!1,this.parts.map(AF),[]);return iJ(n8,X,new q0(YX((Y,Q)=>{let J=fT(this.encodedParts,Y,Q);if(J!==void 0)return d(J);return f(new U0(T(Y),{message:`Expected a string matching template literal parts, got ${P(Y)}`}))}),Q0((Y)=>Y.join(""))))}}class yK extends n0{_tag="UniqueSymbol";symbol;constructor(X,Y,Q,J,$){super(Y,Q,J,$);this.symbol=X}getParser(){return rJ(this,this.symbol)}toCodecStringTree(){return R0(this,[CF])}getExpected(){return globalThis.String(this.symbol)}}class DX extends n0{_tag="Literal";literal;constructor(X,Y,Q,J,$){super(Y,Q,J,$);if(typeof X==="number"&&!globalThis.Number.isFinite(X))throw Error(`A numeric literal must be finite, got ${P(X)}`);this.literal=X}getParser(){return rJ(this,this.literal)}matchPart(X,Y){return X===globalThis.String(this.literal)?this.literal:void 0}toCodecJson(){return typeof this.literal==="bigint"?bT(this):this}toCodecStringTree(){return typeof this.literal==="string"?this:bT(this)}getExpected(){return typeof this.literal==="string"?JSON.stringify(this.literal):globalThis.String(this.literal)}}function bT(X){let Y=globalThis.String(X.literal);return R0(X,[new d0(new DX(Y),new q0(Q0(()=>X.literal),Q0(()=>Y)))])}class YF extends n0{_tag="String";getParser(){return rX(this,bX)}matchPart(X,Y){return nJ(this,X,Y)}getExpected(){return"string"}}var n8=new YF;class QF extends n0{_tag="Number";getParser(){return rX(this,t9)}matchKey(X,Y){return this._match(Du,X,Y)}matchPart(X,Y){return this._match(IK,X,Y)}_match(X,Y,Q){return X.test(Y)?nJ(this,globalThis.Number(Y),Q):void 0}toCodecJson(){if(this.checks&&(MK(this.checks,"effect/schema/isFinite")||MK(this.checks,"effect/schema/isInt")))return this;return R0(this,[ed(this.checks)])}toCodecStringTree(){if(this.toCodecJson()===this)return R0(this,[Nu]);return R0(this,[Vu])}getExpected(){return"number"}}function MK(X,Y){return X.some((Q)=>Q.annotations?.representation?.id===Y||Q._tag==="FilterGroup"&&MK(Q.checks,Y))}function ed(X){let Y=X===void 0?bJ:iX(bJ,X);return new d0(new QX([Y,DF],"anyOf"),new q0(wJ(),Q0((Q)=>globalThis.Number.isFinite(Q)?Q:globalThis.String(Q))))}var hK=new QF;class JF extends n0{_tag="Boolean";getParser(){return rX(this,rD)}getExpected(){return"boolean"}}var $F=new JF;class _F extends n0{_tag="Symbol";getParser(){return rX(this,u_)}matchKey(X,Y){return nJ(this,X,Y)}toCodecStringTree(){return R0(this,[CF])}getExpected(){return"symbol"}}var GF=new _F;class ZF extends n0{_tag="BigInt";getParser(){return rX(this,nD)}matchPart(X,Y){return xK.test(X)?nJ(this,globalThis.BigInt(X),Y):void 0}toCodecStringTree(){return R0(this,[zu])}getExpected(){return"bigint"}}var KF=new ZF;class oX extends n0{_tag="Arrays";isMutable;elements;rest;encodingChecks;constructor(X,Y,Q,J,$,G,Z,K){super(J,$,G,Z);this.isMutable=X,this.elements=Y,this.rest=Q,this.encodingChecks=K;let H=Y.findIndex(l0);if(H!==-1&&(Y.slice(H+1).some((W)=>!l0(W))||Q.length>1))throw Error("A required element cannot follow an optional element. ts(1257)");if(Q.length>1&&Q.slice(1).some(l0))throw Error("An optional element cannot follow a rest element. ts(1266)")}getParser(X){let Y=this,Q=Y.elements.map((W)=>({ast:W,parser:X(W)})),J=Y.rest.map((W)=>({ast:W,parser:X(W)})),$=Q.length,[G,...Z]=J,K=Z.length;function H(W,D){if(D<$)return Q[D];else if(D>=W)return Z[D-W];return G}return oY(function*(W,D){if(W._tag==="None")return W;let U=W.value;if(!Array.isArray(U))return yield*f(new r0(Y,W));let N=U.length,V={ast:Y,getParser:H,oinput:W,len:N,tailThreshold:Yu(N,$,K),output:new globalThis.Array(N),issues:void 0,options:D},z=mK(D?.concurrency),q=Xu(V,U,{concurrency:z?.concurrency,end:Y.rest.length===0?$:Math.max(N,$+K)});if(q)yield*q;if(Y.rest.length===0&&N>$)for(let F=$;F<=N-1;F++){let R=new v0([F],new AJ(Y,U[F]));if(D.errors==="all")if(V.issues)V.issues.push(R);else V.issues=[R];else return yield*f(new F0(Y,W,[R]))}if(V.issues)return yield*f(new F0(Y,W,V.issues));return T(V.output)})}_rebuild(X,Y,Q){let J=V9(this.elements,X),$=V9(this.rest,X);return J===this.elements&&$===this.rest&&Y===this.checks&&Q===this.encodingChecks?this:new oX(this.isMutable,J,$,this.annotations,Y,void 0,this.context,Q)}recur(X){return this._rebuild(X,this.checks,this.encodingChecks)}flip(X){return this._rebuild(X,this.encodingChecks,this.checks)}getExpected(){return"array"}}var Xu=jY()({onItem(X,Y,Q){let J=Q<X.len?T(Y):p();return X.getParser(X.tailThreshold,Q).parser(J,X.options)},step(X,Y,Q,J){if(Q._tag==="Failure")return kJ(X,X.ast,J,Q);else if(Q.value._tag==="Some")X.output[J]=Q.value.value;else{let $=X.getParser(X.tailThreshold,J);if(l0($.ast))return;let G=new v0([J],new DQ($.ast.context?.annotations));if(X.options.errors==="all")if(X.issues)X.issues.push(G);else X.issues=[G];else return IY(new F0(X.ast,X.oinput,[G]))}}});function Yu(X,Y,Q){return Math.max(Y,X-Q)}var mK=(X)=>{return X=X==="unbounded"?1/0:X??1,X>1?{concurrency:X}:void 0},kJ=(X,Y,Q,J)=>{if(J.cause.reasons.length===0)return J;let $=EJ(J.cause);if($===void 0)return h8(J8(J.cause,(Z)=>new F0(Y,X.oinput,[new v0([Q],Z)])));let G=new v0([Q],$);if(X.options.errors==="all")if(X.issues)X.issues.push(G);else X.issues=[G];else return IY(new F0(Y,X.oinput,[G]))},gJ="[+-]?\\d*\\.?\\d+(?:[Ee][+-]?\\d+)?";function z9(X,Y,Q=_5){let J,$;function G(Z){switch(Z._tag){case"String":case"TemplateLiteral":return(J??=Object.keys(X)).filter((K)=>Z.matchPart(K,Q)!==void 0);case"Number":return(J??=Object.keys(X)).filter((K)=>Z.matchKey(K,Q)!==void 0);case"Symbol":return($??=Object.getOwnPropertySymbols(X)).filter((K)=>Z.matchKey(K,Q)!==void 0);case"Union":return[...new Set(Z.types.flatMap(G))];default:return[]}}return G(oK(F1(Y)))}class yJ{name;type;constructor(X,Y){this.name=X,this.type=Y}}class hJ{decode;encode;constructor(X,Y){this.decode=X,this.encode=Y}flip(){return new hJ(this.encode,this.decode)}}function jK(X){switch(X._tag){case"String":case"Number":case"Symbol":case"TemplateLiteral":return!0;case"Union":return X.types.every(jK);default:return!1}}function Qu(X){return jK(X)&&jK(F1(X))}class mJ{parameter;type;merge;constructor(X,Y,Q){if(!Qu(X))throw Error(`Invalid index signature parameter ${X._tag}`);if(this.parameter=X,this.type=Y,this.merge=Q,l0(Y)&&!FF(Y))throw Error("Cannot use `Schema.optionalKey` with index signatures, use `Schema.optional` instead.")}}class q9 extends n0{_tag="Objects";propertySignatures;indexSignatures;encodingChecks;constructor(X,Y,Q,J,$,G,Z){super(Q,J,$,G);this.propertySignatures=X,this.indexSignatures=Y,this.encodingChecks=Z;let K=X.map((H)=>H.name).filter((H,W,D)=>D.indexOf(H)!==W);if(K.length>0)throw Error(`Duplicate identifiers: ${JSON.stringify(K)}. ts(2300)`)}getParser(X){let Y=this,Q=[],J=new Set,$=[];for(let K of Y.propertySignatures)Q.push(K.name),J.add(K.name),$.push({ps:K,parser:X(K.type),name:K.name,type:K.type});let G=Y.indexSignatures.length;if(Y.propertySignatures.length===0&&Y.indexSignatures.length===0)return rX(Y,w7);let Z=G>0?jY()({onItem:oY(function*(K,[H,W]){let U=X(oK(W.parameter))(T(H),K.options),N=w1(U)?U:yield*lY(U);if(N._tag==="Failure"){let R=kJ(K,Y,H,N);if(R)yield*R;return}let V=T(K.input[H]),q=X(W.type)(V,K.options),F=w1(q)?q:yield*lY(q);if(F._tag==="Failure"){let R=kJ(K,Y,H,F);if(R)yield*R;return}else if(N.value._tag==="Some"&&F.value._tag==="Some"){let R=N.value.value;if(J.has(H)||J.has(R))return;let C=F.value.value;if(W.merge&&W.merge.decode&&Object.hasOwn(K.out,R)){let[w,a]=W.merge.decode.combine([R,K.out[R]],[R,C]);k(K.out,w,a)}else k(K.out,R,C)}}),step:(K,H,W)=>W._tag==="Failure"?W:void 0}):void 0;return oY(function*(K,H){if(K._tag==="None")return K;let W=K.value;if(!(typeof W==="object"&&W!==null&&!Array.isArray(W)))return yield*f(new r0(Y,K));let D={},U={ast:Y,oinput:K,input:W,out:D,issues:void 0,options:H},N=H.errors==="all",V=H.onExcessProperty==="error",z=H.onExcessProperty==="preserve",q;if(Y.indexSignatures.length===0&&(V||z)){q=Reflect.ownKeys(W);for(let C=0;C<q.length;C++){let w=q[C];if(!J.has(w))if(V){let a=new v0([w],new AJ(Y,W[w]));if(N){if(U.issues)U.issues.push(a);else U.issues=[a];continue}else return yield*f(new F0(Y,K,[a]))}else k(D,w,W[w])}}let F=mK(H?.concurrency),R=Ju(U,$,F);if(R)yield*R;if(Z){let C=Z3();for(let a=0;a<G;a++){let O=Y.indexSignatures[a],E=z9(W,O.parameter,H);for(let A=0;A<E.length;A++){let x=E[A];C.push([x,O])}}let w=Z(U,C,F);if(w)yield*w}if(U.issues)return yield*f(new F0(Y,K,U.issues));if(H.propertyOrder==="original"){let C=(q??Reflect.ownKeys(W)).concat(Q),w={};for(let a of C)if(Object.hasOwn(D,a))k(w,a,D[a]);return T(w)}return T(D)})}_rebuild(X,Y,Q,J,$){let G=V9(this.propertySignatures,(K)=>{let H=X(K.type);return H===K.type?K:new yJ(K.name,H)}),Z=V9(this.indexSignatures,(K)=>{let H=Y(K.parameter),W=X(K.type),D=Q?K.merge?.flip():K.merge;return H===K.parameter&&W===K.type&&D===K.merge?K:new mJ(H,W,D)});return G===this.propertySignatures&&Z===this.indexSignatures&&J===this.checks&&$===this.encodingChecks?this:new q9(G,Z,this.annotations,J,void 0,this.context,$)}flip(X){return this._rebuild(X,X,!0,this.encodingChecks,this.checks)}recur(X,Y=X){return this._rebuild(X,Y,!1,this.checks,this.encodingChecks)}getExpected(){if(this.propertySignatures.length===0&&this.indexSignatures.length===0)return"object | array";return"object"}}var Ju=jY()({onItem(X,Y){let Q=Object.hasOwn(X.input,Y.name)?T(X.input[Y.name]):p();return Y.parser(Q,X.options)},step(X,Y,Q){if(Q._tag==="Failure")return kJ(X,X.ast,Y.name,Q);else if(Q.value._tag==="Some")k(X.out,Y.name,Q.value.value);else if(!l0(Y.type)){let J=new v0([Y.name],new DQ(Y.type.context?.annotations));if(X.options.errors==="all"){if(X.issues)X.issues.push(J);else X.issues=[J];return}else return IY(new F0(X.ast,X.oinput,[J]))}}});function fK(X,Y){if(!X)return Y;if(!Y)return X;return[...X,...Y]}function fJ(X,Y,Q){return new q9(Reflect.ownKeys(X).map((J)=>{return new yJ(J,X[J].ast)}),[],Q,Y)}function LQ(X){return X.ast}function pK(X,Y=void 0){return new oX(!1,X.map((Q)=>Q.ast),[],void 0,Y)}function pJ(X,Y,Q){return new QX(X.map(LQ),Y,void 0,Q)}function HF(X,Y){if(X.encoding||Y.some((G)=>G.encoding))throw Error("StructWithRest does not support encodings");let{propertySignatures:Q,indexSignatures:J,checks:$}=X;for(let G of Y)Q=Q.concat(G.propertySignatures),J=J.concat(G.indexSignatures),$=fK($,G.checks);return new q9(Q,J,void 0,$)}function WF(X,Y){if(X.encoding)throw Error("TupleWithRest does not support encodings");return new oX(X.isMutable,X.elements,Y,void 0,X.checks)}function UF(X){switch(X._tag){case"Null":return["null"];case"Undefined":return["undefined"];case"String":case"TemplateLiteral":return["string"];case"Number":return["number"];case"Boolean":return["boolean"];case"Symbol":case"UniqueSymbol":return["symbol"];case"BigInt":return["bigint"];case"Arrays":return["array"];case"ObjectKeyword":return["object","array","function"];case"Objects":return X.propertySignatures.length||X.indexSignatures.length?["object"]:["string","number","boolean","symbol","bigint","object","array","function"];case"Enum":return Array.from(new Set(X.enums.map(([,Y])=>typeof Y)));case"Literal":return[typeof X.literal];case"Union":return Array.from(new Set(X.types.flatMap(UF)));default:return["null","undefined","string","number","boolean","symbol","bigint","object","array","function"]}}function TQ(X){switch(X._tag){default:return[];case"Declaration":{let Y=X.annotations?.[KQ];return Array.isArray(Y)?Y:[]}case"Objects":return X.propertySignatures.flatMap((Y)=>{let Q=Y.type;if(!l0(Q)){if(SJ(Q))return[{key:Y.name,literal:Q.literal}];if(td(Q))return[{key:Y.name,literal:Q.symbol}]}return[]});case"Arrays":return X.elements.flatMap((Y,Q)=>{return SJ(Y)&&!l0(Y)?[{key:Q,literal:Y.literal}]:[]});case"Suspend":return TQ(X.thunk())}}var gT=new WeakMap;function $u(X){let Y=gT.get(X);if(Y)return Y;Y={};for(let Q=0;Q<X.length;Q++){let J=X[Q],$=F1(J);if(ad($))continue;let G=UF($),Z=TQ($);Y.byType??={};for(let K of G)(Y.byType[K]??=[]).push(Q);if(Z.length>0){Y.bySentinel??=new Map;for(let{key:K,literal:H}of Z){let W=Y.bySentinel.get(K);if(!W)Y.bySentinel.set(K,W=new Map);let D=W.get(H);if(!D)W.set(H,D=[]);D.push(Q)}}else{Y.otherwise??={};for(let K of G)(Y.otherwise[K]??=[]).push(Q)}}return gT.set(X,Y),Y}function yT(X){return(Y)=>{let Q=F1(Y);return Q._tag==="Literal"?Q.literal===X:Q._tag==="UniqueSymbol"?Q.symbol===X:!0}}function FQ(X,Y){let Q=$u(Y),J=X===null?"null":Array.isArray(X)?"array":typeof X;if(Q.bySentinel){let $=Q.otherwise?.[J]??[];if(J==="object"||J==="array"){let G=new Set($);for(let[Z,K]of Q.bySentinel)if(Object.hasOwn(X,Z)){let H=K.get(X[Z]);if(H)for(let W of H)G.add(W)}return Array.from(G).sort((Z,K)=>Z-K).map((Z)=>Y[Z]).filter(yT(X))}return $.map((G)=>Y[G])}return(Q.byType?.[J]??[]).map(($)=>Y[$]).filter(yT(X))}class QX extends n0{_tag="Union";types;mode;encodingChecks;constructor(X,Y,Q,J,$,G,Z){super(Q,J,$,G);this.types=X,this.mode=Y,this.encodingChecks=Z}getParser(X){let Y=this;return(Q,J)=>{if(Q._tag==="None")return d(Q);let $=Q.value,G=FQ($,Y.types),Z={ast:Y,recur:X,oinput:Q,input:$,out:void 0,successes:[],issues:void 0,options:J},K=mK(J?.concurrency),H=_u(Z,G,K?{...K,orderedStep:!0}:void 0);if(!H)return Z.out?d(Z.out):f(new PJ(Y,$,Z.issues??[]));return cY(H,(W)=>{return Z.out?d(Z.out):f(new PJ(Y,$,Z.issues??[]))})}}_rebuild(X,Y,Q){let J=V9(this.types,X);return J===this.types&&Y===this.checks&&Q===this.encodingChecks?this:new QX(J,this.mode,this.annotations,Y,void 0,this.context,Q)}recur(X){return this._rebuild(X,this.checks,this.encodingChecks)}flip(X){return this._rebuild(X,this.encodingChecks,this.checks)}matchPart(X,Y){for(let Q of this.types){let J=Q.matchPart(X,Y);if(J!==void 0)return J}return}getExpected(X){let Y=this.annotations?.expected;if(typeof Y==="string")return Y;if(this.types.length===0)return"never";let Q=this.types.map((J)=>{let $=F1(J);switch($._tag){case"Arrays":{let G=$.elements.filter(SJ);if(G.length>0)return`${hT($.isMutable)}[ ${G.map((Z)=>X(Z)+mT(Z.context?.isOptional)).join(", ")}, ... ]`;break}case"Objects":{let G=$.propertySignatures.filter((Z)=>SJ(Z.type));if(G.length>0)return`{ ${G.map((Z)=>`${hT(Z.type.context?.isMutable)}${m6(Z.name)}${mT(Z.type.context?.isOptional)}: ${X(Z.type)}`).join(", ")}, ... }`;break}}return X($)});return Array.from(new Set(Q)).join(" | ")}}var _u=jY()({onItem(X,Y){return X.recur(Y)(X.oinput,X.options)},step(X,Y,Q){if(Q._tag==="Failure"){let J=EJ(Q.cause);if(J===void 0)return Q;if(X.issues)X.issues.push(J);else X.issues=[J]}else{if(X.out&&X.ast.mode==="oneOf")return X.successes.push(Y),IY(new DK(X.ast,X.input,X.successes));if(X.out=Q.value,X.successes.push(Y),X.ast.mode==="anyOf")return kz}}}),DF=new QX([new DX("Infinity"),new DX("-Infinity"),new DX("NaN")],"anyOf");function hT(X){return X?"":"readonly "}function mT(X){return X?"?":""}function Z5(X){let Y=!1,Q;return()=>{if(Y)return Q;return Q=X(),Y=!0,Q}}class dJ extends n0{_tag="Suspend";thunk;constructor(X,Y,Q,J,$){if(Q!==void 0)throw Error("Cannot add checks to Suspend");super(Y,void 0,J,$);this.thunk=Z5(X)}getParser(X){return X(this.thunk())}recur(X){return new dJ(()=>X(this.thunk()),this.annotations,void 0,void 0,this.context)}getExpected(X){return X(this.thunk())}}class zQ extends L4{_tag="Filter";run;annotations;aborted;constructor(X,Y=void 0,Q=!1){super();this.run=X,this.annotations=Y,this.aborted=Q}annotate(X){return new zQ(this.run,{...this.annotations,...X},this.aborted)}abort(){return new zQ(this.run,this.annotations,!0)}and(X,Y){return new r8([this,X],Y)}}class r8 extends L4{_tag="FilterGroup";checks;annotations;constructor(X,Y=void 0){super();this.checks=X,this.annotations=Y}annotate(X){return new r8(this.checks,{...this.annotations,...X})}and(X,Y){return new r8([this,X],Y)}}function uJ(X,Y,Q=!1){return new zQ((J,$,G)=>hL(J,$,X(J,$,G)),Y,Q)}function cJ(X,Y){return new zQ((Q)=>X(Q)?void 0:new U0(T(Q)),Y,!0)}function dK(X){return uJ((Y)=>globalThis.Number.isFinite(Y),{expected:"a finite number",representation:{id:"effect/schema/isFinite",payload:null},toJsonSchema:()=>({type:"number"}),toCode:()=>({runtime:"Schema.isFinite()"}),arbitrary:{constraint:{noInfinity:!0,noNaN:!0}},...X})}var bJ=iX(hK,[dK()]);function RQ(X,Y){let Q=X.source;return uJ((J)=>X.test(J),{expected:`a string matching the RegExp ${Q}`,representation:{id:"effect/schema/isPattern",payload:{source:Q,flags:X.flags}},toJsonSchema:()=>({pattern:Q}),arbitrary:{constraint:{patterns:[X.source]}},...Y})}function AQ(X,Y){let Q=Object.getOwnPropertyDescriptors(X);return Y(Q),Object.create(Object.getPrototypeOf(X),Q)}function R0(X,Y){if(X.encoding===Y)return X;return AQ(X,(Q)=>{Q.encoding.value=Y})}function PQ(X,Y){if(X.context===Y)return X;return AQ(X,(Q)=>{Q.context.value=Y})}function s8(X){return X.encoding?s8(X.encoding[X.encoding.length-1].to):X}function E6(X,Y){if(X.checks){let Q=X.checks[X.checks.length-1];return lJ(X,G3(X.checks.slice(0,-1),Q.annotate(Y)))}return AQ(X,(Q)=>{Q.annotations.value={...Q.annotations.value,...Y}})}function lJ(X,Y){if(X._tag==="Suspend"&&Y!==void 0)throw Error("Cannot add checks to Suspend");if(X.checks===Y)return X;return AQ(X,(Q)=>{Q.checks.value=Y})}function iX(X,Y){return lJ(X,fK(X.checks,Y))}function a8(X,Y){let Q=Y(X.to);return Q===X.to?X:new d0(Q,X.transformation)}function NF(X,Y){let Q=X,J=Q[Q.length-1],$=a8(J,Y);return $===J?X:G3(X.slice(0,X.length-1),$)}function uK(X){return(Y)=>Y.encoding?R0(Y,NF(Y.encoding,X)):Y}function oJ(X,Y){return uK((Q)=>PQ(Q,Y))(X)}function t8(X){function Y(Q){return Q.encoding?R0(Q,NF(Q.encoding,Y)):X(Q)}return X1(Y)}function VF(X,Y){return cK(X,Y,T1(X))}function BF(X,Y){return cK(F1(X),Y,X)}function cK(X,Y,Q){let J=new d0(X,Y);return R0(Q,Q.encoding?[...Q.encoding,J]:[J])}function zF(X,Y){let Q=IL(X),J=Q?[...Q,Y]:[Y];return E6(X,{brands:J})}function V9(X,Y){let Q=!1,J=Array(X.length);for(let $=0;$<X.length;$++){let G=X[$],Z=Y(G);if(Z!==G)Q=!0;J[$]=Z}return Q?J:X}function EQ(X,Y){let Q=X.context?new lX(X.context.isOptional,X.context.isMutable,X.context.defaultValue,{...X.context.annotations,...Y}):new lX(!1,!1,void 0,Y);return PQ(X,Q)}var Gu=uK(CQ);function CQ(X){let Y=X.context?X.context.isOptional===!1?new lX(!0,X.context.isMutable,X.context.defaultValue,X.context.annotations):X.context:new lX(!0,!1);return Gu(PQ(X,Y))}var Zu=uK(lK);function lK(X){let Y=X.context?X.context.isMutable===!1?new lX(X.context.isOptional,!0,X.context.defaultValue,X.context.annotations):X.context:new lX(!1,!0);return Zu(PQ(X,Y))}function qF(X,Y){let Q=new q0(NQ(Y),uX()),J=[new d0(Q5,Q)],$=X.context?new lX(X.context.isOptional,X.context.isMutable,J,X.context.annotations):new lX(!1,!1,J);return PQ(X,$)}function iJ(X,Y,Q){return cK(X,Q,Y)}function Ku(X){let Y=[],Q=[];function J($){switch($._tag){case"Literal":if(C7($.literal))Y.push($.literal);return;case"UniqueSymbol":Y.push($.symbol);return;case"Never":return;case"Union":for(let G=0;G<$.types.length;G++)J($.types[G]);return;default:Q.push($)}}return J(X),{literals:Y,parameters:Q}}function OF(X,Y,Q){let{literals:J,parameters:$}=Ku(X);return new q9(J.map((G)=>new yJ(G,Y)),$.map((G)=>new mJ(G,Y,Q)))}function l0(X){return X.context?.isOptional??!1}function LF(X){return X.context?.isMutable??!1}function TF(X){return X.annotations?.[XX]===!0||X._tag==="FilterGroup"&&X.checks.every(TF)}function Hu(X){function Y(J){if(TF(J))return[J];return J._tag==="FilterGroup"?J.checks.flatMap(Y):[]}let Q=X.flatMap(Y);return V6(Q)?Q:void 0}var T1=X1((X)=>{if(X.encoding)return T1(R0(X,void 0));let Y=X,Q=Y.recur?.(T1)??Y,J=Q.encodingChecks;if(J){let $=Q===X?J:qQ(Q)||SK(Q)||$5(Q)&&Q.typeParameters.length>0?Hu(J):void 0;return AQ(Q,(G)=>{G.encodingChecks.value=void 0,G.checks.value=fK(Q.checks,$)})}return Q}),F1=X1((X)=>{return T1(cX(X))});function Wu(X,Y){let Q=Y,J=Q.length,$=Q[J-1],G=[new d0(cX(R0(X,void 0)),Q[0].transformation.flip())];for(let K=1;K<J;K++)G.unshift(new d0(cX(Q[K-1].to),Q[K].transformation.flip()));let Z=cX($.to);if(Z.encoding)return R0(Z,[...Z.encoding,...G]);else return R0(Z,G)}var cX=X1((X)=>{if(X.encoding)return Wu(X,X.encoding);let Y=X;return Y.flip?.(cX)??Y.recur?.(cX)??Y});function FF(X){switch(X._tag){case"Undefined":return!0;case"Union":return X.types.some(FF);default:return!1}}function rJ(X,Y){let Q=dY(Y);return(J)=>{if(J._tag==="None")return pX;return J.value===Y?Q:f(new r0(X,J))}}function Uu(X){let Y=dY(X);return(Q)=>Q._tag==="None"?pX:Y}function rX(X,Y){return(Q)=>{if(Q._tag==="None")return pX;return Y(Q.value)?d(Q):f(new r0(X,Q))}}function nJ(X,Y,Q){if(Q?.disableChecks||X.checks===void 0)return Y;let J=[];return O9(X.checks,Y,J,X,Q),J.length===0?Y:void 0}function fT(X,Y,Q){let J=X.map((H)=>H._tag==="Literal"?globalThis.String(H.literal):void 0);if(J.some((H)=>H!==void 0&&!Y.includes(H)))return;let $=Array(X.length+1);$[X.length]=0;for(let H=X.length-1;H>=0;H--)$[H]=$[H+1]+(J[H]?.length??0);if($[0]>Y.length)return;let G=Array(X.length),Z=X.map(()=>new Set);function K(H,W){if(H===X.length)return W===Y.length;if(Z[H].has(W))return!1;let D=X[H];if(H===X.length-1){let U=Y.slice(W);if(D.matchPart(U,Q)!==void 0)return G[H]=U,!0}else if(D._tag==="Literal"){let U=J[H];if(Y.startsWith(U,W)&&K(H+1,W+U.length))return G[H]=U,!0}else{let U=Y.length-$[H+1],N=J[H+1],V=N===void 0?U:Y.lastIndexOf(N,U);while(V>=W){let z=Y.slice(W,V);if(D.matchPart(z,Q)!==void 0&&K(H+1,V))return G[H]=z,!0;if(V===0)break;V=N===void 0?V-1:Y.lastIndexOf(N,V-1)}}return Z[H].add(W),!1}return K(0,0)?G:void 0}var RF=X1((X)=>{return new QX(X.enums.map((Y)=>new DX(Y[1],{title:Y[0]})),"anyOf")}),oK=t8((X)=>{switch(X._tag){default:return X;case"Number":return X.toCodecStringTree();case"Union":return X.recur(oK)}}),sJ=t8((X)=>{switch(X._tag){default:return X;case"Symbol":case"UniqueSymbol":return X.toCodecStringTree();case"Union":return X.recur(sJ)}}),AF=t8((X)=>{switch(X._tag){default:return X;case"Number":case"Literal":case"BigInt":return X.toCodecStringTree();case"Union":return X.recur(AF)}}),PF="[\\s\\S]*?",IK=new globalThis.RegExp(`^${gJ}$`),Du=new globalThis.RegExp(`^(?:${gJ}|Infinity|-Infinity|NaN)$`);function iK(X){return RQ(IK,{expected:"a string representing a finite number",representation:{id:"effect/schema/isStringFinite",payload:null},toJsonSchema:()=>({pattern:IK.source}),...X})}var EF=iX(n8,[iK()]),Nu=new d0(EF,N9),Vu=new d0(new QX([EF,DF],"anyOf"),N9),Bu="-?\\d+",xK=new globalThis.RegExp(`^${Bu}$`);function rK(X){return RQ(xK,{expected:"a string representing a bigint",representation:{id:"effect/schema/isStringBigInt",payload:null},toJsonSchema:()=>({pattern:xK.source}),...X})}var nK=iX(n8,[rK({expected:"a string representing a bigint"})]),zu=new d0(nK,vJ),qu="Symbol\\((.*)\\)",vK=new globalThis.RegExp(`^${qu}$`),Ou=iX(n8,[sK()]),CF=new d0(Ou,new q0(Q0((X)=>globalThis.Symbol.for(vK.exec(X)[1])),YX((X)=>{if(globalThis.Symbol.keyFor(X)!==void 0)return d(globalThis.String(X));return f(new W9(T(X),{message:"cannot serialize to string, Symbol is not registered"}))})));function sK(X){return RQ(vK,{expected:"a string representing a symbol",representation:{id:"effect/schema/isStringSymbol",payload:null},toJsonSchema:()=>({pattern:vK.source}),...X})}function O9(X,Y,Q,J,$){for(let G=0;G<X.length;G++){let Z=X[G];if(Z._tag==="FilterGroup")O9(Z.checks,Y,Q,J,$);else{let K=Z.run(Y,J,$);if(K){if(Q.push(new RJ(Y,Z,K)),Z.aborted||$?.errors!=="all")return}}}}function wF(X,Y){let Q=[];if(O9(X,Y,Q,Q5,{errors:"all"}),V6(Q)){let J=new F0(Q5,T(Y),Q);return c(J)}return m(Y)}var aJ="~effect/Schema/Class";function Lu(X){return X===null||typeof X==="string"||typeof X==="boolean"||typeof X==="number"&&globalThis.Number.isFinite(X)}function Tu(X){return X===void 0||typeof X==="string"}function MF(X,Y){let Q=new WeakMap,J=[];X:while(!0){if(typeof X!=="object"||X===null){if(!Y(X))return!1}else{let $=X,G=Q.get($);if(G===!1)return!1;if(G===void 0){let Z=Array.isArray($);if(!Z){let K=Object.getPrototypeOf($);if(K!==null&&K!==Object.prototype&&Object.getPrototypeOf(K)!==null)return!1}Q.set($,!1),J.push({value:$,keys:Z?$.length:Object.keys($),index:0})}}while(J.length>0){let $=J[J.length-1],G=$.keys;if(typeof G==="number"){if($.index<G){X=$.value[$.index++];continue X}}else if($.index<G.length){X=$.value[G[$.index++]];continue X}Q.set($.value,!0),J.pop()}return!0}}function L9(X){return MF(X,Lu)}var B9=new G5([],()=>(X,Y)=>L9(X)?d(X):f(new r0(Y,T(X))),{representation:{id:"effect/schema/Json",payload:null},expected:"JSON value",toCodecJson:()=>{return},toCodecStringTree:()=>tK,toArbitrary:()=>(X)=>X.jsonValue()}),jF=E6(B9,{representation:{id:"effect/schema/MutableJson",payload:null}}),aK=new d0(B9,D9()),IF=new d0(new QX([new oX(!1,[],[B9]),new q9([],[new mJ(n8,B9,void 0)])],"anyOf"),D9());function Fu(X){return MF(X,Tu)}var Ru=new G5([],()=>(X,Y)=>Fu(X)?d(X):f(new r0(Y,T(X))),{expected:"StringTree",toCodecStringTree:()=>{return}}),tK=new d0(Ru,D9());var wQ="~effect/SchemaError/SchemaError";class X4 extends DY("SchemaError"){[wQ]=wQ;constructor(X){super({issue:X})}get message(){return this.issue.toString()}toString(){return`SchemaError(${this.message})`}}function eK(X){return j(X,wQ)&&X[wQ]===wQ}var MQ=X1((X)=>{switch(X._tag){case"Declaration":{let Y=X.annotations?.[aJ];if(l1(Y)){let Q=Y(X.typeParameters);return R0(X,[a8(Q,MQ)])}return X}case"Objects":case"Arrays":return X.recur((Y)=>{let Q=Y.context?.defaultValue;if(Q){let J=MQ(Y);return R0(J,J.encoding?[...J.encoding,...Q]:Q)}return MQ(Y)});case"Suspend":return X.recur(MQ);default:return X}});function eJ(X){let Y=MQ(T1(X.ast)),Q=F9(Y);return(J,$)=>{return Q(J,$?.disableChecks?$?.parseOptions?{...$.parseOptions,disableChecks:!0}:{disableChecks:!0}:$?.parseOptions)}}function X$(X){let Y=eJ(X);return(Q,J)=>{let $=p8(Y(Q,J));if(M1($))return T($.value);return H8($.cause,"Option adapter can only return none for schema issues"),p()}}function xF(X){let Y=eJ(X);return(Q,J)=>{let $=p8(Y(Q,J));if(M1($))return $.value;let G=H8($.cause,"Constructor adapter can only throw schema issues");throw Error(G.toString(),{cause:G})}}function vF(X){return jQ(X.ast)}function jQ(X){let Y=K5(F9(T1(X)));return(Q)=>{let J=Y(Q,_5);if(M1(J))return!0;return H8(J.cause,"Type guard adapter can only return false for schema issues"),!1}}function SF(X){let Y=F9(X);return(Q,J)=>{let $=p8(Y(Q,J));if(M1($))return;return H8($.cause,"Issue adapter can only return schema issues")}}function kF(X,Y){let J=K5(F9(T1(X.ast)))(Y,_5);if(bz(J)){let $=H8(J.cause,"Assertion adapter can only throw schema issues");throw Error($.toString(),{cause:$})}}function a0(X,Y){let Q=F9(X.ast);return Y===void 0?Q:(J,$)=>Q(J,pF(Y,$))}var XH=a0;function bF(X,Y){return K5(a0(X,Y))}function YH(X,Y){return dF(a0(X,Y))}var gF=YH;function yF(X,Y){return uF(a0(X,Y))}function Au(X,Y){return cF(a0(X,Y))}var QH=Au;function T9(X,Y){let Q=F9(cX(X.ast));return Y===void 0?Q:(J,$)=>Q(J,pF(Y,$))}function hF(X,Y){return K5(T9(X,Y))}function JH(X,Y){return dF(T9(X,Y))}var mF=JH;function fF(X,Y){return uF(T9(X,Y))}function Pu(X,Y){return cF(T9(X,Y))}var $H=Pu,pF=(X,Y)=>Y===void 0?X:{...X,...Y};function F9(X){let Y=tJ(X);return(Q,J)=>EX(Y(T(Q),J??_5),($)=>{if($._tag==="None")return f(new U0($));return d($.value)})}function K5(X){return(Y,Q)=>p8(X(Y,Q))}function dF(X){let Y=K5(X);return(Q,J)=>{let $=Y(Q,J);if(M1($))return T($.value);return H8($.cause,"Option adapter can only return none for schema issues"),p()}}function uF(X){let Y=K5(X);return(Q,J)=>{let $=Y(Q,J);if(M1($))return m($.value);return c(H8($.cause,"Result adapter can only return schema issues"))}}function cF(X){let Y=K5(X);return(Q,J)=>{let $=Y(Q,J);if(M1($))return $.value;let G=H8($.cause,"Sync adapter can only throw schema issues");throw Error(G.toString(),{cause:G})}}function Eu(X,Y){return i4(X,(Q)=>o4(()=>J8(Q,Y)))}var tJ=X1((X)=>{let Y,Q=X.checks,J=X.encoding,$=J,G=$?.length??0,Z=X.encodingChecks,K=(Q?Q[Q.length-1].annotations:X.annotations)?.parseOptions;if(!X.context&&!J&&!Q&&!Z)return(H,W)=>{if(Y??=X.getParser(tJ),K)W={...W,...K};return Y(H,W)};return(H,W)=>{if(K)W={...W,...K};let D;if($){for(let V=G-1;V>=0;V--){let z=$[V],q=z.to,F=tJ(q);if(D=D?EX(D,(R)=>F(R,W)):F(H,W),z.transformation._tag==="Transformation"){let R=z.transformation.decode;D=EX(D,(C)=>R.run(C,W))}else D=z.transformation.decode(D,W)}D=Eu(D,(V)=>new UK(X,H,V))}Y??=X.getParser(tJ);let U=(V)=>{let z=Y(V,W);if(Z&&!W?.disableChecks)z=EX(z,(q)=>{if(N1(V)&&N1(q)){let F=[];if(O9(Z,V.value,F,X,W),V6(F))return f(new F0(X,V,F))}return d(q)});if(Q&&!W?.disableChecks)z=EX(z,(q)=>{if(N1(q)){let F=q.value,R=[];if(O9(Q,F,R,X,W),V6(R))return f(new F0(X,q,R))}return d(q)});return z};return D?EX(D,U):U(H)}});var Y$="~effect/Schema/Schema";function JX(X,Y,Q){return{id:X,payloadSchema:Y,revive:Q}}function s(X,Y,Q){return{id:X,payloadSchema:Y,revive:Q}}var Cu={[Y$]:Y$,pipe(){return _0(this,arguments)},annotate(X){return this.rebuild(E6(this.ast,X))},annotateKey(X){return this.rebuild(EQ(this.ast,X))},check(...X){return this.rebuild(iX(this.ast,X))}};function IQ(X,Y){function Q(){}let J=Object.defineProperties(Object.setPrototypeOf(Q,Cu),Object.getOwnPropertyDescriptors({...Y}));J.ast=X,J.rebuild=(G)=>IQ(G,Y);let $=eJ(J);return J.makeEffect=(G,Z)=>Q$($(G,Z)),J.make=xF(J),J.makeOption=X$(J),J}function Q$(X){return i4(X,(Y)=>o4(()=>J8(Y,(Q)=>new X4(Q))))}var o_0=globalThis.Boolean;var lF=l6((X,Y)=>X||Y,!1);var oF=B(2,(X,Y)=>{return ZH(X,(Q,J)=>Y.includes(Q)?[Q,J]:void 0)}),iF=B(2,(X,Y)=>{return ZH(X,(Q,J)=>!Y.includes(Q)?[Q,J]:void 0)}),rF=B(2,(X,Y)=>{return{...X,...Y}});var GH=B(2,(X,Y)=>{return ZH(X,(Q,J)=>[Object.hasOwn(Y,Q)?Y[Q]:Q,J])});var j1=(X)=>X;function ZH(X,Y){let Q={};for(let J of Reflect.ownKeys(X)){if(!Object.prototype.propertyIsEnumerable.call(X,J))continue;let $=Y(J,X[J]);if($){let[G,Z]=$;k(Q,G,Z)}}return Q}function nF(X,Y){let Q=Y?.omitKeyWhen??(()=>!1);return VN((J,$)=>{let G=Reflect.ownKeys(X),Z={};for(let K of G){let H=X[K].combine(J[K],$[K]);if(Q(H))continue;k(Z,K,H)}return Z})}function xQ(X){return l6((Y,Q)=>{if(Y===void 0)return Q;if(Q===void 0)return Y;return X.combine(Y,Q)},void 0)}function C6(X,Y){if(Y.length>0)X+=`
  at ${k7(Y)}`;return Error(X)}var sF=new WeakMap,aF=new WeakMap,tF=[];function HR(){return{warnings:[]}}function WR(X){return{warnings:X.warnings.slice()}}function U8(X){return Error(`Unable to derive an arbitrary for ${X}`)}var eF=([X],[Y])=>o(X,Y);function Iu(X,Y,Q){return Y.reduce((J,$)=>J.filter((G)=>$.run(G,X,_5)===void 0),Q)}function UR(X,Y){if(X?.minLength!==void 0&&X.maxLength!==void 0&&X.minLength>X.maxLength)throw U8(`${Y} constraints`)}function DR(X){return X===void 0||X.minLength===void 0&&X.maxLength===void 0?void 0:{...X.minLength!==void 0?{minLength:X.minLength}:{},...X.maxLength!==void 0?{maxLength:X.maxLength}:{}}}function HH(X,Y,Q,J){return J?X.uniqueArray(Y,{...Q,comparator:J}):X.array(Y,Q)}function XR(X,Y,Q,J=!1){let $=Y.constraint,G=DR($);return UR(G,"array"),HH(X,Q,J?{...G,maxLength:G?.minLength??0}:G,$?.unique?o:void 0)}function J$(X,Y,Q,J){return Y.chain(($)=>$.length<Q?X.constant($):J.map((G)=>[...$,...G]))}function YR(X,Y){return X.chain((Q)=>Y.map((J)=>({...Object.fromEntries(J),...Q})))}var xu=xQ(Pq),vu=xQ(Eq),$$=xQ(lF),Su=xQ(uN()),ku=nF({integer:$$,maxLength:vu,minLength:xu,noInfinity:$$,noNaN:$$,patterns:Su,unique:$$},{omitKeyWhen:sD});function QR(X,Y,Q,J,$,G){if(J===void 0||Y===void 0)return J===void 0?[Y,Q]:[J,$];let Z=X(Y,J);return Z===G?[J,$]:Z===0?[Y,Q||$]:[Y,Q]}function bu(X,Y){if(X===void 0)return Y;if(X.order!==Y.order)throw Error("Cannot merge ordered arbitrary constraints with different Order instances");let[Q,J]=QR(X.order,X.minimum,X.exclusiveMinimum,Y.minimum,Y.exclusiveMinimum,-1),[$,G]=QR(X.order,X.maximum,X.exclusiveMaximum,Y.maximum,Y.exclusiveMaximum,1);return{order:X.order,...Q!==void 0?{minimum:Q}:{},...J!==void 0?{exclusiveMinimum:J}:{},...$!==void 0?{maximum:$}:{},...G!==void 0?{exclusiveMaximum:G}:{}}}function gu(X,Y){let{ordered:Q,...J}=X??{},{ordered:$,...G}=Y,Z=$===void 0?Q:bu(Q,$);return{...ku.combine(J,G),...Z===void 0?{}:{ordered:Z}}}function JR(X){let Y=[],Q=[];function J($){if($.annotations?.arbitrary)Q.push($.annotations.arbitrary);if($._tag!=="Filter")for(let G of $.checks)J(G);else Y.push($)}return X?.forEach(J),{filters:Y,arbitraries:Q}}function yu(X){let Y=X.map(({constraint:Q})=>Q).filter(B1);return(Q)=>{let J=Y.reduce(($,G)=>gu($,G),Q.constraint);return{...Q,constraint:J}}}function vQ(X){return{...X,constraint:void 0}}function $R(X,Y,Q){if(Y===void 0||Y.minLength===void 0&&Y.maxLength===void 0)return;if(Y.minLength!==void 0&&X.indexSignatures.length===0&&Y.minLength>X.propertySignatures.length)throw U8("object property constraints");let J={};if(Y.minLength!==void 0)J.minLength=Math.max(0,Y.minLength-Q);if(Y.maxLength!==void 0){if(J.maxLength=Y.maxLength-Q,J.maxLength<0)throw U8("object property constraints")}return UR(J,"object property"),J}function hu(X,Y,Q,J,$,G){let Z=J.length;if(G.maxLength!==void 0&&G.maxLength<Z)throw U8("object property constraints");let K=G.minLength===void 0?0:Math.max(0,G.minLength-Z),H=G.maxLength===void 0?$.length:Math.min($.length,G.maxLength-Z);if(K>H)throw U8("object property constraints");let W=X.record(Y,{requiredKeys:[...J,...$]}),D=X.shuffledSubarray([...$],{minLength:K,maxLength:H});return X.tuple(W,D).map(([U,N])=>{let V=new Set([...J,...N]),z={};for(let q of Q)if(V.has(q))k(z,q,U[q]);return z})}function NR(X,Y,Q,J){let $={};if(X?.minimum!==void 0)$.min=Y(X.minimum,X.exclusiveMinimum===!0);if(X?.maximum!==void 0)$.max=Q(X.maximum,X.exclusiveMaximum===!0);if($.min!==void 0&&$.max!==void 0&&$.min>$.max)throw U8(J);return $}function mu(X){return NR(X,(Y,Q)=>Q?Math.floor(Y)+1:Math.ceil(Y),(Y,Q)=>Q?Math.ceil(Y)-1:Math.floor(Y),"integer constraints")}function fu(X,Y){let Q={...X?.noInfinity?{noDefaultInfinity:!0}:{},...X?.noNaN?{noNaN:!0}:{},...Y?.minimum!==void 0?{min:Y.minimum}:{},...Y?.exclusiveMinimum!==void 0?{minExcluded:Y.exclusiveMinimum}:{},...Y?.maximum!==void 0?{max:Y.maximum}:{},...Y?.exclusiveMaximum!==void 0?{maxExcluded:Y.exclusiveMaximum}:{}};if(Q.min!==void 0&&Q.max!==void 0&&(Q.min>Q.max||Q.min===Q.max&&(Q.minExcluded||Q.maxExcluded)))throw U8("number constraints");return Q}function pu(X){return NR(X,(Y,Q)=>Q?Y+BigInt(1):Y,(Y,Q)=>Q?Y-BigInt(1):Y,"the ordered bigint constraints")}function R9(X,Y){let Q=(J,$,G=tF)=>X(J,$,G);return Q.terminal=(J,$,G=tF)=>Y(J,$,G),Q}function MX(X){return R9(X,X)}function _R(X,Y){let Q=aF.get(Y)??X.createDepthIdentifier();return aF.set(Y,Q),{maxDepth:2,depthIdentifier:Q}}function GR(X,Y){return Y.length===0?void 0:Y.length===1?Y[0]:X.oneof(...Y)}var du={noInfinity:!0,noNaN:!0};function uu(X){return{...X,constraint:du}}function cu(X,Y,Q){function J($,G){let Z=$.annotations?.arbitrary,K=G||Z?.constraint!==void 0||Z?.candidate!==void 0;if($._tag!=="Filter")for(let H of $.checks)J(H,K);else if(!K){let H=$.annotations?.representation?.id??$.annotations?.identifier??$.annotations?.expected;X.warnings.push({_tag:"OpaqueFilter",path:Q,...H===void 0?{}:{description:H}})}}Y?.forEach(($)=>J($,!1))}function VR(X,Y){let Q=new WeakSet;function J($,G){if(Q.has($))return;switch(Q.add($),cu(Y,$.checks,G),$._tag){case"Declaration":$.typeParameters.forEach((Z)=>J(Z,G));break;case"Arrays":{for(let[Z,K]of[...$.elements,...$.rest].entries())J(K,[...G,Z]);break}case"Objects":$.propertySignatures.forEach((Z)=>J(Z.type,[...G,Z.name])),$.indexSignatures.forEach((Z)=>{J(Z.parameter,G),J(Z.type,G)});break;case"Union":$.types.forEach((Z)=>J(Z,G));break;case"TemplateLiteral":$.parts.forEach((Z,K)=>J(F1(Z),[...G,K]));break;case"Suspend":J($.thunk(),G);break}Q.delete($)}J(X,[])}function lu(X,Y,Q,J){let $=J===void 0?[]:[{arbitrary:J,weight:1}];for(let{candidate:G}of Q){if(!G)continue;let Z=G.make(X,Y);if(Z===void 0)continue;let K=G.weight??1;if(!globalThis.Number.isInteger(K)||K<=0)throw U8("a candidate with an invalid weight");$.push({arbitrary:Z,weight:K})}return $.length===0?void 0:$.length===1?$[0].arbitrary:X.oneof(...$)}function ZR(X,Y,Q,J,$){let G=lu(Q,J,Y.arbitraries,$);return G===void 0?void 0:Iu(X,Y.filters,G)}function ou(X,Y){if(!(typeof X==="object"&&X!==null&&("arbitrary"in X)))return{arbitrary:X,terminal:Y?void 0:X};let Q="terminal"in X?X.terminal:Y?void 0:X.arbitrary;return{arbitrary:X.arbitrary,terminal:Q}}function iu(X,Y,Q,J,$){return X.map((G)=>({arbitrary:$?Y.constant(null).chain(()=>G(Y,Q,J)):G(Y,Q,J),terminal:G.terminal(Y,Q,J)}))}function KR(X,Y,Q,J){let $=yu(Y.arbitraries);return R9((G,Z,K)=>{let H=$(Z);return ZR(X,Y,G,H,Q(G,Z,H,K))},(G,Z,K)=>{let H=$(Z);return ZR(X,Y,G,H,J(G,Z,H,K))})}var WH=X1((X)=>jX(X,[]));function jX(X,Y){let Q=K8(X)?.toArbitrary;if(Q){let J=$5(X)?X.typeParameters.map((Z)=>jX(Z,Y)):[],$=JR(X.checks),G=(Z)=>(K,H,W,D)=>ou(Q(iu(J,K,vQ(H),D,Z))(K,W),J.length>0)[Z?"terminal":"arbitrary"];return KR(X,$,G(!1),G(!0))}if(X.checks){let J=JR(X.checks),$=jX(lJ(X,void 0),Y);return KR(X,J,(G,Z,K,H)=>$(G,K,H),(G,Z,K,H)=>$.terminal(G,K,H))}return ru(X,Y)}function ru(X,Y){switch(X._tag){case"Never":case"Declaration":throw C6(`Unsupported AST ${X._tag}`,Y);case"Null":return MX((Q)=>Q.constant(null));case"Void":case"Undefined":return MX((Q)=>Q.constant(void 0));case"Unknown":case"Any":return MX((Q)=>Q.anything());case"String":return MX((Q,J)=>{let $=J.constraint,G=$?.patterns;return G?Q.oneof(...G.map((Z)=>Q.stringMatching(new RegExp(Z)))):Q.string(DR($))});case"Number":return MX((Q,J)=>{let $=J.constraint,G=$?.ordered?.order===O1?$.ordered:void 0;return $?.integer?Q.integer(mu(G)):Q.float(fu($,G))});case"Boolean":return MX((Q)=>Q.boolean());case"BigInt":return MX((Q,J)=>{let $=J.constraint?.ordered?.order===AX?J.constraint.ordered:void 0;return Q.bigInt(pu($))});case"Symbol":return MX((Q)=>Q.string().map(Symbol.for));case"Literal":return MX((Q)=>Q.constant(X.literal));case"UniqueSymbol":return MX((Q)=>Q.constant(X.symbol));case"ObjectKeyword":return MX((Q)=>Q.oneof(Q.object(),Q.array(Q.anything())));case"Enum":return jX(RF(X),Y);case"TemplateLiteral":{let Q=X.parts.map((J,$)=>jX(F1(J),[...Y,$]));return MX((J,$,G)=>J.tuple(...Q.map((Z)=>Z(J,uu($),G))).map((Z)=>Z.map((K)=>globalThis.String(K)).join("")))}case"Arrays":{let Q=X.elements.map((Z,K)=>({ast:Z,arbitrary:jX(Z,[...Y,K])})),J=X.elements.length,$=X.rest.map((Z,K)=>({ast:Z,arbitrary:jX(Z,[...Y,J+K])})),G=(Z,K,H)=>{let W=vQ(K),D=[],U=[],N=0;for(let C of Q){let w=C.arbitrary.terminal(Z,W,H);if(l0(C.ast)){U.push(w);continue}if(w===void 0)return;N++,D.push(w.map(T))}let V=K.constraint?.minLength??0,q=S8($)&&V>N+U.length?U.length:Math.max(0,V-N),F=0;for(let C of U){if(F>=q||C===void 0){D.push(Z.constant(p()));continue}F++,N++,D.push(C.map(T))}if(F<q)return;let R=Z.tuple(...D).map(CG);if(S8($)){let[C,...w]=$,a=X.elements.length===0?K:W,O=Math.max(0,V-N-w.length),E=O===0?void 0:C.arbitrary.terminal(Z,W,H);if(O>0&&E===void 0)return;let A=O===0?Z.constant([]):XR(Z,{...a,constraint:{...a.constraint,minLength:O}},E,!0);if(R=J$(Z,R,J,A),w.length>0){let x=[];for(let x0 of w){let f0=x0.arbitrary.terminal(Z,W,H);if(f0===void 0)return;x.push(f0)}let n=Z.tuple(...x);R=J$(Z,R,J,n)}}return R};return R9((Z,K,H)=>{let W=vQ(K),D=Q.map(({ast:N,arbitrary:V})=>{let z=V(Z,W,H);return l0(N)?z.chain((q)=>Z.boolean().map((F)=>F?T(q):p())):z.map(T)}),U=Z.tuple(...D).map(CG);if(S8($)){let[N,...V]=$.map(({arbitrary:q})=>q(Z,W,H)),z=XR(Z,X.elements.length===0?K:W,N);if(U=J$(Z,U,J,z),V.length>0){let q=Z.tuple(...V);U=J$(Z,U,J,q)}}if(K.recursion){let N=G(Z,K,H);if(N!==void 0)return Z.oneof(K.recursion,N,U)}return U},G)}case"Objects":{let Q=X.propertySignatures.map((G)=>({ps:G,arbitrary:jX(G.type,[...Y,G.name])})),J=X.indexSignatures.map((G)=>({is:G,parameter:jX(G.parameter,Y),type:jX(G.type,Y)}));return R9((G,Z,K)=>{let H=vQ(Z),W={},D=[],U=[],N=[];for(let{ps:F,arbitrary:R}of Q){let C=F.name;if(D.push(C),l0(F.type))N.push(C);else U.push(C);k(W,C,R(G,H,K))}let V=Z.constraint;if(N.length>0&&J.length===0&&V!==void 0&&(V.minLength!==void 0||V.maxLength!==void 0))return hu(G,W,D,U,N,V);let z=G.record(W,{requiredKeys:U}),q=$R(X,Z.constraint,U.length);for(let{parameter:F,type:R}of J){let C=G.tuple(F(G,H,K),R(G,H,K)),w=HH(G,C,q,eF);z=YR(z,w)}return z},(G,Z,K)=>{let H=vQ(Z),W={},D=[],U=[];for(let{ps:F,arbitrary:R}of Q){let C=F.name,w=R.terminal(G,H,K);if(l0(F.type)){if(w!==void 0)U.push([C,w]);continue}if(w===void 0)return;D.push(C),k(W,C,w)}let N=Math.max(0,(Z.constraint?.minLength??0)-D.length);for(let[F,R]of U){if(N===0)break;N--,D.push(F),k(W,F,R)}if(N>0&&X.indexSignatures.length===0)return;let V=G.record(W,{requiredKeys:D}),z=$R(X,Z.constraint,D.length),q=z?.minLength??0;for(let{parameter:F,type:R}of J){let C;if(q===0)C=G.constant([]);else{let w=F.terminal(G,H,K),a=R.terminal(G,H,K);if(w===void 0||a===void 0)return;C=HH(G,G.tuple(w,a),{...z,maxLength:q},eF)}V=YR(V,C)}return V})}case"Union":{let Q=X.types.map(($)=>jX($,Y)),J=($,G,Z)=>GR($,Q.map((K)=>K.terminal($,G,Z)).filter(B1));return R9(($,G,Z)=>{let K=Q.map((W)=>W($,G,Z));if(G.recursion){let W=J($,G,Z);if(W!==void 0)return $.oneof(G.recursion,W,...K)}let H=GR($,K);if(H===void 0)throw U8("a union with no members");return H},J)}case"Suspend":{let Q=sF.get(X);if(Q)return Q;let J=Z5(()=>jX(X.thunk(),Y)),$=R9((G,Z,K)=>{let H=_R(G,X),W={...Z,recursion:H},D=K.includes(X)?K:[...K,X],U=J().terminal(G,W,D);if(U===void 0)throw C6("Unable to derive an arbitrary for a recursive schema without a finite generation path",Y);return G.oneof(H,U,G.constant(null).chain(()=>J()(G,W,D)))},(G,Z,K)=>{if(K.includes(X))return;let H=_R(G,X);return J().terminal(G,{...Z,recursion:H},[...K,X])});return sF.set(X,$),$}}}var BR=X1((X)=>{return Y4(X,[])});function Y4(X,Y){let Q=K8(X)?.toEquivalence;if(Q)return Q($5(X)?X.typeParameters.map((J)=>Y4(J,Y)):[]);switch(X._tag){case"Never":return BN();case"Declaration":case"Null":case"Undefined":case"Void":case"Unknown":case"Any":case"String":case"Number":case"Boolean":case"BigInt":case"Symbol":case"Literal":case"UniqueSymbol":case"ObjectKeyword":case"Enum":case"TemplateLiteral":return o;case"Arrays":{let J=X.elements.map((Z,K)=>Y4(Z,[...Y,K])),$=X.elements.length,G=X.rest.map((Z,K)=>Y4(Z,[...Y,$+K]));return D1((Z,K)=>{if(!Array.isArray(Z)||!Array.isArray(K))return!1;let H=Z.length;if(H!==K.length)return!1;let W=0;for(;W<Math.min(H,X.elements.length);W++)if(!J[W](Z[W],K[W]))return!1;if(G.length>0){let[D,...U]=G;for(;W<H-U.length;W++)if(!D(Z[W],K[W]))return!1;for(let N=0;N<U.length;N++)if(!U[N](Z[W+N],K[W+N]))return!1}return!0})}case"Objects":{if(X.propertySignatures.length===0&&X.indexSignatures.length===0)return o;let J=X.propertySignatures.map((G)=>Y4(G.type,[...Y,G.name])),$=X.indexSignatures.map((G)=>Y4(G.type,Y));return D1((G,Z)=>{if(!x1(G)||!x1(Z))return!1;for(let K=0;K<J.length;K++){let H=X.propertySignatures[K],W=H.name,D=Object.hasOwn(G,W),U=Object.hasOwn(Z,W);if(l0(H.type)){if(D!==U)return!1}if(D&&U&&!J[K](G[W],Z[W]))return!1}for(let K=0;K<$.length;K++){let H=X.indexSignatures[K],W=z9(G,H.parameter),D=z9(Z,H.parameter);if(W.length!==D.length)return!1;for(let U=0;U<W.length;U++){let N=W[U];if(!Object.hasOwn(Z,N)||!$[K](G[N],Z[N]))return!1}}return!0})}case"Union":{let J=T1(X).types,$=new Map(J.map((G,Z)=>[G,[jQ(G),Y4(X.types[Z],Y)]]));return D1((G,Z)=>{let K=FQ(G,J);for(let H=0;H<K.length;H++){let[W,D]=$.get(K[H]);if(W(G)&&W(Z))return D(G,Z)}return!1})}case"Suspend":{let J=Z5(()=>Y4(X.thunk(),Y));return D1(($,G)=>J()($,G))}}}function _$(X){return X.replace(/~/g,"~0").replace(/\//g,"~1")}function zR(X){return X.replace(/~1/g,"/").replace(/~0/g,"~")}var XG0=globalThis.RegExp;var A9=(X)=>X.replace(/[/\\^$*+?.()|[\]{}]/g,"\\$&");var au=new Set([...xL,ZQ,...jL]);function SQ(X,Y){if(X===void 0)return;let Q={},J=X.title;if(typeof J==="string")Q.title=J;let{description:$,expected:G}=X;if(typeof $==="string")Q.description=$;else if(Y?.generateDescriptions===!0&&typeof G==="string")Q.description=G;let Z=X.default;if(L9(Z))Q.default=Z;let K=X.examples;if(Array.isArray(K)&&L9(K))Q.examples=K;let H=X.readOnly;if(typeof H==="boolean")Q.readOnly=H;let W=X.writeOnly;if(typeof W==="boolean")Q.writeOnly=W;let D=X.format;if(typeof D==="string")Q.format=D;let U=X.contentEncoding;if(typeof U==="string")Q.contentEncoding=U;let N=X.contentMediaType;if(typeof N==="string")Q.contentMediaType=N;let V=X.contentSchema;if(L9(V))Q.contentSchema=V;if(Y?.includeAnnotationKey!==void 0)for(let[z,q]of Object.entries(X)){if(au.has(z)||!Y.includeAnnotationKey(z))continue;if(L9(q))k(Q,z,q)}return Object.keys(Q).length===0?void 0:Q}function OR(X){let Y=X.type==="number"||X.type==="integer"?X.type:void 0,Q=X;if(Y!==void 0)Q={...X},delete Q.type;if(Array.isArray(Q.allOf)){let J=[],$=!1;for(let G of Q.allOf){let Z=OR(G);if(Z.type!==void 0){if($=!0,Y===void 0||Z.type==="integer")Y=Z.type}if(Object.keys(Z.schema).length>0)J.push(Z.schema)}if($){let{allOf:G,...Z}=Q;Q=J.length===0?Z:{...Z,allOf:J}}}return{type:Y,schema:Q}}function tu(X){return Array.isArray(X.anyOf)&&X.anyOf.length===4&&X.anyOf[0]?.type==="number"&&X.anyOf.slice(1).every((Y)=>Y.type==="string")}function G$(X,Y){if(Object.keys(X).length===0)return Y;let Q=Object.keys(Y);if(Q.length===0)return X;let J=X.type==="number"||X.type==="integer"?X.type:void 0,$=tu(X);if(J!==void 0||$){let Z=OR(Y);if(Z.type!==void 0){let K=J==="integer"||Z.type==="integer"?"integer":"number",H={...X,type:K};if($)delete H.anyOf;return Object.keys(Z.schema).length===0?H:G$(H,Z.schema)}}let G=Array.isArray(Y.allOf)&&Q.length===1?Y.allOf:[Y];if(Array.isArray(X.allOf))return{...X,allOf:[...X.allOf,...G]};if(typeof X.$ref==="string")return{allOf:[X,...G]};return{...X,allOf:G}}function eu(X,Y,Q,J){let $={};for(let U of Object.keys(Q))k($,U,H(Q[U],["references",U]));return{dialect:"draft-2020-12",schemas:B6(X,(U,N)=>H(U,Y[N])),definitions:$};function Z(U,N){return U?.schemas?.map((V,z)=>H(V,[...N,"schemas",z]))??[]}function K(U,N,V){let z=U.annotations,q=z?.toJsonSchema;if(q!==void 0){let C=Z(U.representation,[...V,"representation"]),w=q({type:N,schemas:C}),a=SQ(z,J);return a===void 0?w:{...w,...a}}if(U._tag==="Filter")return;let F=U.checks.map((C,w)=>K(C,N,[...V,"checks",w])).filter((C)=>C!==void 0);if(F.length===0)return;let R=SQ(z,J);return R===void 0?{allOf:F}:{allOf:F,...R}}function H(U,N){if(U._tag==="Reference"){if(!Object.hasOwn(Q,U.$ref))throw C6(`Invalid reference ${U.$ref}`,[...N,"$ref"]);return{$ref:`#/$defs/${_$(U.$ref)}`}}let V=W(U,N),z=SQ(U.annotations,J);if(z!==void 0)V={...V,...z};for(let q=0;q<U.checks.length;q++){let F=typeof V.type==="string"&&Xc(V.type)?V.type:void 0,R=K(U.checks[q],F,[...N,"checks",q]);if(R!==void 0)V=G$(V,R)}return V}function W(U,N){switch(U._tag){case"Any":case"Unknown":return{};case"ObjectKeyword":return{anyOf:[{type:"object"},{type:"array"}]};case"Void":case"Undefined":case"Null":return{type:"null"};case"BigInt":return{type:"string",allOf:[{pattern:"^-?\\d+$"}]};case"Symbol":case"UniqueSymbol":return{type:"string",allOf:[{pattern:"^Symbol\\((.*)\\)$"}]};case"Declaration":return{};case"Suspend":return H(U.thunk,[...N,"thunk"]);case"Never":return{not:{}};case"String":return{type:"string"};case"Number":return{anyOf:[{type:"number"},{type:"string",enum:["NaN"]},{type:"string",enum:["Infinity"]},{type:"string",enum:["-Infinity"]}]};case"Boolean":return{type:"boolean"};case"Literal":{let V=U.literal;return typeof V==="bigint"?{type:"string",enum:[globalThis.String(V)]}:{type:typeof V,enum:[V]}}case"Enum":{let V=U.enums.map(([z,q])=>typeof q==="number"&&!globalThis.Number.isFinite(q)?{type:"string",enum:[globalThis.String(q)],title:z}:{type:typeof q,enum:[q],title:z});return V.length===0?{not:{}}:{anyOf:V}}case"TemplateLiteral":return{type:"string",pattern:`^${U.parts.map(Z$).join("")}$`};case"Arrays":{if(U.rest.length>1)throw C6("Invalid schema representation document",[...N,"rest"]);let V={type:"array"},z=U.elements.length,q=U.elements.map((F,R)=>{if(F.isOptional)z--;let C=H(F.type,[...N,"elements",R,"type"]),w=SQ(F.annotations,J);return w===void 0?C:G$(C,w)});if(q.length>0){if(V.prefixItems=q,V.maxItems=U.elements.length,z>0)V.minItems=z}else V.items=!1;if(U.rest.length===1){delete V.maxItems;let F=H(U.rest[0],[...N,"rest",0]);if(Object.keys(F).length>0)V.items=F;else delete V.items}return V}case"Objects":{if(U.propertySignatures.length===0&&U.indexSignatures.length===0)return{anyOf:[{type:"object"},{type:"array"}]};let V={type:"object"},z={},q=[];for(let R=0;R<U.propertySignatures.length;R++){let C=U.propertySignatures[R];if(typeof C.name!=="string")throw C6("Invalid schema representation document",[...N,"propertySignatures",R,"name"]);let w=C.name,a=H(C.type,[...N,"propertySignatures",R,"type"]),O=SQ(C.annotations,J);if(k(z,w,O===void 0?a:G$(a,O)),!C.isOptional)q.push(w)}if(U.propertySignatures.length>0)V.properties=z;if(q.length>0)V.required=q;V.additionalProperties=J?.additionalProperties??!1;let F={};for(let R=0;R<U.indexSignatures.length;R++){let C=U.indexSignatures[R],w=H(C.type,[...N,"indexSignatures",R,"type"]);if(Object.keys(w).length===1&&"not"in w)w=!1;let a=D(C.parameter,[...N,"indexSignatures",R,"parameter"],new Set);if(a.length===0)V.additionalProperties=w;else for(let O of a)k(F,O,w)}if(Object.keys(F).length>0)V.patternProperties=F,delete V.additionalProperties;if(typeof V.additionalProperties==="object"&&V.additionalProperties!==null&&Object.keys(V.additionalProperties).length===0)delete V.additionalProperties;return V}case"Union":{let V=U.types.map((z,q)=>H(z,[...N,"types",q]));if(V.length===0)return{not:{}};if(V.length>1){let z=Yc(V);if(z!==void 0)return z}return U.mode==="anyOf"?{anyOf:V}:{oneOf:V}}}}function D(U,N,V){switch(U._tag){case"Reference":{if(!Object.hasOwn(Q,U.$ref))throw C6(`Invalid reference ${U.$ref}`,[...N,"$ref"]);if(V.has(U.$ref))return[];let z=new Set(V).add(U.$ref);return D(Q[U.$ref],["references",U.$ref],z)}case"String":return LR(H(U,N));case"TemplateLiteral":return[`^${U.parts.map(Z$).join("")}$`];case"Union":return U.types.flatMap((z,q)=>D(z,[...N,"types",q],V));default:throw C6("Invalid schema representation document",N)}}}function Xc(X){return X==="string"||X==="number"||X==="boolean"||X==="array"||X==="object"||X==="null"||X==="integer"}function Yc(X){let Y=void 0,Q=[];for(let J of X){if(Object.keys(J).length!==2||J.type===void 0||!Array.isArray(J.enum)||J.enum.length===0)return;if(Y===void 0)Y=J.type;else if(J.type!==Y)return;Q.push(...J.enum)}return{type:Y,enum:Q}}function LR(X){let Y=[];if(typeof X.pattern==="string")Y.push(X.pattern);for(let Q of["allOf","anyOf","oneOf"]){let J=X[Q];if(Array.isArray(J)){for(let $ of J)if(typeof $==="object"&&$!==null&&!Array.isArray($))Y.push(...LR($))}}return Y}function Z$(X){switch(X._tag){case"Literal":return A9(globalThis.String(X.literal));case"String":return PF;case"Number":return gJ;case"TemplateLiteral":return X.parts.map(Z$).join("");case"Union":return X.types.map(Z$).join("|");default:throw C6("Invalid schema representation document",[])}}function TR(X,Y){let Q=eu([X.representation],[["representation"]],X.references,Y);return{dialect:Q.dialect,schema:Q.schemas[0],definitions:Q.definitions}}function UH(X){let{references:Y,representations:Q}=Jc([X]);return{representation:Q[0],references:Y}}function Jc(X){return $c(X,[])}function nX(X){return X===void 0?void 0:{annotations:X}}function AR(X){return qQ(X)||SK(X)||OQ(X)&&X.types.some(AR)}function FR(X){let Y=i8(X);if(Y!==void 0)return{identifier:Y,isFallback:!1};let Q=LJ(X);return Q===void 0?void 0:{identifier:`${Q}JsonEncoding`,isFallback:!0}}function RR(X,Y){if(X===Y)return!0;let Q=Reflect.ownKeys(X),J=Reflect.ownKeys(Y);if(Q.length!==J.length)return!1;for(let $ of Q)if($!=="context"&&X[$]!==Y[$])return!1;return!0}function $c(X,Y){let Q={},J=new Map,$=[],G=new Map,Z=new Set(Y.map((O)=>O.key)),K=new Set,H=new Set,W=new Set;for(let O of Y)G.set(O.key,O.body),J.set(O.original,O.key),J.set(O.encoded,O.key);for(let O of X)N(O);for(let O of Y)N(O.body);let D=B6(X,(O)=>z(O));for(let O of Y)k(Q,O.key,z(O.body,O.key));return{representations:D,references:Q};function U(O,E){let A=O,x=0;while(G.has(A))A=`${O}${++x}`;return G.set(A,E),A}function N(O){let E=s8(O);if(H.has(E)){if(AR(E))W.add(E);return}H.add(E);let A=FR(E);if(A!==void 0&&!A.isFallback){let x=G.get(A.identifier);if(x===void 0)G.set(A.identifier,E);else if(J.get(E)!==A.identifier&&!RR(x,E))throw Error(`Duplicate identifier: ${JSON.stringify(A.identifier)}`)}switch(V(E.checks),E._tag){case"Declaration":case"Arrays":case"Objects":case"Union":E.recur((x)=>{return N(x),x});break;case"TemplateLiteral":E.parts.forEach(N);break;case"Suspend":N(E.thunk());break}}function V(O){O?.forEach((E)=>{if(E.annotations?.representation?.schemas?.forEach((A)=>N(T1(A))),E._tag==="FilterGroup")V(E.checks)})}function z(O,E){let A=J.get(O);if(A!==void 0&&A!==E)return{_tag:"Reference",$ref:A};let x=s8(O);if(x!==O)return z(x,E);let n=E===void 0?FR(O):void 0;if(n!==void 0){let B0=q(n,O);if(J.set(O,B0),!Object.hasOwn(Q,B0)&&!Z.has(B0))k(Q,B0,F(O));return{_tag:"Reference",$ref:B0}}if(E===void 0&&W.has(O)){let B0=U(`${O._tag}_`,O);return J.set(O,B0),k(Q,B0,F(O)),{_tag:"Reference",$ref:B0}}if(K.has(O)){let B0=U(`${O._tag}_`,O);return J.set(O,B0),{_tag:"Reference",$ref:B0}}K.add(O);let x0=F(O);K.delete(O);let f0=J.get(O);if(f0!==void 0&&f0!==E)return k(Q,f0,x0),{_tag:"Reference",$ref:f0};return x0}function q(O,E){if(!O.isFallback)return O.identifier;for(let[x,n]of $)if(RR(x,E))return n;let A=U(O.identifier,E);return $.push([E,A]),A}function F(O){let E=R(O.checks);switch(O._tag){case"Declaration":return{_tag:"Declaration",typeParameters:O.typeParameters.map((A)=>z(A)),checks:E,...w(O.annotations)};case"Null":case"Undefined":case"Void":case"Never":case"Unknown":case"Any":case"String":case"Boolean":case"Number":case"BigInt":case"Symbol":case"ObjectKeyword":return{_tag:O._tag,checks:E,...nX(O.annotations)};case"Literal":return{_tag:"Literal",literal:O.literal,checks:E,...nX(O.annotations)};case"UniqueSymbol":return{_tag:"UniqueSymbol",symbol:O.symbol,checks:E,...nX(O.annotations)};case"Enum":return{_tag:"Enum",enums:O.enums,checks:E,...nX(O.annotations)};case"TemplateLiteral":return{_tag:"TemplateLiteral",parts:O.parts.map((A)=>z(A)),checks:E,...nX(O.annotations)};case"Arrays":return{_tag:"Arrays",elements:O.elements.map((A)=>{let x=s8(A),n=x.context?.annotations;return{isOptional:l0(x),type:z(A),...nX(n)}}),rest:O.rest.map((A)=>z(A)),checks:E,...nX(O.annotations)};case"Objects":return{_tag:"Objects",propertySignatures:O.propertySignatures.map((A)=>{let x=s8(A.type),n=x.context?.annotations;return{name:A.name,type:z(A.type),isOptional:l0(x),isMutable:LF(x),...nX(n)}}),indexSignatures:O.indexSignatures.map((A)=>({parameter:z(A.parameter),type:z(A.type)})),checks:E,...nX(O.annotations)};case"Union":return{_tag:"Union",types:O.types.map((A)=>z(A)),mode:O.mode,checks:E,...nX(O.annotations)};case"Suspend":return{_tag:"Suspend",checks:[],thunk:z(O.thunk()),...nX(O.annotations)}}}function R(O){return O?.map(C)??[]}function C(O){switch(O._tag){case"Filter":return{_tag:"Filter",aborted:O.aborted,...a(O.annotations)};case"FilterGroup":return{_tag:"FilterGroup",checks:B6(O.checks,C),...a(O.annotations)}}}function w(O){if(O===void 0)return;let{representation:E,...A}=O;return{...E===void 0?void 0:{representation:E},...Object.keys(A).length===0?void 0:{annotations:A}}}function a(O){if(O===void 0)return;let{representation:E,...A}=O,x=E===void 0?void 0:E.schemas===void 0?E:{...E,schemas:E.schemas.map((n)=>z(T1(n)))};return{...x===void 0?void 0:{representation:x},...Object.keys(A).length===0?void 0:{annotations:A}}}}function K$(X,Y){if(Object.is(X,Y))return[];let Q=[];if(Array.isArray(X)&&Array.isArray(Y)){let J=X.length,$=Y.length,G=Math.min(J,$);for(let Z=0;Z<G;Z++){let K=`/${Z}`,H=K$(X[Z],Y[Z]);for(let W of H)PR(W,K),Q.push(W)}for(let Z=J-1;Z>=$;Z--)Q.push({op:"remove",path:`/${Z}`});for(let Z=J;Z<$;Z++)Q.push({op:"add",path:`/${Z}`,value:Y[Z]});return Q}if(H$(X)&&H$(Y)){let J=Object.keys(X),$=Object.keys(Y),G=Array.from(new Set([...J,...$])).sort();for(let Z of G){let H=`/${_$(Z)}`,W=Object.hasOwn(X,Z),D=Object.hasOwn(Y,Z);if(W&&D){let U=K$(X[Z],Y[Z]);for(let N of U)PR(N,H),Q.push(N)}else if(!W&&D)Q.push({op:"add",path:H,value:Y[Z]});else if(W&&!D)Q.push({op:"remove",path:H})}return Q}return Q.push({op:"replace",path:"",value:Y}),Q}function CR(X,Y){let Q=Y;for(let J of X)switch(J.op){case"replace":{Q=J.path===""?J.value:ER(Q,J.path,J.value,"replace");break}case"add":{Q=Zc(Q,J.path,J.value);break}case"remove":{Q=ER(Q,J.path,void 0,"remove");break}}return Q}function PR(X,Y){X.path=X.path===""?Y:Y+X.path}function H$(X){return x1(X)}function Gc(X){if(X==="")return[];if(X.charCodeAt(0)!==47)throw Error(`Invalid JSON Pointer, it must start with "/": ${P(X)}`);return X.split("/").slice(1).map(zR)}function DH(X){if(!/^(0|[1-9]\d*)$/.test(X))throw Error(`Invalid array index: "${X}"`);return Number(X)}function Zc(X,Y,Q){if(Y==="")return Q;let J=wR(X,Y);if(J===null)throw Error(`Cannot add at "${Y}" (parent not found or not a container).`);let{lastToken:$,parent:G,stack:Z}=J;if(Array.isArray(G)){let K=$==="-"?G.length:DH($);if(K<0||K>G.length)throw Error(`Array index out of bounds at "${Y}".`);let H=G.slice();return H.splice(K,0,Q),W$(Z,H)}if(H$(G)){let K={...G};return k(K,$,Q),W$(Z,K)}throw Error(`Cannot add at "${Y}" (parent not found or not a container).`)}function ER(X,Y,Q,J){if(Y===""){if(J==="remove"||Q===void 0)throw Error("Unsupported operation at the root");return Q}let $=wR(X,Y);if($===null)throw Error(`Cannot ${J} at "${Y}" (parent not found or not a container).`);let{lastToken:G,parent:Z,stack:K}=$;if(Array.isArray(Z)){if(G==="-")throw Error(`"-" is not valid for ${J} at "${Y}".`);let H=DH(G);if(H<0||H>=Z.length)throw Error(`Array index out of bounds at "${Y}".`);let W=Z.slice();if(J==="remove")W.splice(H,1);else W[H]=Q;return W$(K,W)}if(H$(Z)){if(!Object.hasOwn(Z,G))throw Error(`Property "${G}" does not exist at "${Y}".`);let H={...Z};if(J==="remove")delete H[G];else k(H,G,Q);return W$(K,H)}throw Error(`Cannot ${J} at "${Y}" (parent not found or not a container).`)}function wR(X,Y){let Q=Gc(Y);if(Q.length===0)return null;let J=Q[Q.length-1],$=[],G=X;for(let Z=0;Z<Q.length-1;Z++){let K=Q[Z];if(G==null)return null;if(Array.isArray(G)){let H=DH(K);if(H<0||H>=G.length)return null;$.push({container:G,token:H}),G=G[H];continue}if(G&&typeof G==="object"){if(!Object.hasOwn(G,K))return null;$.push({container:G,token:K}),G=G[K];continue}return null}return{stack:$,parent:G,lastToken:J}}function W$(X,Y){let Q=Y;for(let J=X.length-1;J>=0;J--){let{container:$,token:G}=X[J];if(Array.isArray($)){let Z=$.slice();Z[G]=Q,Q=Z}else{let Z={...$};k(Z,G,Q),Q=Z}}return Q}var Hc=/^#\/\$defs(?=\/|$)/;function jR(X){return{dialect:"draft-07",schema:MR(X.schema),definitions:_3(X.definitions,MR)}}function MR(X){return Y(X);function Y(J){return Q(NH(J,($)=>$.replace(Hc,"#/definitions")),!0)}function Q(J,$){if(Array.isArray(J))return J.map((W)=>Q(W,!1));if(!x1(J))return J;let G=J,Z={},K=void 0,H=void 0;for(let W of Object.keys(G)){let D=G[W];switch(W){case"$ref":case"type":case"required":case"enum":case"const":case"title":case"description":case"default":case"examples":case"format":case"pattern":case"minimum":case"maximum":case"exclusiveMinimum":case"exclusiveMaximum":case"minLength":case"maxLength":case"minItems":case"maxItems":case"minProperties":case"maxProperties":case"multipleOf":case"uniqueItems":Z[W]=D;break;case"properties":case"patternProperties":{let U=Wc(D,Q);Z[W]=U??D;break}case"additionalProperties":case"propertyNames":Z[W]=Q(D,!1);break;case"allOf":case"anyOf":case"oneOf":Z[W]=Array.isArray(D)?D.map((U)=>Q(U,!1)):D;break;case"prefixItems":K=D;break;case"items":H=D;break;default:break}}if(K!==void 0)if(Array.isArray(K)){if(Z.items=K.map((W)=>Q(W,!1)),H!==void 0)Z.additionalItems=Q(H,!1)}else Z.items=Q(K,!1);else if(H!==void 0)Z.items=Q(H,!1);return Z}}function NH(X,Y){if(Array.isArray(X))return X.map((J)=>NH(J,Y));if(!x1(X))return X;let Q={};for(let J of Object.keys(X)){let $=X[J];if(J==="$ref")k(Q,J,typeof $==="string"?Y($):$);else if(Array.isArray($)||x1($))k(Q,J,NH($,Y));else k(Q,J,$)}return Q}function Wc(X,Y){if(!x1(X))return;let Q={};for(let J of Object.keys(X))k(Q,J,Y(X[J],!1));return Q}function xR(X,Y){return sX(new bR(X,Y))}function IR(X,Y){return sX(new BH(X,Y))}class vR{_tag="IdentityNode"}var SR=new vR;class kR{_tag="CompositionNode";nodes;constructor(X){this.nodes=X}}class bR{_tag="IsoNode";get;set;constructor(X,Y){this.get=X,this.set=Y}}class BH{_tag="LensNode";get;set;constructor(X,Y){this.get=X,this.set=Y}}class gR{_tag="PrismNode";get;set;constructor(X,Y){this.get=X,this.set=Y}}class zH{_tag="OptionalNode";get;set;constructor(X,Y){this.get=X,this.set=Y}}class qH{_tag="PathNode";path;constructor(X){this.path=X}}class D${_tag="CheckNode";checks;constructor(X){this.checks=X}}function Dc(X,Y){let Q=X[X.length-1];if(Q){if(Q._tag==="PathNode"&&Y._tag==="PathNode"){X[X.length-1]=new qH([...Q.path,...Y.path]);return}if(Q._tag==="CheckNode"&&Y._tag==="CheckNode"){X[X.length-1]=new D$([...Q.checks,...Y.checks]);return}}X.push(Y)}function VH(X,Y){if(X._tag==="IdentityNode")return;if(X._tag==="CompositionNode"){for(let Q=0;Q<X.nodes.length;Q++)VH(X.nodes[Q],Y);return}Dc(Y,X)}function H5(X,Y){let Q=[];switch(VH(X,Q),VH(Y,Q),Q.length){case 0:return SR;case 1:return Q[0];default:return new kR(Q)}}function Nc(X,Y){return sX(new zH(X,Y))}class kQ{node;getResult;replaceResult;constructor(X,Y,Q){this.node=X,this.getResult=Y,this.replaceResult=Q}replace(X,Y){return x8(this.replaceResult(X,Y),()=>Y)}modify(X){return(Y)=>x8(v8(this.getResult(Y),(Q)=>this.replaceResult(X(Q),Y)),()=>Y)}compose(X){return sX(H5(this.node,X.node))}key(X){return sX(H5(this.node,new qH([X])))}optionalKey(X){return sX(H5(this.node,new BH((Y)=>Y[X],(Y,Q)=>{let J=N$(Q);if(Y===void 0)if(Array.isArray(J)&&typeof X==="number")J.splice(X,1);else delete J[X];else k(J,X,Y);return J})))}check(...X){return sX(H5(this.node,new D$(X)))}refine(X,Y){return sX(H5(this.node,new D$([cJ(X,Y)])))}tag(X){return sX(H5(this.node,new gR((Y)=>Y._tag===X?m(Y):c(`Expected ${P(X)} tag, got ${P(Y._tag)}`),u)))}at(X,...Y){let Q=c(`Key ${P(X)} not found`);return sX(H5(this.node,new zH((J)=>Object.hasOwn(J,X)?m(J[X]):Q,(J,$)=>{if(Object.hasOwn($,X)){let G=N$($);return k(G,X,J),m(G)}else return Q})))}pick(X){return this.compose(IR(oF(X),(Y,Q)=>({...Q,...Y})))}omit(X){return this.compose(IR(iF(X),(Y,Q)=>({...Q,...Y})))}notUndefined(){return this.refine(B1,{expected:"a value other than `undefined`"})}forEach(X){let Y=X(V$());return Nc((Q)=>ZX(this.getResult(Q),(J)=>{let $=[];for(let G=0;G<J.length;G++){let Z=Y.getResult(J[G]);if(Y1(Z))$.push(Z.success)}return $}),(Q,J)=>v8(this.getResult(J),($)=>{let G=[];for(let K=0;K<$.length;K++)if(Y1(Y.getResult($[K])))G.push(K);if(Q.length!==G.length)return c(`each: replacement length mismatch: ${Q.length} !== ${G.length}`);let Z=$.slice();for(let K=0;K<G.length;K++){let H=G[K],W=Y.replaceResult(Q[K],$[H]);if(J0(W))return c(`each: could not set element ${H}`);Z[H]=W.success}return this.replaceResult(Z,J)}))}modifyAll(X){return(Y)=>x8(v8(this.getResult(Y),(Q)=>this.replaceResult(Q.map(X),Y)),()=>Y)}}class yR extends kQ{get;set;constructor(X,Y,Q){super(X,(J)=>m(Y(J)),(J)=>m(Q(J)));this.get=Y,this.set=Q}replace(X,Y){return this.set(X)}modify(X){return(Y)=>this.set(X(this.get(Y)))}}class hR extends kQ{get;constructor(X,Y,Q){super(X,(J)=>m(Y(J)),(J,$)=>m(Q(J,$)));this.get=Y,this.replace=Q}modify(X){return(Y)=>this.replace(X(this.get(Y)),Y)}}class mR extends kQ{set;constructor(X,Y,Q){super(X,Y,(J,$)=>m(Q(J)));this.set=Q}replace(X,Y){return this.set(X)}modify(X){return(Y)=>x8(ZX(this.getResult(Y),(Q)=>this.set(X(Q))),()=>Y)}}function sX(X){let Y=fR(X);switch(Y._tag){case"IsoNode":return new yR(X,Y.get,Y.set);case"LensNode":return new hR(X,Y.get,Y.set);case"PrismNode":return new mR(X,Y.get,Y.set);case"OptionalNode":return new kQ(X,Y.get,Y.set)}}function N$(X){if(Array.isArray(X))return X.slice();if(typeof X==="object"&&X!==null){let Y=Object.getPrototypeOf(X);if(Y!==Object.prototype&&Y!==null)throw Error("Cannot clone object with non-Object constructor or null prototype");return{...X}}return X}var fR=X1((X)=>{switch(X._tag){case"IdentityNode":return{_tag:"IsoNode",get:u,set:u};case"IsoNode":case"LensNode":case"PrismNode":case"OptionalNode":return{_tag:X._tag,get:X.get,set:X.set};case"PathNode":return{_tag:"LensNode",get:(Y)=>{let Q=X.path,J=Y;for(let $=0,G=Q.length;$<G;$++)J=J[Q[$]];return J},set:(Y,Q)=>{let J=X.path,$=N$(Q),G=$,Z=0;for(;Z<J.length-1;Z++){let H=J[Z];k(G,H,N$(G[H])),G=G[H]}let K=J[Z];return k(G,K,Y),$}};case"CheckNode":return{_tag:"PrismNode",get:(Y)=>x4(wF(X.checks,Y),String),set:u};case"CompositionNode":{let Y=X.nodes.map(fR),Q=Y.reduce((J,$)=>Vc(J,$._tag),"IsoNode");return{_tag:Q,get:(J)=>{for(let $=0;$<Y.length;$++){let G=Y[$],Z=G.get(J);if(U$(G._tag)){if(J0(Z))return Z;J=Z.success}else J=Z}return U$(Q)?m(J):J},set:(J,$)=>{let G=$,Z=Y.length,K=Array(Z+1);K[0]=$;for(let H=0;H<Z;H++){let W=Y[H];if(U$(W._tag)){let D=W.get($);if(J0(D))return Q==="OptionalNode"?D:G;$=D.success}else $=W.get($);K[H+1]=$}for(let H=Z-1;H>=0;H--){let W=Y[H];if(pR(W._tag))J=W.set(J);else if(W._tag==="LensNode")J=W.set(J,K[H]);else{let D=W.set(J,K[H]);if(J0(D))return D;J=D.success}}return Q==="OptionalNode"?m(J):J}}}}});function U$(X){return X==="PrismNode"||X==="OptionalNode"}function pR(X){return X==="IsoNode"||X==="PrismNode"}function Vc(X,Y){switch(X){case"IsoNode":return Y;case"LensNode":return U$(Y)?"OptionalNode":"LensNode";case"PrismNode":return pR(Y)?"PrismNode":"OptionalNode";case"OptionalNode":return"OptionalNode"}}var Bc=sX(SR);function V$(){return Bc}var f$={};k6(f$,{webUrl:()=>jt,webSegment:()=>MC,webQueryParameters:()=>IC,webPath:()=>jC,webFragments:()=>wC,webAuthority:()=>EC,uuid:()=>zt,uniqueArray:()=>V5,ulid:()=>Ht,uint8ClampedArray:()=>BC,uint8Array:()=>VC,uint32Array:()=>NC,uint16Array:()=>DC,tuple:()=>Z0,toStringMethod:()=>X6,subarray:()=>Xt,stringify:()=>s0,stringMatching:()=>ze,string:()=>e0,stream:()=>G4,statistics:()=>Yi,sparseArray:()=>zC,shuffledSubarray:()=>Yt,set:()=>qC,schedulerFor:()=>ut,scheduler:()=>dt,scheduledModelRun:()=>ft,sample:()=>eo,resetConfigureGlobal:()=>Qo,record:()=>GW,readConfigureGlobal:()=>eX,property:()=>_o,pre:()=>xc,option:()=>B8,oneof:()=>K1,object:()=>ba,noShrink:()=>b$,noBias:()=>S$,nat:()=>$4,modelRun:()=>ht,mixedCase:()=>Na,memo:()=>Za,maxSafeNat:()=>Ys,maxSafeInteger:()=>YC,mapToConstant:()=>v9,map:()=>ZW,lorem:()=>Ja,limitShrink:()=>Ae,letrec:()=>$C,jsonValue:()=>FC,json:()=>fa,ipV6:()=>JC,ipV4Extended:()=>QC,ipV4:()=>kW,integer:()=>E0,int8Array:()=>UC,int32Array:()=>WC,int16Array:()=>HC,infiniteStream:()=>ua,hash:()=>k$,hasToStringMethod:()=>qW,hasCloneMethod:()=>D5,hasAsyncToStringMethod:()=>OW,getDepthContextFor:()=>RW,gen:()=>Gi,func:()=>an,float64Array:()=>KC,float32Array:()=>ZC,float:()=>tE,falsy:()=>ki,entityGraph:()=>ns,emailAddress:()=>_n,double:()=>h$,domain:()=>IW,dictionary:()=>CW,defaultReportMessage:()=>TE,date:()=>xE,createDepthIdentifier:()=>AW,context:()=>gi,constantFrom:()=>M6,constant:()=>y0,configureGlobal:()=>Yo,compareFunc:()=>rn,compareBooleanFunc:()=>ln,commands:()=>St,cloneMethod:()=>H1,cloneIfNeeded:()=>M9,clone:()=>oi,check:()=>AE,chainUntil:()=>vE,boolean:()=>iQ,bigUint64Array:()=>lt,bigInt64Array:()=>ct,bigInt:()=>Z4,base64String:()=>sa,asyncToStringMethod:()=>V8,asyncStringify:()=>LW,asyncProperty:()=>$o,asyncModelRun:()=>mt,asyncDefaultReportMessage:()=>FE,assert:()=>ao,array:()=>M0,anything:()=>TC,__version:()=>Ee,__type:()=>Pe,__commitHash:()=>Ce,VerbosityLevel:()=>Go,Value:()=>g,Stream:()=>K0,Random:()=>TW,PreconditionFailure:()=>K4,ExecutionStatus:()=>Mo,Arbitrary:()=>m0});var qc=class X{constructor(Y){this.seed=Y}clone(){return new X(this.seed)}next(){let Y=this.seed,Q=Math.imul(Y,214013)+2531011|0,J=Math.imul(Y,-1443076087)+505908858|0,$=Math.imul(Y,1170746341)+-755606699|0;this.seed=$;let G=(Q&-2147483649)>>16,Z=(J&-2147483649)>>16;return($&-2147483649)>>16|Z<<15|G<<30}jump(){this.seed=Math.imul(this.seed,1994129409)+916127744&4294967295}getState(){return[this.seed]}};function dR(X){return new qc(X)}var Oc=class X{constructor(Y,Q){this.states=Y,this.index=Q}clone(){return new X(this.states.slice(),this.index)}next(){let Y=this.states[this.index];return Y^=Y>>>11,Y^=Y<<7&2636928640,Y^=Y<<15&4022730752,Y^=Y>>>18,this.index=B$(this.states,this.index),Y}getState(){return[this.index,...this.states]}jump(){let Y=this.states.slice(),Q=this.index;this.index=B$(this.states,this.index);for(let J=19932;J>0;--J){if("SUSgbA\\W`E[]KN2RUSo8XVU?HKBFRl11E\\KoWOg5B]XEWG;BE;1:oVK[`B^Z9Qd23^XTnhL>]Unda4f[X;_j9H5QD=cN<5H`3bW>9bk1mjoI2fK0obmAAINOV:>Mek_V9dd<hZ\\gC3?Fm7FEk07QH_3PLm^@?^i\\QMkgP<]oLHmFnlecg5F@7U^@4jhZ?WZS0k@GHehmM36:5^9;>Hmm`co>k:KOSkSbIINb1VFf>LXgP>GUAQTD>Ci>XMGkUflLlb?_FaFUk@?5N7i70@;1o68ah@I<HFH7R2^J:G][Gf962ITWID9GWK8ElD2G5=DcHcL]cA]P2n7A=[<bInM;IHDQnJMReRXDWbVldnGEIPij`E08Xdci3@0c:IBbD4:Nk]?lEN9j^;T`0blZX7eiWE8c`<ak7j05FZi>AjUDh?M1B?^??FAXKThf<aBOXZf7jXYGK>R<;NHk3S9YhM7STJ6`:MIE`S@7298X8W>PNK=@;lLX<i\\TXLL<W@X[X54H]in8M;;n?kkQbajgAMY=Tf9b;ZKf0QUB2FHYWfnfkDoU9YkcLd95T>lK6GM1YL\\lid:J>KYS=iJ]Y>QlF>?R5_[5QeYC=66;A32Ac>OHk_ne^0g>bK:g;KFPgbGUcPR_Z=TX3H9d03bKZ2IhEPKBo>LSGWd0iFdV8C<Y:<>T[O6lC\\blaZ>GoAYP4clf^j1IfnZJ]QeDe2X<HE[LJNWnaCg[P]Co^:IRbWPY?97UePBlZNNHY6LOBM8P>=h?Ye:_f_Sb9Ki5GDYBF4dWeMfdg^ccPllNWM7G1\\UMdoYeOOD5^e@foA22G?ADYo5:FVG[bWo96;>3kc_c1Ab30>30;1@4F8g2hY?DJ4[LOL;ZLLKo2]jo>[KMDUcR279N_kF=3WL@Dd620bMTdA\\U9k``ef2iD9JgJ8CZBHS>F^Uk;<laeaeHS<15OSeS`PcSSKBRBFY]aQ=EgUXGNg=?d56`KA@2BejY0^[_DCX`L=CGMT=BW^6S1i@2ATBVk>3_ocRA>2U:4GPQ6o>5jX2HIcV3S@On6KB<[SKB?FC_AAji9agbBFkAi\\;4I\\UJ]c36Ub@[;gQACVGY<V]SDJBUU]La\\_a@JdOO8gm2T0DJMa:8Hf7>E]noQ[1Kambn??QQ]S?1i0oMGOijb\\aGY6lQ^CJ?9bFle8<eH4UUjBINX;n8@VOA5ah^URV49B[A?ONHhHAC1J5;;h0SXYlG^0W=eJdHh^K4SGe=1HZLLam;D<Q3AOdbPcdX``82\\jo0En8jRVGC73WMCF9`d:0heS?80?C188cSn7H9<daZ]MgS4Pb^1HkA:1PU^5>^h_g[RQV@PnYBRI_]`B]Bh@Uk03eXGY`I16L76H28X`R>IROMeNVUdU[:lghLhPCQZ:4a<30YBZCYnXe[?;jc8gKI2QH2MjnWBm4nGCZW`aVU2a;P<AMI25mlW_Nm][2?b6o851X@lAm]YZ`bWRF1g<Ga:T]1NXH5Veja5P9S9>:aNg:Th1Y=5o78K>LQ8hW@5S?I83Lk5Xk;j5@I3o[d:4RjE^oS30:WP9gC\\i8aSI>QRE@4lP:7lDg8g2`Ql[2I8aBU\\BQ?B4_clL9Q]S;^e1Ob5[>3JER2`c7B=o]fPOWO<DGi;Niba1PoWPPE_Q3aX0OB0mZej\\f_M[J4Y6]1`h2MkF[GiW8Q^d3^_=<I1N2Q7]2<2j[iP7V3V821FaI]A`93bC^Z\\G=WJ;^Ih?B97_iIF@\\Dl<eK1je8SNTWo_=XFMZH<<JYLZ^YQMPgYOV45K_:]kSI8^XlO0]GY=VUfe_C_F6TOcoAlVUH:o=WhhT@K`2KFhe<3\\KXQ>W:M?S_4S5d@J^`[AGA7@3]DnGSCO`\\?E8HT75^d9\\:m\\m1egIfk8cd6bD9\\eU8\\n[Pb0Cgd^S0n9kGJHb]i5XodlKHc34Fhi9K>0U5WK`>7Ff2^KL=WC6:kc?e5C^a1T1:4:^S5flXlGNIj08AfO?Dh7T7dWO>E]NI9?ob7B7P_h[4TEP[EU;GllFTnSmg9:\\[N]<SAoKP_kPlG56A:I3T6EG8Hj=XnUE`KT5U@OQ?]7[N^MFN1_NU4KO_3::Le`8IL9[1Z1H1;V3SC\\N3]S@4U[F2mhT5dYM7[4Pg_Na0_8WTH0`bgceQS8]EG;XgD4Ib4iLTP@kE79Mn>AYRJA1U5^Blhgno:aHVYc03c3J0Vc9FjEV^M75Zfd8kVC9>iJDk`AJ[6f7DK2D^DL\\AX:6b5h31XH;RQB\\N<ZSM=J;6L[`UW^eOIFc1Y]6_dfedIe4ARh72mTXC0WND_IDHVCZRDE0eODARCEETQI5TPUQE=jEH5bS?LP[ai`F5ABRYDo2o\\@=]GT?_9;hc4Lm:\\SF9k1T<0E@fX9BG[]g0nY7k[Qmi@la8`PF0j6@Q?Ii7bLkXQ<lLHf]`:DCh@9JY5>hEVLTdhL\\b1EB0lLh<=WaO@F<;8g<d:@e:LA:cFIEdmQh7hNHfSRToW?8N4:Z1K;XEDRO;OIDh<UdVln?bjgL>?VE98[B\\K<BVjkG8LiSX;fb>jf?DUK00Aih<WY6QD6cEnHBZ8iN_fd<G8Ci`11RUW2QlW]IXV:m?;J0GXXHfGNQ>:D`=fLPbO?VOTEYLj^cNj5PM>jKB5HVjJ4U7lXaTQNL9<@\\1`m\\Ug@VQHd7>jW=ca0`miF7;N0F=GjoQ`RFchKMGTmn8cF@Oh4GGCm7m2`U9j93Tb>=kSERjE_J939F01I1;`<ijk_=_Vn=7RVAI6fnQI5KlF:C44bN<<8K=Z<2TP<1]5?<dB>^LA=ebloE2Y2:9lkh0\\<YKbHD97iE`<C5oj^1>X:??`H6BXF2hG1Q[dF0Q=>W=J?7C\\k1T?<;R44oW?1hY^G8Zm]ZKnfOf0eCFYo6?=D8?<`6HU5SXh1;=:23LmV_FSi;OJfV<^?GkIDPISeHg1LaGE:V3Y3K3H<QJfbY?=;ldZRhnhQT_mGXDLFXXhSONE6Do_0iNZagB:BPGOTH;VhHUTd6LhQm^[;dO]5Hlkg<R:F<Kn\\:I:EGojgWZ2X@SYO_dlH;G8S<>oEKabY`:oU;=JW7ig?S?EYb86b7n8ce\\]IRa]koiWY<RfO;5kUI;7lVeC?[@ZaXDiF04B8R]bg@>O<mQDoUcBLcf^f>m2kMBUloD>Ze@NN^Z11TM`inXYhE_I=kA`:ZF4d\\>`L@;ZP[`ENU5cL[BV6\\Z?Di76:jg3hE6oG6jFc8kP=[GS1;WSedYQW1:U4\\OF32GgmMC<AjO]872bdBb`bKAA?8j78b>T3VfcUB2m4J^CPRU;8dScI]LU]^bBYA5_3:Y0N5i^?200000".charCodeAt(J/6|0)-48&1<<J%6)uR(this.states,this.index,Y,Q);this.index=B$(this.states,this.index)}uR(this.states,this.index,Y,Q)}};function uR(X,Y,Q,J){let $=0;if(J>=Y){for(;$<624-J;$++)X[$+Y]^=Q[$+J];for(;$<624-Y;$++)X[$+Y]^=Q[$+J-624];for(;$<624;$++)X[$+Y-624]^=Q[$+J-624]}else{for(;$<624-Y;$++)X[$+Y]^=Q[$+J];for(;$<624-J;$++)X[$+Y-624]^=Q[$+J];for(;$<624;$++)X[$+Y-624]^=Q[$+J-624]}}function B$(X,Y){if(Y<227){let Q=X[Y]&2147483648|X[Y+1]&2147483647;return X[Y]=X[Y+397]^Q>>>1^-(Q&1)&2567483615,Y+1}else if(Y<623){let Q=X[Y]&2147483648|X[Y+1]&2147483647;return X[Y]=X[Y+397-624]^Q>>>1^-(Q&1)&2567483615,Y+1}else{let Q=X[Y]&2147483648|X[0]&2147483647;return X[Y]=X[396]^Q>>>1^-(Q&1)&2567483615,0}}function Lc(X){for(let Y=0;Y!==624;++Y)B$(X,Y)}function cR(X){let Y=[X|0];for(let Q=1;Q!==624;++Q){let J=Y[Q-1]^Y[Q-1]>>>30;Y.push(Math.imul(1812433253,J)+Q|0)}return Lc(Y),new Oc(Y,0)}var Tc=[1667051007,2321340297,1548169110,304075285],Fc=class X{constructor(Y,Q,J,$){this.s01=Y,this.s00=Q,this.s11=J,this.s10=$}clone(){return new X(this.s01,this.s00,this.s11,this.s10)}next(){let Y=this.s00^this.s00<<23,Q=this.s01^(this.s01<<23|this.s00>>>9),J=this.s10,$=this.s11,G=this.s00+J|0;return this.s01=$,this.s00=J,this.s11=Q^$^Q>>>18^$>>>5,this.s10=Y^J^(Y>>>18|Q<<14)^(J>>>5|$<<27),G}jump(){let Y=0,Q=0,J=0,$=0,G=this.s01,Z=this.s00,K=this.s11,H=this.s10;for(let W=0;W!==4;++W){let D=Tc[W];for(let U=1;U;U<<=1){if(D&U)Y^=G,Q^=Z,J^=K,$^=H;let N=Z^Z<<23,V=G^(G<<23|Z>>>9);G=K,Z=H,H=N^H^(N>>>18|V<<14)^(H>>>5|K<<27),K=V^K^V>>>18^K>>>5}}this.s01=Y,this.s00=Q,this.s11=J,this.s10=$}getState(){return[this.s01,this.s00,this.s11,this.s10]}};function OH(X){return new Fc(-1,~X,X|0,0)}var Rc=[3639956645,3750757012,1261568508,386426335],Ac=class X{constructor(Y,Q,J,$){this.s01=Y,this.s00=Q,this.s11=J,this.s10=$}clone(){return new X(this.s01,this.s00,this.s11,this.s10)}next(){let Y=this.s00+this.s10|0,Q=this.s10^this.s00,J=this.s11^this.s01,$=this.s00,G=this.s01;return this.s00=$<<24^G>>>8^Q^Q<<16,this.s01=G<<24^$>>>8^J^(J<<16|Q>>>16),this.s10=J<<5^Q>>>27,this.s11=Q<<5^J>>>27,Y}jump(){let Y=0,Q=0,J=0,$=0,G=this.s01,Z=this.s00,K=this.s11,H=this.s10;for(let W=0;W!==4;++W){let D=Rc[W];for(let U=1;U;U<<=1){if(D&U)Y^=G,Q^=Z,J^=K,$^=H;let N=H^Z,V=K^G,z=Z,q=G;Z=z<<24^q>>>8^N^N<<16,G=q<<24^z>>>8^V^(V<<16|N>>>16),H=V<<5^N>>>27,K=N<<5^V>>>27}}this.s01=Y,this.s00=Q,this.s11=J,this.s10=$}getState(){return[this.s01,this.s00,this.s11,this.s10]}};function lR(X){return new Ac(-1,~X,X|0,0)}function oR(X,Y){for(let Q=0;Q!==Y;++Q)X.next()}var iR=BigInt,Pc=4294967296n;function nR(X,Y,Q){let J=Q-Y+1n,$=Pc,G=1;while($<J)$<<=32n,++G;let Z=rR(G,X);if(Z<J)return Z+Y;if(Z+J<$)return Z%J+Y;let K=$-$%J;while(Z>=K)Z=rR(G,X);return Z%J+Y}function rR(X,Y){let Q=iR(Y.next()+2147483648);for(let J=1;J<X;++J){let $=Y.next();Q=(Q<<32n)+iR($+2147483648)}return Q}function bQ(X,Y){let Q=Y>2?~~(4294967296/Y)*Y:4294967296,J=X.next()+2147483648;while(J>=Q)J=X.next()+2147483648;return J%Y}function LH(X,Y){if(Y<0){let Q=-Y;X.sign=-1,X.data[0]=~~(Q/4294967296),X.data[1]=Q>>>0}else X.sign=1,X.data[0]=~~(Y/4294967296),X.data[1]=Y>>>0;return X}function Ec(X,Y,Q){let J=Y.data[1],$=Y.data[0],G=Y.sign,Z=Q.data[1],K=Q.data[0],H=Q.sign;if(X.sign=1,G===1&&H===-1){let q=J+Z,F=$+K+(q>4294967295?1:0);return X.data[0]=F>>>0,X.data[1]=q>>>0,X}let W=J,D=$,U=Z,N=K;if(G===-1)W=Z,D=K,U=J,N=$;let V=0,z=W-U;if(z<0)V=1,z=z>>>0;return X.data[0]=D-N-V,X.data[1]=z,X}function Cc(X,Y,Q){let J=Q[0]+1;Y[0]=bQ(X,J),Y[1]=bQ(X,4294967296);while(Y[0]>=Q[0]&&(Y[0]!==Q[0]||Y[1]>=Q[1]))Y[0]=bQ(X,J),Y[1]=bQ(X,4294967296);return Y}var wc=Number.MAX_SAFE_INTEGER,Mc={sign:1,data:[0,0]},jc={sign:1,data:[0,0]},sR={sign:1,data:[0,0]},TH=[0,0];function Ic(X,Y,Q,J){let $=J<=wc?LH(sR,J):Ec(sR,LH(Mc,Q),LH(jc,Y));if($.data[1]===4294967295)$.data[0]+=1,$.data[1]=0;else $.data[1]+=1;return Cc(X,TH,$.data),TH[0]*4294967296+TH[1]+Y}function z$(X,Y,Q){let J=Q-Y;if(J<=4294967295)return bQ(X,J+1)+Y;return Ic(X,Y,Q,J)}var aR=Symbol.for("fast-check/PreconditionFailure"),K4=class extends Error{constructor(X=!1){super();this.interruptExecution=X,this.footprint=aR}static isFailure(X){return X!==null&&X!==void 0&&X.footprint===aR}};function xc(X){if(!X)throw new K4}var vc=class{[Symbol.iterator](){return this}next(X){return{value:X,done:!0}}},Sc=new vc;function kc(){return Sc}function*bc(X,Y){for(let Q of X)yield Y(Q)}function*gc(X,Y){for(let Q of X)yield*Y(Q)}function*yc(X,Y){for(let Q of X)if(Y(Q))yield Q}function*hc(X,Y){for(let Q=0;Q<Y;++Q){let J=X.next();if(J.done)break;yield J.value}}function*mc(X,Y){let Q=X.next();while(!Q.done&&Y(Q.value))yield Q.value,Q=X.next()}function*fc(X,Y){for(let Q=X.next();!Q.done;Q=X.next())yield Q.value;for(let Q of Y)for(let J=Q.next();!J.done;J=Q.next())yield J.value}var pc=Symbol.iterator,K0=class X{static nil(){return new X(kc())}static of(...Y){return new X(Y[pc]())}constructor(Y){this.g=Y}next(){return this.g.next()}[Symbol.iterator](){return this.g}map(Y){return new X(bc(this.g,Y))}flatMap(Y){return new X(gc(this.g,Y))}dropWhile(Y){let Q=!1;function*J($){if(Q||!Y($))Q=!0,yield $}return this.flatMap(J)}drop(Y){if(Y<=0)return this;let Q=0;function J(){return Q++<Y}return this.dropWhile(J)}takeWhile(Y){return new X(mc(this.g,Y))}take(Y){return new X(hc(this.g,Y))}filter(Y){return new X(yc(this.g,Y))}every(Y){for(let Q of this.g)if(!Y(Q))return!1;return!0}has(Y){for(let Q of this.g)if(Y(Q))return[!0,Q];return[!1,null]}join(...Y){return new X(fc(this.g,Y))}getNthOrLast(Y){let Q=Y,J=null;for(let $ of this.g){if(Q--===0)return $;J=$}return J}};function G4(X){return new K0(X)}var H1=Symbol.for("fast-check/cloneMethod");function D5(X){return X!==null&&(typeof X==="object"||typeof X==="function")&&H1 in X&&typeof X[H1]==="function"}function M9(X){return D5(X)?X[H1]():X}var dc=Object.defineProperty,g=class{constructor(X,Y,Q){if(this.value_=X,this.context=Y,this.hasToBeCloned=Q!==void 0||D5(X),this.readOnce=!1,this.value=X,this.hasToBeCloned)dc(this,"value",{get:Q!==void 0?Q:this.getValue,enumerable:!1,configurable:!1})}getValue(){if(this.hasToBeCloned){if(!this.readOnce)return this.readOnce=!0,this.value_;return this.value_[H1]()}return this.value_}},m0=class{filter(X){return new lc(this,X)}map(X,Y){return new cc(this,X,Y)}chain(X){return new uc(this,X)}},uc=class extends m0{constructor(X,Y){super();this.arb=X,this.chainer=Y}generate(X,Y){let Q=X.clone(),J=this.arb.generate(X,Y);return this.valueChainer(J,X,Q,Y)}canShrinkWithoutContext(X){return!1}shrink(X,Y){if(this.isSafeContext(Y))return(!Y.stoppedForOriginal?this.arb.shrink(Y.originalValue,Y.originalContext).map((Q)=>this.valueChainer(Q,Y.clonedMrng.clone(),Y.clonedMrng,Y.originalBias)):K0.nil()).join(Y.chainedArbitrary.shrink(X,Y.chainedContext).map((Q)=>{let J={...Y,chainedContext:Q.context,stoppedForOriginal:!0};return new g(Q.value_,J)}));return K0.nil()}valueChainer(X,Y,Q,J){let $=this.chainer(X.value_),G=$.generate(Y,J),Z={originalBias:J,originalValue:X.value_,originalContext:X.context,stoppedForOriginal:!1,chainedArbitrary:$,chainedContext:G.context,clonedMrng:Q};return new g(G.value_,Z)}isSafeContext(X){return X!==null&&X!==void 0&&typeof X==="object"&&"originalBias"in X&&"originalValue"in X&&"originalContext"in X&&"stoppedForOriginal"in X&&"chainedArbitrary"in X&&"chainedContext"in X&&"clonedMrng"in X}};function rP(X,Y){let Q=X.value,J=Y(Q);if(X.hasToBeCloned&&(typeof J==="object"&&J!==null||typeof J==="function")&&Object.isExtensible(J)&&!D5(J))Object.defineProperty(J,H1,{get:()=>()=>rP(X,Y)[0]});return[J,Q]}function tR(X,Y){let[Q,J]=rP(X,Y);return new g(Q,{originalValue:J,originalContext:X.context})}var cc=class extends m0{constructor(X,Y,Q){super();this.arb=X,this.mapper=Y,this.unmapper=Q,this.bindValueMapper=(J)=>tR(J,Y)}generate(X,Y){let Q=this.arb.generate(X,Y);if(!Q.hasToBeCloned){let J=Q.value;return new g(this.mapper(J),{originalValue:J,originalContext:Q.context})}return tR(Q,this.mapper)}canShrinkWithoutContext(X){if(this.unmapper!==void 0)try{let Y=this.unmapper(X);return this.arb.canShrinkWithoutContext(Y)}catch{return!1}return!1}shrink(X,Y){if(this.isSafeContext(Y))return this.arb.shrink(Y.originalValue,Y.originalContext).map(this.bindValueMapper);if(this.unmapper!==void 0){let Q=this.unmapper(X);return this.arb.shrink(Q,void 0).map(this.bindValueMapper)}return K0.nil()}isSafeContext(X){return X!==null&&X!==void 0&&typeof X==="object"&&"originalValue"in X&&"originalContext"in X}},lc=class extends m0{constructor(X,Y){super();this.arb=X,this.refinement=Y,this.bindRefinementOnValue=(Q)=>this.refinementOnValue(Q)}generate(X,Y){while(!0){let Q=this.arb.generate(X,Y);if(this.refinementOnValue(Q))return Q}}canShrinkWithoutContext(X){return this.arb.canShrinkWithoutContext(X)&&this.refinement(X)}shrink(X,Y){return this.arb.shrink(X,Y).filter(this.bindRefinementOnValue)}refinementOnValue(X){return this.refinement(X.value)}};function nP(X){return typeof X==="object"&&X!==null&&"generate"in X&&"shrink"in X&&"canShrinkWithoutContext"in X}function sP(X){if(!nP(X))throw Error("Unexpected value received: not an instance of Arbitrary")}var aP=Function.prototype.apply,FH=Symbol("apply");function oc(X){try{return X.apply}catch{return}}function ic(X,Y,Q){let J=X;J[FH]=aP;let $=J[FH](Y,Q);return delete J[FH],$}function V0(X,Y,Q){if(oc(X)===aP)return X.apply(Y,Q);return ic(X,Y,Q)}var tP=Array,b=BigInt,rc=BigInt64Array,nc=BigUint64Array,eP=Boolean,x$=Date,y=Error,XE=Float32Array,YE=Float64Array,sc=Int8Array,ac=Int16Array,tc=Int32Array,D8=Number,p1=String,tX=Set,ec=Uint8Array,Xl=Uint8ClampedArray,Yl=Uint16Array,Ql=Uint32Array,Jl=encodeURIComponent,N8=Map,P$=Symbol,eR=Array.prototype.forEach,XA=Array.prototype.indexOf,YA=Array.prototype.join,QA=Array.prototype.map,JA=Array.prototype.flat,$A=Array.prototype.filter,_A=Array.prototype.push,GA=Array.prototype.pop,ZA=Array.prototype.splice,KA=Array.prototype.slice,HA=Array.prototype.sort,WA=Array.prototype.every;function $l(X){try{return X.forEach}catch{return}}function _l(X){try{return X.indexOf}catch{return}}function Gl(X){try{return X.join}catch{return}}function Zl(X){try{return X.map}catch{return}}function Kl(X){try{return X.flat}catch{return}}function Hl(X){try{return X.filter}catch{return}}function Wl(X){try{return X.push}catch{return}}function Ul(X){try{return X.pop}catch{return}}function Dl(X){try{return X.splice}catch{return}}function Nl(X){try{return X.slice}catch{return}}function Vl(X){try{return X.sort}catch{return}}function Bl(X){try{return X.every}catch{return}}function QE(X,Y){if($l(X)===eR)return X.forEach(Y);return V0(eR,X,[Y])}function fQ(X,...Y){if(_l(X)===XA)return X.indexOf(...Y);return V0(XA,X,Y)}function h0(X,...Y){if(Gl(X)===YA)return X.join(...Y);return V0(YA,X,Y)}function O0(X,Y){if(Zl(X)===QA)return X.map(Y);return V0(QA,X,[Y])}function zl(X,Y){if(Kl(X)===JA)return[].flat(),X.flat(Y);return V0(JA,X,[Y])}function ql(X,Y){if(Hl(X)===$A)return X.filter(Y);return V0($A,X,[Y])}function I(X,...Y){if(Wl(X)===_A)return X.push(...Y);return V0(_A,X,Y)}function JE(X){if(Ul(X)===GA)return X.pop();return V0(GA,X,[])}function $E(X,...Y){if(Dl(X)===ZA)return X.splice(...Y);return V0(ZA,X,Y)}function Z1(X,...Y){if(Nl(X)===KA)return X.slice(...Y);return V0(KA,X,Y)}function _E(X,...Y){if(Vl(X)===HA)return X.sort(...Y);return V0(HA,X,Y)}function GE(X,...Y){if(Bl(X)===WA)return X.every(...Y);return V0(WA,X,Y)}var UA=Date.prototype.getTime,DA=Date.prototype.toISOString;function Ol(X){try{return X.getTime}catch{return}}function Ll(X){try{return X.toISOString}catch{return}}function v$(X){if(Ol(X)===UA)return X.getTime();return V0(UA,X,[])}function Tl(X){if(Ll(X)===DA)return X.toISOString();return V0(DA,X,[])}var NA=Set.prototype.add,VA=Set.prototype.has;function Fl(X){try{return X.add}catch{return}}function Rl(X){try{return X.has}catch(Y){return}}function pQ(X,Y){if(Fl(X)===NA)return X.add(Y);return V0(NA,X,[Y])}function J4(X,Y){if(Rl(X)===VA)return X.has(Y);return V0(VA,X,[Y])}var BA=WeakMap.prototype.set,zA=WeakMap.prototype.get;function Al(X){try{return X.set}catch(Y){return}}function Pl(X){try{return X.get}catch(Y){return}}function El(X,Y,Q){if(Al(X)===BA)return X.set(Y,Q);return V0(BA,X,[Y,Q])}function Cl(X,Y){if(Pl(X)===zA)return X.get(Y);return V0(zA,X,[Y])}var qA=Map.prototype.set,OA=Map.prototype.get,LA=Map.prototype.has;function wl(X){try{return X.set}catch(Y){return}}function Ml(X){try{return X.get}catch(Y){return}}function jl(X){try{return X.has}catch(Y){return}}function aX(X,Y,Q){if(wl(X)===qA)return X.set(Y,Q);return V0(qA,X,[Y,Q])}function BX(X,Y){if(Ml(X)===OA)return X.get(Y);return V0(OA,X,[Y])}function Il(X,Y){if(jl(X)===LA)return X.has(Y);return V0(LA,X,[Y])}var TA=String.prototype.split,FA=String.prototype.startsWith,RA=String.prototype.endsWith,AA=String.prototype.substring,PA=String.prototype.toLowerCase,EA=String.prototype.toUpperCase,CA=String.prototype.padStart,wA=String.prototype.charCodeAt,MA=String.prototype.normalize,jA=String.prototype.replace;function xl(X){try{return X.split}catch{return}}function vl(X){try{return X.startsWith}catch{return}}function Sl(X){try{return X.endsWith}catch{return}}function kl(X){try{return X.substring}catch{return}}function bl(X){try{return X.toLowerCase}catch{return}}function gl(X){try{return X.toUpperCase}catch{return}}function yl(X){try{return X.padStart}catch{return}}function hl(X){try{return X.charCodeAt}catch{return}}function ml(X){try{return X.normalize}catch(Y){return}}function fl(X){try{return X.replace}catch{return}}function d1(X,...Y){if(xl(X)===TA)return X.split(...Y);return V0(TA,X,Y)}function pl(X,...Y){if(vl(X)===FA)return X.startsWith(...Y);return V0(FA,X,Y)}function dl(X,...Y){if(Sl(X)===RA)return X.endsWith(...Y);return V0(RA,X,Y)}function u0(X,...Y){if(kl(X)===AA)return X.substring(...Y);return V0(AA,X,Y)}function lH(X){if(bl(X)===PA)return X.toLowerCase();return V0(PA,X,[])}function NW(X){if(gl(X)===EA)return X.toUpperCase();return V0(EA,X,[])}function ul(X,...Y){if(yl(X)===CA)return X.padStart(...Y);return V0(CA,X,Y)}function j9(X,Y){if(hl(X)===wA)return X.charCodeAt(Y);return V0(wA,X,[Y])}function cl(X,Y){if(ml(X)===MA)return X.normalize(Y);return V0(MA,X,[Y])}function ll(X,Y,Q){if(fl(X)===jA)return X.replace(Y,Q);return V0(jA,X,[Y,Q])}var IA=Number.prototype.toString;function ol(X){try{return X.toString}catch{return}}function dQ(X,...Y){if(ol(X)===IA)return X.toString(...Y);return V0(IA,X,Y)}var il=Object.prototype.hasOwnProperty,rl=Object.prototype.toString;function ZE(X,Y){return V0(il,X,[Y])}function oH(X){return V0(rl,X,[])}var nl=Error.prototype.toString;function sl(X){return V0(nl,X,[])}var al=class{constructor(X){this.producer=X}[Symbol.iterator](){if(this.it===void 0)this.it=this.producer();return this.it}next(){if(this.it===void 0)this.it=this.producer();return this.it.next()}};function _4(X){return new al(X)}var KE=Array.isArray,tl=Object.defineProperty;function VW(X,Y,Q){return tl(X,H1,{value:()=>{let J=[];for(let $=0;$!==Q.length;++$){let G=Q[$];if(G===void 0)G=new g(X[$],Y[$]);I(J,G.value)}return VW(J,Y,Q),J}})}function HE(X,Y,Q){let J=[],$=KE(Q)?Q:[];for(let G=0;G!==X.length;++G)I(J,_4(()=>X[G].shrink(Y[G],$[G]).map((Z)=>{let K=!1,H=[],W=[],D=[];for(let U=0;U!==X.length;++U){let N=U===G?Z:new g(M9(Y[U]),$[U]);if(N.hasToBeCloned)K=!0,D[U]=N;I(H,N.value),I(W,N.context)}if(K)VW(H,W,D);return new g(H,W)})));return K0.nil().join(...J)}var el=class extends m0{constructor(X){super();this.arbs=X;for(let Y=0;Y!==X.length;++Y){let Q=X[Y];if(Q===null||Q===void 0||Q.generate===null||Q.generate===void 0)throw Error(`Invalid parameter encountered at index ${Y}: expecting an Arbitrary`)}}generate(X,Y){let Q=!1,J=[],$=[],G=[];for(let Z=0;Z!==this.arbs.length;++Z){let K=this.arbs[Z].generate(X,Y);if(K.hasToBeCloned)Q=!0,G[Z]=K;I(J,K.value),I($,K.context)}if(Q)VW(J,$,G);return new g(J,$)}canShrinkWithoutContext(X){if(!KE(X)||X.length!==this.arbs.length)return!1;for(let Y=0;Y!==this.arbs.length;++Y)if(!this.arbs[Y].canShrinkWithoutContext(X[Y]))return!1;return!0}shrink(X,Y){return HE(this.arbs,X,Y)}};function Z0(...X){return new el(X)}var Xo=Math.log;function WE(X){return 2+~~(Xo(X+1)*0.4342944819032518)}var BW={};function Yo(X){BW=X}function eX(){return BW}function Qo(){BW={}}var uQ=Symbol("UndefinedContextPlaceholder");function I9(X){if(X.context!==void 0)return X;if(X.hasToBeCloned)return new g(X.value_,uQ,()=>X.value);return new g(X.value_,uQ)}var xA=()=>{},Jo=class{constructor(X,Y){this.arb=X,this.predicate=Y;let{asyncBeforeEach:Q,asyncAfterEach:J,beforeEach:$,afterEach:G}=eX()||{};if(Q!==void 0&&$!==void 0)throw y(`Global "asyncBeforeEach" and "beforeEach" parameters can't be set at the same time when running async properties`);if(J!==void 0&&G!==void 0)throw y(`Global "asyncAfterEach" and "afterEach" parameters can't be set at the same time when running async properties`);this.beforeEachHook=Q||$||xA,this.afterEachHook=J||G||xA}isAsync(){return!0}generate(X,Y){return I9(this.arb.generate(X,Y!==void 0?WE(Y):void 0))}shrink(X){if(X.context===void 0&&!this.arb.canShrinkWithoutContext(X.value_))return K0.nil();let Y=X.context!==uQ?X.context:void 0;return this.arb.shrink(X.value_,Y).map(I9)}async runBeforeEach(){await this.beforeEachHook()}async runAfterEach(){await this.afterEachHook()}async run(X){try{let Y=await this.predicate(X);return Y===void 0||Y===!0?null:{error:new y("Property failed by returning false")}}catch(Y){if(K4.isFailure(Y))return Y;return{error:Y}}}beforeEach(X){let Y=this.beforeEachHook;return this.beforeEachHook=()=>X(Y),this}afterEach(X){let Y=this.afterEachHook;return this.afterEachHook=()=>X(Y),this}},UE=class extends m0{constructor(X){super();this.arb=X}generate(X,Y){return I9(this.arb.generate(X,Y))}canShrinkWithoutContext(X){return!0}shrink(X,Y){if(Y===void 0&&!this.arb.canShrinkWithoutContext(X))return K0.nil();let Q=Y!==uQ?Y:void 0;return this.arb.shrink(X,Q).map(I9)}};function $o(...X){if(X.length<2)throw Error("asyncProperty expects at least two parameters");let Y=Z1(X,0,X.length-1),Q=X[X.length-1];return QE(Y,sP),new Jo(Z0(...O0(Y,(J)=>new UE(J))),(J)=>Q(...J))}var vA=()=>{},DE=class{constructor(X,Y){this.arb=X,this.predicate=Y;let{beforeEach:Q=vA,afterEach:J=vA,asyncBeforeEach:$,asyncAfterEach:G}=eX()||{};if($!==void 0)throw y(`"asyncBeforeEach" can't be set when running synchronous properties`);if(G!==void 0)throw y(`"asyncAfterEach" can't be set when running synchronous properties`);this.beforeEachHook=Q,this.afterEachHook=J}isAsync(){return!1}generate(X,Y){return I9(this.arb.generate(X,Y!==void 0?WE(Y):void 0))}shrink(X){if(X.context===void 0&&!this.arb.canShrinkWithoutContext(X.value_))return K0.nil();let Y=X.context!==uQ?X.context:void 0;return this.arb.shrink(X.value_,Y).map(I9)}runBeforeEach(){this.beforeEachHook()}runAfterEach(){this.afterEachHook()}run(X){try{let Y=this.predicate(X);return Y===void 0||Y===!0?null:{error:new y("Property failed by returning false")}}catch(Y){if(K4.isFailure(Y))return Y;return{error:Y}}}beforeEach(X){let Y=this.beforeEachHook;return this.beforeEachHook=()=>X(Y),this}afterEach(X){let Y=this.afterEachHook;return this.afterEachHook=()=>X(Y),this}};function _o(...X){if(X.length<2)throw Error("property expects at least two parameters");let Y=Z1(X,0,X.length-1),Q=X[X.length-1];return QE(Y,sP),new DE(Z0(...O0(Y,(J)=>new UE(J))),(J)=>Q(...J))}var Go=function(X){return X[X.None=0]="None",X[X.Verbose=1]="Verbose",X[X.VeryVerbose=2]="VeryVerbose",X}({});function iH(X){if("unsafeNext"in X){if(X.unsafeJump===void 0)return{clone:()=>iH(X),next:()=>X.unsafeNext(),getState:()=>X.getState()};return{clone:()=>iH(X),next:()=>X.unsafeNext(),jump:()=>X.unsafeJump(),getState:()=>X.getState()}}return X}function NE(X){if("jump"in X&&typeof X.jump==="function")return X;return{clone:()=>NE(X),next:()=>X.next(),jump:()=>oR(X,42),getState:()=>X.getState()}}function y$(X){return NE(iH(X))}var Zo=Date.now,Ko=Math.min,Ho=Math.random,Wo=class{constructor(X){let Y=X||{};this.seed=Uo(Y),this.randomType=Do(Y),this.numRuns=No(Y),this.verbose=Vo(Y),this.maxSkipsPerRun=Y.maxSkipsPerRun!==void 0?Y.maxSkipsPerRun:100,this.timeout=AH(Y.timeout),this.skipAllAfterTimeLimit=AH(Y.skipAllAfterTimeLimit),this.interruptAfterTimeLimit=AH(Y.interruptAfterTimeLimit),this.markInterruptAsFailure=Y.markInterruptAsFailure===!0,this.skipEqualValues=Y.skipEqualValues===!0,this.ignoreEqualValues=Y.ignoreEqualValues===!0,this.logger=Y.logger!==void 0?Y.logger:(Q)=>{console.log(Q)},this.path=Y.path!==void 0?Y.path:"",this.unbiased=Y.unbiased===!0,this.examples=Y.examples!==void 0?Y.examples:[],this.endOnFailure=Y.endOnFailure===!0,this.reporter=Y.reporter,this.asyncReporter=Y.asyncReporter,this.includeErrorInReport=Y.includeErrorInReport===!0}toParameters(){return{seed:this.seed,randomType:this.randomType,numRuns:this.numRuns,maxSkipsPerRun:this.maxSkipsPerRun,timeout:this.timeout,skipAllAfterTimeLimit:this.skipAllAfterTimeLimit,interruptAfterTimeLimit:this.interruptAfterTimeLimit,markInterruptAsFailure:this.markInterruptAsFailure,skipEqualValues:this.skipEqualValues,ignoreEqualValues:this.ignoreEqualValues,path:this.path,logger:this.logger,unbiased:this.unbiased,verbose:this.verbose,examples:this.examples,endOnFailure:this.endOnFailure,reporter:this.reporter,asyncReporter:this.asyncReporter,includeErrorInReport:this.includeErrorInReport}}};function RH(X){return(Y)=>{return y$(X(Y))}}function Uo(X){if(X.seed===void 0)return Zo()^Ho()*4294967296;let Y=X.seed|0;if(X.seed===Y)return Y;return Y^(X.seed-Y)*4294967296}function Do(X){if(X.randomType===void 0)return OH;if(typeof X.randomType==="string")switch(X.randomType){case"mersenne":return RH(cR);case"congruential":case"congruential32":return RH(dR);case"xorshift128plus":return OH;case"xoroshiro128plus":return lR;default:throw Error(`Invalid random specified: '${X.randomType}'`)}let Y=X.randomType(0);if("min"in Y&&Y.min!==-2147483648)throw Error(`Invalid random number generator: min must equal -0x80000000, got ${String(Y.min)}`);if("max"in Y&&Y.max!==2147483647)throw Error(`Invalid random number generator: max must equal 0x7fffffff, got ${String(Y.max)}`);if(Y===y$(Y))return X.randomType;return RH(X.randomType)}function No(X){if(X.numRuns!==void 0)return X.numRuns;if(X.num_runs!==void 0)return X.num_runs;return 100}function Vo(X){if(X.verbose===void 0)return 0;if(typeof X.verbose==="boolean")return X.verbose===!0?1:0;if(X.verbose<=0)return 0;if(X.verbose>=2)return 2;return X.verbose|0}function AH(X){if(X===void 0)return;return Ko(X,2147483647)}function zW(X){return new Wo(X)}function Bo(X,Y,Q){let J=null;return{clear:()=>Q(J),promise:new Promise(($)=>{J=Y(()=>{$(new K4(!0))},X)})}}var SA=class{constructor(X,Y,Q,J,$,G){this.property=X,this.getTime=Y,this.interruptExecution=J,this.setTimeoutSafe=$,this.clearTimeoutSafe=G,this.skipAfterTime=this.getTime()+Q}isAsync(){return this.property.isAsync()}generate(X,Y){return this.property.generate(X,Y)}shrink(X){return this.property.shrink(X)}run(X){let Y=this.skipAfterTime-this.getTime();if(Y<=0){let Q=new K4(this.interruptExecution);if(this.isAsync())return Promise.resolve(Q);else return Q}if(this.interruptExecution&&this.isAsync()){let Q=Bo(Y,this.setTimeoutSafe,this.clearTimeoutSafe),J=Promise.race([this.property.run(X),Q.promise]);return J.then(Q.clear,Q.clear),J}return this.property.run(X)}runBeforeEach(){return this.property.runBeforeEach()}runAfterEach(){return this.property.runAfterEach()}},zo=(X,Y,Q)=>{let J=null;return{clear:()=>Q(J),promise:new Promise(($)=>{J=Y(()=>{$({error:new y(`Property timeout: exceeded limit of ${X} milliseconds`)})},X)})}},qo=class{constructor(X,Y,Q,J){this.property=X,this.timeMs=Y,this.setTimeoutSafe=Q,this.clearTimeoutSafe=J}isAsync(){return!0}generate(X,Y){return this.property.generate(X,Y)}shrink(X){return this.property.shrink(X)}async run(X){let Y=zo(this.timeMs,this.setTimeoutSafe,this.clearTimeoutSafe),Q=Promise.race([this.property.run(X),Y.promise]);return Q.then(Y.clear,Y.clear),Q}runBeforeEach(){return Promise.resolve(this.property.runBeforeEach())}runAfterEach(){return Promise.resolve(this.property.runAfterEach())}},VE=class{constructor(X){this.property=X}isAsync(){return this.property.isAsync()}generate(X,Y){return this.property.generate(X,void 0)}shrink(X){return this.property.shrink(X)}run(X){return this.property.run(X)}runBeforeEach(){return this.property.runBeforeEach()}runAfterEach(){return this.property.runAfterEach()}},kA=Array.from,bA=typeof Buffer<"u"?Buffer.isBuffer:void 0,P9=JSON.stringify,gA=Number.isNaN,Oo=Object.keys,Lo=Object.getOwnPropertySymbols,To=Object.getOwnPropertyDescriptor,yA=Object.getPrototypeOf,hA=Number.NEGATIVE_INFINITY,Fo=Number.POSITIVE_INFINITY,X6=Symbol.for("fast-check/toStringMethod");function qW(X){return X!==null&&(typeof X==="object"||typeof X==="function")&&X6 in X&&typeof X[X6]==="function"}var V8=Symbol.for("fast-check/asyncToStringMethod");function OW(X){return X!==null&&(typeof X==="object"||typeof X==="function")&&V8 in X&&typeof X[V8]==="function"}var Ro=/^Symbol\((.*)\)$/;function Ao(X){if(X.description!==void 0)return X.description;let Y=Ro.exec(p1(X));return Y&&Y[1].length?Y[1]:null}function mA(X){switch(X){case 0:return 1/X===hA?"-0":"0";case hA:return"Number.NEGATIVE_INFINITY";case Fo:return"Number.POSITIVE_INFINITY";default:return X===X?p1(X):"Number.NaN"}}function Po(X){let Y=-1;for(let Q in X){let J=Number(Q);if(J!==Y+1)return!0;Y=J}return Y+1!==X.length}function VX(X,Y,Q){let J=[...Y,X];if(typeof X==="object"){if(fQ(Y,X)!==-1)return"[cyclic]"}if(OW(X)){let $=Q(X);if($.state==="fulfilled")return $.value}if(qW(X))try{return X[X6]()}catch{}switch(oH(X)){case"[object Array]":{let $=X;if($.length>=50&&Po($)){let Z=[];for(let K in $)if(!gA(Number(K)))I(Z,`${K}:${VX($[K],J,Q)}`);return Z.length!==0?`Object.assign(Array(${$.length}),{${h0(Z,",")}})`:`Array(${$.length})`}let G=h0(O0($,(Z)=>VX(Z,J,Q)),",");return $.length===0||$.length-1 in $?`[${G}]`:`[${G},]`}case"[object BigInt]":return`${X}n`;case"[object Boolean]":{let $=X==!0?"true":"false";return typeof X==="boolean"?$:`new Boolean(${$})`}case"[object Date]":{let $=X;return gA(v$($))?"new Date(NaN)":`new Date(${P9(Tl($))})`}case"[object Map]":return`new Map(${VX(Array.from(X),J,Q)})`;case"[object Null]":return"null";case"[object Number]":return typeof X==="number"?mA(X):`new Number(${mA(Number(X))})`;case"[object Object]":{try{let G=X.toString;if(typeof G==="function"&&G!==Object.prototype.toString)return X.toString()}catch{return"[object Object]"}let $=(G)=>`${G==="__proto__"?'["__proto__"]':typeof G==="symbol"?`[${VX(G,J,Q)}]`:P9(G)}:${VX(X[G],J,Q)}`;return"{"+h0([...yA(X)===null?["__proto__:null"]:[],...O0(Oo(X),$),...O0(ql(Lo(X),(G)=>{let Z=To(X,G);return Z&&Z.enumerable}),$)],",")+"}"}case"[object Set]":return`new Set(${VX(Array.from(X),J,Q)})`;case"[object String]":return typeof X==="string"?P9(X):`new String(${P9(X)})`;case"[object Symbol]":{let $=X;if(P$.keyFor($)!==void 0)return`Symbol.for(${P9(P$.keyFor($))})`;let G=Ao($);if(G===null)return"Symbol()";return $===(G.startsWith("Symbol.")&&P$[G.substring(7)])?G:`Symbol(${P9(G)})`}case"[object Promise]":{let $=Q(X);switch($.state){case"fulfilled":return`Promise.resolve(${VX($.value,J,Q)})`;case"rejected":return`Promise.reject(${VX($.value,J,Q)})`;case"pending":return"new Promise(() => {/*pending*/})";default:return"new Promise(() => {/*unknown*/})"}}case"[object Error]":if(X instanceof Error)return`new Error(${VX(X.message,J,Q)})`;break;case"[object Undefined]":return"undefined";case"[object Int8Array]":case"[object Uint8Array]":case"[object Uint8ClampedArray]":case"[object Int16Array]":case"[object Uint16Array]":case"[object Int32Array]":case"[object Uint32Array]":case"[object Float32Array]":case"[object Float64Array]":case"[object BigInt64Array]":case"[object BigUint64Array]":{if(typeof bA==="function"&&bA(X))return`Buffer.from(${X.buffer.detached?"/*detached ArrayBuffer*/":VX(kA(X.values()),J,Q)})`;let $=yA(X),G=$&&$.constructor&&$.constructor.name;if(typeof G==="string"){let Z=X;if(Z.buffer.detached)return`${G}.from(/*detached ArrayBuffer*/)`;let K=Z.values();return`${G}.from(${VX(kA(K),J,Q)})`}break}}try{return X.toString()}catch{return oH(X)}}function s0(X){return VX(X,[],()=>({state:"unknown",value:void 0}))}function BE(X){let Y=P$(),Q=[],J=new N8;function $(){let H=null,W=()=>{if(H!==null)clearTimeout(H)};return{delay:new Promise((D)=>{H=setTimeout(()=>{H=null,D(Y)},0)}),cancel:W}}let G={state:"unknown",value:void 0},Z=function(W){let D=W;if(J.has(D))return J.get(D);let U=$(),N=V8 in W?Promise.resolve().then(()=>W[V8]()):W;return N.catch(()=>{}),Q.push(Promise.race([N,U.delay]).then((V)=>{if(V===Y)J.set(D,{state:"pending",value:void 0});else J.set(D,{state:"fulfilled",value:V});U.cancel()},(V)=>{J.set(D,{state:"rejected",value:V}),U.cancel()})),J.set(D,G),G};function K(){let H=VX(X,[],Z);if(Q.length===0)return H;return Promise.all(Q.splice(0)).then(K)}return K()}async function LW(X){return Promise.resolve(BE(X))}function fA(X){return X===null?new K4:X}function Eo(...X){if(X[1])return X[0].then(fA);return fA(X[0])}function Co(X,Y){return Eo(X,Y)}var pA=class{constructor(X,Y){this.property=X,this.skipRuns=Y,this.coveredCases=new Map}isAsync(){return this.property.isAsync()}generate(X,Y){return this.property.generate(X,Y)}shrink(X){return this.property.shrink(X)}run(X){let Y=s0(X);if(this.coveredCases.has(Y)){let J=this.coveredCases.get(Y);if(!this.skipRuns)return J;return Co(J,this.property.isAsync())}let Q=this.property.run(X);return this.coveredCases.set(Y,Q),Q}runBeforeEach(){return this.property.runBeforeEach()}runAfterEach(){return this.property.runAfterEach()}},dA=Date.now,PH=setTimeout,EH=clearTimeout;function wo(X,Y){let Q=X;if(X.isAsync()&&Y.timeout!==void 0)Q=new qo(Q,Y.timeout,PH,EH);if(Y.unbiased)Q=new VE(Q);if(Y.skipAllAfterTimeLimit!==void 0)Q=new SA(Q,dA,Y.skipAllAfterTimeLimit,!1,PH,EH);if(Y.interruptAfterTimeLimit!==void 0)Q=new SA(Q,dA,Y.interruptAfterTimeLimit,!0,PH,EH);if(Y.skipEqualValues)Q=new pA(Q,!0);if(Y.ignoreEqualValues)Q=new pA(Q,!1);return Q}var Mo=function(X){return X[X.Success=0]="Success",X[X.Skipped=-1]="Skipped",X[X.Failure=1]="Failure",X}({}),jo=class X{constructor(Y,Q){this.verbosity=Y,this.interruptedAsFailure=Q,this.rootExecutionTrees=[],this.currentLevelExecutionTrees=this.rootExecutionTrees,this.failure=null,this.numSkips=0,this.numSuccesses=0,this.interrupted=!1}appendExecutionTree(Y,Q){let J={status:Y,value:Q,children:[]};return this.currentLevelExecutionTrees.push(J),J}fail(Y,Q,J){if(this.verbosity>=1){let $=this.appendExecutionTree(1,Y);this.currentLevelExecutionTrees=$.children}if(this.pathToFailure===void 0)this.pathToFailure=`${Q}`;else this.pathToFailure+=`:${Q}`;this.value=Y,this.failure=J}skip(Y){if(this.verbosity>=2)this.appendExecutionTree(-1,Y);if(this.pathToFailure===void 0)++this.numSkips}success(Y){if(this.verbosity>=2)this.appendExecutionTree(0,Y);if(this.pathToFailure===void 0)++this.numSuccesses}interrupt(){this.interrupted=!0}isSuccess(){return this.pathToFailure===void 0}firstFailure(){return this.pathToFailure!==void 0?+d1(this.pathToFailure,":")[0]:-1}numShrinks(){return this.pathToFailure!==void 0?d1(this.pathToFailure,":").length-1:0}extractFailures(){if(this.isSuccess())return[];let Y=[],Q=this.rootExecutionTrees;while(Q.length>0&&Q[Q.length-1].status===1){let J=Q[Q.length-1];Y.push(J.value),Q=J.children}return Y}static mergePaths(Y,Q){if(Y.length===0)return Q;let J=Y.split(":"),$=Q.split(":"),G=+J[J.length-1]+ +$[0];return[...J.slice(0,J.length-1),`${G}`,...$.slice(1)].join(":")}toRunDetails(Y,Q,J,$){if(!this.isSuccess())return{failed:!0,interrupted:this.interrupted,numRuns:this.firstFailure()+1-this.numSkips,numSkips:this.numSkips,numShrinks:this.numShrinks(),seed:Y,counterexample:this.value,counterexamplePath:X.mergePaths(Q,this.pathToFailure),errorInstance:this.failure.error,failures:this.extractFailures(),executionSummary:this.rootExecutionTrees,verbose:this.verbosity,runConfiguration:$.toParameters()};let G=this.interruptedAsFailure||this.numSuccesses===0;return{failed:this.numSkips>J||this.interrupted&&G,interrupted:this.interrupted,numRuns:this.numSuccesses,numSkips:this.numSkips,numShrinks:0,seed:Y,counterexample:null,counterexamplePath:null,error:null,errorInstance:null,failures:[],executionSummary:this.rootExecutionTrees,verbose:this.verbosity,runConfiguration:$.toParameters()}}},zE=class{constructor(X,Y,Q,J){this.sourceValues=X,this.shrink=Y,this.runExecution=new jo(Q,J),this.currentIdx=-1,this.nextValues=X}[Symbol.iterator](){return this}next(){let X=this.nextValues.next();if(X.done||this.runExecution.interrupted)return{done:!0,value:void 0};return this.currentValue=X.value,++this.currentIdx,{done:!1,value:X.value.value_}}handleResult(X){if(X!==null&&typeof X==="object"&&!K4.isFailure(X))this.runExecution.fail(this.currentValue.value_,this.currentIdx,X),this.currentIdx=-1,this.nextValues=this.shrink(this.currentValue);else if(X!==null)if(!X.interruptExecution)this.runExecution.skip(this.currentValue.value_),this.sourceValues.skippedOne();else this.runExecution.interrupt();else this.runExecution.success(this.currentValue.value_)}},Io=class{constructor(X,Y,Q){this.initialValues=X,this.maxInitialIterations=Y,this.remainingSkips=Q}[Symbol.iterator](){return this}next(){if(--this.maxInitialIterations!==-1&&this.remainingSkips>=0){let X=this.initialValues.next();if(!X.done)return{value:X.value,done:!1}}return{value:void 0,done:!0}}skippedOne(){--this.remainingSkips,++this.maxInitialIterations}},xo=-2147483648,vo=2147483647,So=Math.pow(2,27),ko=Math.pow(2,-53),TW=class X{constructor(Y){this.internalRng=y$(Y.clone())}clone(){return new X(this.internalRng)}next(Y){return z$(this.internalRng,0,(1<<Y)-1)}nextBoolean(){return z$(this.internalRng,0,1)===1}nextInt(Y,Q){return z$(this.internalRng,Y===void 0?xo:Y,Q===void 0?vo:Q)}nextBigInt(Y,Q){return nR(this.internalRng,Y,Q)}nextDouble(){let Y=this.next(26),Q=this.next(27);return(Y*So+Q)*ko}getState(){if("getState"in this.internalRng&&typeof this.internalRng.getState==="function")return this.internalRng.getState()}};function bo(X,Y,Q){return Y.jump(),X.generate(new TW(Y),Q)}function*qE(X,Y,Q,J){for(let $=0;$!==J.length;++$)yield new g(J[$],void 0);for(let $=0,G=Q(Y);;++$)yield bo(X,G,$)}function go(X,Y,Q){return()=>X.generate(new TW(Y),Q)}function*OE(X,Y,Q,J){yield*O0(J,(Z)=>()=>new g(Z,void 0));let $=0,G=y$(Q(Y));for(;;)G.jump(),yield go(X,G,$++)}function uA(X){return X()}function LE(X,Y,Q){let J=Y,$=X.split(":").map((Z)=>+Z);if($.length===0)return J.map(uA);if(!$.every((Z)=>!Number.isNaN(Z)))throw Error(`Unable to replay, got invalid path=${X}`);let G=J.drop($[0]).map(uA);for(let Z of $.slice(1)){let K=G.getNthOrLast(0);if(K===null)throw Error(`Unable to replay, got wrong path=${X}`);G=Q(K).drop(Z)}return G}var yo=Object.assign;function ho(X){if(X.length===1)return`Hint: ${X[0]}`;return X.map((Y,Q)=>`Hint (${Q+1}): ${Y}`).join(`
`)}function mo(X,Y){return`Encountered failures were:
- ${X.map(Y).join(`
- `)}`}function FW(X,Y){let Q=[],J=[];for(let $=X.length-1;$>=0;--$)J.push({depth:1,tree:X[$]});while(J.length!==0){let $=J.pop(),G=$.tree,Z=$.depth,K=G.status===0?"\x1B[32m√\x1B[0m":G.status===1?"\x1B[31m×\x1B[0m":"\x1B[33m!\x1B[0m",H=Z!==0?". ".repeat(Z-1):"";Q.push(`${H}${K} ${Y(G.value)}`);for(let W=G.children.length-1;W>=0;--W)J.push({depth:Z+1,tree:G.children[W]})}return`Execution summary:
${Q.join(`
`)}`}function fo(X,Y){let Q=`Failed to run property, too many pre-condition failures encountered
{ seed: ${X.seed} }

Ran ${X.numRuns} time(s)
Skipped ${X.numSkips} time(s)`,J=null,$=["Try to reduce the number of rejected values by combining map, chain and built-in arbitraries","Increase failure tolerance by setting maxSkipsPerRun to an higher value"];if(X.verbose>=2)J=FW(X.executionSummary,Y);else I($,"Enable verbose mode at level VeryVerbose in order to check all generated values and their associated status");return{message:Q,details:J,hints:$}}function po(X){if(X instanceof y&&X.stack!==void 0)return X.stack;try{return p1(X)}catch(Y){}if(X instanceof y)try{return sl(X)}catch(Y){}if(X!==null&&typeof X==="object")try{return oH(X)}catch(Y){}return"Failed to serialize errorInstance"}function uo(X,Y){let Q=X.runConfiguration.includeErrorInReport?`
Got ${ll(po(X.errorInstance),/^Error: /,"error: ")}`:"",J=`Property failed after ${X.numRuns} tests
{ seed: ${X.seed}, path: "${X.counterexamplePath}", endOnFailure: true }
Counterexample: ${Y(X.counterexample)}
Shrunk ${X.numShrinks} time(s)${Q}`,$=null,G=[];if(X.verbose>=2)$=FW(X.executionSummary,Y);else if(X.verbose===1)$=mo(X.failures,Y);else I(G,"Enable verbose mode in order to have the list of all failing values encountered during the run");return{message:J,details:$,hints:G}}function co(X,Y){let Q=`Property interrupted after ${X.numRuns} tests
{ seed: ${X.seed} }`,J=null,$=[];if(X.verbose>=2)J=FW(X.executionSummary,Y);else I($,"Enable verbose mode at level VeryVerbose in order to check all generated values and their associated status");return{message:Q,details:J,hints:$}}function rH(X,Y){if(!X.failed)return;let{message:Q,details:J,hints:$}=X.counterexamplePath===null?X.interrupted?co(X,Y):fo(X,Y):uo(X,Y),G=Q;if(J!==null)G+=`

${J}`;if($.length>0)G+=`

${ho($)}`;return G}function TE(X){return rH(X,s0)}async function FE(X){let Y=[];function Q(Z){let K=BE(Z);if(typeof K==="string")return K;return Y.push(Promise.all([Z,K])),"…"}let J=rH(X,Q);if(Y.length===0)return J;let $=new N8(await Promise.all(Y));function G(Z){let K=BX($,Z);if(K!==void 0)return K;return s0(Z)}return rH(X,G)}function RE(X,Y){if(Y.runConfiguration.includeErrorInReport)throw new y(X);let Q=new y(X,{cause:Y.errorInstance});if(!("cause"in Q))yo(Q,{cause:Y.errorInstance});return Q}function lo(X){if(!X.failed)return;throw RE(TE(X),X)}async function oo(X){if(!X.failed)return;throw RE(await FE(X),X)}function io(X){if(X.runConfiguration.asyncReporter)return X.runConfiguration.asyncReporter(X);else if(X.runConfiguration.reporter)return X.runConfiguration.reporter(X);else return lo(X)}async function ro(X){if(X.runConfiguration.asyncReporter)return X.runConfiguration.asyncReporter(X);else if(X.runConfiguration.reporter)return X.runConfiguration.reporter(X);else return oo(X)}function no(X,Y,Q,J,$){let G=new zE(Q,Y,J,$);for(let Z of G){X.runBeforeEach();let K=X.run(Z);X.runAfterEach(),G.handleResult(K)}return G.runExecution}async function so(X,Y,Q,J,$){let G=new zE(Q,Y,J,$);for(let Z of G){await X.runBeforeEach();let K=await X.run(Z);await X.runAfterEach(),G.handleResult(K)}return G.runExecution}function AE(X,Y){if(X===null||X===void 0||X.generate===null||X.generate===void 0)throw Error("Invalid property encountered, please use a valid property");if(X.run===null||X.run===void 0)throw Error("Invalid property encountered, please use a valid property not an arbitrary");let Q=zW({...eX(),...Y});if(Q.reporter!==void 0&&Q.asyncReporter!==void 0)throw Error("Invalid parameters encountered, reporter and asyncReporter cannot be specified together");if(Q.asyncReporter!==void 0&&!X.isAsync())throw Error("Invalid parameters encountered, only asyncProperty can be used when asyncReporter specified");let J=wo(X,Q),$=Q.path.length===0||Q.path.indexOf(":")===-1?Q.numRuns:-1,G=Q.numRuns*Q.maxSkipsPerRun,Z=(...W)=>J.shrink(...W),K=new Io(Q.path.length===0?qE(J,Q.seed,Q.randomType,Q.examples):LE(Q.path,G4(OE(J,Q.seed,Q.randomType,Q.examples)),Z),$,G),H=!Q.endOnFailure?Z:K0.nil;return J.isAsync()?so(J,H,K,Q.verbose,Q.markInterruptAsFailure).then((W)=>W.toRunDetails(Q.seed,Q.path,G,Q)):no(J,H,K,Q.verbose,Q.markInterruptAsFailure).toRunDetails(Q.seed,Q.path,G,Q)}function ao(X,Y){let Q=AE(X,Y);if(X.isAsync())return Q.then(ro);else io(Q)}function to(X,Y){let Q=!Object.prototype.hasOwnProperty.call(X,"isAsync")?new DE(X,()=>!0):X;return Y.unbiased===!0?new VE(Q):Q}function PE(X,Y){let Q=zW(typeof Y==="number"?{...eX(),numRuns:Y}:{...eX(),...Y}),J=to(X,Q),$=J.shrink.bind(J);return(Q.path.length===0?G4(qE(J,Q.seed,Q.randomType,Q.examples)):LE(Q.path,G4(OE(J,Q.seed,Q.randomType,Q.examples)),$)).take(Q.numRuns).map((G)=>G.value_)}function eo(X,Y){return[...PE(X,Y)]}function Xi(X){return(Math.round(X*100)/100).toFixed(2)}function Yi(X,Y,Q){let J=zW(typeof Q==="number"?{...eX(),numRuns:Q}:{...eX(),...Q}),$={};for(let H of PE(X,Q)){let W=Y(H),D=Array.isArray(W)?W:[W];for(let U of D)$[U]=($[U]||0)+1}let G=Object.entries($).sort((H,W)=>W[1]-H[1]).map((H)=>[H[0],`${Xi(H[1]*100/J.numRuns)}%`]),Z=G.map((H)=>H[0].length).reduce((H,W)=>Math.max(H,W),0),K=G.map((H)=>H[1].length).reduce((H,W)=>Math.max(H,W),0);for(let H of G)J.logger(`${H[0].padEnd(Z,".")}..${H[1].padStart(K,".")}`)}var Qi=Object.assign;function nH(X,Y,Q,J){let $=Q(),G=X.clone(),Z={mrng:X.clone(),biasFactor:Y,history:[]},K=(W)=>{let D=$[Z.history.length];if(D!==void 0&&D.arb===W){let N=D.value;return I(Z.history,{arb:W,value:N,context:D.context,mrng:D.mrng}),G=D.mrng.clone(),N}let U=W.generate(G,Y);return I(Z.history,{arb:W,value:U.value_,context:U.context,mrng:G.clone()}),U.value};return new g(Qi((W,...D)=>{return K(J(W,D))},{values(){return O0(Z.history,(W)=>W.value)},[H1](){return nH(X,Y,Q,J).value},[X6](){return s0(O0(Z.history,(W)=>W.value))}}),Z)}var CH=Array.isArray,cA=Object.keys,Ji=Object.is;function $i(X){let Y=new N8;return function(J,$){let G=BX(Y,J);if(G===void 0){let H=J(...$);return aX(Y,J,[{args:$,value:H}]),H}let Z=G;for(let H of Z)if(X($,H.args))return H.value;let K=J(...$);return I(Z,{args:$,value:K}),K}}function EE(X,Y){if(X!==null&&typeof X==="object"&&Y!==null&&typeof Y==="object"){if(CH(X)){if(!CH(Y))return!1;if(X.length!==Y.length)return!1}else if(CH(Y))return!1;if(cA(X).length!==cA(Y).length)return!1;for(let Q in X){if(!(Q in Y))return!1;if(!EE(X[Q],Y[Q]))return!1}return!0}else return Ji(X,Y)}var _i=class extends m0{constructor(...X){super(...X);this.arbitraryCache=$i(EE)}generate(X,Y){return nH(X,Y,()=>[],this.arbitraryCache)}canShrinkWithoutContext(X){return!1}shrink(X,Y){if(Y===void 0)return K0.nil();let Q=Y,J=Q.mrng,$=Q.biasFactor,G=Q.history;return HE(G.map((Z)=>Z.arb),G.map((Z)=>Z.value),G.map((Z)=>Z.context)).map((Z)=>{function K(){let{value:H,context:W}=Z;return O0(G,(D,U)=>({arb:D.arb,value:H[U],context:W[U],mrng:D.mrng}))}return nH(J,$,K,this.arbitraryCache)})}};function Gi(){return new _i}var{floor:Zi,log:lA}=Math;function Ki(X){return Zi(lA(X)/lA(2))}function Hi(X){if(X===b(0))return b(0);return b(p1(X).length)}function CE(X,Y,Q){if(X===Y)return[{min:X,max:Y}];if(X<0&&Y>0){let Z=Q(-X),K=Q(Y);return[{min:-Z,max:K},{min:Y-K,max:Y},{min:X,max:X+Z}]}let J=Q(Y-X),$={min:X,max:X+J},G={min:Y-J,max:Y};return X<0?[G,$]:[$,G]}var{ceil:Wi,floor:Ui}=Math;function oA(X){return Ui(X/2)}function iA(X){return Wi(X/2)}function rA(X,Y,Q){let J=X-Y;function*$(){let Z=Q?void 0:Y,K=Q?J:oA(J);for(let H=K;H>0;H=oA(H)){let W=H===J?Y:X-H;yield new g(W,Z),Z=W}}function*G(){let Z=Q?void 0:Y,K=Q?J:iA(J);for(let H=K;H<0;H=iA(H)){let W=H===J?Y:X-H;yield new g(W,Z),Z=W}}return J>0?G4($()):G4(G())}var nA=Math.sign,Di=Number.isInteger,Ni=Object.is,x9=class X extends m0{constructor(Y,Q){super();this.min=Y,this.max=Q,this.ranges=CE(Y,Q,Ki)}generate(Y,Q){if(Q===void 0||Y.nextInt(1,Q)!==1)return new g(Y.nextInt(this.min,this.max),void 0);let J=this.ranges;if(J.length===1){let Z=J[0];return new g(Y.nextInt(Z.min,Z.max),void 0)}let $=Y.nextInt(-2*(J.length-1),J.length-2),G=$<0?J[0]:J[$+1];return new g(Y.nextInt(G.min,G.max),void 0)}canShrinkWithoutContext(Y){return typeof Y==="number"&&Di(Y)&&!Ni(Y,-0)&&this.min<=Y&&Y<=this.max}shrink(Y,Q){if(!X.isValidContext(Y,Q))return rA(Y,this.min<=0&&this.max>=0?0:this.min<0?this.max:this.min,!0);if(this.isLastChanceTry(Y,Q))return K0.of(new g(Q,void 0));return rA(Y,Q,!1)}isLastChanceTry(Y,Q){if(Y>0)return Y===Q+1&&Y>this.min;if(Y<0)return Y===Q-1&&Y<this.max;return!1}static isValidContext(Y,Q){if(Q===void 0)return!1;if(typeof Q!=="number")throw Error("Invalid context type passed to IntegerArbitrary (#1)");if(Q!==0&&nA(Y)!==nA(Q))throw Error("Invalid context value passed to IntegerArbitrary (#2)");return!0}},sA=Number.isInteger;function Vi(X){return{min:X.min!==void 0?X.min:-2147483648,max:X.max!==void 0?X.max:2147483647}}function E0(X={}){let Y=Vi(X);if(Y.min>Y.max)throw Error("fc.integer maximum value should be equal or greater than the minimum one");if(!sA(Y.min))throw Error("fc.integer minimum value should be an integer");if(!sA(Y.max))throw Error("fc.integer maximum value should be an integer");return new x9(Y.min,Y.max)}var aA=new Map;function RW(X){if(X===void 0)return{depth:0};if(typeof X!=="string")return X;let Y=BX(aA,X);if(Y!==void 0)return Y;let Q={depth:0};return aX(aA,X,Q),Q}function AW(){return{depth:0}}var Bi=class{constructor(X,Y,Q){this.arb=X,this.mrng=Y,this.biasFactor=Q}attemptExact(){}next(){return this.arb.generate(this.mrng,this.biasFactor)}},zi=Math.min,qi=Math.max,Oi=class{constructor(X,Y,Q,J){this.arb=X,this.mrng=Y,this.slices=Q,this.biasFactor=J,this.activeSliceIndex=0,this.nextIndexInSlice=0,this.lastIndexInSlice=-1}attemptExact(X){if(X!==0&&this.mrng.nextInt(1,this.biasFactor)===1){let Y=[];for(let Q=0;Q!==this.slices.length;++Q)if(this.slices[Q].length===X)I(Y,Q);if(Y.length===0)return;this.activeSliceIndex=Y[this.mrng.nextInt(0,Y.length-1)],this.nextIndexInSlice=0,this.lastIndexInSlice=X-1}}next(){if(this.nextIndexInSlice<=this.lastIndexInSlice)return new g(this.slices[this.activeSliceIndex][this.nextIndexInSlice++],void 0);if(this.mrng.nextInt(1,this.biasFactor)!==1)return this.arb.generate(this.mrng,this.biasFactor);this.activeSliceIndex=this.mrng.nextInt(0,this.slices.length-1);let X=this.slices[this.activeSliceIndex];if(this.mrng.nextInt(1,this.biasFactor)!==1)return this.nextIndexInSlice=1,this.lastIndexInSlice=X.length-1,new g(X[0],void 0);let Y=this.mrng.nextInt(0,X.length-1),Q=this.mrng.nextInt(0,X.length-1);return this.nextIndexInSlice=zi(Y,Q),this.lastIndexInSlice=qi(Y,Q),new g(X[this.nextIndexInSlice++],void 0)}};function tA(X,Y,Q,J){if(J===void 0||Q.length===0||Y.nextInt(1,J)!==1)return new Bi(X,Y,J);return new Oi(X,Y,Q,J)}var{floor:Li,log:eA}=Math,Ti=Array.isArray;function Fi(X,Y){if(X===Y)return X;return X+Li(eA(Y-X)/eA(2))}var wE=class X extends m0{constructor(Y,Q,J,$,G,Z,K){super();this.arb=Y,this.minLength=Q,this.maxGeneratedLength=J,this.maxLength=$,this.setBuilder=Z,this.customSlices=K,this.lengthArb=E0({min:Q,max:J}),this.depthContext=RW(G),this.cachedBiasedMaxLength=Fi(Q,J)}preFilter(Y){if(this.setBuilder===void 0)return Y;let Q=this.setBuilder();for(let J=0;J!==Y.length;++J)Q.tryAdd(Y[J]);return Q.getData()}static makeItCloneable(Y,Q){return Y[H1]=()=>{let J=[];for(let $=0;$!==Q.length;++$)I(J,Q[$].value);return this.makeItCloneable(J,Q),J},Y}generateNItemsNoDuplicates(Y,Q,J,$){let G=0,Z=Y(),K=tA(this.arb,J,this.customSlices,$);while(Z.size()<Q&&G<this.maxGeneratedLength){let H=K.next();if(Z.tryAdd(H))G=0;else G+=1}return Z.getData()}safeGenerateNItemsNoDuplicates(Y,Q,J,$){let G=Q-this.cachedBiasedMaxLength;if(G<=0)return this.generateNItemsNoDuplicates(Y,Q,J,$);this.depthContext.depth+=G;try{return this.generateNItemsNoDuplicates(Y,Q,J,$)}finally{this.depthContext.depth-=G}}generateNItems(Y,Q,J){let $=[],G=tA(this.arb,Q,this.customSlices,J);G.attemptExact(Y);for(let Z=0;Z!==Y;++Z)I($,G.next());return $}safeGenerateNItems(Y,Q,J){let $=Y-this.cachedBiasedMaxLength;if($<=0)return this.generateNItems(Y,Q,J);this.depthContext.depth+=$;try{return this.generateNItems(Y,Q,J)}finally{this.depthContext.depth-=$}}wrapper(Y,Q,J,$){let G=Q?this.preFilter(Y):Y,Z=!1,K=[],H=[];for(let W=0;W!==G.length;++W){let D=G[W];Z=Z||D.hasToBeCloned,I(K,D.value),I(H,D.context)}if(Z)X.makeItCloneable(K,G);return new g(K,{shrunkOnce:Q,lengthContext:Y.length===G.length&&J!==void 0?J:void 0,itemsContexts:H,startIndex:$})}generate(Y,Q){let J,$;if(Q===void 0)J=this.lengthArb.generate(Y,void 0).value;else if(this.minLength===this.maxGeneratedLength)J=this.lengthArb.generate(Y,void 0).value,$=Q;else if(Y.nextInt(1,Q)!==1)J=this.lengthArb.generate(Y,void 0).value;else if(Y.nextInt(1,Q)!==1)J=this.lengthArb.generate(Y,void 0).value,$=Q;else{let Z=this.cachedBiasedMaxLength;J=E0({min:this.minLength,max:Z}).generate(Y,void 0).value,$=Q}let G=this.setBuilder!==void 0?this.safeGenerateNItemsNoDuplicates(this.setBuilder,J,Y,$):this.safeGenerateNItems(J,Y,$);return this.wrapper(G,!1,void 0,0)}canShrinkWithoutContext(Y){if(!Ti(Y)||this.minLength>Y.length||Y.length>this.maxLength)return!1;for(let Q=0;Q!==Y.length;++Q){if(!(Q in Y))return!1;if(!this.arb.canShrinkWithoutContext(Y[Q]))return!1}return this.preFilter(O0(Y,(Q)=>new g(Q,void 0))).length===Y.length}shrinkItemByItem(Y,Q,J){let $=[];for(let G=Q.startIndex;G<J;++G)I($,_4(()=>this.arb.shrink(Y[G],Q.itemsContexts[G]).map((Z)=>{let K=O0(Z1(Y,0,G),(W,D)=>new g(M9(W),Q.itemsContexts[D])),H=O0(Z1(Y,G+1),(W,D)=>new g(M9(W),Q.itemsContexts[D+G+1]));return[[...K,Z,...H],void 0,G]})));return K0.nil().join(...$)}shrinkImpl(Y,Q){if(Y.length===0)return K0.nil();let J=Q!==void 0?Q:{shrunkOnce:!1,lengthContext:void 0,itemsContexts:[],startIndex:0};return this.lengthArb.shrink(Y.length,J.lengthContext).drop(J.shrunkOnce&&J.lengthContext===void 0&&Y.length>this.minLength+1?1:0).map(($)=>{let G=Y.length-$.value;return[O0(Z1(Y,G),(Z,K)=>new g(M9(Z),J.itemsContexts[K+G])),$.context,0]}).join(_4(()=>Y.length>this.minLength?this.shrinkItemByItem(Y,J,1):this.shrinkItemByItem(Y,J,Y.length))).join(Y.length>this.minLength?_4(()=>{let $={shrunkOnce:!1,lengthContext:void 0,itemsContexts:Z1(J.itemsContexts,1),startIndex:0};return this.shrinkImpl(Z1(Y,1),$).filter((G)=>this.minLength<=G[0].length+1).map((G)=>{return[[new g(M9(Y[0]),J.itemsContexts[0]),...G[0]],void 0,0]})}):K0.nil())}shrink(Y,Q){return this.shrinkImpl(Y,Q).map((J)=>this.wrapper(J[0],!0,J[1],J[2]))}},Ri=Math.floor,Ai=Math.min,N5=2147483647,E9=["xsmall","small","medium","large","xlarge"],Pi=["-4","-3","-2","-1","=","+1","+2","+3","+4"],PW="small";function Ei(X,Y){switch(Y){case"xsmall":return Ri(1.1*X)+1;case"small":return 2*X+10;case"medium":return 11*X+100;case"large":return 101*X+1000;case"xlarge":return 1001*X+1e4;default:throw Error(`Unable to compute lengths based on received size: ${Y}`)}}function oQ(X,Y){let Q=fQ(Pi,X);if(Q===-1)return X;let J=fQ(E9,Y);if(J===-1)throw Error(`Unable to offset size based on the unknown defaulted one: ${Y}`);let $=J+Q-4;return $<0?E9[0]:$>=E9.length?E9[E9.length-1]:E9[$]}function cQ(X,Y,Q,J){let{baseSize:$=PW,defaultSizeToMaxWhenMaxSpecified:G}=eX()||{},Z=X!==void 0?X:J&&G?"max":$;if(Z==="max")return Q;let K=oQ(Z,$);return Ai(Ei(Y,K),Q)}function Ci(X,Y){if(typeof X==="number")return 1/X;let{baseSize:Q=PW,defaultSizeToMaxWhenMaxSpecified:J}=eX()||{},$=X!==void 0?X:Y&&J?"max":Q;if($==="max")return 0;switch(oQ($,Q)){case"xsmall":return 1;case"small":return 0.5;case"medium":return 0.25;case"large":return 0.125;case"xlarge":return 0.0625}}function EW(X){let{baseSize:Y=PW}=eX()||{};if(X===void 0)return Y;return oQ(X,Y)}function M0(X,Y={}){let Q=Y.size,J=Y.minLength||0,$=Y.maxLength,G=Y.depthIdentifier,Z=$!==void 0?$:N5;return new wE(X,J,cQ(Q,J,Z,$!==void 0),Z,G,void 0,Y.experimentalCustomSlices||[])}function q$(X){return X/b(2)}function XP(X,Y,Q){let J=X-Y;function*$(){let Z=Q?void 0:Y,K=Q?J:q$(J);for(let H=K;H>0;H=q$(H)){let W=X-H;yield new g(W,Z),Z=W}}function*G(){let Z=Q?void 0:Y,K=Q?J:q$(J);for(let H=K;H<0;H=q$(H)){let W=X-H;yield new g(W,Z),Z=W}}return J>0?G4($()):G4(G())}var wi=class X extends m0{constructor(Y,Q){super();this.min=Y,this.max=Q}generate(Y,Q){let J=this.computeGenerateRange(Y,Q);return new g(Y.nextBigInt(J.min,J.max),void 0)}computeGenerateRange(Y,Q){if(Q===void 0||Y.nextInt(1,Q)!==1)return{min:this.min,max:this.max};let J=CE(this.min,this.max,Hi);if(J.length===1)return J[0];let $=Y.nextInt(-2*(J.length-1),J.length-2);return $<0?J[0]:J[$+1]}canShrinkWithoutContext(Y){return typeof Y==="bigint"&&this.min<=Y&&Y<=this.max}shrink(Y,Q){if(!X.isValidContext(Y,Q))return XP(Y,this.defaultTarget(),!0);if(this.isLastChanceTry(Y,Q))return K0.of(new g(Q,void 0));return XP(Y,Q,!1)}defaultTarget(){if(this.min<=0&&this.max>=0)return b(0);return this.min<0?this.max:this.min}isLastChanceTry(Y,Q){if(Y>0)return Y===Q+b(1)&&Y>this.min;if(Y<0)return Y===Q-b(1)&&Y<this.max;return!1}static isValidContext(Y,Q){if(Q===void 0)return!1;if(typeof Q!=="bigint")throw Error("Invalid context type passed to BigIntArbitrary (#1)");let J=Y>0&&Q<0||Y<0&&Q>0;if(Q!==b(0)&&J)throw Error("Invalid context value passed to BigIntArbitrary (#2)");return!0}};function Mi(X){let Q=b(-1)<<b(255),J=(b(1)<<b(255))-b(1),$=X.min,G=X.max;return{min:$!==void 0?$:Q-(G!==void 0&&G<b(0)?G*G:b(0)),max:G!==void 0?G:J+($!==void 0&&$>b(0)?$*$:b(0))}}function ji(X){if(X[0]===void 0)return{};if(X[1]===void 0)return X[0];return{min:X[0],max:X[1]}}function Z4(...X){let Y=Mi(ji(X));if(Y.min>Y.max)throw Error("fc.bigInt expects max to be greater than or equal to min");return new wi(Y.min,Y.max)}var Ii=Object.getPrototypeOf,gQ=class extends m0{constructor(X){super();this.arb=X}generate(X,Y){return this.arb.generate(X,void 0)}canShrinkWithoutContext(X){return this.arb.canShrinkWithoutContext(X)}shrink(X,Y){return this.arb.shrink(X,Y)}};function S$(X){if(Ii(X)===gQ.prototype&&X.generate===gQ.prototype.generate&&X.canShrinkWithoutContext===gQ.prototype.canShrinkWithoutContext&&X.shrink===gQ.prototype.shrink)return X;return new gQ(X)}function xi(X){return X===1}function vi(X){if(typeof X!=="boolean")throw Error("Unsupported input type");return X===!0?1:0}function iQ(){return S$(E0({min:0,max:1}).map(xi,vi))}var mQ=Object.is,Si=class{constructor(X){this.values=X,this.fastValues=new tX(this.values);let Y=!1,Q=!1;if(J4(this.fastValues,0))for(let J=0;J!==this.values.length;++J){let $=this.values[J];Y=Y||mQ($,-0),Q=Q||mQ($,0)}this.hasMinusZero=Y,this.hasPlusZero=Q}has(X){if(X===0){if(mQ(X,0))return this.hasPlusZero;return this.hasMinusZero}return J4(this.fastValues,X)}},ME=class extends m0{constructor(X){super();this.values=X}generate(X,Y){let Q=this.values.length===1?0:X.nextInt(0,this.values.length-1),J=this.values[Q];if(!D5(J))return new g(J,Q);return new g(J,Q,()=>J[H1]())}canShrinkWithoutContext(X){if(this.values.length===1)return mQ(this.values[0],X);if(this.fastValues===void 0)this.fastValues=new Si(this.values);return this.fastValues.has(X)}shrink(X,Y){if(Y===0||mQ(X,this.values[0]))return K0.nil();return K0.of(new g(this.values[0],0))}};function M6(...X){if(X.length===0)throw Error("fc.constantFrom expects at least one parameter");return new ME(X)}function ki(X){if(!X||!X.withBigInt)return M6(!1,null,void 0,0,"",NaN);return M6(!1,null,void 0,0,"",NaN,b(0))}function y0(X){return new ME([X])}var bi=class X{constructor(){this.receivedLogs=[]}log(Y){this.receivedLogs.push(Y)}size(){return this.receivedLogs.length}toString(){return JSON.stringify({logs:this.receivedLogs})}[H1](){return new X}};function gi(){return y0(new bi)}var yi=NaN,hi=Number.isNaN;function jE(X){return new x$(X)}function IE(X){if(!(X instanceof x$)||X.constructor!==x$)throw new y("Not a valid value for date unmapper");return v$(X)}function mi(X){return(Y)=>{return Y===X?new x$(yi):jE(Y)}}function fi(X){return(Y)=>{let Q=IE(Y);return hi(Q)?X:Q}}var YP=Number.isNaN;function xE(X={}){let Y=X.min!==void 0?v$(X.min):-8640000000000000,Q=X.max!==void 0?v$(X.max):8640000000000000,J=X.noInvalidDate;if(YP(Y))throw Error("fc.date min must be valid instance of Date");if(YP(Q))throw Error("fc.date max must be valid instance of Date");if(Y>Q)throw Error("fc.date max must be greater or equal to min");if(J)return E0({min:Y,max:Q}).map(jE,IE);let $=Q+1;return E0({min:Y,max:Q+1}).map(mi($),fi($))}var pi=class extends m0{constructor(X,Y){super();this.startArb=X,this.chainer=Y}generate(X,Y){let Q=[],J=X.clone(),$=this.startArb.generate(X,Y);Q.push({arbitrary:this.startArb,value:$.value_,context:$.context,clonedMrng:J});while(!0){let Z=this.chainer($.value_);if(Z===void 0)break;let K=X.clone();$=Z.generate(X,Y),Q.push({arbitrary:Z,value:$.value_,context:$.context,clonedMrng:K})}let G={biasFactor:Y,entries:Q,currentShrinkLevel:0};return new g($.value_,G)}canShrinkWithoutContext(X){return!1}shrink(X,Y){if(!this.isSafeContext(Y))return K0.nil();return new K0(this.shrinkIterator(Y))}*shrinkIterator(X){let{entries:Y,currentShrinkLevel:Q,biasFactor:J}=X;for(let $=Q;$<Y.length;++$){let G=Y[$],Z=G.arbitrary.shrink(G.value,G.context);for(let K of Z){let H=Y.slice(0,$);H.push({arbitrary:G.arbitrary,value:K.value_,context:K.context,clonedMrng:G.clonedMrng});let W=K,D=G.clonedMrng.clone();while(!0){let V=this.chainer(W.value_);if(V===void 0)break;let z=D.clone(),q=V.generate(D,J);H.push({arbitrary:V,value:q.value_,context:q.context,clonedMrng:z}),W=q}let U=H[H.length-1],N={biasFactor:J,entries:H,currentShrinkLevel:$};yield new g(U.value,N)}}}isSafeContext(X){return X!==null&&X!==void 0&&typeof X==="object"&&"biasFactor"in X&&"entries"in X&&"currentShrinkLevel"in X}};function vE(X,Y){return new pi(X,Y)}var di=Symbol.iterator,ui=Array.isArray,ci=Object.is,li=class X extends m0{constructor(Y,Q){super();this.arb=Y,this.numValues=Q}generate(Y,Q){let J=[];if(this.numValues<=0)return this.wrapper(J);for(let $=0;$!==this.numValues-1;++$)I(J,this.arb.generate(Y.clone(),Q));return I(J,this.arb.generate(Y,Q)),this.wrapper(J)}canShrinkWithoutContext(Y){if(!ui(Y)||Y.length!==this.numValues)return!1;if(Y.length===0)return!0;for(let Q=1;Q<Y.length;++Q)if(!ci(Y[0],Y[Q]))return!1;return this.arb.canShrinkWithoutContext(Y[0])}shrink(Y,Q){if(Y.length===0)return K0.nil();return new K0(this.shrinkImpl(Y,Q!==void 0?Q:[])).map((J)=>this.wrapper(J))}*shrinkImpl(Y,Q){let J=O0(Y,(G,Z)=>this.arb.shrink(G,Q[Z])[di]()),$=O0(J,(G)=>G.next());while(!$[0].done)yield O0($,(G)=>G.value),$=O0(J,(G)=>G.next())}static makeItCloneable(Y,Q){return Y[H1]=()=>{let J=[];for(let $=0;$!==Q.length;++$)I(J,Q[$].value);return this.makeItCloneable(J,Q),J},Y}wrapper(Y){let Q=!1,J=[],$=[];for(let G=0;G!==Y.length;++G){let Z=Y[G];Q=Q||Z.hasToBeCloned,I(J,Z.value),I($,Z.context)}if(Q)X.makeItCloneable(J,Y);return new g(J,$)}};function oi(X,Y){return new li(X,Y)}var QP=class{constructor(X){this.isEqual=X,this.data=[]}tryAdd(X){for(let Y=0;Y!==this.data.length;++Y)if(this.isEqual(this.data[Y],X))return!1;return I(this.data,X),!0}size(){return this.data.length}getData(){return this.data}},ii=Number.isNaN,ri=class{constructor(X){this.selector=X,this.selectedItemsExceptNaN=new tX,this.data=[]}tryAdd(X){let Y=this.selector(X);if(ii(Y))return I(this.data,X),!0;let Q=this.selectedItemsExceptNaN.size;if(pQ(this.selectedItemsExceptNaN,Y),Q!==this.selectedItemsExceptNaN.size)return I(this.data,X),!0;return!1}size(){return this.data.length}getData(){return this.data}},ni=Object.is,si=class{constructor(X){this.selector=X,this.selectedItemsExceptMinusZero=new tX,this.data=[],this.hasMinusZero=!1}tryAdd(X){let Y=this.selector(X);if(ni(Y,-0)){if(this.hasMinusZero)return!1;return I(this.data,X),this.hasMinusZero=!0,!0}let Q=this.selectedItemsExceptMinusZero.size;if(pQ(this.selectedItemsExceptMinusZero,Y),Q!==this.selectedItemsExceptMinusZero.size)return I(this.data,X),!0;return!1}size(){return this.data.length}getData(){return this.data}},ai=class{constructor(X){this.selector=X,this.selectedItems=new tX,this.data=[]}tryAdd(X){let Y=this.selector(X),Q=this.selectedItems.size;if(pQ(this.selectedItems,Y),Q!==this.selectedItems.size)return I(this.data,X),!0;return!1}size(){return this.data.length}getData(){return this.data}};function ti(X){if(typeof X.comparator==="function"){if(X.selector===void 0){let K=X.comparator,H=(W,D)=>K(W.value_,D.value_);return()=>new QP(H)}let{comparator:J,selector:$}=X,G=(K)=>$(K.value_),Z=(K,H)=>J(G(K),G(H));return()=>new QP(Z)}let Y=X.selector||((J)=>J),Q=(J)=>Y(J.value_);switch(X.comparator){case"IsStrictlyEqual":return()=>new ri(Q);case"SameValueZero":return()=>new ai(Q);case"SameValue":case void 0:return()=>new si(Q)}}function V5(X,Y={}){let Q=Y.minLength!==void 0?Y.minLength:0,J=Y.maxLength!==void 0?Y.maxLength:N5,$=cQ(Y.size,Q,J,Y.maxLength!==void 0),G=Y.depthIdentifier,Z=new wE(X,Q,$,J,G,ti(Y),[]);if(Q===0)return Z;return Z.filter((K)=>K.length>=Q)}var{create:ei,defineProperty:Xr,getOwnPropertyDescriptor:Yr,getPrototypeOf:JP,prototype:Qr}=Object,Jr=Reflect.ownKeys;function $r(X){let Y=X[1]?ei(null):{},Q=X[0];for(let J=0;J!==Q.length;++J){let $=Q[J][0];if($==="__proto__")Xr(Y,$,{enumerable:!0,configurable:!0,writable:!0,value:Q[J][1]});else Y[$]=Q[J][1]}return Y}function _r(X){return X!==void 0&&!!X.configurable&&!!X.enumerable&&!!X.writable&&X.get===void 0&&X.set===void 0}function Gr(X){if(typeof X!=="object"||X===null)throw new y("Incompatible instance received: should be a non-null object");let Y=JP(X)===null,Q=JP(X)===Qr;if(!Y&&!Q)throw new y("Incompatible instance received: should be of exact type Object");let J=O0(Jr(X),($)=>[$,Yr(X,$)]);if(!GE(J,([,$])=>_r($)))throw new y("Incompatible instance received: should contain only c/e/w properties without get/set");return[O0(J,([$,G])=>[$,G.value]),Y]}function Zr(X){return X[0]}function CW(X,Y,Q={}){let J=!!Q.noNullPrototype;return Z0(V5(Z0(X,Y),{minLength:Q.minKeys,maxLength:Q.maxKeys,size:Q.size,selector:Zr,depthIdentifier:Q.depthIdentifier}),J?y0(!1):iQ()).map($r,Gr)}var{POSITIVE_INFINITY:Kr,MAX_SAFE_INTEGER:Hr,isInteger:Wr}=Number,Ur=Math.floor,Dr=Math.pow,Nr=Math.min,sH=class X extends m0{static from(Y,Q,J){if(Y.length===0)throw Error(`${J} expects at least one weighted arbitrary`);let $=0;for(let Z=0;Z!==Y.length;++Z){if(Y[Z].arbitrary===void 0)throw Error(`${J} expects arbitraries to be specified`);let K=Y[Z].weight;if($+=K,!Wr(K))throw Error(`${J} expects weights to be integer values`);if(K<0)throw Error(`${J} expects weights to be superior or equal to 0`)}if($<=0)throw Error(`${J} expects the sum of weights to be strictly superior to 0`);let G={depthBias:Ci(Q.depthSize,Q.maxDepth!==void 0),maxDepth:Q.maxDepth!==void 0?Q.maxDepth:Kr,withCrossShrink:!!Q.withCrossShrink};return new X(Y,G,RW(Q.depthIdentifier))}constructor(Y,Q,J){super();this.warbs=Y,this.constraints=Q,this.context=J;let $=0;this.cumulatedWeights=[];for(let G=0;G!==Y.length;++G)$+=Y[G].weight,I(this.cumulatedWeights,$);this.totalWeight=$}generate(Y,Q){if(this.mustGenerateFirst())return this.safeGenerateForIndex(Y,0,Q);let J=Y.nextInt(this.computeNegDepthBenefit(),this.totalWeight-1);for(let $=0;$!==this.cumulatedWeights.length;++$)if(J<this.cumulatedWeights[$])return this.safeGenerateForIndex(Y,$,Q);throw Error("Unable to generate from fc.frequency")}canShrinkWithoutContext(Y){return this.canShrinkWithoutContextIndex(Y)!==-1}shrink(Y,Q){if(Q!==void 0){let $=Q,G=$.selectedIndex,Z=$.originalBias,K=this.warbs[G].arbitrary.shrink(Y,$.originalContext).map((H)=>this.mapIntoValue(G,H,null,Z));if($.clonedMrngForFallbackFirst!==null){if($.cachedGeneratedForFirst===void 0)$.cachedGeneratedForFirst=this.safeGenerateForIndex($.clonedMrngForFallbackFirst,0,Z);let H=$.cachedGeneratedForFirst;return K0.of(H).join(K)}return K}let J=this.canShrinkWithoutContextIndex(Y);if(J===-1)return K0.nil();return this.defaultShrinkForFirst(J).join(this.warbs[J].arbitrary.shrink(Y,void 0).map(($)=>this.mapIntoValue(J,$,null,void 0)))}defaultShrinkForFirst(Y){++this.context.depth;try{if(!this.mustFallbackToFirstInShrink(Y)||this.warbs[0].fallbackValue===void 0)return K0.nil()}finally{--this.context.depth}let Q=new g(this.warbs[0].fallbackValue.default,void 0);return K0.of(this.mapIntoValue(0,Q,null,void 0))}canShrinkWithoutContextIndex(Y){if(this.mustGenerateFirst())return this.warbs[0].arbitrary.canShrinkWithoutContext(Y)?0:-1;try{++this.context.depth;for(let Q=0;Q!==this.warbs.length;++Q){let J=this.warbs[Q];if(J.weight!==0&&J.arbitrary.canShrinkWithoutContext(Y))return Q}return-1}finally{--this.context.depth}}mapIntoValue(Y,Q,J,$){let G={selectedIndex:Y,originalBias:$,originalContext:Q.context,clonedMrngForFallbackFirst:J};return new g(Q.value,G)}safeGenerateForIndex(Y,Q,J){++this.context.depth;try{let $=this.warbs[Q].arbitrary.generate(Y,J),G=this.mustFallbackToFirstInShrink(Q)?Y.clone():null;return this.mapIntoValue(Q,$,G,J)}finally{--this.context.depth}}mustGenerateFirst(){return this.constraints.maxDepth<=this.context.depth}mustFallbackToFirstInShrink(Y){return Y!==0&&this.constraints.withCrossShrink&&this.warbs[0].weight!==0}computeNegDepthBenefit(){let Y=this.constraints.depthBias;if(Y<=0||this.warbs[0].weight===0)return 0;let Q=Ur(Dr(1+Y,this.context.depth))-1;return-Nr(this.totalWeight*Q,Hr)||0}};function Vr(X){return X!==null&&X!==void 0&&typeof X==="object"&&!("generate"in X)&&!("arbitrary"in X)&&!("weight"in X)}function $P(X){if(nP(X))return{arbitrary:X,weight:1};return X}function K1(...X){let Y=X[0];if(Vr(Y)){let J=O0(Z1(X,1),$P);return sH.from(J,Y,"fc.oneof")}let Q=O0(X,$P);return sH.from(Q,{},"fc.oneof")}var Br=Number.isInteger;function $4(X){let Y=typeof X==="number"?X:X&&X.max!==void 0?X.max:2147483647;if(Y<0)throw Error("fc.nat value should be greater than or equal to 0");if(!Br(Y))throw Error("fc.nat maximum value should be an integer");return new x9(0,Y)}var zr=Object.is;function qr(X){let Y=0,Q=[];for(let J of X){let $=Y;Y=$+J.num;let G=Y-1;Q.push({from:$,to:G,entry:J})}return Q}function Or(X,Y){let Q=0,J=X.length;while(J-Q>1){let $=~~((Q+J)/2);if(Y<X[$].from)J=$;else Q=$}return X[Q]}function Lr(X){let Y=qr(X);return function(J){let $=Or(Y,J);return $.entry.build(J-$.from)}}function Tr(X){let Y={mapping:new N8,negativeZeroIndex:void 0},Q=0;for(let J=0;J!==X.length;++J){let $=X[J];for(let G=0;G!==$.num;++G){let Z=$.build(G);if(Z===0&&1/Z===D8.NEGATIVE_INFINITY)Y.negativeZeroIndex=Q;else aX(Y.mapping,Z,Q);++Q}}return Y}function Fr(X){let Y=null;return function(J){if(Y===null)Y=Tr(X);let $=zr(J,-0)?Y.negativeZeroIndex:BX(Y.mapping,J);if($===void 0)throw new y("Unknown value encountered cannot be built using this mapToConstant");return $}}function Rr(X){if(X.length===0)throw new y("fc.mapToConstant expects at least one option");let Y=0;for(let Q=0;Q!==X.length;++Q){if(X[Q].num<0)throw new y("fc.mapToConstant expects all options to have a number of entries greater or equal to zero");Y+=X[Q].num}if(Y===0)throw new y("fc.mapToConstant expects at least one choice among options");return Y}function v9(...X){return $4({max:Rr(X)-1}).map(Lr(X),Fr(X))}function SE(X,Y,Q,J){if(Y.length===0){if(Q>0)return;return[]}if(J<=0)return;let $=[{endIndexChunks:0,nextStartIndex:1,chunks:[]}];while($.length>0){let G=JE($);for(let Z=G.nextStartIndex;Z<=Y.length;++Z){let K=u0(Y,G.endIndexChunks,Z);if(X.canShrinkWithoutContext(K)){let H=[...G.chunks,K];if(Z===Y.length){if(H.length<Q)break;return H}if(I($,{endIndexChunks:G.endIndexChunks,nextStartIndex:Z+1,chunks:G.chunks}),H.length<J)I($,{endIndexChunks:Z,nextStartIndex:Z+1,chunks:H});break}}}}function Ar(X){return h0(X,"")}function kE(X){return X.minLength!==void 0?X.minLength:0}function bE(X){return X.maxLength!==void 0?X.maxLength:N5}function Pr(X,Y){return kE(Y)<=X.length&&X.length<=bE(Y)}function Er(X,Y){return function(J){if(typeof J!=="string")throw new y("Unsupported value");let $=SE(X,J,kE(Y),bE(Y));if($===void 0)throw new y("Unable to unmap received string");return $}}var gE=["__defineGetter__","__defineSetter__","__lookupGetter__","__lookupSetter__","__proto__","constructor","hasOwnProperty","isPrototypeOf","propertyIsEnumerable","toLocaleString","toString","valueOf","apply","arguments","bind","call","caller","length","name","prototype","key","ref"];function Cr(X,Y,Q){let J;try{J=Q(X)}catch{return}for(let $ of J)if(!Y.canShrinkWithoutContext($))return;return J}function wr(X,Y){let Q=[];for(let J of gE){let $=Cr(J,X,Y);if($!==void 0)I(Q,$)}return Q}var _P=new WeakMap;function Mr(X){let Y=[];for(let Q of gE){let J=SE(X,Q,0,N5);if(J!==void 0)I(Y,J)}return Y}function jr(X,Y){let Q=Cl(_P,X);if(Q===void 0)Q=Mr(X),El(_P,X,Q);let J=[];for(let $ of Q)if(Pr($,Y))I(J,$);return J}var Ir=[[0,127]],xr=[[0,55295],[57344,1114111]],vr=[[32,126],[160,172],[174,767],[880,887],[890,895],[900,906],[908],[910,929],[931,1154],[1162,1327],[1329,1366],[1369,1418],[1421,1423],[1470],[1472],[1475],[1478],[1488,1514],[1519,1524],[1542,1551],[1563],[1565,1610],[1632,1647],[1649,1749],[1758],[1765,1766],[1769],[1774,1805],[1808],[1810,1839],[1869,1957],[1969],[1984,2026],[2036,2042],[2046,2069],[2074],[2084],[2088],[2096,2110],[2112,2136],[2142],[2144,2154],[2160,2190],[2208,2249],[2308,2361],[2365],[2384],[2392,2401],[2404,2432],[2437,2444],[2447,2448],[2451,2472],[2474,2480],[2482],[2486,2489],[2493],[2510],[2524,2525],[2527,2529],[2534,2557],[2565,2570],[2575,2576],[2579,2600],[2602,2608],[2610,2611],[2613,2614],[2616,2617],[2649,2652],[2654],[2662,2671],[2674,2676],[2678],[2693,2701],[2703,2705],[2707,2728],[2730,2736],[2738,2739],[2741,2745],[2749],[2768],[2784,2785],[2790,2801],[2809],[2821,2828],[2831,2832],[2835,2856],[2858,2864],[2866,2867],[2869,2873],[2877],[2908,2909],[2911,2913],[2918,2935],[2947],[2949,2954],[2958,2960],[2962,2965],[2969,2970],[2972],[2974,2975],[2979,2980],[2984,2986],[2990,3001],[3024],[3046,3066],[3077,3084],[3086,3088],[3090,3112],[3114,3129],[3133],[3160,3162],[3165],[3168,3169],[3174,3183],[3191,3200],[3204,3212],[3214,3216],[3218,3240],[3242,3251],[3253,3257],[3261],[3293,3294],[3296,3297],[3302,3311],[3313,3314],[3332,3340],[3342,3344],[3346,3386],[3389],[3407],[3412,3414],[3416,3425],[3430,3455],[3461,3478],[3482,3505],[3507,3515],[3517],[3520,3526],[3558,3567],[3572],[3585,3632],[3634],[3647,3654],[3663,3675],[3713,3714],[3716],[3718,3722],[3724,3747],[3749],[3751,3760],[3762],[3773],[3776,3780],[3782],[3792,3801],[3804,3807],[3840,3863],[3866,3892],[3894],[3896],[3898,3901],[3904,3911],[3913,3948],[3973],[3976,3980],[4030,4037],[4039,4044],[4046,4058],[4096,4138],[4159,4181],[4186,4189],[4193],[4197,4198],[4206,4208],[4213,4225],[4238],[4240,4249],[4254,4293],[4295],[4301],[4304,4351],[4608,4680],[4682,4685],[4688,4694],[4696],[4698,4701],[4704,4744],[4746,4749],[4752,4784],[4786,4789],[4792,4798],[4800],[4802,4805],[4808,4822],[4824,4880],[4882,4885],[4888,4954],[4960,4988],[4992,5017],[5024,5109],[5112,5117],[5120,5788],[5792,5880],[5888,5905],[5919,5937],[5941,5942],[5952,5969],[5984,5996],[5998,6000],[6016,6067],[6100,6108],[6112,6121],[6128,6137],[6144,6154],[6160,6169],[6176,6264],[6272,6276],[6279,6312],[6314],[6320,6389],[6400,6430],[6464],[6468,6509],[6512,6516],[6528,6571],[6576,6601],[6608,6618],[6622,6678],[6686,6740],[6784,6793],[6800,6809],[6816,6829],[6917,6963],[6981,6988],[6992,7018],[7028,7038],[7043,7072],[7086,7141],[7164,7203],[7227,7241],[7245,7304],[7312,7354],[7357,7367],[7379],[7401,7404],[7406,7411],[7413,7414],[7418],[7424,7615],[7680,7957],[7960,7965],[7968,8005],[8008,8013],[8016,8023],[8025],[8027],[8029],[8031,8061],[8064,8116],[8118,8132],[8134,8147],[8150,8155],[8157,8175],[8178,8180],[8182,8190],[8192,8202],[8208,8233],[8239,8287],[8304,8305],[8308,8334],[8336,8348],[8352,8384],[8448,8587],[8592,9254],[9280,9290],[9312,11123],[11126,11157],[11159,11502],[11506,11507],[11513,11557],[11559],[11565],[11568,11623],[11631,11632],[11648,11670],[11680,11686],[11688,11694],[11696,11702],[11704,11710],[11712,11718],[11720,11726],[11728,11734],[11736,11742],[11776,11869],[11904,11929],[11931,12019],[12032,12245],[12272,12329],[12336,12351],[12353,12438],[12443,12543],[12549,12591],[12593,12686],[12688,12771],[12783,12830],[12832,13312],[19903,19968],[40959,42124],[42128,42182],[42192,42539],[42560,42606],[42611],[42622,42653],[42656,42735],[42738,42743],[42752,42954],[42960,42961],[42963],[42965,42969],[42994,43009],[43011,43013],[43015,43018],[43020,43042],[43048,43051],[43056,43065],[43072,43127],[43138,43187],[43214,43225],[43250,43262],[43264,43301],[43310,43334],[43359],[43396,43442],[43457,43469],[43471,43481],[43486,43492],[43494,43518],[43520,43560],[43584,43586],[43588,43595],[43600,43609],[43612,43642],[43646,43695],[43697],[43701,43702],[43705,43709],[43712],[43714],[43739,43754],[43760,43764],[43777,43782],[43785,43790],[43793,43798],[43808,43814],[43816,43822],[43824,43883],[43888,44002],[44011],[44016,44025],[44032],[55203],[63744,64109],[64112,64217],[64256,64262],[64275,64279],[64285],[64287,64310],[64312,64316],[64318],[64320,64321],[64323,64324],[64326,64450],[64467,64911],[64914,64967],[64975],[65008,65023],[65040,65049],[65072,65106],[65108,65126],[65128,65131],[65136,65140],[65142,65276],[65281,65437],[65440,65470],[65474,65479],[65482,65487],[65490,65495],[65498,65500],[65504,65510],[65512,65518],[65532,65533],[65536,65547],[65549,65574],[65576,65594],[65596,65597],[65599,65613],[65616,65629],[65664,65786],[65792,65794],[65799,65843],[65847,65934],[65936,65948],[65952],[66000,66044],[66176,66204],[66208,66256],[66273,66299],[66304,66339],[66349,66378],[66384,66421],[66432,66461],[66463,66499],[66504,66517],[66560,66717],[66720,66729],[66736,66771],[66776,66811],[66816,66855],[66864,66915],[66927,66938],[66940,66954],[66956,66962],[66964,66965],[66967,66977],[66979,66993],[66995,67001],[67003,67004],[67072,67382],[67392,67413],[67424,67431],[67456,67461],[67463,67504],[67506,67514],[67584,67589],[67592],[67594,67637],[67639,67640],[67644],[67647,67669],[67671,67742],[67751,67759],[67808,67826],[67828,67829],[67835,67867],[67871,67897],[67903],[67968,68023],[68028,68047],[68050,68096],[68112,68115],[68117,68119],[68121,68149],[68160,68168],[68176,68184],[68192,68255],[68288,68324],[68331,68342],[68352,68405],[68409,68437],[68440,68466],[68472,68497],[68505,68508],[68521,68527],[68608,68680],[68736,68786],[68800,68850],[68858,68899],[68912,68921],[69216,69246],[69248,69289],[69293],[69296,69297],[69376,69415],[69424,69445],[69457,69465],[69488,69505],[69510,69513],[69552,69579],[69600,69622],[69635,69687],[69703,69709],[69714,69743],[69745,69746],[69749],[69763,69807],[69819,69820],[69822,69825],[69840,69864],[69872,69881],[69891,69926],[69942,69956],[69959],[69968,70002],[70004,70006],[70019,70066],[70081],[70084,70088],[70093],[70096,70111],[70113,70132],[70144,70161],[70163,70187],[70200,70205],[70207,70208],[70272,70278],[70280],[70282,70285],[70287,70301],[70303,70313],[70320,70366],[70384,70393],[70405,70412],[70415,70416],[70419,70440],[70442,70448],[70450,70451],[70453,70457],[70461],[70480],[70493,70497],[70656,70708],[70727,70747],[70749],[70751,70753],[70784,70831],[70852,70855],[70864,70873],[71040,71086],[71105,71131],[71168,71215],[71233,71236],[71248,71257],[71264,71276],[71296,71338],[71352,71353],[71360,71369],[71424,71450],[71472,71494],[71680,71723],[71739],[71840,71922],[71935,71942],[71945],[71948,71955],[71957,71958],[71960,71983],[72004,72006],[72016,72025],[72096,72103],[72106,72144],[72161,72163],[72192],[72203,72242],[72255,72262],[72272],[72284,72323],[72346,72354],[72368,72440],[72448,72457],[72704,72712],[72714,72750],[72768,72773],[72784,72812],[72816,72847],[72960,72966],[72968,72969],[72971,73008],[73040,73049],[73056,73061],[73063,73064],[73066,73097],[73112],[73120,73129],[73440,73458],[73463,73464],[73476,73488],[73490,73523],[73539,73561],[73648],[73664,73713],[73727,74649],[74752,74862],[74864,74868],[74880,75075],[77712,77810],[77824,78895],[78913,78918],[82944,83526],[92160,92728],[92736,92766],[92768,92777],[92782,92862],[92864,92873],[92880,92909],[92917],[92928,92975],[92983,92997],[93008,93017],[93019,93025],[93027,93047],[93053,93071],[93760,93850],[93952,94026],[94032],[94099,94111],[94176,94179],[94208],[100343],[100352,101589],[101632],[101640],[110576,110579],[110581,110587],[110589,110590],[110592,110882],[110898],[110928,110930],[110933],[110948,110951],[110960,111355],[113664,113770],[113776,113788],[113792,113800],[113808,113817],[113820],[113823],[118608,118723],[118784,119029],[119040,119078],[119081,119140],[119146,119148],[119171,119172],[119180,119209],[119214,119274],[119296,119361],[119365],[119488,119507],[119520,119539],[119552,119638],[119648,119672],[119808,119892],[119894,119964],[119966,119967],[119970],[119973,119974],[119977,119980],[119982,119993],[119995],[119997,120003],[120005,120069],[120071,120074],[120077,120084],[120086,120092],[120094,120121],[120123,120126],[120128,120132],[120134],[120138,120144],[120146,120485],[120488,120779],[120782,121343],[121399,121402],[121453,121460],[121462,121475],[121477,121483],[122624,122654],[122661,122666],[122928,122989],[123136,123180],[123191,123197],[123200,123209],[123214,123215],[123536,123565],[123584,123627],[123632,123641],[123647],[124112,124139],[124144,124153],[124896,124902],[124904,124907],[124909,124910],[124912,124926],[124928,125124],[125127,125135],[125184,125251],[125259],[125264,125273],[125278,125279],[126065,126132],[126209,126269],[126464,126467],[126469,126495],[126497,126498],[126500],[126503],[126505,126514],[126516,126519],[126521],[126523],[126530],[126535],[126537],[126539],[126541,126543],[126545,126546],[126548],[126551],[126553],[126555],[126557],[126559],[126561,126562],[126564],[126567,126570],[126572,126578],[126580,126583],[126585,126588],[126590],[126592,126601],[126603,126619],[126625,126627],[126629,126633],[126635,126651],[126704,126705],[126976,127019],[127024,127123],[127136,127150],[127153,127167],[127169,127183],[127185,127221],[127232,127405],[127488,127490],[127504,127547],[127552,127560],[127568,127569],[127584,127589],[127744,127994],[128000,128727],[128732,128748],[128752,128764],[128768,128886],[128891,128985],[128992,129003],[129008],[129024,129035],[129040,129095],[129104,129113],[129120,129159],[129168,129197],[129200,129201],[129280,129619],[129632,129645],[129648,129660],[129664,129672],[129680,129725],[129727,129733],[129742,129755],[129760,129768],[129776,129784],[129792,129938],[129940,129994],[130032,130041],[131072],[173791],[173824],[177977],[177984],[178205],[178208],[183969],[183984],[191456],[191472],[192093],[194560,195101],[196608],[201546],[201552],[205743]],Sr=[[192,197],[199,207],[209,214],[217,221],[224,229],[231,239],[241,246],[249,253],[255,271],[274,293],[296,304],[308,311],[313,318],[323,328],[332,337],[340,357],[360,382],[416,417],[431,432],[461,476],[478,483],[486,496],[500,501],[504,539],[542,543],[550,563],[901,902],[904,906],[908],[910,912],[938,944],[970,974],[979,980],[1024,1025],[1027],[1031],[1036,1038],[1049],[1081],[1104,1105],[1107],[1111],[1116,1118],[1142,1143],[1217,1218],[1232,1235],[1238,1239],[1242,1247],[1250,1255],[1258,1269],[1272,1273],[1570,1574],[1728],[1730],[1747],[2345],[2353],[2356],[2392,2399],[2524,2525],[2527],[2611],[2614],[2649,2651],[2654],[2908,2909],[2964],[3907],[3917],[3922],[3927],[3932],[3945],[4134],[6918],[6920],[6922],[6924],[6926],[6930],[7680,7833],[7835],[7840,7929],[7936,7957],[7960,7965],[7968,8005],[8008,8013],[8016,8023],[8025],[8027],[8029],[8031,8048],[8050],[8052],[8054],[8056],[8058],[8060],[8064,8116],[8118,8122],[8124],[8129,8132],[8134,8136],[8138],[8140,8146],[8150,8154],[8157,8162],[8164,8170],[8172,8173],[8178,8180],[8182,8184],[8186],[8188],[8602,8603],[8622],[8653,8655],[8708],[8713],[8716],[8740],[8742],[8769],[8772],[8775],[8777],[8800],[8802],[8813,8817],[8820,8821],[8824,8825],[8832,8833],[8836,8837],[8840,8841],[8876,8879],[8928,8931],[8938,8941],[10972],[12364],[12366],[12368],[12370],[12372],[12374],[12376],[12378],[12380],[12382],[12384],[12386],[12389],[12391],[12393],[12400,12401],[12403,12404],[12406,12407],[12409,12410],[12412,12413],[12436],[12446],[12460],[12462],[12464],[12466],[12468],[12470],[12472],[12474],[12476],[12478],[12480],[12482],[12485],[12487],[12489],[12496,12497],[12499,12500],[12502,12503],[12505,12506],[12508,12509],[12532],[12535,12538],[12542],[44032],[55203],[64285],[64287],[64298,64310],[64312,64316],[64318],[64320,64321],[64323,64324],[64326,64334],[69786],[69788],[69803],[119134,119140],[119227,119232]],GP=String.fromCodePoint,kr=Math.min,br=Math.max;function aH(X){if(X.length===1){let Q=GP(X[0]);return{num:1,build:()=>Q}}let Y=X[0];return{num:X[1]-X[0]+1,build:(Q)=>GP(Y+Q)}}function ZP(X,Y){let Q=[],J=0,$=0;while(J<X.length&&$<Y.length){let G=X[J],Z=G[0],K=G.length===1?G[0]:G[1],H=Y[$],W=H[0],D=H.length===1?H[0]:H[1];if(K<W)J+=1;else if(D<Z)$+=1;else{let U=br(Z,W),N=kr(K,D);if(Q.length>=1){let V=Q[Q.length-1];if((V.length===1?V[0]:V[1])+1===U)U=V[0],JE(Q)}if(I(Q,U===N?[U]:[U,N]),K<=N)J+=1;if(D<=N)$+=1}}return Q}var KP=Object.create(null);function gr(X){switch(X){case"full":return xr;case"ascii":return Ir}}function yr(X,Y){let Q=`${X}:${Y}`,J=KP[Q];if(J!==void 0)return J;let $=gr(Y),G=X==="binary"?$:ZP($,vr),Z=[];for(let H of G)I(Z,aH(H));if(X==="grapheme"){let H=ZP($,Sr);for(let W of H){let D=aH(W);I(Z,{num:D.num,build:(U)=>cl(D.build(U),"NFD")})}}let K=v9(...Z);return KP[Q]=K,K}function yQ(X,Y){return yr(X,Y)}function hr(X){if(typeof X.unit==="object")return X.unit;switch(X.unit){case"grapheme":return yQ("grapheme","full");case"grapheme-composite":return yQ("composite","full");case"grapheme-ascii":case void 0:return yQ("grapheme","ascii");case"binary":return yQ("binary","full");case"binary-ascii":return yQ("binary","ascii")}}function e0(X={}){let Y=hr(X),Q=Er(Y,X),J=jr(Y,X);return M0(Y,{...X,experimentalCustomSlices:J}).map(Ar,Q)}var yE=Map,wW=String.fromCharCode,MW={num:26,build:(X)=>wW(X+97)},mr={num:26,build:(X)=>wW(X+65)},hE={num:10,build:(X)=>wW(X+48)};function fr(X){let Y=Jl(X);return X!==Y?Y:`%${dQ(j9(X,0),16)}`}function pr(X){if(typeof X!=="string")throw Error("Unsupported");return decodeURIComponent(X)}var dr=()=>e0({unit:"binary",minLength:1,maxLength:1}).map(fr,pr),wH=void 0;function ur(){if(wH===void 0)wH=v9(MW);return wH}var O$=void 0;function tH(X){if(O$===void 0)O$=new yE;let Y=BX(O$,X);if(Y===void 0)Y=v9(MW,hE,{num:X.length,build:(Q)=>X[Q]}),aX(O$,X,Y);return Y}function cr(X){return v9(MW,mr,hE,{num:X.length,build:(Y)=>X[Y]})}var L$=void 0;function jW(X){if(L$===void 0)L$=new yE;let Y=BX(L$,X);if(Y===void 0)Y=K1({weight:10,arbitrary:cr(X)},{weight:1,arbitrary:dr()}),aX(L$,X,Y);return Y}function B8(X,Y={}){let Q=Y.freq===void 0?6:Y.freq,J=ZE(Y,"nil")?Y.nil:null,$=[{arbitrary:y0(J),weight:1,fallbackValue:{default:J}},{arbitrary:X,weight:Q-1}],G={withCrossShrink:!0,depthSize:Y.depthSize,maxDepth:Y.maxDepth,depthIdentifier:Y.depthIdentifier};return sH.from($,G,"fc.option")}function lr(X){if(X.length>63)return!1;return X.length<4||X[0]!=="x"||X[1]!=="n"||X[2]!=="-"||X[3]!=="-"}var mE=Symbol("adapted-value");function or(X,Y){let Q=Y(X.value_);if(!Q.adapted)return X;return new g(Q.value,mE)}var ir=class extends m0{constructor(X,Y){super();this.sourceArb=X,this.adapter=Y,this.adaptValue=(Q)=>or(Q,Y)}generate(X,Y){let Q=this.sourceArb.generate(X,Y);return this.adaptValue(Q)}canShrinkWithoutContext(X){return this.sourceArb.canShrinkWithoutContext(X)&&!this.adapter(X).adapted}shrink(X,Y){if(Y===mE){if(!this.sourceArb.canShrinkWithoutContext(X))return K0.nil();return this.sourceArb.shrink(X,void 0).map(this.adaptValue)}return this.sourceArb.shrink(X,Y).map(this.adaptValue)}};function fE(X,Y){return new ir(X,Y)}function rr([X,Y]){return Y===null?X:`${X}${Y[0]}${Y[1]}`}function nr(X){if(typeof X!=="string"||X.length===0)throw Error("Unsupported");if(X.length===1)return[X[0],null];return[X[0],[u0(X,1,X.length-1),X[X.length-1]]]}function sr(X){let Y=tH("");return Z0(Y,B8(Z0(e0({unit:tH("-"),size:X,maxLength:61}),Y))).map(rr,nr).filter(lr)}function ar(X){return`${h0(X[0],".")}.${X[1]}`}function tr(X){if(typeof X!=="string")throw Error("Unsupported type");let Y=X.lastIndexOf(".");return[d1(u0(X,0,Y),"."),u0(X,Y+1)]}function er(X){let[Y,Q]=X,J=Q.length;for(let $=0;$!==Y.length;++$)if(J+=1+Y[$].length,J>255)return{adapted:!0,value:[Z1(Y,0,$),Q]};return{adapted:!1,value:X}}function IW(X={}){let Y=EW(X.size),Q=oQ("-1",Y),J=e0({unit:ur(),minLength:2,maxLength:63,size:Q});return fE(Z0(M0(sr(Y),{size:Q,minLength:1,maxLength:127}),J),er).map(ar,tr)}function Xn(X){let Y=X[0].length;for(let Q=1;Q!==X.length;++Q)if(Y+=1+X[Q].length,Y>64)return{adapted:!0,value:Z1(X,0,Q)};return{adapted:!1,value:X}}function Yn(X){return h0(X,".")}function Qn(X){if(typeof X!=="string")throw Error("Unsupported");return d1(X,".")}function Jn(X){return`${X[0]}@${X[1]}`}function $n(X){if(typeof X!=="string")throw Error("Unsupported");return d1(X,"@",2)}function _n(X={}){return Z0(fE(M0(e0({unit:tH("!#$%&'*+-/=?^_`{|}~"),minLength:1,maxLength:64,size:X.size}),{minLength:1,maxLength:32,size:X.size}),Xn).map(Yn,Qn),IW({size:X.size})).map(Jn,$n)}var{NEGATIVE_INFINITY:Gn,POSITIVE_INFINITY:eH,EPSILON:pE}=D8,xW=b(2146435072)*b(4294967296),Zn=-xW-b(1),HP=4503599627370496,Kn=b(4503599627370495),WP=b("9007199254740992"),XW=new Float64Array(1),UP=new Uint32Array(XW.buffer,XW.byteOffset);function Hn(X){return XW[0]=X,[UP[1],UP[0]]}function Wn(X){let{0:Y,1:Q}=Hn(X),J=Y>>>31,$=Y>>>20&2047,G=(Y&1048575)*4294967296+Q,Z=$===0?-1022:$-1023,K=$===0?0:1;return K+=G*pE,K*=J===0?1:-1,{exponent:Z,significand:K}}function DP(X,Y){if(X===-1022)return b(Y*HP);return b((Y-1)*HP)+(b(X+1023)<<b(52))}function vW(X){if(X===eH)return xW;if(X===Gn)return Zn;let Y=Wn(X),Q=Y.exponent,J=Y.significand;if(X>0||X===0&&1/X===eH)return DP(Q,J);else return-DP(Q,-J)-b(1)}function YW(X){if(X<0)return-YW(-X-b(1));if(X===xW)return eH;if(X<WP)return D8(X)*0.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005;let Y=X-WP,Q=-1021+D8(Y>>b(52));return(1+D8(Y&Kn)*pE)*2**Q}var NP=Number.isInteger,VP=Object.is,MH=Number.NEGATIVE_INFINITY,jH=Number.POSITIVE_INFINITY;function dE(X,Y,Q,J){let{noDefaultInfinity:$=!1,minExcluded:G=!1,maxExcluded:Z=!1,min:K=$?-Y:MH,max:H=$?Y:jH}=X,W=G?K<-Q?-J:Math.max(K,-Q):K===MH?Math.max(K,-J):Math.max(K,-Q),D=Z?H>Q?J:Math.min(H,Q):H===jH?Math.min(H,J):Math.min(H,Q);return{noDefaultInfinity:!1,minExcluded:G||(K!==MH||G)&&NP(W),maxExcluded:Z||(H!==jH||Z)&&NP(D),min:VP(W,-0)?0:W,max:VP(D,0)?-0:D,noNaN:X.noNaN||!1}}var{NEGATIVE_INFINITY:uE,POSITIVE_INFINITY:cE,MAX_VALUE:Un}=Number,Dn=4503599627370495.5,lE=4503599627370496;function Nn(X){return dE(X,Un,Dn,lE)}function Vn(X){return X===4503599627370496?cE:X===-4503599627370496?uE:X}function Bn(X){if(typeof X!=="number")throw Error("Unsupported type");return X===cE?lE:X===uE?-4503599627370496:X}var{isInteger:zn,isNaN:oE,NEGATIVE_INFINITY:qn,POSITIVE_INFINITY:On,MAX_VALUE:BP}=Number,Ln=NaN;function zP(X,Y){if(oE(X))throw Error("fc.double constraints."+Y+" must be a 64-bit float");return vW(X)}function Tn(X){if(typeof X!=="number")throw Error("Unsupported type");return vW(X)}function Fn(X){return!zn(X)}function qP(X){let{noDefaultInfinity:Y=!1,noNaN:Q=!1,minExcluded:J=!1,maxExcluded:$=!1,min:G=Y?-BP:qn,max:Z=Y?BP:On}=X,K=zP(G,"min"),H=J?K+b(1):K,W=zP(Z,"max"),D=$?W-b(1):W;if(D<H)throw Error("fc.double constraints.min must be smaller or equal to constraints.max");if(Q)return Z4({min:H,max:D}).map(YW,Tn);let U=D>b(0),N=U?H:H-b(1),V=U?D+b(1):D;return Z4({min:N,max:V}).map((z)=>{if(D<z||z<H)return Ln;else return YW(z)},(z)=>{if(typeof z!=="number")throw Error("Unsupported type");if(oE(z))return D!==V?V:N;return vW(z)})}function h$(X={}){if(!X.noInteger)return qP(X);return qP(Nn(X)).map(Vn,Bn).filter(Fn)}var{NEGATIVE_INFINITY:Rn,POSITIVE_INFINITY:QW}=Number,An=Math.imul,JW=340282346638528860000000000000000000000,iE=2139095040,Pn=-2139095041,$W=new Float32Array(1),En=new Uint32Array($W.buffer,$W.byteOffset);function Cn(X){return $W[0]=X,En[0]}function wn(X){let Y=Cn(X),Q=Y>>>31,J=Y>>>23&255,$=Y&8388607,G=J===0?-126:J-127,Z=J===0?0:1;return Z+=$/8388608,Z*=Q===0?1:-1,{exponent:G,significand:Z}}function OP(X,Y){if(X===-126)return Y*8388608;return An(X+127,8388608)+(Y-1)*8388608}function SW(X){if(X===QW)return iE;if(X===Rn)return Pn;let Y=wn(X),Q=Y.exponent,J=Y.significand;if(X>0||X===0&&1/X===QW)return OP(Q,J);else return-OP(Q,-J)-1}function _W(X){if(X<0)return-_W(-X-1);if(X===iE)return QW;if(X<16777216)return X*0.000000000000000000000000000000000000000000001401298464324817;let Y=X-16777216,Q=-125+(Y>>23);return(1+(Y&8388607)/8388608)*2**Q}var{NEGATIVE_INFINITY:rE,POSITIVE_INFINITY:nE}=Number,Mn=JW,jn=8388607.5,sE=8388608;function In(X){return dE(X,Mn,jn,sE)}function xn(X){return X===8388608?nE:X===-8388608?rE:X}function vn(X){if(typeof X!=="number")throw Error("Unsupported type");return X===nE?sE:X===rE?-8388608:X}var{isInteger:Sn,isNaN:aE}=Number,kn=Math.fround,bn=Number.NEGATIVE_INFINITY,gn=Number.POSITIVE_INFINITY,yn=NaN;function LP(X,Y){let Q="fc.float constraints."+Y+" must be a 32-bit float - you can convert any double to a 32-bit float by using `Math.fround(myDouble)`";if(aE(X)||kn(X)!==X)throw Error(Q);return SW(X)}function hn(X){if(typeof X!=="number")throw Error("Unsupported type");return SW(X)}function mn(X){return!Sn(X)}function TP(X){let{noDefaultInfinity:Y=!1,noNaN:Q=!1,minExcluded:J=!1,maxExcluded:$=!1,min:G=Y?-JW:bn,max:Z=Y?JW:gn}=X,K=LP(G,"min"),H=J?K+1:K,W=LP(Z,"max"),D=$?W-1:W;if(H>D)throw Error("fc.float constraints.min must be smaller or equal to constraints.max");if(Q)return E0({min:H,max:D}).map(_W,hn);let U=D>0?H:H-1,N=D>0?D+1:D;return E0({min:U,max:N}).map((V)=>{if(V>D||V<H)return yn;else return _W(V)},(V)=>{if(typeof V!=="number")throw Error("Unsupported type");if(aE(V))return D!==N?N:U;return SW(V)})}function tE(X={}){if(!X.noInteger)return TP(X);return TP(In(X)).map(xn,vn).filter(mn)}function fn(X){return X.replace(/([$`\\])/g,"\\$1").replace(/\r/g,"\\r")}function eE(X){return X.replace(/\*\//g,"*\\/")}var NX=[0,1996959894,3993919788,2567524794,124634137,1886057615,3915621685,2657392035,249268274,2044508324,3772115230,2547177864,162941995,2125561021,3887607047,2428444049,498536548,1789927666,4089016648,2227061214,450548861,1843258603,4107580753,2211677639,325883990,1684777152,4251122042,2321926636,335633487,1661365465,4195302755,2366115317,997073096,1281953886,3579855332,2724688242,1006888145,1258607687,3524101629,2768942443,901097722,1119000684,3686517206,2898065728,853044451,1172266101,3705015759,2882616665,651767980,1373503546,3369554304,3218104598,565507253,1454621731,3485111705,3099436303,671266974,1594198024,3322730930,2970347812,795835527,1483230225,3244367275,3060149565,1994146192,31158534,2563907772,4023717930,1907459465,112637215,2680153253,3904427059,2013776290,251722036,2517215374,3775830040,2137656763,141376813,2439277719,3865271297,1802195444,476864866,2238001368,4066508878,1812370925,453092731,2181625025,4111451223,1706088902,314042704,2344532202,4240017532,1658658271,366619977,2362670323,4224994405,1303535960,984961486,2747007092,3569037538,1256170817,1037604311,2765210733,3554079995,1131014506,879679996,2909243462,3663771856,1141124467,855842277,2852801631,3708648649,1342533948,654459306,3188396048,3373015174,1466479909,544179635,3110523913,3462522015,1591671054,702138776,2966460450,3352799412,1504918807,783551873,3082640443,3233442989,3988292384,2596254646,62317068,1957810842,3939845945,2647816111,81470997,1943803523,3814918930,2489596804,225274430,2053790376,3826175755,2466906013,167816743,2097651377,4027552580,2265490386,503444072,1762050814,4150417245,2154129355,426522225,1852507879,4275313526,2312317920,282753626,1742555852,4189708143,2394877945,397917763,1622183637,3604390888,2714866558,953729732,1340076626,3518719985,2797360999,1068828381,1219638859,3624741850,2936675148,906185462,1090812512,3747672003,2825379669,829329135,1181335161,3412177804,3160834842,628085408,1382605366,3423369109,3138078467,570562233,1426400815,3317316542,2998733608,733239954,1555261956,3268935591,3050360625,752459403,1541320221,2607071920,3965973030,1969922972,40735498,2617837225,3943577151,1913087877,83908371,2512341634,3803740692,2075208622,213261112,2463272603,3855990285,2094854071,198958881,2262029012,4057260610,1759359992,534414190,2176718541,4139329115,1873836001,414664567,2282248934,4279200368,1711684554,285281116,2405801727,4167216745,1634467795,376229701,2685067896,3608007406,1308918612,956543938,2808555105,3495958263,1231636301,1047427035,2932959818,3654703836,1088359270,936918000,2847714899,3736837829,1202900863,817233897,3183342108,3401237130,1404277552,615818150,3134207493,3453421203,1423857449,601450431,3009837614,3294710456,1567103746,711928724,3020668471,3272380065,1510334235,755167117];function k$(X){let Y=4294967295;for(let Q=0;Q<X.length;++Q){let J=j9(X,Q);if(J<128)Y=NX[Y&255^J]^Y>>8;else if(J<2048)Y=NX[Y&255^(192|J>>6&31)]^Y>>8,Y=NX[Y&255^(128|J&63)]^Y>>8;else if(J>=55296&&J<57344){let $=j9(X,++Q);if(J>=56320||$<56320||$>57343||Number.isNaN($))Q-=1,Y=NX[Y&255^239]^Y>>8,Y=NX[Y&255^191]^Y>>8,Y=NX[Y&255^189]^Y>>8;else{let G=(J&1023)+64,Z=$&1023;Y=NX[Y&255^(240|G>>8&7)]^Y>>8,Y=NX[Y&255^(128|G>>2&63)]^Y>>8,Y=NX[Y&255^(128|Z>>6&15|(G&3)<<4)]^Y>>8,Y=NX[Y&255^(128|Z&63)]^Y>>8}}else Y=NX[Y&255^(224|J>>12&15)]^Y>>8,Y=NX[Y&255^(128|J>>6&63)]^Y>>8,Y=NX[Y&255^(128|J&63)]^Y>>8}return(Y|0)+2147483648}var pn=Object.getPrototypeOf,hQ=class extends m0{constructor(X){super();this.arb=X}generate(X,Y){return this.arb.generate(X,Y)}canShrinkWithoutContext(X){return this.arb.canShrinkWithoutContext(X)}shrink(X,Y){return K0.nil()}};function b$(X){if(pn(X)===hQ.prototype&&X.generate===hQ.prototype.generate&&X.canShrinkWithoutContext===hQ.prototype.canShrinkWithoutContext&&X.shrink===hQ.prototype.shrink)return X;return new hQ(X)}var{assign:dn,keys:un}=Object;function XC(X){return Z0(b$(E0()),b$(E0({min:1,max:4294967295}))).map(([Y,Q])=>{let J=()=>{let $={};return dn((Z,K)=>{let H=s0(Z),W=s0(K),D=X(k$(`${Y}${H}`)%Q,k$(`${Y}${W}`)%Q);return $[`[${H},${W}]`]=D,D},{toString:()=>{let Z=un($).sort().map((K)=>`${K} => ${s0($[K])}`).map((K)=>`/* ${eE(K)} */`);return`function(a, b) {
  // With hash and stringify coming from fast-check${Z.length!==0?`
  ${h0(Z,`
  `)}`:""}
  const cmp = ${X};
  const hA = hash('${Y}' + stringify(a)) % ${Q};
  const hB = hash('${Y}' + stringify(b)) % ${Q};
  return cmp(hA, hB);
}`},[H1]:J})};return J()})}var cn=Object.assign;function ln(){return XC(cn((X,Y)=>X<Y,{toString(){return"(hA, hB) => hA < hB"}}))}var on=Object.assign;function rn(){return XC(on((X,Y)=>X-Y,{toString(){return"(hA, hB) => hA - hB"}}))}var{defineProperties:nn,keys:sn}=Object;function an(X){return Z0(M0(X,{minLength:1}),b$(E0())).map(([Y,Q])=>{let J=()=>{let $={},G=(...K)=>{let H=s0(K),W=Y[k$(`${Q}${H}`)%Y.length];return $[H]=W,D5(W)?W[H1]():W};function Z(K){let H=O0(O0(_E(sn($)),(W)=>`${W} => ${s0($[W])}`),(W)=>`/* ${eE(W)} */`);return`function(...args) {
  // With hash and stringify coming from fast-check${H.length!==0?`
  ${H.join(`
  `)}`:""}
  const outs = ${K};
  return outs[hash('${Q}' + stringify(args)) % outs.length];
}`}return nn(G,{toString:{value:()=>Z(s0(Y))},[X6]:{value:()=>Z(s0(Y))},[V8]:{value:async()=>Z(await LW(Y))},[H1]:{value:J,configurable:!0}})};return J()})}var{MIN_SAFE_INTEGER:tn,MAX_SAFE_INTEGER:en}=Number;function YC(){return new x9(tn,en)}var Xs=Number.MAX_SAFE_INTEGER;function Ys(){return new x9(0,Xs)}var Qs=Number.parseInt;function Js(X){let[Y,Q]=X;switch(Y){case"oct":return`0${dQ(Q,8)}`;case"hex":return`0x${dQ(Q,16)}`;default:return`${Q}`}}function E$(X,Y){let Q=Qs(X,Y);if(dQ(Q,Y)!==X)throw Error("Invalid value");return Q}function $s(X){if(typeof X!=="string")throw Error("Invalid type");if(X.length>=2&&X[0]==="0"){if(X[1]==="x")return["hex",E$(u0(X,2),16)];return["oct",E$(u0(X,1),8)]}return["dec",E$(X,10)]}function _s(X){return h0(X,".")}function Gs(X){if(typeof X!=="string")throw Error("Invalid type");return O0(d1(X,"."),(Y)=>E$(Y,10))}function kW(){return Z0($4(255),$4(255),$4(255),$4(255)).map(_s,Gs)}function w6(X){return Z0(M6("dec","oct","hex"),$4(X)).map(Js,$s)}function IH(X){return h0(X,".")}function xH(X){if(typeof X!=="string")throw Error("Invalid type");return d1(X,".")}function QC(){return K1(Z0(w6(255),w6(255),w6(255),w6(255)).map(IH,xH),Z0(w6(255),w6(255),w6(65535)).map(IH,xH),Z0(w6(255),w6(16777215)).map(IH,xH),w6(4294967295))}function bW(X){if(X.length===0)return[];else return d1(X,":")}function gW(X){let Y=d1(X,":");if(Y.length>=2&&Y[Y.length-1].length<=4)return[Z1(Y,0,Y.length-2),`${Y[Y.length-2]}:${Y[Y.length-1]}`];return[Z1(Y,0,Y.length-1),Y[Y.length-1]]}function Zs(X){return`${h0(X[0],":")}:${X[1]}`}function Ks(X){if(typeof X!=="string")throw Error("Invalid type");return gW(X)}function Hs(X){return`::${h0(X[0],":")}:${X[1]}`}function Ws(X){if(typeof X!=="string")throw Error("Invalid type");if(!pl(X,"::"))throw Error("Invalid value");return gW(u0(X,2))}function C$(X){return`${h0(X[0],":")}::${h0(X[1],":")}:${X[2]}`}function w$(X){if(typeof X!=="string")throw Error("Invalid type");let[Y,Q]=d1(X,"::",2),[J,$]=gW(Q);return[bW(Y),J,$]}function Us(X){return C$([X[0],[X[1]],X[2]])}function Ds(X){let Y=w$(X);return[Y[0],h0(Y[1],":"),Y[2]]}function FP(X){return`${h0(X[0],":")}::${X[1]}`}function RP(X){if(typeof X!=="string")throw Error("Invalid type");let[Y,Q]=d1(X,"::",2);return[bW(Y),Q]}function Ns(X){return`${h0(X[0],":")}::`}function Vs(X){if(typeof X!=="string")throw Error("Invalid type");if(!dl(X,"::"))throw Error("Invalid value");return[bW(u0(X,0,X.length-2))]}function Bs([X,Y]){return`${X}:${Y}`}function zs(X){if(typeof X!=="string")throw new y("Invalid type");if(!X.includes(":"))throw new y("Invalid value");return X.split(":",2)}var qs="0123456789abcdef",vH=void 0;function Os(){if(vH===void 0)vH=E0({min:0,max:15}).map((X)=>qs[X],(X)=>{if(typeof X!=="string")throw new y("Not a string");if(X.length!==1)throw new y("Invalid length");let Y=j9(X,0);if(Y<=57)return Y-48;if(Y<97)throw new y("Invalid character");return Y-87});return vH}function JC(){let X=e0({unit:Os(),minLength:1,maxLength:4,size:"max"}),Y=K1(Z0(X,X).map(Bs,zs),kW());return K1(Z0(M0(X,{minLength:6,maxLength:6,size:"max"}),Y).map(Zs,Ks),Z0(M0(X,{minLength:5,maxLength:5,size:"max"}),Y).map(Hs,Ws),Z0(M0(X,{minLength:0,maxLength:1,size:"max"}),M0(X,{minLength:4,maxLength:4,size:"max"}),Y).map(C$,w$),Z0(M0(X,{minLength:0,maxLength:2,size:"max"}),M0(X,{minLength:3,maxLength:3,size:"max"}),Y).map(C$,w$),Z0(M0(X,{minLength:0,maxLength:3,size:"max"}),M0(X,{minLength:2,maxLength:2,size:"max"}),Y).map(C$,w$),Z0(M0(X,{minLength:0,maxLength:4,size:"max"}),X,Y).map(Us,Ds),Z0(M0(X,{minLength:0,maxLength:5,size:"max"}),Y).map(FP,RP),Z0(M0(X,{minLength:0,maxLength:6,size:"max"}),X).map(FP,RP),Z0(M0(X,{minLength:0,maxLength:7,size:"max"})).map(Ns,Vs))}var Ls=class extends m0{constructor(X){super();this.name=X,this.underlying=null}generate(X,Y){if(this.underlying===null)throw Error(`Lazy arbitrary ${JSON.stringify(this.name)} not correctly initialized`);return this.underlying.generate(X,Y)}canShrinkWithoutContext(X){if(this.underlying===null)throw Error(`Lazy arbitrary ${JSON.stringify(this.name)} not correctly initialized`);return this.underlying.canShrinkWithoutContext(X)}shrink(X,Y){if(this.underlying===null)throw Error(`Lazy arbitrary ${JSON.stringify(this.name)} not correctly initialized`);return this.underlying.shrink(X,Y)}},Ts=Object.getOwnPropertyNames;function Fs(){let X=new N8;return(Q)=>{let J=BX(X,Q);if(J!==void 0)return J;return J=new Ls(String(Q)),aX(X,Q,J),J}}function $C(X){let Y=Fs(),Q=X(Y),J=Ts(Q);for(let $ of J){let G=Y($);G.underlying=Q[$]}return Q}function Rs(X,Y){for(let Q of X){let J=Y[Q]||{};if(J.maxLength===void 0||J.maxLength>0)return!0}return!1}function As(X,Y){if(X.length===0)return y0([]);if(!Rs(X,Y))throw new y("Contraints on pool must accept at least one entity, maxLength cannot sum to 0");return Z0(...X.map((Q)=>M0(y0(Q),Y[Q]))).map((Q)=>zl(Q)).filter((Q)=>Q.length>0)}var{assign:AP,create:M$,defineProperty:_C,getPrototypeOf:PP,prototype:Ps}=Object;function Es(X){return _C(M$(null),X6,{configurable:!1,enumerable:!1,writable:!1,value:()=>X})}function EP(X,Y){return Es(`<${p1(X)}#${Y}>`)}function Cs(X,Y){let Q=M$(Ps);for(let J in X){let $=X[J],G=[];for(let Z of $){let K=AP(M$(PP(Z)),Z);G.push(K)}Q[J]=G}for(let J in Y){let $=Y[J];for(let G=0;G!==$.length;++G){let Z=$[G],K=Q[J][G];for(let H in Z){let W=Z[H];K[H]=W.index===void 0?void 0:typeof W.index==="number"?Q[W.type][W.index]:O0(W.index,(D)=>Q[W.type][D])}_C(K,X6,{configurable:!1,enumerable:!1,writable:!1,value:()=>{let H=X[J][G],W=AP(M$(PP(H)),H);for(let D in Z){let U=Z[D];W[D]=U.index===void 0?void 0:typeof U.index==="number"?EP(U.type,U.index):O0(U.index,(N)=>EP(U.type,N))}return s0(W)}})}}return Q}function ws(X){let Y=0,Q=new N8;for(let $ in X){let G=X[$];for(let Z in G){let K=G[Z];if(K.arity!=="inverse")continue;let H=BX(Q,K.type);if(H===void 0)H=new N8,aX(Q,K.type,H);if(Il(H,K.forwardRelationship))throw new y(`Cannot declare multiple inverse relationships for the same forward relationship ${p1(K.forwardRelationship)} on type ${p1(K.type)}`);aX(H,K.forwardRelationship,{type:$,property:Z}),Y+=1}}let J=new N8;if(Y===0)return J;for(let $ in X){let G=X[$],Z=BX(Q,$);if(Z===void 0)continue;for(let K in G){let H=G[K];if(H.arity==="inverse")continue;let W=BX(Z,K);if(W===void 0)continue;if(W.type!==H.type)throw new y(`Inverse relationship ${p1(W.property)} on type ${p1(W.type)} references forward relationship ${p1(K)} but types do not match`);aX(J,H,W)}}if(J.size!==Y)throw new y("Some inverse relationships could not be matched with their corresponding forward relationships");return J}var{assign:CP,create:g$}=Object;function Ms(X,Y,Q){switch(X){case"exclusive":return y0(Q);case"successor":return S$(E0({min:Y!==void 0?Y+1:0,max:Q}));case"any":return S$(E0({min:0,max:Q}))}}function js(X,Y,Q,J,$){let G=Ms(Y,Q,J);switch(X){case"0-1":return B8(G,{nil:void 0,depthIdentifier:$});case"1":return G;case"many":{let Z=0;return B8(V5(G,{depthIdentifier:$,selector:(K)=>K===J?K+ ++Z:K,minLength:1}),{nil:[],depthIdentifier:$}).map((K)=>{let H=0;return O0(K,(W)=>W===J?W+H++:W)})}}}function GC(X,Y){let Q=g$(null),J=X[Y];for(let $ in J){let G=J[$];if(G.arity==="inverse")Q[$]={type:G.type,index:[]}}return Q}function Is(X){let Y=new tX,Q=new tX;for(let J in X){let $=X[J];for(let G in $){let Z=$[G];if(Z.arity==="inverse")continue;if(Z.strategy==="exclusive"){if(J4(Y,Z.type))throw new y(`Cannot mix exclusive with other strategies for type ${p1(Z.type)}`);pQ(Q,Z.type)}else{if(J4(Q,Z.type))throw new y(`Cannot mix exclusive with other strategies for type ${p1(Z.type)}`);pQ(Y,Z.type)}if(Z.strategy==="successor"&&Z.type!==J)throw new y("Cannot mix types for the strategy successor");if(Z.strategy==="successor"&&Z.arity==="1")throw new y("Cannot use an arity of 1 for the strategy successor")}}}function xs(X,Y){let{producedLinks:Q,toBeProducedEntities:J}=X,$=X.nextIndex+Y,G=CP(g$(null),Q);function Z(U){if(G[U]===Q[U])G[U]=Z1(Q[U]);return G[U]}function K(U,N){let V=Z(U);if(V[N]===Q[U][N])V[N]=CP(g$(null),Q[U][N]);return V[N]}function H(U,N,V){let z=K(U,N),q=Q[U][N];if(q!==void 0&&z[V]===q[V]){let F=z[V];z[V]={type:F.type,index:typeof F.index==="object"?Z1(F.index):F.index}}return z[V]}let W=void 0,D=J[$];return{setOutboundLink:(U,N)=>{let V=K(D.type,D.indexInType);V[U]=N},enqueueNewEntity:(U,N)=>{let V=Z(N),z=V.length;if(W===void 0)W=Z1(J);return I(W,{type:N,indexInType:z,depth:D.depth+1}),I(V,GC(U,N)),z},appendBackReference:(U,N,V)=>{let z=H(U,N,V).index;I(z,D.indexInType)},commit:()=>({producedLinks:G,toBeProducedEntities:W!==void 0?W:J,nextIndex:$+1})}}function vs(X,Y){let Q=g$(null);for(let $ in X)Q[$]=[];let J=[];for(let $ of Y)I(J,{type:$,indexInType:Q[$].length,depth:0}),I(Q[$],GC(X,$));return{producedLinks:Q,toBeProducedEntities:J,nextIndex:0}}function Ss(X,Y,Q,J){let $=Q.producedLinks,G=Q.toBeProducedEntities[Q.nextIndex+J],Z=X[G.type],K=AW();K.depth=G.depth;let H=[],W=[];for(let D in Z){let U=Z[D];if(U.arity==="inverse")continue;let N=U.type,V=$[N].length;I(H,js(U.arity,U.strategy||"any",N===G.type?G.indexInType:void 0,V,K)),I(W,{name:D,relation:U,sentinelLinkIndex:V})}if(H.length===0)return;return Z0(...H).map((D)=>{let U=xs(Q,J);for(let N=0;N!==D.length;++N){let V=D[N],{name:z,relation:q,sentinelLinkIndex:F}=W[N],R=[],C=V===void 0?[]:typeof V==="number"?[V]:V;for(let w of C){let a;if(w>=F)a=U.enqueueNewEntity(X,q.type);else a=w;I(R,a);let O=BX(Y,q);if(O!==void 0)U.appendBackReference(q.type,a,O.property)}U.setOutboundLink(z,{type:q.type,index:V===void 0?void 0:typeof V==="number"?R[0]:R})}return U.commit()})}function ks(X,Y){Is(X);let Q=ws(X);return vE(y0(vs(X,Y)),(J)=>{if(J.nextIndex>=J.toBeProducedEntities.length)return;let $=0,G=void 0;while(G===void 0&&J.nextIndex+$<J.toBeProducedEntities.length)G=Ss(X,Q,J,$),$+=1;return G}).map((J)=>{return J.producedLinks})}var{keys:bs,getOwnPropertySymbols:gs,getOwnPropertyDescriptor:ys}=Object;function hs(X){let Y=bs(X),Q=gs(X);for(let J=0;J!==Q.length;++J){let $=Q[J],G=ys(X,$);if(G&&G.enumerable)Y.push($)}return Y}var{create:ms,defineProperty:fs,getOwnPropertyDescriptor:ps,getOwnPropertyNames:ds,getOwnPropertySymbols:us}=Object;function cs(X,Y){return function(J){let $=J[J.length-1]?ms(null):{};for(let G=0;G!==X.length;++G){let Z=J[G];if(Z!==Y){let K=X[G];if(K==="__proto__")fs($,K,{value:Z,configurable:!0,enumerable:!0,writable:!0});else $[K]=Z}}return $}}function ls(X,Y){return function(J){if(typeof J!=="object"||J===null)throw Error("Incompatible instance received: should be a non-null object");let $=Object.getPrototypeOf(J)===null,G="constructor"in J&&J.constructor===Object;if(!$&&!G)throw Error("Incompatible instance received: should be of exact type Object");let Z=0,K=[];for(let D=0;D!==X.length;++D){let U=ps(J,X[D]);if(U!==void 0){if(!U.configurable||!U.enumerable||!U.writable)throw Error("Incompatible instance received: should contain only c/e/w properties");if(U.get!==void 0||U.set!==void 0)throw Error("Incompatible instance received: should contain only no get/set properties");++Z,I(K,U.value)}else I(K,Y)}let H=ds(J).length,W=us(J).length;if(Z!==H+W)throw Error("Incompatible instance received: should not contain extra properties");return[...K,$]}}var SH=Symbol("no-key");function kH(X,Y,Q){let J=hs(X),$=[];for(let G=0;G!==J.length;++G){let Z=J[G],K=X[Z];if(Y===void 0||fQ(Y,Z)!==-1)I($,K);else I($,B8(K,{nil:SH}))}return Z0(...$,Q?y0(!1):iQ()).map(cs(J,SH),ls(J,SH))}function GW(X,Y){let Q=Y!==void 0&&!!Y.noNullPrototype;if(Y===void 0)return kH(X,void 0,Q);if(!(("requiredKeys"in Y)&&Y.requiredKeys!==void 0))return kH(X,void 0,Q);let J=("requiredKeys"in Y?Y.requiredKeys:void 0)||[];for(let $=0;$!==J.length;++$){let G=Object.getOwnPropertyDescriptor(X,J[$]);if(G===void 0)throw Error("requiredKeys cannot reference keys that have not been defined in recordModel");if(!G.enumerable)throw Error("requiredKeys cannot reference keys that are not enumerable in recordModel")}return kH(X,J,Q)}var os=Object.create;function is(X,Y,Q,J){let $=os(null);for(let G in X){let Z=X[G],K=GW(Z,J),H=Y(G),W=Q(G),D={minLength:H,maxLength:H};$[G]=W!==void 0?V5(K,{...D,selector:W}):M0(K,D)}return GW($)}var{create:wP,keys:rs}=Object;function ns(X,Y,Q={}){let J=rs(X),$=Q.initialPoolConstraints||wP(null),G=Q.unicityConstraints||wP(null),Z={noNullPrototype:Q.noNullPrototype};return As(J,$).chain((K)=>ks(Y,K).chain((H)=>is(X,(W)=>H[W].length,(W)=>G[W],Z).map((W)=>Cs(W,H))))}function ss(X){return h0(O0(X,(Y)=>Y[Y.length-1]===","?u0(Y,0,Y.length-1):Y)," ")}function as(X){return function(Q){if(typeof Q!=="string")throw Error("Unsupported type");let J=[];for(let $ of d1(Q," "))if(X.canShrinkWithoutContext($))I(J,$);else if(X.canShrinkWithoutContext($+","))I(J,$+",");else throw Error("Unsupported word");return J}}function ts(X){let Y=h0(X," ");if(Y[Y.length-1]===",")Y=u0(Y,0,Y.length-1);return NW(Y[0])+u0(Y,1)+"."}function es(X){return function(Q){if(typeof Q!=="string")throw Error("Unsupported type");if(Q.length<2||Q[Q.length-1]!=="."||Q[Q.length-2]===","||NW(lH(Q[0]))!==Q[0])throw Error("Unsupported value");let J=lH(Q[0])+u0(Q,1,Q.length-1),$=[],G=d1(J," ");for(let Z=0;Z!==G.length;++Z){let K=G[Z];if(X.canShrinkWithoutContext(K))I($,K);else if(Z===G.length-1&&X.canShrinkWithoutContext(K+","))I($,K+",");else throw Error("Unsupported word")}return $}}function Xa(X){return h0(X," ")}function Ya(X){if(typeof X!=="string")throw Error("Unsupported type");let Y=d1(X,". ");for(let Q=0;Q<Y.length-1;++Q)Y[Q]+=".";return Y}var L=(X,Y)=>{return{arbitrary:y0(X),weight:Y}};function Qa(){return K1(L("non",6),L("adipiscing",5),L("ligula",5),L("enim",5),L("pellentesque",5),L("in",5),L("augue",5),L("et",5),L("nulla",5),L("lorem",4),L("sit",4),L("sed",4),L("diam",4),L("fermentum",4),L("ut",4),L("eu",4),L("aliquam",4),L("mauris",4),L("vitae",4),L("felis",4),L("ipsum",3),L("dolor",3),L("amet,",3),L("elit",3),L("euismod",3),L("mi",3),L("orci",3),L("erat",3),L("praesent",3),L("egestas",3),L("leo",3),L("vel",3),L("sapien",3),L("integer",3),L("curabitur",3),L("convallis",3),L("purus",3),L("risus",2),L("suspendisse",2),L("lectus",2),L("nec,",2),L("ultricies",2),L("sed,",2),L("cras",2),L("elementum",2),L("ultrices",2),L("maecenas",2),L("massa,",2),L("varius",2),L("a,",2),L("semper",2),L("proin",2),L("nec",2),L("nisl",2),L("amet",2),L("duis",2),L("congue",2),L("libero",2),L("vestibulum",2),L("pede",2),L("blandit",2),L("sodales",2),L("ante",2),L("nibh",2),L("ac",2),L("aenean",2),L("massa",2),L("suscipit",2),L("sollicitudin",2),L("fusce",2),L("tempus",2),L("aliquam,",2),L("nunc",2),L("ullamcorper",2),L("rhoncus",2),L("metus",2),L("faucibus,",2),L("justo",2),L("magna",2),L("at",2),L("tincidunt",2),L("consectetur",1),L("tortor,",1),L("dignissim",1),L("congue,",1),L("non,",1),L("porttitor,",1),L("nonummy",1),L("molestie,",1),L("est",1),L("eleifend",1),L("mi,",1),L("arcu",1),L("scelerisque",1),L("vitae,",1),L("consequat",1),L("in,",1),L("pretium",1),L("volutpat",1),L("pharetra",1),L("tempor",1),L("bibendum",1),L("odio",1),L("dui",1),L("primis",1),L("faucibus",1),L("luctus",1),L("posuere",1),L("cubilia",1),L("curae,",1),L("hendrerit",1),L("velit",1),L("mauris,",1),L("gravida",1),L("ornare",1),L("ut,",1),L("pulvinar",1),L("varius,",1),L("turpis",1),L("nibh,",1),L("eros",1),L("id",1),L("aliquet",1),L("quis",1),L("lobortis",1),L("consectetuer",1),L("morbi",1),L("vehicula",1),L("tortor",1),L("tellus,",1),L("id,",1),L("eu,",1),L("quam",1),L("feugiat,",1),L("posuere,",1),L("iaculis",1),L("lectus,",1),L("tristique",1),L("mollis,",1),L("nisl,",1),L("vulputate",1),L("sem",1),L("vivamus",1),L("placerat",1),L("imperdiet",1),L("cursus",1),L("rutrum",1),L("iaculis,",1),L("augue,",1),L("lacus",1))}function Ja(X={}){let{maxCount:Y,mode:Q="words",size:J}=X;if(Y!==void 0&&Y<1)throw Error("lorem has to produce at least one word/sentence");let $=Qa();if(Q==="sentences")return M0(M0($,{minLength:1,size:"small"}).map(ts,es($)),{minLength:1,maxLength:Y,size:J}).map(Xa,Ya);else return M0($,{minLength:1,maxLength:Y,size:J}).map(ss,as($))}function $a(X){return new Map(X)}function _a(X){if(typeof X!=="object"||X===null)throw Error("Incompatible instance received: should be a non-null object");if(!("constructor"in X)||X.constructor!==Map)throw Error("Incompatible instance received: should be of exact type Map");return Array.from(X)}function Ga(X){return X[0]}function ZW(X,Y,Q={}){return V5(Z0(X,Y),{minLength:Q.minKeys,maxLength:Q.maxKeys,size:Q.size,selector:Ga,depthIdentifier:Q.depthIdentifier,comparator:"SameValueZero"}).map($a,_a)}var T$=10;function Za(X){let Y={};return(Q)=>{let J=Q!==void 0?Q:T$;if(!ZE(Y,J)){let $=T$;T$=J-1,Y[J]=X(J),T$=$}return Y[J]}}function Ka(X){let Y=0;while(X>b(0)){if(X&b(1))++Y;X>>=b(1)}return Y}function Ha(X,Y){let Q=(b(1)<<b(Y))-b(1),J=X&Q,$=Ka(X-J),G=J;for(let Z=b(1);Z<=Q&&$!==0;Z<<=b(1))if(!(G&Z))G|=Z,--$;return G}function F$(X,Y){let Q=[];for(let J=X.length-1;J!==-1;--J)if(Y(X[J])!==X[J])I(Q,J);return Q}function Wa(X,Y,Q){let J=b(0);for(let $=0,G=b(1);$!==Q.length;++$,G<<=b(1))if(X[Q[$]]!==Y[Q[$]])J|=G;return J}function bH(X,Y,Q,J){for(let $=0,G=b(1);$!==Q.length;++$,G<<=b(1))if(Y&G)X[Q[$]]=J(X[Q[$]])}var Ua=class extends m0{constructor(X,Y,Q){super();this.stringArb=X,this.toggleCase=Y,this.untoggleAll=Q}buildContextFor(X,Y){return{rawString:X.value,rawStringContext:X.context,flags:Y.value,flagsContext:Y.context}}generate(X,Y){let Q=this.stringArb.generate(X,Y),J=[...Q.value],$=F$(J,this.toggleCase),G=Z4(b(0),(b(1)<<b($.length))-b(1)).generate(X,void 0);return bH(J,G.value,$,this.toggleCase),new g(h0(J,""),this.buildContextFor(Q,G))}canShrinkWithoutContext(X){if(typeof X!=="string")return!1;return this.untoggleAll!==void 0?this.stringArb.canShrinkWithoutContext(this.untoggleAll(X)):this.stringArb.canShrinkWithoutContext(X)}shrink(X,Y){let Q;if(Y!==void 0)Q=Y;else if(this.untoggleAll!==void 0){let G=this.untoggleAll(X),Z=[...X],K=[...G];Q={rawString:G,rawStringContext:void 0,flags:Wa(K,Z,F$(K,this.toggleCase)),flagsContext:void 0}}else Q={rawString:X,rawStringContext:void 0,flags:b(0),flagsContext:void 0};let{rawString:J,flags:$}=Q;return this.stringArb.shrink(J,Q.rawStringContext).map((G)=>{let Z=[...G.value],K=F$(Z,this.toggleCase),H=Ha($,K.length);return bH(Z,H,K,this.toggleCase),new g(h0(Z,""),this.buildContextFor(G,new g(H,void 0)))}).join(_4(()=>{let G=[...J],Z=F$(G,this.toggleCase);return Z4(b(0),(b(1)<<b(Z.length))-b(1)).shrink($,Q.flagsContext).map((K)=>{let H=Z1(G);return bH(H,K.value,Z,this.toggleCase),new g(h0(H,""),this.buildContextFor(new g(J,Q.rawStringContext),K))})}))}};function Da(X){let Y=NW(X);if(Y!==X)return Y;return lH(X)}function Na(X,Y){return new Ua(X,Y&&Y.toggleCase||Da,Y&&Y.untoggleAll)}function Va(X){return XE.from(X)}function Ba(X){if(!(X instanceof XE))throw Error("Unexpected type");return[...X]}function ZC(X={}){return M0(tE(X),X).map(Va,Ba)}function za(X){return YE.from(X)}function qa(X){if(!(X instanceof YE))throw Error("Unexpected type");return[...X]}function KC(X={}){return M0(h$(X),X).map(za,qa)}function z8(X,Y,Q,J,$){let G=J.name,{min:Z=Y,max:K=Q,...H}=X;if(Z>K)throw Error(`Invalid range passed to ${G}: min must be lower than or equal to max`);if(Z<Y)throw Error(`Invalid min value passed to ${G}: min must be greater than or equal to ${Y}`);if(K>Q)throw Error(`Invalid max value passed to ${G}: max must be lower than or equal to ${Q}`);return M0($({min:Z,max:K}),H).map((W)=>J.from(W),(W)=>{if(!(W instanceof J))throw Error("Invalid type");return[...W]})}function HC(X={}){return z8(X,-32768,32767,ac,E0)}function WC(X={}){return z8(X,-2147483648,2147483647,tc,E0)}function UC(X={}){return z8(X,-128,127,sc,E0)}function DC(X={}){return z8(X,0,65535,Yl,E0)}function NC(X={}){return z8(X,0,4294967295,Ql,E0)}function VC(X={}){return z8(X,0,255,ec,E0)}function BC(X={}){return z8(X,0,255,Xl,E0)}function Oa(X){return X!==void 0}function MP(X){if(X.hasToBeCloned)return new g(X.value_,{generatorContext:X.context},()=>X.value);return new g(X.value_,{generatorContext:X.context})}function jP(X){if(X.hasToBeCloned)return new g(X.value_,{shrinkerContext:X.context},()=>X.value);return new g(X.value_,{shrinkerContext:X.context})}var La=class extends m0{constructor(X,Y){super();this.generatorArbitrary=X,this.shrinkerArbitrary=Y}generate(X,Y){return MP(this.generatorArbitrary.generate(X,Y))}canShrinkWithoutContext(X){return this.shrinkerArbitrary.canShrinkWithoutContext(X)}shrink(X,Y){if(!Oa(Y))return this.shrinkerArbitrary.shrink(X,void 0).map(jP);if("generatorContext"in Y)return this.generatorArbitrary.shrink(X,Y.generatorContext).map(MP);return this.shrinkerArbitrary.shrink(X,Y.shrinkerContext).map(jP)}};function KW(X,Y,Q){let J=E0({min:X,max:Y});if(Y===Q)return J;return new La(J,E0({min:X,max:Q}))}var{min:Ta,max:HW}=Math,IP=tP.isArray,Fa=Object.entries;function Ra(X){let Y=-1;for(let Q=0;Q!==X.length;++Q)Y=HW(Y,X[Q][0]);return Y}function Aa(X,Y){let Q=tP(X);for(let J=0;J!==Y.length;++J){let $=Y[J];if($[0]<X)Q[$[0]]=$[1]}return Q}function zC(X,Y={}){let{size:Q,minNumElements:J=0,maxLength:$=N5,maxNumElements:G=$,noTrailingHole:Z,depthIdentifier:K}=Y,H=cQ(Q,cQ(Q,J,G,Y.maxNumElements!==void 0),$,Y.maxLength!==void 0);if(J>$)throw Error("The minimal number of non-hole elements cannot be higher than the maximal length of the array");if(J>G)throw Error("The minimal number of non-hole elements cannot be higher than the maximal number of non-holes");let W=Ta(G,$),D=Y.maxNumElements!==void 0||Q!==void 0?Q:"=",U=V5(Z0(KW(0,HW(H-1,0),HW($-1,0)),X),{size:D,minLength:J,maxLength:W,selector:(N)=>N[0],depthIdentifier:K}).map((N)=>{return Aa(Ra(N)+1,N)},(N)=>{if(!IP(N))throw Error("Not supported entry type");if(Z&&N.length!==0&&!(N.length-1 in N))throw Error("No trailing hole");return O0(Fa(N),(V)=>[Number(V[0]),V[1]])});if(Z||$===J)return U;return Z0(U,KW(J,H,$)).map((N)=>{let V=N[0],z=N[1];if(V.length>=z)return V;let q=Z1(V);return q.length=z,q},(N)=>{if(!IP(N))throw Error("Not supported entry type");return[N,N.length]})}function Pa(X){return new Set(X)}function Ea(X){if(typeof X!=="object"||X===null)throw Error("Incompatible instance received: should be a non-null object");if(!("constructor"in X)||X.constructor!==Set)throw Error("Incompatible instance received: should be of exact type Set");return Array.from(X)}function qC(X,Y={}){return V5(X,{minLength:Y.minLength,maxLength:Y.maxLength,size:Y.size,depthIdentifier:Y.depthIdentifier,comparator:"SameValueZero"}).map(Pa,Ea)}function Ca(X,Y,Q,J,$,G){return CW(X,Y,{maxKeys:Q,noNullPrototype:!G,size:J,depthIdentifier:$})}function wa(X){return K1(UC(X),VC(X),BC(X),HC(X),DC(X),WC(X),NC(X),ZC(X),KC(X))}function OC(X){let{values:Y,depthSize:Q}=X,J=AW(),$=X.maxDepth,G=X.maxKeys,Z=X.size,K=K1(...Y,...X.withBigInt?[Z4()]:[],...X.withDate?[xE()]:[]);return $C((H)=>({anything:K1({maxDepth:$,depthSize:Q,depthIdentifier:J},K,H("array"),H("object"),...X.withMap?[H("map")]:[],...X.withSet?[H("set")]:[],...X.withObjectString?[H("anything").map((W)=>s0(W))]:[],...X.withTypedArray?[wa({maxLength:G,size:Z})]:[],...X.withSparseArray?[zC(H("anything"),{maxNumElements:G,size:Z,depthIdentifier:J})]:[]),keys:X.withObjectString?K1({arbitrary:X.key,weight:10},{arbitrary:H("anything").map((W)=>s0(W)),weight:1}):X.key,array:M0(H("anything"),{maxLength:G,size:Z,depthIdentifier:J}),set:qC(H("anything"),{maxLength:G,size:Z,depthIdentifier:J}),map:K1(ZW(H("keys"),H("anything"),{maxKeys:G,size:Z,depthIdentifier:J}),ZW(H("anything"),H("anything"),{maxKeys:G,size:Z,depthIdentifier:J})),object:Ca(H("keys"),H("anything"),G,Z,J,X.withNullPrototype)})).anything}function Ma(X){switch(typeof X){case"boolean":return new eP(X);case"number":return new D8(X);case"string":return new p1(X);default:return X}}function ja(X){if(typeof X!=="object"||X===null||!("constructor"in X))return X;return X.constructor===eP||X.constructor===D8||X.constructor===p1?X.valueOf():X}function Ia(X){return X.map(Ma,ja)}function xa(X,Y){return[iQ(),YC(),h$(),Y(X),K1(Y(X),y0(null),y0(void 0))]}function va(X){return X.map((Y)=>Ia(Y))}function Sa(X,Y){return Y?va(X).concat(X):X}function LC(X={}){let Y={size:X.size,unit:"stringUnit"in X?X.stringUnit:X.withUnicodeString?"binary":void 0};return{key:X.key!==void 0?X.key:e0(Y),values:Sa(X.values!==void 0?X.values:xa(Y,e0),X.withBoxedValues===!0),depthSize:X.depthSize,maxDepth:X.maxDepth,maxKeys:X.maxKeys,size:X.size,withSet:X.withSet===!0,withMap:X.withMap===!0,withObjectString:X.withObjectString===!0,withNullPrototype:X.withNullPrototype===!0,withBigInt:X.withBigInt===!0,withDate:X.withDate===!0,withTypedArray:X.withTypedArray===!0,withSparseArray:X.withSparseArray===!0}}function ka(X){return CW(X.key,OC(X),{maxKeys:X.maxKeys,noNullPrototype:!X.withNullPrototype,size:X.size})}function ba(X){return ka(LC(X))}function ga(X,Y){let{depthSize:Q,maxDepth:J}=Y;return{key:X,values:[iQ(),h$({noDefaultInfinity:!0,noNaN:!0}),X,y0(null)],depthSize:Q,maxDepth:J}}function TC(X){return OC(LC(X))}function FC(X={}){let Y=X.noUnicodeString===void 0||X.noUnicodeString===!0;return TC(ga("stringUnit"in X?e0({unit:X.stringUnit}):Y?e0():e0({unit:"binary"}),X))}var{stringify:ya,parse:ha}=JSON;function ma(X){if(typeof X!=="string")throw new y("Cannot unmap the passed value");return ha(X)}function fa(X={}){return FC(X).map(ya,ma)}var pa=Object.defineProperties;function gH(X,Y){return`Stream(${Y!==void 0?`${h0(Y,",")}…`:`${X} emitted`})`}var da=class extends m0{constructor(X,Y){super();this.arb=X,this.history=Y}generate(X,Y){let Q=Y!==void 0&&X.nextInt(1,Y)===1?Y:void 0,J=()=>{let $=this.history?[]:null,G=0,K=new K0(function*(H,W){while(!0){let D=H.generate(W,Q).value;if(G++,$!==null)I($,D);yield D}}(this.arb,X.clone()));return pa(K,{toString:{value:()=>gH(G,$!==null?$.map(s0):void 0)},[X6]:{value:()=>gH(G,$!==null?$.map(s0):void 0)},[V8]:{value:async()=>gH(G,$!==null?await Promise.all($.map(LW)):void 0)},[H1]:{value:J,enumerable:!0}})};return new g(J(),void 0)}canShrinkWithoutContext(X){return!1}shrink(X,Y){return K0.nil()}};function ua(X,Y){return new da(X,Y!==void 0&&typeof Y==="object"&&"noHistory"in Y?!Y.noHistory:!0)}function ca(X){return h0(X,"")}function xP(X){if(typeof X!=="string")throw Error("Cannot unmap the passed value");return[...X]}function la(X){switch(X.length%4){case 0:return X;case 3:return`${X}=`;case 2:return`${X}==`;default:return u0(X,1)}}function oa(X){if(typeof X!=="string"||X.length%4!==0)throw Error("Invalid string received");let Y=X.indexOf("=");if(Y===-1)return X;if(X.length-Y>2)throw Error("Cannot unmap the passed value");return u0(X,0,Y)}var yH=String.fromCharCode;function ia(X){if(X<26)return yH(X+65);if(X<52)return yH(X+97-26);if(X<62)return yH(X+48-52);return X===62?"+":"/"}function ra(X){if(typeof X!=="string"||X.length!==1)throw new y("Invalid entry");let Y=j9(X,0);if(Y>=65&&Y<=90)return Y-65;if(Y>=97&&Y<=122)return Y-97+26;if(Y>=48&&Y<=57)return Y-48+52;return Y===43?62:Y===47?63:-1}function na(){return E0({min:0,max:63}).map(ia,ra)}function sa(X={}){let{minLength:Y=0,maxLength:Q=N5,size:J}=X,$=Y+3-(Y+3)%4,G=Q-Q%4,Z=X.maxLength===void 0&&J===void 0?"=":J;if($>G)throw new y("Minimal length should be inferior or equal to maximal length");if($%4!==0)throw new y("Minimal length of base64 strings must be a multiple of 4");if(G%4!==0)throw new y("Maximal length of base64 strings must be a multiple of 4");let K=na();return M0(K,{minLength:$,maxLength:G,size:Z,experimentalCustomSlices:wr(K,xP)}).map(ca,xP).map(la,oa)}var vP=Object.is;function aa(X,Y){let Q=new N8,J=0;for(let $ of X)if(vP($,-0))++J;else aX(Q,$,(BX(Q,$)||0)+1);for(let $=0;$!==Y.length;++$){if(!($ in Y))return!1;let G=Y[$];if(vP(G,-0)){if(J===0)return!1;--J}else{let Z=BX(Q,G)||0;if(Z===0)return!1;aX(Q,G,Z-1)}}return!0}var{floor:ta,log:SP}=Math,ea=Array.isArray,RC=class extends m0{constructor(X,Y,Q,J){super();if(this.originalArray=X,this.isOrdered=Y,this.minLength=Q,this.maxLength=J,Q<0||Q>X.length)throw Error("fc.*{s|S}ubarrayOf expects the minimal length to be between 0 and the size of the original array");if(J<0||J>X.length)throw Error("fc.*{s|S}ubarrayOf expects the maximal length to be between 0 and the size of the original array");if(Q>J)throw Error("fc.*{s|S}ubarrayOf expects the minimal length to be inferior or equal to the maximal length");this.lengthArb=new x9(Q,J),this.biasedLengthArb=Q!==J?new x9(Q,Q+ta(SP(J-Q)/SP(2))):this.lengthArb}generate(X,Y){let Q=(Y!==void 0&&X.nextInt(1,Y)===1?this.biasedLengthArb:this.lengthArb).generate(X,void 0),J=Q.value,$=O0(this.originalArray,(Z,K)=>K),G=[];for(let Z=0;Z!==J;++Z){let K=X.nextInt(0,$.length-1);I(G,$[K]),$E($,K,1)}if(this.isOrdered)_E(G,(Z,K)=>Z-K);return new g(O0(G,(Z)=>this.originalArray[Z]),Q.context)}canShrinkWithoutContext(X){if(!ea(X))return!1;if(!this.lengthArb.canShrinkWithoutContext(X.length))return!1;return aa(this.originalArray,X)}shrink(X,Y){if(X.length===0)return K0.nil();return this.lengthArb.shrink(X.length,Y).map((Q)=>{return new g(Z1(X,X.length-Q.value),Q.context)}).join(X.length>this.minLength?_4(()=>this.shrink(Z1(X,1),void 0).filter((Q)=>this.minLength<=Q.value.length+1).map((Q)=>new g([X[0],...Q.value],void 0))):K0.nil())}};function Xt(X,Y={}){let{minLength:Q=0,maxLength:J=X.length}=Y;return new RC(X,!0,Q,J)}function Yt(X,Y={}){let{minLength:Q=0,maxLength:J=X.length}=Y;return new RC(X,!1,Q,J)}var Qt={10:"A",11:"B",12:"C",13:"D",14:"E",15:"F",16:"G",17:"H",18:"J",19:"K",20:"M",21:"N",22:"P",23:"Q",24:"R",25:"S",26:"T",27:"V",28:"W",29:"X",30:"Y",31:"Z"},Jt={"0":0,"1":1,"2":2,"3":3,"4":4,"5":5,"6":6,"7":7,"8":8,"9":9,A:10,B:11,C:12,D:13,E:14,F:15,G:16,H:17,J:18,K:19,M:20,N:21,P:22,Q:23,R:24,S:25,T:26,V:27,W:28,X:29,Y:30,Z:31};function $t(X){return X<10?p1(X):Qt[X]}function kP(X,Y){let Q="";while(X.length+Q.length<Y)Q+="0";return Q+X}function bP(X){let Y="";for(let Q=X;Q!==0;){let J=Q>>5;Y=$t(Q-(J<<5))+Y,Q=J}return Y}function _t(X,Y){let Q=~~(X/1073741824),J=X&1073741823;return kP(bP(Q),Y-6)+kP(bP(J),6)}function AC(X){return function(Q){return _t(Q,X)}}function hH(X){if(typeof X!=="string")throw new y("Unsupported type");let Y=0,Q=1;for(let J=X.length-1;J>=0;--J){let $=X[J],G=Jt[$];if(G===void 0)throw new y("Unsupported type");Y+=G*Q,Q*=32}return Y}var Gt=AC(10),gP=AC(8);function Zt(X){return Gt(X[0])+gP(X[1])+gP(X[2])}function Kt(X){if(typeof X!=="string"||X.length!==26)throw Error("Unsupported type");return[hH(X.slice(0,10)),hH(X.slice(10,18)),hH(X.slice(18))]}function Ht(){return Z0(E0({min:0,max:281474976710655}),E0({min:0,max:1099511627775}),E0({min:0,max:1099511627775})).map(Zt,Kt)}function PC(X){return ul(dQ(X,16),8,"0")}function Wt(X){if(typeof X!=="string")throw Error("Unsupported type");if(X.length!==8)throw Error("Unsupported value: invalid length");let Y=parseInt(X,16);if(X!==PC(Y))throw Error("Unsupported value: invalid content");return Y}function mH(X,Y){return E0({min:X,max:Y}).map(PC,Wt)}function Ut(X){return`${X[0]}-${u0(X[1],4)}-${u0(X[1],0,4)}-${u0(X[2],0,4)}-${u0(X[2],4)}${X[3]}`}var Dt=/^([0-9a-f]{8})-([0-9a-f]{4})-([0-9a-f]{4})-([0-9a-f]{4})-([0-9a-f]{12})$/;function Nt(X){if(typeof X!=="string")throw Error("Unsupported type");let Y=Dt.exec(X);if(Y===null)throw Error("Unsupported type");return[Y[1],Y[3]+Y[2],Y[4]+u0(Y[5],0,4),u0(Y[5],4)]}var yP="0123456789abcdef";function Vt(X){let Y={},Q={};for(let G=0;G!==X.length;++G){let Z=yP[G],K=yP[X[G]];Y[Z]=K,Q[K]=Z}function J(G){return Y[G[0]]+u0(G,1)}function $(G){if(typeof G!=="string")throw new y("Cannot produce non-string values");let Z=Q[G[0]];if(Z===void 0)throw new y("Cannot produce strings not starting by the version in hexa code");return Z+u0(G,1)}return{versionsApplierMapper:J,versionsApplierUnmapper:$}}function Bt(X){let Y={};for(let Q of X){if(Y[Q])throw new y(`Version ${Q} has been requested at least twice for uuid`);if(Y[Q]=!0,Q<1||Q>15)throw new y(`Version must be a value in [1-15] for uuid, but received ${Q}`);if(~~Q!==Q)throw new y(`Version must be an integer value for uuid, but received ${Q}`)}if(X.length===0)throw new y("Must provide at least one version for uuid")}function zt(X={}){let Y=mH(0,4294967295),Q=X.version!==void 0?typeof X.version==="number"?[X.version]:X.version:[1,2,3,4,5,6,7,8];Bt(Q);let{versionsApplierMapper:J,versionsApplierUnmapper:$}=Vt(Q);return Z0(Y,mH(0,268435456*Q.length-1).map(J,$),mH(2147483648,3221225471),Y).map(Ut,Nt)}function qt(X){return e0({unit:jW("-._~!$&'()*+,;=:"),size:X})}function Ot([X,Y,Q]){return(X===null?"":`${X}@`)+Y+(Q===null?"":`:${Q}`)}function Lt(X){if(typeof X!=="string")throw Error("Unsupported");let Y=X.indexOf("@"),Q=Y!==-1?X.substring(0,Y):null,J=/:(\d+)$/.exec(X),$=J!==null?Number(J[1]):null;return[Q,J!==null?X.substring(Y+1,X.length-J[1].length-1):X.substring(Y+1),$]}function Tt(X){return`[${X}]`}function Ft(X){if(typeof X!=="string"||X[0]!=="["||X[X.length-1]!=="]")throw Error("Unsupported");return X.substring(1,X.length-1)}function EC(X){let Y=X||{},Q=Y.size,J=[IW({size:Q}),...Y.withIPv4===!0?[kW()]:[],...Y.withIPv6===!0?[JC().map(Tt,Ft)]:[],...Y.withIPv4Extended===!0?[QC()]:[]];return Z0(Y.withUserInfo===!0?B8(qt(Q)):y0(null),K1(...J),Y.withPort===!0?B8($4(65535)):y0(null)).map(Ot,Lt)}function CC(X){return e0({unit:jW("-._~!$&'()*+,;=:@/?"),size:X})}function wC(X={}){return CC(X.size)}function MC(X={}){return e0({unit:jW("-._~!$&'()*+,;=:@"),size:X.size})}function Rt(X){let Y="";for(let Q=0;Q!==X.length;++Q)Y+="/"+X[Q];return Y}function At(X){if(typeof X!=="string")throw Error("Incompatible value received: type");if(X.length!==0&&X[0]!=="/")throw Error("Incompatible value received: start");return $E(d1(X,"/"),1)}function Pt(X){switch(X){case"xsmall":return["xsmall","xsmall"];case"small":return["small","xsmall"];case"medium":return["small","small"];case"large":return["medium","small"];case"xlarge":return["medium","medium"]}}function fH(X,Y){return M0(MC({size:X}),{size:Y}).map(Rt,At)}function Et(X){let[Y,Q]=Pt(X);if(Y===Q)return fH(Y,Q);return K1(fH(Y,Q),fH(Q,Y))}function jC(X){return Et(EW((X||{}).size))}function IC(X={}){return CC(X.size)}function Ct(X){let[Y,Q,J]=X;return`${Y}://${Q}${J}${X[3]===null?"":`?${X[3]}`}${X[4]===null?"":`#${X[4]}`}`}var wt=/^([[A-Za-z][A-Za-z0-9+.-]*):\/\/([^/?#]*)([^?#]*)(\?[A-Za-z0-9\-._~!$&'()*+,;=:@/?%]*)?(#[A-Za-z0-9\-._~!$&'()*+,;=:@/?%]*)?$/;function Mt(X){if(typeof X!=="string")throw Error("Incompatible value received: type");let Y=wt.exec(X);if(Y===null)throw Error("Incompatible value received");let Q=Y[1],J=Y[2],$=Y[3],G=Y[4],Z=Y[5];return[Q,J,$,G!==void 0?G.substring(1):null,Z!==void 0?Z.substring(1):null]}function jt(X){let Y=X||{},Q=EW(Y.size),J=Y.authoritySettings!==void 0&&Y.authoritySettings.size!==void 0?oQ(Y.authoritySettings.size,Q):Q,$={...Y.authoritySettings,size:J};return Z0(M6(...Y.validSchemes||["http","https"]),EC($),jC({size:Q}),Y.withQueryParameters===!0?B8(IC({size:Q})):y0(null),Y.withFragments===!0?B8(wC({size:Q})):y0(null)).map(Ct,Mt)}var It=class X{constructor(Y,Q){this.commands=Y,this.metadataForReplay=Q,this[H1]=function(){return new X(this.commands.map((J)=>J.clone()),this.metadataForReplay)}}[Symbol.iterator](){return this.commands[Symbol.iterator]()}toString(){let Y=this.commands.filter((J)=>J.hasRan).map((J)=>J.toString()).join(","),Q=this.metadataForReplay();return Q.length!==0?`${Y} /*${Q}*/`:Y}},xt=class X{constructor(Y){if(this.cmd=Y,this.hasRan=!1,qW(Y)){let Q=Y[X6];this[X6]=function(){return Q.call(Y)}}if(OW(Y)){let Q=Y[V8];this[V8]=function(){return Q.call(Y)}}}check(Y){return this.cmd.check(Y)}run(Y,Q){return this.hasRan=!0,this.cmd.run(Y,Q)}clone(){if(D5(this.cmd))return new X(this.cmd[H1]());return new X(this.cmd)}toString(){return this.cmd.toString()}},hP=class{static parse(X){let[Y,Q]=X.split(":"),J=this.parseCounts(Y),$=this.parseChanges(Q);return this.parseOccurences(J,$)}static stringify(X){let Y=this.countOccurences(X);return`${this.stringifyCounts(Y)}:${this.stringifyChanges(Y)}`}static intToB64(X){if(X<26)return String.fromCharCode(X+65);if(X<52)return String.fromCharCode(X+97-26);if(X<62)return String.fromCharCode(X+48-52);return String.fromCharCode(X===62?43:47)}static b64ToInt(X){if(X>="a")return X.charCodeAt(0)-97+26;if(X>="A")return X.charCodeAt(0)-65;if(X>="0")return X.charCodeAt(0)-48+52;return X==="+"?62:63}static countOccurences(X){return X.reduce((Y,Q)=>{if(Y.length===0||Y[Y.length-1].count===64||Y[Y.length-1].value!==Q)Y.push({value:Q,count:1});else Y[Y.length-1].count+=1;return Y},[])}static parseOccurences(X,Y){let Q=[];for(let J=0;J!==X.length;++J){let $=X[J],G=Y[J];for(let Z=0;Z!==$;++Z)Q.push(G)}return Q}static stringifyChanges(X){let Y="";for(let Q=0;Q<X.length;Q+=6){let J=X.slice(Q,Q+6).reduceRight(($,G)=>($<<1)+(G.value?1:0),0);Y+=this.intToB64(J)}return Y}static parseChanges(X){let Y=X.split("").map((J)=>this.b64ToInt(J)),Q=[];for(let J=0;J!==Y.length;++J){let $=Y[J];for(let G=0;G!==6;++G,$>>=1)Q.push($%2===1)}return Q}static stringifyCounts(X){return X.map(({count:Y})=>this.intToB64(Y-1)).join("")}static parseCounts(X){return X.split("").map((Y)=>this.b64ToInt(Y)+1)}},vt=class extends m0{constructor(X,Y,Q,J,$){super();this.sourceReplayPath=J,this.disableReplayLog=$,this.oneCommandArb=K1(...X).map((G)=>new xt(G)),this.lengthArb=KW(0,Y,Q),this.replayPath=[],this.replayPathPosition=0}metadataForReplay(){return this.disableReplayLog?"":`replayPath=${JSON.stringify(hP.stringify(this.replayPath))}`}buildValueFor(X,Y){let Q=X.map(($)=>$.value_),J={shrunkOnce:Y,items:X};return new g(new It(Q,()=>this.metadataForReplay()),J)}generate(X){let Y=this.lengthArb.generate(X,void 0).value,Q=Array(Y);for(let J=0;J!==Y;++J)Q[J]=this.oneCommandArb.generate(X,void 0);return this.replayPathPosition=0,this.buildValueFor(Q,!1)}canShrinkWithoutContext(X){return!1}filterOnExecution(X){let Y=[];for(let Q of X)if(Q.value_.hasRan)this.replayPath.push(!0),Y.push(Q);else this.replayPath.push(!1);return Y}filterOnReplay(X){return X.filter((Y,Q)=>{let J=this.replayPath[this.replayPathPosition+Q];if(J===void 0)throw Error("Too short replayPath");if(!J&&Y.value_.hasRan)throw Error("Mismatch between replayPath and real execution");return J})}filterForShrinkImpl(X){if(this.replayPathPosition===0)this.replayPath=this.sourceReplayPath!==null?hP.parse(this.sourceReplayPath):[];let Y=this.replayPathPosition<this.replayPath.length?this.filterOnReplay(X):this.filterOnExecution(X);return this.replayPathPosition+=X.length,Y}shrink(X,Y){if(Y===void 0)return K0.nil();let Q=Y,J=Q.shrunkOnce,$=Q.items,G=this.filterForShrinkImpl($);if(G.length===0)return K0.nil();let Z=J?K0.nil():new K0([[]][Symbol.iterator]()),K=[];for(let H=0;H!==G.length;++H)K.push(_4(()=>{let W=G.slice(0,H);return this.lengthArb.shrink(G.length-1-H,void 0).map((D)=>W.concat(G.slice(G.length-(D.value+1))))}));for(let H=0;H!==G.length;++H)K.push(_4(()=>this.oneCommandArb.shrink(G[H].value_,G[H].context).map((W)=>G.slice(0,H).concat([W],G.slice(H+1)))));return Z.join(...K).map((H)=>{return this.buildValueFor(H.map((W)=>new g(W.value_.clone(),W.context)),!0)})}};function St(X,Y={}){let{size:Q,maxCommands:J=N5,disableReplayLog:$=!1,replayPath:G=null}=Y;return new vt(X,cQ(Q,0,J,Y.maxCommands!==void 0),J,G,$)}var kt=class{constructor(X,Y){this.s=X,this.cmd=Y}async check(X){let Y=null,Q=!1;if((await this.s.scheduleSequence([{label:`check@${this.cmd.toString()}`,builder:async()=>{try{Q=await Promise.resolve(this.cmd.check(X))}catch(J){throw Y=J,J}}}]).task).faulty)throw Y;return Q}async run(X,Y){let Q=null;if((await this.s.scheduleSequence([{label:`run@${this.cmd.toString()}`,builder:async()=>{try{await this.cmd.run(X,Y)}catch(J){throw Q=J,J}}}]).task).faulty)throw Q}},bt=function*(X,Y){for(let Q of Y)yield new kt(X,Q)},xC=(X,Y,Q,J,$)=>{return X.then((G)=>{let{model:Z,real:K}=G,H=Q;for(let W of Y)H=$(H,()=>{return J(W,Z,K)});return H})},gt=(X,Y)=>{return xC({then:(G)=>{G(X())}},Y,void 0,(G,Z,K)=>{if(G.check(Z))G.run(Z,K)},(G,Z)=>Z())},yt=(X)=>{return typeof X.then==="function"},vC=async(X,Y,Q=Promise.resolve())=>{return await xC({then:(Z)=>{let K=X();if(yt(K))return K.then(Z);else return Z(K)}},Y,Q,async(Z,K,H)=>{if(await Z.check(K))await Z.run(K,H)},(Z,K)=>Z.then(K))};function ht(X,Y){gt(X,Y)}async function mt(X,Y){await vC(X,Y)}async function ft(X,Y,Q){let J=bt(X,Q),$=vC(Y,J,X.schedule(Promise.resolve(),"startModel"));await X.waitFor($),await X.waitAll()}var R$=(X)=>X(),SC=class X{constructor(Y,Q){this.act=Y,this.taskSelector=Q,this.lastTaskId=0,this.sourceTaskSelector=Q.clone(),this.scheduledTasks=[],this.triggeredTasks=[],this.scheduledWatchers=[],this[H1]=function(){return new X(this.act,this.sourceTaskSelector)}}static buildLog(Y){return`[task\${${Y.taskId}}] ${Y.label.length!==0?`${Y.schedulingType}::${Y.label}`:Y.schedulingType} ${Y.status}${Y.outputValue!==void 0?` with value ${fn(Y.outputValue)}`:""}`}log(Y,Q,J,$,G,Z){this.triggeredTasks.push({status:G,schedulingType:Y,taskId:Q,label:J,metadata:$,outputValue:Z!==void 0?s0(Z):void 0})}scheduleInternal(Y,Q,J,$,G,Z){let K=++this.lastTaskId,H=void 0,W=new Promise((D,U)=>{H=()=>{let N=Promise.resolve(Z!==void 0?J.then(()=>Z()):J);return N.then((V)=>{this.log(Y,K,Q,$,"resolved",V),D(V)},(V)=>{this.log(Y,K,Q,$,"rejected",V),U(V)}),N}});if(this.scheduledTasks.push({original:J,trigger:H,schedulingType:Y,taskId:K,label:Q,metadata:$,customAct:G}),this.scheduledWatchers.length!==0)this.scheduledWatchers[0]();return W}schedule(Y,Q,J,$){return this.scheduleInternal("promise",Q||"",Y,J,$||R$)}scheduleFunction(Y,Q){return(...J)=>this.scheduleInternal("function",`${Y.name}(${J.map(s0).join(",")})`,Y(...J),void 0,Q||R$)}scheduleSequence(Y,Q){let J={done:!1,faulty:!1},$={then:(D)=>D()},G=()=>{},Z=new Promise((D)=>{G=()=>D({done:J.done,faulty:J.faulty})}),K=()=>{J.faulty=!0,G()},H=()=>{J.done=!0,G()},W=(D,U)=>{if(D>=Y.length){U.then(H,K);return}U.then(()=>{let N=Y[D],[V,z,q]=typeof N==="function"?[N,N.name,void 0]:[N.builder,N.label,N.metadata],F=this.scheduleInternal("sequence",z,$,q,Q||R$,()=>V());W(D+1,F)},K)};return W(0,$),Object.assign(J,{task:Z})}count(){return this.scheduledTasks.length}internalWaitOne(){if(this.scheduledTasks.length===0)throw Error("No task scheduled");let Y=this.taskSelector.nextTaskIndex(this.scheduledTasks),[Q]=this.scheduledTasks.splice(Y,1);return Q.customAct(()=>{return Q.trigger().catch((J)=>{})})}waitOne(Y){let Q=Y||R$;return this.act(()=>Q(()=>this.internalWaitOne()))}async waitAll(Y){while(this.scheduledTasks.length>0)await this.waitOne(Y)}async internalWaitFor(Y,Q){let J=!1,$=Q.customAct,G=Q.onWaitStart,Z=Q.onWaitIdle,K=Q.launchAwaiterOnInit,H=void 0,W=void 0,D=0,U=null,N=null,V=async()=>{D=50;for(D=50;!J&&D>0;--D)await Promise.resolve();if(!J&&this.scheduledTasks.length>0){if(G!==void 0)G();return N=this.waitOne($),N.then(()=>{return N=null,V()},(R)=>{throw N=null,J=!0,W(R),R})}if(!J&&Z!==void 0)Z();U=null},z=()=>{if(U!==null){D=51;return}U=V().catch(()=>{})},q=()=>{let R=this.scheduledWatchers.indexOf(z);if(R!==-1)this.scheduledWatchers.splice(R,1);if(R===0&&this.scheduledWatchers.length!==0)this.scheduledWatchers[0]()},F=new Promise((R,C)=>{H=(w)=>{q(),R(w)},W=(w)=>{q(),C(w)}});if(Y.then((R)=>{if(J=!0,N===null)H(R);else N.then(()=>H(R),(C)=>W(C))},(R)=>{if(J=!0,N===null)W(R);else N.then(()=>W(R),()=>W(R))}),(this.scheduledTasks.length>0||K)&&this.scheduledWatchers.length===0)z();return this.scheduledWatchers.push(z),F}waitNext(Y,Q){let J=void 0,$=Y,G=$<=0?Promise.resolve():new Promise((Z)=>{J=()=>{if(--$<=0)Z()}});return this.internalWaitFor(G,{customAct:Q,onWaitStart:J,onWaitIdle:void 0,launchAwaiterOnInit:!1})}waitIdle(Y){let Q=void 0,J=new Promise(($)=>Q=$);return this.internalWaitFor(J,{customAct:Y,onWaitStart:void 0,onWaitIdle:Q,launchAwaiterOnInit:!0})}waitFor(Y,Q){return this.internalWaitFor(Y,{customAct:Q,onWaitStart:void 0,onWaitIdle:void 0,launchAwaiterOnInit:!1})}report(){return[...this.triggeredTasks,...this.scheduledTasks.map((Y)=>({status:"pending",schedulingType:Y.schedulingType,taskId:Y.taskId,label:Y.label,metadata:Y.metadata}))]}toString(){return"schedulerFor()`\n"+this.report().map(X.buildLog).map((Y)=>`-> ${Y}`).join(`
`)+"`"}};function kC(X){let Y=0;return{clone:()=>kC(X),nextTaskIndex:(Q)=>{if(X.length<=Y)throw Error("Invalid schedulerFor defined: too many tasks have been scheduled");let J=Q.findIndex(($)=>$.taskId===X[Y]);if(J===-1)throw Error("Invalid schedulerFor defined: unable to find next task");return++Y,J}}}function mP(X,Y){return new SC(X,kC(Y))}function bC(X){let Y=X.clone();return{clone:()=>bC(Y),nextTaskIndex:(Q)=>{return X.nextInt(0,Q.length-1)}}}var pt=class extends m0{constructor(X){super();this.act=X}generate(X,Y){return new g(new SC(this.act,bC(X.clone())),void 0)}canShrinkWithoutContext(X){return!1}shrink(X,Y){return K0.nil()}};function dt(X){let{act:Y=(Q)=>Q()}=X||{};return new pt(Y)}function ut(X,Y){let{act:Q=(J)=>J()}=Array.isArray(X)?Y||{}:X||{};if(Array.isArray(X))return mP(Q,X);return function(J,...$){return mP(Q,$)}}function ct(X={}){return z8(X,b("-9223372036854775808"),b("9223372036854775807"),rc,Z4)}function lt(X={}){return z8(X,b(0),b("18446744073709551615"),nc,Z4)}function ot(X,Y){return Y}var{floor:pH,min:it}=Math;function IX(X,Y){switch(X.type){case"Char":return{astNode:X,minLength:1};case"Repetition":switch(X.quantifier.kind){case"*":{let Q=IX(X.expression,Y);return{astNode:{type:"Repetition",quantifier:{...X.quantifier,kind:"Range",from:0,to:Y},expression:Q.astNode},minLength:0}}case"+":{let Q=IX(X.expression,Y),J=Q.minLength>1?Q.minLength:1;return{astNode:{type:"Repetition",quantifier:{...X.quantifier,kind:"Range",from:1,to:pH(Y/J)},expression:Q.astNode},minLength:Q.minLength}}case"?":{let Q=IX(X.expression,Y);if(Y<Q.minLength)return{astNode:{type:"Repetition",quantifier:{...X.quantifier,kind:"Range",from:0,to:0},expression:Q.astNode},minLength:0};return{astNode:{...X,expression:Q.astNode},minLength:0}}case"Range":{let Q=X.quantifier.from>1?pH(Y/X.quantifier.from):Y,J=IX(X.expression,Q),$=J.minLength>1?J.minLength:1;if(X.quantifier.to===void 0||X.quantifier.to*$>Y)return{astNode:{type:"Repetition",quantifier:{...X.quantifier,kind:"Range",to:pH(Y/$)},expression:J.astNode},minLength:X.quantifier.from*J.minLength};return{astNode:{...X,expression:J.astNode},minLength:X.quantifier.from*J.minLength}}default:return ot(X.quantifier,{astNode:X,minLength:0})}case"Quantifier":return{astNode:X,minLength:0};case"Alternative":{let Q=0,J=[];for(let G=0;G!==X.expressions.length;++G){let Z=Y-Q,K=IX(X.expressions[G],Z);Q+=K.minLength,I(J,{value:K,allowance:Z})}let $=[];for(let G=0;G!==J.length;++G){let Z=J[G].value,K=J[G].allowance,H=Y-Q+Z.minLength;I($,(H!==K?IX(Z.astNode,H):Z).astNode)}return{astNode:{...X,expressions:$},minLength:Q}}case"CharacterClass":return{astNode:X,minLength:1};case"ClassRange":return{astNode:X,minLength:1};case"Group":{let Q=IX(X.expression,Y);return{astNode:{...X,expression:Q.astNode},minLength:Q.minLength}}case"Disjunction":{if(X.left===null){if(X.right===null)return{astNode:X,minLength:0};let $=IX(X.right,Y),G=$.minLength>Y?null:$.astNode;return{astNode:{...X,left:null,right:G},minLength:0}}if(X.right===null){let $=IX(X.left,Y),G=$.minLength>Y?null:$.astNode;return{astNode:{...X,left:G,right:null},minLength:0}}let Q=IX(X.left,Y),J=IX(X.right,Y);if(Q.minLength>Y)return J;if(J.minLength>Y)return Q;return{astNode:{...X,left:Q.astNode,right:J.astNode},minLength:it(Q.minLength,J.minLength)}}case"Assertion":return{astNode:X,minLength:0};case"Backreference":return{astNode:X,minLength:0};case"UnicodeProperty":return{astNode:X,minLength:1}}}function rt(X,Y){return IX(X,Y).astNode}function nt(X){return Error(`Unsupported AST node! Received: ${s0(X)}`)}function j$(X,Y,Q){if(!Y&&!Q)return X;let J={hasStart:!1,hasEnd:!1},$=gC(X,Y,Q,J),G=Y&&!J.hasStart,Z=Q&&!J.hasEnd;if(!G&&!Z)return $;let K=[];if(G)K.push({type:"Assertion",kind:"^"}),K.push({type:"Repetition",quantifier:{type:"Quantifier",kind:"*",greedy:!0},expression:{type:"Char",kind:"meta",symbol:".",value:".",codePoint:NaN}});if(K.push($),Z)K.push({type:"Repetition",quantifier:{type:"Quantifier",kind:"*",greedy:!0},expression:{type:"Char",kind:"meta",symbol:".",value:".",codePoint:NaN}}),K.push({type:"Assertion",kind:"$"});return{type:"Group",capturing:!1,expression:{type:"Alternative",expressions:K}}}function gC(X,Y,Q,J){switch(X.type){case"Char":return X;case"Repetition":return X;case"Quantifier":throw Error("Wrongly defined AST tree, Quantifier nodes not supposed to be scanned!");case"Alternative":return J.hasStart=!0,J.hasEnd=!0,{...X,expressions:X.expressions.map(($,G)=>j$($,Y&&G===0,Q&&G===X.expressions.length-1))};case"CharacterClass":return X;case"ClassRange":return X;case"Group":return{...X,expression:gC(X.expression,Y,Q,J)};case"Disjunction":return J.hasStart=!0,J.hasEnd=!0,{...X,left:X.left!==null?j$(X.left,Y,Q):null,right:X.right!==null?j$(X.right,Y,Q):null};case"Assertion":if(X.kind==="^"||X.kind==="Lookahead")return J.hasStart=!0,X;else if(X.kind==="$"||X.kind==="Lookbehind")return J.hasEnd=!0,X;else throw Error(`Assertions of kind ${X.kind} not implemented yet!`);case"Backreference":return X;case"UnicodeProperty":return X;default:throw nt(X)}}function st(X){return j$(X,!0,!0)}function fP(X,Y){return X[Y]>="\uD800"&&X[Y]<="\uDBFF"&&X[Y+1]>="\uDC00"&&X[Y+1]<="\uDFFF"?2:1}function t0(X){return X>="0"&&X<="9"||X>="a"&&X<="f"||X>="A"&&X<="F"}function WW(X){return X>="0"&&X<="9"}function yC(X,Y){for(let Q=Y;Q!==X.length;++Q){let J=X[Q];if(J==="\\")Q+=1;else if(J==="]")return Q}throw Error("Missing closing ']'")}function at(X,Y){let Q=0;for(let J=Y;J!==X.length;++J){let $=X[J];if($==="\\")J+=1;else if($===")"){if(Q===0)return J;Q-=1}else if($==="[")J=yC(X,J);else if($==="(")Q+=1}throw Error("Missing closing ')'")}function tt(X,Y){let Q=!1;for(let J=Y;J!==X.length;++J){let $=X[J];if(WW($));else if(Y===J)return-1;else if($===","){if(Q)return-1;Q=!0}else if($==="}")return J;else return-1}return-1}function et(X,Y,Q,J){switch(X[Y]){case"[":if(J===1)return Y+1;return yC(X,Y+1)+1;case"{":{if(J===1)return Y+1;let $=tt(X,Y+1);if($===-1)return Y+1;return $+1}case"(":if(J===1)return Y+1;return at(X,Y+1)+1;case"]":case"}":case")":return Y+1;case"\\":{let $=X[Y+1];switch($){case"x":if(t0(X[Y+2])&&t0(X[Y+3]))return Y+4;throw Error(`Unexpected token '${X.substring(Y,Y+4)}' found`);case"u":if(X[Y+2]==="{"){if(!Q)return Y+2;if(X[Y+4]==="}"){if(t0(X[Y+3]))return Y+5;throw Error(`Unexpected token '${X.substring(Y,Y+5)}' found`)}if(X[Y+5]==="}"){if(t0(X[Y+3])&&t0(X[Y+4]))return Y+6;throw Error(`Unexpected token '${X.substring(Y,Y+6)}' found`)}if(X[Y+6]==="}"){if(t0(X[Y+3])&&t0(X[Y+4])&&t0(X[Y+5]))return Y+7;throw Error(`Unexpected token '${X.substring(Y,Y+7)}' found`)}if(X[Y+7]==="}"){if(t0(X[Y+3])&&t0(X[Y+4])&&t0(X[Y+5])&&t0(X[Y+6]))return Y+8;throw Error(`Unexpected token '${X.substring(Y,Y+8)}' found`)}if(X[Y+8]==="}"&&t0(X[Y+3])&&t0(X[Y+4])&&t0(X[Y+5])&&t0(X[Y+6])&&t0(X[Y+7]))return Y+9;throw Error(`Unexpected token '${X.substring(Y,Y+9)}' found`)}if(t0(X[Y+2])&&t0(X[Y+3])&&t0(X[Y+4])&&t0(X[Y+5]))return Y+6;throw Error(`Unexpected token '${X.substring(Y,Y+6)}' found`);case"p":case"P":{if(!Q)return Y+2;let G=Y+2;for(;G<X.length&&X[G]!=="}";G+=X[G]==="\\"?2:1);if(X[G]!=="}")throw Error("Invalid \\P definition");return G+1}case"k":{let G=Y+2;for(;G<X.length&&X[G]!==">";++G);if(X[G]!==">"){if(!Q)return Y+2;throw Error("Invalid \\k definition")}return G+1}default:if(WW($)){let G=Q?X.length:Math.min(Y+4,X.length),Z=Y+2;for(;Z<G&&WW(X[Z]);++Z);return Z}return Y+(Q?fP(X,Y+1):1)+1}}default:return Y+(Q?fP(X,Y):1)}}function A$(X,Y,Q,J){let $=et(X,Y,Q,J);return X.substring(Y,$)}var pP={gc:"General_Category",sc:"Script",scx:"Script_Extensions"},m$={ASCII:"ASCII",ASCII_Hex_Digit:"AHex",Alphabetic:"Alpha",Any:"Any",Assigned:"Assigned",Bidi_Control:"Bidi_C",Bidi_Mirrored:"Bidi_M",Case_Ignorable:"CI",Cased:"Cased",Changes_When_Casefolded:"CWCF",Changes_When_Casemapped:"CWCM",Changes_When_Lowercased:"CWL",Changes_When_NFKC_Casefolded:"CWKCF",Changes_When_Titlecased:"CWT",Changes_When_Uppercased:"CWU",Dash:"Dash",Default_Ignorable_Code_Point:"DI",Deprecated:"Dep",Diacritic:"Dia",Emoji:"Emoji",Emoji_Component:"Emoji_Component",Emoji_Modifier:"Emoji_Modifier",Emoji_Modifier_Base:"Emoji_Modifier_Base",Emoji_Presentation:"Emoji_Presentation",Extended_Pictographic:"Extended_Pictographic",Extender:"Ext",Grapheme_Base:"Gr_Base",Grapheme_Extend:"Gr_Ext",Hex_Digit:"Hex",IDS_Binary_Operator:"IDSB",IDS_Trinary_Operator:"IDST",ID_Continue:"IDC",ID_Start:"IDS",Ideographic:"Ideo",Join_Control:"Join_C",Logical_Order_Exception:"LOE",Lowercase:"Lower",Math:"Math",Noncharacter_Code_Point:"NChar",Pattern_Syntax:"Pat_Syn",Pattern_White_Space:"Pat_WS",Quotation_Mark:"QMark",Radical:"Radical",Regional_Indicator:"RI",Sentence_Terminal:"STerm",Soft_Dotted:"SD",Terminal_Punctuation:"Term",Unified_Ideograph:"UIdeo",Uppercase:"Upper",Variation_Selector:"VS",White_Space:"space",XID_Continue:"XIDC",XID_Start:"XIDS"},lQ=hW(m$),yW={Cased_Letter:"LC",Close_Punctuation:"Pe",Connector_Punctuation:"Pc",Control:["Cc","cntrl"],Currency_Symbol:"Sc",Dash_Punctuation:"Pd",Decimal_Number:["Nd","digit"],Enclosing_Mark:"Me",Final_Punctuation:"Pf",Format:"Cf",Initial_Punctuation:"Pi",Letter:"L",Letter_Number:"Nl",Line_Separator:"Zl",Lowercase_Letter:"Ll",Mark:["M","Combining_Mark"],Math_Symbol:"Sm",Modifier_Letter:"Lm",Modifier_Symbol:"Sk",Nonspacing_Mark:"Mn",Number:"N",Open_Punctuation:"Ps",Other:"C",Other_Letter:"Lo",Other_Number:"No",Other_Punctuation:"Po",Other_Symbol:"So",Paragraph_Separator:"Zp",Private_Use:"Co",Punctuation:["P","punct"],Separator:"Z",Space_Separator:"Zs",Spacing_Mark:"Mc",Surrogate:"Cs",Symbol:"S",Titlecase_Letter:"Lt",Unassigned:"Cn",Uppercase_Letter:"Lu"},UW=hW(yW),hC={Adlam:"Adlm",Ahom:"Ahom",Anatolian_Hieroglyphs:"Hluw",Arabic:"Arab",Armenian:"Armn",Avestan:"Avst",Balinese:"Bali",Bamum:"Bamu",Bassa_Vah:"Bass",Batak:"Batk",Bengali:"Beng",Bhaiksuki:"Bhks",Bopomofo:"Bopo",Brahmi:"Brah",Braille:"Brai",Buginese:"Bugi",Buhid:"Buhd",Canadian_Aboriginal:"Cans",Carian:"Cari",Caucasian_Albanian:"Aghb",Chakma:"Cakm",Cham:"Cham",Cherokee:"Cher",Common:"Zyyy",Coptic:["Copt","Qaac"],Cuneiform:"Xsux",Cypriot:"Cprt",Cyrillic:"Cyrl",Deseret:"Dsrt",Devanagari:"Deva",Dogra:"Dogr",Duployan:"Dupl",Egyptian_Hieroglyphs:"Egyp",Elbasan:"Elba",Ethiopic:"Ethi",Georgian:"Geor",Glagolitic:"Glag",Gothic:"Goth",Grantha:"Gran",Greek:"Grek",Gujarati:"Gujr",Gunjala_Gondi:"Gong",Gurmukhi:"Guru",Han:"Hani",Hangul:"Hang",Hanifi_Rohingya:"Rohg",Hanunoo:"Hano",Hatran:"Hatr",Hebrew:"Hebr",Hiragana:"Hira",Imperial_Aramaic:"Armi",Inherited:["Zinh","Qaai"],Inscriptional_Pahlavi:"Phli",Inscriptional_Parthian:"Prti",Javanese:"Java",Kaithi:"Kthi",Kannada:"Knda",Katakana:"Kana",Kayah_Li:"Kali",Kharoshthi:"Khar",Khmer:"Khmr",Khojki:"Khoj",Khudawadi:"Sind",Lao:"Laoo",Latin:"Latn",Lepcha:"Lepc",Limbu:"Limb",Linear_A:"Lina",Linear_B:"Linb",Lisu:"Lisu",Lycian:"Lyci",Lydian:"Lydi",Mahajani:"Mahj",Makasar:"Maka",Malayalam:"Mlym",Mandaic:"Mand",Manichaean:"Mani",Marchen:"Marc",Medefaidrin:"Medf",Masaram_Gondi:"Gonm",Meetei_Mayek:"Mtei",Mende_Kikakui:"Mend",Meroitic_Cursive:"Merc",Meroitic_Hieroglyphs:"Mero",Miao:"Plrd",Modi:"Modi",Mongolian:"Mong",Mro:"Mroo",Multani:"Mult",Myanmar:"Mymr",Nabataean:"Nbat",New_Tai_Lue:"Talu",Newa:"Newa",Nko:"Nkoo",Nushu:"Nshu",Ogham:"Ogam",Ol_Chiki:"Olck",Old_Hungarian:"Hung",Old_Italic:"Ital",Old_North_Arabian:"Narb",Old_Permic:"Perm",Old_Persian:"Xpeo",Old_Sogdian:"Sogo",Old_South_Arabian:"Sarb",Old_Turkic:"Orkh",Oriya:"Orya",Osage:"Osge",Osmanya:"Osma",Pahawh_Hmong:"Hmng",Palmyrene:"Palm",Pau_Cin_Hau:"Pauc",Phags_Pa:"Phag",Phoenician:"Phnx",Psalter_Pahlavi:"Phlp",Rejang:"Rjng",Runic:"Runr",Samaritan:"Samr",Saurashtra:"Saur",Sharada:"Shrd",Shavian:"Shaw",Siddham:"Sidd",SignWriting:"Sgnw",Sinhala:"Sinh",Sogdian:"Sogd",Sora_Sompeng:"Sora",Soyombo:"Soyo",Sundanese:"Sund",Syloti_Nagri:"Sylo",Syriac:"Syrc",Tagalog:"Tglg",Tagbanwa:"Tagb",Tai_Le:"Tale",Tai_Tham:"Lana",Tai_Viet:"Tavt",Takri:"Takr",Tamil:"Taml",Tangut:"Tang",Telugu:"Telu",Thaana:"Thaa",Thai:"Thai",Tibetan:"Tibt",Tifinagh:"Tfng",Tirhuta:"Tirh",Ugaritic:"Ugar",Vai:"Vaii",Warang_Citi:"Wara",Yi:"Yiii",Zanabazar_Square:"Zanb"},dP=hW(hC);function hW(X){let Y={};for(let Q of Object.keys(X)){let J=X[Q];if(Array.isArray(J))for(let $=0;$!==J.length;++$)Y[J[$]]=Q;else Y[J]=Q}return Y}function Xe(X){return X in yW||X in UW}function Ye(X){return X in m$||X in lQ}function uP(X){if(X in pP)return pP[X];if(X in lQ)return lQ[X];if(X in m$||X==="General_Category"||X==="Script"||X==="Script_Extensions")return X;throw Error(`Unknown Unicode property name: ${X}`)}function cP(X){if(X in UW)return UW[X];if(X in dP)return dP[X];if(X in lQ)return lQ[X];if(X in yW||X in hC||X in m$)return X;throw Error(`Unknown Unicode property value: ${X}`)}function Qe(X,Y){let Q=X.indexOf("=");if(Q!==-1){let J=X.substring(0,Q),$=X.substring(Q+1);return{type:"UnicodeProperty",name:J,value:$,negative:Y,shorthand:!1,binary:!1,canonicalName:uP(J),canonicalValue:cP($)}}if(Xe(X))return{type:"UnicodeProperty",name:"General_Category",value:X,negative:Y,shorthand:!0,binary:!1,canonicalName:"General_Category",canonicalValue:cP(X)};if(Ye(X)){let J=uP(X);return{type:"UnicodeProperty",name:X,value:X,negative:Y,shorthand:!1,binary:!0,canonicalName:J,canonicalValue:J}}throw Error(`Invalid Unicode property: ${X}`)}var dH=String.fromCodePoint;function uH(X){let Y=X.pop();if(Y===void 0)throw Error("Unable to extract token preceeding the currently parsed one");return Y}function mC(X){return X>="0"&&X<="9"}function I$(X,Y){return{type:"Char",kind:"simple",symbol:X,value:X,codePoint:X.codePointAt(0)||-1,escaped:Y}}function C9(X,Y){return{type:"Char",kind:"meta",symbol:Y,value:X,codePoint:Y.codePointAt(0)||-1}}function Q4(X,Y){if(X.length>1)return{type:"Alternative",expressions:X};if(!Y&&X.length===0)throw Error("Unsupported no token");return X[0]}function cH(X){if(X[0]==="\\"){let Y=X[1];switch(Y){case"x":{let Q=X.substring(2),J=Number.parseInt(Q,16);return{type:"Char",kind:"hex",symbol:dH(J),value:X,codePoint:J}}case"u":{if(X==="\\u")return I$("u",!0);let Q=X[2]==="{"?X.substring(3,X.length-1):X.substring(2),J=Number.parseInt(Q,16);return{type:"Char",kind:"unicode",symbol:dH(J),value:X,codePoint:J}}case"0":return C9(X,"\x00");case"n":return C9(X,`
`);case"f":return C9(X,"\f");case"r":return C9(X,"\r");case"t":return C9(X,"\t");case"v":return C9(X,"\v");case"w":case"W":case"d":case"D":case"s":case"S":case"b":case"B":return{type:"Char",kind:"meta",symbol:void 0,value:X,codePoint:NaN};default:if(mC(Y)){let Q=X.substring(1),J=Number(Q);return{type:"Char",kind:"decimal",symbol:dH(J),value:X,codePoint:J}}if(X.length>2&&(Y==="p"||Y==="P")){let Q=Y==="P";return Qe(X.substring(3,X.length-1),Q)}return I$(X.substring(1),!0)}}return I$(X)}function w9(X,Y,Q,J){let $=null;for(let G=0,Z=A$(Y,G,Q,0);G!==Y.length;G+=Z.length,Z=A$(Y,G,Q,0)){let K=Z[0];switch(K){case"|":if($===null)$=[];$.push(Q4(X.splice(0),!0)||null);break;case".":X.push({type:"Char",kind:"meta",symbol:Z,value:Z,codePoint:NaN});break;case"*":case"+":{let H=uH(X);X.push({type:"Repetition",expression:H,quantifier:{type:"Quantifier",kind:K,greedy:!0}});break}case"?":{let H=uH(X);if(H.type==="Repetition")H.quantifier.greedy=!1,X.push(H);else X.push({type:"Repetition",expression:H,quantifier:{type:"Quantifier",kind:K,greedy:!0}});break}case"{":{if(Z==="{"){X.push(I$(Z));break}let H=uH(X),W=Z.substring(1,Z.length-1).split(","),D=Number(W[0]),U=W.length===1?D:W[1].length!==0?Number(W[1]):void 0;X.push({type:"Repetition",expression:H,quantifier:{type:"Quantifier",kind:"Range",greedy:!0,from:D,to:U}});break}case"[":{let H=Z.substring(1,Z.length-1),W=[],D=void 0,U=!1;for(let N=0,V=A$(H,N,Q,1);N!==H.length;N+=V.length,V=A$(H,N,Q,1)){if(N===0&&V==="^"){D=!0;continue}let z=cH(V);if(V==="-")W.push(z),U=!0;else{let q=W.length>=2?W[W.length-2]:void 0;if(U&&q!==void 0&&q.type==="Char"&&z.type==="Char")W.pop(),W.pop(),W.push({type:"ClassRange",from:q,to:z});else W.push(z);U=!1}}X.push({type:"CharacterClass",expressions:W,negative:D});break}case"(":{let H=Z.substring(1,Z.length-1),W=[];if(H[0]==="?")if(H[1]===":")w9(W,H.substring(2),Q,J),X.push({type:"Group",capturing:!1,expression:Q4(W)});else if(H[1]==="="||H[1]==="!")w9(W,H.substring(2),Q,J),X.push({type:"Assertion",kind:"Lookahead",negative:H[1]==="!"?!0:void 0,assertion:Q4(W)});else if(H[1]==="<"&&(H[2]==="="||H[2]==="!"))w9(W,H.substring(3),Q,J),X.push({type:"Assertion",kind:"Lookbehind",negative:H[2]==="!"?!0:void 0,assertion:Q4(W)});else{let D=H.split(">");if(D.length<2||D[0][1]!=="<")throw Error(`Unsupported regex content found at ${JSON.stringify(Z)}`);let U=++J.lastIndex,N=D[0].substring(2);J.named.set(N,U),w9(W,D.slice(1).join(">"),Q,J),X.push({type:"Group",capturing:!0,nameRaw:N,name:N,number:U,expression:Q4(W)})}else{let D=++J.lastIndex;w9(W,H,Q,J),X.push({type:"Group",capturing:!0,number:D,expression:Q4(W)})}break}default:if(Z==="^")X.push({type:"Assertion",kind:Z});else if(Z==="$")X.push({type:"Assertion",kind:Z});else if(Z[0]==="\\"&&mC(Z[1])){let H=Number(Z.substring(1));if(Q||H<=J.lastIndex)X.push({type:"Backreference",kind:"number",number:H,reference:H});else X.push(cH(Z))}else if(Z[0]==="\\"&&Z[1]==="k"&&Z.length!==2){let H=Z.substring(3,Z.length-1);X.push({type:"Backreference",kind:"name",number:J.named.get(H)||0,referenceRaw:H,reference:H})}else X.push(cH(Z));break}}if($!==null){$.push(Q4(X.splice(0),!0)||null);let G={type:"Disjunction",left:$[0],right:$[1]};for(let Z=2;Z<$.length;++Z)G={type:"Disjunction",left:G,right:$[Z]};X.push(G)}}function Je(X){let Y=fQ([...X.flags],"u")!==-1,Q=X.source,J=[];return w9(J,Q,Y,{lastIndex:0,named:new Map}),Q4(J)}var $e=String.fromCodePoint;function _e(X){if(X.binary||X.shorthand)return X.canonicalValue;return`${X.canonicalName}=${X.canonicalValue}`}function lP(X,Y,Q,J){let $=-1;for(let G=Y;G<=Q;++G)if(X.test($e(G))){if($===-1)$=G}else if($!==-1){let Z=G-1;J.push($===Z?[Z]:[$,Z]),$=-1}if($!==-1)J.push($===Q?[Q]:[$,Q])}function Ge(X,Y){let Q=new RegExp(`^\\${Y?"P":"p"}{${X}}$`,"u"),J=[];return lP(Q,0,55295,J),lP(Q,57344,1114111,J),J}var oP=new Map;function Ze(X,Y){let Q=`${Y?"P":"p"}:${X}`,J=oP.get(Q);if(J!==void 0)return J;let $=Ge(X,Y);return oP.set(Q,$),$}function Ke(X){return v9(...O0(Ze(_e(X),X.negative),(Y)=>aH(Y)))}var He=String.fromCodePoint,fC=[..."abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"],pC=[..."0123456789"],dC=[...` 	\r
\v\f`],DW=[...`\r
`],uC=[..."\x1E\x15"],We=[...DW,...uC],Ue=new tX(fC),De=new tX(pC),Ne=new tX(dC),Ve=new tX(uC),Be=new tX(We),W5=()=>e0({unit:"grapheme-ascii",minLength:1,maxLength:1});function iP(X){return new y(`Unsupported AST node! Received: ${s0(X)}`)}function U5(X,Y,Q){switch(X.type){case"Char":if(X.kind==="meta")switch(X.value){case"\\w":return M6(...fC);case"\\W":return W5().filter((J)=>!J4(Ue,J));case"\\d":return M6(...pC);case"\\D":return W5().filter((J)=>!J4(De,J));case"\\s":return M6(...dC);case"\\S":return W5().filter((J)=>!J4(Ne,J));case"\\b":case"\\B":throw new y(`Meta character ${X.value} not implemented yet!`);case".":{let J=Q.dotAll?Ve:Be;return W5().filter(($)=>!J4(J,$))}}if(X.symbol===void 0)throw new y(`Unexpected undefined symbol received for non-meta Char! Received: ${s0(X)}`);return y0(X.symbol);case"Repetition":{let J=U5(X.expression,Y,Q);switch(X.quantifier.kind){case"*":return e0({...Y,unit:J});case"+":return e0({...Y,minLength:1,unit:J});case"?":return e0({...Y,minLength:0,maxLength:1,unit:J});case"Range":return e0({...Y,minLength:X.quantifier.from,maxLength:X.quantifier.to,unit:J});default:throw iP(X.quantifier)}}case"Quantifier":throw new y("Wrongly defined AST tree, Quantifier nodes not supposed to be scanned!");case"Alternative":{let J=[],$="";for(let G of X.expressions)if(G.type==="Char"&&G.kind!=="meta"&&G.symbol!==void 0)$+=G.symbol;else if(Q.multiline||G.type!=="Assertion"||G.kind!=="^"&&G.kind!=="$"){if($!=="")I(J,y0($)),$="";I(J,U5(G,Y,Q))}if($!=="")I(J,y0($));if(J.length===0)return y0("");if(J.length===1)return J[0];return Z0(...J).map((G)=>h0(G,""))}case"CharacterClass":if(X.negative){let J=O0(X.expressions,($)=>U5($,Y,Q));return W5().filter(($)=>GE(J,(G)=>!G.canShrinkWithoutContext($)))}return K1(...O0(X.expressions,(J)=>U5(J,Y,Q)));case"ClassRange":{let J=X.from.codePoint,$=X.to.codePoint;return E0({min:J,max:$}).map((G)=>He(G),(G)=>{if(typeof G!=="string")throw new y("Invalid type");if([...G].length!==1)throw new y("Invalid length");return j9(G,0)})}case"Group":return U5(X.expression,Y,Q);case"Disjunction":{let J=[X.left,X.right],$=[];for(let G=0;G!==J.length;++G){let Z=J[G];if(Z===null)I($,y0(""));else if(Z.type==="Disjunction")I(J,Z.left),I(J,Z.right);else I($,U5(Z,Y,Q))}return K1(...$)}case"Assertion":if(X.kind==="^"||X.kind==="$"){if(Q.multiline)if(X.kind==="^")return K1(y0(""),Z0(e0({unit:W5()}),M6(...DW)).map((J)=>`${J[0]}${J[1]}`,(J)=>{if(typeof J!=="string"||J.length===0)throw new y("Invalid type");return[u0(J,0,J.length-1),J[J.length-1]]}));else return K1(y0(""),Z0(M6(...DW),e0({unit:W5()})).map((J)=>`${J[0]}${J[1]}`,(J)=>{if(typeof J!=="string"||J.length===0)throw new y("Invalid type");return[J[0],u0(J,1)]}));return y0("")}throw new y(`Assertions of kind ${X.kind} not implemented yet!`);case"Backreference":throw new y("Backreference nodes not implemented yet!");case"UnicodeProperty":return Ke(X);default:throw iP(X)}}function ze(X,Y={}){for(let K of X.flags)if(K!=="d"&&K!=="g"&&K!=="m"&&K!=="s"&&K!=="u")throw new y(`Unable to use "stringMatching" against a regex using the flag ${K}`);let Q=Y.maxLength,J={size:Y.size,maxLength:Q},$={multiline:X.multiline,dotAll:X.dotAll},G=st(Je(X));if(Q!==void 0)G=rt(G,Q);let Z=U5(G,J,$);if(Q!==void 0)return Z.filter((K)=>[...K].length<=Q);return Z}function qe(X){let Y=[];for(let Q=0;Q!==X.length;++Q)Y.push(X[Q].next());return Y}function Oe(X,Y){for(let Q=0;Q!==X.length;++Q)Y[Q]=X[Q].next()}function Le(X){for(let Y=0;Y!==X.length;++Y)if(X[Y].done)return!0;return!1}function*Te(...X){let Y=qe(X);while(!Le(Y))yield Y.map((Q)=>Q.value),Oe(X,Y)}function*Fe(X){let Y=X;while(!0)yield Y,++Y}var Re=class extends m0{constructor(X,Y){super();this.arb=X,this.maxShrinks=Y}generate(X,Y){let Q=this.arb.generate(X,Y);return this.valueMapper(Q,0)}canShrinkWithoutContext(X){return this.arb.canShrinkWithoutContext(X)}shrink(X,Y){if(this.isSafeContext(Y))return this.safeShrink(X,Y.originalContext,Y.length);return this.safeShrink(X,void 0,0)}safeShrink(X,Y,Q){let J=this.maxShrinks-Q;if(J<=0)return K0.nil();return new K0(Te(this.arb.shrink(X,Y),Fe(Q+1))).take(J).map(($)=>this.valueMapper($[0],$[1]))}valueMapper(X,Y){let Q={originalContext:X.context,length:Y};return new g(X.value,Q)}isSafeContext(X){return X!==null&&X!==void 0&&typeof X==="object"&&"originalContext"in X&&"length"in X}};function Ae(X,Y){return new Re(X,Y)}var Pe="module",Ee="4.9.0",Ce="0d3c2547dce556f72413607849377530d18ea283";var rQ=Y$;function qX(){return(X,Y,Q)=>{return S(new G5(X.map(LQ),(J)=>Y(J.map(($)=>S($))),Q))}}function vX(X,Y){return qX()([],()=>(Q,J)=>X(Q)?d(Q):f(new r0(J,T(Q))),Y)}function we(X){return X}function Me(X){return(Y)=>Y.annotate(X)}function je(X){return(Y)=>mW(mW(Y).annotate(X))}function Ie(X){return(Y)=>{return Y.rebuild(EQ(Y.ast,X))}}function xe(X){return X}function cC(X){return M1(X)?X.value:{issues:[{message:Zq(X.cause)}]}}function ve(X,Y){let Q=a0(X),J={errors:"all",...Y?.parseOptions},$=pL(Y),G=(Z)=>{let K=new m5,H=P2(R2(Q(Z,J),{onFailure:$,onSuccess:(D)=>({value:D})}),{scheduler:K});H.currentDispatcher?.flush();let W=H.pollUnsafe();if(W)return cC(W);return new Promise((D)=>{H.addObserver((U)=>{D(cC(U))})})};if("~standard"in X){let Z=X;if("validate"in Z["~standard"])return Z;return Object.assign(Z["~standard"],{validate:G}),Z}else return Object.assign(X,{"~standard":{version:1,vendor:"effect",validate:G}})}function lC(X,Y){let Q=tM(X);if(Y==="draft-2020-12"){let J=Q.schema;if(Object.keys(Q.definitions).length>0)J.$defs=Q.definitions;return J}else if(Y==="draft-07"){let J=jR(Q),$=J.schema;if(Object.keys(J.definitions).length>0)$.definitions=J.definitions;return $}throw new globalThis.Error(`Unsupported target: ${Y}`)}function Se(X){let Y={input(Q){return lC(X,Q.target)},output(Q){return lC(u1(X),Q.target)}};if("~standard"in X){let Q=X;if("jsonSchema"in Q["~standard"])return Q;return Object.assign(Q["~standard"],{jsonSchema:Y}),Q}else return Object.assign(X,{"~standard":{version:1,vendor:"effect",jsonSchema:Y}})}var Jw=vF,ke=kF;function c$(X,Y){let Q=a0(X,Y);return(J,$)=>{return Q$(Q(J,$))}}var be=c$;function $w(X,Y){let Q;for(let J of X.reasons){if(!u3(J)||!eK(J.error))throw new globalThis.Error(Y,{cause:X});Q??=J.error}if(Q===void 0)throw new globalThis.Error(Y,{cause:X});return Q}function _w(X){return YJ(X).then((Y)=>{if(M1(Y))return Y.value;throw $w(Y.cause,"Promise adapter can only reject schema errors")})}function Gw(X){let Y=p8(X);if(M1(Y))return Y.value;throw $w(Y.cause,"Sync adapter can only throw schema errors")}function Zw(X,Y){let Q=bF(X,Y);return(J,$)=>{return Kw(Q(J,$))}}function Kw(X){return M1(X)?n5(X.value):h8(J8(X.cause,(Y)=>new X4(Y)))}var ge=Zw,ye=YH,he=gF;function Hw(X,Y){let Q=yF(X,Y);return(J,$)=>{return x4(Q(J,$),(G)=>new X4(G))}}var me=Hw;function Ww(X,Y){let Q=c$(X,Y);return(J,$)=>{return _w(Q(J,$))}}var fe=Ww;function Uw(X,Y){let Q=c$(X,Y);return(J,$)=>{return Gw(Q(J,$))}}var pe=Uw;function l$(X,Y){let Q=T9(X,Y);return(J,$)=>{return Q$(Q(J,$))}}var Dw=l$;function Nw(X,Y){let Q=hF(X,Y);return(J,$)=>{return Kw(Q(J,$))}}var de=Nw,ue=JH,ce=mF;function Vw(X,Y){let Q=fF(X,Y);return(J,$)=>{return x4(Q(J,$),(G)=>new X4(G))}}var le=Vw;function Bw(X,Y){let Q=l$(X,Y);return(J,$)=>{return _w(Q(J,$))}}var oe=Bw;function zw(X,Y){let Q=l$(X,Y);return(J,$)=>{return Gw(Q(J,$))}}var ie=zw,S=IQ;function o$(X){return j(X,rQ)&&X[rQ]===rQ}var H4=j1((X)=>S(CQ(X.ast),{schema:X})),re=j1((X)=>X.schema),xX=j1((X)=>H4(n$(X))),ne=j1((X)=>X.schema.members[0]),se=j1((X)=>S(lK(X.ast),{schema:X})),ae=j1((X)=>X.schema),u1=j1((X)=>S(T1(X.ast),{schema:X})),h9=j1((X)=>S(F1(X.ast),{schema:X})),nQ="~effect/Schema/flip";function te(X){return j(X,nQ)&&X[nQ]===nQ}function mW(X){if(te(X))return X.schema.rebuild(cX(X.ast));return S(cX(X.ast),{[nQ]:nQ,schema:X})}function c0(X){let Y=S(new DX(X),{literal:X,transform(Q){return Y.pipe(l(c0(Q),{decode:Q0(()=>Q),encode:Q0(()=>X)}))}});return Y}function qw(X){return new gK(X.map((Y)=>o$(Y)?Y.ast:new DX(Y)))}function ee(X){return S(qw(X),{parts:X})}function X00(X){return S(qw(X).asTemplateLiteralParser(),{parts:X})}function Y00(X){return S(new bK(Object.keys(X).filter((Y)=>typeof X[X[Y]]!=="number").map((Y)=>[Y,X[Y]])),{enums:X})}var Q00=S(rT),J00=S(sT),dW=S(Q5),T0=S(kK),uW=S(cT),r=S(n8),i$=S(hK),Ow=S($F),Lw=S(GF),j6=S(KF),$00=S(oT),_00=S(eT);function G00(X){return S(new yK(X))}function cW(X,Y){return S(X,{fields:Y,mapFields(Q,J){let $=Q(this.fields);return cW(fJ($,J?.unsafePreserveChecks?this.ast.checks:void 0),$)}})}function h(X){return cW(fJ(X,void 0),X)}function Z00(X){return j1((Y)=>Y.mapFields(rF(X)))}var K00=(X)=>typeof X==="symbol"?X:globalThis.String(X);function H00(X){return function(Y){let Q={},J=Object.create(null),$=Object.create(null),G=new Set;for(let Z of Reflect.ownKeys(Y.fields)){let K=h9(Y.fields[Z]),H=Object.hasOwn(X,Z),W=H?X[Z]:Z,D=K00(W);if(G.has(D))throw new globalThis.Error(`Duplicate encoded keys: ${m6(W)}`);if(G.add(D),k(Q,W,K),H)J[Z]=W,$[W]=Z}return h(Q).pipe(l(Y,p0({decode:GH($),encode:GH(J)})))}}function W00(X,Y){return(Q)=>{let J=_3(Q.fields,u1),$=h({...J,...X});return Q.pipe(l($,p0({decode:(G)=>{let Z={...G};for(let K in X){let H=Y[K],W=H(G);if(N1(W))k(Z,K,W.value)}return Z},encode:(G)=>{let Z={...G};for(let K in X)delete Z[K];return Z}})))}}function Tw(X,Y,Q){let J=Q?.keyValueCombiner?.decode||Q?.keyValueCombiner?.encode?new hJ(Q.keyValueCombiner.decode,Q.keyValueCombiner.encode):void 0;return S(OF(X.ast,Y.ast,J),{key:X,value:Y})}function U00(X,Y){return S(HF(X.ast,Y.map(LQ)),{schema:X,records:Y})}function Fw(X,Y){return S(X,{elements:Y,mapElements(Q,J){let $=Q(this.elements);return Fw(pK($,J?.unsafePreserveChecks?this.ast.checks:void 0),$)}})}function k9(X){return Fw(pK(X),X)}function D00(X,Y){return S(WF(X.ast,Y.map(LQ)),{schema:X,rest:Y})}var Q1=j1((X)=>S(new oX(!1,[],[X.ast]),{value:X}));var N00=j1((X)=>S(new oX(!1,[X.ast],[X.ast]),{value:X}));function V00(X){return J1([X,Q1(X)]).pipe(l(Q1(u1(X)),p0({decode:dN,encode:(Y)=>Y.length===1?Y[0]:Y})))}function B00(X){return Q1(X).check(YU())}var z00=j1((X)=>{return S(new oX(!0,X.ast.elements,X.ast.rest),{schema:X})});function Rw(X,Y){return S(X,{members:Y,mapMembers(Q,J){let $=Q(this.members);return Rw(pJ($,this.ast.mode,J?.unsafePreserveChecks?this.ast.checks:void 0),$)}})}function J1(X,Y){return Rw(pJ(X,Y?.mode??"anyOf",void 0),X)}function r$(X){let Y=X.map(c0);return S(pJ(Y,"anyOf",void 0),{literals:X,members:Y,mapMembers(Q){return J1(Q(this.members))},pick(Q){return r$(Q)},transform(Q){return J1(Y.map((J,$)=>J.transform(Q[$])))}})}var lW=j1((X)=>J1([X,T0])),n$=j1((X)=>J1([X,uW])),Aw=j1((X)=>J1([X,T0,uW]));function Pw(X){return S(new dJ(()=>X().ast))}function q00(...X){return(Y)=>Y.check(...X)}function O00(X,Y){return(Q)=>S(iX(Q.ast,[cJ(X,Y)]),{schema:Q})}function Ew(X){return(Y)=>S(zF(Y.ast,X),{schema:Y,identifier:X})}function L00(X,Y){return(Q)=>{return(Y.checks?Q.check(...Y.checks):Q).pipe(Ew(X))}}function oW(X){return(Y)=>S(VF(Y.ast,new BQ(X,u)),{schema:Y})}function Cw(X){return(Y)=>S(BF(Y.ast,new BQ(u,X)),{schema:Y})}function T00(X){return ww(X)}function ww(X){return(Y)=>oW(QJ(X))(Y)}function F00(X){return Mw(X)}function Mw(X){return(Y)=>Cw(QJ(X))(Y)}function l(X,Y){return(Q)=>{return S(iJ(Q.ast,X.ast,Y?IJ(Y):D9()),{from:Q,to:X})}}function R00(X){return(Y)=>{return l(u1(Y),X)(Y)}}function iW(X,Y){return(Q)=>{return Y?l(Q,Y)(X):l(Q)(X)}}function A00(X){return(Y)=>{return l(Y,X)(h9(Y))}}function jw(X){return(Y)=>S(qF(Y.ast,rW(X)),{schema:Y})}function rW(X){return i4(X,(Y)=>o4(()=>J8(Y,(Q)=>Q.issue)))}function nW(X,Y){let Q=Y?.encodingStrategy==="omit"?BK():uX();return(J)=>{return H4(h9(J)).pipe(l(J,{decode:NQ(rW(X)),encode:Q}))}}function P00(X,Y){return(Q)=>{return u1(Q).pipe(nW(X,Y),iW(H4(Q)))}}function Iw(X,Y){let Q=Y?.encodingStrategy==="omit"?BK():uX();return(J)=>{return xX(h9(J)).pipe(l(J,{decode:NQ(rW(X)),encode:Q}))}}function E00(X,Y){return(Q)=>{return u1(Q).pipe(Iw(X,Y),iW(xX(Q)))}}function B5(X){return c0(X).pipe(jw(d(X)))}function C00(X){return B5(X).pipe(nW(d(X),{encodingStrategy:"omit"}))}function s$(X,Y){return h({_tag:B5(X),...Y})}function xw(X){return(Y)=>{let Q={},J=[],$=new Set,G={},Z=(W)=>(D)=>W.includes(D[X]);return K(Y),Object.assign(Y,{cases:Q,discriminants:J,isAnyOf:Z,guards:G,match:H});function K(W){let D=W.ast;if(OQ(D)&&"members"in W&&globalThis.Array.isArray(W.members)&&W.members.every(o$))return W.members.forEach(K);let U=TQ(D);if(U.length>0){let N=U.find((V)=>V.key===X)?.literal;if(C7(N)){let V=typeof N==="number"?globalThis.String(N):N;if($.has(V))throw new globalThis.Error(`Duplicate discriminant: ${globalThis.String(N)}`);$.add(V),J.push(N),k(Q,N,W),k(G,N,Jw(u1(W)));return}}throw new globalThis.Error("No literal or unique symbol found")}function H(){if(arguments.length===1){let V=arguments[0];return function(z){let q=z[X];return(Object.hasOwn(V,q)?V[q]:void 0)(z)}}let W=arguments[0],D=arguments[1],U=W[X];return(Object.hasOwn(D,U)?D[U]:void 0)(W)}}}function w00(X){let Y={},Q=[];for(let K of Object.keys(X)){let H=s$(K,X[K]);k(Y,K,H),Q.push(H)}let J=J1(Q),{guards:$,isAnyOf:G,match:Z}=xw("_tag")(J);return S(J.ast,{cases:Y,isAnyOf:G,guards:$,match:Z})}function M00(){return(X)=>{return X}}function W4(X,Y){return vX((Q)=>Q instanceof X,Y)}function S0(){return(X,Y)=>{return new d0(X.ast,IJ(Y))}}var j0=uJ;function j00(X,Y=void 0){return new r8(X,Y)}function I1(X,Y){return JX(X,T0,({annotations:Q})=>Q===void 0?Y:Y.annotate(Q))}var oC="^\\S[\\s\\S]*\\S$|^\\S$|^$";function sW(X){let Y=new globalThis.RegExp(oC);return j0((Q)=>Q.trim()===Q,{expected:"a string with no leading or trailing whitespace",representation:{id:"effect/schema/isTrimmed",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isTrimmed()"}),arbitrary:{constraint:{patterns:[oC]}},...X})}var I00=s("effect/schema/isTrimmed",T0,({annotations:X})=>sW(X));function z5(X,Y){let{source:Q,flags:J}=X,$=J===""?`new RegExp(${P(Q)})`:`new RegExp(${P(Q)}, ${P(J)})`;return RQ(X,{toCode:()=>({runtime:`Schema.isPattern(${$})`}),...Y})}var x00=h({source:r,flags:r}).check(j0((X)=>{let Y=FG(()=>new globalThis.RegExp(X.source,X.flags));return Y1(Y)&&Y.success.source===X.source&&Y.success.flags===X.flags})),v00={id:"effect/schema/isPattern",payloadSchema:x00,revive:({annotations:X,payload:Y})=>z5(new globalThis.RegExp(Y.source,Y.flags),X)};function vw(X){return iK({toCode:()=>({runtime:"Schema.isStringFinite()"}),...X})}var S00=s("effect/schema/isStringFinite",T0,({annotations:X})=>vw(X));function Sw(X){return rK({toCode:()=>({runtime:"Schema.isStringBigInt()"}),...X})}var k00=s("effect/schema/isStringBigInt",T0,({annotations:X})=>Sw(X));function kw(X){return sK({toCode:()=>({runtime:"Schema.isStringSymbol()"}),...X})}var b00=s("effect/schema/isStringSymbol",T0,({annotations:X})=>kw(X)),g00=(X)=>{if(X)return new globalThis.RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${X}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`);return/^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|[fF]{8}-[fF]{4}-[fF]{4}-[fF]{4}-[fF]{12})$/};function bw(X,Y){let Q=g00(X);return z5(Q,{expected:X?`a UUID v${X}`:"a UUID",representation:{id:"effect/schema/isUUID",payload:{version:X??null}},toJsonSchema:()=>({pattern:Q.source,format:"uuid"}),toCode:()=>({runtime:X===void 0?"Schema.isUUID()":`Schema.isUUID(${X})`}),...Y})}var y00=s("effect/schema/isUUID",h({version:J1([r$([1,2,3,4,5,6,7,8]),T0])}),({annotations:X,payload:Y})=>bw(Y.version??void 0,X)),iC=/^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/;function gw(X){return z5(iC,{expected:"a GUID",representation:{id:"effect/schema/isGUID",payload:null},toJsonSchema:()=>({pattern:iC.source}),toCode:()=>({runtime:"Schema.isGUID()"}),...X})}var h00=s("effect/schema/isGUID",T0,({annotations:X})=>gw(X));function yw(X){let Y=/^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/;return z5(Y,{representation:{id:"effect/schema/isULID",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isULID()"}),...X})}var m00=s("effect/schema/isULID",T0,({annotations:X})=>yw(X));function aW(X){let Y=/^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;return z5(Y,{expected:"a base64 encoded string",representation:{id:"effect/schema/isBase64",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isBase64()"}),...X})}var f00=s("effect/schema/isBase64",T0,({annotations:X})=>aW(X));function hw(X){let Y=/^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;return z5(Y,{expected:"a base64url encoded string",representation:{id:"effect/schema/isBase64Url",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isBase64Url()"}),...X})}var p00=s("effect/schema/isBase64Url",T0,({annotations:X})=>hw(X));function mw(X,Y){let Q=JSON.stringify(X),J=new globalThis.RegExp(`^${A9(X)}`);return j0(($)=>$.startsWith(X),{expected:`a string starting with ${Q}`,representation:{id:"effect/schema/isStartsWith",payload:{startsWith:X}},toJsonSchema:()=>({pattern:J.source}),toCode:()=>({runtime:`Schema.isStartsWith(${P(X)})`}),arbitrary:{constraint:{patterns:[J.source]}},...Y})}var d00=s("effect/schema/isStartsWith",h({startsWith:r}),({annotations:X,payload:Y})=>mw(Y.startsWith,X));function fw(X,Y){let Q=JSON.stringify(X),J=new globalThis.RegExp(`${A9(X)}$`);return j0(($)=>$.endsWith(X),{expected:`a string ending with ${Q}`,representation:{id:"effect/schema/isEndsWith",payload:{endsWith:X}},toJsonSchema:()=>({pattern:J.source}),toCode:()=>({runtime:`Schema.isEndsWith(${P(X)})`}),arbitrary:{constraint:{patterns:[J.source]}},...Y})}var u00=s("effect/schema/isEndsWith",h({endsWith:r}),({annotations:X,payload:Y})=>fw(Y.endsWith,X));function pw(X,Y){let Q=JSON.stringify(X),J=new globalThis.RegExp(A9(X));return j0(($)=>$.includes(X),{expected:`a string including ${Q}`,representation:{id:"effect/schema/isIncludes",payload:{includes:X}},toJsonSchema:()=>({pattern:J.source}),toCode:()=>({runtime:`Schema.isIncludes(${P(X)})`}),arbitrary:{constraint:{patterns:[J.source]}},...Y})}var c00=s("effect/schema/isIncludes",h({includes:r}),({annotations:X,payload:Y})=>pw(Y.includes,X)),rC="^[^a-z]*$";function dw(X){let Y=new globalThis.RegExp(rC);return j0((Q)=>Q.toUpperCase()===Q,{expected:"a string with all characters in uppercase",representation:{id:"effect/schema/isUppercased",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isUppercased()"}),arbitrary:{constraint:{patterns:[rC]}},...X})}var l00=s("effect/schema/isUppercased",T0,({annotations:X})=>dw(X)),nC="^[^A-Z]*$";function uw(X){let Y=new globalThis.RegExp(nC);return j0((Q)=>Q.toLowerCase()===Q,{expected:"a string with all characters in lowercase",representation:{id:"effect/schema/isLowercased",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isLowercased()"}),arbitrary:{constraint:{patterns:[nC]}},...X})}var o00=s("effect/schema/isLowercased",T0,({annotations:X})=>uw(X)),sC="^[^a-z]?.*$";function cw(X){let Y=new globalThis.RegExp(sC);return j0((Q)=>Q.charAt(0).toUpperCase()===Q.charAt(0),{expected:"a string with the first character in uppercase",representation:{id:"effect/schema/isCapitalized",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isCapitalized()"}),arbitrary:{constraint:{patterns:[sC]}},...X})}var i00=s("effect/schema/isCapitalized",T0,({annotations:X})=>cw(X)),aC="^[^A-Z]?.*$";function lw(X){let Y=new globalThis.RegExp(aC);return j0((Q)=>Q.charAt(0).toLowerCase()===Q.charAt(0),{expected:"a string with the first character in lowercase",representation:{id:"effect/schema/isUncapitalized",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isUncapitalized()"}),arbitrary:{constraint:{patterns:[aC]}},...X})}var r00=s("effect/schema/isUncapitalized",T0,({annotations:X})=>lw(X)),Y6=S(bJ),ow=dK,n00=s("effect/schema/isFinite",T0,({annotations:X})=>ow(X));function sQ(X){let Y=w8(X.order),Q=X.formatter??P;return(J,$)=>{return j0((G)=>Y(G,J),{expected:`a value greater than ${Q(J)}`,arbitrary:{constraint:{ordered:{order:X.order,minimum:J,exclusiveMinimum:!0}}},...X.annotate?.(J),...$})}}function aQ(X){let Y=WY(X.order),Q=X.formatter??P;return(J,$)=>{return j0((G)=>Y(G,J),{expected:`a value greater than or equal to ${Q(J)}`,arbitrary:{constraint:{ordered:{order:X.order,minimum:J}}},...X.annotate?.(J),...$})}}function tQ(X){let Y=x5(X.order),Q=X.formatter??P;return(J,$)=>{return j0((G)=>Y(G,J),{expected:`a value less than ${Q(J)}`,arbitrary:{constraint:{ordered:{order:X.order,maximum:J,exclusiveMaximum:!0}}},...X.annotate?.(J),...$})}}function eQ(X){let Y=HY(X.order),Q=X.formatter??P;return(J,$)=>{return j0((G)=>Y(G,J),{expected:`a value less than or equal to ${Q(J)}`,arbitrary:{constraint:{ordered:{order:X.order,maximum:J}}},...X.annotate?.(J),...$})}}function X7(X){let Y=WY(X.order),Q=w8(X.order),J=HY(X.order),$=x5(X.order),G=X.formatter??P;return(Z,K)=>{let H=Z.exclusiveMinimum?Q:Y,W=Z.exclusiveMaximum?$:J;return j0((D)=>H(D,Z.minimum)&&W(D,Z.maximum),{expected:`a value between ${G(Z.minimum)}${Z.exclusiveMinimum?" (excluded)":""} and ${G(Z.maximum)}${Z.exclusiveMaximum?" (excluded)":""}`,arbitrary:{constraint:{ordered:{order:X.order,minimum:Z.minimum,maximum:Z.maximum,...Z.exclusiveMinimum&&{exclusiveMinimum:!0},...Z.exclusiveMaximum&&{exclusiveMaximum:!0}}}},...X.annotate?.(Z),...K})}}function iw(X){return(Y,Q)=>{let J=X.formatter??P;return j0(($)=>X.remainder($,Y)===X.zero,{expected:`a value that is a multiple of ${J(Y)}`,...X.annotate?.(Y),...Q})}}function b9(X){if(!globalThis.Number.isFinite(X))throw new globalThis.RangeError(`Expected a finite number, got ${P(X)}`);return X}var rw=sQ({order:O1,annotate:(X)=>({representation:{id:"effect/schema/isGreaterThan",payload:{exclusiveMinimum:b9(X)}},toJsonSchema:()=>({exclusiveMinimum:X}),toCode:()=>({runtime:`Schema.isGreaterThan(${P(X)})`})})}),s00=s("effect/schema/isGreaterThan",h({exclusiveMinimum:Y6}),({annotations:X,payload:Y})=>rw(Y.exclusiveMinimum,X)),tW=aQ({order:O1,annotate:(X)=>({representation:{id:"effect/schema/isGreaterThanOrEqualTo",payload:{minimum:b9(X)}},toJsonSchema:()=>({minimum:X}),toCode:()=>({runtime:`Schema.isGreaterThanOrEqualTo(${P(X)})`})})}),a00=s("effect/schema/isGreaterThanOrEqualTo",h({minimum:Y6}),({annotations:X,payload:Y})=>tW(Y.minimum,X)),nw=tQ({order:O1,annotate:(X)=>({representation:{id:"effect/schema/isLessThan",payload:{exclusiveMaximum:b9(X)}},toJsonSchema:()=>({exclusiveMaximum:X}),toCode:()=>({runtime:`Schema.isLessThan(${P(X)})`})})}),t00=s("effect/schema/isLessThan",h({exclusiveMaximum:Y6}),({annotations:X,payload:Y})=>nw(Y.exclusiveMaximum,X)),sw=eQ({order:O1,annotate:(X)=>({representation:{id:"effect/schema/isLessThanOrEqualTo",payload:{maximum:b9(X)}},toJsonSchema:()=>({maximum:X}),toCode:()=>({runtime:`Schema.isLessThanOrEqualTo(${P(X)})`})})}),e00=s("effect/schema/isLessThanOrEqualTo",h({maximum:Y6}),({annotations:X,payload:Y})=>sw(Y.maximum,X)),a$=X7({order:O1,annotate:(X)=>{let Y=X.exclusiveMinimum?!0:void 0,Q=X.exclusiveMaximum?!0:void 0;return{representation:{id:"effect/schema/isBetween",payload:{minimum:b9(X.minimum),maximum:b9(X.maximum),...Y&&{exclusiveMinimum:Y},...Q&&{exclusiveMaximum:Q}}},toJsonSchema:()=>({[Y?"exclusiveMinimum":"minimum"]:X.minimum,[Q?"exclusiveMaximum":"maximum"]:X.maximum}),toCode:()=>({runtime:`Schema.isBetween({ minimum: ${P(X.minimum)}, maximum: ${P(X.maximum)}, exclusiveMinimum: ${P(Y)}, exclusiveMaximum: ${P(Q)} })`})}}}),X10=s("effect/schema/isBetween",h({minimum:Y6,maximum:Y6,exclusiveMinimum:xX(c0(!0)),exclusiveMaximum:xX(c0(!0))}),({annotations:X,payload:Y})=>a$(Y,X)),aw=iw({remainder:Aq,zero:0,annotate:(X)=>({expected:`a value that is a multiple of ${X}`,representation:{id:"effect/schema/isMultipleOf",payload:{divisor:X}},toJsonSchema:()=>({multipleOf:X}),toCode:()=>({runtime:`Schema.isMultipleOf(${P(X)})`})})}),Y10=s("effect/schema/isMultipleOf",h({divisor:Y6}),({annotations:X,payload:Y})=>aw(Y.divisor,X));function Y7(X){return j0((Y)=>globalThis.Number.isSafeInteger(Y),{expected:"an integer",representation:{id:"effect/schema/isInt",payload:null},toJsonSchema:()=>({type:"integer"}),toCode:()=>({runtime:"Schema.isInt()"}),arbitrary:{constraint:{integer:!0}},...X})}var Q10=s("effect/schema/isInt",T0,({annotations:X})=>Y7(X)),q5=i$.check(Y7()),zX=q5.check(tW(0));function J10(X){return new r8([Y7(),a$({minimum:-2147483648,maximum:2147483647})],{expected:"a 32-bit integer",...X})}function $10(X){return new r8([Y7(),a$({minimum:0,maximum:4294967295})],{expected:"a 32-bit unsigned integer",...X})}function g9(X){if(globalThis.Number.isNaN(X.getTime()))throw new globalThis.RangeError(`Expected a valid Date, got ${P(X)}`);return X.toISOString()}function y9(X){return`new Date(${P(X.getTime())})`}var tw=sQ({order:w4,annotate:(X)=>{return{representation:{id:"effect/schema/isGreaterThanDate",payload:{exclusiveMinimum:g9(X)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isGreaterThanDate(${y9(X)})`})}}}),ew=aQ({order:w4,annotate:(X)=>{return{representation:{id:"effect/schema/isGreaterThanOrEqualToDate",payload:{minimum:g9(X)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isGreaterThanOrEqualToDate(${y9(X)})`})}}}),XM=tQ({order:w4,annotate:(X)=>{return{representation:{id:"effect/schema/isLessThanDate",payload:{exclusiveMaximum:g9(X)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isLessThanDate(${y9(X)})`})}}}),YM=eQ({order:w4,annotate:(X)=>{return{representation:{id:"effect/schema/isLessThanOrEqualToDate",payload:{maximum:g9(X)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isLessThanOrEqualToDate(${y9(X)})`})}}}),QM=X7({order:w4,annotate:(X)=>{let Y=X.exclusiveMinimum?!0:void 0,Q=X.exclusiveMaximum?!0:void 0;return{representation:{id:"effect/schema/isBetweenDate",payload:{minimum:g9(X.minimum),maximum:g9(X.maximum),...Y&&{exclusiveMinimum:Y},...Q&&{exclusiveMaximum:Q}}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isBetweenDate({ minimum: ${y9(X.minimum)}, maximum: ${y9(X.maximum)}, exclusiveMinimum: ${P(Y)}, exclusiveMaximum: ${P(Q)} })`})}}}),JM=sQ({order:AX,annotate:(X)=>{return{representation:{id:"effect/schema/isGreaterThanBigInt",payload:{exclusiveMinimum:X.toString(10)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isGreaterThanBigInt(${P(X)})`})}}}),$M=aQ({order:AX,annotate:(X)=>{return{representation:{id:"effect/schema/isGreaterThanOrEqualToBigInt",payload:{minimum:X.toString(10)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isGreaterThanOrEqualToBigInt(${P(X)})`})}}}),_M=tQ({order:AX,annotate:(X)=>{return{representation:{id:"effect/schema/isLessThanBigInt",payload:{exclusiveMaximum:X.toString(10)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isLessThanBigInt(${P(X)})`})}}}),GM=eQ({order:AX,annotate:(X)=>{return{representation:{id:"effect/schema/isLessThanOrEqualToBigInt",payload:{maximum:X.toString(10)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isLessThanOrEqualToBigInt(${P(X)})`})}}}),ZM=X7({order:AX,annotate:(X)=>{let Y=X.exclusiveMinimum?!0:void 0,Q=X.exclusiveMaximum?!0:void 0;return{representation:{id:"effect/schema/isBetweenBigInt",payload:{minimum:X.minimum.toString(10),maximum:X.maximum.toString(10),...Y&&{exclusiveMinimum:Y},...Q&&{exclusiveMaximum:Q}}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isBetweenBigInt({ minimum: ${P(X.minimum)}, maximum: ${P(X.maximum)}, exclusiveMinimum: ${P(Y)}, exclusiveMaximum: ${P(Q)} })`})}}}),_10=sQ({order:_8,formatter:(X)=>A6(X)}),G10=aQ({order:_8,formatter:(X)=>A6(X)}),Z10=tQ({order:_8,formatter:(X)=>A6(X)}),K10=eQ({order:_8,formatter:(X)=>A6(X)}),H10=X7({order:_8,formatter:(X)=>A6(X)});function eW(X,Y){return X=Math.max(0,Math.floor(X)),j0((Q)=>Q.length>=X,{expected:`a value with a length of at least ${X}`,representation:{id:"effect/schema/isMinLength",payload:{minLength:X}},toJsonSchema:({type:Q})=>Q==="array"?{minItems:X}:{minLength:X},toCode:()=>({runtime:`Schema.isMinLength(${X})`}),[XX]:!0,arbitrary:{constraint:{minLength:X}},...Y})}var W10=s("effect/schema/isMinLength",h({minLength:zX}),({annotations:X,payload:Y})=>eW(Y.minLength,X));function KM(X){return eW(1,X)}function HM(X,Y){return X=Math.max(0,Math.floor(X)),j0((Q)=>Q.length<=X,{expected:`a value with a length of at most ${X}`,representation:{id:"effect/schema/isMaxLength",payload:{maxLength:X}},toJsonSchema:({type:Q})=>Q==="array"?{maxItems:X}:{maxLength:X},toCode:()=>({runtime:`Schema.isMaxLength(${X})`}),[XX]:!0,arbitrary:{constraint:{maxLength:X}},...Y})}var U10=s("effect/schema/isMaxLength",h({maxLength:zX}),({annotations:X,payload:Y})=>HM(Y.maxLength,X));function XU(X,Y,Q){return X=Math.max(0,Math.floor(X)),Y=Math.max(0,Math.floor(Y)),j0((J)=>J.length>=X&&J.length<=Y,{expected:X===Y?`a value with a length of ${X}`:`a value with a length between ${X} and ${Y}`,representation:{id:"effect/schema/isLengthBetween",payload:{minimum:X,maximum:Y}},toJsonSchema:({type:J})=>J==="array"?{allOf:[{minItems:X},{maxItems:Y}]}:{allOf:[{minLength:X},{maxLength:Y}]},toCode:()=>({runtime:`Schema.isLengthBetween(${X}, ${Y})`}),[XX]:!0,arbitrary:{constraint:{minLength:X,maxLength:Y}},...Q})}var D10=s("effect/schema/isLengthBetween",h({minimum:zX,maximum:zX}),({annotations:X,payload:Y})=>XU(Y.minimum,Y.maximum,X));function WM(X,Y){return X=Math.max(0,Math.floor(X)),j0((Q)=>Q.size>=X,{expected:`a value with a size of at least ${X}`,representation:{id:"effect/schema/isMinSize",payload:{minSize:X}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isMinSize(${X})`}),[XX]:!0,arbitrary:{constraint:{minLength:X}},...Y})}var N10=s("effect/schema/isMinSize",h({minSize:zX}),({annotations:X,payload:Y})=>WM(Y.minSize,X));function UM(X,Y){return X=Math.max(0,Math.floor(X)),j0((Q)=>Q.size<=X,{expected:`a value with a size of at most ${X}`,representation:{id:"effect/schema/isMaxSize",payload:{maxSize:X}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isMaxSize(${X})`}),[XX]:!0,arbitrary:{constraint:{maxLength:X}},...Y})}var V10=s("effect/schema/isMaxSize",h({maxSize:zX}),({annotations:X,payload:Y})=>UM(Y.maxSize,X));function DM(X,Y,Q){return X=Math.max(0,Math.floor(X)),Y=Math.max(0,Math.floor(Y)),j0((J)=>J.size>=X&&J.size<=Y,{expected:X===Y?`a value with a size of ${X}`:`a value with a size between ${X} and ${Y}`,representation:{id:"effect/schema/isSizeBetween",payload:{minimum:X,maximum:Y}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isSizeBetween(${X}, ${Y})`}),[XX]:!0,arbitrary:{constraint:{minLength:X,maxLength:Y}},...Q})}var B10=s("effect/schema/isSizeBetween",h({minimum:zX,maximum:zX}),({annotations:X,payload:Y})=>DM(Y.minimum,Y.maximum,X));function NM(X,Y){return X=Math.max(0,Math.floor(X)),j0((Q)=>Reflect.ownKeys(Q).length>=X,{expected:`a value with at least ${X===1?"1 entry":`${X} entries`}`,representation:{id:"effect/schema/isMinProperties",payload:{minProperties:X}},toJsonSchema:()=>({minProperties:X}),toCode:()=>({runtime:`Schema.isMinProperties(${X})`}),[XX]:!0,arbitrary:{constraint:{minLength:X}},...Y})}var z10=s("effect/schema/isMinProperties",h({minProperties:zX}),({annotations:X,payload:Y})=>NM(Y.minProperties,X));function VM(X,Y){return X=Math.max(0,Math.floor(X)),j0((Q)=>Reflect.ownKeys(Q).length<=X,{expected:`a value with at most ${X===1?"1 entry":`${X} entries`}`,representation:{id:"effect/schema/isMaxProperties",payload:{maxProperties:X}},toJsonSchema:()=>({maxProperties:X}),toCode:()=>({runtime:`Schema.isMaxProperties(${X})`}),[XX]:!0,arbitrary:{constraint:{maxLength:X}},...Y})}var q10=s("effect/schema/isMaxProperties",h({maxProperties:zX}),({annotations:X,payload:Y})=>VM(Y.maxProperties,X));function BM(X,Y,Q){return X=Math.max(0,Math.floor(X)),Y=Math.max(0,Math.floor(Y)),j0((J)=>Reflect.ownKeys(J).length>=X&&Reflect.ownKeys(J).length<=Y,{expected:X===Y?`a value with exactly ${X===1?"1 entry":`${X} entries`}`:`a value with between ${X} and ${Y} entries`,representation:{id:"effect/schema/isPropertiesLengthBetween",payload:{minimum:X,maximum:Y}},toJsonSchema:()=>({minProperties:X,maxProperties:Y}),toCode:()=>({runtime:`Schema.isPropertiesLengthBetween(${X}, ${Y})`}),[XX]:!0,arbitrary:{constraint:{minLength:X,maxLength:Y}},...Q})}var O10=s("effect/schema/isPropertiesLengthBetween",h({minimum:zX,maximum:zX}),({annotations:X,payload:Y})=>BM(Y.minimum,Y.maximum,X));function zM(X,Y){let Q=h9(X),J=SF(Q.ast);return j0(($,G,Z)=>{let K=Reflect.ownKeys($),H=[];for(let W of K){let D=J(W,Z);if(D!==void 0){if(H.push(new v0([W],D)),Z.errors==="first")break}}if(V6(H))return new F0(G,T($),H);return!0},{expected:"an object with property names matching the schema",representation:{id:"effect/schema/isPropertyNames",payload:null,schemas:[Q.ast]},toJsonSchema:({schemas:$})=>({propertyNames:$[0]}),toCode:({schemas:$})=>({runtime:`Schema.isPropertyNames(${$[0].runtime})`}),[XX]:!0,...Y})}var L10=s("effect/schema/isPropertyNames",T0,({annotations:X,schemas:Y})=>zM(Y[0],X));function YU(X){return j0((Y)=>K3(Y).length===Y.length,{expected:"an array with unique items",representation:{id:"effect/schema/isUnique",payload:null},toJsonSchema:()=>({uniqueItems:!0}),toCode:()=>({runtime:"Schema.isUnique()"}),arbitrary:{constraint:{unique:!0}},...X})}var T10=s("effect/schema/isUnique",T0,({annotations:X})=>YU(X)),F10=r.check(KM()),R10=r.check(XU(1,1));function U4(X){let Y=qX()([X],([Q])=>(J,$,G)=>{if(n7(J)){if(P0(J))return pX;return V1(a0(Q)(J.value,G),{onSuccess:T,onFailure:(Z)=>new F0($,T(J),[new v0(["value"],Z)])})}return f(new r0($,T(J)))},{representation:{id:"effect/schema/Option",payload:null},toCode:({typeParameters:Q})=>({runtime:`Schema.Option(${Q[0].runtime})`,Type:`Option.Option<${Q[0].Type}>`,importDeclarations:['import * as Option from "effect/Option"']}),expected:"Option",toCodec:([Q])=>S0()(J1([h({_tag:c0("Some"),value:Q}),h({_tag:c0("None")})]),p0({decode:(J)=>J._tag==="None"?p():T(J.value),encode:(J)=>N1(J)?{_tag:"Some",value:J.value}:{_tag:"None"}})),toArbitrary:([Q])=>(J,$)=>{let G=J.constant(p()),Z=J.oneof(G,Q.arbitrary.map(T));return m9(J,$,G,Z)},toEquivalence:([Q])=>MN(Q),toFormatter:([Q])=>gX({onNone:()=>"none()",onSome:(J)=>`some(${Q(J)})`})});return S(Y.ast,{value:X})}var A10=JX("effect/schema/Option",T0,({annotations:X,typeParameters:Y})=>{let Q=U4(Y[0]);return X===void 0?Q:Q.annotate(X)});function P10(X){return lW(X).pipe(l(U4(u1(X)),TT()))}function E10(X){return n$(X).pipe(l(U4(u1(X)),FT()))}function C10(X,Y){return Aw(X).pipe(l(U4(u1(X)),RT(Y)))}function w10(X){return H4(X).pipe(l(U4(u1(X)),AT()))}function M10(X){return xX(X).pipe(l(U4(u1(X)),PT()))}function j10(X,Y){let Q=Y===void 0?"omit":Y.onNoneEncoding,J=Q===null?null:void 0;return xX(lW(X)).pipe(l(U4(u1(X)),xJ({decode:($)=>$.pipe(k5(w7),T),encode:Q==="omit"?S5:($)=>T(s7(S5($),()=>J))})))}function qM(X,Y){let Q=qX()([X,Y],([J,$])=>(G,Z,K)=>{if(!$3(G))return f(new r0(Z,T(G)));switch(G._tag){case"Success":return V1(XH(J)(G.success,K),{onSuccess:m,onFailure:(H)=>new F0(Z,T(G),[new v0(["success"],H)])});case"Failure":return V1(XH($)(G.failure,K),{onSuccess:c,onFailure:(H)=>new F0(Z,T(G),[new v0(["failure"],H)])})}},{representation:{id:"effect/schema/Result",payload:null},toCode:({typeParameters:J})=>({runtime:`Schema.Result(${J[0].runtime}, ${J[1].runtime})`,Type:`Result.Result<${J[0].Type}, ${J[1].Type}>`,importDeclarations:['import * as Result from "effect/Result"']}),expected:"Result",toCodec:([J,$])=>S0()(J1([h({_tag:c0("Success"),success:J}),h({_tag:c0("Failure"),failure:$})]),p0({decode:(G)=>G._tag==="Success"?m(G.success):c(G.failure),encode:(G)=>Y1(G)?{_tag:"Success",success:G.success}:{_tag:"Failure",failure:G.failure}})),toArbitrary:([J,$])=>(G,Z)=>{let K=MM(G,J.terminal?.map((W)=>m(W)),$.terminal?.map((W)=>c(W))),H=G.oneof(J.arbitrary.map((W)=>m(W)),$.arbitrary.map((W)=>c(W)));return m9(G,Z,K,H)},toEquivalence:([J,$])=>RG(J,$),toFormatter:([J,$])=>r1({onSuccess:(G)=>`success(${J(G)})`,onFailure:(G)=>`failure(${$(G)})`})});return S(Q.ast,{success:X,failure:Y})}var I10=JX("effect/schema/Result",T0,({annotations:X,typeParameters:Y})=>{let Q=qM(Y[0],Y[1]);return X===void 0?Q:Q.annotate(X)}),x10=vX((X)=>{if(!x1(X))return!1;let Y=globalThis.Object.keys(X);return Y.length>0&&Y.every((Q)=>{switch(Q){case"label":return typeof X[Q]==="string";case"disallowJsonEncode":return X[Q]===!0;default:return!1}})}),v10=J1([T0,x10]);function QU(X,Y){let Q=typeof Y?.label==="string"?Y.label:void 0,J=Y?.disallowJsonEncode===!0,$=Q!==void 0?J?{label:Q,disallowJsonEncode:!0}:{label:Q}:J?{disallowJsonEncode:!0}:void 0,G=Q!==void 0?a0(c0(Q)):void 0,Z=qX()([X],([K])=>(H,W,D)=>{if(ZK(H)){let U=G!==void 0?$9(G(H.label,D),(N)=>new v0(["label"],N)):uY;return EX(U,()=>V1(a0(K)(H9(H),D),{onSuccess:()=>H,onFailure:()=>{let N=T(H);return new F0(W,N,[new v0(["value"],new U0(N))])}}))}return f(new r0(W,T(H)))},{representation:{id:"effect/schema/Redacted",payload:$??null},toCode:({typeParameters:K})=>({runtime:$!==void 0?`Schema.Redacted(${K[0].runtime}, ${P($)})`:`Schema.Redacted(${K[0].runtime})`,Type:`Redacted.Redacted<${K[0].Type}>`,importDeclarations:['import * as Redacted from "effect/Redacted"']}),expected:"Redacted",toCodecJson:([K])=>S0()(JU(K),{decode:Q0((H)=>P6(H,{label:Q})),encode:J?NK((H)=>"Cannot serialize Redacted"+(N1(H)&&typeof H.value.label==="string"?` with label: "${H.value.label}"`:"")):Q0(H9)}),toArbitrary:([K])=>()=>({arbitrary:K.arbitrary.map((H)=>P6(H,{label:Q})),terminal:K.terminal?.map((H)=>P6(H,{label:Q}))}),toFormatter:()=>globalThis.String,toEquivalence:([K])=>kL(K)});return S(Z.ast,{value:X})}var S10=JX("effect/schema/Redacted",v10,({annotations:X,payload:Y,typeParameters:Q})=>{let J=QU(Q[0],Y??void 0);return X===void 0?J:J.annotate(X)});function JU(X){return oW($9(FJ))(X)}function k10(X,Y){return JU(X).pipe(l(QU(u1(X),{label:Y?.label,disallowJsonEncode:Y?.disallowEncode}),{decode:Q0((Q)=>P6(Q,{label:Y?.label})),encode:Y?.disallowEncode?NK((Q)=>"Cannot encode Redacted"+(N1(Q)&&typeof Q.value.label==="string"?` with label: "${Q.value.label}"`:"")):Q0(H9)}))}function p$(X,Y){let Q=qX()([X,Y],([J,$])=>(G,Z,K)=>{if(!_q(G))return f(new r0(Z,T(G)));switch(G._tag){case"Fail":return V1(a0(J)(G.error,K),{onSuccess:l3,onFailure:(H)=>new F0(Z,T(G),[new v0(["error"],H)])});case"Die":return V1(a0($)(G.defect,K),{onSuccess:o3,onFailure:(H)=>new F0(Z,T(G),[new v0(["defect"],H)])});case"Interrupt":return d(G)}},{representation:{id:"effect/schema/CauseReason",payload:null},toCode:({typeParameters:J})=>({runtime:`Schema.CauseReason(${J[0].runtime}, ${J[1].runtime})`,Type:`Cause.Failure<${J[0].Type}, ${J[1].Type}>`,importDeclarations:['import * as Cause from "effect/Cause"']}),expected:"Cause.Failure",toCodec:([J,$])=>S0()(J1([h({_tag:c0("Fail"),error:J}),h({_tag:c0("Die"),defect:$}),h({_tag:c0("Interrupt"),fiberId:n$(Y6)})]),p0({decode:(G)=>{switch(G._tag){case"Fail":return l3(G.error);case"Die":return o3(G.defect);case"Interrupt":return i3(G.fiberId)}},encode:u})),toArbitrary:([J,$])=>OM(J,$),toEquivalence:([J,$])=>LM(J,$),toFormatter:([J,$])=>TM(J,$)});return S(Q.ast,{error:X,defect:Y})}var b10=JX("effect/schema/CauseReason",T0,({annotations:X,typeParameters:Y})=>{let Q=p$(Y[0],Y[1]);return X===void 0?Q:Q.annotate(X)});function OM(X,Y){return(Q,J)=>{let $=Q.constant(i3()),G=Q.oneof($,Q.integer({min:1}).map(i3),X.arbitrary.map((Z)=>l3(Z)),Y.arbitrary.map((Z)=>o3(Z)));return m9(Q,J,$,G)}}function LM(X,Y){return(Q,J)=>{if(Q._tag!==J._tag)return!1;switch(Q._tag){case"Fail":return X(Q.error,J.error);case"Die":return Y(Q.defect,J.defect);case"Interrupt":return Q.fiberId===J.fiberId}}}function TM(X,Y){return(Q)=>{switch(Q._tag){case"Fail":return`Fail(${X(Q.error)})`;case"Die":return`Die(${Y(Q.defect)})`;case"Interrupt":return"Interrupt"}}}function d$(X,Y){let Q=qX()([X,Y],([J,$])=>{let G=Q1(p$(J,$));return(Z,K,H)=>{if(!$q(Z))return f(new r0(K,T(Z)));return V1(a0(G)(Z.reasons,H),{onSuccess:c3,onFailure:(W)=>new F0(K,T(Z),[new v0(["failures"],W)])})}},{representation:{id:"effect/schema/Cause",payload:null},toCode:({typeParameters:J})=>({runtime:`Schema.Cause(${J[0].runtime}, ${J[1].runtime})`,Type:`Cause.Cause<${J[0].Type}, ${J[1].Type}>`,importDeclarations:['import * as Cause from "effect/Cause"']}),expected:"Cause",toCodec:([J,$])=>S0()(Q1(p$(J,$)),p0({decode:c3,encode:({reasons:G})=>G})),toArbitrary:([J,$])=>FM(J,$),toEquivalence:([J,$])=>RM(J,$),toFormatter:([J,$])=>AM(J,$)});return S(Q.ast,{error:X,defect:Y})}var g10=JX("effect/schema/Cause",T0,({annotations:X,typeParameters:Y})=>{let Q=d$(Y[0],Y[1]);return X===void 0?Q:Q.annotate(X)});function FM(X,Y){return(Q,J)=>{let $=OM(X,Y)(Q,J),G=Q.constant(Gq),Z=Q.array($.arbitrary).map(c3);return m9(Q,J,G,Z)}}function RM(X,Y){let Q=zN(LM(X,Y));return(J,$)=>Q(J.reasons,$.reasons)}function AM(X,Y){let Q=TM(X,Y);return(J)=>`Cause([${J.reasons.map(Q).join(", ")}])`}var y10=vX((X)=>{if(!x1(X))return!1;let Y=globalThis.Object.keys(X);return Y.length>0&&Y.every((Q)=>(Q==="includeStack"||Q==="excludeCause")&&X[Q]===!0)}),h10=J1([T0,y10]),PM=(X)=>(X?.includeStack===!0?1:0)|(X?.excludeCause===!0?2:0),EM=(X)=>{switch(X){case 0:return;case 1:return{includeStack:!0};case 2:return{excludeCause:!0};case 3:return{includeStack:!0,excludeCause:!0}}},tC=[];function CM(X){let Y=PM(X),Q=tC[Y];if(Q!==void 0)return Q;let J=EM(Y),$=W4(globalThis.Error,{representation:{id:"effect/schema/Error",payload:J??null},toCode:()=>({runtime:J!==void 0?`Schema.Error(${P(J)})`:"Schema.Error()",Type:"globalThis.Error"}),expected:"Error",toCodecJson:()=>S0()(j60,OT(J)),toArbitrary:()=>(G)=>G.string().map((Z)=>new globalThis.Error(Z))});return tC[Y]=$,$}var m10=JX("effect/schema/Error",h10,({annotations:X,payload:Y})=>{let Q=CM(Y??void 0);return X===void 0?Q:Q.annotate(X)}),eC=[];function f10(X){let Y=PM(X),Q=eC[Y];if(Q!==void 0)return Q;let J=X_.pipe(l(dW,LT(EM(Y))));return eC[Y]=J,J}function wM(X,Y,Q){let J=qX()([X,Y,Q],([$,G,Z])=>{let K=d$(G,Z);return(H,W,D)=>{if(!Sz(H))return f(new r0(W,T(H)));switch(H._tag){case"Success":return V1(a0($)(H.value,D),{onSuccess:n5,onFailure:(U)=>new F0(W,T(H),[new v0(["value"],U)])});case"Failure":return V1(a0(K)(H.cause,D),{onSuccess:h8,onFailure:(U)=>new F0(W,T(H),[new v0(["cause"],U)])})}}},{representation:{id:"effect/schema/Exit",payload:null},toCode:({typeParameters:$})=>({runtime:`Schema.Exit(${$[0].runtime}, ${$[1].runtime}, ${$[2].runtime})`,Type:`Exit.Exit<${$[0].Type}, ${$[1].Type}, ${$[2].Type}>`,importDeclarations:['import * as Exit from "effect/Exit"']}),expected:"Exit",toCodec:([$,G,Z])=>S0()(J1([h({_tag:c0("Success"),value:$}),h({_tag:c0("Failure"),cause:d$(G,Z)})]),p0({decode:(K)=>K._tag==="Success"?n5(K.value):h8(K.cause),encode:(K)=>M1(K)?{_tag:"Success",value:K.value}:{_tag:"Failure",cause:K.cause}})),toArbitrary:([$,G,Z])=>(K,H)=>{let W=FM(G,Z)(K,H),D=MM(K,$.terminal?.map((N)=>n5(N)),W.terminal?.map((N)=>h8(N))),U=K.oneof($.arbitrary.map((N)=>n5(N)),W.arbitrary.map((N)=>h8(N)));return m9(K,H,D,U)},toEquivalence:([$,G,Z])=>{let K=RM(G,Z);return(H,W)=>{if(H._tag!==W._tag)return!1;switch(H._tag){case"Success":return $(H.value,W.value);case"Failure":return K(H.cause,W.cause)}}},toFormatter:([$,G,Z])=>{let K=AM(G,Z);return(H)=>{switch(H._tag){case"Success":return`Exit.Success(${$(H.value)})`;case"Failure":return`Exit.Failure(${K(H.cause)})`}}}});return S(J.ast,{value:X,error:Y,defect:Q})}var p10=JX("effect/schema/Exit",T0,({annotations:X,typeParameters:Y})=>{let Q=wM(Y[0],Y[1],Y[2]);return X===void 0?Q:Q.annotate(X)});function MM(X,Y,Q){return Y===void 0?Q:Q===void 0?Y:X.oneof(Y,Q)}function m9(X,Y,Q,J){return{arbitrary:Q===void 0||Y.recursion===void 0?J:X.oneof(Y.recursion,Q,J),terminal:Q}}function Xw(X,Y,Q,J){return J===void 0?X.array(Y,Q):X.uniqueArray(Y,{...Q,comparator:J})}function t$(X,Y,Q,J,$,G){let Z=Y.constraint,K=Z===void 0||Z.minLength===void 0&&Z.maxLength===void 0?void 0:{...Z.minLength!==void 0?{minLength:Z.minLength}:{},...Z.maxLength!==void 0?{maxLength:Z.maxLength}:{}};if(K?.minLength!==void 0&&K.maxLength!==void 0&&K.minLength>K.maxLength)throw new globalThis.Error("Unable to derive an arbitrary for size constraints");let H=K?.minLength??0,W=H===0?X.constant([]):J===void 0?void 0:Xw(X,J,{...K,maxLength:H},G),D=m9(X,Y,W,Xw(X,Q,K,G));return{arbitrary:D.arbitrary.map($),terminal:D.terminal?.map($)}}function jM(X,Y,Q,J,$){return t$(X,Y,X.tuple(Q.arbitrary,J.arbitrary),Q.terminal===void 0||J.terminal===void 0?void 0:X.tuple(Q.terminal,J.terminal),$,([G],[Z])=>o(G,Z))}function IM(X,Y){let Q=qX()([X,Y],([J,$])=>{let G=Q1(k9([J,$]));return(Z,K,H)=>{if(Z instanceof globalThis.Map)return V1(a0(G)([...Z],H),{onSuccess:(W)=>new globalThis.Map(W),onFailure:(W)=>new F0(K,T(Z),[new v0(["entries"],W)])});return f(new r0(K,T(Z)))}},{representation:{id:"effect/schema/ReadonlyMap",payload:null},toCode:({typeParameters:J})=>({runtime:`Schema.ReadonlyMap(${J[0].runtime}, ${J[1].runtime})`,Type:`globalThis.ReadonlyMap<${J[0].Type}, ${J[1].Type}>`}),expected:"ReadonlyMap",toCodec:([J,$])=>S0()(Q1(k9([J,$])),p0({decode:(G)=>new globalThis.Map(G),encode:(G)=>[...G.entries()]})),toArbitrary:([J,$])=>(G,Z)=>jM(G,Z,J,$,(K)=>new globalThis.Map(K)),toEquivalence:([J,$])=>x7(J,$),toFormatter:([J,$])=>(G)=>{let Z=G.size;if(Z===0)return"ReadonlyMap(0) {}";let K=globalThis.Array.from(G.entries()).sort().map(([H,W])=>`${J(H)} => ${$(W)}`);return`ReadonlyMap(${Z}) { ${K.join(", ")} }`}});return S(Q.ast,{key:X,value:Y})}var d10=JX("effect/schema/ReadonlyMap",T0,({annotations:X,typeParameters:Y})=>{let Q=IM(Y[0],Y[1]);return X===void 0?Q:Q.annotate(X)});function xM(X,Y){let Q=qX()([X,Y],([J,$])=>{let G=Q1(k9([J,$]));return(Z,K,H)=>{if(k2(Z))return V1(a0(G)(eY(Z),H),{onSuccess:tY,onFailure:(W)=>new F0(K,T(Z),[new v0(["entries"],W)])});return f(new r0(K,T(Z)))}},{representation:{id:"effect/schema/HashMap",payload:null},toCode:({typeParameters:J})=>({runtime:`Schema.HashMap(${J[0].runtime}, ${J[1].runtime})`,Type:`HashMap.HashMap<${J[0].Type}, ${J[1].Type}>`,importDeclarations:['import * as HashMap from "effect/HashMap"']}),expected:"HashMap",toCodec:([J,$])=>S0()(Q1(k9([J,$])),p0({decode:tY,encode:eY})),toArbitrary:([J,$])=>(G,Z)=>jM(G,Z,J,$,tY),toEquivalence:([J,$])=>x7(J,$),toFormatter:([J,$])=>(G)=>{let Z=b2(G);if(Z===0)return"HashMap(0) {}";let K=eY(G).sort().map(([H,W])=>`${J(H)} => ${$(W)}`);return`HashMap(${Z}) { ${K.join(", ")} }`}});return S(Q.ast,{key:X,value:Y})}var u10=JX("effect/schema/HashMap",T0,({annotations:X,typeParameters:Y})=>{let Q=xM(Y[0],Y[1]);return X===void 0?Q:Q.annotate(X)});function vM(X){let Y=qX()([X],([Q])=>{let J=Q1(Q);return($,G,Z)=>{if($ instanceof globalThis.Set)return V1(a0(J)([...$],Z),{onSuccess:(K)=>new globalThis.Set(K),onFailure:(K)=>new F0(G,T($),[new v0(["values"],K)])});return f(new r0(G,T($)))}},{representation:{id:"effect/schema/ReadonlySet",payload:null},toCode:({typeParameters:Q})=>({runtime:`Schema.ReadonlySet(${Q[0].runtime})`,Type:`globalThis.ReadonlySet<${Q[0].Type}>`}),expected:"ReadonlySet",toCodec:([Q])=>S0()(Q1(Q),p0({decode:(J)=>new globalThis.Set(J),encode:(J)=>[...J.values()]})),toArbitrary:([Q])=>(J,$)=>t$(J,$,Q.arbitrary,Q.terminal,(G)=>new globalThis.Set(G),o),toEquivalence:([Q])=>v7(Q),toFormatter:([Q])=>(J)=>{let $=J.size;if($===0)return"ReadonlySet(0) {}";let G=globalThis.Array.from(J.values()).sort().map((Z)=>`${Q(Z)}`);return`ReadonlySet(${$}) { ${G.join(", ")} }`}});return S(Y.ast,{value:X})}var c10=JX("effect/schema/ReadonlySet",T0,({annotations:X,typeParameters:Y})=>{let Q=vM(Y[0]);return X===void 0?Q:Q.annotate(X)});function SM(X){let Y=qX()([X],([Q])=>{let J=Q1(Q);return($,G,Z)=>{if(m2($))return V1(a0(J)(C1($),Z),{onSuccess:QQ,onFailure:(K)=>new F0(G,T($),[new v0(["values"],K)])});return f(new r0(G,T($)))}},{representation:{id:"effect/schema/HashSet",payload:null},toCode:({typeParameters:Q})=>({runtime:`Schema.HashSet(${Q[0].runtime})`,Type:`HashSet.HashSet<${Q[0].Type}>`}),expected:"HashSet",toCodec:([Q])=>S0()(Q1(Q),p0({decode:QQ,encode:C1})),toArbitrary:([Q])=>(J,$)=>t$(J,$,Q.arbitrary,Q.terminal,QQ,o),toEquivalence:([Q])=>v7(Q),toFormatter:([Q])=>(J)=>{let $=f2(J);if($===0)return"HashSet(0) {}";let G=globalThis.Array.from(J).sort().map((Z)=>`${Q(Z)}`);return`HashSet(${$}) { ${G.join(", ")} }`}});return S(Y.ast,{value:X})}var l10=JX("effect/schema/HashSet",T0,({annotations:X,typeParameters:Y})=>{let Q=SM(Y[0]);return X===void 0?Q:Q.annotate(X)});function kM(X){let Y=qX()([X],([Q])=>{let J=Q1(Q);return($,G,Z)=>{if(UJ($))return V1(a0(J)(C1($),Z),{onSuccess:DJ,onFailure:(K)=>new F0(G,T($),[new v0(["values"],K)])});return f(new r0(G,T($)))}},{representation:{id:"effect/schema/Chunk",payload:null},toCode:({typeParameters:Q})=>({runtime:`Schema.Chunk(${Q[0].runtime})`,Type:`Chunk.Chunk<${Q[0].Type}>`}),expected:"Chunk",toCodec:([Q])=>S0()(Q1(Q),p0({decode:DJ,encode:C1})),toArbitrary:([Q])=>(J,$)=>t$(J,$,Q.arbitrary,Q.terminal,DJ),toEquivalence:([Q])=>r2(Q),toFormatter:([Q])=>(J)=>{let $=$L(J);if($===0)return"Chunk(0) {}";let G=globalThis.Array.from(J).sort().map((Z)=>`${Q(Z)}`);return`Chunk(${$}) { ${G.join(", ")} }`}});return S(Y.ast,{value:X})}var o10=JX("effect/schema/Chunk",T0,({annotations:X,typeParameters:Y})=>{let Q=kM(Y[0]);return X===void 0?Q:Q.annotate(X)}),bM=W4(globalThis.RegExp,{representation:{id:"effect/schema/RegExp",payload:null},toCode:()=>({runtime:"Schema.RegExp",Type:"globalThis.RegExp"}),expected:"RegExp",toCodecJson:()=>S0()(h({source:r,flags:r}),wX({decode:(X)=>J9({try:()=>new globalThis.RegExp(X.source,X.flags),catch:(Y)=>new U0(T(Y),{message:globalThis.String(Y)})}),encode:(X)=>d({source:X.source,flags:X.flags})})),toArbitrary:()=>(X)=>X.tuple(X.constantFrom(".",".*","\\d+","\\w+","[a-z]+","[A-Z]+","[0-9]+","^[a-zA-Z0-9]+$","^\\d{4}-\\d{2}-\\d{2}$"),X.uniqueArray(X.constantFrom("g","i","m","s","u","y"),{minLength:0,maxLength:6}).map((Y)=>Y.join(""))).map(([Y,Q])=>new globalThis.RegExp(Y,Q)),toEquivalence:()=>(X,Y)=>X.source===Y.source&&X.flags===Y.flags}),i10=I1("effect/schema/RegExp",bM),gM=r.annotate({expected:"a string that will be decoded as a URL"}),$U=W4(globalThis.URL,{representation:{id:"effect/schema/URL",payload:null},toCode:()=>({runtime:"Schema.URL",Type:"globalThis.URL"}),expected:"URL",toCodecJson:()=>S0()(gM,FK),toArbitrary:()=>(X)=>X.webUrl().map((Y)=>new globalThis.URL(Y)),toEquivalence:()=>(X,Y)=>X.toString()===Y.toString()}),r10=I1("effect/schema/URL",$U),n10=gM.pipe(l($U,FK));function _U(X,Y,Q){let J={...Y};if(X?.minimum!==void 0){let $=Q===void 0?X.minimum:Q(X.minimum),G=X.exclusiveMinimum?new globalThis.Date($.getTime()+1):$;if(J.min===void 0||G.getTime()>J.min.getTime())J.min=G}if(X?.maximum!==void 0){let $=Q===void 0?X.maximum:Q(X.maximum),G=X.exclusiveMaximum?new globalThis.Date($.getTime()-1):$;if(J.max===void 0||G.getTime()<J.max.getTime())J.max=G}return J}var yM=r.annotate({expected:"a string that will be decoded as a Date"}),Q6=vX((X)=>X instanceof globalThis.Date&&!globalThis.Number.isNaN(X.getTime()),{representation:{id:"effect/schema/Date",payload:null},toCode:()=>({runtime:"Schema.Date",Type:"globalThis.Date"}),expected:"a valid Date",toCodecJson:()=>S0()(yM,TK),toArbitrary:()=>(X,Y)=>X.date(_U(Y?.constraint?.ordered?.order===w4?Y.constraint.ordered:void 0,{noInvalidDate:!0}))}),s10=I1("effect/schema/Date",Q6),a10=yM.pipe(l(Q6,TK)),t10=q5.pipe(l(Q6,UT)),Q7=vX(OG,{representation:{id:"effect/schema/Duration",payload:null},toCode:()=>({runtime:"Schema.Duration",Type:"Duration.Duration",importDeclarations:['import * as Duration from "effect/Duration"']}),expected:"Duration",toCodecJson:()=>S0()(J1([h({_tag:c0("Infinity")}),h({_tag:c0("NegativeInfinity")}),h({_tag:c0("Nanos"),value:j6}),h({_tag:c0("Millis"),value:q5})]),p0({decode:(X)=>{switch(X._tag){case"Infinity":return r6;case"NegativeInfinity":return I4;case"Nanos":return N6(X.value);case"Millis":return j8(X.value)}},encode:(X)=>{switch(X.value._tag){case"Infinity":return{_tag:"Infinity"};case"NegativeInfinity":return{_tag:"NegativeInfinity"};case"Nanos":return{_tag:"Nanos",value:X.value.nanos};case"Millis":return{_tag:"Millis",value:X.value.millis}}}})),toArbitrary:()=>(X)=>X.oneof(X.constant(r6),X.constant(I4),X.bigInt().map(N6),X.maxSafeInteger().map(j8)),toFormatter:()=>globalThis.String,toEquivalence:()=>LG}),e10=I1("effect/schema/Duration",Q7),XX0=r.annotate({expected:"a string that will be decoded as a Duration"}),YX0=XX0.pipe(l(Q7,DT)),QX0=j6.pipe(l(Q7,NT)),JX0=i$.pipe(l(Q7,VT)),hM=r.annotate({expected:"a string that will be decoded as a BigDecimal"}),mM=20,fM="Unable to derive an arbitrary for the ordered BigDecimal constraints";function u$(X,Y){return c8(X,Y).value}function $X0(X,Y,Q){return Q?u$(o2(X,Y),Y)+globalThis.BigInt(1):u$(l2(X,Y),Y)}function _X0(X,Y,Q){return Q?u$(l2(X,Y),Y)-globalThis.BigInt(1):u$(o2(X,Y),Y)}function GX0(X){return Math.max(mM,X.minimum?.scale??0,X.maximum?.scale??0,X.exclusiveMinimum&&X.minimum!==void 0?X.minimum.scale+1:0,X.exclusiveMaximum&&X.maximum!==void 0?X.maximum.scale+1:0)}function fW(X,Y){let Q={};if(X.minimum!==void 0)Q.min=$X0(X.minimum,Y,X.exclusiveMinimum===!0);if(X.maximum!==void 0)Q.max=_X0(X.maximum,Y,X.exclusiveMaximum===!0);if(Q.min!==void 0&&Q.max!==void 0&&Q.min>Q.max)return;return Q}function ZX0(X){let Y=GX0(X);if(fW(X,Y)===void 0)throw new globalThis.Error(fM);let Q=0,J=Y;while(Q<J){let $=Q+Math.floor((J-Q)/2);if(fW(X,$)===void 0)Q=$+1;else J=$}return{min:Q,max:Y}}var GU=vX(WJ,{representation:{id:"effect/schema/BigDecimal",payload:null},toCode:()=>({runtime:"Schema.BigDecimal",Type:"BigDecimal.BigDecimal",importDeclarations:['import * as BigDecimal from "effect/BigDecimal"']}),expected:"BigDecimal",toCodecJson:()=>S0()(hM,RK),toArbitrary:()=>(X,Y)=>{let Q=Y.constraint?.ordered?.order===_8?Y.constraint.ordered:void 0;if(Q===void 0)return X.tuple(X.bigInt(),X.integer({min:0,max:mM})).map(([J,$])=>e1(J,$));return X.integer(ZX0(Q)).chain((J)=>{let $=fW(Q,J);if($===void 0)throw new globalThis.Error(fM);return X.bigInt($).map((G)=>e1(G,J))})},toFormatter:()=>(X)=>A6(X),toEquivalence:()=>u2}),KX0=I1("effect/schema/BigDecimal",GU),HX0=hM.pipe(l(GU,RK)),WX0=r.annotate({expected:"a string that will be decoded as JSON",contentMediaType:"application/json"}),UX0=pM(dW);function pM(X){return WX0.pipe(l(X,jT))}var ZU=W4(globalThis.File,{representation:{id:"effect/schema/File",payload:null},toCode:()=>({runtime:"Schema.File",Type:"globalThis.File"}),expected:"File",toCodecJson:()=>S0()(h({data:r.check(aW()),type:r,name:r,lastModified:q5}),wX({decode:(X)=>r1(K9(X.data),{onFailure:(Y)=>f(new U0(T(X.data),{message:Y.message})),onSuccess:(Y)=>{let Q=new globalThis.Uint8Array(Y);return d(new globalThis.File([Q],X.name,{type:X.type,lastModified:X.lastModified}))}}),encode:(X)=>O2({try:async()=>{let Y=new globalThis.Uint8Array(await X.arrayBuffer());return{data:OJ(Y),type:X.type,name:X.name,lastModified:X.lastModified}},catch:(Y)=>new U0(T(X),{message:globalThis.String(Y)})})}))}),DX0=I1("effect/schema/File",ZU),KU=W4(globalThis.FormData,{representation:{id:"effect/schema/FormData",payload:null},toCode:()=>({runtime:"Schema.FormData",Type:"globalThis.FormData"}),expected:"FormData",toCodecJson:()=>S0()(Q1(k9([r,J1([h({_tag:B5("String"),value:r}),h({_tag:B5("File"),value:ZU})])])),wX({decode:(X)=>{let Y=new globalThis.FormData;for(let[Q,J]of X)Y.append(Q,J.value);return d(Y)},encode:(X)=>{return d(globalThis.Array.from(X.entries()).map(([Y,Q])=>{if(typeof Q==="string")return[Y,{_tag:"String",value:Q}];else return[Y,{_tag:"File",value:Q}]}))}}))}),NX0=I1("effect/schema/FormData",KU);function VX0(X){return KU.pipe(l(X,IT))}var HU=W4(globalThis.URLSearchParams,{representation:{id:"effect/schema/URLSearchParams",payload:null},toCode:()=>({runtime:"Schema.URLSearchParams",Type:"globalThis.URLSearchParams"}),expected:"URLSearchParams",toCodecJson:()=>S0()(r.annotate({expected:"a query string that will be decoded as URLSearchParams"}),p0({decode:(X)=>new globalThis.URLSearchParams(X),encode:(X)=>X.toString()}))}),BX0=I1("effect/schema/URLSearchParams",HU);function zX0(X){return HU.pipe(l(X,xT))}var qX0=r.annotate({expected:"a string that will be decoded as a number"}).pipe(l(i$,N9)),OX0=r.annotate({expected:"a string that will be decoded as a finite number"}).pipe(l(Y6,N9)),LX0=S(nK).pipe(l(j6,vJ)),dM=r.check(sW()),TX0=r.annotate({expected:"a string that will be decoded as a trimmed string"}).pipe(l(dM,WT())),FX0=r.annotate({expected:"a base64 encoded string that will be decoded as a UTF-8 string"}).pipe(l(r,ET)),RX0=r.annotate({expected:"a base64 (URL) encoded string that will be decoded as a UTF-8 string"}).pipe(l(r,CT)),AX0=r.annotate({expected:"a hex encoded string that will be decoded as a UTF-8 string"}).pipe(l(r,wT)),PX0=r.annotate({expected:"a URI component encoded string that will be decoded as a UTF-8 string"}).pipe(l(r,MT)),pW=J1([Y6,Lw,r]),EX0=h({issues:Q1(h({message:r,path:xX(Q1(J1([pW,h({key:pW})])))}))}),CX0=r$([0,1]).pipe(l(Ow,p0({decode:(X)=>X===1,encode:(X)=>X?1:0}))),uM=r.annotate({expected:"a base64 encoded string that will be decoded as Uint8Array",format:"byte",contentEncoding:"base64"}),J7=W4(globalThis.Uint8Array,{representation:{id:"effect/schema/Uint8Array",payload:null},toCode:()=>({runtime:"Schema.Uint8Array",Type:"globalThis.Uint8Array"}),expected:"Uint8Array",toCodecJson:()=>S0()(uM,AK),toArbitrary:()=>(X)=>X.uint8Array()}),wX0=I1("effect/schema/Uint8Array",J7),MX0=uM.pipe(l(J7,AK)),jX0=r.annotate({expected:"a base64 (URL) encoded string that will be decoded as a Uint8Array"}).pipe(l(J7,{decode:tL(),encode:MJ()})),IX0=r.annotate({expected:"a hex encoded string that will be decoded as a Uint8Array"}).pipe(l(J7,{decode:XT(),encode:jJ()})),$7=vX((X)=>s2(X)&&KL(X),{representation:{id:"effect/schema/DateTimeUtc",payload:null},toCode:()=>({runtime:"Schema.DateTimeUtc",Type:"DateTime.Utc",importDeclarations:['import * as DateTime from "effect/DateTime"']}),expected:"DateTime.Utc",toCodecJson:()=>S0()(r,CK),toArbitrary:()=>(X,Y)=>X.date(_U(Y?.constraint?.ordered?.order===t2?Y.constraint.ordered:void 0,{noInvalidDate:!0},BJ)).map((Q)=>WL(Q)),toFormatter:()=>(X)=>X.toString(),toEquivalence:()=>a2}),xX0=I1("effect/schema/DateTimeUtc",$7),vX0=Q6.pipe(l($7,{decode:OK(),encode:Q0(BJ)})),SX0=r.annotate({expected:"a string that will be decoded as a DateTime.Utc"}).pipe(l($7,CK)),kX0=q5.pipe(l($7,{decode:OK(),encode:Q0(BL)})),cM=vX(GL,{representation:{id:"effect/schema/TimeZoneOffset",payload:null},toCode:()=>({runtime:"Schema.TimeZoneOffset",Type:"DateTime.TimeZone.Offset",importDeclarations:['import * as DateTime from "effect/DateTime"']}),expected:"DateTime.TimeZone.Offset",toCodecJson:()=>S0()(q5,vT),toArbitrary:()=>(X)=>X.integer({min:-43200000,max:50400000}).map((Y)=>_Q(Y)),toFormatter:()=>(X)=>l8(X),toEquivalence:()=>(X,Y)=>X.offset===Y.offset}),bX0=I1("effect/schema/TimeZoneOffset",cM),lM=r.annotate({expected:"an IANA time zone identifier"}),WU=vX(ZL,{representation:{id:"effect/schema/TimeZoneNamed",payload:null},toCode:()=>({runtime:"Schema.TimeZoneNamed",Type:"DateTime.TimeZone.Named",importDeclarations:['import * as DateTime from "effect/DateTime"']}),expected:"DateTime.TimeZone.Named",toCodecJson:()=>S0()(lM,PK),toArbitrary:()=>(X)=>X.constantFrom(...["UTC","Europe/London","America/New_York","Asia/Tokyo","Australia/Sydney"].map(e2)),toFormatter:()=>(X)=>l8(X),toEquivalence:()=>(X,Y)=>X.id===Y.id}),gX0=I1("effect/schema/TimeZoneNamed",WU),yX0=lM.pipe(l(WU,PK)),oM=r.annotate({expected:"a time zone string (IANA identifier or offset like +03:00)"}),UU=vX(_L,{representation:{id:"effect/schema/TimeZone",payload:null},toCode:()=>({runtime:"Schema.TimeZone",Type:"DateTime.TimeZone",importDeclarations:['import * as DateTime from "effect/DateTime"']}),expected:"DateTime.TimeZone",toCodecJson:()=>S0()(oM,EK),toArbitrary:()=>(X)=>X.oneof(X.integer({min:-43200000,max:50400000}).map((Y)=>_Q(Y)),X.constantFrom(...["UTC","Europe/London","America/New_York","Asia/Tokyo","Australia/Sydney"].map(e2))),toFormatter:()=>(X)=>l8(X),toEquivalence:()=>(X,Y)=>l8(X)===l8(Y)}),hX0=I1("effect/schema/TimeZone",UU),mX0=oM.pipe(l(UU,EK)),iM=r.annotate({expected:"a zoned DateTime string (e.g. 2024-01-01T00:00:00.000+00:00[Europe/London])"}),DU=vX((X)=>s2(X)&&HL(X),{representation:{id:"effect/schema/DateTimeZoned",payload:null},toCode:()=>({runtime:"Schema.DateTimeZoned",Type:"DateTime.Zoned",importDeclarations:['import * as DateTime from "effect/DateTime"']}),expected:"DateTime.Zoned",toCodecJson:()=>S0()(iM,wK),toArbitrary:()=>(X,Y)=>X.tuple(X.date(_U(Y?.constraint?.ordered?.order===t2?Y.constraint.ordered:void 0,{max:new globalThis.Date(8639999949600000),min:new globalThis.Date(-8639999949600000),noInvalidDate:!0},BJ)),X.constantFrom("UTC","Europe/London","America/New_York","Asia/Tokyo","Australia/Sydney")).map(([Q,J])=>UL(Q,{timeZone:J})),toFormatter:()=>(X)=>zJ(X),toEquivalence:()=>a2}),fX0=I1("effect/schema/DateTimeZoned",DU),pX0=iM.pipe(l(DU,wK)),dX0=globalThis.Symbol.for("immer-draftable"),Yw={};function NU(X,Y,Q,J,$){let G=cX0(Q,Y,J),Z=rM(Y),K=class extends X{constructor(...[H,W]){let U=W?.["~payload"],N=U?.token===Yw?U.value:Q.make(H??{},W);super(N,{...W,disableChecks:!0,"~payload":{token:Yw,value:N}})}static[rQ]=rQ;get[Z](){return Z}static[dX0]=!0;static identifier=Y;static fields=Q.fields;static get ast(){return G(this).ast}static pipe(){return _0(this,arguments)}static rebuild(H){return G(this).rebuild(H)}static make(H,W){return new this(H,W)}static makeOption(H,W){return X$(G(this))(H??{},W)}static makeEffect(H,W){return G(this).makeEffect(H??{},W)}static annotate(H){return this.rebuild(E6(this.ast,H))}static annotateKey(H){return this.rebuild(EQ(this.ast,H))}static check(...H){return this.rebuild(iX(this.ast,H))}static extend(H){return(W,D)=>{let U=_7(W)?W:h(W),N={...Q.fields,...U.fields},V=fJ(N,Q.ast.checks,{identifier:H});return NU(this,H,cW(iX(V,U.ast.checks),N),D,$)}}static mapFields(H,W){return Q.mapFields(H,W)}};if($!==void 0)Object.assign(K.prototype,$(Y));return K}function uX0(X){return new q0(Q0((Y)=>new X(Y)),uX())}function rM(X){return`~effect/Schema/Class/${X}`}function cX0(X,Y,Q){let J;return($)=>{if(J!==void 0)return J;let G=uX0($),Z=S(new G5([X.ast],()=>(K,H)=>{return K instanceof $||j(K,rM(Y))?d(K):f(new r0(H,T(K)))},{identifier:Y,[aJ]:([K])=>new d0(K,G),toCodec:([K])=>new d0(K.ast,G),toArbitrary:([K])=>()=>({arbitrary:K.arbitrary.map((H)=>new $(H)),terminal:K.terminal?.map((H)=>new $(H))}),toFormatter:([K])=>(H)=>`${$.identifier}(${K(H)})`,[KQ]:TQ(X.ast),...Q}));return J=l(Z,G)(X)}}function _7(X){return o$(X)}var nM=(X)=>(Y,Q)=>{let J=_7(Y)?Y:h(Y);return NU(Y3,X,J,Q,($)=>({toString(){return`${$}(${P({...this})})`}}))},lX0=(X)=>{return(Y,Q,J)=>{let $=_7(Q)?Q.mapFields((G)=>({_tag:B5(Y),...G}),{unsafePreserveChecks:!0}):s$(Y,Q);return nM(X??Y)($,J)}},sM=(X)=>(Y,Q)=>{let J=_7(Y)?Y:h(Y);return NU(ZY,X,J,Q,(G)=>({name:G}))},oX0=(X)=>{return(Y,Q,J)=>{let $=_7(Q)?Q.mapFields((G)=>({_tag:B5(Y),...G}),{unsafePreserveChecks:!0}):s$(Y,Q);return sM(X??Y)($,J)}};function aM(X){let Y=WH(X.ast);return(Q)=>Y(Q,{})}function iX0(X,Y){if(Y?.report===!0){let Q=WH(X.ast),J=HR();return VR(X.ast,J),{value:Q(f$,{}),report:WR(J)}}return aM(X)(f$)}function rX0(X){return(Y)=>{return Y.annotate({toFormatter:X})}}function nX0(X,Y){return Q(X.ast);function Q($){let G=K8($)?.toFormatter;if(typeof G==="function")return G($5($)?$.typeParameters.map(Q):[]);if(Y?.onBefore){let Z=Y.onBefore($,Q);if(Z!==void 0)return Z}return J($)}function J($){switch($._tag){default:return P;case"Never":return()=>"never";case"Void":return()=>"void";case"Arrays":{let G=$.elements.map(Q),Z=$.rest.map(Q);return(K)=>{let H=[],W=0;for(;W<G.length;W++)if(K.length<W+1){if(l0($.elements[W]))continue}else H.push(G[W](K[W]));if(Z.length>0){let[D,...U]=Z;for(;W<K.length-U.length;W++)H.push(D(K[W]));for(let N=0;N<U.length;N++)H.push(U[N](K[W+N]))}return"["+H.join(", ")+"]"}}case"Objects":{let G=$.propertySignatures.map((K)=>Q(K.type)),Z=$.indexSignatures.map((K)=>Q(K.type));if($.propertySignatures.length===0&&$.indexSignatures.length===0)return P;return(K)=>{let H=[],W=new Set;for(let D=0;D<G.length;D++){let U=$.propertySignatures[D],N=U.name;if(W.add(N),l0(U.type)&&!Object.hasOwn(K,N))continue;H.push(`${m6(N)}: ${G[D](K[N])}`)}for(let D=0;D<Z.length;D++){let U=z9(K,$.indexSignatures[D].parameter);for(let N of U){if(W.has(N))continue;W.add(N),H.push(`${m6(N)}: ${Z[D](K[N])}`)}}return H.length>0?"{ "+H.join(", ")+" }":"{}"}}case"Union":{let G=T1($).types,Z=(H)=>FQ(H,G),K=new Map(G.map((H,W)=>[H,[jQ(H),Q($.types[W])]]));return(H)=>{let W=Z(H);for(let D=0;D<W.length;D++){let[U,N]=K.get(W[D]);if(U(H))return N(H)}return P(H)}}case"Suspend":{let G=Z5(()=>Q($.thunk()));return(Z)=>G()(Z)}}}}function sX0(X){return(Y)=>Y.annotate({toEquivalence:X})}function aX0(X){return BR(X.ast)}function tX0(X){return UH(X.ast)}function tM(X,Y){let Q=UH(e$(X.ast));return TR(Q,Y)}function eM(X){return S(e$(X.ast),{schema:X})}var eX0=t8((X)=>{let Y=Y60(X,e$),Q=X.context;if(Y===X||Q===void 0)return Y;return oJ(Y,VU(Q))}),e$=X1((X)=>{let Y=i8(X),Q=eX0(X);if(Y===void 0||Q.encoding===void 0)return Q;let J=s8(Q);if(i8(J)!==void 0||LJ(J)===Y)return Q;let $=E6(J,{[ZQ]:Y});return t8(()=>$)(Q)});function VU(X){return X.defaultValue===void 0?X:new lX(X.isOptional,X.isMutable,void 0,X.annotations)}function Xj(X){if(X.propertySignatures.some((Y)=>typeof Y.name!=="string"))throw new globalThis.Error("Objects property names must be strings",{cause:X})}function Yj(X){return(Y)=>{let Q=new Map;for(let G=0;G<Y.length;G++)Q.set(F1(Y[G]),G);let J=[...Y].sort((G,Z)=>{G=F1(G),Z=F1(Z);let K=X(G),H=X(Z);if(K!==H)return K-H;return Q.get(G)-Q.get(Z)});if(!J.some((G,Z)=>G!==Y[Z]))return Y;return J}}var X60=Yj((X)=>{switch(X._tag){case"BigInt":case"Symbol":case"UniqueSymbol":return 0;default:return 1}});function Y60(X,Y){switch(X._tag){case"Declaration":{let Q=X.annotations?.toCodecJson??X.annotations?.toCodec;if(!l1(Q))return R0(X,[aK]);let J=X.typeParameters.map((G)=>IQ(F1(G))),$=Q(J);return $===void 0?X:R0(X,[a8($,Y)])}case"Unknown":return R0(X,[aK]);case"ObjectKeyword":return R0(X,[IF]);case"Undefined":case"Void":case"Literal":case"Number":return X.toCodecJson();case"UniqueSymbol":case"Symbol":case"BigInt":return X.toCodecStringTree();case"Objects":return Xj(X),X.recur(Y,sJ);case"Union":{let Q=X60(X.types);if(Q!==X.types)return new QX(Q,X.mode,X.annotations,X.checks,X.encoding,X.context,X.encodingChecks).recur(Y);return X.recur(Y)}case"Arrays":case"Suspend":return X.recur(Y)}return X}function Qj(X){return S(Jj(T1(X.ast)))}var Jj=X1((X)=>{let Y=Q60(X,Jj);return Y!==X&&X.context!==void 0?oJ(Y,VU(X.context)):Y});function Q60(X,Y){switch(X._tag){case"Declaration":{let Q=X.annotations?.toCodecIso??X.annotations?.toCodec;if(l1(Q)){let J=Q(X.typeParameters.map(($)=>IQ($)));return R0(X,[a8(J,Y)])}return X}case"Arrays":case"Objects":case"Union":case"Suspend":return X.recur(Y)}return X}function $j(X){return S(Zj(X.ast),{schema:X})}function J60(X){return S(Kj(X.ast))}function $60(X,Y){let Q=i8(X.ast)??GK(X.ast),J=Dw($j(X));return($)=>J($).pipe(F2((G)=>_60(G,{rootName:Q,...Y})))}function _60(X,Y){let Q=Y.rootName??"root",J=Y.arrayItemName??"item",$=Y.pretty??!0,G=Y.indent??"  ",Z=Y.sortKeys??!0,K=new Set,H=[];return D(Q,X,0),H.join($?`
`:"");function W(U,N){H.push($?G.repeat(U)+N:N)}function D(U,N,V,z){let{attrs:q,safe:F}=S9.tagInfo(U,z);if(N===void 0)W(V,`<${F}${q}/>`);else if(typeof N==="string")W(V,`<${F}${q}>${S9.escapeText(N)}</${F}>`);else if(typeof N!=="object"||N===null)W(V,`<${F}${q}>${S9.escapeText(P(N))}</${F}>`);else{if(K.has(N))throw new globalThis.Error("Cycle detected while serializing to XML.",{cause:N});K.add(N);try{if(globalThis.globalThis.Array.isArray(N)){if(N.length===0){W(V,`<${F}${q}/>`);return}W(V,`<${F}${q}>`);for(let w of N)D(J,w,V+1);W(V,`</${F}>`);return}let R=N,C=Object.keys(R);if(Z)C.sort();if(C.length===0){W(V,`<${F}${q}/>`);return}W(V,`<${F}${q}>`);for(let w of C)D(S9.parseTagName(w).safe,R[w],V+1,w);W(V,`</${F}>`)}finally{K.delete(N)}}}}var S9={escapeText(X){return X.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")},escapeAttribute(X){return X.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;")},parseTagName(X){let Y=X,Q=X;if(!/^[A-Za-z_]/.test(Q))Q="_"+Q;if(Q=Q.replace(/[^A-Za-z0-9._-]/g,"_"),/^xml/i.test(Q))Q="_"+Q;return{safe:Q,changed:Q!==Y}},tagInfo(X,Y){let{changed:Q,safe:J}=S9.parseTagName(X),G=Q||Y&&Y!==X?` data-name="${S9.escapeAttribute(Y??X)}"`:"";return{safe:J,attrs:G}}},G60=Yj((X)=>{switch(X._tag){case"Null":case"Boolean":case"Number":case"BigInt":case"Symbol":case"UniqueSymbol":return 0;default:return 1}});function Z60(X,Y,Q){switch(X._tag){case"Declaration":{let J=X.typeParameters.map((W)=>S(Y(F1(W)))),$=X.annotations?.toCodecStringTree;if(l1($)){let W=$(J);if(W===void 0)return X;return R0(X,[a8(W,Y)])}let G=X.annotations?.toCodecJson,Z=l1(G)?G(J):void 0,K=Z===void 0?X.annotations?.toCodec:void 0,H=Z??(l1(K)?K(J):void 0);return H===void 0?Q(X):R0(X,[a8(H,Y)])}case"Null":return R0(X,[K60]);case"Boolean":return R0(X,[H60]);case"Unknown":case"ObjectKeyword":return R0(X,[tK]);case"Enum":case"Number":case"Literal":case"UniqueSymbol":case"Symbol":case"BigInt":return X.toCodecStringTree();case"Objects":return Xj(X),X.recur(Y,sJ);case"Union":{let J=G60(X.types);if(J!==X.types)return new QX(J,X.mode,X.annotations,X.checks,X.encoding,X.context,X.encodingChecks).recur(Y);return X.recur(Y)}case"Arrays":case"Suspend":return X.recur(Y)}return X}var K60=new d0(new DX("null"),new q0(Q0(()=>null),Q0(()=>"null"))),H60=new d0(new QX([new DX("true"),new DX("false")],"anyOf"),new q0(Q0((X)=>X==="true"),Y5())),_j="~effect/Schema/SERIALIZER_ENSURE_ARRAY",Gj=(X)=>OQ(X)&&X.annotations?.[_j]===!0,Zj=t8((X)=>{if(Gj(X))return X;let Y=Z60(X,Zj,(Q)=>{throw new globalThis.Error("Missing structural codec for StringTree",{cause:Q})});if(Y!==X&&X.context!==void 0)return oJ(Y,VU(X.context));return Y}),Qw=(X)=>l0(X)?CQ(Q5):Q5,W60=new q0(Q0((X)=>typeof X==="string"?[X]:X),uX()),Kj=t8((X)=>{if(Gj(X))return X;let Y=U60(X);if(qQ(Y)){let Q=iJ(new QX([new oX(Y.isMutable,Y.elements.map(Qw),Y.rest.map(Qw)),n8],"anyOf",{[_j]:!0}),Y,W60);return l0(X)?CQ(Q):Q}return Y});function U60(X){return X._tag==="Declaration"||X._tag==="Arrays"||X._tag==="Objects"||X._tag==="Union"||X._tag==="Suspend"?X.recur(Kj):X}var D60=s("effect/schema/isGreaterThanDate",h({exclusiveMinimum:Q6}),({annotations:X,payload:Y})=>tw(Y.exclusiveMinimum,X)),N60=s("effect/schema/isGreaterThanOrEqualToDate",h({minimum:Q6}),({annotations:X,payload:Y})=>ew(Y.minimum,X)),V60=s("effect/schema/isLessThanDate",h({exclusiveMaximum:Q6}),({annotations:X,payload:Y})=>XM(Y.exclusiveMaximum,X)),B60=s("effect/schema/isLessThanOrEqualToDate",h({maximum:Q6}),({annotations:X,payload:Y})=>YM(Y.maximum,X)),z60=s("effect/schema/isBetweenDate",h({minimum:Q6,maximum:Q6,exclusiveMinimum:xX(c0(!0)),exclusiveMaximum:xX(c0(!0))}),({annotations:X,payload:Y})=>QM(Y,X)),q60=s("effect/schema/isGreaterThanBigInt",h({exclusiveMinimum:j6}),({annotations:X,payload:Y})=>JM(Y.exclusiveMinimum,X)),O60=s("effect/schema/isGreaterThanOrEqualToBigInt",h({minimum:j6}),({annotations:X,payload:Y})=>$M(Y.minimum,X)),L60=s("effect/schema/isLessThanBigInt",h({exclusiveMaximum:j6}),({annotations:X,payload:Y})=>_M(Y.exclusiveMaximum,X)),T60=s("effect/schema/isLessThanOrEqualToBigInt",h({maximum:j6}),({annotations:X,payload:Y})=>GM(Y.maximum,X)),F60=s("effect/schema/isBetweenBigInt",h({minimum:j6,maximum:j6,exclusiveMinimum:xX(c0(!0)),exclusiveMaximum:xX(c0(!0))}),({annotations:X,payload:Y})=>ZM(Y,X));function R60(X){let Y=Qj(X);return xR($H(Y),QH(Y))}function A60(X){return V$()}function P60(X){return V$()}function E60(X,Y){return(Q)=>{return S(E6(Q.ast,{toCodecIso:()=>new d0(X.ast,IJ(Y))}),{schema:Q})}}function C60(X){let Y=eM(X),Q=$H(Y),J=QH(Y);return{empty:[],diff:($,G)=>K$(Q($),Q(G)),combine:($,G)=>[...$,...G],patch:($,G)=>{let Z=Q($),K=CR(G,Z);return Object.is(K,Z)?$:J(K)}}}function w60(X){let Y=Pw(()=>Q),Q=J1([X,Q1(Y),Tw(r,Y)]);return Q}var X_=S(E6(B9,{toCode:()=>({runtime:"Schema.Json",Type:"Schema.Json"})})),M60=I1("effect/schema/Json",X_),j60=h({message:r,name:H4(r),stack:H4(r),cause:H4(X_)}),Hj=S(E6(jF,{toCode:()=>({runtime:"Schema.MutableJson",Type:"Schema.MutableJson"})})),I60=I1("effect/schema/MutableJson",Hj);function x60(X){return K8(X.ast)}function v60(X){return X.ast.context?.annotations}var G7=32,Z7=8;var Wj=4096;var Uj=16384,Dj=262144;var BU=4096;var k60=new TextEncoder,Nj=(X)=>k60.encode(X).byteLength,Y_=(X,Y)=>Number.isInteger(Y)&&Y>=0&&Nj(X)<=Y;var b60=/^[A-Za-z0-9][A-Za-z0-9._:-]*$/,Vj=(X)=>typeof X==="string"&&X.length>0&&Y_(X,256)&&b60.test(X);var g60=_.Literals(["unauthorized","bad_request","invalid","not_found","forbidden","timeout","cancelled","resource_exhausted","unsupported_capability","unsupported_result","result_too_large","failed","runtime_down"]),y60=_.String.pipe(_.check(_.makeFilter((X)=>Y_(X,BU),{message:`control error exceeds ${BU} UTF-8 bytes`}))),h60=_.Struct({_tag:g60,message:y60});var GH0=_.Union([_.Struct({ok:_.Literal(!0),data:_.Unknown}),_.Struct({ok:_.Literal(!1),error:h60})]);var zU=(X,Y)=>_.String.pipe(_.check(_.makeFilter((Q)=>Y_(Q,Y),{message:`${X} exceeds ${Y} UTF-8 bytes`}))),K7=_.String.pipe(_.check(_.makeFilter(Vj,{message:"sessionId must be nonempty bounded ASCII"}))),Bj=_.Struct({ref:zU("ref",Wj)}),zj=_.Struct({sessionId:K7,url:zU("url",Uj)}),qj=_.Struct({sessionId:K7,code:zU("code",Dj)}),Oj=_.Struct({sessionId:K7}),Lj=_.Struct({sessionId:K7}),Tj=_.Struct({sessionId:K7}),ZH0=_.Struct({status:_.Literal("ok")}),KH0=_.Struct({id:_.String,label:_.optionalKey(_.String),default:_.optionalKey(_.Boolean)}),HH0=_.Struct({sessionId:_.String,ref:_.String,nodeId:_.String,hostId:_.String,url:_.String,profile:_.String,state:_.String,attached:_.Boolean,title:_.optionalKey(_.String),lastError:_.optionalKey(_.String)}),WH0=_.Struct({result:_.Unknown}),UH0=_.Struct({path:_.String,bytes:_.Number}),DH0=_.Struct({ref:_.String,sessionId:_.NullOr(_.String),canvas:_.String,nodeId:_.String,hostId:_.String,url:_.String,profile:_.optionalKey(_.String)});var $X=(X)=>{try{return process.env[X]==="1"}catch{return!1}},VH0=typeof __VELLUM_COMMAND_HERDR_ENABLED__==="boolean"?__VELLUM_COMMAND_HERDR_ENABLED__:$X("VELLUM_COMMAND_HERDR"),BH0=typeof __VELLUM_COMMAND_CRON_ENABLED__==="boolean"?__VELLUM_COMMAND_CRON_ENABLED__:$X("VELLUM_COMMAND_CRON"),zH0=typeof __VELLUM_COMMAND_RELAY_ENABLED__==="boolean"?__VELLUM_COMMAND_RELAY_ENABLED__:$X("VELLUM_COMMAND_RELAY"),Q_=typeof __VELLUM_COMMAND_BROWSER_ENABLED__==="boolean"?__VELLUM_COMMAND_BROWSER_ENABLED__:$X("VELLUM_COMMAND_BROWSER"),qH0=typeof __VELLUM_COMMAND_FLEET_UI_ENABLED__==="boolean"?__VELLUM_COMMAND_FLEET_UI_ENABLED__:$X("VELLUM_COMMAND_FLEET_UI"),OH0=typeof __VELLUM_COMMAND_USAGE_ENABLED__==="boolean"?__VELLUM_COMMAND_USAGE_ENABLED__:$X("VELLUM_COMMAND_USAGE"),LH0=typeof __VELLUM_COMMAND_HELP_MAP_ENABLED__==="boolean"?__VELLUM_COMMAND_HELP_MAP_ENABLED__:$X("VELLUM_COMMAND_HELP_MAP"),TH0=typeof __VELLUM_COMMAND_AUDIO_ENABLED__==="boolean"?__VELLUM_COMMAND_AUDIO_ENABLED__:$X("VELLUM_COMMAND_AUDIO"),FH0=typeof __VELLUM_COMMAND_HERMES_INTEGRATION_ENABLED__==="boolean"?__VELLUM_COMMAND_HERMES_INTEGRATION_ENABLED__:$X("VELLUM_COMMAND_HERMES"),RH0=typeof __VELLUM_COMMAND_DEV_TOOLS_ENABLED__==="boolean"?__VELLUM_COMMAND_DEV_TOOLS_ENABLED__:$X("VELLUM_COMMAND_DEV_TOOLS"),AH0=typeof __VELLUM_COMMAND_HARNESS_KIMI_ENABLED__==="boolean"?__VELLUM_COMMAND_HARNESS_KIMI_ENABLED__:$X("VELLUM_COMMAND_HARNESS_KIMI"),PH0=typeof __VELLUM_COMMAND_HARNESS_MUSE_ENABLED__==="boolean"?__VELLUM_COMMAND_HARNESS_MUSE_ENABLED__:$X("VELLUM_COMMAND_HARNESS_MUSE"),EH0=typeof __VELLUM_COMMAND_HARNESS_PRIME_AGENT_ENABLED__==="boolean"?__VELLUM_COMMAND_HARNESS_PRIME_AGENT_ENABLED__:$X("VELLUM_COMMAND_HARNESS_PRIME_AGENT"),CH0=typeof __VELLUM_COMMAND_HARNESS_SETTINGS_ENABLED__==="boolean"?__VELLUM_COMMAND_HARNESS_SETTINGS_ENABLED__:$X("VELLUM_COMMAND_HARNESS_SETTINGS");var qU=_.Literals(["claude","codex","grok","hermes","pi","prime-agent","kimi","muse","devin","cursor","agy"]),xH0=qU.literals;var kH0=_.String.pipe(_.brand("NodeId")),bH0=_.String.pipe(_.brand("EdgeId"));var gH0=_.Literals(["actor","sink","scheduler","geography"]),OU=_.Literals(["tasks.list","tasks.create","tasks.claim","tasks.update","msg.list","msg.send","request.escalate","artifact.publish","browser.automate","board.list","board.create_topic","board.post","board.mark_read","pad.read","pad.patch","relay.trigger"]);var I6=(...X)=>WX.fromIterable(X),Fj=_.Literals(["agent"]),Rj=_.Literals(["page","task","requests","artifacts","board","pad","terminal"]),Aj=_.Literals(["watcher","timer","cron","relay"]),yH0=_.Union([Fj,Rj,Aj]),m60=Fj.literals,f60=Rj.literals,p60=Aj.literals,Pj=[...m60,...f60,...p60];var d60=_.Literals(["full","empty","subset"]);class q8 extends _.Class("PortGrant")({mode:d60,ports:_.HashSet(OU)}){static empty=new q8({mode:"empty",ports:WX.empty()});static full=new q8({mode:"full",ports:WX.empty()});static subset(X){if(WX.size(X)===0)return q8.empty;return new q8({mode:"subset",ports:X})}static of(...X){return q8.subset(I6(...X))}attenuate(X){if(this.mode==="empty")return q8.empty;if(this.mode==="full")return q8.subset(X);return q8.subset(WX.intersection(this.ports,X))}allows(X,Y){if(!WX.has(Y,X))return!1;if(this.mode==="empty")return!1;if(this.mode==="full")return!0;return WX.has(this.ports,X)}isEmpty(){return this.mode==="empty"}isFull(){return this.mode==="full"}}var D4=_.String.pipe(_.check(_.isPattern(/^seat_[a-f0-9]{64}$/)),_.brand("ActorSeatId"));var Ej=256,Cj=256,wj=256,SX=_.String.pipe(_.check(_.isMinLength(1)),_.check(_.isMaxLength(Ej))),Mj=_.String.pipe(_.check(_.isMinLength(1)),_.check(_.isMaxLength(Cj))),jj=_.String.pipe(_.check(_.isMinLength(1)),_.check(_.isMaxLength(wj))),J_=_.Struct({canvasName:Mj,nodeId:jj});var J6=_.Struct({seatId:D4,canvasName:Mj,nodeId:jj}),uH0=_.decodeUnknownSync(D4)(`seat_${"c".repeat(64)}`);var Ij=_.Literals(["task","proposal","request","message","artifact","delivery","topic","post","pad"]),xj={itemId:SX,sink:J_},$_=_.Struct({kind:Ij,...xj}),LU=_.Struct({kind:_.Literal("task"),...xj});var H7=_.String.pipe(_.check(_.isPattern(/^[a-f0-9]{64}$/)),_.brand("ContentSha256")),W7=_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(0)),_.check(_.makeFilter(Number.isSafeInteger,{message:"content byteLength must be a safe integer"})),_.brand("ContentByteLength")),TU=_.String.pipe(_.check(_.isMinLength(1)),_.check(_.isMaxLength(255)),_.check(_.isPattern(/^[^\u0000-\u001f\u007f]+$/)),_.brand("ContentMediaType")),FU=_.String.pipe(_.check(_.isMinLength(1)),_.check(_.isMaxLength(255)),_.check(_.isPattern(/^[^\u0000-\u001f\u007f]+$/)),_.brand("ContentDisplayName")),RU=_.Struct({sha256:H7,byteLength:W7}),OX=_.Struct({...RU.fields,mediaType:TU,displayName:_.optionalKey(FU)});var Sj=_.Struct({kind:_.Literal("local-path"),ref:OX,path:_.String.pipe(_.check(_.isMinLength(1)),_.check(_.isMaxLength(4096)),_.check(_.isPattern(/^[^\u0000]+$/)))});var AU=_.String.pipe(_.check(_.isMinLength(1)),_.check(_.isMaxLength(1024)),_.check(_.isPattern(/^[^\u0000-\u001f\u007f]+$/)),_.brand("ContentAvailabilityReason")),PU=_.String.pipe(_.check(_.isMinLength(1)),_.check(_.isMaxLength(64)),_.brand("ContentTimestamp")),EU=_.Struct({ref:OX,state:_.Literal("verified"),verifiedSha256:H7,verifiedByteLength:W7,verifiedAt:PU}).pipe(_.check(_.makeFilter(({ref:X,verifiedSha256:Y,verifiedByteLength:Q})=>X.sha256===Y&&X.byteLength===Q||"verified receipt does not match its ContentRef"))),CU=_.Struct({ref:OX,state:_.Literal("missing"),reason:AU}),wU=_.Struct({ref:OX,state:_.Literal("corrupt"),reason:AU,observedSha256:_.optionalKey(H7),observedByteLength:_.optionalKey(W7)}),MU=_.Struct({ref:OX,state:_.Literal("unavailable"),reason:AU}),kj=_.Union([EU,CU,wU,MU]),O8=_.Struct({kind:_.Literal("content"),ref:OX}),bj=_.decodeUnknownResult(O8,{onExcessProperty:"error"});var t60=_.decodeUnknownResult(OX,{onExcessProperty:"error"});var gj=_.Struct({kind:_.Literal("text"),text:_.String}),yj=_.Struct({kind:_.Literal("url"),url:_.String,mediaType:_.optionalKey(_.String)}),hj=_.Struct({kind:_.Literal("data"),data:_.Unknown}),__=_.Struct({kind:_.Literal("raw"),bytesBase64:_.String,mediaType:_.optionalKey(_.String)}),O5=_.Union([gj,yj,hj,__,O8]),mj=_.Literals(["user","agent"]),N4=_.Record(_.String,_.Unknown),L8=_.Struct({messageId:_.String,role:mj,parts:_.Array(O5),taskId:_.optionalKey(_.String),contextId:_.optionalKey(_.String),referenceTaskIds:_.optionalKey(_.Array(_.String)),metadata:_.optionalKey(N4)}),f9=_.Literals(["submitted","working","input-required","completed","canceled","failed","rejected","auth-required","archived"]),p9=_.Struct({description:_.optionalKey(_.String),artifacts:_.optionalKey(_.Struct({nodeId:_.String.pipe(_.check(_.isMinLength(1))),instruction:_.optionalKey(_.String),names:_.optionalKey(_.Array(_.String))})),git:_.optionalKey(_.Struct({minCommits:_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(1)))}))}),fj=_.Literals(["hard","soft"]),pj={id:_.String.pipe(_.check(_.isMinLength(1))),text:_.String.pipe(_.check(_.isMinLength(1))),severity:fj},G_=_.Struct(pj),jU=_.Struct({id:_.String.pipe(_.check(_.isMinLength(1))),text:_.String.pipe(_.check(_.isMinLength(1))),pinnedAt:_.String,sourceRequestId:_.optionalKey(_.String)}),IU=_.Struct({id:_.String.pipe(_.check(_.isMinLength(1))),label:_.String.pipe(_.check(_.isMinLength(1))),command:_.String.pipe(_.check(_.isMinLength(1)))}),Z_=_.Struct({...pj,station:_.String.pipe(_.check(_.isMinLength(1)))}),dj=_.Literals(["auto","operator-gated","operator-owned"]),uj=_.Struct({instruction:_.optionalKey(_.String),description:_.optionalKey(_.String),admission:_.optionalKey(dj),claimableAfterMs:_.optionalKey(_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(0)))),checklist:_.optionalKey(_.Array(IU))}),cj=_.Struct({emission:_.optionalKey(_.String),description:_.optionalKey(_.String),checklist:_.optionalKey(_.Array(IU))}),lj=_.Struct({instruction:_.optionalKey(_.String),claims:_.optionalKey(_.Array(G_)),inbound:_.optionalKey(uj),outbound:_.optionalKey(cj)});var oj=_.Struct({claimId:_.String.pipe(_.check(_.isMinLength(1))),response:_.String.pipe(_.check(_.isMinLength(1))),refs:_.optionalKey(_.Array(_.String))}),ij=_.Struct({claimId:_.String.pipe(_.check(_.isMinLength(1))),reason:_.String.pipe(_.check(_.isMinLength(1)))}),d9=_.Struct({artifacts:_.Array(_.Struct({artifactId:_.String.pipe(_.check(_.isMinLength(1))),nodeId:_.String.pipe(_.check(_.isMinLength(1)))})),git:_.optionalKey(_.Struct({commits:_.Array(_.String)})),responses:_.optionalKey(_.Array(oj)),claimWaivers:_.optionalKey(_.Array(ij))}),rj=_.Literals(["forwarded","closed","rejected-back"]),nj=_.Struct({nodeId:_.String.pipe(_.check(_.isMinLength(1))),enteredAt:_.String,epoch:_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(0))),claimedBy:_.optionalKey(D4),exitedAt:_.optionalKey(_.String),exit:_.optionalKey(rj),next:_.optionalKey(_.String),emissionNote:_.optionalKey(_.String)}),Y80=_.Struct({epoch:_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(1))),target:_.String.pipe(_.check(_.isMinLength(1))),at:_.String}),sj=8192,aj=_.Literals(["outbound","inbound"]),tj=_.Struct({checkId:_.String.pipe(_.check(_.isMinLength(1))),side:aj,label:_.String,command:_.String,exitCode:_.Number.pipe(_.check(_.isInt())),outputTail:_.String.pipe(_.check(_.isMaxLength(sj))),at:_.String,epoch:_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(0)))}),x6={dependsOn:_.optionalKey(_.Array(_.String)),finishCriteria:_.optionalKey(p9),claims:_.optionalKey(_.Array(Z_)),metadata:_.optionalKey(N4),reason:_.optionalKey(_.String)},LX=_.Struct({id:_.String,state:f9,claimedBy:_.optionalKey(D4),history:_.Array(L8),artifactIds:_.optionalKey(_.Array(_.String)),dependsOn:x6.dependsOn,finishCriteria:x6.finishCriteria,claims:x6.claims,completionEvidence:_.optionalKey(d9),epoch:_.optionalKey(_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(0)))),journey:_.optionalKey(_.Array(nj)),defects:_.optionalKey(_.Array(Y80)),holdUntil:_.optionalKey(_.String),boarding:_.optionalKey(_.Array(tj)),metadata:x6.metadata,reason:x6.reason,response:_.optionalKey(_.String)}).pipe(_.check(_.makeFilter(({id:X,state:Y,claimedBy:Q,metadata:J,dependsOn:$,completionEvidence:G})=>{if(J!==void 0&&Object.prototype.hasOwnProperty.call(J,"claimedBy"))return"metadata.claimedBy is retired; use Task.claimedBy";if(Y==="submitted"&&Q!==void 0)return"submitted tasks must be unclaimed";if((Y==="working"||Y==="input-required"||Y==="auth-required")&&Q===void 0)return`${Y} tasks require claimedBy`;if(G!==void 0&&Y!=="completed")return"completionEvidence is only valid on completed tasks";if($!==void 0){let Z=new Set;for(let K of $){if(typeof K!=="string"||K.trim().length===0)return"dependsOn entries must be non-empty task ids";if(K===X)return"dependsOn cannot include the task itself";if(Z.has(K))return"dependsOn must not contain duplicates";Z.add(K)}}return!0}))),Q80=_.Literals(["pending","approved","rejected"]),L5=_.Struct({id:_.String,state:Q80,brief:L8,proposedBy:J6,approvedTaskId:_.optionalKey(_.String),dependsOn:x6.dependsOn,finishCriteria:x6.finishCriteria,claims:x6.claims,metadata:x6.metadata,reason:x6.reason}).pipe(_.check(_.makeFilter(({state:X,approvedTaskId:Y})=>X==="approved"===(Y!==void 0)||"approved proposals require approvedTaskId; other proposal states forbid it"))),U7=_.Struct({artifactId:_.String,name:_.optionalKey(_.String),parts:_.Array(O5),task:_.optionalKey(LU),metadata:_.optionalKey(N4)}),xU=_.Struct({items:_.Array(LX),proposals:_.optionalKey(_.Array(L5)),contract:_.optionalKey(lj)}),vU=_.Struct({items:_.Array(LX)}),SU=_.Struct({items:_.Array(U7)}),kU=_.Struct({items:_.Array(L8)}),J80=_.Literals(["operator","actor"]),kX=_.Struct({kind:J80,seatId:_.optionalKey(D4),nodeId:_.optionalKey(_.String),label:_.optionalKey(_.String)}),ej=_.Literals(["open","archived"]),D7=_.Struct({postId:_.String,topicId:_.String,author:kX,parts:_.Array(O5).pipe(_.check(_.isMinLength(1))),position:_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(0))),createdAt:_.String,tags:_.optionalKey(_.Array(_.String.pipe(_.check(_.isMinLength(1)))))}),N7=_.Struct({topicId:_.String,title:_.String.pipe(_.check(_.isMinLength(1)),_.check(_.isMaxLength(512))),state:ej,openedBy:kX,openedAt:_.String,postCount:_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(0))),lastActivityAt:_.String,parts:_.optionalKey(_.Array(O5)),posts:_.optionalKey(_.Array(D7))}),XI=_.Struct({topics:_.Array(N7)}),YI=_.Struct({topicId:_.String,title:_.String,state:ej,postCount:_.Number,lastActivityAt:_.String,authorLabel:_.optionalKey(_.String)}),bU=_.Struct({topics:_.Array(YI),unread:_.optionalKey(_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(0))))}),K_=_.Struct({revision:_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(0))),shapeCount:_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(0))),unreadPinCount:_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(0)))}),gU=xU,yU=vU,hU=SU,mU=kU,$80=_.Struct({canvasName:_.String,nodeId:_.String,tasks:xU,requests:vU,messages:kU,artifacts:SU,board:XI,pad:_.optionalKey(K_)});var _W0=_.Struct({brief:_.String,reason:_.optionalKey(_.String),metadata:_.optionalKey(N4),dependsOn:_.optionalKey(_.Array(_.String)),finishCriteria:_.optionalKey(p9)}).pipe(_.check(_.makeFilter((X)=>{let Y=X.metadata?.details;return typeof Y==="string"&&Y.trim().length>0||"description (metadata.details) must be non-empty"}))).annotate({parseOptions:{onExcessProperty:"error"}}),GW0=_.Struct({title:_.String,body:_.optionalKey(_.String),notify:_.optionalKey(_.Boolean)}).annotate({parseOptions:{onExcessProperty:"error"}}),ZW0=_.Struct({topicId:_.String,text:_.String}).annotate({parseOptions:{onExcessProperty:"error"}});var $I=_.String,QI=_.Literals(["top","right","bottom","left"]),JI=_.Literals(["none","arrow"]),_80=_.Literals(["blocks","relates"]);var fU=_.Literals(["blocker","parked","attention"]);var G80=_.Literals(["detach","kill-pane"]),Z80=_.Struct({host:_.String,session:_.optionalKey(_.NullOr(_.String)),workspaceId:_.optionalKey(_.String),tabId:_.optionalKey(_.String),paneId:_.optionalKey(_.String),terminalId:_.optionalKey(_.String),label:_.optionalKey(_.String),onDelete:_.optionalKey(G80)});var K80=_.Literals(["detach","kill-session"]),H80=_.Literals(["shell","command","harness"]),W80=_.Struct({kind:H80,argv:_.optionalKey(_.Array(_.String)),cwd:_.optionalKey(_.String),env:_.optionalKey(_.Record(_.String,_.String))}),U80=_.Struct({bindingId:_.String,label:_.optionalKey(_.String),onDelete:_.optionalKey(K80),launch:_.optionalKey(W80),harness:_.optionalKey(qU),sessionId:_.optionalKey(_.String)});var D80=_.Literals(["detach","kill-session"]),N80=_.Struct({profile:_.String,onDelete:_.optionalKey(D80)});var V80=_.Struct({kind:_.String,name:_.optionalKey(_.String)}),_I=_.String.pipe(_.check(_.isMinLength(1)),_.check(_.isMaxLength(64)),_.check(_.isPattern(/^(?!-)[A-Za-z0-9][A-Za-z0-9._-]*$/))),B80=_.Struct({host:_.String,session:_.optionalKey(_.NullOr(_.String)),workspaceId:_.optionalKey(_.String),tabId:_.optionalKey(_.String)}),z80=_.Struct({url:_.optionalKey(_.String),profile:_.optionalKey(_.String),host:_.optionalKey(_I)}),q80=_.Record(_.String,_.String),O80=_.Struct({herdr:_.optionalKey(B80),page:_.optionalKey(z80),paths:_.optionalKey(q80)}),L80=_.Struct({claims:_.optionalKey(_.Array(G_)),rulings:_.optionalKey(_.Array(jU))}),T80=_.Struct({hold:_.optionalKey(_.Boolean),instruction:_.optionalKey(_.String),defaults:_.optionalKey(O80),contract:_.optionalKey(L80)}),F80=_.Literal("stat_threshold"),R80=_.Struct({kind:F80,source:_.optionalKey(_.Literal("hermes")),key:_.optionalKey(_.String),stat:_.optionalKey(_.String),op:_.optionalKey(_.Literals(["gt","lt","eq"])),value:_.optionalKey(_.Number),flagOnUnsatisfied:_.optionalKey(_.Boolean)}),A80=_.Struct({everyMinutes:_.optionalKey(_.Number),expression:_.optionalKey(_.String)}),P80=_.Literals(["input","output","trigger","recipient"]),GI=_.Struct({word:_.Literal("completes"),equals:_.optionalKey(_.String),itemId:_.optionalKey(_.String)}),ZI=_.Struct({word:_.Literal("flagged"),flag:fU}),E80=_.Union([GI,ZI]),C80=_.Struct({word:_.Literal("any"),any:_.Array(E80).pipe(_.check(_.isMinLength(1)))}),w80=_.Union([GI,ZI,C80]),M80=_.Struct({mode:_.Literal("enqueue_task"),data:_.Unknown}),j80=_.Struct({mode:_.Literal("board_create_topic"),data:_.Unknown}),I80=_.Struct({mode:_.Literal("board_post"),data:_.Unknown}),x80=_.Struct({mode:_.Literal("set_flag"),flag:fU,enabled:_.Union([_.Boolean,_.Literal("mirror")])}),v80=_.Struct({mode:_.Literal("inject_prompt"),text:_.optionalKey(_.String)}),S80=_.Union([M80,j80,I80,x80,v80]),k80=_.Struct({mode:_.Literal("tasks"),itemIds:_.optionalKey(_.Array(_.String))}),b80=k80,g80=_.Struct({entity:_.optionalKey(V80),flags:_.optionalKey(_.Array(fU)),region:_.optionalKey(T80),watch:_.optionalKey(R80),timer:_.optionalKey(A80),tasks:_.optionalKey(gU),requests:_.optionalKey(yU),artifacts:_.optionalKey(hU),messages:_.optionalKey(mU),board:_.optionalKey(bU),pad:_.optionalKey(K_),herdr:_.optionalKey(Z80),terminal:_.optionalKey(U80),browser:_.optionalKey(N80),host:_.optionalKey(_I)}),y80=_.Struct({source:_.String,destination:_.String}),h80=_.Struct({ports:_.optionalKey(_.Array(OU)),stops:_.optionalKey(b80),wake:_.optionalKey(_.Boolean),slot:_.optionalKey(P80),when:_.optionalKey(w80),does:_.optionalKey(S80),flow:_.optionalKey(y80),kind:_.optionalKey(_80)});var H_={id:_.String,x:_.Number,y:_.Number,width:_.Number,height:_.Number,color:_.optionalKey($I),ether:_.optionalKey(g80)},m80=_.Struct({type:_.Literal("text"),text:_.String,...H_}),f80=_.Struct({type:_.Literal("file"),file:_.String,subpath:_.optionalKey(_.String),...H_}),p80=_.Struct({type:_.Literal("link"),url:_.String,...H_}),d80=_.Struct({type:_.Literal("group"),label:_.optionalKey(_.String),background:_.optionalKey(_.String),backgroundStyle:_.optionalKey(_.Literals(["cover","ratio","repeat"])),...H_}),u80=_.Union([m80,f80,p80,d80]),c80=_.Struct({id:_.String,fromNode:_.String,fromSide:_.optionalKey(QI),fromEnd:_.optionalKey(JI),toNode:_.String,toSide:_.optionalKey(QI),toEnd:_.optionalKey(JI),color:_.optionalKey($I),label:_.optionalKey(_.String),ether:_.optionalKey(h80)}),KI=_.Struct({nodes:_.Array(u80),edges:_.Array(c80)}),zW0=_.decodeUnknownResult(KI,{onExcessProperty:"error"}),qW0=_.encodeResult(KI);var B4={onExcessProperty:"error"},T8=_.Number.pipe(_.check(_.makeFilter(Number.isFinite,{message:"must be a finite number"}))),T5=T8.pipe(_.check(_.isGreaterThan(0))),V7=_.Number.pipe(_.check(_.isInt())),V4=_.String.pipe(_.check(_.isMinLength(1))),$6=V4.pipe(_.check(_.isMaxLength(256)),_.brand("PadElementId"));var l80=V4.pipe(_.check(_.isMaxLength(256)),_.brand("PadPostId"));var o80=_.Literals(["box","ellipse","triangle","label"]),i80=_.Literals(["none","active","done","blocked"]),HI=_.Literals(["top","right","bottom","left"]),AW0=_.Literals(["image","shape","edge","ink","pin"]),r80=_.Struct({x:T8,y:T8}),n80=_.Struct({w:T5,h:T5}),pU=_.Struct({id:$6,type:o80,x:T8,y:T8,w:T5,h:T5,z:V7,fill:_.optionalKey(V4),stroke:_.optionalKey(V4),text:_.optionalKey(V4),status:_.optionalKey(i80)}),dU=_.Struct({id:$6,from:$6,to:$6,fromSide:_.optionalKey(HI),toSide:_.optionalKey(HI),label:_.optionalKey(V4)}),uU=_.Struct({id:$6,x:T8,y:T8,w:T5,h:T5,z:V7,ref:OX}),cU=_.Struct({id:$6,z:V7,color:V4,width:T5,points:_.Array(r80).pipe(_.check(_.isMinLength(2)))}),lU=_.Struct({postId:l80,author:kX,parts:_.Array(O5).pipe(_.check(_.isMinLength(1)))}),WI=_.Struct({id:$6,x:T8,y:T8,bounds:_.optionalKey(n80),mentions:_.Array(V4)}),UI=_.Struct({...WI.fields,posts:_.Array(lU)}),s80=(X)=>[...X.images.map((Y)=>Y.id),...X.shapes.map((Y)=>Y.id),...X.edges.map((Y)=>Y.id),...X.inks.map((Y)=>Y.id),...X.pins.map((Y)=>Y.id)],a80=(X)=>{let Y=s80(X);if(new Set(Y).size!==Y.length)return"ids must be unique within the pad";let Q=new Set(X.shapes.map((J)=>J.id));for(let J of X.edges)if(!Q.has(J.from)||!Q.has(J.to))return"edge endpoints must exist";for(let J of X.pins){let $=J.posts.map((G)=>G.postId);if(new Set($).size!==$.length)return"post ids must be unique on a pin";if(J.posts.some((G)=>t80(G.parts)))return"bytes never live in pad JSON"}return!0},t80=(X)=>X.some((Y)=>Y.kind==="raw"),e80=_.Struct({revision:V7.pipe(_.check(_.isGreaterThanOrEqualTo(0))),images:_.Array(uU),shapes:_.Array(pU),edges:_.Array(dU),inks:_.Array(cU),pins:_.Array(UI)}).pipe(_.check(_.makeFilter(a80))),X40=_.Struct({op:_.Literal("upsert"),layer:_.Literal("shape"),shape:pU}),Y40=_.Struct({op:_.Literal("upsert"),layer:_.Literal("edge"),edge:dU}),Q40=_.Struct({op:_.Literal("upsert"),layer:_.Literal("image"),image:uU}),J40=_.Struct({op:_.Literal("upsert"),layer:_.Literal("ink"),ink:cU}),$40=_.Struct({op:_.Literal("pin.upsert"),pin:WI}),_40=_.Struct({op:_.Literal("pin.reply"),pinId:$6,post:lU}),G40=_.Struct({op:_.Literal("delete"),id:$6}),Z40=_.Struct({op:_.Literal("z"),id:$6,z:V7}),u9=_.Union([X40,Y40,Q40,J40,$40,_40,G40,Z40]),K40=_.Literals(["invalid","duplicate_id","zero_size","dangling_edge","empty_ink","layer_mismatch","missing"]);class H40 extends _.TaggedErrorClass()("PadError",{code:K40,message:_.String,id:_.optionalKey($6)}){}var PW0=_.decodeUnknownResult(e80,B4),EW0=_.decodeUnknownResult(u9,B4),CW0=_.decodeUnknownResult(pU,B4),wW0=_.decodeUnknownResult(dU,B4),MW0=_.decodeUnknownResult(uU,B4),jW0=_.decodeUnknownResult(cU,B4),IW0=_.decodeUnknownResult(UI,B4),xW0=_.decodeUnknownResult(lU,B4);var oU=_.Literals(["ping","doctor","capabilities","onboard","preamble","tasks.list","tasks.create","tasks.claim","tasks.update","tasks.show","tasks.claims","tasks.board","rulings","content.path","content.stat","content.materialize","msg.list","msg.send","msg.read","msg.reply","msg.react","request.escalate","artifact.publish","board.list","board.create_topic","board.post","board.mark_read","board.tags","pad.read","pad.patch","relay.trigger"]),W40=_.Literals(["ScopeError","ClaimConflict","UnknownTarget","StaleNodeRef","InvalidTransition","RuntimeDown","AuthError","InputError","ProtocolError","InternalError","Paused","Blocked"]),U40=_.Struct({path:_.optionalKey(_.String),expected:_.optionalKey(_.Unknown),received:_.optionalKey(_.Unknown),hint:_.optionalKey(_.String),next_step:_.optionalKey(_.String),retryable:_.optionalKey(_.Boolean),from:_.optionalKey(_.String),to:_.optionalKey(_.String),holder:_.optionalKey(_.String),target:_.optionalKey(_.String),caller:_.optionalKey(_.String),missing:_.optionalKey(_.String),requestId:_.optionalKey(_.String),stop_directive:_.optionalKey(_.Unknown)}),D40=_.Struct({type:W40,message:_.String,details:_.optionalKey(U40)}),N40=_.Struct({token:_.String,op:oU,args:_.optionalKey(_.Unknown),id:_.optionalKey(_.String)}),V40=_.Struct({ok:_.Literal(!0),op:oU,data:_.Unknown,id:_.optionalKey(_.String),protocol_version:_.optionalKey(_.String)}),B40=_.Struct({ok:_.Literal(!1),op:_.optionalKey(oU),error:D40,id:_.optionalKey(_.String),protocol_version:_.optionalKey(_.String)}),z40=_.Union([V40,B40]),hW0=_.decodeUnknownResult(N40,{onExcessProperty:"error"}),mW0=_.decodeUnknownResult(z40,{onExcessProperty:"error"});var DI=_.Struct({target:_.String}),NI=_.Struct({target:_.String,brief:_.String,reason:_.optionalKey(_.String),metadata:_.optionalKey(N4),media:_.optionalKey(_.Array(_.Union([__,O8]))),dependsOn:_.optionalKey(_.Array(_.String)),finishCriteria:_.optionalKey(p9),claims:_.optionalKey(_.Array(Z_))}).pipe(_.check(_.makeFilter((X)=>{let Y=X.metadata?.details;return typeof Y==="string"&&Y.trim().length>0||"description (metadata.details) must be non-empty"}))).annotate({parseOptions:{onExcessProperty:"error"}}),VI=_.Struct({target:_.String,task:_.String}).annotate({parseOptions:{onExcessProperty:"error"}}),q40=_.Struct({summary:_.String.pipe(_.check(_.isMinLength(1))),refs:_.optionalKey(_.Array(_.String)),target:_.optionalKey(_.String.pipe(_.check(_.isMinLength(1))))}),BI={target:_.String,task:_.String,state:f9,note:_.optionalKey(_.String),completionEvidence:_.optionalKey(d9),next:_.optionalKey(_.String),defect:_.optionalKey(q40)},O40=7776000000,L40=_.optionalKey(_.Number.pipe(_.check(_.isGreaterThanOrEqualTo(0)),_.check(_.isLessThanOrEqualTo(O40)))),fW0=_.Struct({...BI,holdForMs:L40}).pipe(_.check(_.makeFilter(({state:X,completionEvidence:Y})=>Y===void 0||X==="completed"||"completionEvidence is only allowed when state is completed")),_.check(_.makeFilter(({state:X,next:Y})=>Y===void 0||X==="completed"||"next is only allowed when state is completed")),_.check(_.makeFilter(({state:X,holdForMs:Y})=>Y===void 0||X==="completed"||"holdForMs is only allowed when state is completed")),_.check(_.makeFilter(({state:X,defect:Y})=>Y===void 0||X==="rejected"||"defect is only allowed when state is rejected"))).annotate({parseOptions:{onExcessProperty:"error"}}),zI=_.Struct({...BI,holdFor:_.optionalKey(_.Union([_.String,_.Number]))}).pipe(_.check(_.makeFilter(({state:X,completionEvidence:Y})=>Y===void 0||X==="completed"||"completionEvidence is only allowed when state is completed")),_.check(_.makeFilter(({state:X,next:Y})=>Y===void 0||X==="completed"||"next is only allowed when state is completed")),_.check(_.makeFilter(({state:X,holdFor:Y})=>Y===void 0||X==="completed"||"holdFor is only allowed when state is completed")),_.check(_.makeFilter(({state:X,defect:Y})=>Y===void 0||X==="rejected"||"defect is only allowed when state is rejected"))).annotate({parseOptions:{onExcessProperty:"error"}}),qI=_.Struct({target:_.String,task:_.String}).annotate({parseOptions:{onExcessProperty:"error"}}),OI=_.Struct({target:_.String,task:_.optionalKey(_.String)}).annotate({parseOptions:{onExcessProperty:"error"}}),pW0=_.Struct({target:_.String,task:_.String,next:_.optionalKey(_.String),results:_.Array(_.Struct({checkId:_.String.pipe(_.check(_.isMinLength(1))),side:_.Literals(["outbound","inbound"]),exitCode:_.Number,outputTail:_.String}))}).annotate({parseOptions:{onExcessProperty:"error"}}),LI=_.Struct({target:_.String,task:_.String,next:_.optionalKey(_.String)}).annotate({parseOptions:{onExcessProperty:"error"}}),TI=_.Struct({target:_.optionalKey(_.String)}).annotate({parseOptions:{onExcessProperty:"error"}}),T40=OX.annotate({parseOptions:{onExcessProperty:"error"}}),iU={target:_.String.pipe(_.check(_.isMinLength(1))),task:_.String.pipe(_.check(_.isMinLength(1))),ref:T40},FI=_.Struct(iU).annotate({parseOptions:{onExcessProperty:"error"}}),RI=_.Struct(iU).annotate({parseOptions:{onExcessProperty:"error"}}),AI=_.Struct({...iU,name:_.optionalKey(_.String)}).annotate({parseOptions:{onExcessProperty:"error"}}),PI=_.Struct({target:_.optionalKey(_.String),taskId:_.optionalKey(_.String)}),EI=_.Struct({target:_.String,text:_.String,taskId:_.optionalKey(_.String)}),CI=_.Struct({target:_.optionalKey(_.String),messageId:_.String}),wI=_.Struct({target:_.optionalKey(_.String),messageId:_.String,reaction:_.optionalKey(_.Literals(["ack"]))}),MI=_.Struct({target:_.String,text:_.String,inReplyTo:_.String}),jI=_.Struct({text:_.String}).annotate({parseOptions:{onExcessProperty:"error"}}),II=_.Struct({target:_.String,brief:_.String,reason:_.optionalKey(_.String),metadata:_.optionalKey(_.Record(_.String,_.Unknown))}).pipe(_.check(_.makeFilter((X)=>{if(!X.brief.trim())return"brief must be non-empty";let Q=typeof X.reason==="string"?X.reason.trim():"",J=X.metadata?.details,$=typeof J==="string"?J.trim():"";if(!Q&&!$)return"request body required: provide reason and/or metadata.details (not title-only)";return!0}))).annotate({parseOptions:{onExcessProperty:"error"}});var F40=_.Union([_.Struct({kind:_.Literal("text"),text:_.String}),_.Struct({kind:_.Literal("url"),url:_.String,mediaType:_.optionalKey(_.String)}),_.Struct({kind:_.Literal("data"),data:_.Unknown}),_.Struct({kind:_.Literal("raw"),bytesBase64:_.String,mediaType:_.optionalKey(_.String)}),O8]),xI=_.Struct({target:_.String,id:_.String}),dW0=_.Struct({target:_.String,name:_.optionalKey(_.String),artifactId:_.optionalKey(_.String),parts:_.Array(F40),task:_.optionalKey(xI),metadata:_.optionalKey(_.Record(_.String,_.Unknown))}),R40=_.Union([_.Struct({kind:_.Literal("text"),text:_.String}),_.Struct({kind:_.Literal("url"),url:_.String,mediaType:_.optionalKey(_.String)}),_.Struct({kind:_.Literal("data"),data:_.Unknown}),_.Struct({kind:_.Literal("raw"),bytesBase64:_.optionalKey(_.String),path:_.optionalKey(_.String),mediaType:_.optionalKey(_.String)}),O8]),vI=_.Struct({target:_.String,name:_.optionalKey(_.String),artifactId:_.optionalKey(_.String),parts:_.Array(R40),task:_.optionalKey(xI),metadata:_.optionalKey(_.Record(_.String,_.Unknown))}),SI=_.Struct({}),kI=_.Struct({target:_.String,topicId:_.optionalKey(_.String)}),uW0=_.Struct({target:_.String,title:_.String,body:_.optionalKey(_.String),notify:_.optionalKey(_.Boolean)}),bI=_.Struct({target:_.String,topicId:_.String,text:_.String,tags:_.optionalKey(_.Array(_.String))}),gI=_.Struct({target:_.String,topicId:_.optionalKey(_.String)}),cW0=_.Struct({target:_.String,topicId:_.String,upToPosition:_.optionalKey(_.Number)}),yI=_.Struct({target:_.String,pinId:_.optionalKey(_.String)}).annotate({parseOptions:{onExcessProperty:"error"}}),hI=_.Struct({target:_.String,patches:_.Array(u9).pipe(_.check(_.isMinLength(1)))}).annotate({parseOptions:{onExcessProperty:"error"}}),W_=_.Struct({target:_.String.pipe(_.check(_.isMinLength(1)))}).annotate({parseOptions:{onExcessProperty:"error"}}),mI=_.Struct({target:_.String.pipe(_.check(_.isMinLength(1))),pinId:_.String.pipe(_.check(_.isMinLength(1)))}).annotate({parseOptions:{onExcessProperty:"error"}}),fI=_.Struct({target:_.String.pipe(_.check(_.isMinLength(1))),id:_.optionalKey(_.String.pipe(_.check(_.isMinLength(1))))}).annotate({parseOptions:{onExcessProperty:"error"}}),lW0=_.Struct({target:_.String}).annotate({parseOptions:{onExcessProperty:"error"}});var v6=5;var pI={command:"tasks claim",args:["tasks","claim",'{"target":"n7","task":"t1"}'],lesson:"Claim only unclaimed tasks; the factory queue decides what is available."};var dI={command:"tasks update",args:["tasks","update",'{"target":"n7","task":"t1","state":"completed","note":"done","completionEvidence":{"artifacts":[{"artifactId":"a1","nodeId":"art1"}],"git":{"commits":["abc123"]}}}'],lesson:"completed is a factory verdict, not a self-declaration — attach evidence first, or the server rejects the transition."},uI={command:"escalate",args:["escalate",'{"target":"req1","brief":"need API key for staging","reason":"cannot continue without operator secret"}'],lesson:"Escalating blocks the seat and returns a stop directive — stop work ops until the operator answers."};var C0=["inline-json","@file","stdin"],cI={command_id:"tasks.list",command:"tasks list",schema_id:"tasks.list.input/v1",description:"List tasks on a connected task node.",schema:DI,input_modes:C0},lI={command_id:"tasks.claim",command:"tasks claim",schema_id:"tasks.claim.input/v1",description:"Claim a task (submitted → working).",schema:VI,accepts_batch:!0,input_modes:C0},U_={command_id:"tasks.create",command:"tasks create",schema_id:"tasks.create.input/v2",description:"Create a proposal on a connected task node for operator review. Same authoring fields as executable tasks (brief, required metadata.details description, reason, media, dependsOn, finishCriteria); approval mints a submitted Task.",schema:NI,accepts_batch:!0,input_modes:C0},oI={command_id:"tasks.update",command:"tasks update",schema_id:"tasks.update.input/v4",description:`Transition a task to a new task state. On completed, completionEvidence supplies artifacts + git commits for finish-criteria gates and responses + claimWaivers for the station's claims; next names the forward destination and holdFor ("7d", "12h", or ms) bakes the arrival. On rejected, defect sends the task back to a visited station: defect.target picks any stop the journey already made (receipts earned strictly before it stay live), omitted means the previous station.`,schema:zI,accepts_batch:!0,input_modes:C0},iI={command_id:"tasks.show",command:"tasks show",schema_id:"tasks.show.input/v1",description:"Show one task with its journey. Prior stations appear as what they published (emission note + cited refs), never their interiors.",schema:qI,input_modes:C0},rI={command_id:"tasks.claims",command:"tasks claims",schema_id:"tasks.claims.input/v1",description:"Effective claims at a station (region stack, sink contract, station-addressed task claims) with provenance. Name a task to also get readiness: unanswered claims and per-destination ticket status.",schema:OI,input_modes:C0},nI={command_id:"tasks.board",command:"tasks board",schema_id:"tasks.board.input/v1",description:"Run this move's boarding checks (station outbound + chosen destination inbound) in the seat's own environment and submit what happened; the work service stamps tickets from these results. Name next when the station forks.",schema:LI,input_modes:C0},sI={command_id:"rulings",command:"rulings",schema_id:"rulings.input/v1",description:"Operator-pinned rulings across a region stack, outer to inner. No target: this seat's own stack.",schema:TI,input_modes:C0},aI={command_id:"msg.list",command:"msg list",schema_id:"msg.list.input/v1",description:"List this seat's inbox (no target) or a connected mailbox. Own-inbox list marks listed inbound mail read and includes sent mail with readAt.",schema:PI,input_modes:C0},tI={command_id:"msg.send",command:"msg send",schema_id:"msg.send.input/v1",description:"Append a message to a connected node.",schema:EI,accepts_batch:!0,input_modes:C0},eI={command_id:"msg.read",command:"msg read",schema_id:"msg.read.input/v1",description:"Mark one mailbox message read (own seat only). Own `msg list` already does this for every listed item.",schema:CI,accepts_batch:!0,input_modes:C0},Xx={command_id:"msg.reply",command:"msg reply",schema_id:"msg.reply.input/v1",description:"Reply to factory mail: send text to target and mark inReplyTo read on own mailbox.",schema:MI,accepts_batch:!0,input_modes:C0},Yx={command_id:"msg.react",command:"msg react",schema_id:"msg.react.input/v1",description:"Acknowledge own-inbox mail without a reply (reaction defaults to ack).",schema:wI,accepts_batch:!0,input_modes:C0},Qx={command_id:"preamble",command:"preamble",schema_id:"preamble.input/v1",description:"Show a short-lived thought bubble above this agent node.",schema:jI,input_modes:C0},Jx={command_id:"request.escalate",command:"escalate",schema_id:"request.escalate.input/v1",description:"Escalate to the operator: create a request, block this seat, return a stop directive. Subsequent work ops return Blocked until the request is answered.",schema:II,input_modes:C0},$x={command_id:"artifact.publish",command:"artifact publish",schema_id:"artifact.publish.input/v2",description:"Publish an artifact; raw parts may use path and optional task provenance names the exact task sink and id.",schema:vI,accepts_batch:!0,input_modes:C0},_x={command_id:"content.path",command:"content path",schema_id:"content.path.input/v1",description:"Resolve an authorized task ContentRef to its verified canonical local path.",schema:FI,input_modes:C0},Gx={command_id:"content.stat",command:"content stat",schema_id:"content.stat.input/v1",description:"Read availability, identity, metadata, and local path for an authorized task ContentRef.",schema:RI,input_modes:C0},Zx={command_id:"content.materialize",command:"content materialize",schema_id:"content.materialize.input/v1",description:"Stream an authorized task ContentRef into a stable Vellum Command task-scoped workspace path.",schema:AI,input_modes:C0},A40={command_id:"board.list",command:"board list",schema_id:"board.list.input/v1",description:"List topics/posts on a connected board plus metadata of connected actors.",schema:kI,input_modes:C0},P40={command_id:"board.post",command:"board post",schema_id:"board.post.input/v1",description:"Post under a topic; optional tags (actor node ids) soft-notify tagged seats.",schema:bI,accepts_batch:!0,input_modes:C0},E40={command_id:"board.tags",command:"board tags",schema_id:"board.tags.input/v1",description:"List posts on a connected board that tag this process-bound seat.",schema:gI,input_modes:C0},Kx={command_id:"pad.read",command:"pad read",schema_id:"pad.read.input/v1",description:"Read a connected pad (grant pad.read): revision, IR, digest, SVG. Optional pinId adds look-here. Agents never write the factory canvas.",schema:yI,input_modes:C0},Hx={command_id:"pad.patch",command:"pad patch",schema_id:"pad.patch.input/v1",description:"Apply PadPatch on a connected pad (grant pad.patch). Agents may upsert shapes, edges, and pin posts. Agent ink or image upserts are refused. Mentions must be inbound actor node ids.",schema:hI,accepts_batch:!0,input_modes:C0},Wx={command_id:"pad.digest",command:"pad digest",schema_id:"pad.digest.input/v1",description:"Text IR of a connected pad (grant pad.read). Working copy for a wired seat — not the factory canvas.",schema:W_,input_modes:C0},Ux={command_id:"pad.svg",command:"pad svg",schema_id:"pad.svg.input/v1",description:"SVG picture of a connected pad (grant pad.read). Agents read the page; they never write the factory canvas.",schema:W_,input_modes:C0},Dx={command_id:"pad.look-here",command:"pad look-here",schema_id:"pad.look-here.input/v1",description:"Crop around a pin on a connected pad (grant pad.read). pinId required. Mentions are inbound wired actors — @ cannot name an unwired agent.",schema:mI,input_modes:C0},Nx={command_id:"pad.get",command:"pad get",schema_id:"pad.get.input/v1",description:"Compact focused items from a connected pad (grant pad.read). Optional id returns that item. Agents never write the factory canvas.",schema:fI,input_modes:C0},Vx={command_id:"pad.tagged",command:"pad tagged",schema_id:"pad.tagged.input/v1",description:"Pins that mention this process-bound seat (grant pad.read). Mention universe is inbound actor edges; unwired names are refused on pad.patch.",schema:W_,input_modes:C0},F5=(X,Y,Q,J)=>({command_id:`browser.${X}`,command:`browser ${Y}`,schema_id:`browser.${X}.input/v1`,description:Q,schema:J,input_modes:["positional"]}),Bx=F5("pages","pages","List page nodes admitted by the caller's live browser.automate edges.",SI),zx=F5("open","open <vellum-ref>","Open or reuse a granted page session.",Bj),qx=F5("goto","goto <sessionId> <url>","Navigate an admitted browser session.",zj),Ox=F5("eval","eval <sessionId> <code>","Evaluate JavaScript in an admitted browser session.",qj),Lx=F5("screenshot","shot <sessionId>","Capture a server-owned PNG from an admitted browser session.",Oj),Tx=F5("close","close <sessionId>","Detach a browser surface while keeping its session warm.",Lj),Fx=F5("stop","stop <sessionId>","Destroy an admitted browser session.",Tj),XU0=[cI,U_,lI,oI,iI,rI,nI,sI,aI,tI,eI,Xx,Yx,Qx,Jx,$x,_x,Gx,Zx,A40,P40,E40,Kx,Hx,Wx,Ux,Dx,Nx,Vx,...Q_?[Bx,zx,qx,Ox,Lx,Tx,Fx]:[]],I0=[{command_id:"tasks.create",command:"tasks create",name:"propose work",description:"Create an attributed proposal for operator review.",input:{target:"n7",brief:"Add keyboard navigation",metadata:{title:"Keyboard navigation",details:"Cover the task board first."}},args:["tasks","create",'{"target":"n7","brief":"Add keyboard navigation","metadata":{"title":"Keyboard navigation","details":"Cover the task board first."}}']},{command_id:"tasks.create",command:"tasks create",name:"propose with deps and finish criteria",description:"Same authoring contract as task create: dependsOn + finishCriteria carry onto the minted Task on approve.",input:{target:"n7",brief:"Ship media migration graph",reason:"needs prior content-ref work complete",dependsOn:["t_prereq"],finishCriteria:{description:"graph claimable and media uses ContentRef",git:{minCommits:1}},metadata:{title:"Media migration graph",details:"Wire ContentRef media and make the graph claimable."}},args:["tasks","create",'{"target":"n7","brief":"Ship media migration graph","reason":"needs prior content-ref work complete","dependsOn":["t_prereq"],"finishCriteria":{"description":"graph claimable and media uses ContentRef","git":{"minCommits":1}},"metadata":{"title":"Media migration graph","details":"Wire ContentRef media and make the graph claimable."}}']},{command_id:"tasks.claim",command:"tasks claim",name:"claim one",description:"Claim task t1 on target node n7.",args:pI.args,input:{target:"n7",task:"t1"}},{command_id:"tasks.claim",command:"tasks claim",name:"batch claim",description:"Claim several tasks with bounded concurrency.",args:["tasks","claim","@claims.json","--concurrency","5"],input:[{target:"n7",task:"t1"},{target:"n7",task:"t2"}]},{command_id:"tasks.update",command:"tasks update",name:"complete",input:{target:"n7",task:"t1",state:"completed",note:"done"},args:["tasks","update",'{"target":"n7","task":"t1","state":"completed","note":"done"}']},{command_id:"tasks.update",command:"tasks update",name:"complete with evidence",input:{target:"n7",task:"t1",state:"completed",note:"done",completionEvidence:{artifacts:[{artifactId:"a1",nodeId:"art1"}],git:{commits:["abc123"]}}},args:dI.args},{command_id:"tasks.update",command:"tasks update",name:"answer claims and forward",description:"Complete at this station with a response per claim, then forward to the named destination.",input:{target:"n7",task:"t1",state:"completed",note:"review passed",completionEvidence:{artifacts:[],responses:[{claimId:"c1",response:"ran the suite; all green",refs:["abc123"]}],claimWaivers:[{claimId:"c2",reason:"no schema changed in this task"}]},next:"n8",holdFor:"12h"},args:["tasks","update",'{"target":"n7","task":"t1","state":"completed","note":"review passed","completionEvidence":{"artifacts":[],"responses":[{"claimId":"c1","response":"ran the suite; all green","refs":["abc123"]}],"claimWaivers":[{"claimId":"c2","reason":"no schema changed in this task"}]},"next":"n8","holdFor":"12h"}']},{command_id:"tasks.update",command:"tasks update",name:"send back with a defect",description:"Return the task to the previous station with the reason on record.",input:{target:"n7",task:"t1",state:"rejected",defect:{summary:"the brief names an endpoint that does not exist",refs:["abc123"]}},args:["tasks","update",'{"target":"n7","task":"t1","state":"rejected","defect":{"summary":"the brief names an endpoint that does not exist","refs":["abc123"]}}']},{command_id:"tasks.show",command:"tasks show",name:"show",input:{target:"n7",task:"t1"},args:["tasks","show",'{"target":"n7","task":"t1"}']},{command_id:"tasks.claims",command:"tasks claims",name:"station law",description:"The standing claims at this station, with provenance.",input:{target:"n7"},args:["tasks","claims",'{"target":"n7"}']},{command_id:"tasks.claims",command:"tasks claims",name:"readiness for a task",description:"What is still unanswered, and which boarding tickets are green.",input:{target:"n7",task:"t1"},args:["tasks","claims",'{"target":"n7","task":"t1"}']},{command_id:"tasks.board",command:"tasks board",name:"run boarding checks",description:"Resolve and run the applicable checklists locally, then submit results; tickets are stamped from what the checks returned.",input:{target:"n7",task:"t1"},args:["tasks","board",'{"target":"n7","task":"t1"}']},{command_id:"tasks.board",command:"tasks board",name:"run boarding checks toward a destination",description:"Name the destination when the station forks; its inbound checklist joins the station's outbound checks.",input:{target:"n7",task:"t1",next:"n8"},args:["tasks","board",'{"target":"n7","task":"t1","next":"n8"}']},{command_id:"rulings",command:"rulings",name:"own region stack",input:{},args:["rulings"]},{command_id:"msg.send",command:"msg send",name:"note on task",input:{target:"n7",text:"working",taskId:"t1"},args:["msg","send",'{"target":"n7","text":"working","taskId":"t1"}']},{command_id:"msg.read",command:"msg read",name:"ack mailbox",input:{target:"seat-a",messageId:"msg_01"},args:["msg","read",'{"target":"seat-a","messageId":"msg_01"}']},{command_id:"msg.reply",command:"msg reply",name:"reply to mail",input:{target:"seat-b",text:"ack, starting",inReplyTo:"msg_01"},args:["msg","reply",'{"target":"seat-b","text":"ack, starting","inReplyTo":"msg_01"}']},{command_id:"msg.list",command:"msg list",name:"open own inbox",input:{},args:["msg","list"]},{command_id:"msg.react",command:"msg react",name:"ack without reply",input:{messageId:"msg_01"},args:["msg","react",'{"messageId":"msg_01"}']},{command_id:"preamble",command:"preamble",name:"share a brief thought",description:"Show a sentence above this agent node for about 30 seconds.",input:{text:"Inspecting the task and choosing the smallest safe change."},args:["preamble",'{"text":"Inspecting the task and choosing the smallest safe change."}']},{command_id:"request.escalate",command:"escalate",name:"block until answer",description:"File a request and block this seat. Server returns stop_directive; further work ops return Blocked.",input:{target:"req1",brief:"need API key for staging",reason:"cannot continue without operator secret"},args:uI.args},{command_id:"artifact.publish",command:"artifact publish",name:"publish file",input:{target:"art1",name:"report",parts:[{kind:"raw",path:"/abs/x.png"}],task:{target:"tasks",id:"t1"}},args:["artifact","publish",'{"target":"art1","name":"report","parts":[{"kind":"raw","path":"/abs/x.png"}],"task":{"target":"tasks","id":"t1"}}']},{command_id:"tasks.list",command:"tasks list",name:"list",input:{target:"n7"},args:["tasks","list",'{"target":"n7"}']},{command_id:"content.path",command:"content path",name:"resolve task content",description:"Resolve a ContentRef carried by task t1 on target n7.",input:{target:"n7",task:"t1",ref:{sha256:"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",byteLength:12,mediaType:"application/octet-stream"}},args:["content","path",'{"target":"n7","task":"t1","ref":{"sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","byteLength":12,"mediaType":"application/octet-stream"}}']},{command_id:"content.stat",command:"content stat",name:"inspect task content",input:{target:"n7",task:"t1",ref:{sha256:"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",byteLength:12,mediaType:"application/octet-stream"}},args:["content","stat",'{"target":"n7","task":"t1","ref":{"sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","byteLength":12,"mediaType":"application/octet-stream"}}']},{command_id:"content.materialize",command:"content materialize",name:"materialize task content",input:{target:"n7",task:"t1",name:"record.bin",ref:{sha256:"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",byteLength:12,mediaType:"application/octet-stream"}},args:["content","materialize",'{"target":"n7","task":"t1","name":"record.bin","ref":{"sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","byteLength":12,"mediaType":"application/octet-stream"}}']},{command_id:"pad.read",command:"pad read",name:"read pad",description:"Read revision, IR, digest, and SVG on a wired pad.",input:{target:"pad-1"},args:["pad","read",'{"target":"pad-1"}']},{command_id:"pad.read",command:"pad read",name:"read with look-here",description:"Read the pad and crop around pin-1.",input:{target:"pad-1",pinId:"pin-1"},args:["pad","read",'{"target":"pad-1","pinId":"pin-1"}']},{command_id:"pad.patch",command:"pad patch",name:"upsert box",description:"Upsert a named box. Agent ink/image upserts are refused; mentions must be inbound actors.",input:{target:"pad-1",patches:[{op:"upsert",layer:"shape",shape:{id:"box-1",type:"box",x:0,y:0,w:80,h:40,z:0,text:"inbox"}}]},args:["pad","patch",'{"target":"pad-1","patches":[{"op":"upsert","layer":"shape","shape":{"id":"box-1","type":"box","x":0,"y":0,"w":80,"h":40,"z":0,"text":"inbox"}}]}']},{command_id:"pad.patch",command:"pad patch",name:"pin mention",description:"Place a pin that mentions a wired inbound actor. Unwired names are refused.",input:{target:"pad-1",patches:[{op:"pin.upsert",pin:{id:"pin-1",x:16,y:16,mentions:["agent-1"]}}]},args:["pad","patch",'{"target":"pad-1","patches":[{"op":"pin.upsert","pin":{"id":"pin-1","x":16,"y":16,"mentions":["agent-1"]}}]}']},{command_id:"pad.digest",command:"pad digest",name:"text IR",input:{target:"pad-1"},args:["pad","digest",'{"target":"pad-1"}']},{command_id:"pad.svg",command:"pad svg",name:"picture",input:{target:"pad-1"},args:["pad","svg",'{"target":"pad-1"}']},{command_id:"pad.look-here",command:"pad look-here",name:"crop pin",description:"Crop the page around pin-1.",input:{target:"pad-1",pinId:"pin-1"},args:["pad","look-here",'{"target":"pad-1","pinId":"pin-1"}']},{command_id:"pad.get",command:"pad get",name:"focused items",input:{target:"pad-1"},args:["pad","get",'{"target":"pad-1"}']},{command_id:"pad.get",command:"pad get",name:"one item",input:{target:"pad-1",id:"box-1"},args:["pad","get",'{"target":"pad-1","id":"box-1"}']},{command_id:"pad.tagged",command:"pad tagged",name:"pins mentioning this seat",description:"List pins that mention the process-bound seat.",input:{target:"pad-1"},args:["pad","tagged",'{"target":"pad-1"}']},...Q_?[{command_id:"browser.pages",command:"browser pages",name:"list granted pages",args:["browser","pages","--json"],input:{}},{command_id:"browser.open",command:"browser open <vellum-ref>",name:"open a granted page",args:["browser","open","vellum-command://canvas/work?node=page-1","--json"],input:{ref:"vellum-command://canvas/work?node=page-1"}}]:[]],YU0=[{command_id:"ping",command:"ping",category:"diagnostic",description:"Liveness probe against the work control socket."},{command_id:"doctor",command:"doctor",category:"diagnostic",description:"Env socket+token present, perms 0600, protocol version match."},{command_id:"capabilities",command:"capabilities",category:"discovery",description:"Live wiring from the caller's edges as a contract."},{command_id:"onboard",command:"onboard",category:"discovery",description:"Node, region, connected, co-members, capabilities from live state."},{command_id:"schema.list",command:"schema list",category:"discovery",description:"List JSON input schemas."},{command_id:"schema.show",command:"schema show",category:"discovery",description:"Show one JSON input schema."},{command_id:"examples.list",command:"examples list",category:"discovery",description:"List executable examples."},{command_id:"examples.show",command:"examples show",category:"discovery",description:"Show examples for one command."},{command_id:"tasks.list",command:"tasks list",category:"workflow",description:"List tasks on a connected target.",schemas:[cI],examples:I0.filter((X)=>X.command_id==="tasks.list")},{command_id:"tasks.create",command:"tasks create",category:"workflow",description:"Create one or more proposals (batch-capable).",schemas:[U_],examples:I0.filter((X)=>X.command_id==="tasks.create"),batch:{accepts_batch:!0,default_concurrency:v6,supports_concurrency_option:!0}},{command_id:"tasks.claim",command:"tasks claim",category:"workflow",description:"Claim one or more tasks (batch-capable).",schemas:[lI],examples:I0.filter((X)=>X.command_id==="tasks.claim"),batch:{accepts_batch:!0,default_concurrency:v6,supports_concurrency_option:!0}},{command_id:"tasks.update",command:"tasks update",category:"workflow",description:"Update task state (batch-capable).",schemas:[oI],examples:I0.filter((X)=>X.command_id==="tasks.update"),batch:{accepts_batch:!0,default_concurrency:v6,supports_concurrency_option:!0}},{command_id:"tasks.show",command:"tasks show",category:"workflow",description:"Show one task with its journey (onion-scoped for seats).",schemas:[iI],examples:I0.filter((X)=>X.command_id==="tasks.show")},{command_id:"tasks.claims",command:"tasks claims",category:"workflow",description:"Effective claims at a station, plus readiness for a named task.",schemas:[rI],examples:I0.filter((X)=>X.command_id==="tasks.claims")},{command_id:"tasks.board",command:"tasks board",category:"workflow",description:"Run this move's boarding checks in the seat's environment and submit the results; tickets are stamped from what came back.",schemas:[nI],examples:I0.filter((X)=>X.command_id==="tasks.board")},{command_id:"rulings",command:"rulings",category:"workflow",description:"Operator-pinned rulings over a region stack.",schemas:[sI],examples:I0.filter((X)=>X.command_id==="rulings")},{command_id:"msg.list",command:"msg list",category:"workflow",description:"List own inbox (marks listed mail read; includes sent with readAt) or a peer mailbox.",schemas:[aI],examples:I0.filter((X)=>X.command_id==="msg.list")},{command_id:"msg.send",command:"msg send",category:"workflow",description:"Send a message (batch-capable).",schemas:[tI],examples:I0.filter((X)=>X.command_id==="msg.send"),batch:{accepts_batch:!0,default_concurrency:v6,supports_concurrency_option:!0}},{command_id:"msg.read",command:"msg read",category:"workflow",description:"Mark a mailbox message read (own seat; batch-capable).",schemas:[eI],examples:I0.filter((X)=>X.command_id==="msg.read"),batch:{accepts_batch:!0,default_concurrency:v6,supports_concurrency_option:!0}},{command_id:"msg.reply",command:"msg reply",category:"workflow",description:"Reply to factory mail and mark parent read (batch-capable).",schemas:[Xx],examples:I0.filter((X)=>X.command_id==="msg.reply"),batch:{accepts_batch:!0,default_concurrency:v6,supports_concurrency_option:!0}},{command_id:"msg.react",command:"msg react",category:"workflow",description:"Acknowledge own-inbox mail without a reply (batch-capable).",schemas:[Yx],examples:I0.filter((X)=>X.command_id==="msg.react"),batch:{accepts_batch:!0,default_concurrency:v6,supports_concurrency_option:!0}},{command_id:"preamble",command:"preamble",category:"workflow",description:"Show a short-lived thought bubble above this agent node.",schemas:[Qx],examples:I0.filter((X)=>X.command_id==="preamble")},{command_id:"request.escalate",command:"escalate",category:"workflow",description:"Escalate to operator: create request, block seat, return stop directive.",schemas:[Jx],examples:I0.filter((X)=>X.command_id==="request.escalate")},{command_id:"artifact.publish",command:"artifact publish",category:"workflow",description:"Publish an artifact (batch-capable).",schemas:[$x],examples:I0.filter((X)=>X.command_id==="artifact.publish"),batch:{accepts_batch:!0,default_concurrency:v6,supports_concurrency_option:!0}},{command_id:"content.path",command:"content path",category:"workflow",description:"Resolve an authorized task ContentRef to a local path.",schemas:[_x],examples:I0.filter((X)=>X.command_id==="content.path")},{command_id:"content.stat",command:"content stat",category:"workflow",description:"Inspect availability for an authorized task ContentRef.",schemas:[Gx],examples:I0.filter((X)=>X.command_id==="content.stat")},{command_id:"content.materialize",command:"content materialize",category:"workflow",description:"Materialize an authorized task ContentRef into the task workspace.",schemas:[Zx],examples:I0.filter((X)=>X.command_id==="content.materialize")},{command_id:"pad.read",command:"pad read",category:"workflow",description:"Read a connected pad (grant pad.read): revision, IR, digest, SVG.",schemas:[Kx],examples:I0.filter((X)=>X.command_id==="pad.read")},{command_id:"pad.patch",command:"pad patch",category:"workflow",description:"Apply PadPatch (grant pad.patch). Agent ink/image refused; mentions must be inbound actors.",schemas:[Hx],examples:I0.filter((X)=>X.command_id==="pad.patch"),batch:{accepts_batch:!0,default_concurrency:v6,supports_concurrency_option:!0}},{command_id:"pad.digest",command:"pad digest",category:"workflow",description:"Text IR of a connected pad (grant pad.read).",schemas:[Wx],examples:I0.filter((X)=>X.command_id==="pad.digest")},{command_id:"pad.svg",command:"pad svg",category:"workflow",description:"SVG picture of a connected pad (grant pad.read).",schemas:[Ux],examples:I0.filter((X)=>X.command_id==="pad.svg")},{command_id:"pad.look-here",command:"pad look-here",category:"workflow",description:"Crop around a pin (grant pad.read). Mentions are inbound wired actors.",schemas:[Dx],examples:I0.filter((X)=>X.command_id==="pad.look-here")},{command_id:"pad.get",command:"pad get",category:"workflow",description:"Focused items from a connected pad (grant pad.read).",schemas:[Nx],examples:I0.filter((X)=>X.command_id==="pad.get")},{command_id:"pad.tagged",command:"pad tagged",category:"workflow",description:"Pins mentioning this process-bound seat (grant pad.read).",schemas:[Vx],examples:I0.filter((X)=>X.command_id==="pad.tagged")},...Q_?[{command_id:"browser.pages",command:"browser pages",category:"discovery",description:"List page nodes granted through browser.automate edges.",schemas:[Bx],examples:I0.filter((X)=>X.command_id==="browser.pages")},{command_id:"browser.open",command:"browser open",category:"workflow",description:"Open or reuse a granted page session.",schemas:[zx],examples:I0.filter((X)=>X.command_id==="browser.open")},{command_id:"browser.goto",command:"browser goto",category:"workflow",description:"Navigate an admitted browser session.",schemas:[qx]},{command_id:"browser.eval",command:"browser eval",category:"workflow",description:"Evaluate JavaScript in an admitted browser session.",schemas:[Ox]},{command_id:"browser.screenshot",command:"browser shot",category:"workflow",description:"Capture a server-owned page screenshot.",schemas:[Lx]},{command_id:"browser.close",command:"browser close",category:"workflow",description:"Detach a browser surface while keeping its session warm.",schemas:[Tx]},{command_id:"browser.stop",command:"browser stop",category:"workflow",description:"Destroy an admitted browser session.",schemas:[Fx]}]:[]];import{constants as H0}from"node:sqlite";var Rx=`
  CREATE TABLE IF NOT EXISTS browser_profiles (
    id TEXT PRIMARY KEY
      CHECK (
        length(id) BETWEEN 1 AND 63
        AND substr(id, 1, 1) GLOB '[a-z0-9]'
        AND id NOT GLOB '*[^a-z0-9-]*'
      ),
    label TEXT
      CHECK (
        label IS NULL
        OR (
          length(label) > 0
          AND length(CAST(label AS BLOB)) <= 128
        )
      ),
    created_at TEXT NOT NULL CHECK (length(created_at) > 0),
    last_used_at TEXT CHECK (last_used_at IS NULL OR length(last_used_at) > 0),
    sort_order INTEGER NOT NULL UNIQUE CHECK (sort_order >= 0)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS browser_profile_settings (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    version INTEGER NOT NULL CHECK (version = 1),
    default_profile TEXT NOT NULL
      REFERENCES browser_profiles(id) ON DELETE RESTRICT,
    max_warm_sessions INTEGER NOT NULL
      CHECK (max_warm_sessions BETWEEN 1 AND ${G7}),
    max_visible_surfaces INTEGER NOT NULL
      CHECK (max_visible_surfaces BETWEEN 1 AND ${Z7})
  ) STRICT;

  CREATE TABLE IF NOT EXISTS browser_profile_canvas_defaults (
    canvas_name TEXT PRIMARY KEY
      CHECK (
        length(canvas_name) BETWEEN 1 AND 63
        AND substr(canvas_name, 1, 1) GLOB '[a-z0-9]'
        AND canvas_name NOT GLOB '*[^a-z0-9-]*'
      ),
    profile_id TEXT NOT NULL
      REFERENCES browser_profiles(id) ON DELETE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS browser_profile_pending_wipe (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    wipe_id TEXT NOT NULL UNIQUE CHECK (length(wipe_id) = 36),
    profile_id TEXT NOT NULL UNIQUE
      REFERENCES browser_profiles(id) ON DELETE RESTRICT,
    partition TEXT NOT NULL
      CHECK (partition = 'persist:vellum-profile-' || profile_id),
    requested_at TEXT NOT NULL CHECK (length(requested_at) > 0),
    stage TEXT NOT NULL
      CHECK (stage IN ('live_clear_pending', 'restart_delete_pending')),
    storage_path TEXT NOT NULL
      CHECK (length(CAST(storage_path AS BLOB)) BETWEEN 1 AND 4096),
    user_data_path TEXT NOT NULL
      CHECK (length(CAST(user_data_path AS BLOB)) BETWEEN 1 AND 4096),
    session_data_path TEXT NOT NULL
      CHECK (length(CAST(session_data_path AS BLOB)) BETWEEN 1 AND 4096)
  ) STRICT;

  CREATE TRIGGER IF NOT EXISTS browser_profiles_limit
  BEFORE INSERT ON browser_profiles
  WHEN (SELECT count(*) FROM browser_profiles) >= 64
  BEGIN
    SELECT RAISE(ABORT, 'browser profile limit reached');
  END;

  CREATE TRIGGER IF NOT EXISTS browser_profile_canvas_defaults_limit
  BEFORE INSERT ON browser_profile_canvas_defaults
  WHEN (SELECT count(*) FROM browser_profile_canvas_defaults) >= 256
  BEGIN
    SELECT RAISE(ABORT, 'browser canvas-default limit reached');
  END;
`;var Ax=`
  CREATE TABLE IF NOT EXISTS box_resources (
    box_id TEXT PRIMARY KEY
      CHECK (
        length(box_id) = 11
        AND box_id GLOB 'bx_[23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz]'
      ),
    host_id TEXT UNIQUE
      REFERENCES host_registry(id) ON DELETE RESTRICT,
    name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 255),
    machine_ip TEXT,
    machine_state TEXT NOT NULL CHECK (length(machine_state) BETWEEN 1 AND 32),
    provider_created_at TEXT CHECK (
      provider_created_at IS NULL OR length(provider_created_at) > 0
    ),
    provider_updated_at TEXT CHECK (
      provider_updated_at IS NULL OR length(provider_updated_at) > 0
    ),
    ssh_prepared_at TEXT CHECK (
      ssh_prepared_at IS NULL OR length(ssh_prepared_at) > 0
    ),
    ssh_verified_at TEXT CHECK (
      ssh_verified_at IS NULL OR length(ssh_verified_at) > 0
    ),
    enrolled_at TEXT NOT NULL CHECK (length(enrolled_at) > 0)
  ) STRICT;

  CREATE TRIGGER IF NOT EXISTS box_resources_immutable_identity
  BEFORE UPDATE OF box_id ON box_resources
  BEGIN
    SELECT RAISE(ABORT, 'Box ownership identity is immutable');
  END;
`;var D_=`
  CREATE TABLE IF NOT EXISTS canvas_entities (
    canvas_name TEXT NOT NULL
      CHECK (
        length(canvas_name) BETWEEN 1 AND 64
        AND canvas_name GLOB '[a-z0-9]*'
        AND canvas_name NOT GLOB '*[^a-z0-9_-]*'
      ),
    entity_id TEXT NOT NULL
      CHECK (length(entity_id) BETWEEN 1 AND 256),
    kind TEXT
      CHECK (kind IS NULL OR length(kind) BETWEEN 1 AND 128),
    binding_id TEXT
      CHECK (
        binding_id IS NULL
        OR length(binding_id) BETWEEN 1 AND 256
      ),
    lifecycle TEXT NOT NULL
      CHECK (lifecycle IN ('active', 'archived', 'soft_deleted')),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    archived_at TEXT
      CHECK (archived_at IS NULL OR length(archived_at) BETWEEN 1 AND 64),
    soft_deleted_at TEXT
      CHECK (
        soft_deleted_at IS NULL
        OR length(soft_deleted_at) BETWEEN 1 AND 64
      ),
    PRIMARY KEY (canvas_name, entity_id),
    CHECK (
      (lifecycle = 'active' AND archived_at IS NULL AND soft_deleted_at IS NULL)
      OR (
        lifecycle = 'archived'
        AND archived_at IS NOT NULL
        AND soft_deleted_at IS NULL
      )
      OR (
        lifecycle = 'soft_deleted'
        AND archived_at IS NOT NULL
        AND soft_deleted_at IS NOT NULL
      )
    )
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS canvas_entities_lifecycle
    ON canvas_entities(canvas_name, lifecycle, updated_at, entity_id);

  -- Only one *active* entity may hold a binding on a canvas. Archived and
  -- soft_deleted rows retain binding_id for audit without blocking re-bind.
  CREATE UNIQUE INDEX IF NOT EXISTS canvas_entities_canvas_binding
    ON canvas_entities(canvas_name, binding_id)
    WHERE binding_id IS NOT NULL AND lifecycle = 'active';
`;var Px=`
  CREATE TABLE IF NOT EXISTS host_registry (
    id TEXT PRIMARY KEY
      CHECK (
        length(id) BETWEEN 1 AND 64
        AND substr(id, 1, 1) GLOB '[A-Za-z0-9]'
        AND id NOT GLOB '*[^A-Za-z0-9._-]*'
      ),
    label TEXT NOT NULL
      CHECK (length(label) BETWEEN 1 AND 64),
    kind TEXT NOT NULL
      CHECK (kind IN ('local', 'remote')),
    ssh_endpoint TEXT UNIQUE,
    ssh_identity_file TEXT
      CHECK (
        ssh_identity_file IS NULL
        OR (
          length(ssh_identity_file) BETWEEN 1 AND 1024
          AND substr(ssh_identity_file, 1, 1) = '/'
        )
      ),
    ssh_host_key_policy TEXT
      CHECK (
        ssh_host_key_policy IS NULL
        OR ssh_host_key_policy IN ('system', 'accept-new')
      ),
    capability_mask INTEGER,
    hermes_id TEXT
      CHECK (
        hermes_id IS NULL
        OR (
          length(hermes_id) BETWEEN 1 AND 64
          AND substr(hermes_id, 1, 1) GLOB '[A-Za-z0-9]'
          AND hermes_id NOT GLOB '*[^A-Za-z0-9._-]*'
        )
      ),
    effective_hermes_id TEXT UNIQUE,
    appearance_color TEXT,
    appearance_glyph TEXT,
    sort_order INTEGER NOT NULL UNIQUE
      CHECK (sort_order >= 0),
    CHECK (
      (
        kind = 'local'
        AND id = 'local'
        AND ssh_endpoint IS NULL
        AND ssh_identity_file IS NULL
        AND ssh_host_key_policy IS NULL
        AND capability_mask IS NULL
        AND sort_order = 0
      )
      OR
      (
        kind = 'remote'
        AND id <> 'local'
        AND (
          ssh_endpoint IS NULL
          OR length(ssh_endpoint) BETWEEN 1 AND 255
        )
        AND (
          ssh_endpoint IS NOT NULL
          OR (
            ssh_identity_file IS NULL
            AND ssh_host_key_policy IS NULL
          )
        )
        AND capability_mask BETWEEN 1 AND 15
        AND sort_order > 0
      )
    ),
    CHECK (
      (
        (
          kind = 'local'
          OR (capability_mask & 8) <> 0
        )
        AND effective_hermes_id IS NOT NULL
        AND effective_hermes_id = coalesce(hermes_id, id)
      )
      OR
      (
        kind = 'remote'
        AND (capability_mask & 8) = 0
        AND effective_hermes_id IS NULL
      )
    )
  ) STRICT;

  CREATE TABLE IF NOT EXISTS host_registry_state (
    singleton INTEGER PRIMARY KEY
      CHECK (singleton = 1),
    version INTEGER NOT NULL
      CHECK (version = 1),
    initialized_at TEXT NOT NULL
      CHECK (length(initialized_at) > 0)
  ) STRICT;

  CREATE TRIGGER IF NOT EXISTS host_registry_retain_local
  BEFORE DELETE ON host_registry
  WHEN OLD.id = 'local'
  BEGIN
    SELECT RAISE(ABORT, 'the local host is immutable');
  END;
`;var Ex=`
  CREATE TABLE IF NOT EXISTS kernel_armed_regions (
    canvas_name TEXT NOT NULL
      CHECK (
        length(canvas_name) BETWEEN 1 AND 64
        AND canvas_name GLOB '[a-z0-9]*'
        AND canvas_name NOT GLOB '*[^a-z0-9_-]*'
      ),
    region_id TEXT NOT NULL CHECK (length(region_id) BETWEEN 1 AND 1024),
    armed_at TEXT NOT NULL CHECK (length(armed_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, region_id)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS kernel_debug_pulses (
    position INTEGER PRIMARY KEY CHECK (position BETWEEN 0 AND 19),
    id TEXT NOT NULL CHECK (length(id) BETWEEN 1 AND 256),
    at_epoch_ms INTEGER NOT NULL CHECK (at_epoch_ms >= 0),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 64),
    source_node_id TEXT NOT NULL
      CHECK (length(source_node_id) BETWEEN 1 AND 1024),
    region_id TEXT CHECK (
      region_id IS NULL OR length(region_id) BETWEEN 1 AND 1024
    ),
    kind TEXT NOT NULL CHECK (kind IN ('watcher', 'timer', 'manual')),
    summary TEXT NOT NULL CHECK (length(summary) BETWEEN 1 AND 4096),
    delivered_json TEXT NOT NULL
      CHECK (
        json_valid(delivered_json)
        AND json_type(delivered_json) = 'array'
        AND length(CAST(delivered_json AS BLOB)) <= 65536
      ),
    dry INTEGER NOT NULL CHECK (dry IN (0, 1)),
    recorded_at TEXT NOT NULL CHECK (length(recorded_at) BETWEEN 1 AND 64)
  ) STRICT;
`;var Cx=[`
    CREATE TABLE IF NOT EXISTS license_activation (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      record_version INTEGER NOT NULL
        CHECK (record_version = 1),
      activated_license_json TEXT NOT NULL
        CHECK (
          length(CAST(activated_license_json AS BLOB)) BETWEEN 2
            AND 16384
          AND json_valid(activated_license_json)
          AND json_type(activated_license_json) = 'object'
        ),
      updated_at TEXT NOT NULL
        CHECK (length(updated_at) BETWEEN 20 AND 64)
    ) STRICT, WITHOUT ROWID
  `],N_=`${Cx.join(`;
`)};
`,wx=[`
    CREATE TABLE IF NOT EXISTS license_entitlement (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      record_version INTEGER NOT NULL
        CHECK (record_version = 2),
      activated_license_json TEXT NOT NULL
        CHECK (
          length(CAST(activated_license_json AS BLOB)) BETWEEN 2
            AND 16384
          AND json_valid(activated_license_json)
          AND json_type(activated_license_json) = 'object'
        ),
      updated_at TEXT NOT NULL
        CHECK (length(updated_at) BETWEEN 20 AND 64)
    ) STRICT, WITHOUT ROWID
  `],V_=`${wx.join(`;
`)};
`,C40=[...Cx,...wx],HU0=`${C40.join(`;
`)};
`;var Mx=`
  CREATE TABLE IF NOT EXISTS factory_pause_canvases (
    canvas_name TEXT PRIMARY KEY
      CHECK (
        length(canvas_name) BETWEEN 1 AND 64
        AND canvas_name GLOB '[a-z0-9]*'
        AND canvas_name NOT GLOB '*[^a-z0-9_-]*'
      ),
    playing INTEGER NOT NULL CHECK (playing IN (0, 1)),
    ever_played INTEGER NOT NULL CHECK (ever_played IN (0, 1)),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS factory_pause_scopes (
    canvas_name TEXT NOT NULL
      REFERENCES factory_pause_canvases(canvas_name) ON DELETE CASCADE,
    scope_kind TEXT NOT NULL CHECK (scope_kind IN ('node', 'region')),
    scope_id TEXT NOT NULL CHECK (length(scope_id) BETWEEN 1 AND 1024),
    paused_at TEXT NOT NULL CHECK (length(paused_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, scope_kind, scope_id)
  ) STRICT, WITHOUT ROWID;
`;var jx=64;var Ix=/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/;var B_=WX.empty(),w40=["msg.list","msg.send"],M40=I6(...w40),j40=I6("tasks.list","tasks.create","tasks.claim","tasks.update","msg.list","msg.send"),I40=I6("request.escalate","msg.list","msg.send"),x40=I6("artifact.publish"),v40=I6("browser.automate"),S40=I6("board.list","board.create_topic","board.post","board.mark_read"),k40=I6("pad.read","pad.patch"),b40={agent:{kind:"agent",role:"actor",offers:M40},page:{kind:"page",role:"sink",offers:v40},task:{kind:"task",role:"sink",offers:j40},requests:{kind:"requests",role:"sink",offers:I40},artifacts:{kind:"artifacts",role:"sink",offers:x40},board:{kind:"board",role:"sink",offers:S40},pad:{kind:"pad",role:"sink",offers:k40},terminal:{kind:"terminal",role:"sink",offers:B_},watcher:{kind:"watcher",role:"scheduler",offers:B_},timer:{kind:"timer",role:"scheduler",offers:B_},cron:{kind:"cron",role:"scheduler",offers:B_},relay:{kind:"relay",role:"scheduler",offers:I6("relay.trigger")}},zU0=XQ.fromIterable(Pj.map((X)=>[X,b40[X]])),qU0=D6.taggedEnum();var xx=["command-center","remote"];var rU=1,vx=_.Literals(["dark","bright","system"]),Sx=_.Literals(["comfortable","compact"]),_6=(X,Y)=>_.Number.pipe(_.check(_.isInt()),_.check(_.isBetween({minimum:X,maximum:Y}))),kx=_.Literals(["follow","agent"]),nU=_.Struct({theme:vx,density:Sx,reduceMotion:_.Boolean,agentAppearance:_.optionalKey(kx)}),bx=_.String.pipe(_.check(_.isMaxLength(jx)),_.check(_.isPattern(new RegExp(`^$|${Ix.source}`)))),sU=_.Struct({defaultCanvas:bx,showMinimap:_.Boolean,fitOnOpen:_.Boolean}),aU=_.Struct({pulseLogRetention:_.optionalKey(_6(5,500)),debugVerbose:_.Boolean}),tU=_.Struct({maxVisibleSurfaces:_6(1,Z7),maxWarmSessions:_6(1,G7)}),eU=_.Struct({openLastCanvas:_.Boolean,logsExplorer:_.optionalKey(_.Boolean)}),c9=(X)=>_.String.pipe(_.check(_.isMaxLength(X))),g40=_.Struct({enabled:_.optionalKey(_.Boolean),model:_.optionalKey(c9(200)),effort:_.optionalKey(c9(64)),permissionMode:_.optionalKey(c9(64))}),XD=_.Struct({byHarness:_.Record(_.String,g40)}),gx=_.Literals(["fine","balanced","coarse"]),YD=_.Struct({ditherLevel:gx,remoteManagedInstalls:_.Boolean}),yx=_.Literals([...xx,""]),z_=_.String.pipe(_.check(_.isMinLength(1)),_.check(_.isMaxLength(64)),_.check(_.isPattern(/^(?!-)[A-Za-z0-9][A-Za-z0-9._-]*$/))),wU0=_.Unknown.pipe(_.check(_.makeFilter((X)=>!(X!==null&&typeof X==="object"&&!Array.isArray(X)&&Object.prototype.hasOwnProperty.call(X,"topologyIntegrity")),{message:"topologyIntegrity is retired and must not be supplied"}))),y40=_.Struct({role:yx,hostId:z_,agentHostId:_.optionalKey(z_),supervisedPreferred:_.Boolean}),QD=y40,q_=_.Number.pipe(_.check(_.isBetween({minimum:0,maximum:1}))),B7=_.Struct({enabled:_.Boolean,volume:q_}),h40=_.Struct({blocked:B7,permission:B7,herdrDone:B7,orphan:B7,cycle:B7}),JD=_.Struct({muted:_.Boolean,masterVolume:q_,clips:h40}),hx=_.Literals(["block","bar","underline"]),mx=_.Literals(["off","visual","sound"]),l9=(X,Y)=>_.Number.pipe(_.check(_.isBetween({minimum:X,maximum:Y}))),b0={scrollSensitivity:{min:1,max:20},fontSize:{min:6,max:48},scrollback:{min:100,max:50000},minimumContrastRatio:{min:1,max:21},lineHeight:{min:1,max:2},letterSpacing:{min:0,max:5},fontFamily:{minLength:1,maxLength:200}},fx=_.String.pipe(_.check(_.isMinLength(b0.fontFamily.minLength)),_.check(_.isMaxLength(b0.fontFamily.maxLength))),$D=_.Struct({scrollSensitivity:_6(b0.scrollSensitivity.min,b0.scrollSensitivity.max),fontSize:_6(b0.fontSize.min,b0.fontSize.max),fontFamily:fx,cursorStyle:hx,scrollback:_6(b0.scrollback.min,b0.scrollback.max),cursorBlink:_.Boolean,minimumContrastRatio:l9(b0.minimumContrastRatio.min,b0.minimumContrastRatio.max),lineHeight:l9(b0.lineHeight.min,b0.lineHeight.max),letterSpacing:l9(b0.letterSpacing.min,b0.letterSpacing.max),screenReaderMode:_.Boolean,bell:mx}),MU0=_.Struct({version:_.Literal(rU),appearance:nU,canvas:sU,kernel:aU,browser:tU,advanced:eU,audio:JD,station:QD,fleet:YD,harnesses:_.optionalKey(XD),terminal:_.optionalKey($D)}),m40=_.Struct({theme:_.optionalKey(vx),density:_.optionalKey(Sx),reduceMotion:_.optionalKey(_.Boolean),agentAppearance:_.optionalKey(kx)}),f40=_.Struct({defaultCanvas:_.optionalKey(bx),showMinimap:_.optionalKey(_.Boolean),fitOnOpen:_.optionalKey(_.Boolean)}),p40=_.Struct({debugVerbose:_.optionalKey(_.Boolean)}),d40=_.Struct({maxVisibleSurfaces:_.optionalKey(_6(1,Z7)),maxWarmSessions:_.optionalKey(_6(1,G7))}),u40=_.Struct({openLastCanvas:_.optionalKey(_.Boolean),logsExplorer:_.optionalKey(_.Boolean)}),c40=_.Struct({scrollSensitivity:_.optionalKey(_6(b0.scrollSensitivity.min,b0.scrollSensitivity.max)),fontSize:_.optionalKey(_6(b0.fontSize.min,b0.fontSize.max)),fontFamily:_.optionalKey(fx),cursorStyle:_.optionalKey(hx),scrollback:_.optionalKey(_6(b0.scrollback.min,b0.scrollback.max)),cursorBlink:_.optionalKey(_.Boolean),minimumContrastRatio:_.optionalKey(l9(b0.minimumContrastRatio.min,b0.minimumContrastRatio.max)),lineHeight:_.optionalKey(l9(b0.lineHeight.min,b0.lineHeight.max)),letterSpacing:_.optionalKey(l9(b0.letterSpacing.min,b0.letterSpacing.max)),screenReaderMode:_.optionalKey(_.Boolean),bell:_.optionalKey(mx)}),l40=_.Struct({enabled:_.optionalKey(_.Boolean),model:_.optionalKey(c9(200)),effort:_.optionalKey(c9(64)),permissionMode:_.optionalKey(c9(64))}),o40=_.Struct({byHarness:_.optionalKey(_.Record(_.String,l40))}),i40=_.Struct({ditherLevel:_.optionalKey(gx),remoteManagedInstalls:_.optionalKey(_.Boolean)}),r40=_.Struct({role:_.optionalKey(yx),hostId:_.optionalKey(z_),agentHostId:_.optionalKey(z_),supervisedPreferred:_.optionalKey(_.Boolean)}),n40=r40,z7=_.Struct({enabled:_.optionalKey(_.Boolean),volume:_.optionalKey(q_)}),s40=_.Struct({blocked:_.optionalKey(z7),permission:_.optionalKey(z7),herdrDone:_.optionalKey(z7),orphan:_.optionalKey(z7),cycle:_.optionalKey(z7)}),a40=_.Struct({muted:_.optionalKey(_.Boolean),masterVolume:_.optionalKey(q_),clips:_.optionalKey(s40)}),jU0=_.Struct({appearance:_.optionalKey(m40),canvas:_.optionalKey(f40),kernel:_.optionalKey(p40),browser:_.optionalKey(d40),advanced:_.optionalKey(u40),audio:_.optionalKey(a40),station:_.optionalKey(n40),fleet:_.optionalKey(i40),harnesses:_.optionalKey(o40),terminal:_.optionalKey(c40)}),IU0=_.Literals(["appearance","canvas","kernel","browser","advanced","audio","station","fleet","harnesses","terminal"]);var t40=_.Literals(["validation","io","corrupt","unsupported"]);class px extends _.TaggedErrorClass()("SettingsError",{message:_.String,code:t40}){}var dx=`
  CREATE TABLE IF NOT EXISTS settings_preferences (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    version INTEGER NOT NULL CHECK (version = ${rU}),
    body TEXT NOT NULL
      CHECK (
        json_valid(body)
        AND json_type(body) = 'object'
        AND length(CAST(body AS BLOB)) <= 65536
      ),
    updated_at TEXT NOT NULL CHECK (length(updated_at) > 0)
  ) STRICT;

  CREATE TABLE IF NOT EXISTS settings_initialization (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    initialized_at TEXT NOT NULL CHECK (length(initialized_at) > 0)
  ) STRICT;
`,e40=_.Struct({appearance:nU,canvas:sU,kernel:aU,browser:tU,advanced:eU,audio:JD,fleet:YD,harnesses:_.optionalKey(XD),terminal:_.optionalKey($D)}),gU0=_.decodeUnknownResult(e40,{onExcessProperty:"error"}),yU0=_.decodeUnknownResult(QD,{onExcessProperty:"error"});var ux=`
  CREATE TABLE IF NOT EXISTS scheduler_interval_state (
    home_station TEXT NOT NULL
      CHECK (
        length(home_station) BETWEEN 1 AND 64
        AND substr(home_station, 1, 1) <> '-'
        AND home_station GLOB '[A-Za-z0-9]*'
        AND home_station NOT GLOB '*[^A-Za-z0-9._-]*'
      ),
    timer_key TEXT NOT NULL CHECK (length(timer_key) BETWEEN 1 AND 512),
    schedule_id TEXT NOT NULL CHECK (length(schedule_id) BETWEEN 1 AND 256),
    interval_milliseconds INTEGER NOT NULL
      CHECK (interval_milliseconds > 0),
    catch_up_policy TEXT NOT NULL
      CHECK (catch_up_policy = 'coalesce-latest'),
    next_due_at_epoch_ms INTEGER NOT NULL
      CHECK (next_due_at_epoch_ms >= 0),
    next_due_slot TEXT NOT NULL
      CHECK (
        length(next_due_slot) > 0
        AND next_due_slot NOT GLOB '*[^0-9]*'
        AND (
          next_due_slot = '0'
          OR substr(next_due_slot, 1, 1) <> '0'
        )
      ),
    last_fired_slot TEXT
      CHECK (
        last_fired_slot IS NULL
        OR (
          length(last_fired_slot) > 0
          AND last_fired_slot NOT GLOB '*[^0-9]*'
          AND (
            last_fired_slot = '0'
            OR substr(last_fired_slot, 1, 1) <> '0'
          )
        )
      ),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (home_station, timer_key)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS scheduler_interval_firings (
    home_station TEXT NOT NULL
      CHECK (length(home_station) BETWEEN 1 AND 64),
    timer_key TEXT NOT NULL CHECK (length(timer_key) BETWEEN 1 AND 512),
    schedule_id TEXT NOT NULL CHECK (length(schedule_id) BETWEEN 1 AND 256),
    catch_up_policy TEXT NOT NULL
      CHECK (catch_up_policy = 'coalesce-latest'),
    claim_slot TEXT NOT NULL
      CHECK (
        length(claim_slot) > 0
        AND claim_slot NOT GLOB '*[^0-9]*'
        AND (
          claim_slot = '0'
          OR substr(claim_slot, 1, 1) <> '0'
        )
      ),
    due_slot TEXT NOT NULL
      CHECK (
        length(due_slot) > 0
        AND due_slot NOT GLOB '*[^0-9]*'
        AND (
          due_slot = '0'
          OR substr(due_slot, 1, 1) <> '0'
        )
      ),
    scheduled_for_epoch_ms INTEGER NOT NULL
      CHECK (scheduled_for_epoch_ms >= 0),
    observed_at_epoch_ms INTEGER NOT NULL
      CHECK (observed_at_epoch_ms >= 0),
    coalesced_missed_slots TEXT NOT NULL
      CHECK (
        length(coalesced_missed_slots) > 0
        AND coalesced_missed_slots NOT GLOB '*[^0-9]*'
        AND (
          coalesced_missed_slots = '0'
          OR substr(coalesced_missed_slots, 1, 1) <> '0'
        )
      ),
    claimed_at TEXT NOT NULL CHECK (length(claimed_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      home_station,
      timer_key,
      schedule_id,
      claim_slot
    )
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS scheduler_interval_due
    ON scheduler_interval_state(
      home_station,
      next_due_at_epoch_ms,
      timer_key
    );
`;var X50=[`
    CREATE TABLE IF NOT EXISTS station_known_installations (
      installation_id TEXT PRIMARY KEY
        CHECK (
          length(installation_id) BETWEEN 1 AND 128
          AND installation_id GLOB '[A-Za-z0-9]*'
          AND installation_id NOT GLOB '*[^A-Za-z0-9._:-]*'
        ),
      registered_at TEXT NOT NULL
        CHECK (length(registered_at) BETWEEN 1 AND 64)
    ) STRICT, WITHOUT ROWID
  `,`
    CREATE TABLE IF NOT EXISTS station_installation (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      installation_id TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL
        CHECK (length(created_at) BETWEEN 1 AND 64),
      FOREIGN KEY (installation_id)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT
  `,`
    CREATE TABLE IF NOT EXISTS station_pairing (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      command_center_installation_id TEXT NOT NULL,
      station_label TEXT NOT NULL
        CHECK (length(station_label) BETWEEN 1 AND 128),
      app_version TEXT NOT NULL
        CHECK (length(app_version) BETWEEN 1 AND 64),
      paired_at TEXT NOT NULL
        CHECK (length(paired_at) BETWEEN 1 AND 64),
      FOREIGN KEY (command_center_installation_id)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT
  `,`
    CREATE TABLE IF NOT EXISTS station_configuration (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      role TEXT NOT NULL
        CHECK (role IN ('command-center', 'remote')),
      host_id TEXT NOT NULL CHECK (length(host_id) BETWEEN 1 AND 64),
      agent_host_id TEXT,
      command_center_installation_id TEXT,
      supervised_preferred INTEGER NOT NULL
        CHECK (supervised_preferred IN (0, 1)),
      configured_at TEXT NOT NULL
        CHECK (length(configured_at) BETWEEN 1 AND 64),
      CHECK (
        (
          role = 'command-center'
          AND agent_host_id IS NULL
          AND command_center_installation_id IS NULL
        )
        OR
        (
          role = 'remote'
          AND agent_host_id IS NOT NULL
          AND length(agent_host_id) BETWEEN 1 AND 64
          AND command_center_installation_id IS NOT NULL
        )
      ),
      FOREIGN KEY (command_center_installation_id)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT
  `,`
    CREATE TABLE IF NOT EXISTS station_projection_versions (
      generation TEXT NOT NULL
        CHECK (
          length(generation) BETWEEN 1 AND 32
          AND generation NOT GLOB '*[^0-9]*'
          AND (generation = '0' OR substr(generation, 1, 1) <> '0')
        ),
      content_sha256 TEXT NOT NULL
        CHECK (
          length(content_sha256) = 64
          AND content_sha256 NOT GLOB '*[^a-f0-9]*'
        ),
      source_canvas_generation TEXT NOT NULL
        CHECK (
          length(source_canvas_generation) BETWEEN 1 AND 32
          AND source_canvas_generation NOT GLOB '*[^0-9]*'
          AND (
            source_canvas_generation = '0'
            OR substr(source_canvas_generation, 1, 1) <> '0'
          )
        ),
      source_intent_sha256 TEXT NOT NULL
        CHECK (
          length(source_intent_sha256) = 64
          AND source_intent_sha256 NOT GLOB '*[^a-f0-9]*'
        ),
      body TEXT NOT NULL
        CHECK (length(body) BETWEEN 1 AND 67108864),
      created_at TEXT NOT NULL
        CHECK (length(created_at) BETWEEN 1 AND 64),
      received_at TEXT NOT NULL
        CHECK (length(received_at) BETWEEN 1 AND 64),
      PRIMARY KEY (generation),
      UNIQUE (generation, content_sha256)
    ) STRICT, WITHOUT ROWID
  `,`
    CREATE TABLE IF NOT EXISTS station_projection_head (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      generation TEXT NOT NULL,
      content_sha256 TEXT NOT NULL,
      FOREIGN KEY (generation, content_sha256)
        REFERENCES station_projection_versions(
          generation,
          content_sha256
        )
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT
  `,`
    CREATE TABLE IF NOT EXISTS station_received_cursors (
      event_home TEXT NOT NULL,
      entity_home TEXT NOT NULL,
      through_sequence TEXT NOT NULL
        CHECK (
          length(through_sequence) BETWEEN 1 AND 32
          AND through_sequence NOT GLOB '*[^0-9]*'
          AND substr(through_sequence, 1, 1) <> '0'
        ),
      updated_at TEXT NOT NULL
        CHECK (length(updated_at) BETWEEN 1 AND 64),
      PRIMARY KEY (event_home, entity_home),
      FOREIGN KEY (event_home)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
      FOREIGN KEY (entity_home)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT, WITHOUT ROWID
  `,`
    CREATE TABLE IF NOT EXISTS station_peer_ack_cursors (
      peer_installation_id TEXT NOT NULL,
      event_home TEXT NOT NULL,
      entity_home TEXT NOT NULL,
      through_sequence TEXT NOT NULL
        CHECK (
          length(through_sequence) BETWEEN 1 AND 32
          AND through_sequence NOT GLOB '*[^0-9]*'
          AND substr(through_sequence, 1, 1) <> '0'
        ),
      acknowledged_at TEXT NOT NULL
        CHECK (length(acknowledged_at) BETWEEN 1 AND 64),
      PRIMARY KEY (
        peer_installation_id,
        event_home,
        entity_home
      ),
      CHECK (peer_installation_id <> event_home),
      FOREIGN KEY (peer_installation_id)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
      FOREIGN KEY (event_home)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
      FOREIGN KEY (entity_home)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT, WITHOUT ROWID
  `,`
    CREATE TABLE IF NOT EXISTS station_fleet_targets (
      host_id TEXT PRIMARY KEY
        CHECK (
          length(host_id) BETWEEN 1 AND 64
          AND substr(host_id, 1, 1) <> '-'
          AND host_id GLOB '[A-Za-z0-9]*'
          AND host_id NOT GLOB '*[^A-Za-z0-9._-]*'
        ),
      station_installation_id TEXT NOT NULL UNIQUE,
      bound_at TEXT NOT NULL
        CHECK (length(bound_at) BETWEEN 1 AND 64),
      retired_at TEXT
        CHECK (
          retired_at IS NULL
          OR length(retired_at) BETWEEN 1 AND 64
        ),
      FOREIGN KEY (station_installation_id)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT, WITHOUT ROWID
  `,`
    CREATE TRIGGER IF NOT EXISTS station_known_installation_identity_immutable
    BEFORE UPDATE OF installation_id ON station_known_installations
    WHEN OLD.installation_id <> NEW.installation_id
    BEGIN
      SELECT RAISE(ABORT, 'known installation identity is immutable');
    END
  `,`
    CREATE TRIGGER IF NOT EXISTS station_local_installation_identity_immutable
    BEFORE UPDATE OF installation_id ON station_installation
    WHEN OLD.installation_id <> NEW.installation_id
    BEGIN
      SELECT RAISE(ABORT, 'local installation identity is immutable');
    END
  `,`
    CREATE TRIGGER IF NOT EXISTS station_projection_version_immutable_update
    BEFORE UPDATE ON station_projection_versions
    BEGIN
      SELECT RAISE(ABORT, 'station projection versions are immutable');
    END
  `,`
    CREATE TRIGGER IF NOT EXISTS station_projection_version_immutable_delete
    BEFORE DELETE ON station_projection_versions
    BEGIN
      SELECT RAISE(ABORT, 'station projection versions are immutable');
    END
  `],cx=`${X50.join(`;
`)};`;var Y50=[`
    CREATE TABLE IF NOT EXISTS station_status_facts (
      kind TEXT NOT NULL
        CHECK (
          kind IN (
            'kernel',
            'deployment'
          )
        ),
      host_id TEXT NOT NULL CHECK (length(host_id) <= 64),
      record_json TEXT NOT NULL
        CHECK (
          json_valid(record_json)
          AND json_type(record_json) = 'object'
        ),
      updated_at TEXT NOT NULL CHECK (length(updated_at) > 0),
      PRIMARY KEY (kind, host_id),
      CHECK (
        (kind = 'kernel' AND host_id = '')
        OR (kind = 'deployment' AND length(host_id) > 0)
      )
    ) STRICT, WITHOUT ROWID
  `],lx=`${Y50.join(`;
`)};
`;var ox=`
  CREATE TABLE IF NOT EXISTS usage_state (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    snapshots_json TEXT NOT NULL
      CHECK (
        json_valid(snapshots_json)
        AND json_type(snapshots_json) = 'array'
      ),
    last_live_at TEXT NOT NULL CHECK (length(last_live_at) > 0),
    updated_at TEXT NOT NULL CHECK (length(updated_at) > 0)
  ) STRICT;
`;var O_=`
  -- Immutable verified object identity. Media type / display name live on
  -- content_refs (descriptive metadata is not part of byte identity).
  CREATE TABLE IF NOT EXISTS content_objects (
    sha256 TEXT PRIMARY KEY
      CHECK (
        length(sha256) = 64
        AND sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    byte_length INTEGER NOT NULL
      CHECK (
        typeof(byte_length) = 'integer'
        AND byte_length >= 0
      ),
    created_at TEXT NOT NULL
      CHECK (length(created_at) BETWEEN 1 AND 64),
    verified_at TEXT NOT NULL
      CHECK (length(verified_at) BETWEEN 1 AND 64)
  ) STRICT, WITHOUT ROWID;

  -- Portable references bound to durable work after the object exists.
  CREATE TABLE IF NOT EXISTS content_refs (
    ref_id TEXT PRIMARY KEY
      CHECK (length(ref_id) BETWEEN 1 AND 256),
    sha256 TEXT NOT NULL
      CHECK (
        length(sha256) = 64
        AND sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    byte_length INTEGER NOT NULL
      CHECK (
        typeof(byte_length) = 'integer'
        AND byte_length >= 0
      ),
    media_type TEXT NOT NULL
      CHECK (length(media_type) BETWEEN 1 AND 255),
    display_name TEXT
      CHECK (
        display_name IS NULL
        OR length(display_name) BETWEEN 1 AND 255
      ),
    owner_kind TEXT NOT NULL
      CHECK (
        owner_kind IN (
          'task',
          'message',
          'artifact',
          'board_topic',
          'board_post',
          'other'
        )
      ),
    owner_canvas TEXT NOT NULL
      CHECK (length(owner_canvas) BETWEEN 1 AND 256),
    owner_node TEXT NOT NULL
      CHECK (length(owner_node) BETWEEN 1 AND 256),
    owner_record_id TEXT NOT NULL
      CHECK (length(owner_record_id) BETWEEN 1 AND 256),
    created_at TEXT NOT NULL
      CHECK (length(created_at) BETWEEN 1 AND 64),
    FOREIGN KEY (sha256)
      REFERENCES content_objects(sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS content_refs_by_object
    ON content_refs(sha256, created_at, ref_id);

  CREATE INDEX IF NOT EXISTS content_refs_by_owner
    ON content_refs(owner_canvas, owner_node, owner_kind, owner_record_id);

  -- Verification receipts. Only the verified state is durable here; missing /
  -- corrupt / unavailable are computed at read time from object + file state.
  CREATE TABLE IF NOT EXISTS content_receipts (
    sha256 TEXT PRIMARY KEY
      CHECK (
        length(sha256) = 64
        AND sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    verified_sha256 TEXT NOT NULL
      CHECK (
        length(verified_sha256) = 64
        AND verified_sha256 NOT GLOB '*[^a-f0-9]*'
        AND verified_sha256 = sha256
      ),
    verified_byte_length INTEGER NOT NULL
      CHECK (
        typeof(verified_byte_length) = 'integer'
        AND verified_byte_length >= 0
      ),
    verified_at TEXT NOT NULL
      CHECK (length(verified_at) BETWEEN 1 AND 64),
    FOREIGN KEY (sha256)
      REFERENCES content_objects(sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  -- Transfer bookkeeping for a future cross-Station data plane. Local ingest
  -- does not require rows; schema exists so the next migration is not blocked.
  CREATE TABLE IF NOT EXISTS content_transfers (
    transfer_id TEXT PRIMARY KEY
      CHECK (length(transfer_id) BETWEEN 1 AND 256),
    sha256 TEXT NOT NULL
      CHECK (
        length(sha256) = 64
        AND sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    byte_length INTEGER NOT NULL
      CHECK (
        typeof(byte_length) = 'integer'
        AND byte_length >= 0
      ),
    state TEXT NOT NULL
      CHECK (
        state IN (
          'pending',
          'receiving',
          'verifying',
          'complete',
          'failed',
          'canceled'
        )
      ),
    direction TEXT NOT NULL
      CHECK (direction IN ('inbound', 'outbound')),
    peer_installation_id TEXT
      CHECK (
        peer_installation_id IS NULL
        OR length(peer_installation_id) BETWEEN 1 AND 128
      ),
    error_reason TEXT
      CHECK (
        error_reason IS NULL
        OR length(error_reason) BETWEEN 1 AND 1024
      ),
    created_at TEXT NOT NULL
      CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL
      CHECK (length(updated_at) BETWEEN 1 AND 64)
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS content_transfers_by_object
    ON content_transfers(sha256, state, updated_at);
`,L_=`
  CREATE TABLE IF NOT EXISTS content_inline_media_migration (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    status TEXT NOT NULL
      CHECK (status IN ('pending', 'complete')),
    objects_ingested INTEGER NOT NULL DEFAULT 0
      CHECK (
        typeof(objects_ingested) = 'integer'
        AND objects_ingested >= 0
      ),
    completed_at TEXT
      CHECK (
        completed_at IS NULL
        OR length(completed_at) BETWEEN 1 AND 64
      )
  ) STRICT;
`;var ix=`
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;
`,_D=`
  CREATE TABLE IF NOT EXISTS work_event_sequences (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    last_seq TEXT NOT NULL
      CHECK (
        length(last_seq) BETWEEN 1 AND 32
        AND last_seq NOT GLOB '*[^0-9]*'
        AND (last_seq = '0' OR substr(last_seq, 1, 1) <> '0')
      ),
    PRIMARY KEY (event_home, entity_home),
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    protocol TEXT NOT NULL CHECK (protocol = 'vellum/work/v2'),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, record_type),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'command'
      CHECK (record_type = 'command'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    action_json TEXT NOT NULL
      CHECK (
        length(action_json) BETWEEN 2 AND 262144
        AND json_valid(action_json)
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home <> entity_home),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_facts (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'fact'
      CHECK (record_type = 'fact'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    result_json TEXT NOT NULL
      CHECK (
        length(result_json) BETWEEN 2 AND 262144
        AND json_valid(result_json)
      ),
    basis_kind TEXT NOT NULL
      CHECK (
        basis_kind IN (
          'authorial-intent',
          'projected-intent',
          'command'
        )
      ),
    basis_authorial_generation TEXT
      CHECK (
        basis_authorial_generation IS NULL
        OR (
          length(basis_authorial_generation) BETWEEN 1 AND 32
          AND basis_authorial_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_authorial_generation = '0'
            OR substr(basis_authorial_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_authorial_content_sha256 TEXT
      CHECK (
        basis_authorial_content_sha256 IS NULL
        OR (
          length(basis_authorial_content_sha256) = 64
          AND basis_authorial_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_projected_generation TEXT
      CHECK (
        basis_projected_generation IS NULL
        OR (
          length(basis_projected_generation) BETWEEN 1 AND 32
          AND basis_projected_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_projected_generation = '0'
            OR substr(basis_projected_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_projected_content_sha256 TEXT
      CHECK (
        basis_projected_content_sha256 IS NULL
        OR (
          length(basis_projected_content_sha256) = 64
          AND basis_projected_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_command_event_home TEXT,
    basis_command_entity_home TEXT,
    basis_command_seq TEXT
      CHECK (
        basis_command_seq IS NULL
        OR (
          length(basis_command_seq) BETWEEN 1 AND 32
          AND basis_command_seq NOT GLOB '*[^0-9]*'
          AND substr(basis_command_seq, 1, 1) <> '0'
        )
      ),
    basis_command_sha256 TEXT
      CHECK (
        basis_command_sha256 IS NULL
        OR (
          length(basis_command_sha256) = 64
          AND basis_command_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home = entity_home),
    CHECK (
      (
        basis_kind = 'authorial-intent'
        AND basis_authorial_generation IS NOT NULL
        AND basis_authorial_content_sha256 IS NOT NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'projected-intent'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NOT NULL
        AND basis_projected_content_sha256 IS NOT NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'command'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NOT NULL
        AND basis_command_entity_home IS NOT NULL
        AND basis_command_seq IS NOT NULL
        AND basis_command_sha256 IS NOT NULL
        AND basis_command_entity_home = entity_home
      )
    ),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (basis_authorial_generation)
      REFERENCES canvas_generations(generation)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_projected_generation,
      basis_projected_content_sha256
    ) REFERENCES station_projection_versions(generation, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq
    ) REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq,
      basis_command_sha256
    ) REFERENCES work_events(
      event_home,
      entity_home,
      seq,
      content_sha256
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_dispositions (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'disposition'
      CHECK (record_type = 'disposition'),
    status TEXT NOT NULL CHECK (status IN ('applied', 'rejected')),
    command_event_home TEXT NOT NULL,
    command_entity_home TEXT NOT NULL,
    command_seq TEXT NOT NULL,
    command_sha256 TEXT NOT NULL
      CHECK (
        length(command_sha256) = 64
        AND command_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT,
    fact_entity_home TEXT,
    fact_seq TEXT,
    fact_sha256 TEXT
      CHECK (
        fact_sha256 IS NULL
        OR (
          length(fact_sha256) = 64
          AND fact_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    rejection_reason TEXT
      CHECK (
        rejection_reason IS NULL
        OR rejection_reason IN (
          'authority-mismatch',
          'capability-denied',
          'causal-conflict',
          'claim-contention',
          'identity-conflict',
          'invalid-transition',
          'locality-mismatch',
          'missing-entity',
          'projection-conflict',
          'target-mismatch'
        )
      ),
    rejection_message TEXT
      CHECK (
        rejection_message IS NULL
        OR length(rejection_message) BETWEEN 1 AND 2048
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, status),
    CHECK (event_home = entity_home),
    CHECK (command_entity_home = entity_home),
    CHECK (
      (
        status = 'applied'
        AND fact_event_home IS NOT NULL
        AND fact_entity_home IS NOT NULL
        AND fact_seq IS NOT NULL
        AND fact_sha256 IS NOT NULL
        AND fact_event_home = event_home
        AND fact_entity_home = entity_home
        AND rejection_reason IS NULL
        AND rejection_message IS NULL
      )
      OR
      (
        status = 'rejected'
        AND fact_event_home IS NULL
        AND fact_entity_home IS NULL
        AND fact_seq IS NULL
        AND fact_sha256 IS NULL
        AND rejection_reason IS NOT NULL
        AND rejection_message IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (command_event_home, command_entity_home, command_seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      command_event_home,
      command_entity_home,
      command_seq,
      command_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      fact_event_home,
      fact_entity_home,
      fact_seq,
      fact_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    claim_actor_seat_id TEXT
      CHECK (
        claim_actor_seat_id IS NULL
        OR (
          length(claim_actor_seat_id) = 69
          AND substr(claim_actor_seat_id, 1, 5) = 'seat_'
          AND substr(claim_actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT
      CHECK (resolved_at IS NULL OR length(resolved_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        operation = 'task.claim'
        AND item_kind = 'task'
        AND claim_actor_seat_id IS NOT NULL
      )
      OR
      (
        operation <> 'task.claim'
        AND claim_actor_seat_id IS NULL
      )
    ),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      resolution_event_home,
      resolution_entity_home,
      resolution_seq,
      resolution_status
    ) REFERENCES work_dispositions(event_home, entity_home, seq, status)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_tasks (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    task_id TEXT NOT NULL CHECK (length(task_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, task_id),
    UNIQUE (canvas_name, node_id, task_id, entity_home),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'submitted' AND actor_seat_id IS NULL)
      OR state IN ('completed', 'canceled', 'failed', 'rejected')
      OR (
        state IN ('working', 'input-required', 'auth-required')
        AND actor_seat_id IS NOT NULL
      )
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_requests (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    request_id TEXT NOT NULL CHECK (length(request_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'input-required',
          'auth-required',
          'completed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, request_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    parent_lane TEXT NOT NULL CHECK (parent_lane IN ('task', 'request')),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    message_kind TEXT NOT NULL CHECK (message_kind IN ('brief', 'history')),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      message_id
    ),
    UNIQUE (canvas_name, node_id, parent_lane, item_id, position),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, message_id),
    UNIQUE (canvas_name, node_id, position),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_artifacts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    artifact_id TEXT NOT NULL CHECK (length(artifact_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    name TEXT,
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_canvas_name TEXT
      CHECK (
        task_canvas_name IS NULL
        OR length(task_canvas_name) BETWEEN 1 AND 256
      ),
    task_node_id TEXT
      CHECK (
        task_node_id IS NULL
        OR length(task_node_id) BETWEEN 1 AND 256
      ),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    task_entity_home TEXT,
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, artifact_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (
        task_canvas_name IS NULL
        AND task_node_id IS NULL
        AND task_id IS NULL
        AND task_entity_home IS NULL
      )
      OR
      (
        task_canvas_name IS NOT NULL
        AND task_node_id IS NOT NULL
        AND task_id IS NOT NULL
        AND task_entity_home IS NOT NULL
      )
    ),
    CHECK (
      task_entity_home IS NULL
      OR task_entity_home = entity_home
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      task_canvas_name,
      task_node_id,
      task_id,
      task_entity_home
    ) REFERENCES work_tasks(
      canvas_name,
      node_id,
      task_id,
      entity_home
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_transitions (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    lane TEXT NOT NULL CHECK (lane IN ('task', 'request')),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve'
        )
      ),
    from_state TEXT,
    to_state TEXT NOT NULL
      CHECK (
        to_state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, item_id, lane, ordinal),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (
      from_state IS NULL
      OR from_state IN (
        'submitted',
        'working',
        'input-required',
        'auth-required',
        'completed',
        'canceled',
        'failed',
        'rejected'
      )
    ),
    CHECK (
      to_state NOT IN ('working', 'input-required', 'auth-required')
      OR actor_seat_id IS NOT NULL
    ),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_delivery_receipts (
    delivery_id TEXT NOT NULL CHECK (length(delivery_id) BETWEEN 1 AND 256),
    delivered_item_kind TEXT NOT NULL
      CHECK (
        delivered_item_kind IN (
          'task',
          'request',
          'message',
          'artifact',
          'delivery'
        )
      ),
    delivered_item_id TEXT NOT NULL
      CHECK (length(delivered_item_id) BETWEEN 1 AND 256),
    delivered_canvas_name TEXT NOT NULL
      CHECK (length(delivered_canvas_name) BETWEEN 1 AND 256),
    delivered_node_id TEXT NOT NULL
      CHECK (length(delivered_node_id) BETWEEN 1 AND 256),
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    actor_canvas_name TEXT NOT NULL
      CHECK (length(actor_canvas_name) BETWEEN 1 AND 256),
    actor_node_id TEXT NOT NULL
      CHECK (length(actor_node_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    accepted_at TEXT NOT NULL CHECK (length(accepted_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      delivered_canvas_name,
      delivered_node_id,
      delivery_id
    ),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_events_route_order
    ON work_events(event_home, entity_home, length(seq), seq);
  CREATE INDEX IF NOT EXISTS work_events_item_history
    ON work_events(
      item_canvas_name,
      item_node_id,
      item_kind,
      item_id,
      entity_home,
      length(seq),
      seq
    );
  CREATE INDEX IF NOT EXISTS work_pending_commands_route
    ON work_pending_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_item
    ON work_pending_commands(
      item_canvas_name,
      item_node_id,
      item_id
    )
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_actor
    ON work_pending_commands(claim_actor_seat_id)
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE INDEX IF NOT EXISTS work_tasks_node
    ON work_tasks(canvas_name, node_id, created_at, task_id);
  CREATE UNIQUE INDEX IF NOT EXISTS work_tasks_one_active_per_actor
    ON work_tasks(actor_seat_id)
    WHERE
      actor_seat_id IS NOT NULL
      AND state IN ('working', 'input-required', 'auth-required');
  CREATE INDEX IF NOT EXISTS work_requests_node
    ON work_requests(canvas_name, node_id, created_at, request_id);
  CREATE INDEX IF NOT EXISTS work_task_messages_thread
    ON work_task_messages(
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      position
    );
  CREATE UNIQUE INDEX IF NOT EXISTS work_task_messages_sink_identity
    ON work_task_messages(canvas_name, node_id, message_id);
  CREATE INDEX IF NOT EXISTS work_messages_inbox
    ON work_messages(canvas_name, node_id, position);
  CREATE INDEX IF NOT EXISTS work_artifacts_node
    ON work_artifacts(canvas_name, node_id, artifact_id);
  CREATE INDEX IF NOT EXISTS work_delivery_receipts_actor
    ON work_delivery_receipts(
      actor_seat_id,
      accepted_at,
      delivery_id
    );

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_update
  BEFORE UPDATE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_delete
  BEFORE DELETE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_update
  BEFORE UPDATE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_delete
  BEFORE DELETE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_fact_authorial_basis_resolves
  BEFORE INSERT ON work_facts
  WHEN
    NEW.basis_kind = 'authorial-intent'
    AND NOT EXISTS (
      SELECT 1
      FROM canvas_generations AS generation
      JOIN canvas_generation_documents AS document
        ON document.generation = generation.generation
      JOIN work_events AS record
        ON record.event_home = NEW.event_home
        AND record.entity_home = NEW.entity_home
        AND record.seq = NEW.seq
      WHERE generation.generation = NEW.basis_authorial_generation
        AND generation.intent_sha256 =
          NEW.basis_authorial_content_sha256
        AND document.name = record.item_canvas_name
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'authorial fact basis must resolve its exact sink canvas generation'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_update
  BEFORE UPDATE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_delete
  BEFORE DELETE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_applied_disposition_fact_basis_matches
  BEFORE INSERT ON work_dispositions
  WHEN
    NEW.status = 'applied'
    AND NOT EXISTS (
      SELECT 1
      FROM work_facts AS fact
      WHERE fact.event_home = NEW.fact_event_home
        AND fact.entity_home = NEW.fact_entity_home
        AND fact.seq = NEW.fact_seq
        AND fact.basis_kind = 'command'
        AND fact.basis_command_event_home = NEW.command_event_home
        AND fact.basis_command_entity_home = NEW.command_entity_home
        AND fact.basis_command_seq = NEW.command_seq
        AND fact.basis_command_sha256 = NEW.command_sha256
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'applied disposition fact must carry its exact command basis'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_update
  BEFORE UPDATE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_delete
  BEFORE DELETE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_matches_record
  BEFORE INSERT ON work_pending_commands
  WHEN NOT EXISTS (
    SELECT 1
    FROM work_events AS record
    WHERE record.event_home = NEW.event_home
      AND record.entity_home = NEW.entity_home
      AND record.seq = NEW.seq
      AND record.record_type = 'command'
      AND record.operation = NEW.operation
      AND record.item_kind = NEW.item_kind
      AND record.item_canvas_name = NEW.item_canvas_name
      AND record.item_node_id = NEW.item_node_id
      AND record.item_id = NEW.item_id
  )
  BEGIN
    SELECT RAISE(ABORT, 'pending command metadata must match its Work command');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_identity_immutable
  BEFORE UPDATE OF
    event_home,
    entity_home,
    seq,
    operation,
    item_kind,
    item_canvas_name,
    item_node_id,
    item_id,
    claim_actor_seat_id
  ON work_pending_commands
  WHEN
    OLD.event_home IS NOT NEW.event_home
    OR OLD.entity_home IS NOT NEW.entity_home
    OR OLD.seq IS NOT NEW.seq
    OR OLD.operation IS NOT NEW.operation
    OR OLD.item_kind IS NOT NEW.item_kind
    OR OLD.item_canvas_name IS NOT NEW.item_canvas_name
    OR OLD.item_node_id IS NOT NEW.item_node_id
    OR OLD.item_id IS NOT NEW.item_id
    OR OLD.claim_actor_seat_id IS NOT NEW.claim_actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'pending command identity is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_initial_resolution_matches
  BEFORE INSERT ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = NEW.event_home
        AND disposition.command_entity_home = NEW.entity_home
        AND disposition.command_seq = NEW.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_matches
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = OLD.event_home
        AND disposition.command_entity_home = OLD.entity_home
        AND disposition.command_seq = OLD.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_once
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    OLD.resolution_event_home IS NOT NULL
    AND (
      OLD.resolution_status IS NOT NEW.resolution_status
      OR OLD.resolution_event_home IS NOT NEW.resolution_event_home
      OR OLD.resolution_entity_home IS NOT NEW.resolution_entity_home
      OR OLD.resolution_seq IS NOT NEW.resolution_seq
      OR OLD.resolved_at IS NOT NEW.resolved_at
    )
  BEGIN
    SELECT RAISE(ABORT, 'pending command resolution is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_home_immutable
  BEFORE UPDATE OF entity_home ON work_tasks
  WHEN
    OLD.entity_home <> NEW.entity_home
    AND NOT (
      OLD.state = 'submitted'
      AND OLD.actor_seat_id IS NULL
      AND NEW.state = 'working'
      AND NEW.actor_seat_id IS NOT NULL
      AND NEW.entity_home = NEW.fact_entity_home
      AND NEW.fact_event_home = NEW.fact_entity_home
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task home is immutable except for first claim adoption'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_tasks
  WHEN
    OLD.actor_seat_id IS NOT NULL
    AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
    AND NOT (
      NEW.actor_seat_id IS NULL
      AND NEW.state = 'submitted'
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task actor seat is immutable except for operator release'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_home_immutable
  BEFORE UPDATE OF entity_home ON work_requests
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work request home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_requests
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work request actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work task message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_require_exact_parent
  BEFORE INSERT ON work_task_messages
  WHEN NOT (
    (
      NEW.parent_lane = 'task'
      AND EXISTS (
        SELECT 1
        FROM work_tasks
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND task_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
    OR
    (
      NEW.parent_lane = 'request'
      AND EXISTS (
        SELECT 1
        FROM work_requests
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND request_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
  )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task message requires an exact same-home parent'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_require_cc_home
  BEFORE INSERT ON work_messages
  WHEN
    NOT EXISTS (
      SELECT 1
      FROM station_configuration AS configuration
      JOIN station_installation AS installation
        ON installation.singleton = configuration.singleton
      WHERE configuration.singleton = 1
        AND configuration.role = 'command-center'
        AND NEW.entity_home = installation.installation_id
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work mailbox messages must be Command Center-homed'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_messages
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work message actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_home_immutable
  BEFORE UPDATE OF entity_home ON work_artifacts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_artifacts
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work artifact actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_require_claimed_task
  BEFORE INSERT ON work_artifacts
  WHEN
    NEW.task_id IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
    )
    AND NOT EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
        AND actor_seat_id IS NOT NULL
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work artifact requires an exact claimed same-home task'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_task_reference_immutable
  BEFORE UPDATE OF
    task_canvas_name,
    task_node_id,
    task_id,
    task_entity_home
  ON work_artifacts
  WHEN
    OLD.task_canvas_name IS NOT NEW.task_canvas_name
    OR OLD.task_node_id IS NOT NEW.task_node_id
    OR OLD.task_id IS NOT NEW.task_id
    OR OLD.task_entity_home IS NOT NEW.task_entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact task reference is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_transitions_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_transitions
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work transition home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_delivery_receipts_home_immutable
  BEFORE UPDATE OF entity_home ON work_delivery_receipts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work delivery receipt home is immutable');
  END;
  
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;

`,T_=`
  CREATE TABLE IF NOT EXISTS work_task_dependencies (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    task_id TEXT NOT NULL CHECK (length(task_id) BETWEEN 1 AND 256),
    depends_on_task_id TEXT NOT NULL
      CHECK (length(depends_on_task_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    PRIMARY KEY (canvas_name, node_id, task_id, depends_on_task_id),
    FOREIGN KEY (canvas_name, node_id, task_id)
      REFERENCES work_tasks(canvas_name, node_id, task_id)
      ON DELETE CASCADE
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_dependencies_dep
    ON work_task_dependencies(canvas_name, node_id, depends_on_task_id);
`,F_=`
  CREATE TABLE IF NOT EXISTS work_task_finish (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    task_id TEXT NOT NULL CHECK (length(task_id) BETWEEN 1 AND 256),
    finish_criteria_json TEXT
      CHECK (finish_criteria_json IS NULL OR json_valid(finish_criteria_json)),
    completion_evidence_json TEXT
      CHECK (
        completion_evidence_json IS NULL
        OR json_valid(completion_evidence_json)
      ),
    PRIMARY KEY (canvas_name, node_id, task_id),
    FOREIGN KEY (canvas_name, node_id, task_id)
      REFERENCES work_tasks(canvas_name, node_id, task_id)
      ON DELETE CASCADE
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;
`,R_=`
  CREATE TABLE IF NOT EXISTS work_proposal_planning (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    depends_on_json TEXT
      CHECK (depends_on_json IS NULL OR json_valid(depends_on_json)),
    finish_criteria_json TEXT
      CHECK (finish_criteria_json IS NULL OR json_valid(finish_criteria_json)),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    FOREIGN KEY (canvas_name, node_id, proposal_id)
      REFERENCES work_task_proposals(canvas_name, node_id, proposal_id)
      ON DELETE CASCADE
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;
`,q7=`
  CREATE TABLE IF NOT EXISTS work_board_topics (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    title TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 512),
    state TEXT NOT NULL CHECK (state IN ('open', 'archived')),
    author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
    author_seat_id TEXT
      CHECK (
        author_seat_id IS NULL
        OR (
          length(author_seat_id) = 69
          AND substr(author_seat_id, 1, 5) = 'seat_'
          AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    author_node_id TEXT
      CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
    author_label TEXT
      CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    post_count INTEGER NOT NULL DEFAULT 0 CHECK (post_count >= 0),
    last_activity_at TEXT NOT NULL CHECK (length(last_activity_at) BETWEEN 1 AND 64),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_board_posts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    post_id TEXT NOT NULL CHECK (length(post_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
    author_seat_id TEXT
      CHECK (
        author_seat_id IS NULL
        OR (
          length(author_seat_id) = 69
          AND substr(author_seat_id, 1, 5) = 'seat_'
          AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    author_node_id TEXT
      CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
    author_label TEXT
      CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, post_id),
    UNIQUE (canvas_name, node_id, topic_id, position),
    FOREIGN KEY (canvas_name, node_id, topic_id)
      REFERENCES work_board_topics(canvas_name, node_id, topic_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_board_read_cursors (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    principal_key TEXT NOT NULL CHECK (length(principal_key) BETWEEN 1 AND 256),
    last_read_position INTEGER NOT NULL CHECK (last_read_position >= -1),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, principal_key)
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_board_topics_node
    ON work_board_topics(canvas_name, node_id, last_activity_at, topic_id);
  CREATE INDEX IF NOT EXISTS work_board_posts_thread
    ON work_board_posts(canvas_name, node_id, topic_id, position);
`;var rx=`
  CREATE TABLE IF NOT EXISTS work_board_topics (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    title TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 512),
    state TEXT NOT NULL CHECK (state IN ('open', 'archived')),
    author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
    author_seat_id TEXT
      CHECK (
        author_seat_id IS NULL
        OR (
          length(author_seat_id) = 69
          AND substr(author_seat_id, 1, 5) = 'seat_'
          AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    author_node_id TEXT
      CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
    author_label TEXT
      CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    post_count INTEGER NOT NULL DEFAULT 0 CHECK (post_count >= 0),
    last_activity_at TEXT NOT NULL CHECK (length(last_activity_at) BETWEEN 1 AND 64),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_board_posts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    post_id TEXT NOT NULL CHECK (length(post_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
    author_seat_id TEXT
      CHECK (
        author_seat_id IS NULL
        OR (
          length(author_seat_id) = 69
          AND substr(author_seat_id, 1, 5) = 'seat_'
          AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    author_node_id TEXT
      CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
    author_label TEXT
      CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, post_id),
    UNIQUE (canvas_name, node_id, topic_id, position),
    FOREIGN KEY (canvas_name, node_id, topic_id)
      REFERENCES work_board_topics(canvas_name, node_id, topic_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_board_read_cursors (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    principal_key TEXT NOT NULL CHECK (length(principal_key) BETWEEN 1 AND 256),
    last_read_position INTEGER NOT NULL CHECK (last_read_position >= -1),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, principal_key)
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_board_topics_node
    ON work_board_topics(canvas_name, node_id, last_activity_at, topic_id);
  CREATE INDEX IF NOT EXISTS work_board_posts_thread
    ON work_board_posts(canvas_name, node_id, topic_id, position);
`.replace(`parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, post_id),`,`parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    tags_json TEXT
      CHECK (tags_json IS NULL OR json_valid(tags_json)),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, post_id),`),R5=`
  CREATE TABLE IF NOT EXISTS work_event_sequences (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    last_seq TEXT NOT NULL
      CHECK (
        length(last_seq) BETWEEN 1 AND 32
        AND last_seq NOT GLOB '*[^0-9]*'
        AND (last_seq = '0' OR substr(last_seq, 1, 1) <> '0')
      ),
    PRIMARY KEY (event_home, entity_home),
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    protocol TEXT NOT NULL CHECK (protocol = 'vellum/work/v2'),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, record_type),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'command'
      CHECK (record_type = 'command'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    action_json TEXT NOT NULL
      CHECK (
        length(action_json) BETWEEN 2 AND 262144
        AND json_valid(action_json)
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home <> entity_home),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_facts (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'fact'
      CHECK (record_type = 'fact'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    result_json TEXT NOT NULL
      CHECK (
        length(result_json) BETWEEN 2 AND 262144
        AND json_valid(result_json)
      ),
    basis_kind TEXT NOT NULL
      CHECK (
        basis_kind IN (
          'authorial-intent',
          'projected-intent',
          'command'
        )
      ),
    basis_authorial_generation TEXT
      CHECK (
        basis_authorial_generation IS NULL
        OR (
          length(basis_authorial_generation) BETWEEN 1 AND 32
          AND basis_authorial_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_authorial_generation = '0'
            OR substr(basis_authorial_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_authorial_content_sha256 TEXT
      CHECK (
        basis_authorial_content_sha256 IS NULL
        OR (
          length(basis_authorial_content_sha256) = 64
          AND basis_authorial_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_projected_generation TEXT
      CHECK (
        basis_projected_generation IS NULL
        OR (
          length(basis_projected_generation) BETWEEN 1 AND 32
          AND basis_projected_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_projected_generation = '0'
            OR substr(basis_projected_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_projected_content_sha256 TEXT
      CHECK (
        basis_projected_content_sha256 IS NULL
        OR (
          length(basis_projected_content_sha256) = 64
          AND basis_projected_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_command_event_home TEXT,
    basis_command_entity_home TEXT,
    basis_command_seq TEXT
      CHECK (
        basis_command_seq IS NULL
        OR (
          length(basis_command_seq) BETWEEN 1 AND 32
          AND basis_command_seq NOT GLOB '*[^0-9]*'
          AND substr(basis_command_seq, 1, 1) <> '0'
        )
      ),
    basis_command_sha256 TEXT
      CHECK (
        basis_command_sha256 IS NULL
        OR (
          length(basis_command_sha256) = 64
          AND basis_command_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home = entity_home),
    CHECK (
      (
        basis_kind = 'authorial-intent'
        AND basis_authorial_generation IS NOT NULL
        AND basis_authorial_content_sha256 IS NOT NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'projected-intent'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NOT NULL
        AND basis_projected_content_sha256 IS NOT NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'command'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NOT NULL
        AND basis_command_entity_home IS NOT NULL
        AND basis_command_seq IS NOT NULL
        AND basis_command_sha256 IS NOT NULL
        AND basis_command_entity_home = entity_home
      )
    ),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (basis_authorial_generation)
      REFERENCES canvas_generations(generation)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_projected_generation,
      basis_projected_content_sha256
    ) REFERENCES station_projection_versions(generation, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq
    ) REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq,
      basis_command_sha256
    ) REFERENCES work_events(
      event_home,
      entity_home,
      seq,
      content_sha256
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_dispositions (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'disposition'
      CHECK (record_type = 'disposition'),
    status TEXT NOT NULL CHECK (status IN ('applied', 'rejected')),
    command_event_home TEXT NOT NULL,
    command_entity_home TEXT NOT NULL,
    command_seq TEXT NOT NULL,
    command_sha256 TEXT NOT NULL
      CHECK (
        length(command_sha256) = 64
        AND command_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT,
    fact_entity_home TEXT,
    fact_seq TEXT,
    fact_sha256 TEXT
      CHECK (
        fact_sha256 IS NULL
        OR (
          length(fact_sha256) = 64
          AND fact_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    rejection_reason TEXT
      CHECK (
        rejection_reason IS NULL
        OR rejection_reason IN (
          'authority-mismatch',
          'capability-denied',
          'causal-conflict',
          'claim-contention',
          'identity-conflict',
          'invalid-transition',
          'locality-mismatch',
          'missing-entity',
          'projection-conflict',
          'target-mismatch'
        )
      ),
    rejection_message TEXT
      CHECK (
        rejection_message IS NULL
        OR length(rejection_message) BETWEEN 1 AND 2048
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, status),
    CHECK (event_home = entity_home),
    CHECK (command_entity_home = entity_home),
    CHECK (
      (
        status = 'applied'
        AND fact_event_home IS NOT NULL
        AND fact_entity_home IS NOT NULL
        AND fact_seq IS NOT NULL
        AND fact_sha256 IS NOT NULL
        AND fact_event_home = event_home
        AND fact_entity_home = entity_home
        AND rejection_reason IS NULL
        AND rejection_message IS NULL
      )
      OR
      (
        status = 'rejected'
        AND fact_event_home IS NULL
        AND fact_entity_home IS NULL
        AND fact_seq IS NULL
        AND fact_sha256 IS NULL
        AND rejection_reason IS NOT NULL
        AND rejection_message IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (command_event_home, command_entity_home, command_seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      command_event_home,
      command_entity_home,
      command_seq,
      command_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      fact_event_home,
      fact_entity_home,
      fact_seq,
      fact_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    claim_actor_seat_id TEXT
      CHECK (
        claim_actor_seat_id IS NULL
        OR (
          length(claim_actor_seat_id) = 69
          AND substr(claim_actor_seat_id, 1, 5) = 'seat_'
          AND substr(claim_actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT
      CHECK (resolved_at IS NULL OR length(resolved_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        operation = 'task.claim'
        AND item_kind = 'task'
        AND claim_actor_seat_id IS NOT NULL
      )
      OR
      (
        operation <> 'task.claim'
        AND claim_actor_seat_id IS NULL
      )
    ),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      resolution_event_home,
      resolution_entity_home,
      resolution_seq,
      resolution_status
    ) REFERENCES work_dispositions(event_home, entity_home, seq, status)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_tasks (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    task_id TEXT NOT NULL CHECK (length(task_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, task_id),
    UNIQUE (canvas_name, node_id, task_id, entity_home),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'submitted' AND actor_seat_id IS NULL)
      OR state IN ('completed', 'canceled', 'failed', 'rejected')
      OR (
        state IN ('working', 'input-required', 'auth-required')
        AND actor_seat_id IS NOT NULL
      )
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_requests (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    request_id TEXT NOT NULL CHECK (length(request_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'input-required',
          'auth-required',
          'completed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, request_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    parent_lane TEXT NOT NULL CHECK (parent_lane IN ('task', 'request')),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    message_kind TEXT NOT NULL CHECK (message_kind IN ('brief', 'history')),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      message_id
    ),
    UNIQUE (canvas_name, node_id, parent_lane, item_id, position),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, message_id),
    UNIQUE (canvas_name, node_id, position),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_artifacts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    artifact_id TEXT NOT NULL CHECK (length(artifact_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    name TEXT,
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_canvas_name TEXT
      CHECK (
        task_canvas_name IS NULL
        OR length(task_canvas_name) BETWEEN 1 AND 256
      ),
    task_node_id TEXT
      CHECK (
        task_node_id IS NULL
        OR length(task_node_id) BETWEEN 1 AND 256
      ),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    task_entity_home TEXT,
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, artifact_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (
        task_canvas_name IS NULL
        AND task_node_id IS NULL
        AND task_id IS NULL
        AND task_entity_home IS NULL
      )
      OR
      (
        task_canvas_name IS NOT NULL
        AND task_node_id IS NOT NULL
        AND task_id IS NOT NULL
        AND task_entity_home IS NOT NULL
      )
    ),
    CHECK (
      task_entity_home IS NULL
      OR task_entity_home = entity_home
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      task_canvas_name,
      task_node_id,
      task_id,
      task_entity_home
    ) REFERENCES work_tasks(
      canvas_name,
      node_id,
      task_id,
      entity_home
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_transitions (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    lane TEXT NOT NULL CHECK (lane IN ('task', 'request')),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve'
        )
      ),
    from_state TEXT,
    to_state TEXT NOT NULL
      CHECK (
        to_state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, item_id, lane, ordinal),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (
      from_state IS NULL
      OR from_state IN (
        'submitted',
        'working',
        'input-required',
        'auth-required',
        'completed',
        'canceled',
        'failed',
        'rejected'
      )
    ),
    CHECK (
      to_state NOT IN ('working', 'input-required', 'auth-required')
      OR actor_seat_id IS NOT NULL
    ),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_delivery_receipts (
    delivery_id TEXT NOT NULL CHECK (length(delivery_id) BETWEEN 1 AND 256),
    delivered_item_kind TEXT NOT NULL
      CHECK (
        delivered_item_kind IN (
          'task',
          'request',
          'message',
          'artifact',
          'delivery'
        )
      ),
    delivered_item_id TEXT NOT NULL
      CHECK (length(delivered_item_id) BETWEEN 1 AND 256),
    delivered_canvas_name TEXT NOT NULL
      CHECK (length(delivered_canvas_name) BETWEEN 1 AND 256),
    delivered_node_id TEXT NOT NULL
      CHECK (length(delivered_node_id) BETWEEN 1 AND 256),
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    actor_canvas_name TEXT NOT NULL
      CHECK (length(actor_canvas_name) BETWEEN 1 AND 256),
    actor_node_id TEXT NOT NULL
      CHECK (length(actor_node_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    accepted_at TEXT NOT NULL CHECK (length(accepted_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      delivered_canvas_name,
      delivered_node_id,
      delivery_id
    ),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_events_route_order
    ON work_events(event_home, entity_home, length(seq), seq);
  CREATE INDEX IF NOT EXISTS work_events_item_history
    ON work_events(
      item_canvas_name,
      item_node_id,
      item_kind,
      item_id,
      entity_home,
      length(seq),
      seq
    );
  CREATE INDEX IF NOT EXISTS work_pending_commands_route
    ON work_pending_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_item
    ON work_pending_commands(
      item_canvas_name,
      item_node_id,
      item_id
    )
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_actor
    ON work_pending_commands(claim_actor_seat_id)
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE INDEX IF NOT EXISTS work_tasks_node
    ON work_tasks(canvas_name, node_id, created_at, task_id);
  CREATE UNIQUE INDEX IF NOT EXISTS work_tasks_one_active_per_actor
    ON work_tasks(actor_seat_id)
    WHERE
      actor_seat_id IS NOT NULL
      AND state IN ('working', 'input-required', 'auth-required');
  CREATE INDEX IF NOT EXISTS work_requests_node
    ON work_requests(canvas_name, node_id, created_at, request_id);
  CREATE INDEX IF NOT EXISTS work_task_messages_thread
    ON work_task_messages(
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      position
    );
  CREATE UNIQUE INDEX IF NOT EXISTS work_task_messages_sink_identity
    ON work_task_messages(canvas_name, node_id, message_id);
  CREATE INDEX IF NOT EXISTS work_messages_inbox
    ON work_messages(canvas_name, node_id, position);
  CREATE INDEX IF NOT EXISTS work_artifacts_node
    ON work_artifacts(canvas_name, node_id, artifact_id);
  CREATE INDEX IF NOT EXISTS work_delivery_receipts_actor
    ON work_delivery_receipts(
      actor_seat_id,
      accepted_at,
      delivery_id
    );

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_update
  BEFORE UPDATE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_delete
  BEFORE DELETE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_update
  BEFORE UPDATE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_delete
  BEFORE DELETE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_fact_authorial_basis_resolves
  BEFORE INSERT ON work_facts
  WHEN
    NEW.basis_kind = 'authorial-intent'
    AND NOT EXISTS (
      SELECT 1
      FROM canvas_generations AS generation
      JOIN canvas_generation_documents AS document
        ON document.generation = generation.generation
      JOIN work_events AS record
        ON record.event_home = NEW.event_home
        AND record.entity_home = NEW.entity_home
        AND record.seq = NEW.seq
      WHERE generation.generation = NEW.basis_authorial_generation
        AND generation.intent_sha256 =
          NEW.basis_authorial_content_sha256
        AND document.name = record.item_canvas_name
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'authorial fact basis must resolve its exact sink canvas generation'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_update
  BEFORE UPDATE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_delete
  BEFORE DELETE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_applied_disposition_fact_basis_matches
  BEFORE INSERT ON work_dispositions
  WHEN
    NEW.status = 'applied'
    AND NOT EXISTS (
      SELECT 1
      FROM work_facts AS fact
      WHERE fact.event_home = NEW.fact_event_home
        AND fact.entity_home = NEW.fact_entity_home
        AND fact.seq = NEW.fact_seq
        AND fact.basis_kind = 'command'
        AND fact.basis_command_event_home = NEW.command_event_home
        AND fact.basis_command_entity_home = NEW.command_entity_home
        AND fact.basis_command_seq = NEW.command_seq
        AND fact.basis_command_sha256 = NEW.command_sha256
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'applied disposition fact must carry its exact command basis'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_update
  BEFORE UPDATE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_delete
  BEFORE DELETE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_matches_record
  BEFORE INSERT ON work_pending_commands
  WHEN NOT EXISTS (
    SELECT 1
    FROM work_events AS record
    WHERE record.event_home = NEW.event_home
      AND record.entity_home = NEW.entity_home
      AND record.seq = NEW.seq
      AND record.record_type = 'command'
      AND record.operation = NEW.operation
      AND record.item_kind = NEW.item_kind
      AND record.item_canvas_name = NEW.item_canvas_name
      AND record.item_node_id = NEW.item_node_id
      AND record.item_id = NEW.item_id
  )
  BEGIN
    SELECT RAISE(ABORT, 'pending command metadata must match its Work command');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_identity_immutable
  BEFORE UPDATE OF
    event_home,
    entity_home,
    seq,
    operation,
    item_kind,
    item_canvas_name,
    item_node_id,
    item_id,
    claim_actor_seat_id
  ON work_pending_commands
  WHEN
    OLD.event_home IS NOT NEW.event_home
    OR OLD.entity_home IS NOT NEW.entity_home
    OR OLD.seq IS NOT NEW.seq
    OR OLD.operation IS NOT NEW.operation
    OR OLD.item_kind IS NOT NEW.item_kind
    OR OLD.item_canvas_name IS NOT NEW.item_canvas_name
    OR OLD.item_node_id IS NOT NEW.item_node_id
    OR OLD.item_id IS NOT NEW.item_id
    OR OLD.claim_actor_seat_id IS NOT NEW.claim_actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'pending command identity is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_initial_resolution_matches
  BEFORE INSERT ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = NEW.event_home
        AND disposition.command_entity_home = NEW.entity_home
        AND disposition.command_seq = NEW.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_matches
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = OLD.event_home
        AND disposition.command_entity_home = OLD.entity_home
        AND disposition.command_seq = OLD.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_once
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    OLD.resolution_event_home IS NOT NULL
    AND (
      OLD.resolution_status IS NOT NEW.resolution_status
      OR OLD.resolution_event_home IS NOT NEW.resolution_event_home
      OR OLD.resolution_entity_home IS NOT NEW.resolution_entity_home
      OR OLD.resolution_seq IS NOT NEW.resolution_seq
      OR OLD.resolved_at IS NOT NEW.resolved_at
    )
  BEGIN
    SELECT RAISE(ABORT, 'pending command resolution is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_home_immutable
  BEFORE UPDATE OF entity_home ON work_tasks
  WHEN
    OLD.entity_home <> NEW.entity_home
    AND NOT (
      OLD.state = 'submitted'
      AND OLD.actor_seat_id IS NULL
      AND NEW.state = 'working'
      AND NEW.actor_seat_id IS NOT NULL
      AND NEW.entity_home = NEW.fact_entity_home
      AND NEW.fact_event_home = NEW.fact_entity_home
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task home is immutable except for first claim adoption'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_tasks
  WHEN
    OLD.actor_seat_id IS NOT NULL
    AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
    AND NOT (
      NEW.actor_seat_id IS NULL
      AND NEW.state = 'submitted'
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task actor seat is immutable except for operator release'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_home_immutable
  BEFORE UPDATE OF entity_home ON work_requests
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work request home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_requests
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work request actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work task message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_require_exact_parent
  BEFORE INSERT ON work_task_messages
  WHEN NOT (
    (
      NEW.parent_lane = 'task'
      AND EXISTS (
        SELECT 1
        FROM work_tasks
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND task_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
    OR
    (
      NEW.parent_lane = 'request'
      AND EXISTS (
        SELECT 1
        FROM work_requests
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND request_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
  )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task message requires an exact same-home parent'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_require_cc_home
  BEFORE INSERT ON work_messages
  WHEN
    NOT EXISTS (
      SELECT 1
      FROM station_configuration AS configuration
      JOIN station_installation AS installation
        ON installation.singleton = configuration.singleton
      WHERE configuration.singleton = 1
        AND configuration.role = 'command-center'
        AND NEW.entity_home = installation.installation_id
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work mailbox messages must be Command Center-homed'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_messages
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work message actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_home_immutable
  BEFORE UPDATE OF entity_home ON work_artifacts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_artifacts
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work artifact actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_require_claimed_task
  BEFORE INSERT ON work_artifacts
  WHEN
    NEW.task_id IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
    )
    AND NOT EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
        AND actor_seat_id IS NOT NULL
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work artifact requires an exact claimed same-home task'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_task_reference_immutable
  BEFORE UPDATE OF
    task_canvas_name,
    task_node_id,
    task_id,
    task_entity_home
  ON work_artifacts
  WHEN
    OLD.task_canvas_name IS NOT NEW.task_canvas_name
    OR OLD.task_node_id IS NOT NEW.task_node_id
    OR OLD.task_id IS NOT NEW.task_id
    OR OLD.task_entity_home IS NOT NEW.task_entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact task reference is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_transitions_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_transitions
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work transition home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_delivery_receipts_home_immutable
  BEFORE UPDATE OF entity_home ON work_delivery_receipts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work delivery receipt home is immutable');
  END;
  
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;

`.replaceAll("item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')","item_kind IN ('task', 'request', 'message', 'artifact', 'delivery', 'topic', 'post')").replaceAll(`'delivery.accepted'
        )`,`'delivery.accepted',
          'board.topic.create',
          'board.post.append'
        )`),GD=R5.replaceAll("operation IN ('proposal.create', 'proposal.approve')","operation IN ('proposal.create', 'proposal.approve', 'proposal.reject')"),o9=GD.replaceAll(`'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, task_id),`,`'completed',
          'canceled',
          'failed',
          'rejected',
          'archived'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, task_id),`).replaceAll("OR state IN ('completed', 'canceled', 'failed', 'rejected')","OR state IN ('completed', 'canceled', 'failed', 'rejected', 'archived')").replaceAll(`to_state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )`,`to_state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected',
          'archived'
        )`).replaceAll(`from_state IN (
        'submitted',
        'working',
        'input-required',
        'auth-required',
        'completed',
        'canceled',
        'failed',
        'rejected'
      )`,`from_state IN (
        'submitted',
        'working',
        'input-required',
        'auth-required',
        'completed',
        'canceled',
        'failed',
        'rejected',
        'archived'
      )`),nx=`
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;
`.replaceAll("operation IN ('proposal.create', 'proposal.approve')","operation IN ('proposal.create', 'proposal.approve', 'proposal.reject')"),ZD=`
  CREATE TABLE IF NOT EXISTS work_event_sequences (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    last_seq TEXT NOT NULL
      CHECK (
        length(last_seq) BETWEEN 1 AND 32
        AND last_seq NOT GLOB '*[^0-9]*'
        AND (last_seq = '0' OR substr(last_seq, 1, 1) <> '0')
      ),
    PRIMARY KEY (event_home, entity_home),
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    protocol TEXT NOT NULL CHECK (protocol = 'vellum/work/v2'),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, record_type),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'command'
      CHECK (record_type = 'command'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    action_json TEXT NOT NULL
      CHECK (
        length(action_json) BETWEEN 2 AND 262144
        AND json_valid(action_json)
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home <> entity_home),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_facts (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'fact'
      CHECK (record_type = 'fact'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    result_json TEXT NOT NULL
      CHECK (
        length(result_json) BETWEEN 2 AND 262144
        AND json_valid(result_json)
      ),
    basis_kind TEXT NOT NULL
      CHECK (
        basis_kind IN (
          'authorial-intent',
          'projected-intent',
          'command'
        )
      ),
    basis_authorial_generation TEXT
      CHECK (
        basis_authorial_generation IS NULL
        OR (
          length(basis_authorial_generation) BETWEEN 1 AND 32
          AND basis_authorial_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_authorial_generation = '0'
            OR substr(basis_authorial_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_authorial_content_sha256 TEXT
      CHECK (
        basis_authorial_content_sha256 IS NULL
        OR (
          length(basis_authorial_content_sha256) = 64
          AND basis_authorial_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_projected_generation TEXT
      CHECK (
        basis_projected_generation IS NULL
        OR (
          length(basis_projected_generation) BETWEEN 1 AND 32
          AND basis_projected_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_projected_generation = '0'
            OR substr(basis_projected_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_projected_content_sha256 TEXT
      CHECK (
        basis_projected_content_sha256 IS NULL
        OR (
          length(basis_projected_content_sha256) = 64
          AND basis_projected_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_command_event_home TEXT,
    basis_command_entity_home TEXT,
    basis_command_seq TEXT
      CHECK (
        basis_command_seq IS NULL
        OR (
          length(basis_command_seq) BETWEEN 1 AND 32
          AND basis_command_seq NOT GLOB '*[^0-9]*'
          AND substr(basis_command_seq, 1, 1) <> '0'
        )
      ),
    basis_command_sha256 TEXT
      CHECK (
        basis_command_sha256 IS NULL
        OR (
          length(basis_command_sha256) = 64
          AND basis_command_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home = entity_home),
    CHECK (
      (
        basis_kind = 'authorial-intent'
        AND basis_authorial_generation IS NOT NULL
        AND basis_authorial_content_sha256 IS NOT NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'projected-intent'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NOT NULL
        AND basis_projected_content_sha256 IS NOT NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'command'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NOT NULL
        AND basis_command_entity_home IS NOT NULL
        AND basis_command_seq IS NOT NULL
        AND basis_command_sha256 IS NOT NULL
        AND basis_command_entity_home = entity_home
      )
    ),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (basis_authorial_generation)
      REFERENCES canvas_generations(generation)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_projected_generation,
      basis_projected_content_sha256
    ) REFERENCES station_projection_versions(generation, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq
    ) REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq,
      basis_command_sha256
    ) REFERENCES work_events(
      event_home,
      entity_home,
      seq,
      content_sha256
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_dispositions (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'disposition'
      CHECK (record_type = 'disposition'),
    status TEXT NOT NULL CHECK (status IN ('applied', 'rejected')),
    command_event_home TEXT NOT NULL,
    command_entity_home TEXT NOT NULL,
    command_seq TEXT NOT NULL,
    command_sha256 TEXT NOT NULL
      CHECK (
        length(command_sha256) = 64
        AND command_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT,
    fact_entity_home TEXT,
    fact_seq TEXT,
    fact_sha256 TEXT
      CHECK (
        fact_sha256 IS NULL
        OR (
          length(fact_sha256) = 64
          AND fact_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    rejection_reason TEXT
      CHECK (
        rejection_reason IS NULL
        OR rejection_reason IN (
          'authority-mismatch',
          'capability-denied',
          'causal-conflict',
          'claim-contention',
          'identity-conflict',
          'invalid-transition',
          'locality-mismatch',
          'missing-entity',
          'projection-conflict',
          'target-mismatch'
        )
      ),
    rejection_message TEXT
      CHECK (
        rejection_message IS NULL
        OR length(rejection_message) BETWEEN 1 AND 2048
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, status),
    CHECK (event_home = entity_home),
    CHECK (command_entity_home = entity_home),
    CHECK (
      (
        status = 'applied'
        AND fact_event_home IS NOT NULL
        AND fact_entity_home IS NOT NULL
        AND fact_seq IS NOT NULL
        AND fact_sha256 IS NOT NULL
        AND fact_event_home = event_home
        AND fact_entity_home = entity_home
        AND rejection_reason IS NULL
        AND rejection_message IS NULL
      )
      OR
      (
        status = 'rejected'
        AND fact_event_home IS NULL
        AND fact_entity_home IS NULL
        AND fact_seq IS NULL
        AND fact_sha256 IS NULL
        AND rejection_reason IS NOT NULL
        AND rejection_message IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (command_event_home, command_entity_home, command_seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      command_event_home,
      command_entity_home,
      command_seq,
      command_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      fact_event_home,
      fact_entity_home,
      fact_seq,
      fact_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    claim_actor_seat_id TEXT
      CHECK (
        claim_actor_seat_id IS NULL
        OR (
          length(claim_actor_seat_id) = 69
          AND substr(claim_actor_seat_id, 1, 5) = 'seat_'
          AND substr(claim_actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT
      CHECK (resolved_at IS NULL OR length(resolved_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        operation = 'task.claim'
        AND item_kind = 'task'
        AND claim_actor_seat_id IS NOT NULL
      )
      OR
      (
        operation <> 'task.claim'
        AND claim_actor_seat_id IS NULL
      )
    ),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      resolution_event_home,
      resolution_entity_home,
      resolution_seq,
      resolution_status
    ) REFERENCES work_dispositions(event_home, entity_home, seq, status)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_tasks (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    task_id TEXT NOT NULL CHECK (length(task_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, task_id),
    UNIQUE (canvas_name, node_id, task_id, entity_home),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'submitted' AND actor_seat_id IS NULL)
      OR state IN ('completed', 'canceled', 'failed', 'rejected')
      OR (
        state IN ('working', 'input-required', 'auth-required')
        AND actor_seat_id IS NOT NULL
      )
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_requests (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    request_id TEXT NOT NULL CHECK (length(request_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'input-required',
          'auth-required',
          'completed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, request_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    parent_lane TEXT NOT NULL CHECK (parent_lane IN ('task', 'request')),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    message_kind TEXT NOT NULL CHECK (message_kind IN ('brief', 'history')),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      message_id
    ),
    UNIQUE (canvas_name, node_id, parent_lane, item_id, position),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, message_id),
    UNIQUE (canvas_name, node_id, position),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_artifacts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    artifact_id TEXT NOT NULL CHECK (length(artifact_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    name TEXT,
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_canvas_name TEXT
      CHECK (
        task_canvas_name IS NULL
        OR length(task_canvas_name) BETWEEN 1 AND 256
      ),
    task_node_id TEXT
      CHECK (
        task_node_id IS NULL
        OR length(task_node_id) BETWEEN 1 AND 256
      ),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    task_entity_home TEXT,
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, artifact_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (
        task_canvas_name IS NULL
        AND task_node_id IS NULL
        AND task_id IS NULL
        AND task_entity_home IS NULL
      )
      OR
      (
        task_canvas_name IS NOT NULL
        AND task_node_id IS NOT NULL
        AND task_id IS NOT NULL
        AND task_entity_home IS NOT NULL
      )
    ),
    CHECK (
      task_entity_home IS NULL
      OR task_entity_home = entity_home
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      task_canvas_name,
      task_node_id,
      task_id,
      task_entity_home
    ) REFERENCES work_tasks(
      canvas_name,
      node_id,
      task_id,
      entity_home
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_transitions (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    lane TEXT NOT NULL CHECK (lane IN ('task', 'request')),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve'
        )
      ),
    from_state TEXT,
    to_state TEXT NOT NULL
      CHECK (
        to_state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, item_id, lane, ordinal),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (
      from_state IS NULL
      OR from_state IN (
        'submitted',
        'working',
        'input-required',
        'auth-required',
        'completed',
        'canceled',
        'failed',
        'rejected'
      )
    ),
    CHECK (
      to_state NOT IN ('working', 'input-required', 'auth-required')
      OR actor_seat_id IS NOT NULL
    ),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_delivery_receipts (
    delivery_id TEXT NOT NULL CHECK (length(delivery_id) BETWEEN 1 AND 256),
    delivered_item_kind TEXT NOT NULL
      CHECK (
        delivered_item_kind IN (
          'task',
          'request',
          'message',
          'artifact',
          'delivery'
        )
      ),
    delivered_item_id TEXT NOT NULL
      CHECK (length(delivered_item_id) BETWEEN 1 AND 256),
    delivered_canvas_name TEXT NOT NULL
      CHECK (length(delivered_canvas_name) BETWEEN 1 AND 256),
    delivered_node_id TEXT NOT NULL
      CHECK (length(delivered_node_id) BETWEEN 1 AND 256),
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    actor_canvas_name TEXT NOT NULL
      CHECK (length(actor_canvas_name) BETWEEN 1 AND 256),
    actor_node_id TEXT NOT NULL
      CHECK (length(actor_node_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    accepted_at TEXT NOT NULL CHECK (length(accepted_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      delivered_canvas_name,
      delivered_node_id,
      delivery_id
    ),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_events_route_order
    ON work_events(event_home, entity_home, length(seq), seq);
  CREATE INDEX IF NOT EXISTS work_events_item_history
    ON work_events(
      item_canvas_name,
      item_node_id,
      item_kind,
      item_id,
      entity_home,
      length(seq),
      seq
    );
  CREATE INDEX IF NOT EXISTS work_pending_commands_route
    ON work_pending_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_item
    ON work_pending_commands(
      item_canvas_name,
      item_node_id,
      item_id
    )
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_actor
    ON work_pending_commands(claim_actor_seat_id)
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE INDEX IF NOT EXISTS work_tasks_node
    ON work_tasks(canvas_name, node_id, created_at, task_id);
  CREATE UNIQUE INDEX IF NOT EXISTS work_tasks_one_active_per_actor
    ON work_tasks(actor_seat_id)
    WHERE
      actor_seat_id IS NOT NULL
      AND state IN ('working', 'input-required', 'auth-required');
  CREATE INDEX IF NOT EXISTS work_requests_node
    ON work_requests(canvas_name, node_id, created_at, request_id);
  CREATE INDEX IF NOT EXISTS work_task_messages_thread
    ON work_task_messages(
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      position
    );
  CREATE UNIQUE INDEX IF NOT EXISTS work_task_messages_sink_identity
    ON work_task_messages(canvas_name, node_id, message_id);
  CREATE INDEX IF NOT EXISTS work_messages_inbox
    ON work_messages(canvas_name, node_id, position);
  CREATE INDEX IF NOT EXISTS work_artifacts_node
    ON work_artifacts(canvas_name, node_id, artifact_id);
  CREATE INDEX IF NOT EXISTS work_delivery_receipts_actor
    ON work_delivery_receipts(
      actor_seat_id,
      accepted_at,
      delivery_id
    );

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_update
  BEFORE UPDATE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_delete
  BEFORE DELETE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_update
  BEFORE UPDATE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_delete
  BEFORE DELETE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_fact_authorial_basis_resolves
  BEFORE INSERT ON work_facts
  WHEN
    NEW.basis_kind = 'authorial-intent'
    AND NOT EXISTS (
      SELECT 1
      FROM canvas_generations AS generation
      JOIN canvas_generation_documents AS document
        ON document.generation = generation.generation
      JOIN work_events AS record
        ON record.event_home = NEW.event_home
        AND record.entity_home = NEW.entity_home
        AND record.seq = NEW.seq
      WHERE generation.generation = NEW.basis_authorial_generation
        AND generation.intent_sha256 =
          NEW.basis_authorial_content_sha256
        AND document.name = record.item_canvas_name
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'authorial fact basis must resolve its exact sink canvas generation'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_update
  BEFORE UPDATE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_delete
  BEFORE DELETE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_applied_disposition_fact_basis_matches
  BEFORE INSERT ON work_dispositions
  WHEN
    NEW.status = 'applied'
    AND NOT EXISTS (
      SELECT 1
      FROM work_facts AS fact
      WHERE fact.event_home = NEW.fact_event_home
        AND fact.entity_home = NEW.fact_entity_home
        AND fact.seq = NEW.fact_seq
        AND fact.basis_kind = 'command'
        AND fact.basis_command_event_home = NEW.command_event_home
        AND fact.basis_command_entity_home = NEW.command_entity_home
        AND fact.basis_command_seq = NEW.command_seq
        AND fact.basis_command_sha256 = NEW.command_sha256
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'applied disposition fact must carry its exact command basis'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_update
  BEFORE UPDATE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_delete
  BEFORE DELETE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_matches_record
  BEFORE INSERT ON work_pending_commands
  WHEN NOT EXISTS (
    SELECT 1
    FROM work_events AS record
    WHERE record.event_home = NEW.event_home
      AND record.entity_home = NEW.entity_home
      AND record.seq = NEW.seq
      AND record.record_type = 'command'
      AND record.operation = NEW.operation
      AND record.item_kind = NEW.item_kind
      AND record.item_canvas_name = NEW.item_canvas_name
      AND record.item_node_id = NEW.item_node_id
      AND record.item_id = NEW.item_id
  )
  BEGIN
    SELECT RAISE(ABORT, 'pending command metadata must match its Work command');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_identity_immutable
  BEFORE UPDATE OF
    event_home,
    entity_home,
    seq,
    operation,
    item_kind,
    item_canvas_name,
    item_node_id,
    item_id,
    claim_actor_seat_id
  ON work_pending_commands
  WHEN
    OLD.event_home IS NOT NEW.event_home
    OR OLD.entity_home IS NOT NEW.entity_home
    OR OLD.seq IS NOT NEW.seq
    OR OLD.operation IS NOT NEW.operation
    OR OLD.item_kind IS NOT NEW.item_kind
    OR OLD.item_canvas_name IS NOT NEW.item_canvas_name
    OR OLD.item_node_id IS NOT NEW.item_node_id
    OR OLD.item_id IS NOT NEW.item_id
    OR OLD.claim_actor_seat_id IS NOT NEW.claim_actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'pending command identity is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_initial_resolution_matches
  BEFORE INSERT ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = NEW.event_home
        AND disposition.command_entity_home = NEW.entity_home
        AND disposition.command_seq = NEW.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_matches
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = OLD.event_home
        AND disposition.command_entity_home = OLD.entity_home
        AND disposition.command_seq = OLD.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_once
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    OLD.resolution_event_home IS NOT NULL
    AND (
      OLD.resolution_status IS NOT NEW.resolution_status
      OR OLD.resolution_event_home IS NOT NEW.resolution_event_home
      OR OLD.resolution_entity_home IS NOT NEW.resolution_entity_home
      OR OLD.resolution_seq IS NOT NEW.resolution_seq
      OR OLD.resolved_at IS NOT NEW.resolved_at
    )
  BEGIN
    SELECT RAISE(ABORT, 'pending command resolution is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_home_immutable
  BEFORE UPDATE OF entity_home ON work_tasks
  WHEN
    OLD.entity_home <> NEW.entity_home
    AND NOT (
      OLD.state = 'submitted'
      AND OLD.actor_seat_id IS NULL
      AND NEW.state = 'working'
      AND NEW.actor_seat_id IS NOT NULL
      AND NEW.entity_home = NEW.fact_entity_home
      AND NEW.fact_event_home = NEW.fact_entity_home
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task home is immutable except for first claim adoption'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_tasks
  WHEN
    OLD.actor_seat_id IS NOT NULL
    AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
    AND NOT (
      NEW.actor_seat_id IS NULL
      AND NEW.state = 'submitted'
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task actor seat is immutable except for operator release'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_home_immutable
  BEFORE UPDATE OF entity_home ON work_requests
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work request home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_requests
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work request actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work task message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_require_exact_parent
  BEFORE INSERT ON work_task_messages
  WHEN NOT (
    (
      NEW.parent_lane = 'task'
      AND EXISTS (
        SELECT 1
        FROM work_tasks
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND task_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
    OR
    (
      NEW.parent_lane = 'request'
      AND EXISTS (
        SELECT 1
        FROM work_requests
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND request_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
  )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task message requires an exact same-home parent'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_require_cc_home
  BEFORE INSERT ON work_messages
  WHEN
    NOT EXISTS (
      SELECT 1
      FROM station_configuration AS configuration
      JOIN station_installation AS installation
        ON installation.singleton = configuration.singleton
      WHERE configuration.singleton = 1
        AND configuration.role = 'command-center'
        AND NEW.entity_home = installation.installation_id
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work mailbox messages must be Command Center-homed'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_messages
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work message actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_home_immutable
  BEFORE UPDATE OF entity_home ON work_artifacts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_artifacts
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work artifact actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_require_claimed_task
  BEFORE INSERT ON work_artifacts
  WHEN
    NEW.task_id IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
    )
    AND NOT EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
        AND actor_seat_id IS NOT NULL
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work artifact requires an exact claimed same-home task'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_task_reference_immutable
  BEFORE UPDATE OF
    task_canvas_name,
    task_node_id,
    task_id,
    task_entity_home
  ON work_artifacts
  WHEN
    OLD.task_canvas_name IS NOT NEW.task_canvas_name
    OR OLD.task_node_id IS NOT NEW.task_node_id
    OR OLD.task_id IS NOT NEW.task_id
    OR OLD.task_entity_home IS NOT NEW.task_entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact task reference is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_transitions_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_transitions
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work transition home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_delivery_receipts_home_immutable
  BEFORE UPDATE OF entity_home ON work_delivery_receipts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work delivery receipt home is immutable');
  END;
  
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;

`.replace(`  
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;

`,"").replace(`  CREATE TRIGGER IF NOT EXISTS work_tasks_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_tasks
  WHEN
    OLD.actor_seat_id IS NOT NULL
    AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
    AND NOT (
      NEW.actor_seat_id IS NULL
      AND NEW.state = 'submitted'
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task actor seat is immutable except for operator release'
    );
  END;`,`  CREATE TRIGGER IF NOT EXISTS work_tasks_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_tasks
  WHEN
    OLD.actor_seat_id IS NOT NULL
    AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work task actor seat is immutable after first claim');
  END;`),A_=`
  CREATE TABLE IF NOT EXISTS work_pad_meta (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    revision INTEGER NOT NULL CHECK (revision >= 0),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_images (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    element_id TEXT NOT NULL CHECK (length(element_id) BETWEEN 1 AND 256),
    x REAL NOT NULL,
    y REAL NOT NULL,
    w REAL NOT NULL CHECK (w > 0),
    h REAL NOT NULL CHECK (h > 0),
    z INTEGER NOT NULL,
    ref_json TEXT NOT NULL CHECK (json_valid(ref_json)),
    PRIMARY KEY (canvas_name, node_id, element_id),
    FOREIGN KEY (canvas_name, node_id)
      REFERENCES work_pad_meta(canvas_name, node_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_shapes (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    element_id TEXT NOT NULL CHECK (length(element_id) BETWEEN 1 AND 256),
    type TEXT NOT NULL CHECK (type IN ('box', 'ellipse', 'triangle', 'label')),
    x REAL NOT NULL,
    y REAL NOT NULL,
    w REAL NOT NULL CHECK (w > 0),
    h REAL NOT NULL CHECK (h > 0),
    z INTEGER NOT NULL,
    fill TEXT CHECK (fill IS NULL OR length(fill) BETWEEN 1 AND 256),
    stroke TEXT CHECK (stroke IS NULL OR length(stroke) BETWEEN 1 AND 256),
    text TEXT CHECK (text IS NULL OR length(text) >= 1),
    status TEXT CHECK (
      status IS NULL OR status IN ('none', 'active', 'done', 'blocked')
    ),
    PRIMARY KEY (canvas_name, node_id, element_id),
    FOREIGN KEY (canvas_name, node_id)
      REFERENCES work_pad_meta(canvas_name, node_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_edges (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    element_id TEXT NOT NULL CHECK (length(element_id) BETWEEN 1 AND 256),
    from_id TEXT NOT NULL CHECK (length(from_id) BETWEEN 1 AND 256),
    to_id TEXT NOT NULL CHECK (length(to_id) BETWEEN 1 AND 256),
    from_side TEXT CHECK (
      from_side IS NULL OR from_side IN ('top', 'right', 'bottom', 'left')
    ),
    to_side TEXT CHECK (
      to_side IS NULL OR to_side IN ('top', 'right', 'bottom', 'left')
    ),
    label TEXT CHECK (label IS NULL OR length(label) >= 1),
    PRIMARY KEY (canvas_name, node_id, element_id),
    FOREIGN KEY (canvas_name, node_id)
      REFERENCES work_pad_meta(canvas_name, node_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_inks (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    element_id TEXT NOT NULL CHECK (length(element_id) BETWEEN 1 AND 256),
    z INTEGER NOT NULL,
    color TEXT NOT NULL CHECK (length(color) BETWEEN 1 AND 256),
    width REAL NOT NULL CHECK (width > 0),
    points_json TEXT NOT NULL CHECK (json_valid(points_json)),
    PRIMARY KEY (canvas_name, node_id, element_id),
    FOREIGN KEY (canvas_name, node_id)
      REFERENCES work_pad_meta(canvas_name, node_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_pins (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    element_id TEXT NOT NULL CHECK (length(element_id) BETWEEN 1 AND 256),
    x REAL NOT NULL,
    y REAL NOT NULL,
    bounds_json TEXT CHECK (bounds_json IS NULL OR json_valid(bounds_json)),
    mentions_json TEXT NOT NULL CHECK (json_valid(mentions_json)),
    PRIMARY KEY (canvas_name, node_id, element_id),
    FOREIGN KEY (canvas_name, node_id)
      REFERENCES work_pad_meta(canvas_name, node_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_posts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    pin_id TEXT NOT NULL CHECK (length(pin_id) BETWEEN 1 AND 256),
    post_id TEXT NOT NULL CHECK (length(post_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
    author_seat_id TEXT
      CHECK (
        author_seat_id IS NULL
        OR (
          length(author_seat_id) = 69
          AND substr(author_seat_id, 1, 5) = 'seat_'
          AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    author_node_id TEXT
      CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
    author_label TEXT
      CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    PRIMARY KEY (canvas_name, node_id, pin_id, post_id),
    UNIQUE (canvas_name, node_id, pin_id, position),
    FOREIGN KEY (canvas_name, node_id, pin_id)
      REFERENCES work_pad_pins(canvas_name, node_id, element_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_pad_shapes_node
    ON work_pad_shapes(canvas_name, node_id, z, element_id);
  CREATE INDEX IF NOT EXISTS work_pad_posts_pin
    ON work_pad_posts(canvas_name, node_id, pin_id, position);
`,P_=`
  CREATE TABLE IF NOT EXISTS work_pad_read_cursors (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    pin_id TEXT NOT NULL CHECK (length(pin_id) BETWEEN 1 AND 256),
    principal_key TEXT NOT NULL CHECK (length(principal_key) BETWEEN 1 AND 256),
    last_read_position INTEGER NOT NULL CHECK (last_read_position >= -1),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, pin_id, principal_key)
  ) STRICT, WITHOUT ROWID;
`,E_=o9.replaceAll("item_kind IN ('task', 'request', 'message', 'artifact', 'delivery', 'topic', 'post')","item_kind IN ('task', 'request', 'message', 'artifact', 'delivery', 'topic', 'post', 'pad')").replaceAll(`'board.topic.create',
          'board.post.append'
        )`,`'board.topic.create',
          'board.post.append',
          'pad.patch'
        )`),C_=`
  CREATE TABLE IF NOT EXISTS work_canvas_revisions (
    canvas_name TEXT NOT NULL
      PRIMARY KEY
      CHECK (length(canvas_name) BETWEEN 1 AND 256),
    revision INTEGER NOT NULL CHECK (revision >= 0)
  ) STRICT, WITHOUT ROWID;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_events_insert
    AFTER INSERT ON work_events
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.item_canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_proposal_events_insert
    AFTER INSERT ON work_proposal_events
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_topics_insert
    AFTER INSERT ON work_board_topics
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_topics_update
    AFTER UPDATE ON work_board_topics
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_topics_delete
    AFTER DELETE ON work_board_topics
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_posts_insert
    AFTER INSERT ON work_board_posts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_posts_update
    AFTER UPDATE ON work_board_posts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_posts_delete
    AFTER DELETE ON work_board_posts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_cursors_insert
    AFTER INSERT ON work_board_read_cursors
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_cursors_update
    AFTER UPDATE ON work_board_read_cursors
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_cursors_delete
    AFTER DELETE ON work_board_read_cursors
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_meta_insert
    AFTER INSERT ON work_pad_meta
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_meta_update
    AFTER UPDATE ON work_pad_meta
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_meta_delete
    AFTER DELETE ON work_pad_meta
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_cursors_insert
    AFTER INSERT ON work_pad_read_cursors
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_cursors_update
    AFTER UPDATE ON work_pad_read_cursors
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_cursors_delete
    AFTER DELETE ON work_pad_read_cursors
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;
`,sx=`
  INSERT INTO work_canvas_revisions(canvas_name, revision)
  SELECT canvas_name, count(*)
  FROM (
    SELECT item_canvas_name AS canvas_name FROM work_events
    UNION ALL
    SELECT canvas_name FROM work_proposal_events
    UNION ALL
    SELECT canvas_name FROM work_board_topics
    UNION ALL
    SELECT canvas_name FROM work_board_posts
    UNION ALL
    SELECT canvas_name FROM work_board_read_cursors
    UNION ALL
    SELECT canvas_name FROM work_pad_meta
    UNION ALL
    SELECT canvas_name FROM work_pad_read_cursors
  )
  GROUP BY canvas_name
  ON CONFLICT(canvas_name) DO UPDATE
    SET revision = max(work_canvas_revisions.revision, excluded.revision);
`,w_=`

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_tasks_insert
    AFTER INSERT ON work_tasks
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_tasks_update
    AFTER UPDATE ON work_tasks
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_tasks_delete
    AFTER DELETE ON work_tasks
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_requests_insert
    AFTER INSERT ON work_requests
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_requests_update
    AFTER UPDATE ON work_requests
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_requests_delete
    AFTER DELETE ON work_requests
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_messages_insert
    AFTER INSERT ON work_messages
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_messages_update
    AFTER UPDATE ON work_messages
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_messages_delete
    AFTER DELETE ON work_messages
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_messages_insert
    AFTER INSERT ON work_task_messages
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_messages_update
    AFTER UPDATE ON work_task_messages
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_messages_delete
    AFTER DELETE ON work_task_messages
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_dependencies_insert
    AFTER INSERT ON work_task_dependencies
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_dependencies_update
    AFTER UPDATE ON work_task_dependencies
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_dependencies_delete
    AFTER DELETE ON work_task_dependencies
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_finish_insert
    AFTER INSERT ON work_task_finish
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_finish_update
    AFTER UPDATE ON work_task_finish
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_finish_delete
    AFTER DELETE ON work_task_finish
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_artifacts_insert
    AFTER INSERT ON work_artifacts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_artifacts_update
    AFTER UPDATE ON work_artifacts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_artifacts_delete
    AFTER DELETE ON work_artifacts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_delivery_receipts_insert
    AFTER INSERT ON work_delivery_receipts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.delivered_canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_delivery_receipts_update
    AFTER UPDATE ON work_delivery_receipts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.delivered_canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_delivery_receipts_delete
    AFTER DELETE ON work_delivery_receipts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.delivered_canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_proposals_insert
    AFTER INSERT ON work_task_proposals
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_proposals_update
    AFTER UPDATE ON work_task_proposals
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_proposals_delete
    AFTER DELETE ON work_task_proposals
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_proposal_planning_insert
    AFTER INSERT ON work_proposal_planning
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_proposal_planning_update
    AFTER UPDATE ON work_proposal_planning
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_proposal_planning_delete
    AFTER DELETE ON work_proposal_planning
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_posts_insert
    AFTER INSERT ON work_pad_posts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_posts_update
    AFTER UPDATE ON work_pad_posts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_posts_delete
    AFTER DELETE ON work_pad_posts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_shapes_insert
    AFTER INSERT ON work_pad_shapes
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_shapes_update
    AFTER UPDATE ON work_pad_shapes
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_shapes_delete
    AFTER DELETE ON work_pad_shapes
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;
`;var Q50=`
  CREATE TABLE IF NOT EXISTS state_schema_identity (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    actual_schema_sha256 TEXT NOT NULL
      CHECK (
        length(actual_schema_sha256) = 64
        AND actual_schema_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    source_schema_sha256 TEXT NOT NULL
      CHECK (
        length(source_schema_sha256) = 64
        AND source_schema_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    verified_at TEXT NOT NULL
      CHECK (length(verified_at) BETWEEN 1 AND 64)
  ) STRICT;
`,J50=`
  CREATE TABLE IF NOT EXISTS canvas_generations (
    generation TEXT PRIMARY KEY
      CHECK (
        length(generation) > 0
        AND generation NOT GLOB '*[^0-9]*'
        AND (generation = '0' OR substr(generation, 1, 1) <> '0')
      ),
    created_at TEXT NOT NULL CHECK (length(created_at) > 0),
    cause TEXT NOT NULL CHECK (length(cause) > 0),
    intent_sha256 TEXT NOT NULL CHECK (length(intent_sha256) = 64),
    document_count INTEGER NOT NULL
      CHECK (document_count >= 0)
  ) STRICT;

  CREATE TABLE IF NOT EXISTS canvas_generation_documents (
    generation TEXT NOT NULL
      REFERENCES canvas_generations(generation) ON DELETE CASCADE,
    name TEXT NOT NULL CHECK (length(name) > 0),
    body TEXT NOT NULL,
    sha256 TEXT NOT NULL CHECK (length(sha256) = 64),
    modified_at TEXT NOT NULL CHECK (length(modified_at) > 0),
    PRIMARY KEY (generation, name)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS canvas_head (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    generation TEXT NOT NULL
      REFERENCES canvas_generations(generation) ON DELETE RESTRICT
  ) STRICT;
`,ax=[Q50,J50,Rx,Px,Ax,Ex,Mx,dx,ux,cx,lx,ox,ZD],_D0=ax.join(`
`),tx=[...ax,N_],GD0=tx.join(`
`),$50=[...tx,V_],ex=$50.map((X)=>X===ZD?_D:X),ZD0=ex.join(`
`),Xv=[...ex,D_],KD0=Xv.join(`
`),Yv=[...Xv,T_],HD0=Yv.join(`
`),Qv=[...Yv,F_],WD0=Qv.join(`
`),Jv=[...Qv,q7],UD0=Jv.join(`
`),$v=Jv.map((X)=>X===_D?R5:X),DD0=$v.join(`
`),_v=[...$v,R_],ND0=_v.join(`
`),Gv=[..._v,O_],VD0=Gv.join(`
`),KD=[...Gv,L_],BD0=KD.join(`
`),_50=KD.map((X)=>X===R5?GD:X),zD0=_50.join(`
`),Zv=KD.map((X)=>X===R5?o9:X),qD0=Zv.join(`
`),Kv=Zv.map((X)=>X===q7?rx:X),OD0=Kv.join(`
`),Hv=[...Kv.map((X)=>X===o9?E_:X),A_],LD0=Hv.join(`
`),Wv=[...Hv,P_],TD0=Wv.join(`
`),Uv=[...Wv,C_],FD0=Uv.join(`
`),G50=[...Uv,w_],Dv=G50.join(`
`);import{createHash as Z50}from"node:crypto";import{DatabaseSync as K50}from"node:sqlite";var H50="0".repeat(64),W50=(X)=>Z50("sha256").update(X).digest("hex"),U50=(X)=>{let Y=[],Q=0,J=($)=>{let G=$==="["?"]":$,Z=$;Q+=1;while(Q<X.length){let K=X[Q];if(Z+=K,Q+=1,K!==G)continue;if(X[Q]===G){Z+=G,Q+=1;continue}break}Y.push(Z)};while(Q<X.length){let $=X[Q];if(/\s/u.test($)){Q+=1;continue}if($==="-"&&X[Q+1]==="-"){Q+=2;while(Q<X.length&&X[Q]!==`
`)Q+=1;continue}if($==="/"&&X[Q+1]==="*"){let H=X.indexOf("*/",Q+2);Q=H===-1?X.length:H+2;continue}if($==="'"||$==='"'||$==="`"||$==="["){J($);continue}let G=X.slice(Q,Q+3);if(G==="->>"){Y.push(G),Q+=3;continue}let Z=X.slice(Q,Q+2);if(["||","<<",">>","<=",">=","==","!=","<>","->"].includes(Z)){Y.push(Z),Q+=2;continue}if(/[\[\]\(\),.;+\-*/%<>=!|&~]/u.test($)){Y.push($),Q+=1;continue}let K=Q;while(Q<X.length&&!/[\s'"`\[\]\(\),.;+\-*/%<>=!|&~]/u.test(X[Q]))Q+=1;Y.push(X.slice(K,Q).toLowerCase())}return JSON.stringify(Y)},j_=(X)=>X.prepare(`
          SELECT type, name, tbl_name AS table_name, sql
          FROM sqlite_schema
          WHERE type IN ('table', 'index', 'view', 'trigger')
            AND name NOT GLOB 'sqlite_*'
          ORDER BY type COLLATE BINARY, name COLLATE BINARY
        `).all().map((Y)=>({type:String(Y.type),name:String(Y.name),tableName:String(Y.table_name),sql:Y.sql===null?null:U50(String(Y.sql))})),M_=(X)=>W50(JSON.stringify(X)),HD=(X)=>M_(j_(X)),WD=(X)=>j_(X).length===0,Nv=(X)=>`${X.type}:${X.name}`,D50=(X,Y)=>{let Q=new Map(X.map((K)=>[Nv(K),K])),J=new Map(Y.map((K)=>[Nv(K),K])),$=[...Q.keys()].filter((K)=>!J.has(K)).sort(),G=[...J.keys()].filter((K)=>!Q.has(K)).sort(),Z=[...J.keys()].filter((K)=>{let H=Q.get(K),W=J.get(K);return H!==void 0&&W!==void 0&&JSON.stringify(H)!==JSON.stringify(W)}).sort();return[$.length>0?`unexpected=${$.join(",")}`:"",G.length>0?`missing=${G.join(",")}`:"",Z.length>0?`changed=${Z.join(",")}`:""].filter(Boolean).join("; ")},Vv=(X)=>{let Y=new K50(":memory:",{open:!0,readOnly:!1,allowExtension:!1,enableForeignKeyConstraints:!0,enableDoubleQuotedStringLiterals:!1,allowBareNamedParameters:!1,allowUnknownNamedParameters:!1});try{return Y.exec(`
      PRAGMA foreign_keys = ON;
      PRAGMA trusted_schema = OFF;
    `),Y.exec(X),j_(Y)}finally{Y.close()}},Bv=(X)=>({actualSchemaSha256:M_(Vv(X))}),I_=(X)=>{if(X.prepare(`
        SELECT 1
        FROM sqlite_schema
        WHERE type = 'table'
          AND name = 'state_schema_identity'
      `).get()===void 0)throw Error("state schema identity table is missing");let Q=X.prepare(`
        SELECT
          actual_schema_sha256,
          verified_at
        FROM state_schema_identity
        WHERE singleton = 1
      `).get();if(Q===void 0)throw Error("state schema identity witness is missing");return{actualSchemaSha256:String(Q.actual_schema_sha256),verifiedAt:String(Q.verified_at)}},UD=(X)=>{let Y=I_(X),Q=HD(X);if(Y.actualSchemaSha256!==Q)throw Error("state schema changed after its recorded identity was stamped");return Y},DD=(X,Y)=>{X.prepare(`
        INSERT INTO state_schema_identity(
          singleton,
          actual_schema_sha256,
          source_schema_sha256,
          verified_at
        ) VALUES (1, ?, ?, ?)
        ON CONFLICT(singleton) DO UPDATE SET
          actual_schema_sha256 = excluded.actual_schema_sha256,
          source_schema_sha256 = excluded.source_schema_sha256,
          verified_at = excluded.verified_at
      `).run(Y.actualSchemaSha256,H50,new Date().toISOString())},ND=(X,Y)=>{let Q=Vv(Y),J=j_(X),$=M_(Q),G=M_(J);if(G!==$){let Z=D50(J,Q);throw Error(`state schema identity mismatch${Z.length>0?` (${Z})`:""}`)}return{actualSchemaSha256:G}},VD=(X,Y)=>{let Q=ND(X,Y);return DD(X,Q),Q};var $1="expand-only",qv={actualSchemaSha256:"376d0448e43bda8373930f74140ff2f11c315bcf9c9382daf25bd4cb7b910195"},N50={actualSchemaSha256:"c7050c73efcea27e7ccb6e7c687f213cae8d2c32e8903d1ab7c7f1e8aeb953c3"},V50={actualSchemaSha256:"4a8d0fd0545e2108c79c611fc4f56acb1ce96a1972cae13cbf7e716b241bc941"},B50={actualSchemaSha256:"8870c6e4b932ee4a2895bfc9926e2be97f0baa3c538bdfa1e9e8cca5eb354d7f"},z50={actualSchemaSha256:"4c0fd324cb37c9c609acdeade50a10325b2bffddaae40c0ee8fa464d6cfc6b6f"},q50={actualSchemaSha256:"f097722579ffcaad121b0e5eb62076a8ab70cb9c5d66a78978d572612703be53"},O50={actualSchemaSha256:"9f2aace6eaefaa20c1141304d5d4d62544a0500ff3bc7f30acda94d4099006bc"},L50={actualSchemaSha256:"8239ad37bd9fb890d585f5fedef69086890a75b1c01b5fb257bb4573c2809e71"},T50={actualSchemaSha256:"00777be6fb3361c057a799d0f58c86d364518d24a1eb2d8a08b6f32c58d7bcef"},F50={actualSchemaSha256:"7844862b7ed357a60b4e78a336ae7229aab8dd812622862f0de56c916e12269e"},R50={actualSchemaSha256:"66e16dda9d6d938b107ec25b0edd58f1a964d40192fd1d9fe35793665d03e99f"},A50={actualSchemaSha256:"a4bf3db00027fc2a52b5b73592d3d33b1f7d739c5ec7f32cdde41e3d95d5d53e"},P50={actualSchemaSha256:"fd6f5b73d474c83ed8ff93c24b60b8587f7cfe3783d2fe65274c7611ae431abf"},E50={actualSchemaSha256:"646f7b553d54bd55cbdab2562132c22508b8ea9b4f29b7f9ae31c8f93d9bf06f"},C50={actualSchemaSha256:"419206d0b4a3e52fa7d24a04c0cf07fb17f25cbf60b83e64e6d89bb32d4fb5c9"},w50={actualSchemaSha256:"68c01a84360fe399ea98c2963aa763f86cfd0c2c5262ecea9996ee984a3cb3bb"},M50={actualSchemaSha256:"5f580bc42f6e3332256ca6bfadda1489f42889616c75acd1cf4a3af1259249bb"},j50={actualSchemaSha256:"06411da7eb2843c89a7b170321ca0992e8c72b9da65e3fa702b2fce1197980e1"},I50={actualSchemaSha256:"e203c32e409f105a110bfac9a3f98b3eefaba0885d60c0ec3c25d705ec4980ab"};var i9=20,x50=[{fromVersion:1,toVersion:2,name:"add-license-activation",safety:$1,fromIdentity:qv,migrate:(X)=>{X.exec(N_)}},{fromVersion:2,toVersion:3,name:"bind-license-entitlement-to-dodo-product",safety:$1,fromIdentity:N50,migrate:(X)=>{X.exec(V_)}},{fromVersion:3,toVersion:4,name:"allow-atomic-task-release",safety:$1,fromIdentity:V50,replacesObjects:["trigger:work_tasks_actor_immutable"],migrate:(X)=>{X.exec(`
          DROP TRIGGER work_tasks_actor_immutable;
          CREATE TRIGGER work_tasks_actor_immutable
          BEFORE UPDATE OF actor_seat_id ON work_tasks
          WHEN
            OLD.actor_seat_id IS NOT NULL
            AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
            AND NOT (
              NEW.actor_seat_id IS NULL
              AND NEW.state = 'submitted'
            )
          BEGIN
            SELECT RAISE(
              ABORT,
              'work task actor seat is immutable except for operator release'
            );
          END;
        `)}},{fromVersion:4,toVersion:5,name:"add-task-proposals",safety:$1,fromIdentity:B50,migrate:(X)=>{X.exec(ix)}},{fromVersion:5,toVersion:6,name:"add-canvas-entities",safety:$1,fromIdentity:z50,migrate:(X)=>{X.exec(D_),v50(X)}},{fromVersion:6,toVersion:7,name:"add-work-task-dependencies",safety:$1,fromIdentity:q50,migrate:(X)=>{X.exec(T_)}},{fromVersion:7,toVersion:8,name:"add-work-task-finish-criteria",safety:$1,fromIdentity:O50,migrate:(X)=>{X.exec(F_)}},{fromVersion:8,toVersion:9,name:"add-work-board",safety:$1,fromIdentity:L50,migrate:(X)=>{X.exec(q7)}},{fromVersion:9,toVersion:10,name:"board-event-vocabulary",safety:$1,fromIdentity:T50,replacesTables:["work_events","work_pending_commands"],migrate:(X)=>{X.exec(`
          CREATE TABLE work_events__migrate_bak AS SELECT * FROM work_events;
          CREATE TABLE work_pending_commands__migrate_bak AS
            SELECT * FROM work_pending_commands;

          DROP TABLE work_pending_commands;
          DROP TABLE work_events;
        `),X.exec(R5),X.exec(`
          INSERT INTO work_events SELECT * FROM work_events__migrate_bak;
          INSERT INTO work_pending_commands
            SELECT * FROM work_pending_commands__migrate_bak;
          DROP TABLE work_events__migrate_bak;
          DROP TABLE work_pending_commands__migrate_bak;
        `)}},{fromVersion:10,toVersion:11,name:"add-work-proposal-planning",safety:$1,fromIdentity:F50,migrate:(X)=>{X.exec(R_)}},{fromVersion:11,toVersion:12,name:"add-content-manifest",safety:$1,fromIdentity:R50,migrate:(X)=>{X.exec(O_)}},{fromVersion:12,toVersion:13,name:"add-content-inline-media-migration-marker",safety:$1,fromIdentity:A50,migrate:(X)=>{X.exec(L_)}},{fromVersion:13,toVersion:14,name:"proposal-reject-event-vocabulary",safety:$1,fromIdentity:P50,replacesTables:["work_proposal_events","work_pending_proposal_commands"],migrate:(X)=>{X.exec(`
          CREATE TABLE work_proposal_events__migrate_bak AS
            SELECT * FROM work_proposal_events;
          CREATE TABLE work_pending_proposal_commands__migrate_bak AS
            SELECT * FROM work_pending_proposal_commands;

          DROP TABLE work_pending_proposal_commands;
          DROP TABLE work_proposal_events;
        `),X.exec(nx),X.exec(`
          INSERT INTO work_proposal_events
            SELECT * FROM work_proposal_events__migrate_bak;
          INSERT INTO work_pending_proposal_commands
            SELECT * FROM work_pending_proposal_commands__migrate_bak;
          DROP TABLE work_proposal_events__migrate_bak;
          DROP TABLE work_pending_proposal_commands__migrate_bak;
        `)}},{fromVersion:14,toVersion:15,name:"task-archived-soft-delete",safety:$1,fromIdentity:E50,replacesTables:["work_tasks","work_task_transitions"],migrate:(X)=>{X.exec(`
          CREATE TABLE work_tasks__migrate_bak AS SELECT * FROM work_tasks;
          CREATE TABLE work_task_transitions__migrate_bak AS
            SELECT * FROM work_task_transitions;

          DROP TABLE work_task_transitions;
          DROP TABLE work_tasks;
        `),X.exec(o9),X.exec(`
          INSERT INTO work_tasks SELECT * FROM work_tasks__migrate_bak;
          INSERT INTO work_task_transitions
            SELECT * FROM work_task_transitions__migrate_bak;
          DROP TABLE work_tasks__migrate_bak;
          DROP TABLE work_task_transitions__migrate_bak;
        `)}},{fromVersion:15,toVersion:16,name:"board-post-tags",safety:$1,fromIdentity:C50,replacesTables:["work_board_posts"],migrate:(X)=>{X.exec(`
          CREATE TABLE work_board_posts__migrate_bak AS
            SELECT * FROM work_board_posts;
          DROP TABLE work_board_posts;
        `),X.exec(`
          CREATE TABLE work_board_posts (
            canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
            node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
            topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
            post_id TEXT NOT NULL CHECK (length(post_id) BETWEEN 1 AND 256),
            position INTEGER NOT NULL CHECK (position >= 0),
            author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
            author_seat_id TEXT
              CHECK (
                author_seat_id IS NULL
                OR (
                  length(author_seat_id) = 69
                  AND substr(author_seat_id, 1, 5) = 'seat_'
                  AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
                )
              ),
            author_node_id TEXT
              CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
            author_label TEXT
              CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
            parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
            tags_json TEXT
              CHECK (tags_json IS NULL OR json_valid(tags_json)),
            created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
            PRIMARY KEY (canvas_name, node_id, topic_id, post_id),
            UNIQUE (canvas_name, node_id, topic_id, position),
            FOREIGN KEY (canvas_name, node_id, topic_id)
              REFERENCES work_board_topics(canvas_name, node_id, topic_id)
              ON DELETE RESTRICT
              ON UPDATE RESTRICT
          ) STRICT, WITHOUT ROWID;
          CREATE INDEX IF NOT EXISTS work_board_posts_thread
            ON work_board_posts(canvas_name, node_id, topic_id, position);
        `),X.exec(`
          INSERT INTO work_board_posts(
            canvas_name, node_id, topic_id, post_id, position,
            author_kind, author_seat_id, author_node_id, author_label,
            parts_json, tags_json, created_at
          )
          SELECT
            canvas_name, node_id, topic_id, post_id, position,
            author_kind, author_seat_id, author_node_id, author_label,
            parts_json, NULL, created_at
          FROM work_board_posts__migrate_bak;
          DROP TABLE work_board_posts__migrate_bak;
        `)}},{fromVersion:16,toVersion:17,name:"add-work-pad",safety:$1,fromIdentity:w50,replacesTables:["work_events","work_pending_commands"],migrate:(X)=>{X.exec(A_),X.exec(`
          CREATE TABLE work_events__migrate_bak AS SELECT * FROM work_events;
          CREATE TABLE work_pending_commands__migrate_bak AS
            SELECT * FROM work_pending_commands;

          DROP TABLE work_pending_commands;
          DROP TABLE work_events;
        `),X.exec(E_),X.exec(`
          INSERT INTO work_events SELECT * FROM work_events__migrate_bak;
          INSERT INTO work_pending_commands
            SELECT * FROM work_pending_commands__migrate_bak;
          DROP TABLE work_events__migrate_bak;
          DROP TABLE work_pending_commands__migrate_bak;
        `)}},{fromVersion:17,toVersion:18,name:"add-work-pad-read-cursors",safety:$1,fromIdentity:M50,migrate:(X)=>{X.exec(P_)}},{fromVersion:18,toVersion:19,name:"add-work-canvas-revision-counter",safety:$1,fromIdentity:j50,migrate:(X)=>{X.exec(C_),X.exec(sx)}},{fromVersion:19,toVersion:20,name:"witness-every-projected-work-table",safety:$1,fromIdentity:I50,migrate:(X)=>{X.exec(w_)}}],v50=(X)=>{let Y=X.prepare("SELECT generation FROM canvas_head WHERE singleton = 1").get();if(Y===void 0)return;let Q=X.prepare(`
        SELECT name, body
        FROM canvas_generation_documents
        WHERE generation = ?
      `).all(Y.generation),J=new Date().toISOString(),$=X.prepare(`
      INSERT INTO canvas_entities(
        canvas_name,
        entity_id,
        kind,
        binding_id,
        lifecycle,
        created_at,
        updated_at,
        archived_at,
        soft_deleted_at
      ) VALUES (?, ?, ?, ?, 'active', ?, ?, NULL, NULL)
      ON CONFLICT(canvas_name, entity_id) DO NOTHING
    `);for(let G of Q){if(G.body.length===0)continue;let Z;try{Z=JSON.parse(G.body)}catch{throw Error(`canvas entity backfill: document "${G.name}" is not valid JSON`)}if(Z===null||typeof Z!=="object"||!("nodes"in Z)||!Array.isArray(Z.nodes))throw Error(`canvas entity backfill: document "${G.name}" is not a canvas body with nodes[]`);let K=new Set;for(let H of Z.nodes){if(H===null||typeof H!=="object"||!("id"in H)||typeof H.id!=="string")throw Error(`canvas entity backfill: document "${G.name}" has a node without a string id`);let W=H.id;if(W.length===0||W.length>256)throw Error(`canvas entity backfill: document "${G.name}" has an out-of-range entity id`);let D=null,U=null,N=H.ether;if(N!==null&&typeof N==="object"){let V=N.entity;if(V!==null&&typeof V==="object"&&typeof V.kind==="string"){let q=V.kind;if(q.length>0&&q.length<=128)D=q}let z=N.terminal;if(z!==null&&typeof z==="object"&&typeof z.bindingId==="string"){let q=z.bindingId;if(q.length>0&&q.length<=256)U=q}}if(D===null){let V=H.type;if(typeof V==="string"&&V.length>0&&V.length<=128)D=V}if(U!==null)if(K.has(U))U=null;else K.add(U);$.run(G.name,W,D,U,J,J)}}},Ov={baselineVersion:1,baselineIdentity:qv,currentVersion:i9,currentSchemaSql:Dv,migrations:x50},Lv=(X)=>{let Y=X.prepare("PRAGMA user_version").get(),Q=Number(Y?.user_version);if(!Number.isSafeInteger(Q)||Q<0||Q>2147483647)throw Error(`state schema user_version is invalid: ${String(Y?.user_version)}`);return Q},BD=(X,Y)=>{if(!Number.isSafeInteger(Y)||Y<0||Y>2147483647)throw Error(`refusing invalid state schema version ${Y}`);X.exec(`PRAGMA user_version = ${Y}`)},S50=(X,Y)=>X.actualSchemaSha256===Y.actualSchemaSha256,z4=(X,Y,Q)=>{if(!S50(Y,Q))throw Error(`${X} identity is not a recognized Vellum Command schema`)},k50=(X)=>{let Y=X.prepare("PRAGMA foreign_key_check").all();if(Y.length>0)throw Error(`state schema migration leaves ${Y.length} foreign-key violation(s)`)},Tv=(X)=>{let Y=X.prepare(`
        SELECT type, name, sql
        FROM sqlite_schema
        WHERE type IN ('table', 'index', 'view', 'trigger')
          AND name NOT GLOB 'sqlite_*'
        ORDER BY type COLLATE BINARY, name COLLATE BINARY
      `).all(),Q=new Map,J=new Map;for(let $ of Y){let G=String($.type),Z=String($.name);if(G!=="table"){J.set(`${G}:${Z}`,$.sql===null?null:String($.sql));continue}let K=X.prepare(`
          SELECT
            name,
            type,
            "notnull" AS not_null,
            dflt_value AS default_value,
            pk AS primary_key,
            hidden
          FROM pragma_table_xinfo(?)
          ORDER BY cid
        `).all(Z);Q.set(Z,new Map(K.map((H)=>[String(H.name),{name:String(H.name),type:String(H.type),notNull:Number(H.not_null),defaultValue:H.default_value===null?null:String(H.default_value),primaryKey:Number(H.primary_key),hidden:Number(H.hidden)}])))}return{tables:Q,retainedObjects:J}},b50=(X,Y,Q,J={indexes:new Set,triggers:new Set})=>{let $=Tv(Y);for(let[G,Z]of X.tables){let K=$.tables.get(G);if(K===void 0)throw Error(`state schema startup migration removed table ${G}`);for(let[H,W]of Z){let D=K.get(H);if(D===void 0||JSON.stringify(D)!==JSON.stringify(W))throw Error(`state schema startup migration changed durable column ${G}.${H}`)}}for(let[G,Z]of X.retainedObjects){if(Q.has(G))continue;let K=G.indexOf(":");if(K>0){let H=G.slice(0,K),W=G.slice(K+1);if(H==="trigger"&&J.triggers.has(W))continue;if(H==="index"&&J.indexes.has(W))continue}if($.retainedObjects.get(G)!==Z)throw Error(`state schema startup migration changed durable ${G}`)}},g50=new Set([H0.SQLITE_DELETE,H0.SQLITE_DROP_INDEX,H0.SQLITE_DROP_TABLE,H0.SQLITE_DROP_TEMP_INDEX,H0.SQLITE_DROP_TEMP_TABLE,H0.SQLITE_DROP_TEMP_TRIGGER,H0.SQLITE_DROP_TEMP_VIEW,H0.SQLITE_DROP_TRIGGER,H0.SQLITE_DROP_VIEW,H0.SQLITE_DROP_VTABLE,H0.SQLITE_ATTACH,H0.SQLITE_DETACH,H0.SQLITE_REINDEX,H0.SQLITE_ANALYZE]),y50=new Set(["application_id","journal_mode","legacy_alter_table","schema_version","user_version","writable_schema"]),zv=(X)=>{let Y=X.replace(/--[^\r\n]*/gu," ").replace(/\/\*[\s\S]*?\*\//gu," ");if(/\balter\s+table\b[\s\S]*?\b(?:rename(?:\s+(?:to|column))?|drop\s+column)\b/iu.test(Y))throw Error("state schema startup migrations may not rename or drop tables or columns");if(/\b(?:insert\s+or\s+replace|replace\s+into)\b/iu.test(Y))throw Error("state schema startup migrations may not replace existing rows")},h50=(X,Y)=>{if(Y.size===0)return{indexes:new Set,triggers:new Set};let Q=[...Y],J=Q.map(()=>"?").join(", "),$=X.prepare(`
        SELECT type, name
        FROM sqlite_schema
        WHERE type IN ('index', 'trigger')
          AND tbl_name IN (${J})
      `).all(...Q),G=new Set,Z=new Set;for(let K of $)if(K.type==="index")G.add(K.name);else if(K.type==="trigger")Z.add(K.name);return{indexes:G,triggers:Z}},m50=(X,Y,Q,J)=>{if(Y)return!1;if(X>=Q.currentVersion)return!1;let $=X===0?Q.baselineVersion:X;if($<Q.baselineVersion)return!1;while($<Q.currentVersion){let G=J.get($);if(G===void 0)return!1;if((G.replacesTables?.length??0)>0)return!0;$=G.toVersion}return!1},f50=(X,Y)=>{let Q=Tv(X),J=new Set(Y.replacesObjects??[]),$=new Set(Y.replacesTables??[]),G=h50(X,$),Z={exec:(K)=>{zv(K),X.exec(K)},prepare:(K,H)=>{return zv(K),X.prepare(K,H)}};X.setAuthorizer((K,H,W)=>{let D=H===null?"":H.toLowerCase(),U=H==="sqlite_schema"||H==="sqlite_master",N=H!==null&&$.has(H),V=H!==null&&H.endsWith("__migrate_bak"),z=H!==null&&G.indexes.has(H),q=H!==null&&G.triggers.has(H);return K===H0.SQLITE_TRANSACTION||K===H0.SQLITE_SAVEPOINT||g50.has(K)&&!(K===H0.SQLITE_REINDEX&&H!==null&&(!Q.retainedObjects.has(`index:${H}`)||z))&&!(K===H0.SQLITE_DROP_TRIGGER&&H!==null&&(J.has(`trigger:${H}`)||q))&&!(K===H0.SQLITE_DELETE&&(U&&(J.size>0||$.size>0)||N||V))&&!(K===H0.SQLITE_DROP_TABLE&&(N||V))&&!(K===H0.SQLITE_DROP_INDEX&&z)||K===H0.SQLITE_INSERT&&H!==null&&Q.tables.has(H)&&!$.has(H)||K===H0.SQLITE_UPDATE&&H!==null&&W!==null&&Q.tables.get(H)?.has(W)===!0||K===H0.SQLITE_PRAGMA&&H!==null&&y50.has(D)?H0.SQLITE_DENY:H0.SQLITE_OK});try{Y.migrate(Z),b50(Q,X,J,G)}finally{X.setAuthorizer(null)}if(!X.isTransaction)throw Error(`state schema migration ${Y.fromVersion} -> ${Y.toVersion} escaped its startup transaction`)},p50=(X,Y)=>{let Q,J;try{Q=I_(X)}catch(G){J=G}let $=VD(X,Y);if(Q===void 0)throw J;return z4("recorded current state schema",Q,$),Q},d50=(X,Y)=>{let Q,J;try{Q=I_(X)}catch(G){J=G}let $=ND(X,Y);if(Q===void 0)throw J;return z4("recorded current state schema",Q,$),Q},Fv=(X)=>{if(!Number.isSafeInteger(X.baselineVersion)||X.baselineVersion<1||!Number.isSafeInteger(X.currentVersion)||X.currentVersion<X.baselineVersion)throw Error("state schema migration version bounds are invalid");let Y=new Map;for(let Q of X.migrations){if(!Number.isSafeInteger(Q.fromVersion)||Q.fromVersion<X.baselineVersion||Q.toVersion!==Q.fromVersion+1||Q.toVersion>X.currentVersion||Q.name.length===0||Q.safety!==$1)throw Error(`invalid state schema migration ${Q.fromVersion} -> ${Q.toVersion}`);if(Y.has(Q.fromVersion))throw Error(`duplicate state schema migration from version ${Q.fromVersion}`);Y.set(Q.fromVersion,Q)}for(let Q=X.baselineVersion;Q<X.currentVersion;Q+=1)if(!Y.has(Q))throw Error(`missing state schema migration ${Q} -> ${Q+1}`);return Y},Rv=(X,Y=Ov)=>{let Q=Fv(Y),J=Lv(X);if(J>Y.currentVersion)throw Error(`state schema version ${J} is newer than supported version ${Y.currentVersion}`);if(WD(X)){if(J!==0)throw Error(`fresh state database carries unexpected user_version ${J}`);return!1}if(J===Y.currentVersion&&J!==0)return!1;if(J===0&&Y.baselineVersion===Y.currentVersion)return d50(X,Y.currentSchemaSql),!0;let $=UD(X),G=J===0?Y.baselineVersion:J;if(J===0)z4("unversioned state schema baseline",$,Y.baselineIdentity);else if(J<Y.baselineVersion)throw Error(`state schema version ${J} predates the supported baseline ${Y.baselineVersion}`);let Z=Q.get(G);if(G<Y.currentVersion&&Z===void 0)throw Error(`missing state schema migration ${G} -> ${G+1}`);if(Z!==void 0)z4(`state schema version ${G}`,$,Z.fromIdentity);return!0},Av=(X,Y=Ov)=>{let Q=Fv(Y),J=Lv(X);if(J>Y.currentVersion)throw Error(`state schema version ${J} is newer than supported version ${Y.currentVersion}`);let $=WD(X),G=m50(J,$,Y,Q),Z=!1;try{if(G)X.exec("PRAGMA foreign_keys = OFF"),Z=!0;X.exec("BEGIN IMMEDIATE");try{let K=J;if($){if(K!==0)throw Error(`fresh state database carries unexpected user_version ${K}`);X.exec(Y.currentSchemaSql),K=Y.currentVersion}else{let W=K===Y.currentVersion||K===0&&Y.baselineVersion===Y.currentVersion?p50(X,Y.currentSchemaSql):UD(X);if(K===0)z4("unversioned state schema baseline",W,Y.baselineIdentity),K=Y.baselineVersion,BD(X,K);else if(K<Y.baselineVersion)throw Error(`state schema version ${K} predates the supported baseline ${Y.baselineVersion}`);while(K<Y.currentVersion){let D=Q.get(K);if(D===void 0)throw Error(`missing state schema migration ${K} -> ${K+1}`);if(z4(`state schema version ${K}`,W,D.fromIdentity),f50(X,D),K=D.toVersion,BD(X,K),K<Y.currentVersion){let U=Q.get(K);if(U===void 0)throw Error(`missing state schema migration ${K} -> ${K+1}`);let N=HD(X);z4(`migrated state schema version ${K}`,{actualSchemaSha256:N},U.fromIdentity),DD(X,U.fromIdentity),W=U.fromIdentity}}if(J===Y.currentVersion)z4(`state schema version ${Y.currentVersion}`,W,Bv(Y.currentSchemaSql))}let H=VD(X,Y.currentSchemaSql);return k50(X),BD(X,Y.currentVersion),X.exec("COMMIT"),{...H,schemaVersion:Y.currentVersion,previousVersion:J,initialized:$}}catch(K){try{X.exec("ROLLBACK")}catch{}throw K}}finally{if(Z)try{X.exec("PRAGMA foreign_keys = ON")}catch{}}};import{existsSync as hY0,lstatSync as mY0}from"node:fs";import{resolve as fY0}from"node:path";import{DatabaseSync as pY0}from"node:sqlite";import{chmodSync as av,lstatSync as tv,mkdirSync as MY0}from"node:fs";import{homedir as u50}from"node:os";import{isAbsolute as c50,join as yD0,resolve as l50}from"node:path";var zD,o50=(X)=>{if(X===void 0)return;let Y=X.trim();if(Y.length===0)return;if(Y.length>4096)return;if(/[\u0000-\u001f\u007f]/.test(Y))return;if(!c50(Y))return;return l50(Y)},x_=()=>{if(zD===void 0)zD=o50(process.env.VELLUM_COMMAND_HOME)??u50();return zD};import{dirname as jY0,join as IY0,resolve as ev}from"node:path";import{DatabaseSync as xY0}from"node:sqlite";class O7 extends _.TaggedErrorClass()("StateEngineError",{operation:_.String,message:_.String,cause:_.Unknown}){}class L7 extends b1.Service()("@vellum/StateEngine"){}import{appendFileSync as V90,chmodSync as Ev,mkdirSync as B90,renameSync as z90,statSync as q90}from"node:fs";import{dirname as O90,join as L90}from"node:path";import{performance as T90}from"node:perf_hooks";import{join as D90}from"node:path";var S6=_.String.pipe(_.check(_.isMinLength(1)),_.brand("BindingId")),v_=_.String.pipe(_.check(_.isMinLength(1)),_.brand("SessionEpoch")),uD0=_.String.pipe(_.check(_.isMinLength(1)),_.brand("HerdrStreamId")),cD0=_.String.pipe(_.check(_.isMinLength(1)),_.brand("HerdrTerminalId")),lD0=_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(20)),_.brand("ControlCols")),oD0=_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(5)),_.brand("ControlRows")),iD0=D6.taggedEnum();var rD0=D6.taggedEnum();class i50 extends _.TaggedErrorClass()("HerdrControlInactiveError",{message:_.String}){}class r50 extends _.TaggedErrorClass()("HerdrControlPipeError",{channel:_.Literals(["stdin","stdout","stderr"]),message:_.String}){}class n50 extends _.TaggedErrorClass()("HerdrControlProtocolError",{message:_.String}){}class s50 extends _.TaggedErrorClass()("HerdrControlOverflowError",{message:_.String}){}class a50 extends _.TaggedErrorClass()("HerdrControlShutdownError",{message:_.String}){}class t50 extends _.TaggedErrorClass()("TerminalSpawnError",{surface:_.Literals(["native","herdr-control"]),message:_.String}){}class e50 extends _.TaggedErrorClass()("TerminalAdmitError",{message:_.String}){}class X90 extends _.TaggedErrorClass()("TerminalWriteError",{surface:_.Literals(["native","herdr-control"]),message:_.String}){}var nD0=_.Struct({type:_.Literal("terminal.input"),bytes:_.String}),sD0=_.Struct({type:_.Literal("terminal.input"),text:_.String}),aD0=_.Struct({type:_.Literal("terminal.resize"),cols:_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThan(0))),rows:_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThan(0)))}),tD0=_.Struct({type:_.Literal("terminal.scroll"),direction:_.Literals(["up","down"]),lines:_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThan(0))),column:_.optional(_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(0)))),row:_.optional(_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(0)))),modifiers:_.optional(_.Number.pipe(_.check(_.isInt()),_.check(_.isBetween({minimum:0,maximum:255}))))}),eD0=_.Struct({type:_.Literal("terminal.release")});var Y90=_.Struct({type:_.Literal("terminal.frame"),bytes:_.String,encoding:_.optional(_.String),full:_.optional(_.Boolean),width:_.optional(_.Number),height:_.optional(_.Number),seq:_.optional(_.Number)}),Q90=_.Struct({type:_.Literal("terminal.closed"),reason:_.optional(_.String)}),XN0=_.Union([Y90,Q90]);var YN0=_.Literals(["pipe_broken","overflow","child_error","stdin_error","stdout_error","stderr_error","client_close","renderer_destroyed","renderer_process_gone","renderer_reloaded","renderer_gone","scope_release","host_revoked","superseded","exit","pane_gone","unknown"]);var S_=_.Literals(["local","remote"]),Pv=_.Struct({_tag:_.Literal("VacantSeat"),bindingId:S6,placement:S_}),qD=_.Struct({_tag:_.Literal("OccupiedSeat"),bindingId:S6,epoch:v_,placement:S_}),_N0=_.Union([Pv,qD]),GN0=_.Struct({_tag:_.Literal("OccupyVacantSeat"),seat:Pv}),ZN0=_.Struct({_tag:_.Literal("ActivateOccupiedSeat"),seat:qD}),KN0=_.Struct({_tag:_.Literal("EvictOccupiedSeat"),seat:qD});class J90 extends _.TaggedErrorClass()("SeatAlreadyOccupiedError",{bindingId:S6,epoch:v_,message:_.String}){}class $90 extends _.TaggedErrorClass()("SeatVacantError",{bindingId:S6,message:_.String}){}var _90=_.Struct({harness:_.String,agentKey:_.String,canvasName:_.String,nodeId:_.String}),G90=_.Struct({harness:_.optionalKey(_.String),agentKey:_.optionalKey(_.String),canvasName:_.optionalKey(_.String),nodeId:_.optionalKey(_.String)});class Z90 extends _.TaggedErrorClass()("SeatIdentityConflictError",{bindingId:S6,expected:_90,actual:G90,message:_.String}){}class K90 extends _.TaggedErrorClass()("SeatGenerationConflictError",{bindingId:S6,expectedEpoch:_.String,actualEpoch:_.String,message:_.String}){}class H90 extends _.TaggedErrorClass()("SeatBindingMismatchError",{bindingId:S6,returnedBindingId:_.String,message:_.String}){}class W90 extends _.TaggedErrorClass()("SeatOccupationFailedError",{bindingId:S6,epoch:_.String,message:_.String}){}var U90=_.Literals(["starting","running","exited"]),HN0=_.Struct({placement:S_,liveness:U90,resumable:_.Boolean,sessionId:_.optionalKey(_.String)}),WN0=_.decodeUnknownSync(S6),UN0=_.decodeUnknownSync(v_),DN0=_.decodeUnknownSync(S_);var N90=[".vellum-command","logs"];var OD=(X=x_())=>D90(X,...N90);var F90="perf.jsonl",R90=20,A90=50,P90=5000,E90=5000,C90=8388608,LD=448,w90=384,c1=(X,Y=1)=>{let Q=10**Y;return Math.round(X*Q)/Q},TD=(X,Y)=>{if(X.length===0)return 0;let Q=Math.ceil(Y*X.length),J=Math.min(X.length-1,Math.max(0,Q-1));return X[J]??0},M90=(X)=>{let Y=new Map;for(let Q of X){let J=Y.get(Q.tag);if(J===void 0)Y.set(Q.tag,[Q]);else J.push(Q)}return[...Y.entries()].map(([Q,J])=>{let $=J.map((G)=>G.ms).sort((G,Z)=>G-Z);return{tag:Q,calls:J.length,totalMs:c1(J.reduce((G,Z)=>G+Z.ms,0)),p50Ms:c1(TD($,0.5)),maxMs:c1($[$.length-1]??0),statements:J.reduce((G,Z)=>G+Z.statements,0),bytes:J.reduce((G,Z)=>G+Z.bytes,0)}}).sort((Q,J)=>J.totalMs-Q.totalMs)},j90=(X,Y)=>{let Q=X.map((G)=>G.ms).sort((G,Z)=>G-Z),J=Q.reduce((G,Z)=>G+Z,0),$=new Map;for(let G of X)for(let Z of G.attribution){let K=$.get(Z.tag)??{calls:0,ms:0};$.set(Z.tag,{calls:K.calls+Z.calls,ms:K.ms+Z.ms})}return{count:X.length,perSec:Y>0?c1(X.length*1000/Y,2):0,totalMs:c1(J),dutyPct:Y>0?c1(J/Y*100):0,minMs:c1(Q[0]??0),p50Ms:c1(TD(Q,0.5)),p90Ms:c1(TD(Q,0.9)),maxMs:c1(Q[Q.length-1]??0),byCaller:[...$.entries()].map(([G,Z])=>({tag:G,calls:Z.calls,ms:c1(Z.ms)})).sort((G,Z)=>Z.ms-G.ms)}},I90=(X)=>{try{let Y=JSON.stringify(X);return Y===void 0?0:Buffer.byteLength(Y,"utf8")}catch{return 0}},x90=(X={})=>{let Y=X.now??(()=>T90.now()),Q=X.emit??k90,J=X.tickMs??R90,$=X.blockMs??A90,G=X.windowMs??P90,Z=X.maxSamples??E90,K=0,H=[],W=[],D=0,U=new Map,N,V,z=0,q=(x,n)=>{if(x.length>=Z)x.shift(),D+=1;x.push(n)},F=()=>{K+=1},R=(x)=>({tag:x,startedAt:Y(),statementsAt:K}),C=(x,n)=>{let x0=Y(),f0=x0-x.startedAt,B0=I90(n),n9=Y()-x0;q(H,{tag:x.tag,ms:f0,statements:K-x.statementsAt,bytes:B0,probeMs:n9});let iD=U.get(x.tag)??{calls:0,ms:0};U.set(x.tag,{calls:iD.calls+1,ms:iD.ms+f0})},w=(x)=>{q(W,{ms:x,attribution:[...U.entries()].map(([n,x0])=>({tag:n,calls:x0.calls,ms:c1(x0.ms)}))})},a=()=>{let x=Y(),n=x-z-J;if(z=x,n>=$)w(n);if(U.size>0)U=new Map},O=(x=G)=>{let n=H,x0=W,f0=D;return H=[],W=[],D=0,{kind:"perf.window",ts:new Date().toISOString(),windowMs:x,reads:{calls:n.length,perSec:x>0?c1(n.length*1000/x,2):0,totalMs:c1(n.reduce((B0,n9)=>B0+n9.ms,0)),probeMs:c1(n.reduce((B0,n9)=>B0+n9.probeMs,0)),byCaller:M90(n)},blocks:j90(x0,x),...f0>0?{dropped:f0}:{}}};return{countStatement:F,beginRead:R,endRead:C,recordBlock:w,drain:O,start:()=>{if(N!==void 0)return;z=Y(),N=setInterval(a,J),N.unref?.(),V=setInterval(()=>{Q(O())},G),V.unref?.()},stop:()=>{if(N!==void 0)clearInterval(N);if(V!==void 0)clearInterval(V);N=void 0,V=void 0}}},wv=()=>L90(OD(),F90),Cv=!1,v90=()=>{let X=OD();B90(X,{recursive:!0,mode:LD}),Ev(O90(X),LD),Ev(X,LD)},S90=()=>{try{let X=wv();if(q90(X).size<C90)return;z90(X,`${X}.1`)}catch{}},k90=(X)=>{try{if(!Cv)v90(),Cv=!0;S90(),V90(wv(),`${JSON.stringify(X)}
`,{encoding:"utf8",mode:w90})}catch{}},FD=process.env.VELLUM_PERF==="1",Mv=FD?x90():void 0;import{performance as jv}from"node:perf_hooks";var b90=4,g90=200,y90=()=>{let X=process.env.VELLUM_COMMAND_BUDGET?.trim().toLowerCase();if(X==="0"||X==="off"||X==="false")return{enabled:!1,strict:!1,forced:!0};if(X==="strict")return{enabled:!0,strict:!0,forced:!0};if(X==="1"||X==="on"||X==="true")return{enabled:!0,strict:!1,forced:!0};return{enabled:!0,strict:!1,forced:!1}},PD=y90(),h90=(X)=>{let Y=X.detail===void 0?"":` (${X.detail})`;console.error(`[budget] ${X.operation}${Y} held the main thread ${X.ms.toFixed(2)}ms, over the ${X.budgetMs}ms budget`)},Iv=PD.enabled,m90=PD.strict,EN0=PD.forced,RD=b90,f90=h90,AD=[],p90=new Set;var d90=(X,Y,Q,J)=>{if(!Iv||Y<=RD)return!1;let $={operation:X,ms:Y,budgetMs:RD,at:new Date().toISOString(),...Q===void 0?{}:{detail:Q}};if(AD.length>=g90)AD.shift();AD.push($),f90($);for(let G of p90)try{G($)}catch{}if(m90&&J)throw Error(`[budget] ${X} held the main thread ${Y.toFixed(2)}ms, over the ${RD}ms budget`);return!0},xv=(X,Y,Q)=>{if(!Iv)return Y();let J=jv.now(),$=!1;try{return Y()}catch(G){throw $=!0,G}finally{d90(X,jv.now()-J,Q,!$)}};var yv=new Map([["work_events","journal"],["work_facts","journal"],["work_commands","journal"],["work_dispositions","journal"],["work_proposal_events","journal"],["work_event_sequences","allocation"],["work_tasks","projection"],["work_requests","projection"],["work_task_messages","projection"],["work_task_transitions","projection"],["work_task_dependencies","projection"],["work_task_finish","projection"],["work_task_proposals","projection"],["work_proposal_planning","projection"],["work_messages","projection"],["work_artifacts","projection"],["work_delivery_receipts","projection"],["work_board_topics","projection"],["work_board_posts","projection"],["work_pad_meta","projection"],["work_pad_images","projection"],["work_pad_shapes","projection"],["work_pad_edges","projection"],["work_pad_inks","projection"],["work_pad_pins","projection"],["work_pad_posts","projection"],["work_pending_commands","projection"],["work_pending_proposal_commands","projection"],["work_pad_read_cursors","cursor"],["work_board_read_cursors","cursor"],["work_canvas_revisions","derived"]]),wN0={"work.artifact.set_archived":{why:"Operator soft-archive / restore rewrites work_artifacts.metadata_json in place and mints no fact, so no replica learns the artifact was archived and a journal rebuild loses the flag.",retire:"Mint an artifact.archive fact and materialize it like every other operation, then delete this reason."},"work.artifact.delete":{why:"Operator delete removes the work_artifacts row outright with no tombstone record, so a journal rebuild resurrects the artifact.",retire:"Mint an artifact.retract fact carrying the tombstone, materialize it, then delete this reason."},"content.inline-media.backfill":{why:"BACKFILL_INLINE_MEDIA_V1 rewrites parts_json in six work_* projection tables to externalize inline media. It is a one-time content move, not a work transition, and must not mint facts that replicate.",retire:"Delete src/main/vellum/content/inline-media-migration.ts once the backfill has run on every install."},"test.fixture-seed":{why:"A migration/schema test seeds projection rows to pin how OLD rows survive a migration. Seeding through the repository would exercise the NEW write path and prove nothing about the old shape.",retire:"Never — but `bun run lint:single-write-seam` forbids this reason under "+"src/, so it can only ever appear in tests and fixtures."}};class T7 extends Error{name="WorkMutationSeamError";constructor(X){super(`work mutation seam: ${X}`)}}var u90=/^[\s;]*(?:--[^\n]*\n|\/\*[\s\S]*?\*\/|\s)*(insert|replace|update|delete)\b/i,c90=/\binto\s+(?:[`"[]?([A-Za-z_][\w$]*)[`"\]]?\s*\.\s*)?[`"[]?([A-Za-z_][\w$]*)/i,l90=/^[\s;]*(?:--[^\n]*\n|\/\*[\s\S]*?\*\/|\s)*update\s+(?:or\s+\w+\s+)?(?:[`"[]?([A-Za-z_][\w$]*)[`"\]]?\s*\.\s*)?[`"[]?([A-Za-z_][\w$]*)/i,o90=/\bfrom\s+(?:[`"[]?([A-Za-z_][\w$]*)[`"\]]?\s*\.\s*)?[`"[]?([A-Za-z_][\w$]*)/i,vv=new Map,ED=/\b(insert\s+(?:or\s+\w+\s+)?into|replace\s+into|update(?:\s+or\s+\w+)?|delete\s+from)\s+(?:[`"[]?([A-Za-z_][\w$]*)[`"\]]?\s*\.\s*)?[`"[]?([A-Za-z_][\w$]*)/gi,i90=(X)=>{let Y="",Q=!1;for(let J=0;J<X.length;J+=1){let $=X[J];if(Q){if(Y+=$==="'"?"'":" ",$==="'")Q=!1;continue}if($==="'"){Q=!0,Y+=" ";continue}Y+=$}return Y},r90=(X)=>{let Y=i90(X);ED.lastIndex=0;for(let Q=ED.exec(Y);Q!==null;Q=ED.exec(Y)){let J=(Q[3]??Q[2]).toLowerCase(),$=yv.get(J);if($===void 0)continue;let G=Q[1].toLowerCase();return{verb:G.startsWith("insert")?"INSERT":G.startsWith("replace")?"REPLACE":G.startsWith("update")?"UPDATE":"DELETE",table:J,role:$,sink:"unreadable"}}return null},n90=(X)=>{let Y=u90.exec(X);if(Y===null)return r90(X);let Q=Y[1].toUpperCase(),J=Q==="UPDATE"?l90.exec(X):Q==="DELETE"?o90.exec(X):c90.exec(X);if(J===null)return null;let $=(J[2]??J[1]).toLowerCase(),G=yv.get($);if(G===void 0)return null;return{verb:Q,table:$,role:G,sink:"readable"}},s90=(X)=>{let Y=vv.get(X);if(Y!==void 0)return Y;let Q=n90(X);return vv.set(X,Q),Q},F7=[],a90=()=>F7[F7.length-1],hv=(X)=>{let Y={operation:X,journaled:!1,unjournaled:void 0};F7.push(Y);let Q=!1;return()=>{if(Q)return;Q=!0;let J=F7.pop();if(J===Y)return;if(J!==void 0)F7.push(J);throw new T7(`scope for "${X}" closed out of order (top is "${J?.operation??"none"}")`)}},CD=(X)=>X.replace(/\s+/g," ").trim().slice(0,120),mv=(X,Y)=>{let Q=s90(X);if(Q===null)return;if(Q.role==="derived")throw new T7(`"${Q.table}" is maintained by SQL triggers only; no application statement may write it (${CD(X)})`);let J=a90();if(J===void 0)throw new T7(`${Q.verb} on "${Q.table}" ran outside any state transaction (${CD(X)})`);if(Q.role==="journal"){J.journaled=!0,wD(Q,X,Y);return}if(Q.role==="allocation"||Q.role==="cursor"){wD(Q,X,Y);return}if(J.journaled||J.unjournaled!==void 0){wD(Q,X,Y);return}throw new T7(`${Q.verb} on the work projection table "${Q.table}" in "${J.operation}" is not explained by any journal record in this transaction. Mint a work record and materialize it, or declare the write with unjournaledWorkMutation(...) if it deliberately mints no fact (${CD(X)})`)};var t90=new Set(["work_artifacts","work_board_posts","work_board_read_cursors","work_board_topics","work_delivery_receipts","work_events","work_messages","work_pad_meta","work_pad_posts","work_pad_read_cursors","work_pad_shapes","work_proposal_events","work_proposal_planning","work_requests","work_task_dependencies","work_task_finish","work_task_messages","work_task_proposals","work_tasks"]),e90=new Map([["work_events",["item_canvas_name","item_node_id"]],["work_proposal_events",["canvas_name","node_id"]],["work_delivery_receipts",["delivered_canvas_name","delivered_node_id"]]]),XY0=["canvas_name","node_id"],YY0=(X)=>{let Y=!1;for(let Q=0;Q<X.length;Q+=1){let J=X[Q];if(Y){if(J==="'")Y=!1;continue}if(J==="'"){Y=!0;continue}if(J!=="?")continue;let $=X[Q+1];if($!==void 0&&$>="0"&&$<="9")return!0}return!1},QY0=(X)=>{let Y=Array(X.length).fill(0),Q=0,J=!1,$=-1;for(let G=0;G<X.length;G+=1){let Z=X[G];if(Y[G]=Q,J){if(Z==="'")J=!1;continue}if(Z==="'"){J=!0;continue}if(Z==="("){Q+=1;continue}if(Z===")"){Q=Math.max(0,Q-1);continue}if($<0&&Q===0&&(Z==="w"||Z==="W")&&/^where\b/i.test(X.slice(G,G+6))&&(G===0||/\s|\)/.test(X[G-1]??" ")))$=G}return{depth:Y,whereAt:$}},fv=(X)=>{let Y=[],Q=!1;for(let J=0;J<X.length;J+=1){let $=X[J];if(Q){if($==="'")Q=!1;continue}if($==="'"){Q=!0;continue}if($==="?")Y.push(J)}return Y},Sv=(X,Y)=>{let Q=0,J=!1;for(let $=Y;$<X.length;$+=1){let G=X[$];if(J){if(G==="'")J=!1;continue}if(G==="'")J=!0;else if(G==="(")Q+=1;else if(G===")"){if(Q-=1,Q===0)return{body:X.slice(Y+1,$),end:$}}}return null},kv=(X)=>{let Y=[],Q=0,J=!1,$=0;for(let G=0;G<X.length;G+=1){let Z=X[G];if(J){if(Z==="'")J=!1;continue}if(Z==="'")J=!0;else if(Z==="(")Q+=1;else if(Z===")")Q-=1;else if(Z===","&&Q===0)Y.push(X.slice($,G)),$=G+1}return Y.push(X.slice($)),Y},JY0=(X)=>fv(X).length,$Y0=(X,Y)=>{let Q=/\binto\b/i.exec(X);if(Q===null)return null;let J=X.indexOf("(",Q.index);if(J<0)return null;let $=Sv(X,J);if($===null)return null;let G=/\bvalues\b/i.exec(X.slice($.end));if(G===void 0||G===null)return null;let Z=X.indexOf("(",$.end+G.index);if(Z<0)return null;let K=Sv(X,Z);if(K===null)return null;if(X.slice(K.end+1).replace(/^[\s]+/,"").startsWith(","))return null;let W=kv($.body).map((q)=>q.trim().replace(/^["`[]|["`\]]$/g,"").toLowerCase()),D=kv(K.body);if(W.length!==D.length)return null;let U=new Map,N=0;for(let q=0;q<D.length;q+=1){let F=D[q].trim();if(F==="?"){U.set(W[q],N),N+=1;continue}N+=JY0(F)}let V=U.get(Y[0]),z=U.get(Y[1]);if(V===void 0||z===void 0)return null;return{canvas:V,node:z}},_Y0=(X,Y)=>{let Q=fv(X),J=QY0(X);if(J.whereAt<0)return null;for(let K of Y){let H=new RegExp(`\\b${K}\\s*=`,"gi");for(let W=H.exec(X);W!==null;W=H.exec(X)){if((J.depth[W.index]??0)!==0)continue;if(W.index<J.whereAt)return null}}let $=(K)=>{let H=new RegExp(`\\b${K}\\s*=\\s*\\?`,"gi"),W;for(let D=H.exec(X);D!==null;D=H.exec(X)){if((J.depth[D.index]??0)!==0)continue;if(D.index<J.whereAt)continue;if(W!==void 0)return;let U=X.indexOf("?",D.index),N=Q.indexOf(U);if(N<0)return;W=N}return W},G=$(Y[0]),Z=$(Y[1]);if(G===void 0||Z===void 0)return null;return{canvas:G,node:Z}},bv=new Map,GY0=(X,Y)=>{let Q=bv.get(Y);if(Q!==void 0)return Q;let J=e90.get(X.table)??XY0,$=X.sink==="unreadable"||YY0(Y)?null:X.verb==="INSERT"||X.verb==="REPLACE"?$Y0(Y,J):_Y0(Y,J);return bv.set(Y,$),$},gv=new Set;var wD=(X,Y,Q)=>{if(gv.size===0)return;if(!t90.has(X.table))return;let J,$;if(Array.isArray(Q)){let G=GY0(X,Y);if(G!==null){let Z=Q[G.canvas],K=Q[G.node];if(typeof Z==="string"&&typeof K==="string")J=Z,$=K}}for(let G of gv)G(J,$)};import{mkdtempDisposableSync as ZY0}from"node:fs";import{tmpdir as KY0}from"node:os";import{join as xD}from"node:path";var MD,jD=()=>{if(MD===void 0)MD=process.argv.includes("--vellum-demo")||process.env.VELLUM_COMMAND_DEMO==="1";return MD};var r9,ID=!1,pv=()=>{HY0()},dv=()=>{if(r9!==void 0)return r9;return r9=ZY0(xD(KY0(),"vellum-command-demo-runtime-")),process.once("exit",pv),ID=!0,r9},uv=()=>jD()?xD(dv().path,"vellum-command.db"):void 0,HY0=()=>{if(ID)process.off("exit",pv),ID=!1;let X=r9;r9=void 0,X?.remove()};if(jD()&&!process.env.VELLUM_COMMAND_CANVASES_DIR)process.env.VELLUM_COMMAND_CANVASES_DIR=xD(dv().path,"projections");import{randomUUID as WY0}from"node:crypto";import{chmodSync as UY0,closeSync as SD,constants as A5,fchmodSync as DY0,fstatSync as kD,fsyncSync as ov,linkSync as NY0,lstatSync as G6,mkdirSync as VY0,openSync as bD,readdirSync as BY0,unlinkSync as iv}from"node:fs";import{join as b_}from"node:path";import{DatabaseSync as zY0}from"node:sqlite";var cv=448,qY0=384,rv="backups",OY0="vellum-command-backup-",LY0=".pending",TY0=/^vellum-command-backup-[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\.db\.pending$/u,k_=(X)=>{try{let Y=G6(X);if(!Y.isFile()||Y.isSymbolicLink())throw Error(`state backup is not a regular file: ${X}`);return!0}catch(Y){if(typeof Y==="object"&&Y!==null&&"code"in Y&&Y.code==="ENOENT")return!1;throw Y}},FY0=(X)=>{let Y=bD(X,A5.O_RDONLY|A5.O_NOFOLLOW);try{let Q=kD(Y);if(!Q.isFile())throw Error(`state backup is not a regular file: ${X}`);DY0(Y,qY0);let J=G6(X);if(!J.isFile()||J.isSymbolicLink()||J.dev!==Q.dev||J.ino!==Q.ino)throw Error(`state backup path changed during creation: ${X}`);return{device:Q.dev,inode:Q.ino}}finally{SD(Y)}},RY0=(X,Y)=>{try{let Q=G6(X);if(Q.isFile()&&!Q.isSymbolicLink()&&Q.dev===Y.device&&Q.ino===Y.inode)iv(X)}catch{}},vD=(X,Y)=>{let Q=G6(X);if(!Q.isFile()||Q.isSymbolicLink()||Q.dev!==Y.device||Q.ino!==Y.inode)throw Error(`state backup path changed before removal: ${X}`);iv(X)},AY0=(X,Y)=>{let Q=bD(X,A5.O_RDONLY|A5.O_NOFOLLOW);try{let J=kD(Q),$=G6(X);if(!J.isFile()||!$.isFile()||$.isSymbolicLink()||J.dev!==Y.device||J.ino!==Y.inode||$.dev!==Y.device||$.ino!==Y.inode)throw Error(`state backup path changed before sync: ${X}`);ov(Q)}finally{SD(Q)}},g_=(X)=>{let Y=bD(X,A5.O_RDONLY|A5.O_NOFOLLOW|A5.O_DIRECTORY);try{if(!kD(Y).isDirectory())throw Error(`state backup path is not a real directory: ${X}`);ov(Y)}finally{SD(Y)}},PY0=(X)=>{let Y=b_(X,rv),Q=!1;try{VY0(Y,{mode:cv}),Q=!0}catch($){if(typeof $!=="object"||$===null||!("code"in $)||$.code!=="EEXIST")throw $}let J=G6(Y);if(!J.isDirectory()||J.isSymbolicLink())throw Error(`state backup path is not a real directory: ${Y}`);if(UY0(Y,cv),Q)g_(X);return Y},EY0=(X)=>{let Y=b_(X,rv),Q;try{let $=G6(Y);if(!$.isDirectory()||$.isSymbolicLink())throw Error(`state backup path is not a real directory: ${Y}`);Q=BY0(Y)}catch($){if(typeof $==="object"&&$!==null&&"code"in $&&$.code==="ENOENT")return;throw $}let J=!1;for(let $ of Q){if(!TY0.test($))continue;let G=b_(Y,$),Z=G6(G);if(!Z.isFile()||Z.isSymbolicLink())throw Error(`pending state backup is not a regular file: ${G}`);vD(G,{device:Z.dev,inode:Z.ino}),J=!0}if(J)g_(Y)},CY0=(X)=>`"${X.replaceAll('"','""')}"`,lv=(X)=>{let Y=X.prepare("PRAGMA user_version").get(),Q=X.prepare(`
      SELECT actual_schema_sha256
      FROM state_schema_identity
      WHERE singleton = 1
    `).get();if(Q===void 0)throw Error("state backup source has no schema identity witness");let J=X.prepare(`
      SELECT type, name, tbl_name AS table_name, sql
      FROM sqlite_schema
      WHERE type IN ('table', 'index', 'view', 'trigger')
        AND name NOT GLOB 'sqlite_*'
      ORDER BY type COLLATE BINARY, name COLLATE BINARY
    `).all(),$=J.filter((G)=>G.type==="table");return{userVersion:Number(Y?.user_version),identity:{actualSchemaSha256:String(Q.actual_schema_sha256)},schema:J.map((G)=>({type:String(G.type),name:String(G.name),tableName:String(G.table_name),sql:G.sql===null?null:String(G.sql)})),rowCounts:$.map((G)=>{let Z=String(G.name),K=X.prepare(`SELECT count(*) AS count FROM ${CY0(Z)}`).get();return{tableName:Z,count:Number(K?.count)}})}},wY0=(X,Y)=>{if(JSON.stringify(X)!==JSON.stringify(Y))throw Error("state backup witness does not match its live source")},gD=(X,Y)=>{let Q=lv(X);EY0(Y);let J=PY0(Y),$=WY0(),G=b_(J,`${OY0}${$}.db`),Z=`${G}${LY0}`;if(k_(G))throw Error(`backup destination already exists: ${G}`);if(k_(Z))throw Error(`backup destination already exists: ${Z}`);try{X.prepare("VACUUM INTO ?").run(Z)}catch(U){if(k_(Z)){let N=G6(Z);vD(Z,{device:N.dev,inode:N.ino}),g_(J)}throw U}let K=G6(Z);if(!K.isFile()||K.isSymbolicLink())throw Error(`state backup is not a regular file: ${Z}`);let H={device:K.dev,inode:K.ino},W,D=!1;try{let U=FY0(Z);if(U.device!==H.device||U.inode!==H.inode)throw Error(`state backup path changed during creation: ${Z}`);W=new zY0(Z,{open:!0,readOnly:!0,allowExtension:!1,enableForeignKeyConstraints:!0,enableDoubleQuotedStringLiterals:!1,allowBareNamedParameters:!1,allowUnknownNamedParameters:!1});let N=W.prepare("PRAGMA quick_check").all();if(N.length!==1||String(N[0]?.quick_check)!=="ok")throw Error("state backup quick_check failed");let V=W.prepare("PRAGMA foreign_key_check").all();if(V.length>0)throw Error(`state backup has ${V.length} foreign-key violation(s)`);if(wY0(Q,lv(W)),W.close(),W=void 0,AY0(Z,H),k_(G))throw Error(`backup destination already exists: ${G}`);NY0(Z,G);let z=G6(G);if(!z.isFile()||z.isSymbolicLink()||z.dev!==H.device||z.ino!==H.inode)throw Error(`state backup changed during publication: ${G}`);vD(Z,H),g_(J),D=!0}finally{if(W?.close(),!D)RY0(Z,H)}return{path:G,schemaSha256:Q.identity.actualSchemaSha256,schemaVersion:Q.userVersion}};var nv=448,vY0=384,sv=5000,SY0=64,y_=(X,Y)=>Y instanceof O7?Y:O7.make({operation:X,message:Y instanceof Error?Y.message:String(Y),cause:Y}),hD=()=>ev(uv()??IY0(x_(),".vellum-command","state","vellum-command.db")),kY0=(X)=>{MY0(X,{recursive:!0,mode:nv});let Y=tv(X);if(!Y.isDirectory()||Y.isSymbolicLink())throw Error(`state path is not a real directory: ${X}`);av(X,nv)},bY0=(X)=>{try{let Y=tv(X);if(!Y.isFile()||Y.isSymbolicLink())throw Error(`state database is not a regular file: ${X}`);return!0}catch(Y){if(typeof Y==="object"&&Y!==null&&"code"in Y&&Y.code==="ENOENT")return!1;throw Y}},yD=(X,Y,Q,J)=>{if(Y===void 0)return Q();if(Array.isArray(Y))return Q(...Y);return J({...Y})},gY0=(X)=>i0.try({try:()=>{let Y=ev(X??hD()),Q=jY0(Y);kY0(Q),bY0(Y);let J=new xY0(Y,{open:!0,readOnly:!1,allowExtension:!1,enableForeignKeyConstraints:!0,enableDoubleQuotedStringLiterals:!1,allowBareNamedParameters:!1,allowUnknownNamedParameters:!1,timeout:sv}),$=!1,G=new Map,Z=!1,K=(()=>{try{if(av(Y,vY0),J.exec(`
            PRAGMA foreign_keys = ON;
            PRAGMA busy_timeout = ${sv};
            PRAGMA trusted_schema = OFF;
          `),Rv(J))gD(J,Q);let O=Av(J);return J.exec(`
            PRAGMA journal_mode = WAL;
            PRAGMA synchronous = NORMAL;
          `),O}catch(O){throw J.close(),O}})(),H=()=>{if($)throw Error("state engine is closed")},W=(O)=>{H();let E=G.get(O);if(E)return E;let A=J.prepare(O);return G.set(O,A),A},D=()=>{if(FD)Mv?.countStatement()},U={get:(O,E)=>{return D(),yD(W(O),E,(...A)=>W(O).get(...A),(A)=>W(O).get(A))},all:(O,E)=>{return D(),yD(W(O),E,(...A)=>W(O).all(...A),(A)=>W(O).all(A))}},N={...U,run:(O,E)=>{return mv(O,E),D(),yD(W(O),E,(...A)=>W(O).run(...A),(A)=>W(O).run(A))}},V=(O,E)=>i0.try({try:()=>{return H(),E(U)},catch:(A)=>y_(O,A)}).pipe(i0.withSpan(`state.${O}`)),z=(O,E)=>i0.try({try:()=>xv(`state.${O}`,()=>{if(H(),Z)throw Error(`nested state transaction is not allowed (${O})`);let A=hv(O);Z=!0,J.exec("BEGIN IMMEDIATE");try{let x=E(N);return J.exec("COMMIT"),x}catch(x){try{J.exec("ROLLBACK")}catch{}throw x}finally{A(),Z=!1}}),catch:(A)=>y_(O,A)}).pipe(i0.withSpan(`state.${O}`)),q=(O,E,A,x={})=>i0.gen(function*(){let n=Math.max(1,Math.floor(x.chunkRows??SY0));for(let x0=0;x0<E.length;x0+=n){let f0=E.slice(x0,x0+n);if(yield*z(`${O}.chunk`,(B0)=>A(B0,f0)),x0+n<E.length)yield*i0.sleep("1 millis")}}).pipe(i0.withSpan(`state.${O}`)),F=()=>i0.try({try:()=>{return H(),gD(J,Q)},catch:(O)=>y_("backup",O)}).pipe(i0.withSpan("state.backup")),R=U.get("PRAGMA journal_mode")?.journal_mode,C=U.get("PRAGMA synchronous")?.synchronous,w=U.get("PRAGMA foreign_keys")?.foreign_keys,a={path:Y,journalMode:String(R??""),synchronous:Number(C??-1),foreignKeys:Number(w??0)===1,schemaSha256:K.actualSchemaSha256,schemaVersion:K.schemaVersion};return{service:L7.of({info:a,read:V,transaction:z,chunkedWrite:q,backup:F}),close:()=>{if($)return;$=!0,G.clear(),J.close()}}},catch:(Y)=>y_("open",Y)}),yY0=(X)=>t5.effect(L7,i0.acquireRelease(gY0(X),({close:Y})=>i0.sync(Y)).pipe(i0.map(({service:Y})=>Y))),tN0=yY0();var dY0=(X)=>{try{let Y=mY0(X);return Y.isFile()&&!Y.isSymbolicLink()}catch{return!1}},mD=(X)=>{let Y=fY0(X??hD());if(!hY0(Y))return{kind:"missing"};if(!dY0(Y))return{kind:"unreadable",message:`state database path is not a regular file: ${Y}`};let Q;try{Q=new pY0(Y,{open:!0,readOnly:!0,allowExtension:!1,enableForeignKeyConstraints:!0,enableDoubleQuotedStringLiterals:!1,allowBareNamedParameters:!1,allowUnknownNamedParameters:!1,timeout:2000});let J=Q.prepare("PRAGMA user_version").get(),$=Number(J?.user_version??0);if(!Number.isSafeInteger($)||$<0)return{kind:"unreadable",message:`state schema user_version is invalid: ${String(J?.user_version)}`};return{kind:"present",userVersion:$,path:Y}}catch(J){return{kind:"unreadable",message:J instanceof Error?J.message:String(J)}}finally{try{Q?.close()}catch{}}},XS=(X=mD(),Y=i9)=>{if(X.kind==="missing")return{ok:!0,userVersion:null};if(X.kind==="unreadable")return{ok:!0,userVersion:null};if(X.userVersion>Y)return{ok:!1,reason:"newer-than-supported",userVersion:X.userVersion,supportedVersion:Y,path:X.path};return{ok:!0,userVersion:X.userVersion}};var uY0=(X)=>X==="REMOTE STATIONS ARE RELEASED",YS=(X,Y)=>{if(!Number.isSafeInteger(Y)||Y<1)throw TypeError(`${X} version must be a positive safe integer`);if(!uY0("REMOTE STATIONS ARE NOT RELEASED")&&Y!==1)throw TypeError(`${X} must remain at version 1 until REMOTE_STATIONS_RELEASE_STATE is "REMOTE STATIONS ARE RELEASED"`);return Y};var P5=YS("Station protocol",1),h_=_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThan(0)),_.check(_.makeFilter(Number.isSafeInteger,{message:"Station protocol version must be a safe integer"}))),QS=_.Struct({preferred:h_,compatibleFrom:h_,warnBelow:h_}).pipe(_.check(_.makeFilter(({compatibleFrom:X,warnBelow:Y,preferred:Q})=>X<=Y&&Y<=Q,{message:"Station protocol support must satisfy compatibleFrom <= warnBelow <= preferred"}))),m_=QS.make({preferred:P5,compatibleFrom:P5,warnBelow:P5}),JS=(X,Y)=>{let Q=Math.max(X.compatibleFrom,Y.compatibleFrom),J=Math.min(X.preferred,Y.preferred);if(Q>J)return{_tag:"no-common",local:X,peer:Y};let $=J<X.warnBelow,G=J<Y.warnBelow;return{_tag:"selected",selected:J,deprecatedForLocal:$,deprecatedForPeer:G,warning:$||G}},cY0=_.NonEmptyString.pipe(_.check(_.isMaxLength(64))),lY0=_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThan(0)),_.check(_.makeFilter(Number.isSafeInteger,{message:"state schema version must be a safe integer"}))),f_="vellum-command/station-protocol-preface/v1",fD={appVersion:cY0,stateSchemaVersion:lY0,support:QS},oY0=_.Struct({protocol:_.Literal(f_),frame:_.Literal("offer"),...fD}),iY0=_.Struct({protocol:_.Literal(f_),frame:_.Literal("accept"),...fD,selected:h_}),$S=_.Struct({protocol:_.Literal(f_),frame:_.Literal("reject"),...fD,reason:_.Literal("no-common-version"),retryable:_.Literal(!1)}),rY0=_.Union([oY0,iY0,$S]),WV0=_.decodeUnknownResult(rY0,{onExcessProperty:"error"});var _S=(X)=>$S.make({protocol:f_,frame:"reject",...X,reason:"no-common-version",retryable:!1}),pD=(X)=>X===P5?k0.succeed(P5):k0.fail("unsupported-station-protocol");var q4=_.String.pipe(_.check(_.isMinLength(1)),_.check(_.isMaxLength(128)),_.check(_.isPattern(/^[A-Za-z0-9][A-Za-z0-9._:-]*$/)),_.brand("InstallationId"));var dD="vellum/work/v2",GS=262144,nY0=2048,sY0=64,ZS=_.String.pipe(_.check(_.isPattern(/^[1-9][0-9]*$/)),_.check(_.isMaxLength(32)),_.brand("WorkLogicalSequence")),E5=_.String.pipe(_.check(_.isPattern(/^[a-f0-9]{64}$/)),_.brand("WorkSha256")),uD=_.String.pipe(_.check(_.isMinLength(1)),_.check(_.isMaxLength(sY0))),aY0=_.String.pipe(_.check(_.isMinLength(1)),_.check(_.isMaxLength(nY0))),tY0=_.Struct({eventHome:q4,entityHome:q4}),O4=_.Struct({route:tY0,seq:ZS}),KS=_.String.pipe(_.check(_.isPattern(/^(0|[1-9][0-9]*)$/)),_.check(_.isMaxLength(32)),_.brand("FactBasisGeneration")),HS=_.Struct({kind:_.Literal("authorial-intent"),generation:KS,contentSha256:E5}),WS=_.Struct({kind:_.Literal("projected-intent"),generation:KS,contentSha256:E5}),eY0=_.Struct({kind:_.Literal("command"),command:O4,commandSha256:E5}),XQ0=_.Union([HS,WS,eY0]),MV0=_.Union([HS,WS]),jV0=_.Struct({eventHome:q4,entityHome:q4,through:ZS}),YQ0=_.Literals(["proposal.create","proposal.approve","proposal.reject","task.create","task.describe","task.transition","task.claim","request.create","request.resolve","message.append","artifact.publish","delivery.accepted","board.topic.create","board.post.append","pad.patch"]),QQ0=_.Struct({operation:_.Literal("proposal.create"),proposal:L5}).pipe(_.check(_.makeFilter(({proposal:X})=>X.state==="pending"||"proposal.create requires a pending proposal"))),JQ0=_.Struct({operation:_.Literal("proposal.approve"),proposalId:SX,task:LX}).pipe(_.check(_.makeFilter(({task:X})=>X.state==="submitted"&&X.claimedBy===void 0||"proposal.approve requires a submitted unclaimed task"))),$Q0=_.Struct({operation:_.Literal("proposal.reject"),proposalId:SX}),US=_.Struct({deliveryId:SX,deliveredItem:$_,actor:J6,acceptedAt:uD}),_Q0=_.Struct({operation:_.Literal("task.create"),task:LX}).pipe(_.check(_.makeFilter(({task:X})=>X.state==="submitted"&&X.claimedBy===void 0||"task.create requires a submitted task snapshot"))),GQ0=_.Struct({operation:_.Literal("task.describe"),taskId:SX,message:L8}),ZQ0=_.Struct({operation:_.Literal("task.transition"),taskId:SX,state:f9,message:_.optionalKey(L8),completionEvidence:_.optionalKey(d9)}).pipe(_.check(_.makeFilter(({state:X,completionEvidence:Y})=>Y===void 0||X==="completed"||"completionEvidence is only allowed when state is completed"))),KQ0=_.Struct({operation:_.Literal("task.claim"),sourceQueueHome:q4,sourcePredecessor:_.NullOr(O4),sourceTask:LX,sink:J_,actor:J6,targetHome:q4}).pipe(_.check(_.makeFilter((X)=>{if(X.sourceTask.state!=="submitted")return"task.claim requires a submitted source task snapshot";if(X.sourceTask.claimedBy!==void 0)return"task.claim requires an unclaimed source task snapshot";if(X.sourceQueueHome===X.targetHome)return"task.claim command must cross authority installations";if(X.sourcePredecessor!==null&&(X.sourcePredecessor.route.eventHome!==X.sourceQueueHome||X.sourcePredecessor.route.entityHome!==X.sourceQueueHome))return"task.claim source predecessor must belong to the source queue authority lane";return!0}))),HQ0=_.Struct({operation:_.Literal("request.create"),request:LX,raisedBy:J6}).pipe(_.check(_.makeFilter(({request:X,raisedBy:Y})=>X.state==="input-required"&&X.claimedBy===Y.seatId||"request.create requires an input-required request claimed by its raiser"))),WQ0=_.Struct({operation:_.Literal("request.resolve"),requestId:SX,response:_.String,disposition:_.Literals(["completed","rejected"]),message:_.optionalKey(L8)}),UQ0=_.Union([_.Struct({kind:_.Literal("mailbox")}),_.Struct({kind:_.Literal("task"),itemId:SX}),_.Struct({kind:_.Literal("request"),itemId:SX})]),DS={message:L8,sentBy:J6,destination:UQ0},NS=(X)=>X.destination.kind==="mailbox"||X.message.taskId===X.destination.itemId?!0:"task/request message destination must equal Message.taskId",DQ0=_.Struct({operation:_.Literal("message.append"),...DS}).pipe(_.check(_.makeFilter(NS))),NQ0=_.Struct({operation:_.Literal("artifact.publish"),artifact:U7,publishedBy:J6}),VQ0=_.Struct({operation:_.Literal("delivery.accepted"),receipt:US}),BQ0=_.Struct({operation:_.Literal("board.topic.create"),topic:N7,createdBy:kX}),zQ0=_.Struct({operation:_.Literal("board.post.append"),post:D7,createdBy:kX}),qQ0=_.Struct({operation:_.Literal("pad.patch"),patchId:SX,patches:_.Array(u9).pipe(_.check(_.isMinLength(1))),author:kX}),VS=_.Union([QQ0,JQ0,$Q0,_Q0,GQ0,ZQ0,KQ0,HQ0,WQ0,DQ0,NQ0,VQ0,BQ0,zQ0,qQ0]),OQ0=_.Struct({operation:_.Literal("proposal.create"),proposal:L5}).pipe(_.check(_.makeFilter(({proposal:X})=>X.state==="pending"||"proposal.create result requires a pending proposal"))),LQ0=_.Struct({operation:_.Literal("proposal.approve"),proposal:L5,task:LX}).pipe(_.check(_.makeFilter(({proposal:X,task:Y})=>X.state==="approved"&&X.approvedTaskId===Y.id&&Y.state==="submitted"&&Y.claimedBy===void 0||"proposal.approve result must bind the approved proposal to its submitted task"))),TQ0=_.Struct({operation:_.Literal("proposal.reject"),proposal:L5}).pipe(_.check(_.makeFilter(({proposal:X})=>X.state==="rejected"||"proposal.reject result requires a rejected proposal"))),FQ0=_.Struct({operation:_.Literal("task.create"),task:LX}).pipe(_.check(_.makeFilter(({task:X})=>X.state==="submitted"&&X.claimedBy===void 0||"task.create result requires a submitted unclaimed task"))),RQ0=_.Struct({operation:_.Literals(["task.describe","task.transition"]),task:LX}),AQ0=_.Struct({operation:_.Literal("task.claim"),task:LX,claimedBy:J6,previousHome:q4}).pipe(_.check(_.makeFilter(({task:X,claimedBy:Y})=>X.state==="working"&&X.claimedBy===Y.seatId||"task.claim result requires a working task claimed by the exact actor seat"))),PQ0=_.Struct({operation:_.Literals(["request.create","request.resolve"]),request:LX}).pipe(_.check(_.makeFilter((X)=>{if(X.operation==="request.create")return X.request.state==="input-required"&&X.request.claimedBy!==void 0||"request.create result requires an input-required request with a claimant";return(X.request.state==="completed"||X.request.state==="rejected")&&X.request.claimedBy!==void 0||"request.resolve result requires a completed or rejected request with its original claimant"}))),EQ0=_.Struct({operation:_.Literal("message.append"),...DS}).pipe(_.check(_.makeFilter(NS))),CQ0=_.Struct({operation:_.Literal("artifact.publish"),artifact:U7,publishedBy:J6}),wQ0=_.Struct({operation:_.Literal("delivery.accepted"),receipt:US}),MQ0=_.Struct({operation:_.Literal("board.topic.create"),topic:N7,createdBy:kX}),jQ0=_.Struct({operation:_.Literal("board.post.append"),post:D7,createdBy:kX}),IQ0=_.Struct({operation:_.Literal("pad.patch"),patchId:SX,patches:_.Array(u9).pipe(_.check(_.isMinLength(1))),author:kX,revision:_.Number.pipe(_.check(_.isInt()),_.check(_.isGreaterThanOrEqualTo(0)))}),BS=_.Union([OQ0,LQ0,TQ0,FQ0,RQ0,AQ0,PQ0,EQ0,CQ0,wQ0,MQ0,jQ0,IQ0]),xQ0=_.Literals(["authority-mismatch","capability-denied","causal-conflict","claim-contention","identity-conflict","invalid-transition","locality-mismatch","missing-entity","projection-conflict","target-mismatch"]),vQ0=_.Struct({status:_.Literal("applied"),command:O4,commandSha256:E5,fact:O4,factSha256:E5}),SQ0=_.Struct({status:_.Literal("rejected"),command:O4,commandSha256:E5,reason:xQ0,message:aY0}),kQ0=_.Union([vQ0,SQ0]),cD=_.Struct({protocol:_.Literal(dD),id:O4,recordType:_.Literals(["command","fact","disposition"]),item:$_,operation:YQ0,contentSha256:E5,originAt:uD}),bQ0=(X,Y)=>X.canvasName===Y.canvasName&&X.nodeId===Y.nodeId,zS=(X,Y,Q)=>X.kind==="artifact"&&X.itemId===Y.artifactId&&Q.canvasName===X.sink.canvasName&&(Y.task===void 0||Y.task.sink.canvasName===X.sink.canvasName),gQ0=(X,Y)=>{switch(Y.operation){case"proposal.create":return X.kind==="proposal"&&X.itemId===Y.proposal.id;case"proposal.approve":case"proposal.reject":return X.kind==="proposal"&&X.itemId===Y.proposalId;case"task.create":return X.kind==="task"&&X.itemId===Y.task.id;case"task.describe":case"task.transition":return X.kind==="task"&&X.itemId===Y.taskId;case"task.claim":return X.kind==="task"&&X.itemId===Y.sourceTask.id&&bQ0(X.sink,Y.sink);case"request.create":return X.kind==="request"&&X.itemId===Y.request.id;case"request.resolve":return X.kind==="request"&&X.itemId===Y.requestId;case"message.append":return X.kind==="message"&&X.itemId===Y.message.messageId;case"artifact.publish":return zS(X,Y.artifact,Y.publishedBy);case"delivery.accepted":return X.kind==="delivery"&&X.itemId===Y.receipt.deliveryId;case"board.topic.create":return X.kind==="topic"&&X.itemId===Y.topic.topicId;case"board.post.append":return X.kind==="post"&&X.itemId===Y.post.postId;case"pad.patch":return X.kind==="pad"&&X.itemId===Y.patchId}},yQ0=(X,Y)=>{switch(Y.operation){case"proposal.create":case"proposal.approve":case"proposal.reject":return X.kind==="proposal"&&X.itemId===Y.proposal.id;case"task.create":case"task.describe":case"task.transition":case"task.claim":return X.kind==="task"&&X.itemId===Y.task.id;case"request.create":case"request.resolve":return X.kind==="request"&&X.itemId===Y.request.id;case"message.append":return X.kind==="message"&&X.itemId===Y.message.messageId;case"artifact.publish":return zS(X,Y.artifact,Y.publishedBy);case"delivery.accepted":return X.kind==="delivery"&&X.itemId===Y.receipt.deliveryId;case"board.topic.create":return X.kind==="topic"&&X.itemId===Y.topic.topicId;case"board.post.append":return X.kind==="post"&&X.itemId===Y.post.postId;case"pad.patch":return X.kind==="pad"&&X.itemId===Y.patchId}},qS=(X)=>X==="proposal.create"||X==="task.create"||X==="task.claim"||X==="request.create"||X==="message.append"||X==="artifact.publish"||X==="delivery.accepted"||X==="board.topic.create"||X==="board.post.append"||X==="pad.patch",hQ0=(X)=>{try{let Y=JSON.stringify(X);return Y===void 0?void 0:new TextEncoder().encode(Y).byteLength}catch{return}};var lD=(X)=>{let Y=hQ0(X);if(Y===void 0)return"Work record must be JSON-serializable";return Y<=GS||`Work record exceeds ${GS} encoded bytes`},mQ0=_.Struct({...cD.fields,recordType:_.Literal("command"),predecessor:_.NullOr(O4),body:VS}),fQ0=mQ0.pipe(_.check(_.makeFilter((X)=>{if(X.id.route.eventHome===X.id.route.entityHome)return"Work command event and entity homes must be different";if(X.operation!==X.body.operation)return"Work command operation must match its action";if(!gQ0(X.item,X.body))return"Work command item must match its action identity";if(X.body.operation==="task.claim"){if(X.predecessor!==null)return"Cross-home task.claim command predecessor must be null";if(X.id.route.entityHome!==X.body.targetHome)return"task.claim targetHome must match command entityHome";return!0}if(qS(X.operation))return X.predecessor===null||"Create command predecessor must be null";return X.predecessor!==null||"Mutation command must name its predecessor"})),_.check(_.makeFilter(lD))),pQ0=_.Struct({...cD.fields,recordType:_.Literal("fact"),basis:XQ0,predecessor:_.NullOr(O4),body:BS}),dQ0=pQ0.pipe(_.check(_.makeFilter((X)=>{if(X.id.route.eventHome!==X.id.route.entityHome)return"Work fact must be emitted by its entity authority home";if(X.operation!==X.body.operation)return"Work fact operation must match its result";if(!yQ0(X.item,X.body))return"Work fact item must match its result identity";if(X.basis.kind==="command"&&X.basis.command.route.entityHome!==X.id.route.entityHome)return"Command fact basis must address the fact authority lane";if(X.body.operation==="task.claim"){if(X.body.previousHome!==X.id.route.entityHome)return X.predecessor===null||"First cross-home task.claim fact predecessor must be null";return X.predecessor!==null||"Same-home task.claim fact must name its submitted predecessor"}if(qS(X.operation))return X.predecessor===null||"Create fact predecessor must be null";return X.predecessor!==null||"Mutation fact must name its predecessor"})),_.check(_.makeFilter(lD))),uQ0=_.Struct({...cD.fields,recordType:_.Literal("disposition"),body:kQ0}),cQ0=uQ0.pipe(_.check(_.makeFilter((X)=>{if(X.id.route.eventHome!==X.id.route.entityHome)return"Work disposition must be emitted by its entity authority home";if(X.body.command.route.entityHome!==X.id.route.entityHome)return"Work disposition must address the command entity authority lane";if(X.body.status==="applied"&&(X.body.fact.route.eventHome!==X.id.route.eventHome||X.body.fact.route.entityHome!==X.id.route.entityHome))return"Applied disposition fact must belong to the disposition authority lane";return!0})),_.check(_.makeFilter(lD))),OS=_.Union([fQ0,dQ0,cQ0]),lQ0=_.Struct({record:OS,receivedAt:uD}),p_={onExcessProperty:"error"},IV0=_.decodeUnknownResult(VS,p_),xV0=_.decodeUnknownResult(BS,p_),oD=_.decodeUnknownResult(OS,p_),vV0=_.decodeUnknownResult(lQ0,p_);var LS=(X)=>k0.isSuccess(X)?{ok:!0,value:X.success}:{ok:!1,error:String(X.failure)},TS=(X)=>{let Y=oD(X);return k0.isSuccess(Y)?{accepted:!0}:{accepted:!1,error:String(Y.failure),namesAdmission:/admission/u.test(String(Y.failure)),namesRaisedBy:/raisedBy/u.test(String(Y.failure))}},FS=()=>JSON.parse(oQ0(0,"utf8")),RS=()=>({tasksCreateSchemaId:U_.schema_id,stateSchemaVersion:i9,stationProtocolBaseline:P5,stationProtocolSupport:m_,workProtocol:dD}),iQ0=()=>_S({appVersion:"qualification-probe",stateSchemaVersion:i9,support:m_}),AS=process.argv[2],R7;switch(AS){case"cohort":R7=RS();break;case"decode-work-record":R7=LS(oD(FS()));break;case"matrix":{let X=FS(),Y=JS(m_,X.peer),Q=0,J=Y._tag==="no-common"?{accepted:!1,reason:"no-common-version"}:(()=>{let $=pD(Y.selected);if(k0.isFailure($))return{accepted:!1,reason:String($.failure)};return Q+=1,TS(X.guardedRecord)})();R7={cohort:RS(),records:Object.fromEntries(Object.entries(X.records).map(([$,G])=>[$,TS(G)])),negotiation:Y,localCodecForPeerPreferred:LS(pD(X.peer.preferred)),guarded:{versionedDecoderInvocations:Q,result:J,...Y._tag==="no-common"?{rejection:iQ0()}:{}}};break}case"schema-probe":{let X=process.argv[3];if(X===void 0)throw TypeError("schema-probe requires a path");let Y=mD(X);R7={probe:Y,compatibility:XS(Y)};break}default:throw TypeError(`unknown command: ${String(AS)}`)}process.stdout.write(`${JSON.stringify(R7)}
`);
