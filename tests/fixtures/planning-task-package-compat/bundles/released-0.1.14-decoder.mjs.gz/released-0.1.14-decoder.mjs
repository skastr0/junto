var Gv=Object.defineProperty;var Jv=(X)=>X;function $v(X,Y){this[X]=Jv.bind(null,Y)}var M6=(X,Y)=>{for(var Q in Y)Gv(X,Q,{get:Y[Q],enumerable:!0,configurable:!0,set:$v.bind(Y,Q)})};import{readFileSync as Q90}from"node:fs";var k1={};M6(k1,{pick:()=>sv,omit:()=>av,mutate:()=>tv,mergeAll:()=>Q$,merge:()=>S5,makeUnsafe:()=>F8,make:()=>K6,isReference:()=>tJ,isKey:()=>lv,isContext:()=>o_,getUnsafe:()=>FX,getReferenceUnsafe:()=>X$,getOrUndefined:()=>eJ,getOrElse:()=>iv,getOption:()=>Y$,get:()=>v1,empty:()=>x1,addOrOmit:()=>rv,add:()=>l1,ServiceTypeId:()=>c_,Service:()=>bX,Reference:()=>O0});var G0=(X,Y)=>{switch(Y.length){case 0:return X;case 1:return Y[0](X);case 2:return Y[1](Y[0](X));case 3:return Y[2](Y[1](Y[0](X)));case 4:return Y[3](Y[2](Y[1](Y[0](X))));case 5:return Y[4](Y[3](Y[2](Y[1](Y[0](X)))));case 6:return Y[5](Y[4](Y[3](Y[2](Y[1](Y[0](X))))));case 7:return Y[6](Y[5](Y[4](Y[3](Y[2](Y[1](Y[0](X)))))));case 8:return Y[7](Y[6](Y[5](Y[4](Y[3](Y[2](Y[1](Y[0](X))))))));case 9:return Y[8](Y[7](Y[6](Y[5](Y[4](Y[3](Y[2](Y[1](Y[0](X)))))))));default:{let Q=X;for(let _=0,G=Y.length;_<G;_++)Q=Y[_](Q);return Q}}},Zv={pipe(){return G0(this,arguments)}},N4=function(){function X(){}return X.prototype=Zv,X}();var V=function(X,Y){if(typeof X==="function")return function(){return X(arguments)?Y.apply(this,arguments):(Q)=>Y(Q,...arguments)};switch(X){case 0:case 1:throw RangeError(`Invalid arity ${X}`);case 2:return function(Q,_){if(arguments.length>=2)return Y(Q,_);return function(G){return Y(G,Q)}};case 3:return function(Q,_,G){if(arguments.length>=3)return Y(Q,_,G);return function(J){return Y(J,Q,_)}};default:return function(){if(arguments.length>=X)return Y.apply(this,arguments);let Q=arguments;return function(_){return Y(_,...Q)}}}};var u=(X)=>X;var Z1=(X)=>()=>X,I6=Z1(!0),q_=Z1(!1),z_=Z1(null),OX=Z1(void 0),O_=OX;function MJ(X,...Y){return G0(X,Y)}function a0(X){let Y=new WeakMap;return(Q)=>{if(Y.has(Q))return Y.get(Q);let _=X(Q);return Y.set(Q,_),_}}var l9=(X)=>{let Y=new Set(Reflect.ownKeys(X));if(X.constructor===Object)return Y;if(X instanceof Error)Y.delete("stack");let Q=Object.getPrototypeOf(X),_=Q;while(_!==null&&_!==Object.prototype){let G=Reflect.ownKeys(_);for(let J=0;J<G.length;J++)Y.add(G[J]);_=Object.getPrototypeOf(_)}if(Y.has("constructor")&&typeof X.constructor==="function"&&Q===X.constructor.prototype)Y.delete("constructor");return Y},F5=new WeakSet;function xX(X){return typeof X==="string"}function o9(X){return typeof X==="number"}function LD(X){return typeof X==="boolean"}function TD(X){return typeof X==="bigint"}function IJ(X){return typeof X==="symbol"}function L_(X){return xX(X)||o9(X)||IJ(X)}function u1(X){return typeof X==="function"}function RD(X){return X===void 0}function N1(X){return X!==void 0}function T_(X){return X!=null}function FD(X){return!1}function jJ(X){return!0}function j1(X){return typeof X==="object"&&X!==null&&!Array.isArray(X)}function SJ(X){return typeof X==="object"&&X!==null||u1(X)}var I=V(2,(X,Y)=>SJ(X)&&(Y in X)),j6=V(2,(X,Y)=>I(X,"_tag")&&X._tag===Y);function ED(X){return X instanceof Error}function S6(X){return I(X,Symbol.iterator)||xX(X)}var U0="~effect/interfaces/Hash",e=(X)=>{switch(typeof X){case"number":return v6(X);case"bigint":return S0(X.toString(10));case"boolean":return S0(String(X));case"symbol":return S0(String(X));case"string":return S0(X);case"undefined":return S0("undefined");case"function":case"object":if(X===null)return S0("null");else if(X instanceof Date)return S0(X.toISOString());else if(X instanceof RegExp)return S0(X.toString());else{if(F5.has(X))return R_(X);if(xJ.has(X))return xJ.get(X);let Y=Dv(X,()=>{if(Hv(X))return X[U0]();else if(typeof X==="function")return R_(X);else if(Array.isArray(X)||ArrayBuffer.isView(X))return r9(X);else if(X instanceof Map)return Wv(X);else if(X instanceof Set)return Uv(X);return gJ(X)});return xJ.set(X,Y),Y}default:throw Error(`BUG: unhandled typeof ${typeof X} - please report an issue at https://github.com/Effect-TS/effect/issues`)}},R_=(X)=>{if(!vJ.has(X))vJ.set(X,v6(Math.floor(Math.random()*Number.MAX_SAFE_INTEGER)));return vJ.get(X)},Y1=V(2,(X,Y)=>X*53^Y),F_=(X)=>X&3221225471|X>>>1&1073741824,Hv=(X)=>I(X,U0),v6=(X)=>{if(X!==X)return S0("NaN");if(X===1/0)return S0("Infinity");if(X===-1/0)return S0("-Infinity");let Y=X|0;if(Y!==X)Y^=X*4294967295;while(X>4294967295)Y^=X/=4294967295;return F_(Y)},S0=(X)=>{let Y=5381,Q=X.length;while(Q)Y=Y*33^X.charCodeAt(--Q);return F_(Y)},bJ=(X,Y)=>{let Q=12289;for(let _ of Y)Q^=Y1(e(_),e(X[_]));return F_(Q)},gJ=(X)=>bJ(X,l9(X)),yJ=(X,Y)=>(Q)=>{let _=X;for(let G of Q)_^=Y(G);return F_(_)},r9=yJ(6151,e),Wv=yJ(S0("Map"),([X,Y])=>Y1(e(X),e(Y))),Uv=yJ(S0("Set"),e),vJ=new WeakMap,xJ=new WeakMap,kJ=new WeakSet;function Dv(X,Y){if(kJ.has(X))return S0("[Circular]");kJ.add(X);let Q=Y();return kJ.delete(X),Q}var D0="~effect/interfaces/Equal";function o(){if(arguments.length===1)return(X)=>B4(X,arguments[0]);return B4(arguments[0],arguments[1])}function B4(X,Y){if(X===Y)return!0;if(X==null||Y==null)return!1;let Q=typeof X;if(Q!==typeof Y)return!1;if(Q==="number"&&X!==X&&Y!==Y)return!0;if(Q!=="object"&&Q!=="function")return!1;if(F5.has(X)||F5.has(Y))return!1;return Vv(X,Y,Bv)}function Nv(X,Y,Q){let _=hJ.has(X),G=mJ.has(Y);if(_&&G)return!0;if(_||G)return!1;hJ.add(X),mJ.add(Y);let J=Q();return hJ.delete(X),mJ.delete(Y),J}var hJ=new WeakSet,mJ=new WeakSet;function Bv(X,Y){if(e(X)!==e(Y))return!1;else if(X instanceof Date){if(!(Y instanceof Date))return!1;return X.toISOString()===Y.toISOString()}else if(X instanceof RegExp){if(!(Y instanceof RegExp))return!1;return X.toString()===Y.toString()}let Q=AD(X),_=AD(Y);if(Q!==_)return!1;let G=Q&&_;if(typeof X==="function"&&!G)return!1;return Nv(X,Y,()=>{if(G)return X[D0](Y);else if(Array.isArray(X)){if(!Array.isArray(Y)||X.length!==Y.length)return!1;return qv(X,Y)}else if(ArrayBuffer.isView(X)){if(!ArrayBuffer.isView(Y)||X.byteLength!==Y.byteLength)return!1;return zv(X,Y)}else if(X instanceof Map){if(!(Y instanceof Map)||X.size!==Y.size)return!1;return Lv(X,Y)}else if(X instanceof Set){if(!(Y instanceof Set)||X.size!==Y.size)return!1;return Tv(X,Y)}return Ov(X,Y)})}function Vv(X,Y,Q){let _=E_.get(X);if(!_)_=new WeakMap,E_.set(X,_);else if(_.has(Y))return _.get(Y);let G=Q(X,Y);_.set(Y,G);let J=E_.get(Y);if(!J)J=new WeakMap,E_.set(Y,J);return J.set(X,G),G}var E_=new WeakMap;function qv(X,Y){for(let Q=0;Q<X.length;Q++)if(!B4(X[Q],Y[Q]))return!1;return!0}function zv(X,Y){if(X.length!==Y.length)return!1;for(let Q=0;Q<X.length;Q++)if(X[Q]!==Y[Q])return!1;return!0}function Ov(X,Y){let Q=l9(X),_=l9(Y);if(Q.size!==_.size)return!1;for(let G of Q)if(!_.has(G)||!B4(X[G],Y[G]))return!1;return!0}function A_(X,Y){return function(_,G){for(let[J,Z]of _){let K=!1;for(let[H,W]of G)if(X(J,H)&&Y(Z,W)){K=!0;break}if(!K)return!1}return!0}}var Lv=A_(B4,B4);function P_(X){return function(Q,_){for(let G of Q){let J=!1;for(let Z of _)if(X(G,Z)){J=!0;break}if(!J)return!1}return!0}}var Tv=P_(B4),AD=(X)=>I(X,D0);var PD=(X)=>{return F5.add(X),X};var w_=Symbol.for("~effect/Redactable"),Rv=(X)=>I(X,w_);function i9(X){if(Rv(X))return dJ(X);return X}function dJ(X){return X[w_](globalThis[E5]?.context??Fv)}var E5="~effect/Fiber/currentFiber",Fv={"~effect/Context":{},mapUnsafe:new Map,pipe(){return G0(this,arguments)}};function A(X,Y){let Q=Y?.space??0,_=new WeakSet,G=!Q?"":typeof Q==="number"?" ".repeat(Q):Q,J=(W)=>G.repeat(W),Z=(W,D)=>{let U=W?.constructor;return U&&U!==Object.prototype.constructor&&U.name?`${U.name}(${D})`:D},K=(W)=>{try{return Reflect.ownKeys(W)}catch{return["[ownKeys threw]"]}};function H(W,D=0){if(Array.isArray(W)){if(_.has(W))return wD;if(_.add(W),!G||W.length<=1)return`[${W.map((N)=>H(N,D)).join(",")}]`;let U=W.map((N)=>H(N,D+1)).join(`,
`+J(D+1));return`[
${J(D+1)}${U}
${J(D)}]`}if(W instanceof Date)return fJ(W);if(!Y?.ignoreToString&&I(W,"toString")&&typeof W.toString==="function"&&W.toString!==Object.prototype.toString&&W.toString!==Array.prototype.toString){let U=Ev(W);if(W instanceof Error&&W.cause)return`${U} (cause: ${H(W.cause,D)})`;return U}if(typeof W==="string")return JSON.stringify(W);if(typeof W==="number"||W==null||typeof W==="boolean"||typeof W==="symbol")return String(W);if(typeof W==="bigint")return String(W)+"n";if(typeof W==="object"||typeof W==="function"){if(_.has(W))return wD;if(_.add(W),w_ in W)return A(dJ(W));if(Symbol.iterator in W)return`${W.constructor.name}(${H(Array.from(W),D)})`;let U=K(W);if(!G||U.length<=1){let B=`{${U.map((q)=>`${x6(q)}:${H(W[q],D)}`).join(",")}}`;return Z(W,B)}let N=`{
${U.map((B)=>`${J(D+1)}${x6(B)}: ${H(W[B],D+1)}`).join(`,
`)}
${J(D)}}`;return Z(W,N)}return String(W)}return H(X,0)}var wD="[Circular]";function x6(X){return typeof X==="string"?JSON.stringify(X):String(X)}function C_(X){return X.map((Y)=>`[${x6(Y)}]`).join("")}function fJ(X){try{return X.toISOString()}catch{return"Invalid Date"}}function Ev(X){try{let Y=X.toString();return typeof Y==="string"?Y:String(Y)}catch{return"[toString threw]"}}function V4(X,Y){let Q=[];return JSON.stringify(X,function(_,G){let J=i9(G);if(typeof J!=="object"||J===null)return J;while(Q.length>0&&Q[Q.length-1]!==this)Q.pop();if(Q.includes(J))return;return Q.push(J),J},Y?.space)}var K1=Symbol.for("nodejs.util.inspect.custom"),R1=(X)=>{try{if(I(X,"toJSON")&&u1(X.toJSON)&&X.toJSON.length===0)return X.toJSON();else if(Array.isArray(X))return X.map(R1)}catch{return"[toJSON threw]"}return i9(X)},CD=(X,Y=2)=>{if(typeof X==="string")return X;try{return typeof X==="object"?V4(X,{space:Y}):String(X)}catch{return String(X)}},T90={toJSON(){return R1(this)},[K1](){return this.toJSON()},toString(){return A(this.toJSON())}};class V8{called=!1;self;constructor(X){this.self=X}next(X){return this.called?{value:X,done:!0}:(this.called=!0,{value:this.self,done:!1})}[Symbol.iterator](){return new V8(this.self)}}var Pv=()=>{let Y={["~effect/Utils/internal"]:(G)=>{return G()}},Q={["~effect/Utils/internal"]:(G)=>{try{return G()}finally{}}};return Y["~effect/Utils/internal"](()=>Error().stack)?.includes("~effect/Utils/internal")===!0?Y["~effect/Utils/internal"]:Q["~effect/Utils/internal"]},H0=Pv();function k(X,Y,Q){if(Y==="__proto__")Object.defineProperty(X,Y,{value:Q,writable:!0,enumerable:!0,configurable:!0});else X[Y]=Q}function M_(X,Y){for(let Q of Reflect.ownKeys(Y))if(Object.prototype.propertyIsEnumerable.call(Y,Q))k(X,Q,Y[Q])}var G6="~effect/Effect",q4="~effect/Exit",wv={_A:u,_E:u,_R:u},ID=`${G6}/identifier`,J0=`${G6}/args`,u0=`${G6}/evaluate`,S1=`${G6}/successCont`,LX=`${G6}/failureCont`,q8=`${G6}/ensureCont`,z4=Symbol.for("effect/Effect/Yield"),k6={pipe(){return G0(this,arguments)},toJSON(){return{...this}},toString(){return A(this.toJSON(),{ignoreToString:!0,space:2})},[K1](){return this.toJSON()}},jD={[U0](){return bJ(this,Object.keys(this))},[D0](X){let Y=Object.keys(this),Q=Object.keys(X);if(Y.length!==Q.length)return!1;for(let _=0;_<Y.length;_++)if(Y[_]!==Q[_]||!o(this[Y[_]],X[Y[_]]))return!1;return!0}},Cv={[G6]:wv,...k6,[Symbol.iterator](){return new V8(this)},toJSON(){return{_id:"Effect",op:this[ID],...J0 in this?{args:this[J0]}:void 0}}},r=(X)=>I(X,G6),pJ=(X)=>I(X,q4),n9="~effect/Cause",s9="~effect/Cause/Reason",P5=(X)=>I(X,n9),SD=(X)=>I(X,s9);class b6{[n9];reasons;constructor(X){this[n9]=n9,this.reasons=X}pipe(){return G0(this,arguments)}toJSON(){return{_id:"Cause",failures:this.reasons.map((X)=>X.toJSON())}}toString(){return`Cause(${A(this.reasons)})`}[K1](){return this.toJSON()}[D0](X){return P5(X)&&this.reasons.length===X.reasons.length&&this.reasons.every((Y,Q)=>o(Y,X.reasons[Q]))}[U0](){return r9(this.reasons)}}var MD=new WeakMap;class a9{[s9];annotations;_tag;constructor(X,Y,Q){if(this[s9]=s9,this._tag=X,Y!==t9&&typeof Q==="object"&&Q!==null&&Y.size>0){let _=MD.get(Q);if(_)Y=new Map([..._,...Y]);MD.set(Q,Y)}this.annotations=Y}annotate(X,Y){if(X.mapUnsafe.size===0)return this;let Q=new Map(this.annotations);X.mapUnsafe.forEach((G,J)=>{if(Y?.overwrite!==!0&&Q.has(J))return;Q.set(J,G)});let _=Object.assign(Object.create(Object.getPrototypeOf(this)),this);return _.annotations=Q,_}pipe(){return G0(this,arguments)}toString(){return A(this)}[K1](){return this.toString()}}var t9=new Map;class w5 extends a9{error;constructor(X,Y=t9){super("Fail",Y,X);this.error=X}toString(){return`Fail(${A(this.error)})`}toJSON(){return{_tag:"Fail",error:this.error}}[D0](X){return O4(X)&&o(this.error,X.error)&&o(this.annotations,X.annotations)}[U0](){return Y1(S0(this._tag))(Y1(e(this.error))(e(this.annotations)))}}var g6=(X)=>new b6(X),j_=new b6([]),vD=(X)=>new b6([new w5(X)]);class S_ extends a9{defect;constructor(X,Y=t9){super("Die",Y,X);this.defect=X}toString(){return`Die(${A(this.defect)})`}toJSON(){return{_tag:"Die",defect:this.defect}}[D0](X){return XY(X)&&o(this.defect,X.defect)&&o(this.annotations,X.annotations)}[U0](){return Y1(S0(this._tag))(Y1(e(this.defect))(e(this.annotations)))}}var xD=(X)=>new b6([new S_(X)]),e9=V((X)=>P5(X[0]),(X,Y,Q)=>{if(Y.mapUnsafe.size===0)return X;return new b6(X.reasons.map((_)=>_.annotate(Y,Q)))}),O4=(X)=>X._tag==="Fail",XY=(X)=>X._tag==="Die",v_=(X)=>X._tag==="Interrupt";function Mv(X){return $6("Effect.evaluate: Not implemented")}var y6=(X)=>({...Cv,[ID]:X.op,[u0]:X[u0]??Mv,[S1]:X[S1],[LX]:X[LX],[q8]:X[q8]}),TX=(X)=>{let Y=y6(X);return function(){let Q=Object.create(Y);return Q[J0]=X.single===!1?arguments:arguments[0],Q}},kD=(X)=>{let Y={...y6(X),[q4]:q4,_tag:X.op,get[X.prop](){return this[J0]},toString(){return`${X.op}(${A(this[J0])})`},toJSON(){return{_id:"Exit",_tag:X.op,[X.prop]:this[J0]}},[D0](Q){return pJ(Q)&&Q._tag===this._tag&&o(this[J0],Q[J0])},[U0](){return Y1(S0(X.op),e(this[J0]))}};return function(Q){let _=Object.create(Y);return _[J0]=Q,_}},Q1=kD({op:"Success",prop:"value",[u0](X){let Y=X.getCont(S1);return Y?Y[S1](this[J0],X,this):X.yieldWith(this)}}),x_={key:"effect/Cause/StackTrace"},uJ={key:"effect/Cause/InterruptorStackTrace"},_X=kD({op:"Failure",prop:"cause",[u0](X){let Y=this[J0],Q=!1;if(X.currentStackFrame)Y=e9(Y,{mapUnsafe:new Map([[x_.key,X.currentStackFrame]])}),Q=!0;let _=X.getCont(LX);while(X.interruptible&&X._interruptedCause&&_)_=X.getCont(LX);return _?_[LX](Y,X,Q?void 0:this):X.yieldWith(Q?_X(Y):this)}}),J6=(X)=>_X(vD(X)),$6=(X)=>_X(xD(X)),s=TX({op:"WithFiber",[u0](X){return this[J0](X)}}),Iv=function(){class X extends globalThis.Error{}let Y=y6({op:"YieldableError",[u0](){return J6(this)}});return delete Y.toString,Object.assign(X.prototype,Y),X}(),YY=function(){let X=Symbol.for("effect/Data/Error/plainArgs");return class extends Iv{constructor(Q){super(Q?.message,Q?.cause?{cause:Q.cause}:void 0);if(Q)M_(this,Q),Object.defineProperty(this,X,{value:Q,enumerable:!1})}toJSON(){return{...this[X],...this}}}}(),z8=(X)=>{class Y extends YY{_tag=X}return Y.prototype.name=X,Y},I_="~effect/Cause/NoSuchElementError",cJ=(X)=>I(X,I_);class h6 extends z8("NoSuchElementError"){[I_]=I_;constructor(X){super({message:X})}}var A5="~effect/Cause/Done",QY=(X)=>I(X,A5),bD={[A5]:A5,_tag:"Done",value:void 0},gD=(X)=>{if(X===void 0)return bD;return{[A5]:A5,_tag:"Done",value:X}},jv=J6(bD),yD=(X)=>{if(X===void 0)return jv;return J6(gD(X))};var hD=(X)=>y6({op:X.label,[u0]:X.evaluate});var vv=()=>{let X=Object.getOwnPropertyDescriptor(Error,"stackTraceLimit");if(X===void 0)return Object.isExtensible(Error);return Object.hasOwn(X,"writable")?X.writable===!0:X.set!==void 0},xv=vv(),Z6=()=>Error.stackTraceLimit,F1=(X)=>{if(xv)Error.stackTraceLimit=X};function mD(X){return{combine:X}}function m6(X,Y,Q){return{combine:X,initialValue:Y,combineAll:Q??((_)=>{let G=Y;for(let J of _)G=X(G,J);return G})}}var H1=(X)=>(Y,Q)=>Y===Q||X(Y,Q),bv=(X,Y)=>X===Y,dD=()=>bv;function fD(X){return H1((Y,Q)=>{if(Y.length!==Q.length)return!1;for(let _=0;_<Y.length;_++)if(!X(Y[_],Q[_]))return!1;return!0})}var b_=(X)=>V(3,(Y,Q,_)=>X(Y,(G)=>({...G,[Q]:_(G)}))),g_=(X)=>V(2,(Y,Q)=>X(Y,(_)=>({[Q]:_}))),y_=(X,Y)=>V(3,(Q,_,G)=>Y(Q,(J)=>X(G(J),(Z)=>({...J,[_]:Z}))));var uD="~effect/data/Option",cD={[uD]:{_A:(X)=>X},...k6,[Symbol.iterator](){return new V8(this)}},gv=Object.defineProperty(Object.assign(Object.create(cD),{_tag:"Some",_op:"Some",[D0](X){return h_(X)&&lJ(X)&&o(this.value,X.value)},[U0](){return Y1(e(this._tag))(e(this.value))},toString(){return`some(${A(this.value)})`},toJSON(){return{_id:"Option",_tag:this._tag,value:R1(this.value)}}}),"valueOrUndefined",{get(){return this.value}}),yv=e("None"),hv=Object.assign(Object.create(cD),{_tag:"None",_op:"None",valueOrUndefined:void 0,[D0](X){return h_(X)&&T8(X)},[U0](){return yv},toString(){return"none()"},toJSON(){return{_id:"Option",_tag:this._tag}}}),h_=(X)=>I(X,uD),T8=(X)=>X._tag==="None",lJ=(X)=>X._tag==="Some",L4=Object.create(hv),d6=(X)=>{let Y=Object.create(gv);return Y.value=X,Y};var lD="~effect/data/Result",oD={[lD]:{_A:(X)=>X,_E:(X)=>X},...k6,[Symbol.iterator](){return new V8(this)}},mv=Object.assign(Object.create(oD),{_tag:"Success",_op:"Success",[D0](X){return m_(X)&&f_(X)&&o(this.success,X.success)},[U0](){return Y1(e(this._tag))(e(this.success))},toString(){return`success(${A(this.success)})`},toJSON(){return{_id:"Result",_tag:this._tag,value:R1(this.success)}}}),dv=Object.assign(Object.create(oD),{_tag:"Failure",_op:"Failure",[D0](X){return m_(X)&&d_(X)&&o(this.failure,X.failure)},[U0](){return Y1(e(this._tag))(e(this.failure))},toString(){return`failure(${A(this.failure)})`},toJSON(){return{_id:"Result",_tag:this._tag,failure:R1(this.failure)}}}),m_=(X)=>I(X,lD),d_=(X)=>X._tag==="Failure",f_=(X)=>X._tag==="Success",rJ=(X)=>{let Y=Object.create(dv);return Y.failure=X,Y},iJ=(X)=>{let Y=Object.create(mv);return Y.success=X,Y},rD=(X)=>f_(X)?L4:d6(X.failure),iD=(X)=>d_(X)?L4:d6(X.success),nD=V(2,(X,Y)=>T8(X)?rJ(Y()):iJ(X.value));function T4(X){return(Y,Q)=>Y===Q?0:X(Y,Q)}var q1=T4((X,Y)=>{if(globalThis.Number.isNaN(X)&&globalThis.Number.isNaN(Y))return 0;if(globalThis.Number.isNaN(X))return-1;if(globalThis.Number.isNaN(Y))return 1;return X<Y?-1:1});var RX=T4((X,Y)=>X<Y?-1:1);var nJ=V(2,(X,Y)=>T4((Q,_)=>X(Y(Q),Y(_)))),R4=nJ(q1,(X)=>X.getTime());var C5=(X)=>V(2,(Y,Q)=>X(Y,Q)===-1),R8=(X)=>V(2,(Y,Q)=>X(Y,Q)===1),_Y=(X)=>V(2,(Y,Q)=>X(Y,Q)!==1),GY=(X)=>V(2,(Y,Q)=>X(Y,Q)!==-1);var f=()=>L4,T=d6,p_=h_,E0=T8,W1=lJ,kX=V(2,(X,{onNone:Y,onSome:Q})=>E0(X)?Y():Q(X.value));var u_=V(2,(X,Y)=>E0(X)?Y():X.value);var sD=(X)=>X==null?f():T(X),aD=(X)=>X===void 0?f():T(X),tD=(X)=>X===null?f():T(X);var sJ=u_(z_),F4=u_(OX),E4=(X)=>(...Y)=>{try{return T(X(...Y))}catch{return f()}};var f6=V(2,(X,Y)=>E0(X)?f():T(Y(X.value)));var pv=V(2,(X,Y)=>E0(X)?f():Y(X.value));var I5=pv(u);var j5=V(2,(X,Y)=>E0(X)?f():Y(X.value)?T(X.value):f()),eD=(X)=>H1((Y,Q)=>E0(Y)?E0(Q):E0(Q)?!1:X(Y.value,Q.value));var c_="~effect/Context/Service",bX=function(){let X=Z6();F1(2);let Y=Error();F1(X);function Q(){}let _=Q;if(Object.setPrototypeOf(_,uv),Object.defineProperty(_,"stack",{get(){return Y.stack}}),arguments.length>0){if(_.key=arguments[0],arguments[1]?.defaultValue)_[l_]=l_,_.defaultValue=arguments[1].defaultValue;return _}return function(G,J){if(_.key=G,J?.make)_.make=J.make;return _}},uv={[c_]:c_,...hD({label:"Service",evaluate(X){return Q1(v1(X.context,this))}}),toJSON(){return{_id:"Service",key:this.key,stack:this.stack}},of(X){return X},context(X){return K6(this,X)},use(X){return s((Y)=>X(v1(Y.context,this)))},useSync(X){return s((Y)=>Q1(X(v1(Y.context,this))))}},l_="~effect/Context/Reference",XN="~effect/Context",F8=(X)=>{let Y=Object.create(cv);return Y.mapUnsafe=X,Y.mutable=!1,Y},cv={...k6,[XN]:{_Services:(X)=>X},toJSON(){return{_id:"Context",services:Array.from(this.mapUnsafe).map(([X,Y])=>({key:X,value:Y}))}},[D0](X){if(!o_(X)||this.mapUnsafe.size!==X.mapUnsafe.size)return!1;for(let Y of this.mapUnsafe.keys())if(!X.mapUnsafe.has(Y)||!o(this.mapUnsafe.get(Y),X.mapUnsafe.get(Y)))return!1;return!0},[U0](){return v6(this.mapUnsafe.size)}},o_=(X)=>I(X,XN),lv=(X)=>I(X,c_),tJ=(X)=>I(X,l_),x1=()=>ov,ov=F8(new Map),K6=(X,Y)=>F8(new Map([[X.key,Y]])),l1=V(3,(X,Y,Q)=>JY(X,(_)=>{_.set(Y.key,Q)})),rv=V(3,(X,Y,Q)=>JY(X,(_)=>{if(Q._tag==="None")_.delete(Y.key);else _.set(Y.key,Q.value)})),iv=V(3,(X,Y,Q)=>{if(X.mapUnsafe.has(Y.key))return X.mapUnsafe.get(Y.key);return tJ(Y)?r_(Y):Q()}),eJ=V(2,(X,Y)=>X.mapUnsafe.get(Y.key)),FX=V(2,(X,Y)=>{if(!X.mapUnsafe.has(Y.key)){if(l_ in Y)return r_(Y);throw nv(Y)}return X.mapUnsafe.get(Y.key)}),v1=FX,X$=(X,Y)=>{if(!X.mapUnsafe.has(Y.key))return r_(Y);return X.mapUnsafe.get(Y.key)},aJ="~effect/Context/defaultValue",r_=(X)=>{if(aJ in X)return X[aJ];return X[aJ]=X.defaultValue()},nv=(X)=>{let Y=Error(`Service not found${X.key?`: ${String(X.key)}`:""}`);if(X.stack){let Q=X.stack.split(`
`);if(Q.length>2){let _=Q[2].match(/at (.*)/);if(_)Y.message=Y.message+` (defined at ${_[1]})`}}if(Y.stack){let Q=Y.stack.split(`
`);Q.splice(1,3),Y.stack=Q.join(`
`)}return Y},Y$=V(2,(X,Y)=>{if(X.mapUnsafe.has(Y.key))return T(X.mapUnsafe.get(Y.key));return tJ(Y)?T(r_(Y)):f()}),S5=V(2,(X,Y)=>{if(X.mapUnsafe.size===0)return Y;if(Y.mapUnsafe.size===0)return X;return JY(X,(Q)=>{Y.mapUnsafe.forEach((_,G)=>Q.set(G,_))})}),Q$=(...X)=>{let Y=new Map;for(let Q=0;Q<X.length;Q++)X[Q].mapUnsafe.forEach((_,G)=>{Y.set(G,_)});return F8(Y)},sv=(...X)=>(Y)=>JY(Y,(Q)=>{let _=new Set(X.map((G)=>G.key));Q.forEach((G,J)=>{if(_.has(J))return;Q.delete(J)})}),av=(...X)=>(Y)=>JY(Y,(Q)=>{for(let _=0;_<X.length;_++)Q.delete(X[_].key)}),tv=V(2,(X,Y)=>{let Q=F8(new Map(X.mapUnsafe));Q.mutable=!0;let _=Y(Q);return _.mutable=!1,_}),JY=(X,Y)=>{if(X.mutable)return Y(X.mapUnsafe),X;let Q=new Map(X.mapUnsafe);return Y(Q),F8(Q)},O0=bX;var A4={};M6(A4,{taggedEnum:()=>Xx,TaggedError:()=>$Y,TaggedClass:()=>ev,Error:()=>Qx,Class:()=>i_});var i_=class extends N4{constructor(X){super();if(X)M_(this,X)}},ev=(X)=>class extends i_{_tag=X},Xx=()=>new Proxy({},{get(X,Y,Q){if(Y==="$is")return j6;else if(Y==="$match")return Yx;return(_)=>({..._,_tag:Y})}});function Yx(){if(arguments.length===1){let Q=arguments[0];return function(_){return Q[_._tag](_)}}let X=arguments[0];return arguments[1][X._tag](X)}var Qx=YY,$Y=z8;var c0={};M6(c0,{zipWith:()=>_y,zip:()=>Qy,yieldNowWith:()=>cg,yieldNow:()=>ug,withTracerTiming:()=>oh,withTracerEnabled:()=>lh,withTracer:()=>ch,withSpanScoped:()=>Gm,withSpan:()=>_m,withParentSpan:()=>Jm,withLogger:()=>km,withLogSpan:()=>ym,withFiber:()=>Fz,withExecutionPlan:()=>My,withErrorReporting:()=>Iy,whileLoop:()=>Oz,when:()=>ny,void:()=>yY,validate:()=>Ig,useSpan:()=>Qm,updateServiceScoped:()=>Nh,updateService:()=>Dh,updateContext:()=>Uh,unwrapReason:()=>Hy,uninterruptibleMask:()=>Iz,uninterruptible:()=>kh,undefined:()=>kg,txRetry:()=>rm,tx:()=>um,tryPromise:()=>G2,try:()=>e5,transposeOption:()=>og,trackSuccesses:()=>mm,trackErrors:()=>dm,trackDuration:()=>pm,trackDefects:()=>fm,track:()=>hm,tracer:()=>uh,timeoutOrElse:()=>ky,timeoutOption:()=>xy,timeout:()=>vy,timed:()=>yy,tapErrorTag:()=>Ly,tapError:()=>Az,tapDefect:()=>wz,tapCauseIf:()=>Ty,tapCauseFilter:()=>Ry,tapCause:()=>Pz,tap:()=>Ez,sync:()=>Tz,suspend:()=>Lz,succeedSome:()=>gY,succeedNone:()=>mX,succeed:()=>p,spanLinks:()=>th,spanAnnotations:()=>ah,sleep:()=>gy,setContext:()=>Kh,serviceOption:()=>Wh,service:()=>Hh,scopedWith:()=>zh,scoped:()=>qh,scope:()=>Vh,scheduleFrom:()=>jz,schedule:()=>ph,satisfiesSuccessType:()=>nm,satisfiesServicesType:()=>am,satisfiesErrorType:()=>sm,sandbox:()=>Py,runSyncWith:()=>Fm,runSyncExitWith:()=>Em,runSyncExit:()=>b8,runSync:()=>Rm,runPromiseWith:()=>Lm,runPromiseExitWith:()=>Tm,runPromiseExit:()=>i7,runPromise:()=>Om,runForkWith:()=>Vm,runFork:()=>W2,runCallbackWith:()=>qm,runCallback:()=>zm,retryOrElse:()=>Ay,retry:()=>Ey,result:()=>sg,requestUnsafe:()=>Zm,request:()=>$m,replicateEffect:()=>fh,replicate:()=>dh,repeatOrElse:()=>mh,repeat:()=>hh,reduce:()=>Mg,raceFirst:()=>fy,raceAllFirst:()=>my,raceAll:()=>hy,race:()=>dy,provideServiceEffect:()=>Bh,provideService:()=>Cz,provideContext:()=>Zh,provide:()=>$h,promise:()=>xg,partition:()=>Cg,orElseSucceed:()=>jy,orDie:()=>Oy,option:()=>ag,onInterrupt:()=>xh,onExitPrimitive:()=>wh,onExitIf:()=>Ch,onExitFilter:()=>Mh,onExit:()=>H2,onErrorIf:()=>Ah,onErrorFilter:()=>Ph,onError:()=>Eh,never:()=>bg,matchEffect:()=>Yh,matchEager:()=>sy,matchCauseEffectEager:()=>ey,matchCauseEffect:()=>Xh,matchCauseEager:()=>ty,matchCause:()=>ay,match:()=>K2,mapErrorEager:()=>X9,mapError:()=>qy,mapEager:()=>u4,mapBothEager:()=>U1,mapBoth:()=>zy,map:()=>Z2,makeSpanScoped:()=>Ym,makeSpan:()=>Xm,logWithLevel:()=>wm,logWarning:()=>Im,logTrace:()=>xm,logInfo:()=>Sm,logFatal:()=>Mm,logError:()=>jm,logDebug:()=>vm,log:()=>Cm,linkSpans:()=>eh,let:()=>hg,isSuccess:()=>_h,isFailure:()=>Qh,isEffect:()=>d4,interruptibleMask:()=>bh,interruptible:()=>vh,interrupt:()=>Mz,ignoreCause:()=>Cy,ignore:()=>wy,gen:()=>dg,fromResult:()=>$2,fromOption:()=>lg,fromNullishOr:()=>rg,forkScoped:()=>Wm,forkIn:()=>Hm,forkDetach:()=>Um,forkChild:()=>Km,forever:()=>yh,forEach:()=>vg,fnUntracedEager:()=>dY,fnUntraced:()=>Am,fn:()=>Pm,flip:()=>Yy,flatten:()=>ig,flatMapEager:()=>EX,flatMap:()=>hY,firstSuccessOf:()=>Sy,findFirstFilter:()=>Sg,findFirst:()=>jg,filterOrFail:()=>ry,filterOrElse:()=>ly,filterMapOrFail:()=>iy,filterMapOrElse:()=>oy,filterMapEffect:()=>cy,filterMap:()=>uy,filter:()=>py,fiberId:()=>Bm,fiber:()=>Nm,failSync:()=>fg,failCauseSync:()=>f4,failCause:()=>pg,fail:()=>d,exit:()=>mY,eventually:()=>Fy,ensuring:()=>Fh,effectify:()=>im,die:()=>Rz,delay:()=>by,currentSpan:()=>nh,currentParentSpan:()=>sh,contextWith:()=>Jh,context:()=>Gh,clockWith:()=>Sz,catchTags:()=>$y,catchTag:()=>Jy,catchReasons:()=>Ky,catchReason:()=>Zy,catchNoSuchElement:()=>Ny,catchIf:()=>Uy,catchFilter:()=>Dy,catchEager:()=>n7,catchDefect:()=>Wy,catchCauseIf:()=>By,catchCauseFilter:()=>Vy,catchCause:()=>p4,catch:()=>Gy,callback:()=>J2,cachedWithTTL:()=>jh,cachedInvalidateWithTTL:()=>Sh,cached:()=>Ih,bindTo:()=>yg,bind:()=>mg,awaitAllChildren:()=>Dm,asVoid:()=>Xy,asSome:()=>eg,as:()=>tg,annotateSpans:()=>rh,annotateLogsScoped:()=>gm,annotateLogs:()=>bm,annotateCurrentSpan:()=>ih,andThen:()=>ng,all:()=>wg,addFinalizer:()=>Rh,acquireUseRelease:()=>Th,acquireRelease:()=>Oh,acquireDisposable:()=>Lh,abortSignal:()=>gh,TypeId:()=>Pg,Transaction:()=>bY,Do:()=>gg});var n_="~effect/time/Duration",_x=BigInt(0),Gx=BigInt(1);var Jx=BigInt(1000);var s_=(X)=>BigInt(X<0?Math.ceil(X-0.5):Math.floor(X+0.5)),GN=(X)=>s_(X*1e6),YN=(X,Y)=>X.includes(".")?s_(Number(X)*Number(Y)):BigInt(X)*Y;var $x=/^(-?\d+(?:\.\d+)?)\s+(nanos?|micros?|millis?|seconds?|minutes?|hours?|days?|weeks?)$/,GX=(X)=>{switch(typeof X){case"number":return E8(X);case"bigint":return H6(X);case"string":{if(X==="Infinity")return p6;if(X==="-Infinity")return P4;let Y=$x.exec(X);if(!Y)break;let[Q,_,G]=Y;if(G==="nano"||G==="nanos")return H6(YN(_,Gx));if(G==="micro"||G==="micros")return H6(YN(_,Jx));let J=Number(_);switch(G){case"milli":case"millis":return E8(J);case"second":case"seconds":return Wx(J);case"minute":case"minutes":return Ux(J);case"hour":case"hours":return Dx(J);case"day":case"days":return Nx(J);case"week":case"weeks":return Bx(J)}break}case"object":{if(X===null)break;if(n_ in X)return X;if(Array.isArray(X)){if(X.length!==2||!X.every(o9))return QN(X);if(Number.isNaN(X[0])||Number.isNaN(X[1]))return v5;if(X[0]===-1/0||X[1]===-1/0)return P4;if(X[0]===1/0||X[1]===1/0)return p6;return b1(s_(X[0]*1e9+X[1]))}let Y=X,Q=0;if(Y.weeks)Q+=Y.weeks*604800000;if(Y.days)Q+=Y.days*86400000;if(Y.hours)Q+=Y.hours*3600000;if(Y.minutes)Q+=Y.minutes*60000;if(Y.seconds)Q+=Y.seconds*1000;if(Y.milliseconds)Q+=Y.milliseconds;if(!Y.microseconds&&!Y.nanoseconds)return b1(Q);return b1(s_(Q*1e6+(Y.microseconds??0)*1000+(Y.nanoseconds??0)))}}return QN(X)},QN=(X)=>{throw Error(`Invalid Input: ${X}`)},JN=E4(GX),_N={_tag:"Millis",millis:0},Zx={_tag:"Infinity"},Kx={_tag:"NegativeInfinity"},Hx={[n_]:n_,[U0](){return gJ(this.value)},[D0](X){return G$(X)&&qx(this,X)},toString(){switch(this.value._tag){case"Infinity":return"Infinity";case"NegativeInfinity":return"-Infinity";case"Nanos":return`${this.value.nanos} nanos`;case"Millis":return`${this.value.millis} millis`}},toJSON(){switch(this.value._tag){case"Millis":return{_id:"Duration",_tag:"Millis",millis:this.value.millis};case"Nanos":return{_id:"Duration",_tag:"Nanos",nanos:String(this.value.nanos)};case"Infinity":return{_id:"Duration",_tag:"Infinity"};case"NegativeInfinity":return{_id:"Duration",_tag:"NegativeInfinity"}}},[K1](){return this.toJSON()},pipe(){return G0(this,arguments)}},b1=(X)=>{let Y=Object.create(Hx);if(typeof X==="number")if(isNaN(X)||X===0||Object.is(X,-0))Y.value=_N;else if(!Number.isFinite(X))Y.value=X>0?Zx:Kx;else if(!Number.isInteger(X))Y.value={_tag:"Nanos",nanos:GN(X)};else Y.value={_tag:"Millis",millis:X};else if(X===_x)Y.value=_N;else Y.value={_tag:"Nanos",nanos:X};return Y},G$=(X)=>I(X,n_);var v5=b1(0),p6=b1(1/0),P4=b1(-1/0),H6=(X)=>b1(X);var E8=(X)=>b1(X),Wx=(X)=>b1(X*1000),Ux=(X)=>b1(X*60000),Dx=(X)=>b1(X*3600000),Nx=(X)=>b1(X*86400000),Bx=(X)=>b1(X*604800000),A8=(X)=>Vx(GX(X),{onMillis:u,onNanos:(Y)=>Number(Y)/1e6,onInfinity:()=>1/0,onNegativeInfinity:()=>-1/0});var _$=(X)=>{let Y=GX(X);switch(Y.value._tag){case"Infinity":case"NegativeInfinity":throw Error("Cannot convert infinite duration to nanos");case"Nanos":return Y.value.nanos;case"Millis":return GN(Y.value.millis)}},$N=E4(_$);var Vx=V(2,(X,Y)=>{switch(X.value._tag){case"Millis":return Y.onMillis(X.value.millis);case"Nanos":return Y.onNanos(X.value.nanos);case"Infinity":return Y.onInfinity();case"NegativeInfinity":return(Y.onNegativeInfinity??Y.onInfinity)()}}),ZN=V(3,(X,Y,Q)=>{if(X.value._tag==="Infinity"||X.value._tag==="NegativeInfinity"||Y.value._tag==="Infinity"||Y.value._tag==="NegativeInfinity")return Q.onInfinity(X,Y);if(X.value._tag==="Millis")return Y.value._tag==="Millis"?Q.onMillis(X.value.millis,Y.value.millis):Q.onNanos(_$(X),Y.value.nanos);else return Q.onNanos(X.value.nanos,_$(Y))});var J$=(X,Y)=>ZN(X,Y,{onMillis:(Q,_)=>Q===_,onNanos:(Q,_)=>Q===_,onInfinity:(Q,_)=>Q.value._tag===_.value._tag});var KN=V(2,(X,Y)=>ZN(X,Y,{onMillis:(Q,_)=>b1(Q-_),onNanos:(Q,_)=>b1(Q-_),onInfinity:(Q,_)=>{let G=Q.value._tag,J=_.value._tag;if(G==="Infinity")return J==="Infinity"?v5:p6;if(G==="NegativeInfinity")return J==="NegativeInfinity"?v5:P4;return J==="Infinity"?P4:p6}}));var qx=V(2,(X,Y)=>J$(X,Y));var $$=(X)=>X.length>0;var g0={};M6(g0,{void:()=>Ox,try:()=>Z$,transposeOption:()=>mx,transposeMapOption:()=>dx,tap:()=>px,succeedSome:()=>fx,succeedNone:()=>H$,succeed:()=>m,orElse:()=>jx,merge:()=>wx,match:()=>o1,mapError:()=>w4,mapBoth:()=>HN,map:()=>JX,makeEquivalence:()=>K$,liftPredicate:()=>Ax,let:()=>hx,isSuccess:()=>t0,isResult:()=>a_,isFailure:()=>Q0,getSuccess:()=>Fx,getOrUndefined:()=>Mx,getOrThrowWith:()=>WN,getOrThrow:()=>Ix,getOrNull:()=>Cx,getOrElse:()=>P8,getFailure:()=>Ex,gen:()=>kx,fromOption:()=>Rx,fromNullishOr:()=>Tx,flip:()=>xx,flatMap:()=>w8,filterOrFail:()=>Px,failVoid:()=>Lx,fail:()=>c,bindTo:()=>yx,bind:()=>gx,andThen:()=>Sx,all:()=>vx,Do:()=>bx});var m=iJ,c=rJ,Ox=m(void 0);var Lx=c(void 0),Tx=V(2,(X,Y)=>X==null?c(Y(X)):m(X)),Rx=nD,Z$=(X)=>{if(u1(X))try{return m(X())}catch(Y){return c(Y)}else try{return m(X.try())}catch(Y){return c(X.catch(Y))}};var a_=m_,Q0=d_,t0=f_,Fx=iD,Ex=rD,K$=(X,Y)=>H1((Q,_)=>Q0(Q)?Q0(_)&&Y(Q.failure,_.failure):t0(_)&&X(Q.success,_.success)),HN=V(2,(X,{onFailure:Y,onSuccess:Q})=>Q0(X)?c(Y(X.failure)):m(Q(X.success))),w4=V(2,(X,Y)=>Q0(X)?c(Y(X.failure)):m(X.success)),JX=V(2,(X,Y)=>t0(X)?m(Y(X.success)):c(X.failure)),o1=V(2,(X,{onFailure:Y,onSuccess:Q})=>Q0(X)?Y(X.failure):Q(X.success)),Ax=V(3,(X,Y,Q)=>Y(X)?m(X):c(Q(X))),Px=V(3,(X,Y,Q)=>w8(X,(_)=>Y(_)?m(_):c(Q(_)))),wx=o1({onFailure:u,onSuccess:u}),P8=V(2,(X,Y)=>Q0(X)?Y(X.failure):X.success),Cx=P8(z_),Mx=P8(OX),WN=V(2,(X,Y)=>{if(t0(X))return X.success;throw Y(X.failure)}),Ix=WN(u),jx=V(2,(X,Y)=>Q0(X)?Y(X.failure):m(X.success)),w8=V(2,(X,Y)=>Q0(X)?c(X.failure):Y(X.success)),Sx=V(2,(X,Y)=>w8(X,(Q)=>{let _=u1(Y)?Y(Q):Y;return a_(_)?_:m(_)})),vx=(X)=>{if(Symbol.iterator in X){let Q=[];for(let _ of X){if(Q0(_))return _;Q.push(_.success)}return m(Q)}let Y={};for(let Q of Object.keys(X)){let _=X[Q];if(Q0(_))return _;k(Y,Q,_.success)}return m(Y)},xx=(X)=>Q0(X)?m(X.failure):c(X.success),kx=(...X)=>{let Q=(X.length===1?X[0]:X[1].bind(X[0]))(),_=Q.next();while(!_.done){let G=_.value;if(Q0(G))return G;_=Q.next(G.success)}return m(_.value)},bx=m({}),gx=y_(JX,w8),yx=g_(JX),hx=b_(JX);var mx=(X)=>{return T8(X)?H$:JX(X.value,d6)},dx=V(2,(X,Y)=>T8(X)?H$:JX(Y(X.value),d6)),H$=m(L4),fx=(X)=>m(d6(X)),px=V(2,(X,Y)=>{if(t0(X))Y(X.success);return X});var _Y0={[Symbol.iterator](){return ux}},ux={next(){return{done:!0,value:void 0}}};var UN=V(2,(X,Y)=>({[Symbol.iterator](){let Q=X[Symbol.iterator](),_=0;return{next(){let G=Q.next();while(!G.done){if(Y(G.value,_++))return{done:!1,value:G.value};G=Q.next()}return{done:!0,value:void 0}}}}}));var t_=V(2,(X,Y)=>{let Q={...X};for(let _ of lx(X))k(Q,_,Y(X[_],_));return Q});var lx=(X)=>Object.keys(X);var k5=globalThis.Array;var W$=(X)=>new k5(X);var A1=(X)=>k5.isArray(X)?X:k5.from(X),NN=(X)=>k5.isArray(X)?X:[X];var e_=V(2,(X,Y)=>[...X,Y]),ox=V(2,(X,Y)=>A1(X).concat(A1(Y)));var KY0=k5.isArray;var W6=$$,C8=$$;var ZY=V(2,(X,Y)=>{let Q=k5.from(X);return Q.sort(Y),Q});var rx=(X,Y)=>{let Q=e(Y),_=X.get(Q);if(_===void 0)return X.set(Q,[Y]),!0;for(let G of _)if(o(G,Y))return!1;return _.push(Y),!0};var U$=V(2,(X,Y)=>{let Q=A1(X),_=A1(Y);if(C8(Q))return C8(_)?Y7(ox(Q,_)):Q;return _});var X7=()=>[];var U6=V(2,(X,Y)=>X.map(Y));var D$=(X)=>{let Y=[];for(let Q of X)if(W1(Q))Y.push(Q.value);return Y};var N$=V(2,(X,Y)=>{let Q=[],_=[],G=0;for(let J of X){let Z=Y(J,G++);if(t0(Z))_.push(Z.success);else Q.push(Z.failure)}return[Q,_]});var Y7=(X)=>{let Y=A1(X);if(Y.length<2)return[...Y];let Q=new Map,_=[];for(let G of Y)if(rx(Q,G))_.push(G);return _};var ix=m6((X,Y)=>X.concat(Y),[]);function BN(){return ix}var B$=V(2,(X,Y)=>(Q)=>{let _=X(Q);if(Q0(_))return c(Q);let G=Y(_.success);if(Q0(G))return c(Q);return G});var KY=O0("effect/Scheduler",{defaultValue:()=>new b5}),VN="setImmediate"in globalThis?(X)=>{let Y=globalThis.setImmediate(X);return()=>globalThis.clearImmediate(Y)}:(X)=>{let Y=setTimeout(X,0);return()=>clearTimeout(Y)};class qN{buckets=[];scheduleTask(X,Y){let Q=this.buckets,_=Q.length,G,J=0;for(;J<_;J++){if(Q[J][0]>Y)break;G=Q[J]}if(G&&G[0]===Y)G[1].push(X);else if(J===_)Q.push([Y,[X]]);else Q.splice(J,0,[Y,[X]])}drain(){let X=this.buckets;return this.buckets=[],X}}class b5{executionMode;setImmediate;constructor(X="async",Y=VN){this.executionMode=X,this.setImmediate=Y}shouldYield(X){return X.currentOpCount>=X.maxOpsBeforeYield}makeDispatcher(){return new zN(this.setImmediate)}}class zN{tasks=new qN;running=void 0;setImmediate;constructor(X=VN){this.setImmediate=X}scheduleTask(X,Y){if(this.tasks.scheduleTask(X,Y),this.running===void 0)this.running=this.setImmediate(this.afterScheduled)}afterScheduled=()=>{this.running=void 0,this.runTasks()};runTasks(){let X=this.tasks.drain();for(let Y=0;Y<X.length;Y++){let Q=X[Y][1];for(let _=0;_<Q.length;_++)Q[_]()}}flush(){while(this.tasks.buckets.length>0){if(this.running!==void 0)this.running(),this.running=void 0;this.runTasks()}}}var ON=O0("effect/Scheduler/MaxOpsBeforeYield",{defaultValue:()=>2048}),LN=O0("effect/Scheduler/PreventSchedulerYield",{defaultValue:()=>!1});var V$="effect/Tracer/ParentSpan";class C4 extends bX()(V$){}var sx=(X)=>X;var Q7=O0("effect/Tracer/DisablePropagation",{defaultValue:q_}),FN=O0("effect/Tracer/CurrentTraceLevel",{defaultValue:()=>"Info"}),EN=O0("effect/Tracer/MinimumTraceLevel",{defaultValue:()=>"All"}),q$="effect/Tracer",_7=O0(q$,{defaultValue:()=>sx({span:(X)=>new AN(X)})});class AN{_tag="Span";spanId;traceId="native";sampled;name;parent;annotations;links;startTime;kind;status;attributes;events=[];constructor(X){this.name=X.name,this.parent=X.parent,this.annotations=X.annotations,this.links=X.links,this.startTime=X.startTime,this.kind=X.kind,this.sampled=X.sampled,this.status={_tag:"Started",startTime:X.startTime},this.attributes=new Map,this.traceId=F4(X.parent)?.traceId??RN(32),this.spanId=RN(16)}end(X,Y){this.status={_tag:"Ended",endTime:X,exit:Y,startTime:this.status.startTime}}attribute(X,Y){this.attributes.set(X,Y)}event(X,Y,Q){this.events.push([X,Y,Q??{}])}addLinks(X){this.links.push(...X)}}var RN=function(){return function(Q){let _="";for(let G=0;G<Q;G++)_+="abcdef0123456789".charAt(Math.floor(Math.random()*16));return _}}();var wN="effect/observability/Metric/FiberRuntimeMetricsKey";var CN=O0("effect/ErrorReporter/CurrentErrorReporters",{defaultValue:()=>new Set}),g5=O0("effect/References/CurrentStackFrame",{defaultValue:OX}),G7=O0("effect/References/TracerEnabled",{defaultValue:I6}),HY=O0("effect/References/TracerTimingEnabled",{defaultValue:I6}),WY=O0("effect/References/TracerSpanAnnotations",{defaultValue:()=>({})}),UY=O0("effect/References/TracerSpanLinks",{defaultValue:()=>[]}),u6=O0("effect/References/CurrentLogAnnotations",{defaultValue:()=>({})}),z$=O0("effect/References/CurrentLogLevel",{defaultValue:()=>"Info"}),O$=O0("effect/References/MinimumLogLevel",{defaultValue:()=>"Info"});var J7=O0("effect/References/CurrentLogSpans",{defaultValue:()=>[]});var M8=(X)=>{if(X?.captureStackTrace===!1)return X;else if(X?.captureStackTrace!==void 0&&typeof X.captureStackTrace!=="boolean")return X;let Y=Z6();F1(3);let Q=Error();return F1(Y),{...X,captureStackTrace:ex(()=>Q.stack)}},L$=(X)=>(Y)=>{let Q;return()=>{if(Q!==void 0)return Q;let _=Y();if(!_)return;let G=_.split(`
`);if(G[X]!==void 0)return Q=G[X].trim(),Q}},ex=L$(3);var MN="dev";class v$ extends a9{fiberId;constructor(X,Y=t9){super("Interrupt",Y,"Interrupted");this.fiberId=X}toString(){return`Interrupt(${this.fiberId})`}toJSON(){return{_tag:"Interrupt",fiberId:this.fiberId}}[D0](X){return v_(X)&&this.fiberId===X.fiberId&&this.annotations===X.annotations}[U0](){return Y1(S0(`${this._tag}:${this.fiberId}`))(R_(this.annotations))}}var bN=(X)=>new v$(X),Z7=(X)=>new b6([new v$(X)]);var gN=(X)=>{let Y=X.reasons.find(O4);return Y?m(Y):c(X)},B6=(X)=>{for(let Y=0;Y<X.reasons.length;Y++){let Q=X.reasons[Y];if(Q._tag==="Fail")return m(Q.error)}return c(X)};var yN=(X)=>X.reasons.some(XY);var x$=(X)=>{let Y=X.reasons.find(XY);return Y?m(Y.defect):c(X)},hN=(X)=>X.reasons.some(v_);var mN=(X)=>{let Y;for(let Q=0;Q<X.reasons.length;Q++){let _=X.reasons[Q];if(_._tag!=="Interrupt")continue;if(Y??=new Set,_.fiberId!==void 0)Y.add(_.fiberId)}return Y?m(Y):c(X)};var dN=V(2,(X,Y)=>{if(X.reasons.length===0)return Y;else if(Y.reasons.length===0)return X;let Q=new b6(U$(X.reasons,Y.reasons));return o(X,Q)?X:Q}),fN=V(2,(X,Y)=>{let Q=!1,_=X.reasons.map((G)=>{if(O4(G))return Q=!0,new w5(Y(G.error));return G});return Q?g6(_):X}),Yk=(X)=>{let Y={Fail:[],Die:[],Interrupt:[]};for(let Q=0;Q<X.reasons.length;Q++)Y[X.reasons[Q]._tag].push(X.reasons[Q]);return Y},k$=(X)=>{let Y=Yk(X);if(Y.Fail.length>0)return Y.Fail[0].error;else if(Y.Die.length>0)return Y.Die[0].defect;else if(Y.Interrupt.length>0)return new globalThis.Error("All fibers interrupted without error");return new globalThis.Error("Empty cause")},pN=(X,Y)=>{let Q=[],_=[];if(X.reasons.length===0)return Q;let G=Z6();F1(1);for(let J of X.reasons){if(J._tag==="Interrupt"){_.push(J);continue}Q.push(R$(J._tag==="Die"?J.defect:J.error,J.annotations,Y))}if(Q.length===0){let J=Error("The fiber was interrupted by:");J.name="InterruptCause",J.stack=Jk(J,_);let Z=new globalThis.Error("All fibers interrupted without error",{cause:J});Z.name="InterruptError",Z.stack=`${Z.name}: ${Z.message}`,Q.push(R$(Z,_[0].annotations,Y))}return F1(G),Q},R$=(X,Y,Q)=>{let _=typeof X,G;if(X&&_==="object"){if(G=new globalThis.Error(Qk(X),{cause:X.cause?R$(X.cause):void 0}),typeof X.name==="string")G.name=X.name;if(typeof X.stack==="string")G.stack=Gk(X.stack,G,Y);else{let J=`${G.name}: ${G.message}`;G.stack=Y?uN(J,Y):J}if(Q?.includeCauseInStack)G.stack=lN(G);for(let J of Object.keys(X))if(!(J in G))G[J]=X[J]}else G=new globalThis.Error(!X?`Unknown error: ${X}`:_==="string"?X:V4(X));return G},Qk=(X)=>{if(typeof X.message==="string")return X.message;else if(typeof X.toString==="function"&&X.toString!==Object.prototype.toString&&X.toString!==Array.prototype.toString)try{return X.toString()}catch{}return V4(X)},_k=/\((.*)\)/g,Gk=(X,Y,Q)=>{let _=`${Y.name}: ${Y.message}`,G=(X.startsWith(_)?X.slice(_.length):X).split(`
`),J=[_];for(let Z=1;Z<G.length;Z++){if(/(?:Generator\.next|~effect\/Effect)/.test(G[Z]))break;J.push(G[Z])}return Q?uN(J.join(`
`),Q):J.join(`
`)},uN=(X,Y)=>{let Q=Y?.get(x_.key);if(Q)X=`${X}
${cN(Q)}`;return X},Jk=(X,Y)=>{let Q=[`${X.name}: ${X.message}`];for(let _ of Y){let G=_.fiberId!==void 0?`#${_.fiberId}`:"unknown",J=_.annotations.get(uJ.key);if(Q.push(`    at fiber (${G})`),J)Q.push(cN(J))}return Q.join(`
`)},cN=(X)=>{let Y=[],Q=X,_=0;while(Q&&_<10){let G=Q.stack();if(G){let J=G.matchAll(_k),Z=!1;for(let[,K]of J)Z=!0,Y.push(`    at ${Q.name} (${K})`);if(!Z)Y.push(`    at ${Q.name} (${G.replace(/^at /,"")})`)}else Y.push(`    at ${Q.name}`);Q=Q.parent,_++}return Y.join(`
`)},K7=(X)=>pN(X).map(lN).join(`
`),lN=(X)=>X.cause?`${X.stack} {
${oN(X.cause,"  ")}
}`:X.stack,oN=(X,Y)=>{let Q=X.stack.split(`
`),_=`${Y}[cause]: ${Q[0]}`;for(let G=1,J=Q.length;G<J;G++)_+=`
${Y}${Q[G]}`;if(X.cause)_+=` {
${oN(X.cause,`${Y}  `)}
${Y}}`;return _},F$=`~effect/Fiber/${MN}`,$k={_A:u,_E:u},Zk={id:0},H7=()=>globalThis[E5];class b${constructor(X,Y=!0){this[F$]=$k,this.setContext(X),this.id=++Zk.id,this.currentOpCount=0,this.interruptible=Y,this._stack=[],this._observers=[],this._exit=void 0,this._children=void 0,this._interruptedCause=void 0,this._yielded=void 0,this._running=!1,this._deferredInterrupt=!1,this.runtimeMetrics?.recordFiberStart(this.context)}[F$];id;interruptible;currentOpCount;_stack;_observers;_exit;_children;_interruptedCause;_yielded;_running;_deferredInterrupt;context;currentScheduler;currentTracerContext;currentSpan;currentLogLevel;minimumLogLevel;currentStackFrame;runtimeMetrics;maxOpsBeforeYield;currentPreventYield;_dispatcher=void 0;get currentDispatcher(){return this._dispatcher??=this.currentScheduler.makeDispatcher()}getRef(X){return X$(this.context,X)}addObserver(X){if(this._exit)return X(this._exit),O_;return this._observers.push(X),()=>{let Y=this._observers.indexOf(X);if(Y>=0)this._observers.splice(Y,1)}}interruptUnsafe(X,Y){if(this._exit)return;let Q=Z7(X);if(this.currentStackFrame)Q=e9(Q,K6(x_,this.currentStackFrame));if(Y)Q=e9(Q,Y);if(this._interruptedCause=this._interruptedCause?dN(this._interruptedCause,Q):Q,this.interruptible)if(this._running)this._deferredInterrupt=!0;else this.evaluate(F0(this._interruptedCause))}pollUnsafe(){return this._exit}evaluate(X){if(this._exit)return;else if(this._yielded!==void 0){let _=this._yielded;this._yielded=void 0,_()}let Y=this.runLoop(X);if(Y===z4)return;let Q=E$.interruptChildren&&E$.interruptChildren(this);if(Q!==void 0)return this.evaluate(v(Q,()=>Y));this._exit=Y,this.runtimeMetrics?.recordFiberEnd(this.context,this._exit);for(let _=0;_<this._observers.length;_++)this._observers[_](Y);this._observers.length=0,this._stack.length=0,this._children=void 0,this.context=x1()}runLoop(X){let Y=globalThis[E5];globalThis[E5]=this;let Q=this._running;this._running=!0;let _=!1,G=X;this.currentOpCount=0;try{while(!0){if(this._deferredInterrupt)this._deferredInterrupt=!1,G=F0(this._interruptedCause);if(this.currentOpCount++,!_&&!this.currentPreventYield&&this.currentScheduler.shouldYield(this)){_=!0;let J=G;G=v(d5,()=>J)}if(G=this.currentTracerContext?this.currentTracerContext(G,this):G[u0](this),G===z4){let J=this._yielded;if(q4 in J)return this._deferredInterrupt=!1,this._yielded=void 0,J;else if(this._deferredInterrupt){this._yielded=void 0,J();continue}return z4}}}catch(J){if(!I(G,u0))return $6(`Fiber.runLoop: Not a valid effect: ${String(G)}`);return this.runLoop($6(J))}finally{this._running=Q,globalThis[E5]=Y}}getCont(X){if(this._deferredInterrupt)return this._deferredInterrupt=!1,Kk;while(!0){let Y=this._stack.pop();if(!Y)return;let Q=Y[q8]&&Y[q8](this);if(Q)return Q[X]=Q,Q;if(Y[X])return Y}}yieldWith(X){return this._yielded=X,z4}children(){return this._children??=new Set}pipe(){return G0(this,arguments)}setContext(X){this.context=X;let Y=this.getRef(KY);if(Y!==this.currentScheduler)this.currentScheduler=Y,this._dispatcher=void 0;this.currentSpan=X.mapUnsafe.get(V$),this.currentLogLevel=this.getRef(z$),this.minimumLogLevel=this.getRef(O$),this.currentStackFrame=X.mapUnsafe.get(g5.key),this.maxOpsBeforeYield=this.getRef(ON),this.currentPreventYield=this.getRef(LN),this.runtimeMetrics=X.mapUnsafe.get(wN);let Q=X.mapUnsafe.get(q$);this.currentTracerContext=Q?Q.context:void 0}get currentSpanLocal(){return this.currentSpan?._tag==="Span"?this.currentSpan:void 0}}var Kk={[S1](X,Y){return F0(Y._interruptedCause)},[LX](X,Y){return F0(Y._interruptedCause)}},E$={interruptChildren:void 0},W7=(X)=>{if(!X.currentStackFrame)return;let Y=new Map;return Y.set(uJ.key,X.currentStackFrame),F8(Y)},Hk=(X)=>{if(X._children===void 0||X._children.size===0)return;return I4(X._children)},Wk=(X)=>{let Y=X;if(Y._exit)return M(Y._exit);return r1((Q)=>{if(Y._exit)return Q(M(Y._exit));return X0(X.addObserver((_)=>Q(M(_))))})},g$=(X)=>r1((Y)=>{let Q=X[Symbol.iterator](),_=[],G=void 0;function J(){let Z=Q.next();while(!Z.done){if(Z.value._exit){_.push(Z.value._exit),Z=Q.next();continue}G=Z.value.addObserver((K)=>{_.push(K),J()});return}Y(M(_))}return J(),X0(()=>G?.())});var Uk=(X)=>s((Y)=>Dk(X,Y.id)),Dk=V((X)=>I(X[0],F$),(X,Y,Q)=>s((_)=>{let G=W7(_);return G=G&&Q?S5(G,Q):G??Q,X.interruptUnsafe(Y,G),VY(Wk(X))})),I4=(X)=>s((Y)=>{let Q=W7(Y),_=X7();for(let G of X)G.interruptUnsafe(Y.id,Q),_.push(G);return VY(g$(_))});var M=Q1,F0=_X,P0=J6,X0=TX({op:"Sync",[u0](X){let Y=this[J0](),Q=X.getCont(S1);return Q?Q[S1](Y,X):X.yieldWith(Q1(Y))}}),a=TX({op:"Suspend",[u0](X){return this[J0]()}}),rN=V((X)=>X.length>=2||p_(X[0]),(X,Y)=>E0(X)?P0(Y?Y():new h6("Effect.fromOption: Option.none")):M(X.value)),m5=o1({onFailure:P0,onSuccess:M}),iN=(X)=>X==null?P0(new h6):M(X),y$=TX({op:"Yield",[u0](X){let Y=!1;return X.currentDispatcher.scheduleTask(()=>{if(Y)return;X.evaluate(ZX)},this[J0]??0),X.yieldWith(()=>{Y=!0})}}),d5=y$(0),h$=(X)=>M(T(X)),NY=M(f()),nN=(X)=>E0(X)?NY:B0(X.value,T),sN=(X)=>a(()=>F0(H0(X))),c6=(X)=>$6(X),U7=(X)=>a(()=>P0(H0(X))),_0=M(void 0);var aN=(X)=>{let Y=typeof X==="function"?X:X.try,Q=typeof X==="function"?(_)=>new M7(_,"An error occurred in Effect.try"):X.catch;return a(()=>{try{return M(H0(Y))}catch(_){return P0(H0(()=>Q(_)))}})};var m$=(X)=>d$(function(Y,Q){H0(()=>X(Q)).then((_)=>Y(M(_)),(_)=>Y(c6(_)))},X.length!==0),tN=(X)=>{let Y=typeof X==="function"?X:X.try,Q=typeof X==="function"?(_)=>new M7(_,"An error occurred in Effect.tryPromise"):X.catch;return d$(function(_,G){let J=(Z)=>{try{_(P0(H0(()=>Q(Z))))}catch(K){_(c6(K))}};try{H0(()=>Y(G)).then((Z)=>_(M(Z)),J)}catch(Z){J(Z)}},Y.length!==0)},eN=(X)=>s((Y)=>X(Y.id)),XB=s(M),YB=eN(M),d$=TX({op:"Async",single:!1,[u0](X){let Y=H0(()=>this[J0][0].bind(X.currentScheduler)),Q=!1,_=!1,G=this[J0][1]?new AbortController:void 0,J=Y((Z)=>{if(Q)return;if(Q=!0,_)X.evaluate(Z);else _=Z},G?.signal);if(_!==!1)return _;if(_=!0,X._yielded=()=>{Q=!0},G===void 0&&J===void 0)return z4;return X._stack.push(Nk(()=>{return Q=!0,G?.abort(),J??ZX})),z4}}),Nk=TX({op:"AsyncFinalizer",[q8](X){if(X.interruptible)X.interruptible=!1,X._stack.push(P7)},[LX](X,Y){return hN(X)?v(this[J0](),()=>F0(X)):F0(X)}}),r1=(X)=>d$(X,X.length>=2),BY=r1(O_),QB=(...X)=>a(()=>y5(X.length===1?X[0]():X[1].call(X[0].self))),f$=(X,...Y)=>{let Q=Y.length===0?function(){return a(()=>y5(X.apply(this,arguments)))}:function(){let _=a(()=>y5(X.apply(this,arguments)));for(let G=0;G<Y.length;G++)_=Y[G](_,...arguments);return _};return p$(X.length,Q)},p$=(X,Y)=>Object.defineProperty(Y,"length",{value:X,configurable:!0}),IN=L$(2),_B=function(){let X=typeof arguments[0]==="string",Y=X?arguments[0]:"Effect.fn",Q=X?arguments[1]:void 0,_=Z6();F1(2);let G=new globalThis.Error;if(F1(_),X)return(J,...Z)=>jN(Y,J,G,Z,X,Q);return jN(Y,arguments[0],G,Array.prototype.slice.call(arguments,1),X,Q)},jN=(X,Y,Q,_,G,J)=>{let Z=typeof Y==="function"?Y:_.pop().bind(Y.self);return p$(Z.length,function(...K){let H=a(()=>{let U=Z.apply(this,arguments);return r(U)?U:y5(U)});for(let U=0;U<_.length;U++)H=_[U](H,...K);if(!r(H))return H;let W=Z6();F1(2);let D=new globalThis.Error;return F1(W),l6(G?DY(X,J,(U)=>C$(H,U)):H,g5,(U)=>({name:X,stack:IN(()=>D.stack),parent:{name:`${X} (definition)`,stack:IN(()=>Q.stack),parent:U}}))})},GB=(X,...Y)=>p$(X.length,Y.length===0?function(){return SN(()=>X.apply(this,arguments))}:function(){let Q=SN(()=>X.apply(this,arguments));for(let _ of Y)Q=_(Q);return Q}),SN=(X)=>{try{let Y=X(),Q=void 0;while(!0){let _=Y.next(Q);if(_.done)return M(_.value);let G=_.value;if(G&&G._tag==="Success"){Q=G.value;continue}else if(G&&G._tag==="Failure")return _.value;else{let J=!0;return a(()=>{if(J)return J=!1,v(_.value,(Z)=>y5(Y,Z));else return a(()=>y5(X()))})}}}catch(Y){return c6(Y)}},y5=TX({op:"Iterator",single:!1,[S1](X,Y){let Q=this[J0][0];while(!0){let _=Q.next(X);if(_.done)return M(_.value);if(!P1(_.value))return Y._stack.push(this),_.value;else if(_.value._tag==="Failure")return _.value;X=_.value.value}},[u0](X){return this[S1](this[J0][1],X)}}),g1=V(2,(X,Y)=>{let Q=M(Y);return v(X,(_)=>Q)}),D7=(X)=>B0(X,T),JB=(X)=>j4(X,{onFailure:M,onSuccess:P0}),yX=V(2,(X,Y)=>v(X,(Q)=>r(Y)?Y:H0(()=>Y(Q)))),V6=V(2,(X,Y)=>v(X,(Q)=>g1(r(Y)?Y:H0(()=>Y(Q)),Q))),VY=(X)=>v(X,(Y)=>ZX),$B=(X)=>i1(X,P0),u$=(X,Y)=>s((Q)=>r1((_)=>{let G=A1(X),J=G.length,Z=0,K=!1,H=new Set,W=[],D=(U,N,B)=>{if(Z++,U._tag==="Failure"){if(W.push(...U.cause.reasons),Z>=J)_(F0(g6(W)));return}let q=!K;if(K=!0,_(H.size===0?U:v(i6(I4(H)),()=>U)),q&&Y?.onWinner)Y.onWinner({fiber:N,index:B,parentFiber:Q})};for(let U=0;U<J;U++){let N=S4(Q,G[U],!0,!0,!1);if(H.add(N),N.addObserver((B)=>{H.delete(N),D(B,N,U)}),K)break}return I4(H)})),c$=(X,Y)=>s((Q)=>r1((_)=>{let G=!1,J=new Set,Z=(H)=>{G=!0,_(J.size===0?H:v(i6(I4(J)),()=>H))},K=0;for(let H of X){if(G)break;let W=K++,D=S4(Q,H,!0,!0,!1);J.add(D),D.addObserver((U)=>{J.delete(D);let N=!G;if(Z(U),N&&Y?.onWinner)Y.onWinner({fiber:D,index:W,parentFiber:Q})})}return I4(J)})),ZB=V((X)=>r(X[1]),(X,Y,Q)=>u$([X,Y],Q)),N7=V((X)=>r(X[1]),(X,Y,Q)=>c$([X,Y],Q)),v=V(2,(X,Y)=>{let Q=Object.create(Bk);return Q[J0]=X,Q[S1]=Y.length!==1?(_)=>Y(_):Y,Q}),Bk=y6({op:"OnSuccess",[u0](X){return X._stack.push(this),this[J0]}}),KB=V(2,(X,Y)=>{if(P1(X))return X._tag==="Success"?Y.onSuccess(X.value):Y.onFailure(X.cause);return N6(X,Y)}),P1=(X)=>(q4 in X),HB=V(2,(X,Y)=>{if(P1(X))return X._tag==="Success"?Y(X.value):X;return v(X,Y)}),WB=(X)=>v(X,u),B0=V(2,(X,Y)=>v(X,(Q)=>M(H0(()=>Y(Q))))),UB=V(2,(X,Y)=>P1(X)?zB(X,Y):B0(X,Y)),DB=V(2,(X,Y)=>P1(X)?OB(X,Y):a$(X,Y)),NB=V(2,(X,Y)=>P1(X)?LB(X,Y):t$(X,Y)),BB=V(2,(X,Y)=>{if(P1(X)){if(X._tag==="Success")return X;let Q=B6(X.cause);if(Q0(Q))return X;return Y(Q.success)}return h1(X,Y)});var l$=(X)=>X._tag==="Success";var VB=(X)=>X._tag==="Failure";var qB=(X)=>X._tag==="Failure"?m(X.cause):c(X);var ZX=Q1(void 0),zB=V(2,(X,Y)=>X._tag==="Success"?Q1(Y(X.value)):X),OB=V(2,(X,Y)=>{if(X._tag==="Success")return X;let Q=B6(X.cause);if(Q0(Q))return X;return J6(Y(Q.success))}),LB=V(2,(X,Y)=>{if(X._tag==="Success")return Q1(Y.onSuccess(X.value));let Q=B6(X.cause);if(Q0(Q))return X;return J6(Y.onFailure(Q.success))});var TB=(X)=>{let Y=[];for(let Q of X)if(Q._tag==="Failure")Y.push(...Q.cause.reasons);return Y.length===0?ZX:_X(g6(Y))};var RB=(X)=>X,FB=(X)=>s((Y)=>M(Y$(Y.context,X))),Vk=(X)=>s((Y)=>Y.context.mapUnsafe.has(X.key)?M(FX(Y.context,X)):P0(new h6)),f5=V(2,(X,Y)=>s((Q)=>{let _=Q.context,G=Y(_);if(_===G)return X;return Q.setContext(G),c5(X,()=>{Q.setContext(_);return})})),l6=V(3,(X,Y,Q)=>f5(X,(_)=>{let G=FX(_,Y),J=Q(G);if(G===J)return _;return l1(_,Y,J)})),EB=(X,Y,Q)=>i6(s((_)=>{let G=FX(_.context,X),J=Y(G);return _.setContext(l1(_.context,X,J)),r6(FX(_.context,S8),(Z)=>{let K=FX(_.context,X),H;if(Q?.reset===void 0){if(K!==J)return _0;H=G}else H=Q.reset(G,J,K);return _.setContext(l1(_.context,X,H)),_0})})),o$=()=>qk,qk=s((X)=>M(X.context)),j8=(X)=>s((Y)=>X(Y.context)),AB=V(2,(X,Y)=>f5(X,Z1(Y))),o6=V(2,(X,Y)=>{if(P1(X))return X;return f5(X,S5(Y))}),y1=function(){if(arguments.length===1)return V(2,(X,Y)=>vN(X,arguments[0],Y));return V(3,(X,Y,Q)=>vN(X,Y,Q)).apply(this,arguments)},vN=(X,Y,Q)=>f5(X,(_)=>{if(_.mapUnsafe.get(Y.key)===Q)return _;return l1(_,Y,Q)}),B7=V(3,(X,Y,Q)=>v(Q,(_)=>y1(X,Y,_))),PB=V((X)=>r(X[1]),(X,Y,Q)=>r$(X,Y,(_,G)=>[_,G],Q)),r$=V((X)=>r(X[1]),(X,Y,Q,_)=>_?.concurrent?B0(FY([X,Y],{concurrency:2}),([G,J])=>H0(()=>Q(G,J))):v(X,(G)=>B0(Y,(J)=>H0(()=>Q(G,J))))),wB=V((X)=>r(X[0]),(X,Y,Q)=>UZ(X,Y,Q?(_)=>P0(Q(_)):()=>P0(new h6))),CB=V(2,(X,Y)=>v(Y,(Q)=>Q?D7(X):NY)),i$=V(2,(X,Y)=>Array.from({length:Y},()=>X)),MB=V((X)=>r(X[0]),(X,Y,Q)=>FY(i$(X,Y),Q)),V7=V((X)=>r(X[0]),(X,Y)=>n6({while:I6,body:Z1(Y?.disableYield?X:v(X,(Q)=>d5)),step:O_})),i1=V(2,(X,Y)=>{let Q=Object.create(zk);return Q[J0]=X,Q[LX]=Y.length!==1?(_)=>Y(_):Y,Q}),zk=y6({op:"OnFailure",[u0](X){return X._stack.push(this),this[J0]}}),n$=V(3,(X,Y,Q)=>i1(X,(_)=>{if(!Y(_))return F0(_);return H0(()=>Q(_))})),p5=V(3,(X,Y,Q)=>i1(X,(_)=>{let G=Y(_);return Q0(G)?F0(G.failure):H0(()=>Q(G.success,_))})),h1=V(2,(X,Y)=>p5(X,B6,(Q)=>Y(Q))),IB=(X)=>j4(X,{onFailure:(Y)=>cJ(Y)?NY:P0(Y),onSuccess:h$}),jB=V(2,(X,Y)=>p5(X,x$,Y)),SB=V(2,(X,Y)=>i1(X,(Q)=>yX(H0(()=>Y(Q)),F0(Q)))),vB=V(3,(X,Y,Q)=>n$(X,Y,(_)=>yX(H0(()=>Q(_)),F0(_)))),q7=V(3,(X,Y,Q)=>i1(X,(_)=>{let G=Y(_);if(Q0(G))return F0(_);return yX(H0(()=>Q(G.success,_)),F0(_))})),s$=V(2,(X,Y)=>q7(X,B6,(Q)=>Y(Q))),xB=V(3,(X,Y,Q)=>{let _=Array.isArray(Y)?(G)=>I(G,"_tag")&&Y.includes(G._tag):j6(Y);return s$(X,(G)=>_(G)?Q(G):_0)}),kB=V(2,(X,Y)=>q7(X,x$,(Q)=>Y(Q))),qY=V((X)=>r(X[0]),(X,Y,Q,_)=>i1(X,(G)=>{let J=B6(G);if(Q0(J))return F0(J.failure);if(!Y(J.success))return _?H0(()=>_(J.success)):F0(G);return H0(()=>Q(J.success))})),z7=V((X)=>r(X[0]),(X,Y,Q,_)=>i1(X,(G)=>{let J=B6(G);if(Q0(J))return F0(J.failure);let Z=Y(J.success);if(Q0(Z))return _?H0(()=>_(Z.failure)):F0(G);return H0(()=>Q(Z.success))})),O7=V((X)=>r(X[0]),(X,Y,Q,_)=>{let G=Array.isArray(Y)?(J)=>I(J,"_tag")&&Y.includes(J._tag):j6(Y);return qY(X,G,Q,_)}),bB=V((X)=>r(X[0]),(X,Y,Q)=>{let _;return z7(X,(G)=>{return _??=Object.keys(Y),I(G,"_tag")&&xX(G._tag)&&_.includes(G._tag)?m(G):c(G)},(G)=>H0(()=>Y[G._tag](G)),Q)}),gB=V((X)=>r(X[0]),(X,Y,Q,_,G)=>qY(X,(J)=>j6(J,Y)&&I(J,"reason"),(J)=>{let Z=J.reason;if(j6(Z,Q))return _(Z,J);return G?H0(()=>G(Z,J)):P0(J)})),yB=V((X)=>r(X[0]),(X,Y,Q,_)=>{let G;return qY(X,(J)=>j6(J,Y)&&I(J,"reason")&&I(J.reason,"_tag")&&xX(J.reason._tag),(J)=>{let Z=J.reason;if(G??=Object.keys(Q),G.includes(Z._tag))return H0(()=>Q[Z._tag](Z,J));return _?H0(()=>_(Z,J)):P0(J)})}),hB=V(2,(X,Y)=>z7(X,(Q)=>{if(j6(Q,Y)&&I(Q,"reason"))return m(Q.reason);return c(Q)},P0)),a$=V(2,(X,Y)=>h1(X,(Q)=>U7(()=>Y(Q)))),t$=V(2,(X,Y)=>j4(X,{onFailure:(Q)=>U7(()=>Y.onFailure(Q)),onSuccess:(Q)=>X0(()=>Y.onSuccess(Q))})),L7=(X)=>h1(X,c6),mB=V(2,(X,Y)=>h1(X,(Q)=>X0(Y))),dB=(X)=>a(()=>{let Y=X[Symbol.iterator](),Q=Y.next();if(Q.done)return c6(Error("Received an empty collection of effects"));function _(G){let J=Y.next();if(J.done)return G.value;return h1(G.value,(Z)=>_(J))}return _(Q)}),e$=(X)=>h1(X,(Y)=>v(d5,()=>e$(X))),fB=V((X)=>r(X[0]),(X,Y)=>{if(!Y?.log)return j4(X,{onFailure:(_)=>_0,onSuccess:(_)=>_0});let Q=hX(Y.log===!0?void 0:Y.log);return N6(X,{onFailure(_){let G=gN(_);return Q0(G)?F0(G.failure):Y.message===void 0?Q(_):Q(Y.message,_)},onSuccess:(_)=>_0})}),pB=V((X)=>r(X[0]),(X,Y)=>{if(!Y?.log)return N6(X,{onFailure:(_)=>_0,onSuccess:(_)=>_0});let Q=hX(Y.log===!0?void 0:Y.log);return N6(X,{onFailure:(_)=>Y.message===void 0?Q(_):Q(Y.message,_),onSuccess:(_)=>_0})}),uB=(X)=>T7(X,{onFailure:f,onSuccess:T}),I8=(X)=>zY(X,{onFailure:c,onSuccess:m}),N6=V(2,(X,Y)=>{let Q=Object.create(Ok);return Q[J0]=X,Q[S1]=Y.onSuccess.length!==1?(_)=>Y.onSuccess(_):Y.onSuccess,Q[LX]=Y.onFailure.length!==1?(_)=>Y.onFailure(_):Y.onFailure,Q}),Ok=y6({op:"OnSuccessAndFailure",[u0](X){return X._stack.push(this),this[J0]}}),XZ=V(2,(X,Y)=>N6(X,{onFailure:(Q)=>X0(()=>Y.onFailure(Q)),onSuccess:(Q)=>X0(()=>Y.onSuccess(Q))})),j4=V(2,(X,Y)=>N6(X,{onFailure:(Q)=>{let _=Q.reasons.find(O4);return _?H0(()=>Y.onFailure(_.error)):F0(Q)},onSuccess:Y.onSuccess})),T7=V(2,(X,Y)=>j4(X,{onFailure:(Q)=>X0(()=>Y.onFailure(Q)),onSuccess:(Q)=>X0(()=>Y.onSuccess(Q))})),zY=V(2,(X,Y)=>{if(P1(X)){if(X._tag==="Success")return Q1(Y.onSuccess(X.value));let Q=B6(X.cause);if(Q0(Q))return X;return Q1(Y.onFailure(Q.success))}return T7(X,Y)}),cB=V(2,(X,Y)=>{if(P1(X)){if(X._tag==="Success")return Q1(Y.onSuccess(X.value));return Q1(Y.onFailure(X.cause))}return XZ(X,Y)}),OY=(X)=>P1(X)?Q1(X):Lk(X),Lk=TX({op:"Exit",[u0](X){return X._stack.push(this),this[J0]},[S1](X,Y,Q){return M(Q??Q1(X))},[LX](X,Y,Q){return M(Q??_X(X))}}),lB=zY({onFailure:()=>!0,onSuccess:()=>!1}),oB=zY({onFailure:()=>!1,onSuccess:()=>!0}),rB=V(2,(X,Y)=>yX(x4(Y),X)),YZ=V(2,(X,Y)=>N7(X,v(x4(Y.duration),Y.orElse))),iB=V(2,(X,Y)=>YZ(X,{duration:Y,orElse:()=>P0(new OZ)})),nB=V(2,(X,Y)=>N7(D7(X),g1(x4(Y),f()))),sB=(X)=>v4((Y)=>{let Q=Y.currentTimeNanosUnsafe();return B0(X,(_)=>[H6(Y.currentTimeNanosUnsafe()-Q),_])}),A$="~effect/Scope",P$="~effect/Scope/Closeable",S8=bX("effect/Scope"),QZ=(X,Y)=>a(()=>R7(X,Y)??_0),R7=(X,Y)=>{if(X.state._tag==="Closed")return;let Q={_tag:"Closed",exit:Y};if(X.state._tag==="Empty"){X.state=Q;return}let{finalizers:_}=X.state;if(X.state=Q,_.size===0)return;else if(_.size===1)return _.values().next().value(Y);return Tk(X,_,Y)},Tk=f$(function*(X,Y,Q){let _=[],G=[],J=Array.from(Y.values()),Z=H7();for(let K=J.length-1;K>=0;K--){let H=J[K];if(X.strategy==="sequential")_.push(yield*OY(H(Q)));else G.push(S4(Z,H(Q),!0,!0,"inherit"))}if(G.length>0)_=yield*g$(G);return yield*TB(_)});var aB=(X,Y)=>{let Q=LY(Y);if(X.state._tag==="Closed")return Q.state=X.state,Q;let _={};return $7(X,_,(G)=>QZ(Q,G)),$7(Q,_,(G)=>X0(()=>tB(X,_))),Q},r6=(X,Y)=>{return a(()=>{if(X.state._tag==="Closed")return Y(X.state.exit);return $7(X,{},Y),_0})};var $7=(X,Y,Q)=>{if(X.state._tag==="Empty")X.state={_tag:"Open",finalizers:new Map([[Y,Q]])};else if(X.state._tag==="Open")X.state.finalizers.set(Y,Q)},tB=(X,Y)=>{if(X.state._tag==="Open")X.state.finalizers.delete(Y)},LY=(X="sequential")=>({[P$]:P$,[A$]:A$,strategy:X,state:Rk}),Rk={_tag:"Empty"};var TY=S8,eB=y1(S8),F7=(X)=>s((Y)=>{let Q=Y.context,_=LY();return Y.setContext(l1(Y.context,S8,_)),c5(X,(G)=>{return Y.setContext(Q),R7(_,G)})});var E7=(X)=>a(()=>{let Y=LY();return m1(X(Y),(Q)=>a(()=>R7(Y,Q)??_0))}),A7=(X,Y,Q)=>j8((_)=>RY((G)=>v(TY,(J)=>V6(Q?.interruptible?G(X):X,(Z)=>r6(J,(K)=>o6(Y(Z,K),_)))))),u5=(X)=>v(TY,(Y)=>j8((Q)=>r6(Y,(_)=>o6(X(_),Q)))),c5=TX({op:"OnExit",single:!1,[u0](X){return X._stack.push(this),this[J0][0]},[q8](X){if(X.interruptible&&this[J0][2]!==!0)X._stack.push(P7),X.interruptible=!1},[S1](X,Y,Q){Q??=Q1(X);let _=this[J0][1](Q);return _?v(_,(G)=>Q):Q},[LX](X,Y,Q){Q??=_X(X);let _=this[J0][1](Q);return _?v(_,(G)=>Q):Q}}),m1=V(2,c5),XV=V(2,(X,Y)=>m1(X,(Q)=>Y)),_Z=V(3,(X,Y,Q)=>m1(X,(_)=>{if(!Y(_))return _0;return Q(_)})),GZ=V(3,(X,Y,Q)=>m1(X,(_)=>{let G=Y(_);return Q0(G)?_0:Q(G.success,_)})),JZ=V(2,(X,Y)=>GZ(X,qB,Y)),YV=V(3,(X,Y,Q)=>_Z(X,(_)=>{if(_._tag!=="Failure")return!1;return Y(_.cause)},(_)=>Q(_.cause))),$Z=V(3,(X,Y,Q)=>m1(X,(_)=>{if(_._tag!=="Failure")return _0;let G=Y(_.cause);return Q0(G)?_0:Q(G.success,_.cause)})),QV=V(2,(X,Y)=>$Z(mN,Y)(X)),_V=(X,Y,Q)=>RY((_)=>v(X,(G)=>c5(_(Y(G)),(J)=>Q(G,J),!0))),GV=(X)=>A7(X,(Y)=>I(Y,Symbol.asyncDispose)?m$(()=>Y[Symbol.asyncDispose]()):X0(()=>Y[Symbol.dispose]())),ZZ=V(2,(X,Y)=>X0(()=>{let Q=A8(GX(Y)),_=Number.isFinite(Q),G=Pk(!1),J=0,Z=!1,K,H=v(G.await,()=>K);return[s((W)=>{let D=W.getRef(q6),U=_?D.currentTimeMillisUnsafe():0;if(Z||U<J)return K??H;return Z=!0,G.closeUnsafe(),K=void 0,m1(X,(N)=>X0(()=>{Z=!1,J=D.currentTimeMillisUnsafe()+Q,K=N,G.openUnsafe()}))}),X0(()=>{J=0,G.closeUnsafe(),K=void 0})]})),KZ=V(2,(X,Y)=>B0(ZZ(X,Y),(Q)=>Q[0])),JV=(X)=>KZ(X,p6),$V=s((X)=>F0(Z7(X.id))),i6=(X)=>s((Y)=>{if(!Y.interruptible)return X;return Y.interruptible=!1,Y._stack.push(P7),X}),ZV=TX({op:"SetInterruptible",[q8](X){if(X.interruptible=this[J0],X._interruptedCause&&X.interruptible)return()=>F0(X._interruptedCause)}}),P7=ZV(!0),Fk=ZV(!1),KV=(X)=>{if(X.interruptible=!0,X._stack.push(Fk),X._interruptedCause)return F0(X._interruptedCause)},HZ=(X)=>s((Y)=>{if(Y.interruptible)return X;return KV(Y)??X}),RY=(X)=>s((Y)=>{if(!Y.interruptible)return X(u);return Y.interruptible=!1,Y._stack.push(P7),X(HZ)}),HV=(X)=>s((Y)=>{if(Y.interruptible)return X(u);let Q=KV(Y),_=X(i6);return Q??_}),WV=B0(A7(X0(()=>new AbortController),(X)=>X0(()=>X.abort())),(X)=>X.signal),FY=(X,Y)=>{if(S6(X))return Y?.mode==="result"?$X(X,I8,Y):$X(X,u,Y);else if(Y?.discard)return Y.mode==="result"?$X(Object.values(X),I8,Y):$X(Object.values(X),u,Y);return a(()=>{let Q={};return g1($X(Object.entries(X),([_,G])=>B0(Y?.mode==="result"?I8(G):G,(J)=>{k(Q,_,J)}),{discard:!0,concurrency:Y?.concurrency}),Q)})},WZ=V((X)=>S6(X[0])&&!r(X[0]),(X,Y,Q)=>B0($X(X,(_,G)=>I8(Y(_,G)),Q),(_)=>N$(_,u))),UV=V(3,(X,Y,Q)=>{let _=A1(X);if(_.length===0)return X0(Y);return a(()=>{let G=0,J=Y();return B0(n6({while:()=>G<_.length,body:()=>Q(J,_[G],G),step(Z){J=Z,G++}}),()=>J)})}),DV=V((X)=>S6(X[0])&&!r(X[0]),(X,Y,Q)=>v(WZ(X,Y,{concurrency:Q?.concurrency}),([_,G])=>{if(W6(_))return P0(_);return Q?.discard?_0:M(G)})),NV=V((X)=>S6(X[0])&&!r(X[0]),(X,Y)=>a(()=>{let Q=X[Symbol.iterator](),_=Q.next();if(!_.done)return BV(Q,0,Y,_.value);return M(f())})),BV=(X,Y,Q,_)=>v(Q(_,Y),(G)=>{if(G)return M(T(_));let J=X.next();if(!J.done)return BV(X,Y+1,Q,J.value);return M(f())}),VV=V((X)=>S6(X[0])&&!r(X[0]),(X,Y)=>a(()=>{let Q=X[Symbol.iterator](),_=Q.next();if(!_.done)return qV(Q,0,Y,_.value);return M(f())})),qV=(X,Y,Q,_)=>v(Q(_,Y),(G)=>{if(t0(G))return M(T(G.success));let J=X.next();if(!J.done)return qV(X,Y+1,Q,J.value);return M(f())}),n6=TX({op:"While",[S1](X,Y){if(this[J0].step(X),this[J0].while())return Y._stack.push(this),this[J0].body();return ZX},[u0](X){if(this[J0].while())return X._stack.push(this),this[J0].body();return ZX}}),$X=V((X)=>typeof X[1]==="function",(X,Y,Q)=>a(()=>{let _=Q?.concurrency??1,G=_==="unbounded"?Number.POSITIVE_INFINITY:Math.max(1,_);if(G===1)return Ek(X,Y,Q);let J=A1(X),Z=J.length;if(Z===0)return Q?.discard?_0:M([]);let K=Q?.discard?void 0:Array(Z),H=Ak({f:Y,out:K},J,{concurrency:G});return H?g1(H,K):M(K)})),Ek=(X,Y,Q)=>a(()=>{let _=Q?.discard?void 0:[],G=X[Symbol.iterator](),J=G.next(),Z=0;return g1(n6({while:()=>!J.done,body:()=>Y(J.value,Z++),step:(K)=>{if(_)_.push(K);J=G.next()}}),_)}),zV=(X)=>{let{onItem:Y,step:Q}=X;return(_,G,J)=>{let Z=J?.start??0,K=J?.end??G.length,H=J?.concurrency??1,W=J?.orderedStep===!0&&H>1,D=!1,U,N,B,q=!1,O,R,F=Z,P=W?Array(K):void 0,C=(E)=>{let j=$6(E);return O=j,D=!0,q=!0,N&&N.size>0?v(i6(I4(Array.from(N))),()=>j):j},w=(E,j,t)=>{if(!W)return Q(_,E,j,t);if(O)return O;P[t]=j;while(F<K){let z0=P[F];if(z0===void 0)return;P[F]=void 0;let I1=F++,$1=Q(_,G[I1],z0,I1);if($1)return $1}},L=()=>{let E=!1;for(;!O&&Z<K;Z++){let j=G[Z],t=R??Y(_,j,Z);if(P1(t)){if(O=w(j,t,Z),O)break}else if(H===1)return v(OY(t),(z0)=>{return O=w(j,z0,Z),Z++,O??L()??_0});else if(!U)return r1((z0)=>{U=H7(),N=new Set,R=t,B=z0;let I1;try{I1=L()}catch($1){return z0(C($1))}if(I1)return z0(I1);return a(()=>{return O=ZX,q=!0,N?I4(N):_0})});else{R=void 0;let z0=S4(U,t,!0,!0,"inherit");if(z0._exit){if(O=w(j,z0._exit,Z),O)break;continue}N.add(z0);let I1=Z;if(z0.addObserver(($1)=>{N.delete(z0);try{if(O){if(!q&&$1._tag==="Failure")for(let j0 of $1.cause.reasons)if(j0._tag==="Interrupt")continue;else if(O._tag==="Failure")O.cause.reasons.push(j0);else O=_X(g6([j0]))}else{let j0=w(j,$1,I1);if(j0)O=j0._tag==="Failure"?_X(g6(j0.cause.reasons.slice())):j0,L()}if(E){let j0=L();if(j0)B(j0)}else if(D&&N.size===0)B(O??_0)}catch(j0){B(C(j0))}}),N.size<H)continue;E=!0,Z++;return}}if(D=!0,O){if(N&&N.size>0){let j=W7(U);N.forEach((t)=>t.interruptUnsafe(U.id,j));return}if(B||O._tag==="Failure")return O}else if(B){if(!N)return ZX;else if(N.size===0)B(_0)}};return L()}},EY=()=>zV,Ak=zV({onItem(X,Y,Q){return X.f(Y,Q)},step(X,Y,Q,_){if(Q._tag==="Failure")return Q;else if(X.out)X.out[_]=Q.value}}),UZ=V(3,(X,Y,Q)=>v(X,(_)=>Y(_)?M(_):Q(_))),DZ=V(3,(X,Y,Q)=>v(X,(_)=>{let G=Y(_);return Q0(G)?Q(G.failure):M(G.success)})),OV=V((X)=>r(X[0]),(X,Y,Q)=>DZ(X,Y,Q?(_)=>P0(Q(_)):()=>P0(new h6))),LV=V((X)=>S6(X[0])&&!r(X[0]),(X,Y,Q)=>a(()=>{let _=[];return g1($X(X,(G,J)=>{let Z=Y(G,J);if(typeof Z==="boolean"){if(Z)_.push(G);return _0}return B0(Z,(K)=>{if(K)_.push(G)})},{discard:!0,concurrency:Q?.concurrency}),_)})),TV=V((X)=>S6(X[0])&&!r(X[0]),(X,Y)=>a(()=>{let Q=[];for(let _ of X){let G=Y(_);if(t0(G))Q.push(G.success)}return M(Q)})),RV=V((X)=>S6(X[0])&&!r(X[0]),(X,Y,Q)=>a(()=>{let _=[];return g1($X(X,(G)=>B0(Y(G),(J)=>{if(t0(J))_.push(J.success)}),{discard:!0,concurrency:Q?.concurrency}),_)})),FV=M({}),EV=g_(B0),AV=y_(B0,v),PV=b_(B0);var wV=V((X)=>r(X[0]),(X,Y)=>s((Q)=>{return uk(),M(S4(Q,X,Y?.startImmediately,!1,Y?.uninterruptible??!1))})),S4=(X,Y,Q=!1,_=!1,G=!1)=>{let J=G==="inherit"?X.interruptible:!G,Z=new b$(X.context,J);if(Q)Z.evaluate(Y);else X.currentDispatcher.scheduleTask(()=>Z.evaluate(Y),0);if(!_&&!Z._exit)X.children().add(Z),Z.addObserver(()=>X._children.delete(Z));return Z},CV=V((X)=>r(X[0]),(X,Y)=>s((Q)=>M(S4(Q,X,Y?.startImmediately,!0,Y?.uninterruptible)))),MV=(X)=>s((Y)=>{let Q=Y._children&&new Set(Y._children);return m1(X,(_)=>{let G=Y._children;if(G===void 0||G.size===0)return _0;else if(Q)G=UN(G,(J)=>!Q.has(J));return VY(g$(G))})}),NZ=V((X)=>r(X[0]),(X,Y,Q)=>s((_)=>{let G=S4(_,X,Q?.startImmediately,!0,Q?.uninterruptible);if(!G._exit)if(Y.state._tag!=="Closed"){let J={};$7(Y,J,()=>eN((K)=>K===G.id?_0:Uk(G))),G.addObserver(()=>tB(Y,J))}else G.interruptUnsafe(_.id,W7(_));return M(G)})),IV=V((X)=>r(X[0]),(X,Y)=>v(TY,(Q)=>NZ(X,Q,Y))),s6=(X)=>(Y,Q)=>{let _=new b$(Q?.scheduler?l1(X,KY,Q.scheduler):X,Q?.uninterruptible!==!0);if(_.evaluate(Y),_._exit)return _;if(Q?.signal)if(Q.signal.aborted)_.interruptUnsafe();else{let G=()=>_.interruptUnsafe();Q.signal.addEventListener("abort",G,{once:!0}),_.addObserver(()=>Q.signal.removeEventListener("abort",G))}if(Q?.onFiberStart)Q.onFiberStart(_);return _};var jV=s6(x1()),BZ=(X)=>{let Y=s6(X);return(Q,_)=>{let G=Y(Q,_);if(_?.onExit)G.addObserver(_.onExit);return(J)=>{return G.interruptUnsafe(J)}}},SV=BZ(x1()),w7=(X)=>{let Y=s6(X);return(Q,_)=>{let G=Y(Q,_);return new Promise((J)=>{G.addObserver((Z)=>J(Z))})}},vV=w7(x1()),VZ=(X)=>{let Y=w7(X);return(Q,_)=>Y(Q,_).then((G)=>{if(G._tag==="Failure")throw k$(G.cause);return G.value})},xV=VZ(x1()),C7=(X)=>{let Y=s6(X);return(Q)=>{if(P1(Q))return Q;let _=new b5("sync"),G=Y(Q,{scheduler:_});return G._dispatcher?.flush(),G._exit??$6(new TZ(G))}},kV=C7(x1()),qZ=(X)=>{let Y=C7(X);return(Q)=>{let _=Y(Q);if(_._tag==="Failure")throw k$(_.cause);return _.value}},bV=qZ(x1()),xN=M(!0),kN=M(!1);class gV{waiters=[];scheduled=void 0;_isOpen;constructor(X){this._isOpen=X}scheduleUnsafe(X){if(this.waiters.length===0)return xN;if(this.scheduled===void 0)this.scheduled=this.waiters,X.currentDispatcher.scheduleTask(this.flushScheduled,0);else for(let Y=0;Y<this.waiters.length;Y++)this.scheduled.push(this.waiters[Y]);return this.waiters=[],xN}flushScheduled=()=>{if(this.scheduled===void 0)return;let X=this.scheduled;this.scheduled=void 0;for(let Y=0;Y<X.length;Y++)X[Y](ZX)};flushWaiters(){let X=this.waiters;this.waiters=[],this.flushScheduled();for(let Y=0;Y<X.length;Y++)X[Y](ZX)}open=s((X)=>{if(this._isOpen)return kN;return this._isOpen=!0,this.scheduleUnsafe(X)});release=s((X)=>this._isOpen?kN:this.scheduleUnsafe(X));openUnsafe(){if(this._isOpen)return!1;return this._isOpen=!0,this.flushWaiters(),!0}await=r1((X)=>{if(this._isOpen)return X(_0);return this.waiters.push(X),X0(()=>{let Y=this.waiters.indexOf(X);if(Y!==-1)this.waiters.splice(Y,1);else if(this.scheduled!==void 0){if(Y=this.scheduled.indexOf(X),Y!==-1)this.scheduled.splice(Y,1)}})});closeUnsafe(){if(!this._isOpen)return!1;return this._isOpen=!1,!0}close=X0(()=>this.closeUnsafe());whenOpen=(X)=>v(this.await,()=>X);isOpen(){return this._isOpen}}var Pk=(X)=>new gV(X??!1);var yV=s((X)=>M(X.getRef(_7))),hV=V(2,(X,Y)=>y1(X,_7,Y)),mV=y1(G7),dV=y1(HY),w$=BigInt(0),wk={_tag:"Span",spanId:"noop",traceId:"noop",sampled:!1,status:{_tag:"Ended",startTime:w$,endTime:w$,exit:ZX},attributes:new Map,links:[],kind:"internal",attribute(){},event(){},end(){},addLinks(){}},Ck=(X)=>Object.assign(Object.create(wk),X),fV=(X)=>{if(!X)return f();return v1(X.annotations,Q7)?X._tag==="Span"?fV(F4(X.parent)):f():T(X)},zZ=(X,Y,Q)=>{let _=!X.getRef(G7)||Q?.annotations&&v1(Q.annotations,Q7),G=Q?.parent!==void 0?T(Q.parent):Q?.root?f():fV(X.currentSpan),J;if(_)J=Ck({name:Y,parent:G,annotations:l1(Q?.annotations??x1(),Q7,!0)});else{let Z=X.getRef(_7),K=X.getRef(q6),H=X.getRef(HY),W=X.getRef(WY),D=X.getRef(UY),U=Q?.level??X.getRef(FN),N=Q?.links!==void 0?[...D,...Q.links]:D.slice();J=Z.span({name:Y,parent:G,annotations:Q?.annotations??x1(),links:N,startTime:H?K.currentTimeNanosUnsafe():BigInt(0),kind:Q?.kind??"internal",root:Q?.root??E0(G),sampled:Q?.sampled??(W1(G)&&G.value.sampled===!1?!1:!Xq(X.getRef(EN),U))});for(let[B,q]of Object.entries(W))J.attribute(B,q);if(Q?.attributes!==void 0)for(let[B,q]of Object.entries(Q.attributes))J.attribute(B,q)}return J},pV=(X,Y)=>s((Q)=>M(zZ(Q,X,Y))),gX=(X,Y)=>i6(s((Q)=>{let _=FX(Q.context,S8),G=zZ(Q,X,Y??{}),J=Q.getRef(q6),Z=Q.getRef(HY);return g1(r6(_,(K)=>Ik(G,K,J,Z)),G)})),uV=function(){let X=typeof arguments[0]!=="string",Y=X?arguments[1]:arguments[0],Q=M8(X?arguments[2]:arguments[1]);if(X){let _=arguments[0];return v(gX(Y,Q),(G)=>h5(_,G,Q))}return(_)=>v(gX(Y,Q),(G)=>h5(_,G,Q))},Mk=(X,Y)=>{return Y=typeof Y==="function"?Y:OX,l6(g5,(Q)=>({name:X,stack:Y,parent:Q}))},cV=WY,lV=UY,oV=V((X)=>r(X[0]),(X,Y,Q={})=>{let G=(Array.isArray(Y)?Y:[Y]).map((J)=>({span:J,attributes:Q}));return l6(X,UY,(J)=>[...J,...G])}),Ik=(X,Y,Q,_)=>X0(()=>{if(X.status._tag==="Ended")return;X.end(_?Q.currentTimeNanosUnsafe():w$,Y)}),DY=(X,...Y)=>{let Q=Y.length===1?void 0:Y[0],_=Y[Y.length-1];return s((G)=>{let J=zZ(G,X,Q),Z=G.getRef(q6);return m1(H0(()=>_(J)),(K)=>X0(()=>{if(J.status._tag==="Ended")return;J.end(Z.currentTimeNanosUnsafe(),K)}))})},C$=y1(C4),h5=function(){let X=r(arguments[0]),Y=X?arguments[1]:arguments[0],Q=X?arguments[2]:arguments[1],_=u;if(Y._tag==="Span")Q=M8(Q),_=Mk(Y.name,Q?.captureStackTrace);if(X)return C$(_(arguments[0]),Y);return(G)=>C$(_(G),Y)},rV=function(){let X=typeof arguments[0]!=="string",Y=X?arguments[1]:arguments[0],Q=M8(arguments[2]);if(X){let J=arguments[0];return DY(Y,arguments[2],(Z)=>h5(J,Z,Q))}let _=typeof arguments[1]==="function"?arguments[1]:void 0,G=_?void 0:arguments[1];return(J,...Z)=>DY(Y,_?_(...Z):G,(K)=>h5(J,K,Q))},iV=V((X)=>r(X[0]),(X,...Y)=>l6(X,WY,(Q)=>{let _=Y.length===1?{...Q,...Y[0]}:{...Q};if(Y.length===1)return _;else k(_,Y[0],Y[1]);return _})),nV=(...X)=>s((Y)=>{let Q=Y.currentSpanLocal;if(Q)if(X.length===1)for(let[_,G]of Object.entries(X[0]))Q.attribute(_,G);else Q.attribute(X[0],X[1]);return _0}),sV=s((X)=>{let Y=X.currentSpanLocal;return Y?M(Y):P0(new h6)}),aV=Vk(C4),q6=O0("effect/Clock",{defaultValue:()=>new tV}),T$=2147483647;class tV{currentTimeMillisUnsafe(){return Date.now()}currentTimeMillis=X0(()=>this.currentTimeMillisUnsafe());currentTimeNanosUnsafe(){return Sk()}currentTimeNanos=X0(()=>this.currentTimeNanosUnsafe());sleep(X){return this.sleepMillis(A8(X))}sleepMillis(X){if(X<=0)return d5;else if(!Number.isFinite(X))return BY;return r1((Y)=>{let Q=X>T$?this.sleepMillis(X-T$):_0,_=setTimeout(()=>Y(Q),Math.min(X,T$));return X0(()=>clearTimeout(_))})}}var jk=function(){let X=BigInt(1e6);if(typeof performance>"u"||typeof performance.now>"u")return()=>BigInt(Date.now())*X;let Y;return()=>{return Y??=BigInt(Date.now())*X-BigInt(Math.round(performance.now()*1e6)),Y+BigInt(Math.round(performance.now()*1e6))}}(),Sk=function(){let X=typeof process==="object"&&"hrtime"in process&&typeof process.hrtime.bigint==="function"?process.hrtime:void 0;if(!X)return jk;let Y=BigInt(Date.now())*BigInt(1e6)-X.bigint();return()=>Y+X.bigint()}(),v4=(X)=>s((Y)=>X(Y.getRef(q6))),x4=(X)=>v4((Y)=>Y.sleep(GX(X))),eV=v4((X)=>X.currentTimeMillis);var M$="~effect/Cause/TimeoutError";class OZ extends z8("TimeoutError"){[M$]=M$;constructor(X){super({message:X})}}var I$="~effect/Cause/IllegalArgumentError";class LZ extends z8("IllegalArgumentError"){[I$]=I$;constructor(X){super({message:X})}}var j$="~effect/Cause/AsyncFiberError";class TZ extends z8("AsyncFiberError"){[j$]=j$;constructor(X){super({message:"An asynchronous Effect was executed with Effect.runSync",fiber:X})}}var S$="~effect/Cause/UnknownError";class M7 extends z8("UnknownError"){[S$]=S$;constructor(X,Y){super({message:Y,cause:X})}}var vk=O0("effect/Console/CurrentConsole",{defaultValue:()=>globalThis.console}),xk=(X)=>{switch(X){case"All":return Number.MIN_SAFE_INTEGER;case"Fatal":return 50000;case"Error":return 40000;case"Warn":return 30000;case"Info":return 20000;case"Debug":return 1e4;case"Trace":return 0;case"None":return Number.MAX_SAFE_INTEGER}},kk=nJ(q1,xk),Xq=R8(kk),RZ=O0("effect/Loggers/CurrentLoggers",{defaultValue:()=>new Set([fk,pk])}),bk=O0("effect/Logger/LogToStderr",{defaultValue:q_}),Yq=function(){let X=typeof arguments[0]==="string"?[[arguments[0],arguments[1]]]:Object.entries(arguments[0]);return i6(s((Y)=>{let Q=Y.getRef(u6),_={...Q};for(let G=0;G<X.length;G++){let[J,Z]=X[G];k(_,J,Z)}return Y.setContext(l1(Y.context,u6,_)),r6(FX(Y.context,S8),(G)=>{let J=Y.getRef(u6),Z={...J};for(let K=0;K<X.length;K++){let[H,W]=X[K];if(J[H]!==W)continue;if(Object.hasOwn(Q,H))k(Z,H,Q[H]);else delete Z[H]}return Y.setContext(l1(Y.context,u6,Z)),_0})}))},gk="~effect/Logger",yk={[gk]:{_Message:u,_Output:u},pipe(){return G0(this,arguments)}},Qq=(X)=>{let Y=Object.create(yk);return Y.log=X,Y},hk=(X)=>X.replace(/[\s="]/g,"_"),mk=(X,Y)=>{return`${hk(X[0])}=${Y-X[1]}ms`};var hX=(X)=>(...Y)=>{let Q=void 0;for(let _=0,G=Y.length;_<G;_++){let J=Y[_];if(P5(J)){if(Q)Y.splice(_,1);else Y=Y.slice(0,_).concat(Y.slice(_+1));Q=Q?g6(Q.reasons.concat(J.reasons)):J,_--}}if(Q===void 0)Q=j_;return s((_)=>{let G=X??_.currentLogLevel;if(Xq(_.minimumLogLevel,G))return _0;let J=_.getRef(q6),Z=_.getRef(RZ);if(Z.size>0){let K=new Date(J.currentTimeMillisUnsafe());for(let H of Z)H.log({cause:Q,fiber:_,date:K,logLevel:G,message:Y})}return _0})};var M4={bold:"1",red:"31",green:"32",yellow:"33",blue:"34",cyan:"36",white:"37",gray:"90",black:"30",bgBrightRed:"101"},wY0={None:[],All:[],Trace:[M4.gray],Debug:[M4.blue],Info:[M4.green],Warn:[M4.yellow],Error:[M4.red],Fatal:[M4.bgBrightRed,M4.black]};var dk=(X)=>`${X.getHours().toString().padStart(2,"0")}:${X.getMinutes().toString().padStart(2,"0")}:${X.getSeconds().toString().padStart(2,"0")}.${X.getMilliseconds().toString().padStart(3,"0")}`;var fk=Qq(({cause:X,date:Y,fiber:Q,logLevel:_,message:G})=>{let J=Array.isArray(G)?G.slice():[G];if(X.reasons.length>0)J.push(K7(X));let Z=Y.getTime(),K=Q.getRef(J7),H="";for(let N of K)H+=` ${mk(N,Z)}`;let W=Q.getRef(u6);if(Object.keys(W).length>0)J.push(W);let D=Q.getRef(vk);(Q.getRef(bk)?D.error:D.log)(`[${dk(Y)}] ${_.toUpperCase()} (#${Q.id})${H}:`,...J)}),pk=Qq(({cause:X,fiber:Y,logLevel:Q,message:_})=>{let G=Y.getRef(q6),J=Y.getRef(u6),Z=Y.currentSpan;if(Z===void 0||Z._tag==="ExternalSpan")return;let K={};for(let[H,W]of Object.entries(J))k(K,H,W);if(K["effect.fiberId"]=Y.id,K["effect.logLevel"]=Q.toUpperCase(),X.reasons.length>0)K["effect.cause"]=K7(X);Z.event(CD(Array.isArray(_)&&_.length===1?_[0]:_),G.currentTimeNanosUnsafe(),K)});function uk(){E$.interruptChildren??=Hk}var FZ=M(void 0);var _q=V((X)=>r(X[0]),(X,Y)=>JZ(X,(Q)=>s((_)=>{return ck(_,Q,Y?.defectsOnly),_0}))),ck=(X,Y,Q)=>{let _=X.getRef(CN);if(_.size===0)return;if(Q&&!yN(Y))return;let G={cause:Y,fiber:X,timestamp:X.getRef(q6).currentTimeNanosUnsafe()};_.forEach((J)=>J.report(G))};var Gq=pJ,l5=Q1,v8=_X,AY=J6;var Jq=ZX;var w1=l$,$q=VB;var i5={};M6(i5,{withSpan:()=>Eb,withParentSpan:()=>wZ,updateService:()=>Pq,unwrap:()=>PZ,tapError:()=>Hb,tapCause:()=>Wb,tap:()=>Kb,syncContext:()=>AZ,sync:()=>_b,suspend:()=>Jb,succeedContext:()=>b4,succeed:()=>Rq,span:()=>Fb,satisfiesSuccessType:()=>Lb,satisfiesServicesType:()=>Rb,satisfiesErrorType:()=>Tb,provideMerge:()=>Zb,provide:()=>o5,parentSpan:()=>wq,orDie:()=>Ub,mock:()=>zb,mergeAll:()=>b7,merge:()=>$b,makeMemoMapUnsafe:()=>r5,makeMemoMap:()=>Xb,launch:()=>qb,isLayer:()=>v7,fromBuildMemo:()=>x7,fromBuild:()=>x8,fresh:()=>Vb,forkMemoMapUnsafe:()=>MZ,forkMemoMap:()=>Yb,flatMap:()=>Aq,empty:()=>Qb,effectDiscard:()=>Gb,effectContext:()=>jZ,effect:()=>k7,catchTag:()=>Nb,catchCause:()=>Bb,catch:()=>Db,buildWithScope:()=>IZ,buildWithMemoMap:()=>wY,build:()=>Tq,CurrentMemoMap:()=>k4});var lk="~effect/Deferred";var ok={[lk]:{_A:u,_E:u},pipe(){return G0(this,arguments)}},Zq=()=>{let X=Object.create(ok);return X.resumes=void 0,X.effect=void 0,X};var Kq=(X)=>r1((Y)=>{if(X.effect)return Y(X.effect);return X.resumes??=[],X.resumes.push(Y),X0(()=>{let Q=X.resumes.indexOf(Y);X.resumes.splice(Q,1)})});var rk=V(2,(X,Y)=>X0(()=>ik(X,Y))),Hq=rk;var ik=(X,Y)=>{if(X.effect)return!1;if(X.effect=Y,X.resumes){for(let Q=0;Q<X.resumes.length;Q++)X.resumes[Q](Y);X.resumes=void 0}return!0};var Wq=u6;var Uq=J7,Dq=g5;var Nq=S8;var Bq=LY,PY=eB;var j7=aB,EZ=QZ;var Lq="~effect/Layer",Vq="~effect/Layer/MemoMap",ak=(X,Y)=>{return X.observers++,yX(r6(Y,(Q)=>X.finalizer(Q)),X.effect)},v7=(X)=>I(X,Lq),tk={[Lq]:{_ROut:u,_E:u,_RIn:u},pipe(){return G0(this,arguments)}},g4=(X)=>{let Y=Object.create(tk);return Y.build=X,Y},x8=(X)=>g4((Y,Q)=>{let _=j7(Q);return m1(X(Y,_),(G)=>G._tag==="Failure"?EZ(_,G):_0)}),x7=(X)=>{let Y=x8((Q,_)=>Q.getOrElseMemoize(Y,_,X));return Y},ek=(X,Y,Q,_)=>{let G=Bq(),J=Zq(),Z={observers:1,effect:Kq(J),finalizer:(K)=>a(()=>{if(Z.observers--,Z.observers===0)return X.map.delete(Y),EZ(G,K);return _0})};return X.map.set(Y,Z),r6(Q,Z.finalizer).pipe(v(()=>_(X,G)),m1((K)=>{return Z.effect=K,Hq(J,K)}))};class CZ{get[Vq](){return Vq}parent;constructor(X){this.parent=X}map=new Map;get(X,Y){let Q=this.map.get(X);if(Q)return ak(Q,Y);return this.parent?.get(X,Y)}getOrElseMemoize(X,Y,Q){let _=this.get(X,Y);if(_)return _;return ek(this,X,Y,Q)}}var r5=()=>new CZ,MZ=(X)=>new CZ(X),Xb=X0(r5),Yb=(X)=>X0(()=>MZ(X));class k4 extends bX()("effect/Layer/CurrentMemoMap"){static forkOrCreate(X){let Y=eJ(X,k4);return Y?MZ(Y):r5()}}var wY=V(3,(X,Y,Q)=>y1(B0(X.build(Y,Q),l1(k4,Y)),k4,Y)),Tq=(X)=>s((Y)=>wY(X,k4.forkOrCreate(Y.context),FX(Y.context,Nq))),IZ=V(2,(X,Y)=>s((Q)=>wY(X,k4.forkOrCreate(Q.context),Y))),Rq=function(){if(arguments.length===1)return(X)=>b4(K6(arguments[0],X));return b4(K6(arguments[0],arguments[1]))},b4=(X)=>g4(Z1(M(X))),Qb=b4(x1()),_b=function(){if(arguments.length===1)return(X)=>AZ(()=>K6(arguments[0],X()));return AZ(()=>K6(arguments[0],arguments[1]()))},AZ=(X)=>x7(Z1(X0(X))),k7=function(){if(arguments.length===1)return(X)=>qq(arguments[0],X);return qq(arguments[0],arguments[1])},qq=(X,Y)=>jZ(B0(Y,(Q)=>K6(X,Q))),jZ=(X)=>x7((Y,Q)=>PY(X,Q)),Gb=(X)=>jZ(g1(X,x1())),Jb=(X)=>x7((Y,Q)=>a(()=>X().build(Y,Q))),PZ=(X)=>{let Y=bX("effect/Layer/unwrap");return Aq(k7(Y)(X),v1(Y))},Fq=(X,Y,Q)=>{let _=j7(Q,"parallel");return $X(X,(G)=>G.build(Y,j7(_,"sequential")),{concurrency:X.length}).pipe(B0((G)=>Q$(...G)))},b7=(...X)=>x8((Y,Q)=>Fq(X,Y,Q)),$b=V(2,(X,Y)=>b7(X,...Array.isArray(Y)?Y:[Y])),Eq=(X,Y,Q)=>x8((_,G)=>v(Array.isArray(Y)?Fq(Y,_,G):Y.build(_,G),(J)=>X.build(_,G).pipe(o6(J),B0((Z)=>Q(Z,J))))),o5=V(2,(X,Y)=>Eq(X,Y,u)),Zb=V(2,(X,Y)=>Eq(X,Y,(Q,_)=>S5(_,Q))),Aq=V(2,(X,Y)=>x8((Q,_)=>v(X.build(Q,_),(G)=>Y(G).build(Q,_)))),Kb=V(2,(X,Y)=>x8((Q,_)=>v(X.build(Q,_),(G)=>PY(g1(Y(G),G),_)))),Hb=V(2,(X,Y)=>x8((Q,_)=>h1(X.build(Q,_),(G)=>PY(yX(Y(G),P0(G)),_)))),Wb=V(2,(X,Y)=>x8((Q,_)=>i1(X.build(Q,_),(G)=>PY(yX(Y(G),F0(G)),_)))),Ub=(X)=>g4((Y,Q)=>L7(X.build(Y,Q))),Db=V(2,(X,Y)=>g4((Q,_)=>h1(X.build(Q,_),(G)=>Y(G).build(Q,_))));var Nb=V(3,(X,Y,Q)=>g4((_,G)=>O7(X.build(_,G),Y,(J)=>Q(J).build(_,G)))),Bb=V(2,(X,Y)=>g4((Q,_)=>i1(X.build(Q,_),(G)=>Y(G).build(Q,_)))),Pq=V(3,(X,Y,Q)=>o5(X,k7(Y,B0(Y,Q)))),Vb=(X)=>g4((Y,Q)=>X.build(r5(),Q)),qb=(X)=>F7(yX(Tq(X),BY)),zb=function(){if(arguments.length===1)return(X)=>zq(arguments[0],X);return zq(arguments[0],arguments[1])},zq=(X,Y)=>Rq(X)(new Proxy({...Y},{get(Q,_,G){if(_ in Q)return Q[_];let J=Z6();F1(2);let Z=Error(`${X.key}: Unimplemented method "${_.toString()}"`);return F1(J),Z.name="UnimplementedError",Ob(Z)},has:I6})),Ob=(X)=>{let Y=Object.assign(c6(X),{[Oq]:Oq,channel:{[S7]:S7,transform:()=>M(Y),pipe(){return G0(this,arguments)}},[S7]:S7,transform:()=>M(Y)});function Q(){return Y}return Object.assign(Q,Y),Object.setPrototypeOf(Q,Object.getPrototypeOf(Y)),Q},Oq="~effect/Stream",S7="~effect/Channel",Lb=()=>(X)=>X,Tb=()=>(X)=>X,Rb=()=>(X)=>X,Fb=(X,Y)=>{return Y=M8(Y),k7(C4,Y?.onEnd?V6(gX(X,Y),(Q)=>u5((_)=>Y.onEnd(Q,_))):gX(X,Y))},wq=(X)=>b4(C4.context(X)),Eb=function(){let X=typeof arguments[0]!=="string",Y=X?arguments[1]:arguments[0],Q=M8(X?arguments[2]:arguments[1]);if(X){let _=arguments[0];return PZ(B0(Q?.onEnd!==void 0?V6(gX(Y,Q),(G)=>u5((J)=>Q.onEnd(G,J))):gX(Y,Q),(G)=>wZ(_,G)))}return(_)=>PZ(B0(Q?.onEnd!==void 0?V6(gX(Y,Q),(G)=>u5((J)=>Q.onEnd(G,J))):gX(Y,Q),(G)=>wZ(_,G)))},wZ=function(){let X=v7(arguments[0]),Y=X?arguments[1]:arguments[0],Q=X?arguments[2]:arguments[1],_=u;if(Y._tag==="Span")Q=M8(Q),_=Ab(Y.name,Q?.captureStackTrace);let G=wq(Y);if(X)return o5(_(arguments[0]),G);return(J)=>o5(_(J),G)},Ab=(X,Y)=>{return Y=typeof Y==="function"?Y:OX,Pq(Dq,(Q)=>({name:X,stack:Y,parent:Q}))};var Cq="~effect/ExecutionPlan";var Pb={[Cq]:Cq,get captureRequirements(){let X=this;return j8((Y)=>M(wb(X.steps.map((Q)=>({...Q,provide:v7(Q.provide)?o5(Q.provide,b4(Y)):Q.provide})))))},pipe(){return G0(this,arguments)}},wb=(X)=>{let Y=Object.create(Pb);return Y.steps=X,Y};var Mq=O0("effect/ExecutionPlan/CurrentMetadata",{defaultValue:Z1({attempt:0,stepIndex:0})});var Iq=P5,jq=SD,g7=O4;var y7=g6,Sq=j_;var h7=(X)=>new w5(X),m7=(X)=>new S_(X),d7=bN;var a6=fN;var SZ=B6;var vq=K7;var vZ=QY;var xZ=yD;var f7=LZ;var p7="~effect/time/DateTime",u7="~effect/time/DateTime/TimeZone",kq={[p7]:p7,pipe(){return G0(this,arguments)},[K1](){return this.toString()},toJSON(){return jY(this).toJSON()}},vb={...kq,_tag:"Utc",[U0](){return v6(this.epochMilliseconds)},[D0](X){return s5(X)&&X._tag==="Utc"&&this.epochMilliseconds===X.epochMilliseconds},toString(){return`DateTime.Utc(${jY(this).toJSON()})`}},xb={...kq,_tag:"Zoned",[U0](){return Y1(v6(this.epochMilliseconds))(e(this.zone))},[D0](X){return s5(X)&&X._tag==="Zoned"&&this.epochMilliseconds===X.epochMilliseconds&&o(this.zone,X.zone)},toString(){return`DateTime.Zoned(${rZ(this)})`}},bq={[u7]:u7,[K1](){return this.toString()}},kb={...bq,_tag:"Named",[U0](){return S0(`Named:${this.id}`)},[D0](X){return h4(X)&&X._tag==="Named"&&this.id===X.id},toString(){return`TimeZone.Named(${this.id})`},toJSON(){return{_id:"TimeZone",_tag:"Named",id:this.id}}},bb={...bq,_tag:"Offset",[U0](){return S0(`Offset:${this.offset}`)},[D0](X){return h4(X)&&X._tag==="Offset"&&this.offset===X.offset},toString(){return`TimeZone.Offset(${cZ(this.offset)})`},toJSON(){return{_id:"TimeZone",_tag:"Offset",offset:this.offset}}},z6=(X,Y,Q)=>{let _=Object.create(xb);return _.epochMilliseconds=X,_.zone=Y,Object.defineProperty(_,"partsUtc",{value:Q,enumerable:!1,writable:!0}),Object.defineProperty(_,"adjustedEpochMillis",{value:void 0,enumerable:!1,writable:!0}),Object.defineProperty(_,"partsAdjusted",{value:void 0,enumerable:!1,writable:!0}),_},s5=(X)=>I(X,p7);var h4=(X)=>I(X,u7),gq=(X)=>h4(X)&&X._tag==="Offset",yq=(X)=>h4(X)&&X._tag==="Named",hq=(X)=>X._tag==="Utc",gZ=(X)=>X._tag==="Zoned",mq=H1((X,Y)=>X.epochMilliseconds===Y.epochMilliseconds),dq=T4((X,Y)=>X.epochMilliseconds<Y.epochMilliseconds?-1:X.epochMilliseconds>Y.epochMilliseconds?1:0);var yZ=(X)=>{let Y=Object.create(vb);return Y.epochMilliseconds=X,Object.defineProperty(Y,"partsUtc",{value:void 0,enumerable:!1,writable:!0}),Y},n5=(X)=>{let Y=X.getTime();if(Number.isNaN(Y))throw new f7("Invalid date");return yZ(Y)},hZ=(X)=>{if(s5(X))return X;else if(X instanceof Date)return n5(X);else if(typeof X==="object"){if("epochMilliseconds"in X)return yZ(X.epochMilliseconds);let Y=new Date(0);return ub(Y,X),n5(Y)}else if(typeof X==="string"&&!gb(X))return n5(new Date(X+"Z"));return n5(new Date(X))},gb=(X)=>/Z|GMT|[+-]\d{2}$|[+-]\d{2}:?\d{2}$|\]$/.test(X),yb=-8639999956800000,hb=8639999949600000,mZ=(X,Y)=>{let Q=Y?.timeZone;if(Q===void 0&&s5(X)&&gZ(X))return X;let _=hZ(X);if(_.epochMilliseconds<yb||_.epochMilliseconds>hb)throw RangeError(`Epoch millis out of range: ${_.epochMilliseconds}`);if(Q===void 0&&typeof X==="object"&&"timeZoneId"in X)Q=X.timeZoneId;let G;if(Q===void 0){let J=new Date(_.epochMilliseconds).getTimezoneOffset()*-60*1000;G=IY(J)}else if(h4(Q))G=Q;else if(typeof Q==="number")G=IY(Q);else{let J=pZ(Q);if(E0(J))throw new f7(`Invalid time zone: ${Q}`);G=J.value}if(Y?.adjustForTimeZone!==!0)return z6(_.epochMilliseconds,G,_.partsUtc);return cb(_.epochMilliseconds,G,Y?.disambiguation??"compatible")},kZ=E4(mZ),fq=E4(hZ),mb=/^(.{17,35})\[(.+)\]$/,pq=(X)=>{let Y=mb.exec(X);if(Y===null){let G=oZ(X);return G!==null?kZ(X,{timeZone:G}):f()}let[,Q,_]=Y;return kZ(Q,{timeZone:_})};var uq=(X)=>yZ(X.epochMilliseconds);var MY=new Map,db={day:"numeric",month:"numeric",year:"numeric",hour:"numeric",minute:"numeric",second:"numeric",timeZoneName:"longOffset",fractionalSecondDigits:3,hourCycle:"h23"},fb=(X)=>{let Y=X.resolvedOptions().timeZone;if(MY.has(Y))return MY.get(Y);let Q=Object.create(kb);return Q.id=Y,Q.format=X,MY.set(Y,Q),Q},dZ=(X)=>{if(MY.has(X))return MY.get(X);try{return fb(new Intl.DateTimeFormat("en-US",{...db,timeZone:X}))}catch{throw new f7(`Invalid time zone: ${X}`)}},IY=(X)=>{let Y=Object.create(bb);return Y.offset=X,Y},fZ=E4(dZ);var pb=/^(?:GMT|[+-])/,pZ=(X)=>{if(pb.test(X)){let Y=oZ(X);return Y===null?f():T(IY(Y))}return fZ(X)},cq=(X)=>{if(X._tag==="Offset")return cZ(X.offset);return X.id};var jY=(X)=>new Date(X.epochMilliseconds),c7=(X)=>{if(X._tag==="Utc")return new Date(X.epochMilliseconds);else if(X.zone._tag==="Offset")return new Date(X.epochMilliseconds+X.zone.offset);else if(X.adjustedEpochMilliseconds!==void 0)return new Date(X.adjustedEpochMilliseconds);let Y=X.zone.format.formatToParts(X.epochMilliseconds).filter((_)=>_.type!=="literal"),Q=new Date(0);return Q.setUTCFullYear(Number(Y[2].value),Number(Y[0].value)-1,Number(Y[1].value)),Q.setUTCHours(Number(Y[3].value),Number(Y[4].value),Number(Y[5].value),Number(Y[6].value)),X.adjustedEpochMilliseconds=Q.getTime(),Q},uZ=(X)=>{return c7(X).getTime()-lZ(X)},cZ=(X)=>{let Y=Math.abs(X),Q=Math.floor(Y/3600000),_=Math.round(Y%3600000/60000);if(_===60)Q+=1,_=0;return`${X<0?"-":"+"}${String(Q).padStart(2,"0")}:${String(_).padStart(2,"0")}`},lq=(X)=>cZ(uZ(X)),lZ=(X)=>X.epochMilliseconds;var ub=(X,Y)=>{if(Y.year!==void 0)X.setUTCFullYear(Y.year);if(Y.month!==void 0)X.setUTCMonth(Y.month-1);if(Y.day!==void 0)X.setUTCDate(Y.day);if(Y.weekDay!==void 0){let Q=Y.weekDay-X.getUTCDay();X.setUTCDate(X.getUTCDate()+Q)}if(Y.hour!==void 0)X.setUTCHours(Y.hour);if(Y.minute!==void 0)X.setUTCMinutes(Y.minute);if(Y.second!==void 0)X.setUTCSeconds(Y.second);if(Y.millisecond!==void 0)X.setUTCMilliseconds(Y.millisecond)};var xq=86400000,cb=(X,Y,Q)=>{if(Y._tag==="Offset")return z6(X-Y.offset,Y);let _=CY(X-xq,X,Y),G=CY(X+xq,X,Y);if(_===G)return z6(X-_,Y);let J=_<G,Z=_-G;if(J){if(CY(X-G,X,Y)===G)return z6(X-G,Y);let W=z6(X-_,Y),D=c7(W).getTime();if(X!==D)switch(Q){case"reject":{let U=new Date(X).toISOString();throw RangeError(`Gap time: ${U} does not exist in time zone ${Y.id}`)}case"earlier":return z6(X-G,Y);case"compatible":case"later":return W}return W}if(CY(X-_,X,Y)===_){if(Q==="earlier"||Q==="compatible")return z6(X-_,Y);if(CY(X-_+Z,X+Z,Y)===_)return z6(X-_,Y);if(Q==="reject"){let W=new Date(X).toISOString();throw RangeError(`Ambiguous time: ${W} occurs twice in time zone ${Y.id}`)}}return z6(X-G,Y)},lb=/([+-])(\d{2}):(\d{2})$/,oZ=(X)=>{let Y=lb.exec(X);if(Y===null)return null;let[,Q,_,G]=Y;return(Q==="+"?1:-1)*(Number(_)*60+Number(G))*60*1000},CY=(X,Y,Q)=>{let _=Q.format.formatToParts(X).find((J)=>J.type==="timeZoneName")?.value??"";if(_==="GMT")return 0;let G=oZ(_);if(G===null)return uZ(z6(Y,Q));return G};var oq=(X)=>jY(X).toISOString();var bZ=(X)=>{let Y=c7(X);return X._tag==="Utc"?Y.toISOString():`${Y.toISOString().slice(0,-1)}${lq(X)}`},rZ=(X)=>X.zone._tag==="Offset"?bZ(X):`${bZ(X)}[${X.zone.id}]`;var TQ0=globalThis.Number;var iq=V(2,(X,Y)=>{let Q=X.toString(),_=Y.toString();if(Q.includes("e")||_.includes("e")){if(!globalThis.Number.isFinite(X)||!globalThis.Number.isFinite(Y)||Y===0)return NaN;return rb(X,Y)}let G=(Q.split(".")[1]||"").length,J=(_.split(".")[1]||"").length,Z=G>J?G:J,K=parseInt(X.toFixed(Z).replace(".","")),H=parseInt(Y.toFixed(Z).replace(".",""));return K%H/Math.pow(10,Z)});function rb(X,Y){let[Q,_]=rq(X),[G,J]=rq(Y),Z=Math.min(_,J),K=Q*BigInt(10)**BigInt(_-Z),H=G*BigInt(10)**BigInt(J-Z),W=K%H;if(W===BigInt(0))return X<0||Object.is(X,-0)?-0:0;let D=globalThis.Number(`${W}e${Z}`);return D===0?Math.sign(X)*globalThis.Number.MIN_VALUE:D}function rq(X){let Y=Math.abs(X).toExponential(),Q=Y.indexOf("e"),_=Y.slice(0,Q).replace(".","");return[BigInt(_)*(X<0?-BigInt(1):BigInt(1)),globalThis.Number(Y.slice(Q+1))-_.length+1]}var nq=m6((X,Y)=>Math.max(X,Y),-1/0),sq=m6((X,Y)=>Math.min(X,Y),1/0);var RQ0=globalThis.String;var aq=(X)=>X.trim();var iZ=V(2,(X,Y)=>p5(X,ab,(Q)=>Y(Q)));var sb=B$(SZ,(X)=>vZ(X)?m(X):c(X));var ab=B$(SZ,(X)=>vZ(X)?m(X.value):c(X));var tq=V(2,(X,Y)=>N6(X,{onSuccess:Y.onSuccess,onFailure:(Q)=>{let _=sb(Q);return!Q0(_)?Y.onDone(_.success.value):Y.onFailure(_.failure)}}));var Xz="~effect/Schedule";var m4=O0("effect/Schedule/CurrentMetadata",{defaultValue:Z1({input:void 0,output:void 0,duration:v5,attempt:0,start:0,now:0,elapsed:0,elapsedSincePrevious:0})}),tb={[Xz]:{_Out:u,_In:u,_Env:u},pipe(){return G0(this,arguments)}},nZ=(X)=>I(X,Xz),sZ=(X)=>{let Y=Object.create(tb);return Y.step=X,Y},aZ=()=>{let X=0,Y,Q;return(_,G)=>{if(Q===void 0)Q=_;let J=_-Q,Z=Y===void 0?0:_-Y;return Y=_,{input:G,attempt:++X,start:Q,now:_,elapsed:J,elapsedSincePrevious:Z}}},eb=(X)=>sZ(B0(X,(Y)=>{let Q=aZ();return(_,G)=>Y(Q(_,G))})),tZ=(X)=>i1(X.step,(Y)=>M(()=>F0(Y))),l7=(X)=>v4((Y)=>B0(tZ(X),(Q)=>{let _=aZ();return(G)=>a(()=>{let J=Y.currentTimeMillisUnsafe();return v(Q(J,G),([Z,K])=>{let H=_(J,G);return H.output=Z,H.duration=K,g1(x4(K),H)})})}));var eZ=(X)=>sZ(B0(tZ(X),(Y)=>(Q,_)=>tq(Y(Q,_),{onSuccess:(G)=>M([_,G[1]]),onFailure:F0,onDone:()=>xZ(_)}))),Yz=(X)=>SY(X2,({attempt:Y})=>M(Y<=X)),Xg=(X)=>{let Y=GX(X);return eb(M((Q)=>M([Q.attempt-1,Y])))};var SY=V(2,(X,Y)=>sZ(B0(tZ(X),(Q)=>{let _=aZ();return(G,J)=>v(Q(G,J),(Z)=>{let[K,H]=Z,W=Y({..._(G,J),output:K,duration:H});return v(r(W)?W:M(W),(D)=>D?M(Z):xZ(K))})})));var X2=Xg(v5);var Yg=(X,Y,Q)=>E7((_)=>v(Q?.local?wY(Y,r5(),_):IZ(Y,_),(G)=>o6(X,G))),o7=V((X)=>r(X[0]),(X,Y,Q)=>o_(Y)?o6(X,Y):Yg(X,Array.isArray(Y)?b7(...Y):Y,Q));var Y2=V(3,(X,Y,Q)=>v(l7(Y),(_)=>{let G=m4.defaultValue();return h1(V7(V6(v(a(()=>y1(X,m4,G)),_),(J)=>X0(()=>{G=J})),{disableYield:!0}),(J)=>QY(J)?M(J.value):Q(J,G.attempt===0?f():T(G)))})),Q2=V(3,(X,Y,Q)=>v(l7(Y),(_)=>{let G=m4.defaultValue(),J,Z=h1(a(()=>y1(X,m4,G)),(K)=>{return J=K,v(_(K),(H)=>{return G=H,Z})});return iZ(Z,(K)=>H0(()=>Q(J,K)))})),Gz=V(2,(X,Y)=>{let Q=typeof Y==="function"?Y(u):nZ(Y)?Y:xY(Y);return Y2(X,Q,P0)}),vY=V(2,(X,Y)=>{let Q=typeof Y==="function"?Y(u):nZ(Y)?Y:xY(Y);return Q2(X,Q,P0)}),Jz=V(3,(X,Y,Q)=>v(l7(Q),(_)=>{let G=m4.defaultValue(),J=a(()=>y1(X,m4,G));return h1(v(_(Y),(Z)=>{G=Z;let K=Z1(v(J,_));return n6({while:I6,body:K,step(H){G=H}})}),(Z)=>QY(Z)?M(Z.value):P0(Z))})),Qg=eZ(X2),xY=(X)=>{let Y=X.schedule?eZ(X.schedule):Qg;if(X.while)Y=SY(Y,({input:Q})=>{let _=X.while(Q);return r(_)?_:M(_)});if(X.until)Y=SY(Y,({input:Q})=>{let _=X.until(Q);return r(_)?B0(_,(G)=>!G):M(!_)});if(X.times!==void 0)Y=SY(Y,({attempt:Q})=>M(Q<=X.times));return Y};var Kz=V(2,(X,Y)=>a(()=>{let Q=0,_={attempt:0,stepIndex:0},G=B7(Mq,X0(()=>{return _={attempt:_.attempt+1,stepIndex:Q},_})),J;return v(n6({while:()=>Q<Y.steps.length&&(J===void 0||Q0(J)),body(){let Z=Y.steps[Q],K=G(o7(X,Z.provide));if(J){let H=!1,W=K;K=a(()=>{if(H)return W;return H=!0,m5(J)}),K=vY(K,Zz(Z,!1))}else{let H=Zz(Z,!0);K=H?vY(K,H):K}return I8(K)},step(Z){J=Z,Q++}}),()=>m5(J))})),Zz=(X,Y)=>{if(!Y)return xY({schedule:X.schedule?X.schedule:X.attempts?void 0:_g,times:X.attempts,while:X.while});else if(X.attempts===1||!(X.schedule||X.attempts))return;return xY({schedule:X.schedule,while:X.while,times:X.attempts?X.attempts-1:void 0})},_g=Yz(1);var Jg="~effect/Request",$g=PD({_E:(X)=>X,_A:(X)=>X,_R:(X)=>X}),yQ0={...jD,[Jg]:$g};var Hz=(X)=>X;var Uz=V(2,(X,Y)=>{let Q=(_)=>r1((G)=>{let J=Nz(_,X,G,H7());return Zg(_,J)});return r(Y)?v(Y,Q):Q(Y)}),Dz=(X,Y)=>{let Q=Nz(Y.resolver,X,Y.onExit,{context:Y.context,currentScheduler:v1(Y.context,KY)});return()=>Bz(Y.resolver,Q)},r7=[],_2=new WeakMap,Nz=(X,Y,Q,_)=>{let G=_2.get(X);if(!G)G=new Map,_2.set(X,G);let J,Z=!1,K=Hz({request:Y,context:_.context,uninterruptible:!1,completeUnsafe(W){if(Z)return;Z=!0,Q(W),J?.entrySet.delete(K)}});if(X.preCheck!==void 0&&!X.preCheck(K))return K;let H=X.batchKey(K);if(J=G.get(H),!J){if(r7.length>0)J=r7.pop(),J.key=H,J.resolver=X,J.map=G;else{let W={key:H,resolver:X,map:G,entrySet:new Set,entries:new Set,delayEffect:v(a(()=>W.resolver.delay),(D)=>Wz(W)),run:m1(a(()=>W.resolver.runAll(Array.from(W.entries),W.key)),(D)=>{for(let U of W.entrySet)U.completeUnsafe(D._tag==="Success"?$6(Error("Effect.request: RequestResolver did not complete request",{cause:U.request})):D);if(W.entries.clear(),r7.length<128)W.entrySet.clear(),W.key=void 0,W.fiber=void 0,W.resolver=void 0,W.map=void 0,r7.push(W);return _0})};J=W}G.set(H,J),J.fiber=s6(_.context)(J.delayEffect,{scheduler:_.currentScheduler})}if(J.entrySet.add(K),J.entries.add(K),J.resolver.collectWhile(J.entries))return K;return J.fiber.interruptUnsafe(_.id),J.fiber=s6(_.context)(Wz(J),{scheduler:_.currentScheduler}),K},Bz=(X,Y)=>{if(Y.uninterruptible)return;let Q=_2.get(X);if(!Q)return;let _=X.batchKey(Y),G=Q.get(_);if(!G)return;if(G.entries.delete(Y),G.entrySet.delete(Y),G.entries.size===0)Q.delete(_),G.fiber?.interruptUnsafe()},Zg=(X,Y)=>X0(()=>Bz(X,Y));function Wz(X){if(!X.map.has(X.key))return _0;return X.map.delete(X.key),X.run}var Ug="effect/Metric/CurrentMetricAttributes",Dg=O0(Ug,{defaultValue:()=>({})}),Ng="~effect/observability/Metric/MetricRegistryKey",Bg=O0(Ng,{defaultValue:()=>new Map}),Vz="~effect/observability/Metric";class a5{[Vz]=Vz;#X=new WeakMap;#Y;id;description;attributes;constructor(X,Y,Q){this.id=X,this.description=Y,this.attributes=Q}valueUnsafe(X){return this.hook(X).get(X)}modifyUnsafe(X,Y){return this.hook(Y).modify(X,Y)}updateUnsafe(X,Y){return this.hook(Y).update(X,Y)}hook(X){let Y=v1(X,Dg);if(Object.keys(Y).length===0){if(N1(this.#Y))return this.#Y.hooks;return this.#Y=this.getOrCreate(X,this.attributes),this.#Y.hooks}let Q=Eg(this.attributes,Y),_=this.#X.get(Q);if(N1(_))return _.hooks;return _=this.getOrCreate(X,Q),this.#X.set(Q,_),_.hooks}getOrCreate(X,Y){let Q=Tg(this,Y),_=v1(X,Bg);if(_.has(Q))return _.get(Q);let G=this.createHooks(),J={id:this.id,type:this.type,description:this.description,attributes:k8(Y),hooks:G};return _.set(Q,J),J}pipe(){return G0(this,arguments)}}var qz=BigInt(0);class Vg extends a5{type="Counter";#X;#Y;constructor(X,Y){super(X,Y?.description,k8(Y?.attributes));this.#X=Y?.bigint??!1,this.#Y=Y?.incremental??!1}createHooks(){let X=this.#X?qz:0,Y=this.#Y?this.#X?(_)=>_>=qz:(_)=>_>=0:(_)=>!0;return kY(()=>({count:X,incremental:this.#Y}),(_)=>{if(Y(_))X=X+_})}}class qg extends a5{type="Gauge";#X;constructor(X,Y){super(X,Y?.description,k8(Y?.attributes));this.#X=Y?.bigint??!1}createHooks(){let X=this.#X?BigInt(0):0;return kY(()=>({value:X}),(_)=>{X=_},(_)=>{X=X+_})}}class zg extends a5{type="Frequency";#X;constructor(X,Y){super(X,Y?.description,k8(Y?.attributes));this.#X=Y?.preregisteredWords}createHooks(){let X=new Map;if(N1(this.#X))for(let Q of this.#X)X.set(Q,0);return kY(()=>({occurrences:X}),(Q)=>{let _=X.get(Q)??0;X.set(Q,_+1)})}}class Og extends a5{type="Histogram";#X;constructor(X,Y){super(X,Y?.description,k8(Y?.attributes));this.#X=Y.boundaries}createHooks(){let X=this.#X,Y=X.length,Q=new Uint32Array(Y+1),_=new Float64Array(Y),G=0,J=0,Z=Number.MAX_VALUE,K=-Number.MAX_VALUE;U6(ZY(X,q1),(D,U)=>{_[U]=D});let H=(D)=>{let U=0,N=Y;while(U!==N){let B=Math.floor(U+(N-U)/2),q=_[B];if(D<=q)N=B;else U=B;if(N===U+1)if(D<=_[U])N=U;else U=N}if(Q[U]=Q[U]+1,G=G+1,J=J+D,D<Z)Z=D;if(D>K)K=D},W=()=>{let D=W$(Y),U=0;for(let N=0;N<Y;N++){let B=_[N],q=Q[N];U=U+q,D[N]=[B,U]}return D};return kY(()=>({buckets:W(),count:G,min:Z,max:K,sum:J}),H)}}class Lg extends a5{type="Summary";#X;#Y;#Q;constructor(X,Y){super(X,Y?.description,k8(Y?.attributes));this.#X=Math.max(A8(GX(Y.maxAge)),0),this.#Y=Y.maxSize,this.#Q=Y.quantiles}createHooks(){let X=ZY(this.#Q,q1),Y=W$(this.#Y);for(let U of this.#Q)if(U<0||U>1)throw Error(`Quantile must be between 0 and 1, found: ${U}`);let Q=0,_=0,G=0,J=Number.MAX_VALUE,Z=-Number.MAX_VALUE,K=(U)=>{let N=[],B=0;while(B<this.#Y){let R=Y[B];if(N1(R)){let[F,P]=R,C=U-F;if(C>=0&&C<=this.#X)N.push(P)}B=B+1}let q=ZY(N,q1),O=q.length;if(O===0)return X.map((R)=>[R,void 0]);return X.map((R)=>{if(R<=0)return[R,q[0]];if(R>=1)return[R,q[O-1]];let F=Math.ceil(R*O)-1;return[R,q[F]]})},H=(U,N)=>{if(this.#Y>0){let B=Q%this.#Y;Y[B]=[N,U],Q=Q+1}if(_=_+1,G=G+U,U<J)J=U;if(U>Z)Z=U};return kY((U)=>{let N=v1(U,q6);return{quantiles:K(N.currentTimeMillisUnsafe()),count:_,min:J,max:Z,sum:G}},([U,N])=>H(U,N))}}var t5=V(2,(X,Y)=>j8((Q)=>X0(()=>X.updateUnsafe(Y,Q))));function Tg(X,Y){let Q=`${X.type}:${X.id}`;if(N1(X.description))Q+=`:${X.description}`;if(N1(Y))Q+=`:${Rg(Y)}`;return Q}function kY(X,Y,Q){return{get:X,update:Y,modify:Q??Y}}function Rg(X){return Fg(Array.isArray(X)?X:Object.entries(X))}function Fg(X){return X.map(([Y,Q])=>`${Y}=${Q}`).join(",")}function Eg(X,Y){return{...k8(X),...k8(Y)}}function k8(X){if(N1(X)&&Array.isArray(X))return X.reduce((Y,[Q,_])=>{return k(Y,Q,_),Y},{});return X}var Pg=G6,d4=r,wg=FY,Cg=WZ,Mg=UV,Ig=DV,jg=NV,Sg=VV,vg=$X,Oz=n6,xg=m$,G2=tN,p=M,mX=NY,gY=h$,Lz=a,Tz=X0,yY=_0;var kg=FZ;var J2=r1,bg=BY,gg=FV,yg=EV,hg=PV;var mg=AV,dg=QB,d=P0,fg=U7,pg=F0,f4=sN,Rz=c6,e5=aN;var ug=d5,cg=y$,Fz=s,$2=m5,lg=rN,og=nN,rg=iN,hY=v,ig=WB,ng=yX,Ez=V6,sg=I8,ag=uB,mY=OY,Z2=B0,tg=g1,eg=D7,Xy=VY,Yy=JB,Qy=PB,_y=r$,Gy=h1;var Jy=O7,$y=bB,Zy=gB,Ky=yB,Hy=hB,p4=i1,Wy=jB,Uy=qY,Dy=z7,Ny=IB,By=n$,Vy=p5,qy=a$,zy=t$,Oy=L7,Az=s$,Ly=xB,Pz=SB,Ty=vB,Ry=q7,wz=kB,Fy=e$,Ey=vY,Ay=Q2,Py=$B,wy=fB,Cy=pB,My=Kz,Iy=_q,jy=mB,Sy=dB,vy=iB,xy=nB,ky=YZ,by=rB,gy=x4,yy=sB,hy=u$,my=c$,dy=ZB,fy=N7,py=LV,uy=TV,cy=RV,ly=UZ,oy=DZ,ry=wB,iy=OV,ny=CB,K2=T7,sy=zY,ay=XZ,ty=cB,ey=KB,Xh=N6,Yh=j4,Qh=lB,_h=oB,Gh=o$,Jh=j8,$h=o7,Zh=o6,Kh=AB,Hh=RB,Wh=FB,Uh=f5,Dh=l6,Nh=EB,Cz=y1,Bh=B7,Vh=TY,qh=F7,zh=E7,Oh=A7,Lh=GV,Th=_V,Rh=u5,Fh=XV,Eh=JZ,Ah=YV,Ph=$Z,wh=c5,H2=m1,Ch=_Z,Mh=GZ,Ih=JV,jh=KZ,Sh=ZZ,Mz=$V,vh=HZ,xh=QV,kh=i6,Iz=RY,bh=HV,gh=WV,yh=V7,hh=Gz,mh=Y2,dh=i$,fh=MB,ph=V(2,(X,Y)=>jz(X,void 0,Y)),jz=Jz,uh=yV,ch=hV,lh=mV,oh=dV,rh=iV,ih=nV,nh=sV,sh=aV,ah=cV,th=lV,eh=oV,Xm=pV,Ym=gX,Qm=DY,_m=rV,Gm=uV,Jm=h5,$m=Uz,Zm=Dz,Km=wV,Hm=NZ,Wm=IV,Um=CV,Dm=MV,Nm=XB,Bm=YB,W2=jV,Vm=s6,qm=BZ,zm=SV,Om=xV,Lm=VZ,i7=vV,Tm=w7,Rm=bV,Fm=qZ,b8=kV,Em=C7,Am=f$,Pm=_B,Sz=v4,wm=hX,Cm=hX(),Mm=hX("Fatal"),Im=hX("Warn"),jm=hX("Error"),Sm=hX("Info"),vm=hX("Debug"),xm=hX("Trace"),km=V(2,(X,Y)=>l6(X,RZ,(Q)=>new Set([...Q,Y]))),bm=V((X)=>d4(X[0]),(X,...Y)=>l6(X,Wq,(Q)=>{let _=Y.length===1?{...Q,...Y[0]}:{...Q};if(Y.length===1)return _;else k(_,Y[0],Y[1]);return _})),gm=Yq,ym=V(2,(X,Y)=>v(eV,(Q)=>l6(X,Uq,(_)=>{return[[Y,Q],..._]}))),hm=V((X)=>d4(X[0]),(X,Y,Q)=>H2(X,(_)=>{let G=Q===void 0?_:H0(()=>Q(_));return t5(Y,G)})),mm=V((X)=>d4(X[0]),(X,Y,Q)=>Ez(X,(_)=>{let G=Q===void 0?_:Q(_);return t5(Y,G)})),dm=V((X)=>d4(X[0]),(X,Y,Q)=>Az(X,(_)=>{let G=Q===void 0?_:H0(()=>Q(_));return t5(Y,G)})),fm=V((X)=>d4(X[0]),(X,Y,Q)=>wz(X,(_)=>{let G=Q===void 0?_:H0(()=>Q(_));return t5(Y,G)})),pm=V((X)=>d4(X[0]),(X,Y,Q)=>Sz((_)=>{let G=_.currentTimeNanosUnsafe();return H2(X,()=>{let J=_.currentTimeNanosUnsafe(),Z=KN(GX(J),GX(G)),K=Q===void 0?Z:H0(()=>Q(Z));return t5(Y,K)})}));class bY extends bX()("effect/Effect/Transaction"){}var um=(X)=>Fz((Y)=>{if(Y.context.mapUnsafe.has(bY.key))return X;let Q={journal:new Map,retry:!1},_;return Iz((G)=>hY(Oz({while:()=>!_,body:Z1(G(X).pipe(Cz(bY,Q),Pz(()=>{if(!Q.retry)return yY;return G(lm(Q))}),mY)),step(J){if(Q.retry||!cm(Q))return zz(Q);if(w1(J))om(Y,Q);else zz(Q);_=J}}),()=>_))}),cm=(X)=>{for(let[Y,{version:Q}]of X.journal)if(Y.version!==Q)return!1;return!0},lm=(X)=>Lz(()=>{let Y={},Q=Array.from(X.journal.keys()),_=()=>{for(let G of Q)G.pending.delete(Y)};return J2((G)=>{let J=()=>{_(),G(yY)};for(let Z of Q)Z.pending.set(Y,J);return Tz(_)})});function om(X,Y){for(let[Q,{value:_}]of Y.journal){if(_!==Q.value)Q.version=Q.version+1,Q.value=_;for(let G of Q.pending.values())X.currentDispatcher.scheduleTask(G,0);Q.pending.clear()}}function zz(X){X.retry=!1,X.journal.clear()}var rm=hY(bY,(X)=>{return X.retry=!0,Mz}),im=(X,Y,Q)=>(..._)=>J2((G)=>{try{X(..._,(J,Z)=>{if(J)G(d(Y?Y(J,_):J));else G(p(Z))})}catch(J){G(Q?d(Q(J,_)):Rz(J))}}),nm=()=>(X)=>X,sm=()=>(X)=>X,am=()=>(X)=>X,u4=UB,X9=DB,U1=NB,EX=HB,n7=BB,dY=GB;var iY={};M6(iY,{values:()=>QO,union:()=>Ld,toValues:()=>Dd,toEntries:()=>rY,some:()=>Sd,size:()=>R2,setMany:()=>Fd,set:()=>Wd,removeMany:()=>Rd,remove:()=>Td,reduce:()=>wd,mutate:()=>Vd,modifyHash:()=>zd,modifyAt:()=>qd,modify:()=>Od,map:()=>Ed,make:()=>Qd,keys:()=>Ud,isHashMap:()=>T2,isEmpty:()=>_d,hasHash:()=>Kd,hasBy:()=>Hd,has:()=>Zd,getUnsafe:()=>$d,getHash:()=>Jd,get:()=>Gd,fromIterable:()=>oY,forEach:()=>Pd,flatMap:()=>Ad,findFirst:()=>jd,filterMap:()=>Id,filter:()=>Cd,every:()=>vd,entries:()=>_O,endMutation:()=>Bd,empty:()=>Yd,compact:()=>Md,beginMutation:()=>Nd});var a7="~effect/collections/HashMap",dX=5,cY=1<<dX,tm=cY/4,vz=cY/2,em=cY-1,Xd=(X)=>{return X=X-(X>>>1&1431655765),X=(X&858993459)+(X>>>2&858993459),(X+(X>>>4)&252645135)*16843009>>>24},fY=(X,Y)=>X>>>Y&em,g8=(X,Y)=>1<<fY(X,Y),s7=(X,Y)=>Xd(X&Y-1);function xz(X,Y,Q,_,G,J){if(Y>32)throw Error("HashMap: max depth exceeded");let Z=g8(Q,Y),K=g8(G,Y);if(Z===K){let D=xz(X,Y+dX,Q,_,G,J);return new O6(X,Z,[D])}let H=Z|K,W=Z>>>0<K>>>0?[_,J]:[J,_];return new O6(X,H,W)}class Y9{canEdit(X){return this.edit===X}}class kz extends Y9{_tag="EmptyNode";edit=0;get size(){return 0}get(X,Y,Q){return f()}has(X,Y,Q){return!1}set(X,Y,Q,_,G,J){return J.value=!0,new t6(X,Q,_,G)}remove(X,Y,Q,_,G){return this}iterator(){return[][Symbol.iterator]()}[Symbol.iterator](){return this.iterator()}canEdit(X){return!1}}class t6 extends Y9{_tag="LeafNode";edit;hash;key;value;constructor(X,Y,Q,_){super();this.edit=X,this.hash=Y,this.key=Q,this.value=_}get size(){return 1}get(X,Y,Q){if(this.hash===Y&&o(this.key,Q))return T(this.value);return f()}has(X,Y,Q){return this.hash===Y&&o(this.key,Q)}set(X,Y,Q,_,G,J){if(this.hash===Q&&o(this.key,_)){if(o(this.value,G))return this;if(this.canEdit(X))return this.value=G,this;return new t6(X,Q,_,G)}if(J.value=!0,this.hash===Q)return new pY(X,Q,[[this.key,this.value],[_,G]]);let Z=g8(Q,Y),K=g8(this.hash,Y);if(Z===K)return new O6(X,Z,[this.set(X,Y+dX,Q,_,G,J)]);let H=Z|K,W=Z>>>0<K>>>0?[new t6(X,Q,_,G),this]:[this,new t6(X,Q,_,G)];return new O6(X,H,W)}remove(X,Y,Q,_,G){if(this.hash===Q&&o(this.key,_)){G.value=!0;return}return this}iterator(){return[[this.key,this.value]][Symbol.iterator]()}[Symbol.iterator](){return this.iterator()}}class pY extends Y9{_tag="CollisionNode";edit;hash;entries;constructor(X,Y,Q){super();this.edit=X,this.hash=Y,this.entries=Q}get size(){return this.entries.length}get(X,Y,Q){if(this.hash!==Y)return f();for(let[_,G]of this.entries)if(o(_,Q))return T(G);return f()}has(X,Y,Q){if(this.hash!==Y)return!1;for(let[_]of this.entries)if(o(_,Q))return!0;return!1}set(X,Y,Q,_,G,J){if(this.hash!==Q)return J.value=!0,xz(X,Y,this.hash,this,Q,new t6(X,Q,_,G));for(let Z=0;Z<this.entries.length;Z++)if(o(this.entries[Z][0],_)){if(o(this.entries[Z][1],G))return this;if(this.canEdit(X))return this.entries[Z]=[_,G],this;let K=[...this.entries];return K[Z]=[_,G],new pY(X,this.hash,K)}if(J.value=!0,this.canEdit(X))return this.entries.push([_,G]),this;return new pY(X,this.hash,[...this.entries,[_,G]])}remove(X,Y,Q,_,G){if(this.hash!==Q)return this;let J=this.entries.findIndex(([K])=>o(K,_));if(J===-1)return this;if(G.value=!0,this.entries.length===1)return;if(this.entries.length===2){let K=this.entries[J===0?1:0];return new t6(X,this.hash,K[0],K[1])}if(this.canEdit(X))return this.entries.splice(J,1),this;let Z=[...this.entries];return Z.splice(J,1),new pY(X,this.hash,Z)}iterator(){return this.entries[Symbol.iterator]()}[Symbol.iterator](){return this.iterator()}}class O6 extends Y9{_tag="IndexedNode";edit;_size;bitmap;children;constructor(X,Y,Q){super();this.edit=X,this.bitmap=Y,this.children=Q}get size(){if(this._size===void 0)this._size=this.children.reduce((X,Y)=>X+Y.size,0);return this._size}get(X,Y,Q){let _=g8(Y,X);if((this.bitmap&_)===0)return f();let G=s7(this.bitmap,_);return this.children[G].get(X+dX,Y,Q)}has(X,Y,Q){let _=g8(Y,X);if((this.bitmap&_)===0)return!1;let G=s7(this.bitmap,_);return this.children[G].has(X+dX,Y,Q)}set(X,Y,Q,_,G,J){let Z=g8(Q,Y),K=s7(this.bitmap,Z);if((this.bitmap&Z)!==0){let H=this.children[K],W=H.set(X,Y+dX,Q,_,G,J);if(H===W)return this;if(this.canEdit(X))return this.children[K]=W,this;let D=[...this.children];return D[K]=W,new O6(X,this.bitmap,D)}else{J.value=!0;let H=new t6(X,Q,_,G),W=this.bitmap|Z;if(this.canEdit(X)){if(this.children.splice(K,0,H),this.bitmap=W,this._size=void 0,this.children.length>vz)return this.expand(X,W,this.children);return this}let D=[...this.children];if(D.splice(K,0,H),D.length>vz)return this.expand(X,W,D);return new O6(X,W,D)}}remove(X,Y,Q,_,G){let J=g8(Q,Y);if((this.bitmap&J)===0)return this;let Z=s7(this.bitmap,J),K=this.children[Z],H=K.remove(X,Y+dX,Q,_,G);if(!G.value)return this;if(H===void 0){let D=this.bitmap^J;if(D===0)return;if(this.children.length===2){let N=this.children[Z===0?1:0];if(N._tag==="LeafNode")return N}if(this.canEdit(X))return this.children.splice(Z,1),this.bitmap=D,this._size=void 0,this;let U=[...this.children];return U.splice(Z,1),new O6(X,D,U)}if(K===H)return this;if(this.canEdit(X))return this.children[Z]=H,this;let W=[...this.children];return W[Z]=H,new O6(X,this.bitmap,W)}expand(X,Y,Q){let _=new globalThis.Array(cY),G=0;for(let J=0;J<cY;J++)if((Y&1<<J)!==0)_[J]=Q[G++];return new uY(X,Q.length,_)}iterator(){let X=0,Y;return{next:()=>{while(X<this.children.length){if(!Y)Y=this.children[X].iterator();let Q=Y.next();if(!Q.done)return Q;Y=void 0,X++}return{done:!0,value:void 0}}}}[Symbol.iterator](){return this.iterator()}}class uY extends Y9{_tag="ArrayNode";edit;_size;count;children;constructor(X,Y,Q){super();this.edit=X,this.count=Y,this.children=Q}get size(){if(this._size===void 0)this._size=this.children.reduce((X,Y)=>X+(Y?.size??0),0);return this._size}get(X,Y,Q){let _=fY(Y,X),G=this.children[_];return G?G.get(X+dX,Y,Q):f()}has(X,Y,Q){let _=fY(Y,X),G=this.children[_];return G?G.has(X+dX,Y,Q):!1}set(X,Y,Q,_,G,J){let Z=fY(Q,Y),K=this.children[Z];if(K){let H=K.set(X,Y+dX,Q,_,G,J);if(K===H)return this;if(this.canEdit(X))return this.children[Z]=H,this;let W=[...this.children];return W[Z]=H,new uY(X,this.count,W)}else{J.value=!0;let H=new t6(X,Q,_,G);if(this.canEdit(X))return this.children[Z]=H,this.count++,this._size=void 0,this;let W=[...this.children];return W[Z]=H,new uY(X,this.count+1,W)}}remove(X,Y,Q,_,G){let J=fY(Q,Y),Z=this.children[J];if(!Z)return this;let K=Z.remove(X,Y+dX,Q,_,G);if(!G.value)return this;let H=this.count-(K?0:1);if(H<tm)return this.pack(X,J,K);if(Z===K)return this;if(this.canEdit(X)){if(this.children[J]=K,!K)this.count=H;return this._size=void 0,this}let W=[...this.children];return W[J]=K,new uY(X,H,W)}pack(X,Y,Q){let _=[],G=0,J=1;for(let Z=0;Z<this.children.length;Z++){let K=Z===Y?Q:this.children[Z];if(K)_.push(K),G|=J;J<<=1}return new O6(X,G,_)}iterator(){let X=0,Y;return{next:()=>{while(X<this.children.length){let Q=this.children[X];if(!Q){X++;continue}if(!Y)Y=Q.iterator();let _=Y.next();if(!_.done)return _;Y=void 0,X++}return{done:!0,value:void 0}}}}[Symbol.iterator](){return this.iterator()}}class Q9{[a7]=a7;_editable;_edit;_root;_size;constructor(X,Y,Q,_){this._editable=X,this._edit=Y,this._root=Q,this._size=_}get size(){return this._size}[Symbol.iterator](){return this._root.iterator()}[D0](X){if(D2(X)){let Y=X;if(this.size!==Y.size)return!1;for(let[Q,_]of this){let G=MJ(X,lY(Q));if(E0(G)||!o(_,G.value))return!1}return!0}return!1}[U0](){let X=S0("HashMap");for(let[Y,Q]of this)X=X^e(Y)+e(Q);return X}[K1](){return R1(this)}toString(){return`HashMap(${A(Array.from(this))})`}toJSON(){return{_id:"HashMap",values:Array.from(this).map(([X,Y])=>[R1(X),R1(Y)])}}pipe(){return G0(this,arguments)}}var U2=new kz,D2=(X)=>I(X,a7),s1=()=>new Q9(!1,0,U2,0),bz=(...X)=>N2(X),N2=(X)=>{let Y=U2,Q=0,_={value:!1};for(let[G,J]of X){let Z=e(G);if(_.value=!1,Y=Y.set(NaN,0,Z,G,J,_),_.value)Q++}return new Q9(!1,0,Y,Q)},t7=(X)=>X.size===0,lY=V(2,(X,Y)=>{return X._root.get(0,e(Y),Y)}),B2=V(3,(X,Y,Q)=>{return X._root.get(0,Q,Y)}),gz=V(2,(X,Y)=>{let Q=lY(X,Y);if(W1(Q))return Q.value;throw Error(`HashMap.getUnsafe: key not found: ${Y}`)}),c4=V(2,(X,Y)=>{return X._root.has(0,e(Y),Y)}),V2=V(3,(X,Y,Q)=>{return X._root.has(0,Q,Y)}),yz=V(2,(X,Y)=>{for(let[Q,_]of X)if(Y(_,Q))return!0;return!1}),z1=V(3,(X,Y,Q)=>{let _=X,G=e(Y),J={value:!1},Z=_._editable?_._edit:NaN,K=_._root.set(Z,0,G,Y,Q,J);if(_._editable){if(_._root=K,J.value)_._size++;return X}if(_._root===K)return X;return new Q9(!1,_._edit,K,_._size+(J.value?1:0))}),e7=(X)=>{let Y=X[Symbol.iterator]();return{[Symbol.iterator](){return this},next(){let Q=Y.next();if(Q.done)return{done:!0,value:void 0};return{done:!1,value:Q.value[0]}}}},hz=(X)=>{let Y=X[Symbol.iterator]();return{[Symbol.iterator](){return this},next(){let Q=Y.next();if(Q.done)return{done:!0,value:void 0};return{done:!1,value:Q.value[1]}}}},mz=(X)=>{let Y=X[Symbol.iterator]();return{[Symbol.iterator](){return this},next(){return Y.next()}}},X3=(X)=>X.size,q2=(X)=>{let Y=X;return new Q9(!0,Y._edit+1,Y._root,Y._size)},z2=(X)=>{let Y=X;return Y._editable=!1,X},dz=V(2,(X,Y)=>{let Q=q2(X);return Y(Q),z2(Q)}),O2=V(3,(X,Y,Q)=>{let _=lY(X,Y),G=Q(_);if(E0(G))return c4(X,Y)?l4(X,Y):X;return z1(X,Y,G.value)}),fz=V(4,(X,Y,Q,_)=>{let G=B2(X,Y,Q),J=_(G);if(E0(J))return V2(X,Y,Q)?l4(X,Y):X;return z1(X,Y,J.value)}),pz=V(3,(X,Y,Q)=>{return O2(X,Y,f6(Q))}),L2=V(2,(X,Y)=>{let Q=X;for(let[_,G]of Y)Q=z1(Q,_,G);return Q}),l4=V(2,(X,Y)=>{let Q=X,_=e(Y),G={value:!1},J=Q._editable?Q._edit:NaN,Z=Q._root.remove(J,0,_,Y,G);if(!G.value)return X;if(Q._editable)return Q._root=Z??U2,Q._size--,X;if(Z===void 0)return s1();return new Q9(!1,Q._edit,Z,Q._size-1)}),uz=V(2,(X,Y)=>{let Q=X;for(let _ of Y)Q=l4(Q,_);return Q}),cz=V(2,(X,Y)=>{let Q=X;for(let[_,G]of Y)Q=z1(Q,_,G);return Q}),lz=V(2,(X,Y)=>{let Q=s1();for(let[_,G]of X)Q=z1(Q,_,Y(G,_));return Q}),oz=V(2,(X,Y)=>{let Q=s1();for(let[_,G]of X)Q=L2(Q,Y(G,_));return Q}),rz=V(2,(X,Y)=>{for(let[Q,_]of X)Y(_,Q)}),iz=V(3,(X,Y,Q)=>{let _=Y;for(let[G,J]of X)_=Q(_,J,G);return _}),nz=V(2,(X,Y)=>{let Q=s1();for(let[_,G]of X)if(Y(G,_))Q=z1(Q,_,G);return Q}),sz=(X)=>{let Y=s1();for(let[Q,_]of X)if(W1(_))Y=z1(Y,Q,_.value);return Y},az=V(2,(X,Y)=>{let Q=s1();for(let[_,G]of X){let J=Y(G,_);if(t0(J))Q=z1(Q,_,J.success)}return Q}),tz=V(2,(X,Y)=>{for(let[Q,_]of X)if(Y(_,Q))return T([Q,_]);return f()}),ez=V(2,(X,Y)=>{for(let[Q,_]of X)if(Y(_,Q))return!0;return!1}),XO=V(2,(X,Y)=>{for(let[Q,_]of X)if(!Y(_,Q))return!1;return!0});var T2=D2,Yd=s1,Qd=bz,oY=N2,_d=t7,Gd=lY,Jd=B2,$d=gz,Zd=c4,Kd=V2,Hd=yz,Wd=z1,Ud=e7,QO=hz,Dd=(X)=>Array.from(QO(X)),_O=mz,rY=(X)=>Array.from(_O(X)),R2=X3,Nd=q2,Bd=z2,Vd=dz,qd=O2,zd=fz,Od=pz,Ld=L2,Td=l4,Rd=uz,Fd=cz,Ed=lz,Ad=oz,Pd=rz,wd=iz,Cd=nz,Md=sz,Id=az,jd=tz,Sd=ez,vd=XO;var KX={};M6(KX,{union:()=>fd,some:()=>rd,size:()=>w2,remove:()=>md,reduce:()=>nd,map:()=>ld,make:()=>gd,isSubset:()=>cd,isHashSet:()=>P2,isEmpty:()=>dd,intersection:()=>pd,has:()=>hd,fromIterable:()=>sY,filter:()=>od,every:()=>id,empty:()=>bd,difference:()=>ud,add:()=>yd});var nY="~effect/collections/HashSet",xd={[U0](){return e(nY)},[D0](X){return F2(X)&&Y3(this)===Y3(X)&&A2(this,(Y)=>_9(X,Y))},[Symbol.iterator](){return e7(o4(this))},toString(){return`HashSet(${A(Array.from(this))})`},toJSON(){return{_id:"HashSet",values:R1(Array.from(this))}},[K1](){return this.toJSON()},pipe(){return G0(this,arguments)}},y8=(X)=>{let Y=Object.create(xd);return Y[nY]=nY,Y.keyMap=X,Y},F2=(X)=>I(X,nY),o4=(X)=>X.keyMap,GO=()=>y8(s1()),JO=(...X)=>E2(X),E2=(X)=>{let Y=s1();for(let Q of X)Y=z1(Y,Q,!0);return y8(Y)},_9=(X,Y)=>c4(o4(X),Y),$O=(X,Y)=>{let Q=o4(X);return c4(Q,Y)?X:y8(z1(Q,Y,!0))},ZO=(X,Y)=>{let Q=o4(X);return c4(Q,Y)?y8(l4(Q,Y)):X},Y3=(X)=>X3(o4(X)),KO=(X)=>t7(o4(X)),HO=(X,Y)=>{let Q=s1();for(let _ of X)if(Y(_))Q=z1(Q,_,!0);return y8(Q)},WO=(X,Y)=>{let _=o4(X);for(let G of Y)_=z1(_,G,!0);return y8(_)},UO=(X,Y)=>{let Q=s1();for(let _ of X)if(_9(Y,_))Q=z1(Q,_,!0);return y8(Q)},DO=(X,Y)=>HO(X,(Q)=>!_9(Y,Q)),NO=(X,Y)=>{for(let Q of X)if(!_9(Y,Q))return!1;return!0},BO=(X,Y)=>{let Q=s1();for(let _ of X)Q=z1(Q,Y(_),!0);return y8(Q)},VO=(X,Y)=>HO(X,Y),qO=(X,Y)=>{for(let Q of X)if(Y(Q))return!0;return!1},A2=(X,Y)=>{for(let Q of X)if(!Y(Q))return!1;return!0},zO=(X,Y,Q)=>{let _=Y;for(let G of X)_=Q(_,G);return _};var bd=GO,gd=JO,sY=E2,P2=F2,yd=V(2,$O),hd=V(2,_9),md=V(2,ZO),w2=Y3,dd=KO,fd=V(2,WO),pd=V(2,UO),ud=V(2,DO),cd=V(2,NO),ld=V(2,BO),od=V(2,VO),rd=V(2,qO),id=V(2,A2),nd=V(3,zO);var $={};M6($,{withDecodingDefaultTypeKey:()=>Ge,withDecodingDefaultType:()=>Je,withDecodingDefaultKey:()=>bW,withDecodingDefault:()=>YC,withConstructorDefault:()=>XC,toType:()=>p1,toTaggedUnion:()=>QC,toStandardSchemaV1:()=>Dt,toStandardJSONSchemaV1:()=>Nt,toRepresentation:()=>v10,toJsonSchemaDocument:()=>EM,toIsoSource:()=>_X0,toIsoFocus:()=>GX0,toIso:()=>QX0,toFormatter:()=>I10,toEquivalence:()=>S10,toEncoderXml:()=>h10,toEncoded:()=>k9,toDifferJsonPatch:()=>$X0,toCodecStringTree:()=>IM,toCodecJsonAST:()=>oG,toCodecJson:()=>AM,toCodecIso:()=>CM,toCodecArrayFromSingle:()=>y10,toArbitraryLazy:()=>FM,toArbitrary:()=>C10,tagDefaultOmit:()=>$e,tag:()=>W5,suspend:()=>nw,revealCodec:()=>Ut,revealBottom:()=>Zt,resolveAnnotationsKey:()=>DX0,resolveAnnotations:()=>UX0,requiredKey:()=>Mt,required:()=>It,refine:()=>tt,redact:()=>uW,readonlyKey:()=>St,overrideToFormatter:()=>M10,overrideToEquivalence:()=>j10,overrideToCodecIso:()=>JX0,optionalKey:()=>_4,optional:()=>IX,mutableKey:()=>jt,mutable:()=>st,middlewareEncoding:()=>aw,middlewareDecoding:()=>vW,makeIsMultipleOf:()=>OC,makeIsLessThanOrEqualTo:()=>rQ,makeIsLessThan:()=>oQ,makeIsGreaterThanOrEqualTo:()=>lQ,makeIsGreaterThan:()=>cQ,makeIsBetween:()=>iQ,makeFilterGroup:()=>He,makeFilter:()=>C0,make:()=>x,link:()=>I0,isUppercasedReviver:()=>Pe,isUppercased:()=>NC,isUniqueReviver:()=>X00,isUnique:()=>fW,isUncapitalizedReviver:()=>Me,isUncapitalized:()=>qC,isUint32:()=>he,isUUIDReviver:()=>ze,isUUID:()=>$C,isULIDReviver:()=>Le,isULID:()=>KC,isTrimmedReviver:()=>We,isTrimmed:()=>gW,isStringSymbolReviver:()=>Ve,isStringSymbol:()=>JC,isStringFiniteReviver:()=>Ne,isStringFinite:()=>_C,isStringBigIntReviver:()=>Be,isStringBigInt:()=>GC,isStartsWithReviver:()=>Fe,isStartsWith:()=>WC,isSizeBetweenReviver:()=>ne,isSizeBetween:()=>yC,isSchemaError:()=>mK,isSchema:()=>mG,isPropertyNamesReviver:()=>ee,isPropertyNames:()=>fC,isPropertiesLengthBetweenReviver:()=>te,isPropertiesLengthBetween:()=>dC,isPatternReviver:()=>De,isPattern:()=>U5,isNonEmpty:()=>xC,isMultipleOfReviver:()=>be,isMultipleOf:()=>FC,isMinSizeReviver:()=>re,isMinSize:()=>bC,isMinPropertiesReviver:()=>se,isMinProperties:()=>hC,isMinLengthReviver:()=>ce,isMinLength:()=>mW,isMaxSizeReviver:()=>ie,isMaxSize:()=>gC,isMaxPropertiesReviver:()=>ae,isMaxProperties:()=>mC,isMaxLengthReviver:()=>le,isMaxLength:()=>kC,isLowercasedReviver:()=>we,isLowercased:()=>BC,isLessThanReviver:()=>ve,isLessThanOrEqualToReviver:()=>xe,isLessThanOrEqualToDateReviver:()=>n10,isLessThanOrEqualToDate:()=>wC,isLessThanOrEqualToBigIntReviver:()=>XX0,isLessThanOrEqualToBigInt:()=>SC,isLessThanOrEqualToBigDecimal:()=>pe,isLessThanOrEqualTo:()=>RC,isLessThanDateReviver:()=>i10,isLessThanDate:()=>PC,isLessThanBigIntReviver:()=>e10,isLessThanBigInt:()=>jC,isLessThanBigDecimal:()=>fe,isLessThan:()=>TC,isLengthBetweenReviver:()=>oe,isLengthBetween:()=>dW,isIntReviver:()=>ge,isInt32:()=>ye,isInt:()=>nQ,isIncludesReviver:()=>Ae,isIncludes:()=>DC,isGreaterThanReviver:()=>je,isGreaterThanOrEqualToReviver:()=>Se,isGreaterThanOrEqualToDateReviver:()=>r10,isGreaterThanOrEqualToDate:()=>AC,isGreaterThanOrEqualToBigIntReviver:()=>t10,isGreaterThanOrEqualToBigInt:()=>IC,isGreaterThanOrEqualToBigDecimal:()=>de,isGreaterThanOrEqualTo:()=>hW,isGreaterThanDateReviver:()=>o10,isGreaterThanDate:()=>EC,isGreaterThanBigIntReviver:()=>a10,isGreaterThanBigInt:()=>MC,isGreaterThanBigDecimal:()=>me,isGreaterThan:()=>LC,isGUIDReviver:()=>Oe,isGUID:()=>ZC,isFiniteReviver:()=>Ie,isFinite:()=>zC,isEndsWithReviver:()=>Ee,isEndsWith:()=>UC,isCapitalizedReviver:()=>Ce,isCapitalized:()=>VC,isBetweenReviver:()=>ke,isBetweenDateReviver:()=>s10,isBetweenDate:()=>CC,isBetweenBigIntReviver:()=>YX0,isBetweenBigInt:()=>vC,isBetweenBigDecimal:()=>ue,isBetween:()=>cG,isBase64UrlReviver:()=>Re,isBase64Url:()=>HC,isBase64Reviver:()=>Te,isBase64:()=>yW,is:()=>Mw,instanceOf:()=>G4,fromURLSearchParams:()=>s00,fromJsonString:()=>DM,fromFormData:()=>i00,fromBrand:()=>et,flip:()=>PW,fieldsAssign:()=>ft,extendTo:()=>ct,encodeUnknownSync:()=>fw,encodeUnknownResult:()=>mw,encodeUnknownPromise:()=>dw,encodeUnknownOption:()=>Et,encodeUnknownExit:()=>hw,encodeUnknownEffect:()=>hG,encodeTo:()=>xW,encodeSync:()=>Ct,encodeResult:()=>Pt,encodePromise:()=>wt,encodeOption:()=>At,encodeKeys:()=>ut,encodeExit:()=>Ft,encodeEffect:()=>yw,encode:()=>_e,decodeUnknownSync:()=>gw,decodeUnknownResult:()=>kw,decodeUnknownPromise:()=>bw,decodeUnknownOption:()=>zt,decodeUnknownExit:()=>vw,decodeUnknownEffect:()=>yG,decodeTo:()=>l,decodeSync:()=>Rt,decodeResult:()=>Lt,decodePromise:()=>Tt,decodeOption:()=>Ot,decodeExit:()=>qt,decodeEffect:()=>Vt,decode:()=>Qe,declareConstructor:()=>VX,declare:()=>jX,check:()=>at,catchEncodingWithContext:()=>ew,catchEncoding:()=>Ye,catchDecodingWithContext:()=>tw,catchDecoding:()=>Xe,brand:()=>sw,asserts:()=>Bt,annotateKey:()=>Wt,annotateEncoded:()=>Ht,annotate:()=>Kt,Void:()=>ht,UnknownFromJsonString:()=>l00,Unknown:()=>MW,UniqueSymbol:()=>dt,UniqueArray:()=>nt,Union:()=>X1,UndefinedOr:()=>pG,Undefined:()=>IW,Uint8ArrayReviver:()=>Z10,Uint8ArrayFromHex:()=>W10,Uint8ArrayFromBase64Url:()=>H10,Uint8ArrayFromBase64:()=>K10,Uint8Array:()=>aQ,URLSearchParamsReviver:()=>n00,URLSearchParams:()=>nW,URLReviver:()=>M00,URLFromString:()=>I00,URL:()=>cW,TupleWithRest:()=>ot,Tuple:()=>j9,Trimmed:()=>NM,Trim:()=>X10,Tree:()=>ZX0,TimeZoneReviver:()=>O10,TimeZoneOffsetReviver:()=>V10,TimeZoneOffset:()=>VM,TimeZoneNamedReviver:()=>q10,TimeZoneNamedFromString:()=>z10,TimeZoneNamed:()=>sW,TimeZoneFromString:()=>L10,TimeZone:()=>aW,TemplateLiteralParser:()=>kt,TemplateLiteral:()=>xt,TaggedUnion:()=>Ze,TaggedStruct:()=>uG,TaggedErrorClass:()=>w10,TaggedClass:()=>P10,Symbol:()=>cw,StructWithRest:()=>lt,Struct:()=>h,StringFromUriComponent:()=>G10,StringFromHex:()=>_10,StringFromBase64Url:()=>Q10,StringFromBase64:()=>Y10,String:()=>i,StandardSchemaV1FailureResult:()=>J10,SchemaError:()=>i8,ResultReviver:()=>W00,Result:()=>pC,RegExpReviver:()=>C00,RegExp:()=>$M,RedactedReviver:()=>N00,RedactedFromValue:()=>B00,Redacted:()=>pW,Record:()=>lw,ReadonlySetReviver:()=>A00,ReadonlySet:()=>_M,ReadonlyMapReviver:()=>F00,ReadonlyMap:()=>YM,PropertyKey:()=>CW,OptionReviver:()=>_00,OptionFromUndefinedOr:()=>J00,OptionFromOptionalNullOr:()=>H00,OptionFromOptionalKey:()=>Z00,OptionFromOptional:()=>K00,OptionFromNullishOr:()=>$00,OptionFromNullOr:()=>G00,Option:()=>J4,Opaque:()=>Ke,ObjectKeyword:()=>mt,NumberFromString:()=>a00,Number:()=>dG,NullishOr:()=>iw,NullOr:()=>SW,Null:()=>L0,NonEmptyString:()=>Y00,NonEmptyArray:()=>rt,Never:()=>gt,Natural:()=>BX,MutableJsonReviver:()=>WX0,MutableJson:()=>kM,Literals:()=>fG,Literal:()=>d0,JsonReviver:()=>KX0,Json:()=>rG,Int:()=>D5,HashSetReviver:()=>P00,HashSet:()=>GM,HashMapReviver:()=>E00,HashMap:()=>QM,FormDataReviver:()=>r00,FormData:()=>iW,FiniteFromString:()=>t00,Finite:()=>eX,FileReviver:()=>o00,File:()=>rW,ExitReviver:()=>R00,Exit:()=>tC,ErrorReviver:()=>L00,ErrorClass:()=>RM,Error:()=>aC,Enum:()=>bt,DurationReviver:()=>x00,DurationFromString:()=>b00,DurationFromNanos:()=>g00,DurationFromMillis:()=>y00,Duration:()=>sQ,Defect:()=>T00,DateTimeZonedReviver:()=>T10,DateTimeZonedFromString:()=>R10,DateTimeZoned:()=>tW,DateTimeUtcReviver:()=>U10,DateTimeUtcFromString:()=>N10,DateTimeUtcFromMillis:()=>B10,DateTimeUtcFromDate:()=>D10,DateTimeUtc:()=>tQ,DateReviver:()=>j00,DateFromString:()=>S00,DateFromMillis:()=>v00,Date:()=>X6,Class:()=>TM,ChunkReviver:()=>w00,Chunk:()=>JM,Char:()=>Q00,CauseReviver:()=>q00,CauseReasonReviver:()=>V00,CauseReason:()=>kG,Cause:()=>bG,BooleanFromBit:()=>$10,Boolean:()=>uw,BigIntFromString:()=>e00,BigInt:()=>P6,BigDecimalReviver:()=>p00,BigDecimalFromString:()=>u00,BigDecimal:()=>oW,ArrayEnsure:()=>it,Array:()=>e0,Any:()=>yt});var OO=/^[+-]?\d+$/,C2="~effect/BigDecimal",sd={[C2]:C2,[U0](){let X=M2(this);return Y1(e(X.value),v6(X.scale))},[D0](X){return _3(X)&&Qf(this,X)},toString(){return`BigDecimal(${L6(this)})`},toJSON(){return{_id:"BigDecimal",value:String(this.value),scale:this.scale}},[K1](){return this.toJSON()},pipe(){return G0(this,arguments)}},_3=(X)=>I(X,C2),a1=(X,Y)=>{let Q=Object.create(sd);return Q.value=X,Q.scale=Y,Q},TO=(X,Y)=>{if(X!==HX&&X%Q3===HX)throw RangeError("Value must be normalized");let Q=a1(X,Y);return Q.normalized=Q,Q},HX=BigInt(0),ad=BigInt(1),td=BigInt(-1);var Q3=BigInt(10),RO=TO(HX,0);var M2=(X)=>{if(X.normalized===void 0)if(X.value===HX)X.normalized=RO;else{let Y=`${X.value}`,Q=0;for(let J=Y.length-1;J>=0;J--)if(Y[J]==="0")Q++;else break;if(Q===0)X.normalized=X;let _=BigInt(Y.substring(0,Y.length-Q)),G=X.scale-Q;X.normalized=TO(_,G)}return X.normalized},h8=V(2,(X,Y)=>{if(Y>X.scale)return a1(X.value*Q3**BigInt(Y-X.scale),Y);if(Y<X.scale)return a1(X.value/Q3**BigInt(X.scale-Y),Y);return X}),FO=V(2,(X,Y)=>{if(Y.value===HX)return X;if(X.value===HX)return Y;if(X.scale>Y.scale)return a1(h8(Y,X.scale).value+X.value,X.scale);if(X.scale<Y.scale)return a1(h8(X,Y.scale).value+Y.value,Y.scale);return a1(X.value+Y.value,X.scale)});var e6=T4((X,Y)=>{let Q=q1(LO(X),LO(Y));if(Q!==0)return Q;if(X.scale>Y.scale)return RX(X.value,h8(Y,X.scale).value);if(X.scale<Y.scale)return RX(h8(X,Y.scale).value,Y.value);return RX(X.value,Y.value)}),ed=C5(e6);var Xf=R8(e6);var LO=(X)=>X.value===HX?0:X.value<HX?-1:1,Yf=(X)=>X.value<HX?a1(-X.value,X.scale):X;var I2=H1((X,Y)=>{if(X.scale>Y.scale)return h8(Y,X.scale).value===X.value;if(X.scale<Y.scale)return h8(X,Y.scale).value===Y.value;return X.value===Y.value}),Qf=V(2,(X,Y)=>I2(X,Y));var EO=(X)=>{if(X==="")return T(RO);let Y,Q,_=X.search(/[eE]/);if(_!==-1){let H=X.slice(_+1);if(Y=X.slice(0,_),Q=Number(H),Y===""||!Number.isSafeInteger(Q)||!OO.test(H))return f()}else Y=X,Q=0;let G,J,Z=Y.search(/\./);if(Z!==-1){let H=Y.slice(0,Z),W=Y.slice(Z+1);G=`${H}${W}`,J=W.length}else G=Y,J=0;if(!OO.test(G))return f();let K=J-Q;if(!Number.isSafeInteger(K))return f();return T(a1(BigInt(G),K))};var L6=(X)=>{let Y=M2(X);if(Math.abs(Y.scale)>=16)return _f(Y);let Q=Y.value<HX,_=Q?`${Y.value}`.substring(1):`${Y.value}`,G,J;if(Y.scale>=_.length)G="0",J="0".repeat(Y.scale-_.length)+_;else{let K=_.length-Y.scale;if(K>_.length){let H=K-_.length;G=`${_}${"0".repeat(H)}`,J=""}else J=_.slice(K),G=_.slice(0,K)}let Z=J===""?G:`${G}.${J}`;return Q?`-${Z}`:Z},_f=(X)=>{if(Gf(X))return"0e+0";let Y=M2(X),Q=`${Yf(Y).value}`,_=Q.slice(0,1),G=Q.slice(1),J=`${AO(Y)?"-":""}${_}`;if(G!=="")J+=`.${G}`;let Z=G.length-Y.scale;return`${J}e${Z>=0?"+":""}${Z}`};var Gf=(X)=>X.value===HX,AO=(X)=>X.value<HX,Jf=(X)=>X.value>HX,j2=(X)=>_3(X[0]);var PO=V(j2,(X,Y=0)=>{if(X.scale<=Y)return X;return a1(X.value/Q3**BigInt(X.scale-Y),Y)}),S2=V(j2,(X,Y=0)=>{let Q=PO(X,Y);if(Jf(X)&&ed(Q,X))return FO(Q,a1(ad,Y));return Q});var v2=V(j2,(X,Y=0)=>{let Q=PO(X,Y);if(AO(X)&&Xf(Q,X))return FO(Q,a1(td,Y));return Q});var CO="~effect/collections/Chunk";function $f(X,Y,Q,_,G){for(let J=Y;J<Math.min(X.length,Y+G);J++)Q[_+J-Y]=X[J];return Q}var MO=[],k2=(X)=>H1((Y,Q)=>Y.length===Q.length&&aY(Y).every((_,G)=>X(_,tY(Q,G)))),Zf=k2(o),Kf={[CO]:{_A:(X)=>X},toString(){return`Chunk(${A(aY(this))})`},toJSON(){return{_id:"Chunk",values:R1(aY(this))}},[K1](){return this.toJSON()},[D0](X){return G3(X)&&Zf(this,X)},[U0](){return r9(aY(this))},[Symbol.iterator](){switch(this.backing._tag){case"IArray":return this.backing.array[Symbol.iterator]();case"IEmpty":return MO[Symbol.iterator]();default:return aY(this)[Symbol.iterator]()}},pipe(){return G0(this,arguments)}},b2=(X)=>{let Y=Object.create(Kf);switch(Y.backing=X,X._tag){case"IEmpty":{Y.length=0,Y.depth=0,Y.left=Y,Y.right=Y;break}case"IConcat":{Y.length=X.left.length+X.right.length,Y.depth=1+Math.max(X.left.depth,X.right.depth),Y.left=X.left,Y.right=X.right;break}case"IArray":{Y.length=X.array.length,Y.depth=0,Y.left=X8,Y.right=X8;break}case"ISingleton":{Y.length=1,Y.depth=0,Y.left=X8,Y.right=X8;break}case"ISlice":{Y.length=X.length,Y.depth=X.chunk.depth+1,Y.left=X8,Y.right=X8;break}}return Y},G3=(X)=>I(X,CO),X8=b2({_tag:"IEmpty"}),Hf=()=>X8;var Wf=(X)=>b2({_tag:"ISingleton",a:X}),J3=(X)=>G3(X)?X:Df(A1(X)),x2=(X,Y,Q)=>{switch(X.backing._tag){case"IArray":{$f(X.backing.array,0,Y,Q,X.length);break}case"IConcat":{x2(X.left,Y,Q),x2(X.right,Y,Q+X.left.length);break}case"ISingleton":{Y[Q]=X.backing.a;break}case"ISlice":{let _=0,G=Q;while(_<X.length)Y[G]=tY(X,_),_+=1,G+=1;break}}};var Uf=(X)=>{switch(X.backing._tag){case"IEmpty":return MO;case"IArray":return X.backing.array;default:{let Y=Array(X.length);return x2(X,Y,0),X.backing={_tag:"IArray",array:Y},X.left=X8,X.right=X8,X.depth=0,Y}}},aY=Uf;var Df=(X)=>X.length===0?Hf():X.length===1?Wf(X[0]):b2({_tag:"IArray",array:X});var tY=V(2,(X,Y)=>{let Q=Math.floor(Y);switch(X.backing._tag){case"IEmpty":throw Error(`Index out of bounds: ${Q}`);case"ISingleton":{if(Y!==0)throw Error(`Index out of bounds: ${Q}`);return X.backing.a}case"IArray":{if(Q>=X.length||Q<0)throw Error(`Index out of bounds: ${Q}`);return X.backing.array[Q]}case"IConcat":return Q<X.left.length?tY(X.left,Q):tY(X.right,Q-X.left.length);case"ISlice":return tY(X.backing.chunk,Q+X.backing.offset)}});var IO=(X)=>X.length;var g2=s5,jO=h4,SO=gq,vO=yq,xO=hq,kO=gZ,y2=mq,h2=dq;var bO=n5;var gO=mZ;var $3=fq,yO=pq;var Z3=uq;var m2=dZ,eY=IY,hO=fZ;var mO=pZ,m8=cq;var K3=jY;var dO=lZ;var fO=oq;var H3=rZ;var pO="~effect/encoding/EncodingError";class d8 extends $Y("EncodingError"){[pO]=pO}var U3=(X)=>typeof X==="string"?f2(c2.encode(X)):f2(X),G9=(X)=>{let Y=tO(X),Q=Y.length;if(Q%4!==0)return c(new d8({kind:"Decode",module:"Base64",input:Y,message:`Length must be a multiple of 4, but is ${Q}`}));let _=Y.indexOf("=");if(_!==-1&&(_<Q-2||_===Q-2&&Y[Q-1]!=="="))return c(new d8({kind:"Decode",module:"Base64",input:Y,message:"Found a '=' character, but it is not at the end"}));try{let G=Y.endsWith("==")?2:Y.endsWith("=")?1:0,J=new Uint8Array(3*(Q/4)-G);for(let Z=0,K=0;Z<Q;Z+=4,K+=3){let H=W3(Y.charCodeAt(Z))<<18|W3(Y.charCodeAt(Z+1))<<12|W3(Y.charCodeAt(Z+2))<<6|W3(Y.charCodeAt(Z+3));J[K]=H>>16,J[K+1]=H>>8&255,J[K+2]=H&255}return m(J)}catch(G){return c(new d8({kind:"Decode",module:"Base64",input:Y,message:G instanceof Error?G.message:"Invalid input"}))}},rO=(X)=>JX(G9(X),(Y)=>l2.decode(Y)),iO=(X)=>typeof X==="string"?cO(c2.encode(X)):cO(X),p2=(X)=>{let Y=tO(X),Q=Y.length;if(Q%4===1)return c(new d8({module:"Base64Url",kind:"Decode",input:Y,message:`Length should be a multiple of 4, but is ${Q}`}));if(!/^[-_A-Z0-9]*?={0,2}$/i.test(Y))return c(new d8({module:"Base64Url",kind:"Decode",input:Y,message:"Invalid input"}));let _=Q%4===2?`${Y}==`:Q%4===3?`${Y}=`:Y;return _=_.replace(/-/g,"+").replace(/_/g,"/"),G9(_)},nO=(X)=>JX(p2(X),(Y)=>l2.decode(Y)),sO=(X)=>typeof X==="string"?lO(c2.encode(X)):lO(X),u2=(X)=>{let Y=new TextEncoder().encode(X);if(Y.length%2!==0)return c(new d8({module:"Hex",kind:"Decode",input:X,message:`Length must be a multiple of 2, but is ${Y.length}`}));try{let Q=Y.length/2,_=new Uint8Array(Q);for(let G=0;G<Q;G++){let J=oO(Y[G*2]),Z=oO(Y[G*2+1]);_[G]=J<<4|Z}return m(_)}catch(Q){return c(new d8({module:"Hex",kind:"Decode",input:X,message:Q instanceof Error?Q.message:"Invalid input"}))}},aO=(X)=>JX(u2(X),(Y)=>l2.decode(Y)),c2=new TextEncoder,l2=new TextDecoder,tO=(X)=>X.replace(/[\n\r]/g,""),f2=(X)=>{let Y=X.length,Q="",_;for(_=2;_<Y;_+=3)Q+=Y8[X[_-2]>>2],Q+=Y8[(X[_-2]&3)<<4|X[_-1]>>4],Q+=Y8[(X[_-1]&15)<<2|X[_]>>6],Q+=Y8[X[_]&63];if(_===Y+1)Q+=Y8[X[_-2]>>2],Q+=Y8[(X[_-2]&3)<<4],Q+="==";if(_===Y)Q+=Y8[X[_-2]>>2],Q+=Y8[(X[_-2]&3)<<4|X[_-1]>>4],Q+=Y8[(X[_-1]&15)<<2],Q+="=";return Q};function W3(X){if(X>=uO.length)throw TypeError(`Invalid character ${String.fromCharCode(X)}`);let Y=uO[X];if(Y===255)throw TypeError(`Invalid character ${String.fromCharCode(X)}`);return Y}var Y8=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","0","1","2","3","4","5","6","7","8","9","+","/"],uO=[255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,62,255,255,255,63,52,53,54,55,56,57,58,59,60,61,255,255,255,0,255,255,255,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,255,255,255,255,255,255,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51],cO=(X)=>f2(X).replace(/=/g,"").replace(/\+/g,"-").replace(/\//g,"_"),lO=(X)=>{let Y="";for(let Q=0;Q<X.length;++Q)Y+=Bf[X[Q]];return Y},oO=(X)=>{if(48<=X&&X<=57)return X-48;if(97<=X&&X<=102)return X-97+10;if(65<=X&&X<=70)return X-65+10;throw TypeError("Invalid input")},Bf=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];function Q8(X){return X.checks?X.checks[X.checks.length-1].annotations:X.annotations}function XQ(X){return(Y)=>Q8(Y)?.[X]}var t1="~structural",YQ="~identifier",QQ="~sentinels",XL=["title","description","default","examples","readOnly","writeOnly","format","contentEncoding","contentMediaType","contentSchema"],f8=XQ("identifier"),D3=XQ(YQ),o2=XQ("title");var YL=XQ("brands"),N3=a0((X)=>{let Y=f8(X);if(typeof Y==="string")return Y;return X.getExpected(N3)});var QL=new Set([QQ,t1,"representation","arbitrary","brands","toJsonSchema","toCode","toArbitrary","toEquivalence","toFormatter","toCodec","toCodecJson","toCodecStringTree","toCodecIso"]);var i4=new WeakMap,_L=(X)=>{if(i4.has(X))return i4.get(X);else throw Error("Unable to get redacted value"+(X.label?` with label: "${X.label}"`:""))};var GL="~effect/data/Redacted",r2=(X)=>I(X,GL),T6=(X,Y)=>{let Q=Object.create(qf);if(Y?.label)Q.label=Y.label;return i4.set(Q,X),Q},qf={[GL]:{_A:(X)=>X},label:void 0,...k6,toJSON(){return this.toString()},toString(){return`<redacted${xX(this.label)?":"+this.label:""}>`},[U0](){return e(i4.get(this))},[D0](X){return r2(X)&&o(i4.get(this),i4.get(X))}},J9=_L;var JL=(X)=>H1((Y,Q)=>X(J9(Y),J9(Q)));var GQ="~effect/SchemaIssue/Issue";function s2(X){return I(X,GQ)&&X[GQ]===GQ}class AX{[GQ]=GQ;toString(){return Of(this)}}class V3 extends AX{_tag="Filter";actual;filter;issue;constructor(X,Y,Q){super();this.actual=X,this.filter=Y,this.issue=Q}}class a2 extends AX{_tag="Encoding";ast;actual;issue;constructor(X,Y,Q){super();this.ast=X,this.actual=Y,this.issue=Q}}class M0 extends AX{_tag="Pointer";path;issue;constructor(X,Y){super();this.path=X,this.issue=Y}}class $Q extends AX{_tag="MissingKey";annotations;constructor(X){super();this.annotations=X}}class q3 extends AX{_tag="UnexpectedKey";ast;actual;constructor(X,Y){super();this.ast=X,this.actual=Y}}class T0 extends AX{_tag="Composite";ast;actual;issues;constructor(X,Y,Q){super();this.ast=X,this.actual=Y,this.issues=Q}}class l0 extends AX{_tag="InvalidType";ast;actual;constructor(X,Y){super();this.ast=X,this.actual=Y}}class W0 extends AX{_tag="InvalidValue";actual;annotations;constructor(X,Y){super();this.actual=X,this.annotations=Y}}class $9 extends AX{_tag="Forbidden";actual;annotations;constructor(X,Y){super();this.actual=X,this.annotations=Y}}class z3 extends AX{_tag="AnyOf";ast;actual;issues;constructor(X,Y,Q){super();this.ast=X,this.actual=Y,this.issues=Q}}class t2 extends AX{_tag="OneOf";ast;actual;successes;constructor(X,Y,Q){super();this.ast=X,this.actual=Y,this.successes=Q}}function i2(X,Y){if(s2(Y))return Y;if(typeof Y==="string")return new W0(T(X),{message:Y});let Q=typeof Y.issue==="string"?new W0(T(X),{message:Y.issue}):Y.issue;return new M0(Y.path,Q)}function KL(X,Y){if(Y===void 0)return;if(typeof Y==="boolean")return Y?void 0:new W0(T(X));return i2(X,Y)}function HL(X,Y,Q){if(Array.isArray(Q)){if(C8(Q)){if(Q.length===1)return i2(X,Q[0]);return new T0(Y,T(X),U6(Q,(_)=>i2(X,_)))}return}return KL(X,Q)}var WL=(X)=>{let Y=JQ(X);if(Y!==void 0)return Y;switch(X._tag){case"InvalidType":return n2(N3(X.ast),ZL(X.actual));case"InvalidValue":return`Invalid data ${ZL(X.actual)}`;case"MissingKey":return"Missing key";case"UnexpectedKey":return`Unexpected key with value ${A(X.actual)}`;case"Forbidden":return"Forbidden operation";case"OneOf":return`Expected exactly one member to match the input ${A(X.actual)}`}},UL=(X)=>{return JQ(X.issue)??JQ(X)};function DL(X){return(Y)=>({issues:n4(Y,[],X?.leafHook??WL,X?.checkHook??UL)})}function n2(X,Y){return`Expected ${X}, got ${Y}`}function n4(X,Y,Q,_){switch(X._tag){case"Filter":{let G=_(X);if(G!==void 0)return[{path:Y,message:G}];switch(X.issue._tag){case"InvalidValue":return[{path:Y,message:n2(NL(X.filter),A(X.actual))}];default:return n4(X.issue,Y,Q,_)}}case"Encoding":return n4(X.issue,Y,Q,_);case"Pointer":return n4(X.issue,[...Y,...X.path],Q,_);case"Composite":return X.issues.flatMap((G)=>n4(G,Y,Q,_));case"AnyOf":{let G=JQ(X);if(X.issues.length===0){if(G!==void 0)return[{path:Y,message:G}];let J=n2(N3(X.ast),A(X.actual));return[{path:Y,message:J}]}return X.issues.flatMap((J)=>n4(J,Y,Q,_))}default:return[{path:Y,message:Q(X)}]}}function NL(X){let Y=X.annotations?.expected;if(typeof Y==="string")return Y;switch(X._tag){case"Filter":return"<filter>";case"FilterGroup":return X.checks.map((Q)=>NL(Q)).join(" & ")}}function zf(){return(X)=>n4(X,[],WL,UL).map(Lf).join(`
`)}var Of=zf();function Lf(X){let Y=X.message;if(X.path&&X.path.length>0){let Q=C_(X.path);Y+=`
  at ${Q}`}return Y}function JQ(X){switch(X._tag){case"InvalidType":case"OneOf":case"Composite":case"AnyOf":return _Q(X.ast.annotations);case"InvalidValue":case"Forbidden":return _Q(X.annotations);case"MissingKey":return _Q(X.annotations,"messageMissingKey");case"UnexpectedKey":return _Q(X.ast.annotations,"messageUnexpectedKey");case"Filter":return _Q(X.filter.annotations);case"Encoding":return JQ(X.issue)}}function _Q(X,Y="message"){let Q=X?.[Y];if(typeof Q==="string")return Q}function ZL(X){if(E0(X))return"no value provided";return A(X.value)}function B3(X){switch(X._tag){case"MissingKey":return X;case"Forbidden":return new $9(f6(X.actual,T6),X.annotations);case"Filter":return new V3(T6(X.actual),X.filter,B3(X.issue));case"Pointer":return new M0(X.path,B3(X.issue));case"Encoding":case"InvalidType":case"InvalidValue":case"Composite":return new W0(f6(X.actual,T6));case"AnyOf":case"OneOf":case"UnexpectedKey":return new W0(T(T6(X.actual)))}}function O3(X){let Y;for(let Q of X.reasons){if(!g7(Q)||!s2(Q.error))return;Y??=Q.error}return Y}function _8(X,Y){let Q=O3(X);if(Q===void 0)throw Error(Y,{cause:X});return Q}class G8 extends N4{run;constructor(X){super();this.run=X}map(X){return new G8((Y,Q)=>this.run(Y,Q).pipe(u4(f6(X))))}compose(X){if(VL(this))return X;if(VL(X))return this;return new G8((Y,Q)=>this.run(Y,Q).pipe(EX((_)=>X.run(_,Q))))}}function Tf(X){return new G8((Y)=>d(X(Y)))}function e2(X){return Tf((Y)=>new $9(Y,{message:X(Y)}))}var qL=new G8(p);function VL(X){return X.run===qL.run}function fX(){return qL}function XK(X){return new G8((Y,Q)=>E0(Y)?mX:X(Y.value,Q))}function Y0(X){return L3(f6(X))}function e1(X){return XK((Y,Q)=>X(Y,Q).pipe(u4(T)))}function L3(X){return new G8((Y)=>p(X(Y)))}function YK(){return new G8(()=>mX)}function ZQ(X){return new G8((Y)=>{let Q=j5(Y,N1);return W1(Q)?p(Q):u4(X,T)})}function s4(){return Y0(globalThis.String)}function T3(){return Y0(globalThis.Number)}function zL(){return Y0(globalThis.BigInt)}function QK(){return Y0((X)=>new globalThis.Date(X))}function OL(){return Y0(aq)}function LL(X){return XK((Y)=>e5({try:()=>T(JSON.parse(Y,X?.reviver)),catch:(Q)=>new W0(T(Y),{message:globalThis.String(Q)})}))}function TL(X){return XK((Y)=>e5({try:()=>{let Q=JSON.stringify(Y,X?.replacer,X?.space);if(Q===void 0)throw TypeError("Value cannot be represented as JSON");return T(Q)},catch:(Q)=>new W0(T(Y),{message:globalThis.String(Q)})}))}function _K(){return Y0(U3)}function R3(){return Y0(iO)}function F3(){return Y0(sO)}function RL(){return e1((X)=>X9($2(G9(X)),(Y)=>new W0(T(X),{message:Y.message})))}function FL(){return e1((X)=>o1(rO(X),{onFailure:(Y)=>d(new W0(T(X),{message:Y.message})),onSuccess:p}))}function EL(){return e1((X)=>o1(p2(X),{onFailure:(Y)=>d(new W0(T(X),{message:Y.message})),onSuccess:p}))}function AL(){return e1((X)=>o1(nO(X),{onFailure:(Y)=>d(new W0(T(X),{message:Y.message})),onSuccess:p}))}function PL(){return e1((X)=>o1(u2(X),{onFailure:(Y)=>d(new W0(T(X),{message:Y.message})),onSuccess:p}))}function wL(){return e1((X)=>o1(aO(X),{onFailure:(Y)=>d(new W0(T(X),{message:Y.message})),onSuccess:p}))}function CL(){return Y0(encodeURIComponent)}function ML(){return e1((X)=>{try{return p(globalThis.decodeURIComponent(X))}catch(Y){return d(new W0(T(X),{message:Y instanceof URIError?Y.message:"Invalid URI component"}))}})}function GK(){return e1((X)=>{return kX($3(X),{onNone:()=>d(new W0(T(X),{message:"Invalid DateTime input"})),onSome:(Y)=>p(Z3(Y))})})}function IL(){return Y0((X)=>xL(Array.from(X.entries())))}var Rf=kL((X)=>typeof X==="string"||typeof Blob<"u"&&X instanceof Blob);function jL(){return Y0((X)=>{let Y=new FormData;if(typeof X==="object"&&X!==null)Rf(X).forEach(([_,G])=>{Y.append(_,G)});return Y})}function SL(){return Y0((X)=>xL(Array.from(X.entries())))}var Ff=kL(xX);function vL(){return Y0((X)=>{if(typeof X==="object"&&X!==null)return new URLSearchParams(Ff(X));return new URLSearchParams})}var Ef=/^\d+$/;function Af(X){if(X==="")return[""];let Y=X.replace(/\[(.*?)\]/g,".$1"),Q=Y.split("."),_=Y.startsWith(".")?1:0;return Q.slice(_).map((G)=>Ef.test(G)?globalThis.Number(G):G)}function xL(X){let Y={},Q=new WeakSet;function _(G,J,Z){let K=Object.hasOwn(G,J)?G[J]:void 0;if(Q.has(K)&&Array.isArray(K)===Z)return K;let H=Z?[]:{};return Q.add(H),k(G,J,H),H}return X.forEach(([G,J])=>{let Z=Af(G),K=Y;Z.forEach((H,W)=>{let D=W===Z.length-1;if(Array.isArray(K)&&H==="")if(D)K.push(J);else{let U=Z[W+1],N=typeof U==="number"||U==="",B=K.length;K=_(K,B,N)}else if(D){let U=Object.hasOwn(K,H);if(U&&Array.isArray(K[H]))K[H].push(J);else if(U)k(K,H,[K[H],J]);else k(K,H,J)}else{let U=Z[W+1];K=_(K,H,typeof U==="number"||U==="")}})}),Y}function kL(X){return(Y)=>{let Q=[];function _(G,J){if(X(J))Q.push([G,J]);else if(Array.isArray(J))if(J.every(X))J.forEach((K)=>{Q.push([G,K])});else J.forEach((K,H)=>{_(`${G}[${H}]`,K)});else if(typeof J==="object"&&J!==null)for(let[Z,K]of Object.entries(J))_(`${G}[${Z}]`,K)}for(let[G,J]of Object.entries(Y))_(G,J);return Q}}class HQ{_tag="Middleware";decode;encode;constructor(X,Y){this.decode=X,this.encode=Y}flip(){return new HQ(this.encode,this.decode)}}var KQ="~effect/SchemaTransformation/Transformation";class V0{[KQ]=KQ;_tag="Transformation";decode;encode;constructor(X,Y){this.decode=X,this.encode=Y}flip(){return new V0(this.encode,this.decode)}compose(X){return new V0(this.decode.compose(X.decode),X.encode.compose(this.encode))}}function Pf(X){return I(X,KQ)&&X[KQ]===KQ}var E3=(X)=>{if(Pf(X))return X;return new V0(X.decode,X.encode)};function PX(X){return new V0(e1(X.decode),e1(X.encode))}function y0(X){return new V0(Y0(X.decode),Y0(X.encode))}function A3(X){return new V0(L3(X.decode),L3(X.encode))}function bL(){return new V0(OL(),fX())}var wf=new V0(fX(),fX());function K9(){return wf}var H9=new V0(T3(),s4()),P3=new V0(zL(),s4()),$K=new V0(QK(),Y0(fJ)),gL=new V0(QK(),Y0((X)=>X.getTime())),yL=PX({decode:(X)=>kX(JN(X),{onNone:()=>d(new W0(T(X),{message:`Invalid Duration string: ${X}`})),onSome:p}),encode:(X)=>p(globalThis.String(X))}),hL=PX({decode:(X)=>p(H6(X)),encode:(X)=>kX($N(X),{onNone:()=>d(new W0(T(X),{message:`Unable to encode ${X} into a bigint`})),onSome:(Y)=>p(Y)})}),mL=y0({decode:(X)=>E8(X),encode:(X)=>A8(X)}),Cf=(X)=>j1(X)&&typeof X.message==="string",dL=(X)=>{let Q=Object.hasOwn(X,"cause")?Error(X.message,{cause:pL(X.cause)}):Error(X.message);if(typeof X.name==="string"&&X.name!=="Error")Q.name=X.name;if(typeof X.stack==="string")Q.stack=X.stack;return Q},Mf=(X)=>{try{let Y=V4(X);return Y===void 0?A(X):JSON.parse(Y)}catch{return A(X)}},If=(X,Y,Q)=>{let _={name:X.name,message:typeof X.message==="string"?X.message:""};if(Y?.includeStack&&typeof X.stack==="string")_.stack=X.stack;if(!Y?.excludeCause&&X.cause!==void 0)_.cause=Q(X.cause);return _},fL=(X)=>{let Y=new WeakSet,Q=(_)=>{if(ED(_)){if(Y.has(_))return"[Circular]";Y.add(_);let G=If(_,X,Q);return Y.delete(_),G}return Mf(_)};return Q},pL=(X)=>Cf(X)?dL(X):X,uL=(X)=>y0({decode:dL,encode:(Y)=>fL(X)(Y)}),cL=(X)=>y0({decode:pL,encode:fL(X)});function lL(){return y0({decode:tD,encode:sJ})}function oL(){return y0({decode:aD,encode:F4})}function rL(X){return y0({decode:sD,encode:X?.onNoneEncoding===null?sJ:F4})}function iL(){return A3({decode:T,encode:I5})}function nL(){return A3({decode:(X)=>X.pipe(j5(N1),T),encode:I5})}var ZK=PX({decode:(X)=>URL.canParse(X)?p(new URL(X)):d(new W0(T(X),{message:`Invalid URL string: ${X}`})),encode:(X)=>p(X.href)}),KK=PX({decode:(X)=>{let Y=EO(X);return E0(Y)?d(new W0(T(X),{message:`Invalid BigDecimal string: ${X}`})):p(Y.value)},encode:(X)=>p(L6(X))}),HK=new V0(RL(),_K()),sL=new V0(FL(),_K()),aL=new V0(AL(),R3()),tL=new V0(wL(),F3()),eL=new V0(ML(),CL()),XT=new V0(LL(),TL()),YT=new V0(IL(),jL()),QT=new V0(SL(),vL()),_T=y0({decode:(X)=>eY(X),encode:(X)=>X.offset}),WK=PX({decode:(X)=>{return kX(hO(X),{onNone:()=>d(new W0(T(X),{message:`Invalid IANA time zone: ${X}`})),onSome:p})},encode:(X)=>p(X.id)}),UK=PX({decode:(X)=>{return kX(mO(X),{onNone:()=>d(new W0(T(X),{message:`Invalid time zone: ${X}`})),onSome:p})},encode:(X)=>p(m8(X))}),DK=PX({decode:(X)=>{return kX($3(X),{onNone:()=>d(new W0(T(X),{message:`Invalid UTC DateTime string: ${X}`})),onSome:(Y)=>p(Z3(Y))})},encode:(X)=>p(fO(X))}),NK=PX({decode:(X)=>{return kX(yO(X),{onNone:()=>d(new W0(T(X),{message:`Invalid Zoned DateTime string: ${X}`})),onSome:p})},encode:(X)=>p(H3(X))});function t4(X){return(Y)=>Y._tag===X}var e4=t4("Declaration");var jf=t4("Never");var w3=t4("Literal"),Sf=t4("UniqueSymbol");var UQ=t4("Arrays"),LK=t4("Objects"),DQ=t4("Union");class h0{to;transformation;constructor(X,Y){this.to=X,this.transformation=Y}}var X5={};class uX{isOptional;isMutable;defaultValue;annotations;constructor(X,Y,Q=void 0,_=void 0){this.isOptional=X,this.isMutable=Y,this.defaultValue=Q,this.annotations=_}}var JT="~effect/Schema";class o0{[JT]=JT;annotations;checks;encoding;context;constructor(X=void 0,Y=void 0,Q=void 0,_=void 0){this.annotations=X,this.checks=Y,this.encoding=Q,this.context=_}toString(){return`<${this._tag}>`}}class Y5 extends o0{_tag="Declaration";typeParameters;run;encodingChecks;constructor(X,Y,Q,_,G,J,Z){super(Q,_,G,J);this.typeParameters=X,this.run=Y,this.encodingChecks=Z}getParser(){let X=this.run(this.typeParameters);return(Y,Q)=>{if(E0(Y))return mX;return u4(X(Y.value,this,Q),T)}}_rebuild(X,Y,Q){let _=W9(this.typeParameters,X);return _===this.typeParameters&&Y===this.checks&&Q===this.encodingChecks?this:new Y5(_,this.run,this.annotations,Y,void 0,this.context,Q)}recur(X){return this._rebuild(X,this.checks,this.encodingChecks)}flip(X){return this._rebuild(X,this.encodingChecks,this.checks)}getExpected(){let X=this.annotations?.expected;if(typeof X==="string")return X;return"<Declaration>"}}class DT extends o0{_tag="Null";getParser(){return f3(this,null)}getExpected(){return"null"}}var TK=new DT;class NT extends o0{_tag="Undefined";getParser(){return f3(this,void 0)}toCodecJson(){return R0(this,[BT])}getExpected(){return"undefined"}}var BT=new h0(TK,new V0(Y0(()=>{return}),Y0(()=>null))),VT=new NT;class qT extends o0{_tag="Void";getParser(){return cf(void 0)}toCodecJson(){return R0(this,[BT])}getExpected(){return"void"}}var zT=new qT;class OT extends o0{_tag="Never";getParser(){return oX(this,FD)}getExpected(){return"never"}}var LT=new OT;class TT extends o0{_tag="Any";getParser(){return oX(this,jJ)}getExpected(){return"any"}}var RT=new TT;class FT extends o0{_tag="Unknown";getParser(){return oX(this,jJ)}getExpected(){return"unknown"}}var a4=new FT;class ET extends o0{_tag="ObjectKeyword";getParser(){return oX(this,SJ)}getExpected(){return"object | array | function"}}var AT=new ET;class RK extends o0{_tag="Enum";enums;constructor(X,Y,Q,_,G){super(Y,Q,_,G);this.enums=X}getParser(){let X=new Set(this.enums.map(([,Y])=>Y));return oX(this,(Y)=>X.has(Y))}toCodecStringTree(){if(this.enums.some(([X,Y])=>typeof Y==="number")){let X=Object.fromEntries(this.enums.map(([Y,Q])=>[globalThis.String(Q),Q]));return R0(this,[new h0(new XX(Object.keys(X).map((Y)=>new WX(Y)),"anyOf"),new V0(Y0((Y)=>X[Y]),s4()))])}return this}getExpected(){return this.enums.map(([X,Y])=>JSON.stringify(Y)).join(" | ")}}function PT(X){switch(X._tag){case"String":case"Number":case"BigInt":return!0;case"Literal":case"TemplateLiteral":return X.checks===void 0;case"Union":return X.checks===void 0&&X.types.every(PT);default:return!1}}class FK extends o0{_tag="TemplateLiteral";parts;encodedParts;constructor(X,Y,Q,_,G){super(Y,Q,_,G);let J=[];for(let Z of X){let K=L1(Z);if(PT(K))J.push(K);else throw Error(`Invalid TemplateLiteral part ${K._tag}`)}this.parts=X,this.encodedParts=J}getParser(X){let Y=X(this.asTemplateLiteralParser());return(Q,_)=>U1(Y(Q,_),{onSuccess:()=>Q,onFailure:(G)=>new T0(this,Q,[G])})}getExpected(){return"string"}matchPart(X,Y){return UT(this.encodedParts,X,Y)===void 0?void 0:X}asTemplateLiteralParser(){let X=new cX(!1,this.parts.map(iT),[]);return d3(u8,X,new V0(e1((Y,Q)=>{let _=UT(this.encodedParts,Y,Q);if(_!==void 0)return p(_);return d(new W0(T(Y),{message:`Expected a string matching template literal parts, got ${A(Y)}`}))}),Y0((Y)=>Y.join(""))))}}class EK extends o0{_tag="UniqueSymbol";symbol;constructor(X,Y,Q,_,G){super(Y,Q,_,G);this.symbol=X}getParser(){return f3(this,this.symbol)}toCodecStringTree(){return R0(this,[aT])}getExpected(){return globalThis.String(this.symbol)}}class WX extends o0{_tag="Literal";literal;constructor(X,Y,Q,_,G){super(Y,Q,_,G);if(typeof X==="number"&&!globalThis.Number.isFinite(X))throw Error(`A numeric literal must be finite, got ${A(X)}`);this.literal=X}getParser(){return f3(this,this.literal)}matchPart(X,Y){return X===globalThis.String(this.literal)?this.literal:void 0}toCodecJson(){return typeof this.literal==="bigint"?$T(this):this}toCodecStringTree(){return typeof this.literal==="string"?this:$T(this)}getExpected(){return typeof this.literal==="string"?JSON.stringify(this.literal):globalThis.String(this.literal)}}function $T(X){let Y=globalThis.String(X.literal);return R0(X,[new h0(new WX(Y),new V0(Y0(()=>X.literal),Y0(()=>Y)))])}class wT extends o0{_tag="String";getParser(){return oX(this,xX)}matchPart(X,Y){return p3(this,X,Y)}getExpected(){return"string"}}var u8=new wT;class CT extends o0{_tag="Number";getParser(){return oX(this,o9)}matchKey(X,Y){return this._match(lf,X,Y)}matchPart(X,Y){return this._match(qK,X,Y)}_match(X,Y,Q){return X.test(Y)?p3(this,globalThis.Number(Y),Q):void 0}toCodecJson(){if(this.checks&&(BK(this.checks,"effect/schema/isFinite")||BK(this.checks,"effect/schema/isInt")))return this;return R0(this,[vf(this.checks)])}toCodecStringTree(){if(this.toCodecJson()===this)return R0(this,[of]);return R0(this,[rf])}getExpected(){return"number"}}function BK(X,Y){return X.some((Q)=>Q.annotations?.representation?.id===Y||Q._tag==="FilterGroup"&&BK(Q.checks,Y))}function vf(X){let Y=X===void 0?M3:lX(M3,X);return new h0(new XX([Y,yT],"anyOf"),new V0(T3(),Y0((Q)=>globalThis.Number.isFinite(Q)?Q:globalThis.String(Q))))}var AK=new CT;class MT extends o0{_tag="Boolean";getParser(){return oX(this,LD)}getExpected(){return"boolean"}}var IT=new MT;class jT extends o0{_tag="Symbol";getParser(){return oX(this,IJ)}matchKey(X,Y){return p3(this,X,Y)}toCodecStringTree(){return R0(this,[aT])}getExpected(){return"symbol"}}var ST=new jT;class vT extends o0{_tag="BigInt";getParser(){return oX(this,TD)}matchPart(X,Y){return zK.test(X)?p3(this,globalThis.BigInt(X),Y):void 0}toCodecStringTree(){return R0(this,[sf])}getExpected(){return"bigint"}}var xT=new vT;class cX extends o0{_tag="Arrays";isMutable;elements;rest;encodingChecks;constructor(X,Y,Q,_,G,J,Z,K){super(_,G,J,Z);this.isMutable=X,this.elements=Y,this.rest=Q,this.encodingChecks=K;let H=Y.findIndex(p0);if(H!==-1&&(Y.slice(H+1).some((W)=>!p0(W))||Q.length>1))throw Error("A required element cannot follow an optional element. ts(1257)");if(Q.length>1&&Q.slice(1).some(p0))throw Error("An optional element cannot follow a rest element. ts(1266)")}getParser(X){let Y=this,Q=Y.elements.map((W)=>({ast:W,parser:X(W)})),_=Y.rest.map((W)=>({ast:W,parser:X(W)})),G=Q.length,[J,...Z]=_,K=Z.length;function H(W,D){if(D<G)return Q[D];else if(D>=W)return Z[D-W];return J}return dY(function*(W,D){if(W._tag==="None")return W;let U=W.value;if(!Array.isArray(U))return yield*d(new l0(Y,W));let N=U.length,B={ast:Y,getParser:H,oinput:W,len:N,tailThreshold:kf(N,G,K),output:new globalThis.Array(N),issues:void 0,options:D},q=PK(D?.concurrency),O=xf(B,U,{concurrency:q?.concurrency,end:Y.rest.length===0?G:Math.max(N,G+K)});if(O)yield*O;if(Y.rest.length===0&&N>G)for(let R=G;R<=N-1;R++){let F=new M0([R],new q3(Y,U[R]));if(D.errors==="all")if(B.issues)B.issues.push(F);else B.issues=[F];else return yield*d(new T0(Y,W,[F]))}if(B.issues)return yield*d(new T0(Y,W,B.issues));return T(B.output)})}_rebuild(X,Y,Q){let _=W9(this.elements,X),G=W9(this.rest,X);return _===this.elements&&G===this.rest&&Y===this.checks&&Q===this.encodingChecks?this:new cX(this.isMutable,_,G,this.annotations,Y,void 0,this.context,Q)}recur(X){return this._rebuild(X,this.checks,this.encodingChecks)}flip(X){return this._rebuild(X,this.encodingChecks,this.checks)}getExpected(){return"array"}}var xf=EY()({onItem(X,Y,Q){let _=Q<X.len?T(Y):f();return X.getParser(X.tailThreshold,Q).parser(_,X.options)},step(X,Y,Q,_){if(Q._tag==="Failure")return C3(X,X.ast,_,Q);else if(Q.value._tag==="Some")X.output[_]=Q.value.value;else{let G=X.getParser(X.tailThreshold,_);if(p0(G.ast))return;let J=new M0([_],new $Q(G.ast.context?.annotations));if(X.options.errors==="all")if(X.issues)X.issues.push(J);else X.issues=[J];else return AY(new T0(X.ast,X.oinput,[J]))}}});function kf(X,Y,Q){return Math.max(Y,X-Q)}var PK=(X)=>{return X=X==="unbounded"?1/0:X??1,X>1?{concurrency:X}:void 0},C3=(X,Y,Q,_)=>{if(_.cause.reasons.length===0)return _;let G=O3(_.cause);if(G===void 0)return v8(a6(_.cause,(Z)=>new T0(Y,X.oinput,[new M0([Q],Z)])));let J=new M0([Q],G);if(X.options.errors==="all")if(X.issues)X.issues.push(J);else X.issues=[J];else return AY(new T0(Y,X.oinput,[J]))},I3="[+-]?\\d*\\.?\\d+(?:[Ee][+-]?\\d+)?";function D9(X,Y,Q=X5){let _,G;function J(Z){switch(Z._tag){case"String":case"TemplateLiteral":return(_??=Object.keys(X)).filter((K)=>Z.matchPart(K,Q)!==void 0);case"Number":return(_??=Object.keys(X)).filter((K)=>Z.matchKey(K,Q)!==void 0);case"Symbol":return(G??=Object.getOwnPropertySymbols(X)).filter((K)=>Z.matchKey(K,Q)!==void 0);case"Union":return[...new Set(Z.types.flatMap(J))];default:return[]}}return J(vK(L1(Y)))}class j3{name;type;constructor(X,Y){this.name=X,this.type=Y}}class S3{decode;encode;constructor(X,Y){this.decode=X,this.encode=Y}flip(){return new S3(this.encode,this.decode)}}function VK(X){switch(X._tag){case"String":case"Number":case"Symbol":case"TemplateLiteral":return!0;case"Union":return X.types.every(VK);default:return!1}}function bf(X){return VK(X)&&VK(L1(X))}class v3{parameter;type;merge;constructor(X,Y,Q){if(!bf(X))throw Error(`Invalid index signature parameter ${X._tag}`);if(this.parameter=X,this.type=Y,this.merge=Q,p0(Y)&&!oT(Y))throw Error("Cannot use `Schema.optionalKey` with index signatures, use `Schema.optional` instead.")}}class N9 extends o0{_tag="Objects";propertySignatures;indexSignatures;encodingChecks;constructor(X,Y,Q,_,G,J,Z){super(Q,_,G,J);this.propertySignatures=X,this.indexSignatures=Y,this.encodingChecks=Z;let K=X.map((H)=>H.name).filter((H,W,D)=>D.indexOf(H)!==W);if(K.length>0)throw Error(`Duplicate identifiers: ${JSON.stringify(K)}. ts(2300)`)}getParser(X){let Y=this,Q=[],_=new Set,G=[];for(let K of Y.propertySignatures)Q.push(K.name),_.add(K.name),G.push({ps:K,parser:X(K.type),name:K.name,type:K.type});let J=Y.indexSignatures.length;if(Y.propertySignatures.length===0&&Y.indexSignatures.length===0)return oX(Y,T_);let Z=J>0?EY()({onItem:dY(function*(K,[H,W]){let U=X(vK(W.parameter))(T(H),K.options),N=P1(U)?U:yield*mY(U);if(N._tag==="Failure"){let F=C3(K,Y,H,N);if(F)yield*F;return}let B=T(K.input[H]),O=X(W.type)(B,K.options),R=P1(O)?O:yield*mY(O);if(R._tag==="Failure"){let F=C3(K,Y,H,R);if(F)yield*F;return}else if(N.value._tag==="Some"&&R.value._tag==="Some"){let F=N.value.value;if(_.has(H)||_.has(F))return;let P=R.value.value;if(W.merge&&W.merge.decode&&Object.hasOwn(K.out,F)){let[C,w]=W.merge.decode.combine([F,K.out[F]],[F,P]);k(K.out,C,w)}else k(K.out,F,P)}}),step:(K,H,W)=>W._tag==="Failure"?W:void 0}):void 0;return dY(function*(K,H){if(K._tag==="None")return K;let W=K.value;if(!(typeof W==="object"&&W!==null&&!Array.isArray(W)))return yield*d(new l0(Y,K));let D={},U={ast:Y,oinput:K,input:W,out:D,issues:void 0,options:H},N=H.errors==="all",B=H.onExcessProperty==="error",q=H.onExcessProperty==="preserve",O;if(Y.indexSignatures.length===0&&(B||q)){O=Reflect.ownKeys(W);for(let P=0;P<O.length;P++){let C=O[P];if(!_.has(C))if(B){let w=new M0([C],new q3(Y,W[C]));if(N){if(U.issues)U.issues.push(w);else U.issues=[w];continue}else return yield*d(new T0(Y,K,[w]))}else k(D,C,W[C])}}let R=PK(H?.concurrency),F=gf(U,G,R);if(F)yield*F;if(Z){let P=X7();for(let w=0;w<J;w++){let L=Y.indexSignatures[w],E=D9(W,L.parameter,H);for(let j=0;j<E.length;j++){let t=E[j];P.push([t,L])}}let C=Z(U,P,R);if(C)yield*C}if(U.issues)return yield*d(new T0(Y,K,U.issues));if(H.propertyOrder==="original"){let P=(O??Reflect.ownKeys(W)).concat(Q),C={};for(let w of P)if(Object.hasOwn(D,w))k(C,w,D[w]);return T(C)}return T(D)})}_rebuild(X,Y,Q,_,G){let J=W9(this.propertySignatures,(K)=>{let H=X(K.type);return H===K.type?K:new j3(K.name,H)}),Z=W9(this.indexSignatures,(K)=>{let H=Y(K.parameter),W=X(K.type),D=Q?K.merge?.flip():K.merge;return H===K.parameter&&W===K.type&&D===K.merge?K:new v3(H,W,D)});return J===this.propertySignatures&&Z===this.indexSignatures&&_===this.checks&&G===this.encodingChecks?this:new N9(J,Z,this.annotations,_,void 0,this.context,G)}flip(X){return this._rebuild(X,X,!0,this.encodingChecks,this.checks)}recur(X,Y=X){return this._rebuild(X,Y,!1,this.checks,this.encodingChecks)}getExpected(){if(this.propertySignatures.length===0&&this.indexSignatures.length===0)return"object | array";return"object"}}var gf=EY()({onItem(X,Y){let Q=Object.hasOwn(X.input,Y.name)?T(X.input[Y.name]):f();return Y.parser(Q,X.options)},step(X,Y,Q){if(Q._tag==="Failure")return C3(X,X.ast,Y.name,Q);else if(Q.value._tag==="Some")k(X.out,Y.name,Q.value.value);else if(!p0(Y.type)){let _=new M0([Y.name],new $Q(Y.type.context?.annotations));if(X.options.errors==="all"){if(X.issues)X.issues.push(_);else X.issues=[_];return}else return AY(new T0(X.ast,X.oinput,[_]))}}});function wK(X,Y){if(!X)return Y;if(!Y)return X;return[...X,...Y]}function x3(X,Y,Q){return new N9(Reflect.ownKeys(X).map((_)=>{return new j3(_,X[_].ast)}),[],Q,Y)}function NQ(X){return X.ast}function CK(X,Y=void 0){return new cX(!1,X.map((Q)=>Q.ast),[],void 0,Y)}function k3(X,Y,Q){return new XX(X.map(NQ),Y,void 0,Q)}function kT(X,Y){if(X.encoding||Y.some((J)=>J.encoding))throw Error("StructWithRest does not support encodings");let{propertySignatures:Q,indexSignatures:_,checks:G}=X;for(let J of Y)Q=Q.concat(J.propertySignatures),_=_.concat(J.indexSignatures),G=wK(G,J.checks);return new N9(Q,_,void 0,G)}function bT(X,Y){if(X.encoding)throw Error("TupleWithRest does not support encodings");return new cX(X.isMutable,X.elements,Y,void 0,X.checks)}function gT(X){switch(X._tag){case"Null":return["null"];case"Undefined":return["undefined"];case"String":case"TemplateLiteral":return["string"];case"Number":return["number"];case"Boolean":return["boolean"];case"Symbol":case"UniqueSymbol":return["symbol"];case"BigInt":return["bigint"];case"Arrays":return["array"];case"ObjectKeyword":return["object","array","function"];case"Objects":return X.propertySignatures.length||X.indexSignatures.length?["object"]:["string","number","boolean","symbol","bigint","object","array","function"];case"Enum":return Array.from(new Set(X.enums.map(([,Y])=>typeof Y)));case"Literal":return[typeof X.literal];case"Union":return Array.from(new Set(X.types.flatMap(gT)));default:return["null","undefined","string","number","boolean","symbol","bigint","object","array","function"]}}function BQ(X){switch(X._tag){default:return[];case"Declaration":{let Y=X.annotations?.[QQ];return Array.isArray(Y)?Y:[]}case"Objects":return X.propertySignatures.flatMap((Y)=>{let Q=Y.type;if(!p0(Q)){if(w3(Q))return[{key:Y.name,literal:Q.literal}];if(Sf(Q))return[{key:Y.name,literal:Q.symbol}]}return[]});case"Arrays":return X.elements.flatMap((Y,Q)=>{return w3(Y)&&!p0(Y)?[{key:Q,literal:Y.literal}]:[]});case"Suspend":return BQ(X.thunk())}}var ZT=new WeakMap;function yf(X){let Y=ZT.get(X);if(Y)return Y;Y={};for(let Q=0;Q<X.length;Q++){let _=X[Q],G=L1(_);if(jf(G))continue;let J=gT(G),Z=BQ(G);Y.byType??={};for(let K of J)(Y.byType[K]??=[]).push(Q);if(Z.length>0){Y.bySentinel??=new Map;for(let{key:K,literal:H}of Z){let W=Y.bySentinel.get(K);if(!W)Y.bySentinel.set(K,W=new Map);let D=W.get(H);if(!D)W.set(H,D=[]);D.push(Q)}}else{Y.otherwise??={};for(let K of J)(Y.otherwise[K]??=[]).push(Q)}}return ZT.set(X,Y),Y}function KT(X){return(Y)=>{let Q=L1(Y);return Q._tag==="Literal"?Q.literal===X:Q._tag==="UniqueSymbol"?Q.symbol===X:!0}}function VQ(X,Y){let Q=yf(Y),_=X===null?"null":Array.isArray(X)?"array":typeof X;if(Q.bySentinel){let G=Q.otherwise?.[_]??[];if(_==="object"||_==="array"){let J=new Set(G);for(let[Z,K]of Q.bySentinel)if(Object.hasOwn(X,Z)){let H=K.get(X[Z]);if(H)for(let W of H)J.add(W)}return Array.from(J).sort((Z,K)=>Z-K).map((Z)=>Y[Z]).filter(KT(X))}return G.map((J)=>Y[J])}return(Q.byType?.[_]??[]).map((G)=>Y[G]).filter(KT(X))}class XX extends o0{_tag="Union";types;mode;encodingChecks;constructor(X,Y,Q,_,G,J,Z){super(Q,_,G,J);this.types=X,this.mode=Y,this.encodingChecks=Z}getParser(X){let Y=this;return(Q,_)=>{if(Q._tag==="None")return p(Q);let G=Q.value,J=VQ(G,Y.types),Z={ast:Y,recur:X,oinput:Q,input:G,out:void 0,successes:[],issues:void 0,options:_},K=PK(_?.concurrency),H=hf(Z,J,K?{...K,orderedStep:!0}:void 0);if(!H)return Z.out?p(Z.out):d(new z3(Y,G,Z.issues??[]));return hY(H,(W)=>{return Z.out?p(Z.out):d(new z3(Y,G,Z.issues??[]))})}}_rebuild(X,Y,Q){let _=W9(this.types,X);return _===this.types&&Y===this.checks&&Q===this.encodingChecks?this:new XX(_,this.mode,this.annotations,Y,void 0,this.context,Q)}recur(X){return this._rebuild(X,this.checks,this.encodingChecks)}flip(X){return this._rebuild(X,this.encodingChecks,this.checks)}matchPart(X,Y){for(let Q of this.types){let _=Q.matchPart(X,Y);if(_!==void 0)return _}return}getExpected(X){let Y=this.annotations?.expected;if(typeof Y==="string")return Y;if(this.types.length===0)return"never";let Q=this.types.map((_)=>{let G=L1(_);switch(G._tag){case"Arrays":{let J=G.elements.filter(w3);if(J.length>0)return`${HT(G.isMutable)}[ ${J.map((Z)=>X(Z)+WT(Z.context?.isOptional)).join(", ")}, ... ]`;break}case"Objects":{let J=G.propertySignatures.filter((Z)=>w3(Z.type));if(J.length>0)return`{ ${J.map((Z)=>`${HT(Z.type.context?.isMutable)}${x6(Z.name)}${WT(Z.type.context?.isOptional)}: ${X(Z.type)}`).join(", ")}, ... }`;break}}return X(G)});return Array.from(new Set(Q)).join(" | ")}}var hf=EY()({onItem(X,Y){return X.recur(Y)(X.oinput,X.options)},step(X,Y,Q){if(Q._tag==="Failure"){let _=O3(Q.cause);if(_===void 0)return Q;if(X.issues)X.issues.push(_);else X.issues=[_]}else{if(X.out&&X.ast.mode==="oneOf")return X.successes.push(Y),AY(new t2(X.ast,X.input,X.successes));if(X.out=Q.value,X.successes.push(Y),X.ast.mode==="anyOf")return Jq}}}),yT=new XX([new WX("Infinity"),new WX("-Infinity"),new WX("NaN")],"anyOf");function HT(X){return X?"":"readonly "}function WT(X){return X?"?":""}function Q5(X){let Y=!1,Q;return()=>{if(Y)return Q;return Q=X(),Y=!0,Q}}class b3 extends o0{_tag="Suspend";thunk;constructor(X,Y,Q,_,G){if(Q!==void 0)throw Error("Cannot add checks to Suspend");super(Y,void 0,_,G);this.thunk=Q5(X)}getParser(X){return X(this.thunk())}recur(X){return new b3(()=>X(this.thunk()),this.annotations,void 0,void 0,this.context)}getExpected(X){return X(this.thunk())}}class WQ extends N4{_tag="Filter";run;annotations;aborted;constructor(X,Y=void 0,Q=!1){super();this.run=X,this.annotations=Y,this.aborted=Q}annotate(X){return new WQ(this.run,{...this.annotations,...X},this.aborted)}abort(){return new WQ(this.run,this.annotations,!0)}and(X,Y){return new p8([this,X],Y)}}class p8 extends N4{_tag="FilterGroup";checks;annotations;constructor(X,Y=void 0){super();this.checks=X,this.annotations=Y}annotate(X){return new p8(this.checks,{...this.annotations,...X})}and(X,Y){return new p8([this,X],Y)}}function g3(X,Y,Q=!1){return new WQ((_,G,J)=>HL(_,G,X(_,G,J)),Y,Q)}function y3(X,Y){return new WQ((Q)=>X(Q)?void 0:new W0(T(Q)),Y,!0)}function MK(X){return g3((Y)=>globalThis.Number.isFinite(Y),{expected:"a finite number",representation:{id:"effect/schema/isFinite",payload:null},toJsonSchema:()=>({type:"number"}),toCode:()=>({runtime:"Schema.isFinite()"}),arbitrary:{constraint:{noInfinity:!0,noNaN:!0}},...X})}var M3=lX(AK,[MK()]);function qQ(X,Y){let Q=X.source;return g3((_)=>X.test(_),{expected:`a string matching the RegExp ${Q}`,representation:{id:"effect/schema/isPattern",payload:{source:Q,flags:X.flags}},toJsonSchema:()=>({pattern:Q}),arbitrary:{constraint:{patterns:[X.source]}},...Y})}function zQ(X,Y){let Q=Object.getOwnPropertyDescriptors(X);return Y(Q),Object.create(Object.getPrototypeOf(X),Q)}function R0(X,Y){if(X.encoding===Y)return X;return zQ(X,(Q)=>{Q.encoding.value=Y})}function OQ(X,Y){if(X.context===Y)return X;return zQ(X,(Q)=>{Q.context.value=Y})}function c8(X){return X.encoding?c8(X.encoding[X.encoding.length-1].to):X}function R6(X,Y){if(X.checks){let Q=X.checks[X.checks.length-1];return h3(X,e_(X.checks.slice(0,-1),Q.annotate(Y)))}return zQ(X,(Q)=>{Q.annotations.value={...Q.annotations.value,...Y}})}function h3(X,Y){if(X._tag==="Suspend"&&Y!==void 0)throw Error("Cannot add checks to Suspend");if(X.checks===Y)return X;return zQ(X,(Q)=>{Q.checks.value=Y})}function lX(X,Y){return h3(X,wK(X.checks,Y))}function l8(X,Y){let Q=Y(X.to);return Q===X.to?X:new h0(Q,X.transformation)}function hT(X,Y){let Q=X,_=Q[Q.length-1],G=l8(_,Y);return G===_?X:e_(X.slice(0,X.length-1),G)}function IK(X){return(Y)=>Y.encoding?R0(Y,hT(Y.encoding,X)):Y}function m3(X,Y){return IK((Q)=>OQ(Q,Y))(X)}function o8(X){function Y(Q){return Q.encoding?R0(Q,hT(Q.encoding,Y)):X(Q)}return a0(Y)}function mT(X,Y){return jK(X,Y,O1(X))}function dT(X,Y){return jK(L1(X),Y,X)}function jK(X,Y,Q){let _=new h0(X,Y);return R0(Q,Q.encoding?[...Q.encoding,_]:[_])}function fT(X,Y){let Q=YL(X),_=Q?[...Q,Y]:[Y];return R6(X,{brands:_})}function W9(X,Y){let Q=!1,_=Array(X.length);for(let G=0;G<X.length;G++){let J=X[G],Z=Y(J);if(Z!==J)Q=!0;_[G]=Z}return Q?_:X}function LQ(X,Y){let Q=X.context?new uX(X.context.isOptional,X.context.isMutable,X.context.defaultValue,{...X.context.annotations,...Y}):new uX(!1,!1,void 0,Y);return OQ(X,Q)}var mf=IK(TQ);function TQ(X){let Y=X.context?X.context.isOptional===!1?new uX(!0,X.context.isMutable,X.context.defaultValue,X.context.annotations):X.context:new uX(!0,!1);return mf(OQ(X,Y))}var df=IK(SK);function SK(X){let Y=X.context?X.context.isMutable===!1?new uX(X.context.isOptional,!0,X.context.defaultValue,X.context.annotations):X.context:new uX(!1,!0);return df(OQ(X,Y))}function pT(X,Y){let Q=new V0(ZQ(Y),fX()),_=[new h0(a4,Q)],G=X.context?new uX(X.context.isOptional,X.context.isMutable,_,X.context.annotations):new uX(!1,!1,_);return OQ(X,G)}function d3(X,Y,Q){return jK(X,Q,Y)}function ff(X){let Y=[],Q=[];function _(G){switch(G._tag){case"Literal":if(L_(G.literal))Y.push(G.literal);return;case"UniqueSymbol":Y.push(G.symbol);return;case"Never":return;case"Union":for(let J=0;J<G.types.length;J++)_(G.types[J]);return;default:Q.push(G)}}return _(X),{literals:Y,parameters:Q}}function uT(X,Y,Q){let{literals:_,parameters:G}=ff(X);return new N9(_.map((J)=>new j3(J,Y)),G.map((J)=>new v3(J,Y,Q)))}function p0(X){return X.context?.isOptional??!1}function cT(X){return X.context?.isMutable??!1}function lT(X){return X.annotations?.[t1]===!0||X._tag==="FilterGroup"&&X.checks.every(lT)}function pf(X){function Y(_){if(lT(_))return[_];return _._tag==="FilterGroup"?_.checks.flatMap(Y):[]}let Q=X.flatMap(Y);return W6(Q)?Q:void 0}var O1=a0((X)=>{if(X.encoding)return O1(R0(X,void 0));let Y=X,Q=Y.recur?.(O1)??Y,_=Q.encodingChecks;if(_){let G=Q===X?_:UQ(Q)||LK(Q)||e4(Q)&&Q.typeParameters.length>0?pf(_):void 0;return zQ(Q,(J)=>{J.encodingChecks.value=void 0,J.checks.value=wK(Q.checks,G)})}return Q}),L1=a0((X)=>{return O1(pX(X))});function uf(X,Y){let Q=Y,_=Q.length,G=Q[_-1],J=[new h0(pX(R0(X,void 0)),Q[0].transformation.flip())];for(let K=1;K<_;K++)J.unshift(new h0(pX(Q[K-1].to),Q[K].transformation.flip()));let Z=pX(G.to);if(Z.encoding)return R0(Z,[...Z.encoding,...J]);else return R0(Z,J)}var pX=a0((X)=>{if(X.encoding)return uf(X,X.encoding);let Y=X;return Y.flip?.(pX)??Y.recur?.(pX)??Y});function oT(X){switch(X._tag){case"Undefined":return!0;case"Union":return X.types.some(oT);default:return!1}}function f3(X,Y){let Q=gY(Y);return(_)=>{if(_._tag==="None")return mX;return _.value===Y?Q:d(new l0(X,_))}}function cf(X){let Y=gY(X);return(Q)=>Q._tag==="None"?mX:Y}function oX(X,Y){return(Q)=>{if(Q._tag==="None")return mX;return Y(Q.value)?p(Q):d(new l0(X,Q))}}function p3(X,Y,Q){if(Q?.disableChecks||X.checks===void 0)return Y;let _=[];return B9(X.checks,Y,_,X,Q),_.length===0?Y:void 0}function UT(X,Y,Q){let _=X.map((H)=>H._tag==="Literal"?globalThis.String(H.literal):void 0);if(_.some((H)=>H!==void 0&&!Y.includes(H)))return;let G=Array(X.length+1);G[X.length]=0;for(let H=X.length-1;H>=0;H--)G[H]=G[H+1]+(_[H]?.length??0);if(G[0]>Y.length)return;let J=Array(X.length),Z=X.map(()=>new Set);function K(H,W){if(H===X.length)return W===Y.length;if(Z[H].has(W))return!1;let D=X[H];if(H===X.length-1){let U=Y.slice(W);if(D.matchPart(U,Q)!==void 0)return J[H]=U,!0}else if(D._tag==="Literal"){let U=_[H];if(Y.startsWith(U,W)&&K(H+1,W+U.length))return J[H]=U,!0}else{let U=Y.length-G[H+1],N=_[H+1],B=N===void 0?U:Y.lastIndexOf(N,U);while(B>=W){let q=Y.slice(W,B);if(D.matchPart(q,Q)!==void 0&&K(H+1,B))return J[H]=q,!0;if(B===0)break;B=N===void 0?B-1:Y.lastIndexOf(N,B-1)}}return Z[H].add(W),!1}return K(0,0)?J:void 0}var rT=a0((X)=>{return new XX(X.enums.map((Y)=>new WX(Y[1],{title:Y[0]})),"anyOf")}),vK=o8((X)=>{switch(X._tag){default:return X;case"Number":return X.toCodecStringTree();case"Union":return X.recur(vK)}}),u3=o8((X)=>{switch(X._tag){default:return X;case"Symbol":case"UniqueSymbol":return X.toCodecStringTree();case"Union":return X.recur(u3)}}),iT=o8((X)=>{switch(X._tag){default:return X;case"Number":case"Literal":case"BigInt":return X.toCodecStringTree();case"Union":return X.recur(iT)}}),nT="[\\s\\S]*?",qK=new globalThis.RegExp(`^${I3}$`),lf=new globalThis.RegExp(`^(?:${I3}|Infinity|-Infinity|NaN)$`);function xK(X){return qQ(qK,{expected:"a string representing a finite number",representation:{id:"effect/schema/isStringFinite",payload:null},toJsonSchema:()=>({pattern:qK.source}),...X})}var sT=lX(u8,[xK()]),of=new h0(sT,H9),rf=new h0(new XX([sT,yT],"anyOf"),H9),nf="-?\\d+",zK=new globalThis.RegExp(`^${nf}$`);function kK(X){return qQ(zK,{expected:"a string representing a bigint",representation:{id:"effect/schema/isStringBigInt",payload:null},toJsonSchema:()=>({pattern:zK.source}),...X})}var bK=lX(u8,[kK({expected:"a string representing a bigint"})]),sf=new h0(bK,P3),af="Symbol\\((.*)\\)",OK=new globalThis.RegExp(`^${af}$`),tf=lX(u8,[gK()]),aT=new h0(tf,new V0(Y0((X)=>globalThis.Symbol.for(OK.exec(X)[1])),e1((X)=>{if(globalThis.Symbol.keyFor(X)!==void 0)return p(globalThis.String(X));return d(new $9(T(X),{message:"cannot serialize to string, Symbol is not registered"}))})));function gK(X){return qQ(OK,{expected:"a string representing a symbol",representation:{id:"effect/schema/isStringSymbol",payload:null},toJsonSchema:()=>({pattern:OK.source}),...X})}function B9(X,Y,Q,_,G){for(let J=0;J<X.length;J++){let Z=X[J];if(Z._tag==="FilterGroup")B9(Z.checks,Y,Q,_,G);else{let K=Z.run(Y,_,G);if(K){if(Q.push(new V3(Y,Z,K)),Z.aborted||G?.errors!=="all")return}}}}function tT(X,Y){let Q=[];if(B9(X,Y,Q,a4,{errors:"all"}),W6(Q)){let _=new T0(a4,T(Y),Q);return c(_)}return m(Y)}var c3="~effect/Schema/Class";function ef(X){return X===null||typeof X==="string"||typeof X==="boolean"||typeof X==="number"&&globalThis.Number.isFinite(X)}function Xp(X){return X===void 0||typeof X==="string"}function eT(X,Y){let Q=new WeakMap,_=[];X:while(!0){if(typeof X!=="object"||X===null){if(!Y(X))return!1}else{let G=X,J=Q.get(G);if(J===!1)return!1;if(J===void 0){let Z=Array.isArray(G);if(!Z){let K=Object.getPrototypeOf(G);if(K!==null&&K!==Object.prototype&&Object.getPrototypeOf(K)!==null)return!1}Q.set(G,!1),_.push({value:G,keys:Z?G.length:Object.keys(G),index:0})}}while(_.length>0){let G=_[_.length-1],J=G.keys;if(typeof J==="number"){if(G.index<J){X=G.value[G.index++];continue X}}else if(G.index<J.length){X=G.value[J[G.index++]];continue X}Q.set(G.value,!0),_.pop()}return!0}}function V9(X){return eT(X,ef)}var U9=new Y5([],()=>(X,Y)=>V9(X)?p(X):d(new l0(Y,T(X))),{representation:{id:"effect/schema/Json",payload:null},expected:"JSON value",toCodecJson:()=>{return},toCodecStringTree:()=>hK,toArbitrary:()=>(X)=>X.jsonValue()}),XR=R6(U9,{representation:{id:"effect/schema/MutableJson",payload:null}}),yK=new h0(U9,K9()),YR=new h0(new XX([new cX(!1,[],[U9]),new N9([],[new v3(u8,U9,void 0)])],"anyOf"),K9());function Yp(X){return eT(X,Xp)}var Qp=new Y5([],()=>(X,Y)=>Yp(X)?p(X):d(new l0(Y,T(X))),{expected:"StringTree",toCodecStringTree:()=>{return}}),hK=new h0(Qp,K9());var RQ="~effect/SchemaError/SchemaError";class i8 extends $Y("SchemaError"){[RQ]=RQ;constructor(X){super({issue:X})}get message(){return this.issue.toString()}toString(){return`SchemaError(${this.message})`}}function mK(X){return I(X,RQ)&&X[RQ]===RQ}var FQ=a0((X)=>{switch(X._tag){case"Declaration":{let Y=X.annotations?.[c3];if(u1(Y)){let Q=Y(X.typeParameters);return R0(X,[l8(Q,FQ)])}return X}case"Objects":case"Arrays":return X.recur((Y)=>{let Q=Y.context?.defaultValue;if(Q){let _=FQ(Y);return R0(_,_.encoding?[..._.encoding,...Q]:Q)}return FQ(Y)});case"Suspend":return X.recur(FQ);default:return X}});function o3(X){let Y=FQ(O1(X.ast)),Q=z9(Y);return(_,G)=>{return Q(_,G?.disableChecks?G?.parseOptions?{...G.parseOptions,disableChecks:!0}:{disableChecks:!0}:G?.parseOptions)}}function r3(X){let Y=o3(X);return(Q,_)=>{let G=b8(Y(Q,_));if(w1(G))return T(G.value);return _8(G.cause,"Option adapter can only return none for schema issues"),f()}}function QR(X){let Y=o3(X);return(Q,_)=>{let G=b8(Y(Q,_));if(w1(G))return G.value;let J=_8(G.cause,"Constructor adapter can only throw schema issues");throw Error(J.toString(),{cause:J})}}function _R(X){return EQ(X.ast)}function EQ(X){let Y=_5(z9(O1(X)));return(Q)=>{let _=Y(Q,X5);if(w1(_))return!0;return _8(_.cause,"Type guard adapter can only return false for schema issues"),!1}}function GR(X){let Y=z9(X);return(Q,_)=>{let G=b8(Y(Q,_));if(w1(G))return;return _8(G.cause,"Issue adapter can only return schema issues")}}function JR(X,Y){let _=_5(z9(O1(X.ast)))(Y,X5);if($q(_)){let G=_8(_.cause,"Assertion adapter can only throw schema issues");throw Error(G.toString(),{cause:G})}}function i0(X,Y){let Q=z9(X.ast);return Y===void 0?Q:(_,G)=>Q(_,DR(Y,G))}var dK=i0;function $R(X,Y){return _5(i0(X,Y))}function fK(X,Y){return NR(i0(X,Y))}var ZR=fK;function KR(X,Y){return BR(i0(X,Y))}function _p(X,Y){return VR(i0(X,Y))}var pK=_p;function q9(X,Y){let Q=z9(pX(X.ast));return Y===void 0?Q:(_,G)=>Q(_,DR(Y,G))}function HR(X,Y){return _5(q9(X,Y))}function uK(X,Y){return NR(q9(X,Y))}var WR=uK;function UR(X,Y){return BR(q9(X,Y))}function Gp(X,Y){return VR(q9(X,Y))}var cK=Gp,DR=(X,Y)=>Y===void 0?X:{...X,...Y};function z9(X){let Y=l3(X);return(Q,_)=>EX(Y(T(Q),_??X5),(G)=>{if(G._tag==="None")return d(new W0(G));return p(G.value)})}function _5(X){return(Y,Q)=>b8(X(Y,Q))}function NR(X){let Y=_5(X);return(Q,_)=>{let G=Y(Q,_);if(w1(G))return T(G.value);return _8(G.cause,"Option adapter can only return none for schema issues"),f()}}function BR(X){let Y=_5(X);return(Q,_)=>{let G=Y(Q,_);if(w1(G))return m(G.value);return c(_8(G.cause,"Result adapter can only return schema issues"))}}function VR(X){let Y=_5(X);return(Q,_)=>{let G=Y(Q,_);if(w1(G))return G.value;let J=_8(G.cause,"Sync adapter can only throw schema issues");throw Error(J.toString(),{cause:J})}}function Jp(X,Y){return p4(X,(Q)=>f4(()=>a6(Q,Y)))}var l3=a0((X)=>{let Y,Q=X.checks,_=X.encoding,G=_,J=G?.length??0,Z=X.encodingChecks,K=(Q?Q[Q.length-1].annotations:X.annotations)?.parseOptions;if(!X.context&&!_&&!Q&&!Z)return(H,W)=>{if(Y??=X.getParser(l3),K)W={...W,...K};return Y(H,W)};return(H,W)=>{if(K)W={...W,...K};let D;if(G){for(let B=J-1;B>=0;B--){let q=G[B],O=q.to,R=l3(O);if(D=D?EX(D,(F)=>R(F,W)):R(H,W),q.transformation._tag==="Transformation"){let F=q.transformation.decode;D=EX(D,(P)=>F.run(P,W))}else D=q.transformation.decode(D,W)}D=Jp(D,(B)=>new a2(X,H,B))}Y??=X.getParser(l3);let U=(B)=>{let q=Y(B,W);if(Z&&!W?.disableChecks)q=EX(q,(O)=>{if(W1(B)&&W1(O)){let R=[];if(B9(Z,B.value,R,X,W),W6(R))return d(new T0(X,B,R))}return p(O)});if(Q&&!W?.disableChecks)q=EX(q,(O)=>{if(W1(O)){let R=O.value,F=[];if(B9(Q,R,F,X,W),W6(F))return d(new T0(X,O,F))}return p(O)});return q};return D?EX(D,U):U(H)}});var i3="~effect/Schema/Schema";function YX(X,Y,Q){return{id:X,payloadSchema:Y,revive:Q}}function n(X,Y,Q){return{id:X,payloadSchema:Y,revive:Q}}var $p={[i3]:i3,pipe(){return G0(this,arguments)},annotate(X){return this.rebuild(R6(this.ast,X))},annotateKey(X){return this.rebuild(LQ(this.ast,X))},check(...X){return this.rebuild(lX(this.ast,X))}};function AQ(X,Y){function Q(){}let _=Object.defineProperties(Object.setPrototypeOf(Q,$p),Object.getOwnPropertyDescriptors({...Y}));_.ast=X,_.rebuild=(J)=>AQ(J,Y);let G=o3(_);return _.makeEffect=(J,Z)=>n3(G(J,Z)),_.make=QR(_),_.makeOption=r3(_),_}function n3(X){return p4(X,(Y)=>f4(()=>a6(Y,(Q)=>new i8(Q))))}var Q30=globalThis.Boolean;var qR=m6((X,Y)=>X||Y,!1);var zR=V(2,(X,Y)=>{return rK(X,(Q,_)=>Y.includes(Q)?[Q,_]:void 0)}),OR=V(2,(X,Y)=>{return rK(X,(Q,_)=>!Y.includes(Q)?[Q,_]:void 0)}),LR=V(2,(X,Y)=>{return{...X,...Y}});var oK=V(2,(X,Y)=>{return rK(X,(Q,_)=>[Object.hasOwn(Y,Q)?Y[Q]:Q,_])});var C1=(X)=>X;function rK(X,Y){let Q={};for(let _ of Reflect.ownKeys(X)){if(!Object.prototype.propertyIsEnumerable.call(X,_))continue;let G=Y(_,X[_]);if(G){let[J,Z]=G;k(Q,J,Z)}}return Q}function TR(X,Y){let Q=Y?.omitKeyWhen??(()=>!1);return mD((_,G)=>{let J=Reflect.ownKeys(X),Z={};for(let K of J){let H=X[K].combine(_[K],G[K]);if(Q(H))continue;k(Z,K,H)}return Z})}function PQ(X){return m6((Y,Q)=>{if(Y===void 0)return Q;if(Q===void 0)return Y;return X.combine(Y,Q)},void 0)}function F6(X,Y){if(Y.length>0)X+=`
  at ${C_(Y)}`;return Error(X)}var RR=new WeakMap,FR=new WeakMap,ER=[];function kR(){return{warnings:[]}}function bR(X){return{warnings:X.warnings.slice()}}function J8(X){return Error(`Unable to derive an arbitrary for ${X}`)}var AR=([X],[Y])=>o(X,Y);function Wp(X,Y,Q){return Y.reduce((_,G)=>_.filter((J)=>G.run(J,X,X5)===void 0),Q)}function gR(X,Y){if(X?.minLength!==void 0&&X.maxLength!==void 0&&X.minLength>X.maxLength)throw J8(`${Y} constraints`)}function yR(X){return X===void 0||X.minLength===void 0&&X.maxLength===void 0?void 0:{...X.minLength!==void 0?{minLength:X.minLength}:{},...X.maxLength!==void 0?{maxLength:X.maxLength}:{}}}function nK(X,Y,Q,_){return _?X.uniqueArray(Y,{...Q,comparator:_}):X.array(Y,Q)}function PR(X,Y,Q,_=!1){let G=Y.constraint,J=yR(G);return gR(J,"array"),nK(X,Q,_?{...J,maxLength:J?.minLength??0}:J,G?.unique?o:void 0)}function s3(X,Y,Q,_){return Y.chain((G)=>G.length<Q?X.constant(G):_.map((J)=>[...G,...J]))}function wR(X,Y){return X.chain((Q)=>Y.map((_)=>({...Object.fromEntries(_),...Q})))}var Up=PQ(nq),Dp=PQ(sq),a3=PQ(qR),Np=PQ(BN()),Bp=TR({integer:a3,maxLength:Dp,minLength:Up,noInfinity:a3,noNaN:a3,patterns:Np,unique:a3},{omitKeyWhen:RD});function CR(X,Y,Q,_,G,J){if(_===void 0||Y===void 0)return _===void 0?[Y,Q]:[_,G];let Z=X(Y,_);return Z===J?[_,G]:Z===0?[Y,Q||G]:[Y,Q]}function Vp(X,Y){if(X===void 0)return Y;if(X.order!==Y.order)throw Error("Cannot merge ordered arbitrary constraints with different Order instances");let[Q,_]=CR(X.order,X.minimum,X.exclusiveMinimum,Y.minimum,Y.exclusiveMinimum,-1),[G,J]=CR(X.order,X.maximum,X.exclusiveMaximum,Y.maximum,Y.exclusiveMaximum,1);return{order:X.order,...Q!==void 0?{minimum:Q}:{},..._!==void 0?{exclusiveMinimum:_}:{},...G!==void 0?{maximum:G}:{},...J!==void 0?{exclusiveMaximum:J}:{}}}function qp(X,Y){let{ordered:Q,..._}=X??{},{ordered:G,...J}=Y,Z=G===void 0?Q:Vp(Q,G);return{...Bp.combine(_,J),...Z===void 0?{}:{ordered:Z}}}function MR(X){let Y=[],Q=[];function _(G){if(G.annotations?.arbitrary)Q.push(G.annotations.arbitrary);if(G._tag!=="Filter")for(let J of G.checks)_(J);else Y.push(G)}return X?.forEach(_),{filters:Y,arbitraries:Q}}function zp(X){let Y=X.map(({constraint:Q})=>Q).filter(N1);return(Q)=>{let _=Y.reduce((G,J)=>qp(G,J),Q.constraint);return{...Q,constraint:_}}}function wQ(X){return{...X,constraint:void 0}}function IR(X,Y,Q){if(Y===void 0||Y.minLength===void 0&&Y.maxLength===void 0)return;if(Y.minLength!==void 0&&X.indexSignatures.length===0&&Y.minLength>X.propertySignatures.length)throw J8("object property constraints");let _={};if(Y.minLength!==void 0)_.minLength=Math.max(0,Y.minLength-Q);if(Y.maxLength!==void 0){if(_.maxLength=Y.maxLength-Q,_.maxLength<0)throw J8("object property constraints")}return gR(_,"object property"),_}function Op(X,Y,Q,_,G,J){let Z=_.length;if(J.maxLength!==void 0&&J.maxLength<Z)throw J8("object property constraints");let K=J.minLength===void 0?0:Math.max(0,J.minLength-Z),H=J.maxLength===void 0?G.length:Math.min(G.length,J.maxLength-Z);if(K>H)throw J8("object property constraints");let W=X.record(Y,{requiredKeys:[..._,...G]}),D=X.shuffledSubarray([...G],{minLength:K,maxLength:H});return X.tuple(W,D).map(([U,N])=>{let B=new Set([..._,...N]),q={};for(let O of Q)if(B.has(O))k(q,O,U[O]);return q})}function hR(X,Y,Q,_){let G={};if(X?.minimum!==void 0)G.min=Y(X.minimum,X.exclusiveMinimum===!0);if(X?.maximum!==void 0)G.max=Q(X.maximum,X.exclusiveMaximum===!0);if(G.min!==void 0&&G.max!==void 0&&G.min>G.max)throw J8(_);return G}function Lp(X){return hR(X,(Y,Q)=>Q?Math.floor(Y)+1:Math.ceil(Y),(Y,Q)=>Q?Math.ceil(Y)-1:Math.floor(Y),"integer constraints")}function Tp(X,Y){let Q={...X?.noInfinity?{noDefaultInfinity:!0}:{},...X?.noNaN?{noNaN:!0}:{},...Y?.minimum!==void 0?{min:Y.minimum}:{},...Y?.exclusiveMinimum!==void 0?{minExcluded:Y.exclusiveMinimum}:{},...Y?.maximum!==void 0?{max:Y.maximum}:{},...Y?.exclusiveMaximum!==void 0?{maxExcluded:Y.exclusiveMaximum}:{}};if(Q.min!==void 0&&Q.max!==void 0&&(Q.min>Q.max||Q.min===Q.max&&(Q.minExcluded||Q.maxExcluded)))throw J8("number constraints");return Q}function Rp(X){return hR(X,(Y,Q)=>Q?Y+BigInt(1):Y,(Y,Q)=>Q?Y-BigInt(1):Y,"the ordered bigint constraints")}function O9(X,Y){let Q=(_,G,J=ER)=>X(_,G,J);return Q.terminal=(_,G,J=ER)=>Y(_,G,J),Q}function wX(X){return O9(X,X)}function jR(X,Y){let Q=FR.get(Y)??X.createDepthIdentifier();return FR.set(Y,Q),{maxDepth:2,depthIdentifier:Q}}function SR(X,Y){return Y.length===0?void 0:Y.length===1?Y[0]:X.oneof(...Y)}var Fp={noInfinity:!0,noNaN:!0};function Ep(X){return{...X,constraint:Fp}}function Ap(X,Y,Q){function _(G,J){let Z=G.annotations?.arbitrary,K=J||Z?.constraint!==void 0||Z?.candidate!==void 0;if(G._tag!=="Filter")for(let H of G.checks)_(H,K);else if(!K){let H=G.annotations?.representation?.id??G.annotations?.identifier??G.annotations?.expected;X.warnings.push({_tag:"OpaqueFilter",path:Q,...H===void 0?{}:{description:H}})}}Y?.forEach((G)=>_(G,!1))}function mR(X,Y){let Q=new WeakSet;function _(G,J){if(Q.has(G))return;switch(Q.add(G),Ap(Y,G.checks,J),G._tag){case"Declaration":G.typeParameters.forEach((Z)=>_(Z,J));break;case"Arrays":{for(let[Z,K]of[...G.elements,...G.rest].entries())_(K,[...J,Z]);break}case"Objects":G.propertySignatures.forEach((Z)=>_(Z.type,[...J,Z.name])),G.indexSignatures.forEach((Z)=>{_(Z.parameter,J),_(Z.type,J)});break;case"Union":G.types.forEach((Z)=>_(Z,J));break;case"TemplateLiteral":G.parts.forEach((Z,K)=>_(L1(Z),[...J,K]));break;case"Suspend":_(G.thunk(),J);break}Q.delete(G)}_(X,[])}function Pp(X,Y,Q,_){let G=_===void 0?[]:[{arbitrary:_,weight:1}];for(let{candidate:J}of Q){if(!J)continue;let Z=J.make(X,Y);if(Z===void 0)continue;let K=J.weight??1;if(!globalThis.Number.isInteger(K)||K<=0)throw J8("a candidate with an invalid weight");G.push({arbitrary:Z,weight:K})}return G.length===0?void 0:G.length===1?G[0].arbitrary:X.oneof(...G)}function vR(X,Y,Q,_,G){let J=Pp(Q,_,Y.arbitraries,G);return J===void 0?void 0:Wp(X,Y.filters,J)}function wp(X,Y){if(!(typeof X==="object"&&X!==null&&("arbitrary"in X)))return{arbitrary:X,terminal:Y?void 0:X};let Q="terminal"in X?X.terminal:Y?void 0:X.arbitrary;return{arbitrary:X.arbitrary,terminal:Q}}function Cp(X,Y,Q,_,G){return X.map((J)=>({arbitrary:G?Y.constant(null).chain(()=>J(Y,Q,_)):J(Y,Q,_),terminal:J.terminal(Y,Q,_)}))}function xR(X,Y,Q,_){let G=zp(Y.arbitraries);return O9((J,Z,K)=>{let H=G(Z);return vR(X,Y,J,H,Q(J,Z,H,K))},(J,Z,K)=>{let H=G(Z);return vR(X,Y,J,H,_(J,Z,H,K))})}var sK=a0((X)=>CX(X,[]));function CX(X,Y){let Q=Q8(X)?.toArbitrary;if(Q){let _=e4(X)?X.typeParameters.map((Z)=>CX(Z,Y)):[],G=MR(X.checks),J=(Z)=>(K,H,W,D)=>wp(Q(Cp(_,K,wQ(H),D,Z))(K,W),_.length>0)[Z?"terminal":"arbitrary"];return xR(X,G,J(!1),J(!0))}if(X.checks){let _=MR(X.checks),G=CX(h3(X,void 0),Y);return xR(X,_,(J,Z,K,H)=>G(J,K,H),(J,Z,K,H)=>G.terminal(J,K,H))}return Mp(X,Y)}function Mp(X,Y){switch(X._tag){case"Never":case"Declaration":throw F6(`Unsupported AST ${X._tag}`,Y);case"Null":return wX((Q)=>Q.constant(null));case"Void":case"Undefined":return wX((Q)=>Q.constant(void 0));case"Unknown":case"Any":return wX((Q)=>Q.anything());case"String":return wX((Q,_)=>{let G=_.constraint,J=G?.patterns;return J?Q.oneof(...J.map((Z)=>Q.stringMatching(new RegExp(Z)))):Q.string(yR(G))});case"Number":return wX((Q,_)=>{let G=_.constraint,J=G?.ordered?.order===q1?G.ordered:void 0;return G?.integer?Q.integer(Lp(J)):Q.float(Tp(G,J))});case"Boolean":return wX((Q)=>Q.boolean());case"BigInt":return wX((Q,_)=>{let G=_.constraint?.ordered?.order===RX?_.constraint.ordered:void 0;return Q.bigInt(Rp(G))});case"Symbol":return wX((Q)=>Q.string().map(Symbol.for));case"Literal":return wX((Q)=>Q.constant(X.literal));case"UniqueSymbol":return wX((Q)=>Q.constant(X.symbol));case"ObjectKeyword":return wX((Q)=>Q.oneof(Q.object(),Q.array(Q.anything())));case"Enum":return CX(rT(X),Y);case"TemplateLiteral":{let Q=X.parts.map((_,G)=>CX(L1(_),[...Y,G]));return wX((_,G,J)=>_.tuple(...Q.map((Z)=>Z(_,Ep(G),J))).map((Z)=>Z.map((K)=>globalThis.String(K)).join("")))}case"Arrays":{let Q=X.elements.map((Z,K)=>({ast:Z,arbitrary:CX(Z,[...Y,K])})),_=X.elements.length,G=X.rest.map((Z,K)=>({ast:Z,arbitrary:CX(Z,[...Y,_+K])})),J=(Z,K,H)=>{let W=wQ(K),D=[],U=[],N=0;for(let P of Q){let C=P.arbitrary.terminal(Z,W,H);if(p0(P.ast)){U.push(C);continue}if(C===void 0)return;N++,D.push(C.map(T))}let B=K.constraint?.minLength??0,O=C8(G)&&B>N+U.length?U.length:Math.max(0,B-N),R=0;for(let P of U){if(R>=O||P===void 0){D.push(Z.constant(f()));continue}R++,N++,D.push(P.map(T))}if(R<O)return;let F=Z.tuple(...D).map(D$);if(C8(G)){let[P,...C]=G,w=X.elements.length===0?K:W,L=Math.max(0,B-N-C.length),E=L===0?void 0:P.arbitrary.terminal(Z,W,H);if(L>0&&E===void 0)return;let j=L===0?Z.constant([]):PR(Z,{...w,constraint:{...w.constraint,minLength:L}},E,!0);if(F=s3(Z,F,_,j),C.length>0){let t=[];for(let I1 of C){let $1=I1.arbitrary.terminal(Z,W,H);if($1===void 0)return;t.push($1)}let z0=Z.tuple(...t);F=s3(Z,F,_,z0)}}return F};return O9((Z,K,H)=>{let W=wQ(K),D=Q.map(({ast:N,arbitrary:B})=>{let q=B(Z,W,H);return p0(N)?q.chain((O)=>Z.boolean().map((R)=>R?T(O):f())):q.map(T)}),U=Z.tuple(...D).map(D$);if(C8(G)){let[N,...B]=G.map(({arbitrary:O})=>O(Z,W,H)),q=PR(Z,X.elements.length===0?K:W,N);if(U=s3(Z,U,_,q),B.length>0){let O=Z.tuple(...B);U=s3(Z,U,_,O)}}if(K.recursion){let N=J(Z,K,H);if(N!==void 0)return Z.oneof(K.recursion,N,U)}return U},J)}case"Objects":{let Q=X.propertySignatures.map((J)=>({ps:J,arbitrary:CX(J.type,[...Y,J.name])})),_=X.indexSignatures.map((J)=>({is:J,parameter:CX(J.parameter,Y),type:CX(J.type,Y)}));return O9((J,Z,K)=>{let H=wQ(Z),W={},D=[],U=[],N=[];for(let{ps:R,arbitrary:F}of Q){let P=R.name;if(D.push(P),p0(R.type))N.push(P);else U.push(P);k(W,P,F(J,H,K))}let B=Z.constraint;if(N.length>0&&_.length===0&&B!==void 0&&(B.minLength!==void 0||B.maxLength!==void 0))return Op(J,W,D,U,N,B);let q=J.record(W,{requiredKeys:U}),O=IR(X,Z.constraint,U.length);for(let{parameter:R,type:F}of _){let P=J.tuple(R(J,H,K),F(J,H,K)),C=nK(J,P,O,AR);q=wR(q,C)}return q},(J,Z,K)=>{let H=wQ(Z),W={},D=[],U=[];for(let{ps:R,arbitrary:F}of Q){let P=R.name,C=F.terminal(J,H,K);if(p0(R.type)){if(C!==void 0)U.push([P,C]);continue}if(C===void 0)return;D.push(P),k(W,P,C)}let N=Math.max(0,(Z.constraint?.minLength??0)-D.length);for(let[R,F]of U){if(N===0)break;N--,D.push(R),k(W,R,F)}if(N>0&&X.indexSignatures.length===0)return;let B=J.record(W,{requiredKeys:D}),q=IR(X,Z.constraint,D.length),O=q?.minLength??0;for(let{parameter:R,type:F}of _){let P;if(O===0)P=J.constant([]);else{let C=R.terminal(J,H,K),w=F.terminal(J,H,K);if(C===void 0||w===void 0)return;P=nK(J,J.tuple(C,w),{...q,maxLength:O},AR)}B=wR(B,P)}return B})}case"Union":{let Q=X.types.map((G)=>CX(G,Y)),_=(G,J,Z)=>SR(G,Q.map((K)=>K.terminal(G,J,Z)).filter(N1));return O9((G,J,Z)=>{let K=Q.map((W)=>W(G,J,Z));if(J.recursion){let W=_(G,J,Z);if(W!==void 0)return G.oneof(J.recursion,W,...K)}let H=SR(G,K);if(H===void 0)throw J8("a union with no members");return H},_)}case"Suspend":{let Q=RR.get(X);if(Q)return Q;let _=Q5(()=>CX(X.thunk(),Y)),G=O9((J,Z,K)=>{let H=jR(J,X),W={...Z,recursion:H},D=K.includes(X)?K:[...K,X],U=_().terminal(J,W,D);if(U===void 0)throw F6("Unable to derive an arbitrary for a recursive schema without a finite generation path",Y);return J.oneof(H,U,J.constant(null).chain(()=>_()(J,W,D)))},(J,Z,K)=>{if(K.includes(X))return;let H=jR(J,X);return _().terminal(J,{...Z,recursion:H},[...K,X])});return RR.set(X,G),G}}}var dR=a0((X)=>{return n8(X,[])});function n8(X,Y){let Q=Q8(X)?.toEquivalence;if(Q)return Q(e4(X)?X.typeParameters.map((_)=>n8(_,Y)):[]);switch(X._tag){case"Never":return dD();case"Declaration":case"Null":case"Undefined":case"Void":case"Unknown":case"Any":case"String":case"Number":case"Boolean":case"BigInt":case"Symbol":case"Literal":case"UniqueSymbol":case"ObjectKeyword":case"Enum":case"TemplateLiteral":return o;case"Arrays":{let _=X.elements.map((Z,K)=>n8(Z,[...Y,K])),G=X.elements.length,J=X.rest.map((Z,K)=>n8(Z,[...Y,G+K]));return H1((Z,K)=>{if(!Array.isArray(Z)||!Array.isArray(K))return!1;let H=Z.length;if(H!==K.length)return!1;let W=0;for(;W<Math.min(H,X.elements.length);W++)if(!_[W](Z[W],K[W]))return!1;if(J.length>0){let[D,...U]=J;for(;W<H-U.length;W++)if(!D(Z[W],K[W]))return!1;for(let N=0;N<U.length;N++)if(!U[N](Z[W+N],K[W+N]))return!1}return!0})}case"Objects":{if(X.propertySignatures.length===0&&X.indexSignatures.length===0)return o;let _=X.propertySignatures.map((J)=>n8(J.type,[...Y,J.name])),G=X.indexSignatures.map((J)=>n8(J.type,Y));return H1((J,Z)=>{if(!j1(J)||!j1(Z))return!1;for(let K=0;K<_.length;K++){let H=X.propertySignatures[K],W=H.name,D=Object.hasOwn(J,W),U=Object.hasOwn(Z,W);if(p0(H.type)){if(D!==U)return!1}if(D&&U&&!_[K](J[W],Z[W]))return!1}for(let K=0;K<G.length;K++){let H=X.indexSignatures[K],W=D9(J,H.parameter),D=D9(Z,H.parameter);if(W.length!==D.length)return!1;for(let U=0;U<W.length;U++){let N=W[U];if(!Object.hasOwn(Z,N)||!G[K](J[N],Z[N]))return!1}}return!0})}case"Union":{let _=O1(X).types,G=new Map(_.map((J,Z)=>[J,[EQ(J),n8(X.types[Z],Y)]]));return H1((J,Z)=>{let K=VQ(J,_);for(let H=0;H<K.length;H++){let[W,D]=G.get(K[H]);if(W(J)&&W(Z))return D(J,Z)}return!1})}case"Suspend":{let _=Q5(()=>n8(X.thunk(),Y));return H1((G,J)=>_()(G,J))}}}function t3(X){return X.replace(/~/g,"~0").replace(/\//g,"~1")}function fR(X){return X.replace(/~1/g,"/").replace(/~0/g,"~")}var W30=globalThis.RegExp;var L9=(X)=>X.replace(/[/\\^$*+?.()|[\]{}]/g,"\\$&");var Sp=new Set([...QL,YQ,...XL]);function CQ(X,Y){if(X===void 0)return;let Q={},_=X.title;if(typeof _==="string")Q.title=_;let{description:G,expected:J}=X;if(typeof G==="string")Q.description=G;else if(Y?.generateDescriptions===!0&&typeof J==="string")Q.description=J;let Z=X.default;if(V9(Z))Q.default=Z;let K=X.examples;if(Array.isArray(K)&&V9(K))Q.examples=K;let H=X.readOnly;if(typeof H==="boolean")Q.readOnly=H;let W=X.writeOnly;if(typeof W==="boolean")Q.writeOnly=W;let D=X.format;if(typeof D==="string")Q.format=D;let U=X.contentEncoding;if(typeof U==="string")Q.contentEncoding=U;let N=X.contentMediaType;if(typeof N==="string")Q.contentMediaType=N;let B=X.contentSchema;if(V9(B))Q.contentSchema=B;if(Y?.includeAnnotationKey!==void 0)for(let[q,O]of Object.entries(X)){if(Sp.has(q)||!Y.includeAnnotationKey(q))continue;if(V9(O))k(Q,q,O)}return Object.keys(Q).length===0?void 0:Q}function uR(X){let Y=X.type==="number"||X.type==="integer"?X.type:void 0,Q=X;if(Y!==void 0)Q={...X},delete Q.type;if(Array.isArray(Q.allOf)){let _=[],G=!1;for(let J of Q.allOf){let Z=uR(J);if(Z.type!==void 0){if(G=!0,Y===void 0||Z.type==="integer")Y=Z.type}if(Object.keys(Z.schema).length>0)_.push(Z.schema)}if(G){let{allOf:J,...Z}=Q;Q=_.length===0?Z:{...Z,allOf:_}}}return{type:Y,schema:Q}}function vp(X){return Array.isArray(X.anyOf)&&X.anyOf.length===4&&X.anyOf[0]?.type==="number"&&X.anyOf.slice(1).every((Y)=>Y.type==="string")}function e3(X,Y){if(Object.keys(X).length===0)return Y;let Q=Object.keys(Y);if(Q.length===0)return X;let _=X.type==="number"||X.type==="integer"?X.type:void 0,G=vp(X);if(_!==void 0||G){let Z=uR(Y);if(Z.type!==void 0){let K=_==="integer"||Z.type==="integer"?"integer":"number",H={...X,type:K};if(G)delete H.anyOf;return Object.keys(Z.schema).length===0?H:e3(H,Z.schema)}}let J=Array.isArray(Y.allOf)&&Q.length===1?Y.allOf:[Y];if(Array.isArray(X.allOf))return{...X,allOf:[...X.allOf,...J]};if(typeof X.$ref==="string")return{allOf:[X,...J]};return{...X,allOf:J}}function xp(X,Y,Q,_){let G={};for(let U of Object.keys(Q))k(G,U,H(Q[U],["references",U]));return{dialect:"draft-2020-12",schemas:U6(X,(U,N)=>H(U,Y[N])),definitions:G};function Z(U,N){return U?.schemas?.map((B,q)=>H(B,[...N,"schemas",q]))??[]}function K(U,N,B){let q=U.annotations,O=q?.toJsonSchema;if(O!==void 0){let P=Z(U.representation,[...B,"representation"]),C=O({type:N,schemas:P}),w=CQ(q,_);return w===void 0?C:{...C,...w}}if(U._tag==="Filter")return;let R=U.checks.map((P,C)=>K(P,N,[...B,"checks",C])).filter((P)=>P!==void 0);if(R.length===0)return;let F=CQ(q,_);return F===void 0?{allOf:R}:{allOf:R,...F}}function H(U,N){if(U._tag==="Reference"){if(!Object.hasOwn(Q,U.$ref))throw F6(`Invalid reference ${U.$ref}`,[...N,"$ref"]);return{$ref:`#/$defs/${t3(U.$ref)}`}}let B=W(U,N),q=CQ(U.annotations,_);if(q!==void 0)B={...B,...q};for(let O=0;O<U.checks.length;O++){let R=typeof B.type==="string"&&kp(B.type)?B.type:void 0,F=K(U.checks[O],R,[...N,"checks",O]);if(F!==void 0)B=e3(B,F)}return B}function W(U,N){switch(U._tag){case"Any":case"Unknown":return{};case"ObjectKeyword":return{anyOf:[{type:"object"},{type:"array"}]};case"Void":case"Undefined":case"Null":return{type:"null"};case"BigInt":return{type:"string",allOf:[{pattern:"^-?\\d+$"}]};case"Symbol":case"UniqueSymbol":return{type:"string",allOf:[{pattern:"^Symbol\\((.*)\\)$"}]};case"Declaration":return{};case"Suspend":return H(U.thunk,[...N,"thunk"]);case"Never":return{not:{}};case"String":return{type:"string"};case"Number":return{anyOf:[{type:"number"},{type:"string",enum:["NaN"]},{type:"string",enum:["Infinity"]},{type:"string",enum:["-Infinity"]}]};case"Boolean":return{type:"boolean"};case"Literal":{let B=U.literal;return typeof B==="bigint"?{type:"string",enum:[globalThis.String(B)]}:{type:typeof B,enum:[B]}}case"Enum":{let B=U.enums.map(([q,O])=>typeof O==="number"&&!globalThis.Number.isFinite(O)?{type:"string",enum:[globalThis.String(O)],title:q}:{type:typeof O,enum:[O],title:q});return B.length===0?{not:{}}:{anyOf:B}}case"TemplateLiteral":return{type:"string",pattern:`^${U.parts.map(XG).join("")}$`};case"Arrays":{if(U.rest.length>1)throw F6("Invalid schema representation document",[...N,"rest"]);let B={type:"array"},q=U.elements.length,O=U.elements.map((R,F)=>{if(R.isOptional)q--;let P=H(R.type,[...N,"elements",F,"type"]),C=CQ(R.annotations,_);return C===void 0?P:e3(P,C)});if(O.length>0){if(B.prefixItems=O,B.maxItems=U.elements.length,q>0)B.minItems=q}else B.items=!1;if(U.rest.length===1){delete B.maxItems;let R=H(U.rest[0],[...N,"rest",0]);if(Object.keys(R).length>0)B.items=R;else delete B.items}return B}case"Objects":{if(U.propertySignatures.length===0&&U.indexSignatures.length===0)return{anyOf:[{type:"object"},{type:"array"}]};let B={type:"object"},q={},O=[];for(let F=0;F<U.propertySignatures.length;F++){let P=U.propertySignatures[F];if(typeof P.name!=="string")throw F6("Invalid schema representation document",[...N,"propertySignatures",F,"name"]);let C=P.name,w=H(P.type,[...N,"propertySignatures",F,"type"]),L=CQ(P.annotations,_);if(k(q,C,L===void 0?w:e3(w,L)),!P.isOptional)O.push(C)}if(U.propertySignatures.length>0)B.properties=q;if(O.length>0)B.required=O;B.additionalProperties=_?.additionalProperties??!1;let R={};for(let F=0;F<U.indexSignatures.length;F++){let P=U.indexSignatures[F],C=H(P.type,[...N,"indexSignatures",F,"type"]);if(Object.keys(C).length===1&&"not"in C)C=!1;let w=D(P.parameter,[...N,"indexSignatures",F,"parameter"],new Set);if(w.length===0)B.additionalProperties=C;else for(let L of w)k(R,L,C)}if(Object.keys(R).length>0)B.patternProperties=R,delete B.additionalProperties;if(typeof B.additionalProperties==="object"&&B.additionalProperties!==null&&Object.keys(B.additionalProperties).length===0)delete B.additionalProperties;return B}case"Union":{let B=U.types.map((q,O)=>H(q,[...N,"types",O]));if(B.length===0)return{not:{}};if(B.length>1){let q=bp(B);if(q!==void 0)return q}return U.mode==="anyOf"?{anyOf:B}:{oneOf:B}}}}function D(U,N,B){switch(U._tag){case"Reference":{if(!Object.hasOwn(Q,U.$ref))throw F6(`Invalid reference ${U.$ref}`,[...N,"$ref"]);if(B.has(U.$ref))return[];let q=new Set(B).add(U.$ref);return D(Q[U.$ref],["references",U.$ref],q)}case"String":return cR(H(U,N));case"TemplateLiteral":return[`^${U.parts.map(XG).join("")}$`];case"Union":return U.types.flatMap((q,O)=>D(q,[...N,"types",O],B));default:throw F6("Invalid schema representation document",N)}}}function kp(X){return X==="string"||X==="number"||X==="boolean"||X==="array"||X==="object"||X==="null"||X==="integer"}function bp(X){let Y=void 0,Q=[];for(let _ of X){if(Object.keys(_).length!==2||_.type===void 0||!Array.isArray(_.enum)||_.enum.length===0)return;if(Y===void 0)Y=_.type;else if(_.type!==Y)return;Q.push(..._.enum)}return{type:Y,enum:Q}}function cR(X){let Y=[];if(typeof X.pattern==="string")Y.push(X.pattern);for(let Q of["allOf","anyOf","oneOf"]){let _=X[Q];if(Array.isArray(_)){for(let G of _)if(typeof G==="object"&&G!==null&&!Array.isArray(G))Y.push(...cR(G))}}return Y}function XG(X){switch(X._tag){case"Literal":return L9(globalThis.String(X.literal));case"String":return nT;case"Number":return I3;case"TemplateLiteral":return X.parts.map(XG).join("");case"Union":return X.types.map(XG).join("|");default:throw F6("Invalid schema representation document",[])}}function lR(X,Y){let Q=xp([X.representation],[["representation"]],X.references,Y);return{dialect:Q.dialect,schema:Q.schemas[0],definitions:Q.definitions}}function aK(X){let{references:Y,representations:Q}=yp([X]);return{representation:Q[0],references:Y}}function yp(X){return hp(X,[])}function rX(X){return X===void 0?void 0:{annotations:X}}function iR(X){return UQ(X)||LK(X)||DQ(X)&&X.types.some(iR)}function oR(X){let Y=f8(X);if(Y!==void 0)return{identifier:Y,isFallback:!1};let Q=D3(X);return Q===void 0?void 0:{identifier:`${Q}JsonEncoding`,isFallback:!0}}function rR(X,Y){if(X===Y)return!0;let Q=Reflect.ownKeys(X),_=Reflect.ownKeys(Y);if(Q.length!==_.length)return!1;for(let G of Q)if(G!=="context"&&X[G]!==Y[G])return!1;return!0}function hp(X,Y){let Q={},_=new Map,G=[],J=new Map,Z=new Set(Y.map((L)=>L.key)),K=new Set,H=new Set,W=new Set;for(let L of Y)J.set(L.key,L.body),_.set(L.original,L.key),_.set(L.encoded,L.key);for(let L of X)N(L);for(let L of Y)N(L.body);let D=U6(X,(L)=>q(L));for(let L of Y)k(Q,L.key,q(L.body,L.key));return{representations:D,references:Q};function U(L,E){let j=L,t=0;while(J.has(j))j=`${L}${++t}`;return J.set(j,E),j}function N(L){let E=c8(L);if(H.has(E)){if(iR(E))W.add(E);return}H.add(E);let j=oR(E);if(j!==void 0&&!j.isFallback){let t=J.get(j.identifier);if(t===void 0)J.set(j.identifier,E);else if(_.get(E)!==j.identifier&&!rR(t,E))throw Error(`Duplicate identifier: ${JSON.stringify(j.identifier)}`)}switch(B(E.checks),E._tag){case"Declaration":case"Arrays":case"Objects":case"Union":E.recur((t)=>{return N(t),t});break;case"TemplateLiteral":E.parts.forEach(N);break;case"Suspend":N(E.thunk());break}}function B(L){L?.forEach((E)=>{if(E.annotations?.representation?.schemas?.forEach((j)=>N(O1(j))),E._tag==="FilterGroup")B(E.checks)})}function q(L,E){let j=_.get(L);if(j!==void 0&&j!==E)return{_tag:"Reference",$ref:j};let t=c8(L);if(t!==L)return q(t,E);let z0=E===void 0?oR(L):void 0;if(z0!==void 0){let j0=O(z0,L);if(_.set(L,j0),!Object.hasOwn(Q,j0)&&!Z.has(j0))k(Q,j0,R(L));return{_tag:"Reference",$ref:j0}}if(E===void 0&&W.has(L)){let j0=U(`${L._tag}_`,L);return _.set(L,j0),k(Q,j0,R(L)),{_tag:"Reference",$ref:j0}}if(K.has(L)){let j0=U(`${L._tag}_`,L);return _.set(L,j0),{_tag:"Reference",$ref:j0}}K.add(L);let I1=R(L);K.delete(L);let $1=_.get(L);if($1!==void 0&&$1!==E)return k(Q,$1,I1),{_tag:"Reference",$ref:$1};return I1}function O(L,E){if(!L.isFallback)return L.identifier;for(let[t,z0]of G)if(rR(t,E))return z0;let j=U(L.identifier,E);return G.push([E,j]),j}function R(L){let E=F(L.checks);switch(L._tag){case"Declaration":return{_tag:"Declaration",typeParameters:L.typeParameters.map((j)=>q(j)),checks:E,...C(L.annotations)};case"Null":case"Undefined":case"Void":case"Never":case"Unknown":case"Any":case"String":case"Boolean":case"Number":case"BigInt":case"Symbol":case"ObjectKeyword":return{_tag:L._tag,checks:E,...rX(L.annotations)};case"Literal":return{_tag:"Literal",literal:L.literal,checks:E,...rX(L.annotations)};case"UniqueSymbol":return{_tag:"UniqueSymbol",symbol:L.symbol,checks:E,...rX(L.annotations)};case"Enum":return{_tag:"Enum",enums:L.enums,checks:E,...rX(L.annotations)};case"TemplateLiteral":return{_tag:"TemplateLiteral",parts:L.parts.map((j)=>q(j)),checks:E,...rX(L.annotations)};case"Arrays":return{_tag:"Arrays",elements:L.elements.map((j)=>{let t=c8(j),z0=t.context?.annotations;return{isOptional:p0(t),type:q(j),...rX(z0)}}),rest:L.rest.map((j)=>q(j)),checks:E,...rX(L.annotations)};case"Objects":return{_tag:"Objects",propertySignatures:L.propertySignatures.map((j)=>{let t=c8(j.type),z0=t.context?.annotations;return{name:j.name,type:q(j.type),isOptional:p0(t),isMutable:cT(t),...rX(z0)}}),indexSignatures:L.indexSignatures.map((j)=>({parameter:q(j.parameter),type:q(j.type)})),checks:E,...rX(L.annotations)};case"Union":return{_tag:"Union",types:L.types.map((j)=>q(j)),mode:L.mode,checks:E,...rX(L.annotations)};case"Suspend":return{_tag:"Suspend",checks:[],thunk:q(L.thunk()),...rX(L.annotations)}}}function F(L){return L?.map(P)??[]}function P(L){switch(L._tag){case"Filter":return{_tag:"Filter",aborted:L.aborted,...w(L.annotations)};case"FilterGroup":return{_tag:"FilterGroup",checks:U6(L.checks,P),...w(L.annotations)}}}function C(L){if(L===void 0)return;let{representation:E,...j}=L;return{...E===void 0?void 0:{representation:E},...Object.keys(j).length===0?void 0:{annotations:j}}}function w(L){if(L===void 0)return;let{representation:E,...j}=L,t=E===void 0?void 0:E.schemas===void 0?E:{...E,schemas:E.schemas.map((z0)=>q(O1(z0)))};return{...t===void 0?void 0:{representation:t},...Object.keys(j).length===0?void 0:{annotations:j}}}}function YG(X,Y){if(Object.is(X,Y))return[];let Q=[];if(Array.isArray(X)&&Array.isArray(Y)){let _=X.length,G=Y.length,J=Math.min(_,G);for(let Z=0;Z<J;Z++){let K=`/${Z}`,H=YG(X[Z],Y[Z]);for(let W of H)nR(W,K),Q.push(W)}for(let Z=_-1;Z>=G;Z--)Q.push({op:"remove",path:`/${Z}`});for(let Z=_;Z<G;Z++)Q.push({op:"add",path:`/${Z}`,value:Y[Z]});return Q}if(QG(X)&&QG(Y)){let _=Object.keys(X),G=Object.keys(Y),J=Array.from(new Set([..._,...G])).sort();for(let Z of J){let H=`/${t3(Z)}`,W=Object.hasOwn(X,Z),D=Object.hasOwn(Y,Z);if(W&&D){let U=YG(X[Z],Y[Z]);for(let N of U)nR(N,H),Q.push(N)}else if(!W&&D)Q.push({op:"add",path:H,value:Y[Z]});else if(W&&!D)Q.push({op:"remove",path:H})}return Q}return Q.push({op:"replace",path:"",value:Y}),Q}function aR(X,Y){let Q=Y;for(let _ of X)switch(_.op){case"replace":{Q=_.path===""?_.value:sR(Q,_.path,_.value,"replace");break}case"add":{Q=fp(Q,_.path,_.value);break}case"remove":{Q=sR(Q,_.path,void 0,"remove");break}}return Q}function nR(X,Y){X.path=X.path===""?Y:Y+X.path}function QG(X){return j1(X)}function dp(X){if(X==="")return[];if(X.charCodeAt(0)!==47)throw Error(`Invalid JSON Pointer, it must start with "/": ${A(X)}`);return X.split("/").slice(1).map(fR)}function tK(X){if(!/^(0|[1-9]\d*)$/.test(X))throw Error(`Invalid array index: "${X}"`);return Number(X)}function fp(X,Y,Q){if(Y==="")return Q;let _=tR(X,Y);if(_===null)throw Error(`Cannot add at "${Y}" (parent not found or not a container).`);let{lastToken:G,parent:J,stack:Z}=_;if(Array.isArray(J)){let K=G==="-"?J.length:tK(G);if(K<0||K>J.length)throw Error(`Array index out of bounds at "${Y}".`);let H=J.slice();return H.splice(K,0,Q),_G(Z,H)}if(QG(J)){let K={...J};return k(K,G,Q),_G(Z,K)}throw Error(`Cannot add at "${Y}" (parent not found or not a container).`)}function sR(X,Y,Q,_){if(Y===""){if(_==="remove"||Q===void 0)throw Error("Unsupported operation at the root");return Q}let G=tR(X,Y);if(G===null)throw Error(`Cannot ${_} at "${Y}" (parent not found or not a container).`);let{lastToken:J,parent:Z,stack:K}=G;if(Array.isArray(Z)){if(J==="-")throw Error(`"-" is not valid for ${_} at "${Y}".`);let H=tK(J);if(H<0||H>=Z.length)throw Error(`Array index out of bounds at "${Y}".`);let W=Z.slice();if(_==="remove")W.splice(H,1);else W[H]=Q;return _G(K,W)}if(QG(Z)){if(!Object.hasOwn(Z,J))throw Error(`Property "${J}" does not exist at "${Y}".`);let H={...Z};if(_==="remove")delete H[J];else k(H,J,Q);return _G(K,H)}throw Error(`Cannot ${_} at "${Y}" (parent not found or not a container).`)}function tR(X,Y){let Q=dp(Y);if(Q.length===0)return null;let _=Q[Q.length-1],G=[],J=X;for(let Z=0;Z<Q.length-1;Z++){let K=Q[Z];if(J==null)return null;if(Array.isArray(J)){let H=tK(K);if(H<0||H>=J.length)return null;G.push({container:J,token:H}),J=J[H];continue}if(J&&typeof J==="object"){if(!Object.hasOwn(J,K))return null;G.push({container:J,token:K}),J=J[K];continue}return null}return{stack:G,parent:J,lastToken:_}}function _G(X,Y){let Q=Y;for(let _=X.length-1;_>=0;_--){let{container:G,token:J}=X[_];if(Array.isArray(G)){let Z=G.slice();Z[J]=Q,Q=Z}else{let Z={...G};k(Z,J,Q),Q=Z}}return Q}var up=/^#\/\$defs(?=\/|$)/;function XF(X){return{dialect:"draft-07",schema:eR(X.schema),definitions:t_(X.definitions,eR)}}function eR(X){return Y(X);function Y(_){return Q(eK(_,(G)=>G.replace(up,"#/definitions")),!0)}function Q(_,G){if(Array.isArray(_))return _.map((W)=>Q(W,!1));if(!j1(_))return _;let J=_,Z={},K=void 0,H=void 0;for(let W of Object.keys(J)){let D=J[W];switch(W){case"$ref":case"type":case"required":case"enum":case"const":case"title":case"description":case"default":case"examples":case"format":case"pattern":case"minimum":case"maximum":case"exclusiveMinimum":case"exclusiveMaximum":case"minLength":case"maxLength":case"minItems":case"maxItems":case"minProperties":case"maxProperties":case"multipleOf":case"uniqueItems":Z[W]=D;break;case"properties":case"patternProperties":{let U=cp(D,Q);Z[W]=U??D;break}case"additionalProperties":case"propertyNames":Z[W]=Q(D,!1);break;case"allOf":case"anyOf":case"oneOf":Z[W]=Array.isArray(D)?D.map((U)=>Q(U,!1)):D;break;case"prefixItems":K=D;break;case"items":H=D;break;default:break}}if(K!==void 0)if(Array.isArray(K)){if(Z.items=K.map((W)=>Q(W,!1)),H!==void 0)Z.additionalItems=Q(H,!1)}else Z.items=Q(K,!1);else if(H!==void 0)Z.items=Q(H,!1);return Z}}function eK(X,Y){if(Array.isArray(X))return X.map((_)=>eK(_,Y));if(!j1(X))return X;let Q={};for(let _ of Object.keys(X)){let G=X[_];if(_==="$ref")k(Q,_,typeof G==="string"?Y(G):G);else if(Array.isArray(G)||j1(G))k(Q,_,eK(G,Y));else k(Q,_,G)}return Q}function cp(X,Y){if(!j1(X))return;let Q={};for(let _ of Object.keys(X))k(Q,_,Y(X[_],!1));return Q}function QF(X,Y){return iX(new $F(X,Y))}function YF(X,Y){return iX(new YH(X,Y))}class _F{_tag="IdentityNode"}var GF=new _F;class JF{_tag="CompositionNode";nodes;constructor(X){this.nodes=X}}class $F{_tag="IsoNode";get;set;constructor(X,Y){this.get=X,this.set=Y}}class YH{_tag="LensNode";get;set;constructor(X,Y){this.get=X,this.set=Y}}class ZF{_tag="PrismNode";get;set;constructor(X,Y){this.get=X,this.set=Y}}class QH{_tag="OptionalNode";get;set;constructor(X,Y){this.get=X,this.set=Y}}class _H{_tag="PathNode";path;constructor(X){this.path=X}}class JG{_tag="CheckNode";checks;constructor(X){this.checks=X}}function op(X,Y){let Q=X[X.length-1];if(Q){if(Q._tag==="PathNode"&&Y._tag==="PathNode"){X[X.length-1]=new _H([...Q.path,...Y.path]);return}if(Q._tag==="CheckNode"&&Y._tag==="CheckNode"){X[X.length-1]=new JG([...Q.checks,...Y.checks]);return}}X.push(Y)}function XH(X,Y){if(X._tag==="IdentityNode")return;if(X._tag==="CompositionNode"){for(let Q=0;Q<X.nodes.length;Q++)XH(X.nodes[Q],Y);return}op(Y,X)}function G5(X,Y){let Q=[];switch(XH(X,Q),XH(Y,Q),Q.length){case 0:return GF;case 1:return Q[0];default:return new JF(Q)}}function rp(X,Y){return iX(new QH(X,Y))}class MQ{node;getResult;replaceResult;constructor(X,Y,Q){this.node=X,this.getResult=Y,this.replaceResult=Q}replace(X,Y){return P8(this.replaceResult(X,Y),()=>Y)}modify(X){return(Y)=>P8(w8(this.getResult(Y),(Q)=>this.replaceResult(X(Q),Y)),()=>Y)}compose(X){return iX(G5(this.node,X.node))}key(X){return iX(G5(this.node,new _H([X])))}optionalKey(X){return iX(G5(this.node,new YH((Y)=>Y[X],(Y,Q)=>{let _=$G(Q);if(Y===void 0)if(Array.isArray(_)&&typeof X==="number")_.splice(X,1);else delete _[X];else k(_,X,Y);return _})))}check(...X){return iX(G5(this.node,new JG(X)))}refine(X,Y){return iX(G5(this.node,new JG([y3(X,Y)])))}tag(X){return iX(G5(this.node,new ZF((Y)=>Y._tag===X?m(Y):c(`Expected ${A(X)} tag, got ${A(Y._tag)}`),u)))}at(X,...Y){let Q=c(`Key ${A(X)} not found`);return iX(G5(this.node,new QH((_)=>Object.hasOwn(_,X)?m(_[X]):Q,(_,G)=>{if(Object.hasOwn(G,X)){let J=$G(G);return k(J,X,_),m(J)}else return Q})))}pick(X){return this.compose(YF(zR(X),(Y,Q)=>({...Q,...Y})))}omit(X){return this.compose(YF(OR(X),(Y,Q)=>({...Q,...Y})))}notUndefined(){return this.refine(N1,{expected:"a value other than `undefined`"})}forEach(X){let Y=X(ZG());return rp((Q)=>JX(this.getResult(Q),(_)=>{let G=[];for(let J=0;J<_.length;J++){let Z=Y.getResult(_[J]);if(t0(Z))G.push(Z.success)}return G}),(Q,_)=>w8(this.getResult(_),(G)=>{let J=[];for(let K=0;K<G.length;K++)if(t0(Y.getResult(G[K])))J.push(K);if(Q.length!==J.length)return c(`each: replacement length mismatch: ${Q.length} !== ${J.length}`);let Z=G.slice();for(let K=0;K<J.length;K++){let H=J[K],W=Y.replaceResult(Q[K],G[H]);if(Q0(W))return c(`each: could not set element ${H}`);Z[H]=W.success}return this.replaceResult(Z,_)}))}modifyAll(X){return(Y)=>P8(w8(this.getResult(Y),(Q)=>this.replaceResult(Q.map(X),Y)),()=>Y)}}class KF extends MQ{get;set;constructor(X,Y,Q){super(X,(_)=>m(Y(_)),(_)=>m(Q(_)));this.get=Y,this.set=Q}replace(X,Y){return this.set(X)}modify(X){return(Y)=>this.set(X(this.get(Y)))}}class HF extends MQ{get;constructor(X,Y,Q){super(X,(_)=>m(Y(_)),(_,G)=>m(Q(_,G)));this.get=Y,this.replace=Q}modify(X){return(Y)=>this.replace(X(this.get(Y)),Y)}}class WF extends MQ{set;constructor(X,Y,Q){super(X,Y,(_,G)=>m(Q(_)));this.set=Q}replace(X,Y){return this.set(X)}modify(X){return(Y)=>P8(JX(this.getResult(Y),(Q)=>this.set(X(Q))),()=>Y)}}function iX(X){let Y=UF(X);switch(Y._tag){case"IsoNode":return new KF(X,Y.get,Y.set);case"LensNode":return new HF(X,Y.get,Y.set);case"PrismNode":return new WF(X,Y.get,Y.set);case"OptionalNode":return new MQ(X,Y.get,Y.set)}}function $G(X){if(Array.isArray(X))return X.slice();if(typeof X==="object"&&X!==null){let Y=Object.getPrototypeOf(X);if(Y!==Object.prototype&&Y!==null)throw Error("Cannot clone object with non-Object constructor or null prototype");return{...X}}return X}var UF=a0((X)=>{switch(X._tag){case"IdentityNode":return{_tag:"IsoNode",get:u,set:u};case"IsoNode":case"LensNode":case"PrismNode":case"OptionalNode":return{_tag:X._tag,get:X.get,set:X.set};case"PathNode":return{_tag:"LensNode",get:(Y)=>{let Q=X.path,_=Y;for(let G=0,J=Q.length;G<J;G++)_=_[Q[G]];return _},set:(Y,Q)=>{let _=X.path,G=$G(Q),J=G,Z=0;for(;Z<_.length-1;Z++){let H=_[Z];k(J,H,$G(J[H])),J=J[H]}let K=_[Z];return k(J,K,Y),G}};case"CheckNode":return{_tag:"PrismNode",get:(Y)=>w4(tT(X.checks,Y),String),set:u};case"CompositionNode":{let Y=X.nodes.map(UF),Q=Y.reduce((_,G)=>ip(_,G._tag),"IsoNode");return{_tag:Q,get:(_)=>{for(let G=0;G<Y.length;G++){let J=Y[G],Z=J.get(_);if(GG(J._tag)){if(Q0(Z))return Z;_=Z.success}else _=Z}return GG(Q)?m(_):_},set:(_,G)=>{let J=G,Z=Y.length,K=Array(Z+1);K[0]=G;for(let H=0;H<Z;H++){let W=Y[H];if(GG(W._tag)){let D=W.get(G);if(Q0(D))return Q==="OptionalNode"?D:J;G=D.success}else G=W.get(G);K[H+1]=G}for(let H=Z-1;H>=0;H--){let W=Y[H];if(DF(W._tag))_=W.set(_);else if(W._tag==="LensNode")_=W.set(_,K[H]);else{let D=W.set(_,K[H]);if(Q0(D))return D;_=D.success}}return Q==="OptionalNode"?m(_):_}}}}});function GG(X){return X==="PrismNode"||X==="OptionalNode"}function DF(X){return X==="IsoNode"||X==="PrismNode"}function ip(X,Y){switch(X){case"IsoNode":return Y;case"LensNode":return GG(Y)?"OptionalNode":"LensNode";case"PrismNode":return DF(Y)?"PrismNode":"OptionalNode";case"OptionalNode":return"OptionalNode"}}var np=iX(GF);function ZG(){return np}var xG={};M6(xG,{webUrl:()=>Ha,webSegment:()=>eP,webQueryParameters:()=>Yw,webPath:()=>Xw,webFragments:()=>tP,webAuthority:()=>sP,uuid:()=>ss,uniqueArray:()=>H5,ulid:()=>us,uint8ClampedArray:()=>dP,uint8Array:()=>mP,uint32Array:()=>hP,uint16Array:()=>yP,tuple:()=>$0,toStringMethod:()=>tX,subarray:()=>ks,stringify:()=>r0,stringMatching:()=>sa,string:()=>s0,stream:()=>X4,statistics:()=>kl,sparseArray:()=>fP,shuffledSubarray:()=>bs,set:()=>pP,schedulerFor:()=>Ea,scheduler:()=>Fa,scheduledModelRun:()=>Ta,sample:()=>vl,resetConfigureGlobal:()=>gc,record:()=>oH,readConfigureGlobal:()=>aX,property:()=>mc,pre:()=>Uu,option:()=>H8,oneof:()=>G1,object:()=>Vs,noShrink:()=>MG,noBias:()=>wG,nat:()=>t8,modelRun:()=>Oa,mixedCase:()=>on,memo:()=>dn,maxSafeNat:()=>ki,maxSafeInteger:()=>wP,mapToConstant:()=>M9,map:()=>rH,lorem:()=>gn,limitShrink:()=>_t,letrec:()=>IP,jsonValue:()=>oP,json:()=>Ts,ipV6:()=>MP,ipV4Extended:()=>CP,ipV4:()=>TW,integer:()=>A0,int8Array:()=>gP,int32Array:()=>bP,int16Array:()=>kP,infiniteStream:()=>Es,hash:()=>CG,hasToStringMethod:()=>_W,hasCloneMethod:()=>Z5,hasAsyncToStringMethod:()=>GW,getDepthContextFor:()=>KW,gen:()=>ml,func:()=>ji,float64Array:()=>xP,float32Array:()=>vP,float:()=>EP,falsy:()=>No,entityGraph:()=>Mn,emailAddress:()=>mr,double:()=>SG,domain:()=>qW,dictionary:()=>DW,defaultReportMessage:()=>lA,date:()=>QP,createDepthIdentifier:()=>HW,context:()=>Vo,constantFrom:()=>A6,constant:()=>v0,configureGlobal:()=>bc,compareFunc:()=>Ci,compareBooleanFunc:()=>Pi,commands:()=>Na,cloneMethod:()=>J1,cloneIfNeeded:()=>A9,clone:()=>Po,check:()=>iA,chainUntil:()=>_P,boolean:()=>fQ,bigUint64Array:()=>Pa,bigInt64Array:()=>Aa,bigInt:()=>Y4,base64String:()=>js,asyncToStringMethod:()=>K8,asyncStringify:()=>JW,asyncProperty:()=>hc,asyncModelRun:()=>La,asyncDefaultReportMessage:()=>oA,assert:()=>jl,array:()=>w0,anything:()=>lP,__version:()=>Jt,__type:()=>Gt,__commitHash:()=>$t,VerbosityLevel:()=>dc,Value:()=>g,Stream:()=>Z0,Random:()=>$W,PreconditionFailure:()=>Q4,ExecutionStatus:()=>Kl,Arbitrary:()=>k0});var ap=class X{constructor(Y){this.seed=Y}clone(){return new X(this.seed)}next(){let Y=this.seed,Q=Math.imul(Y,214013)+2531011|0,_=Math.imul(Y,-1443076087)+505908858|0,G=Math.imul(Y,1170746341)+-755606699|0;this.seed=G;let J=(Q&-2147483649)>>16,Z=(_&-2147483649)>>16;return(G&-2147483649)>>16|Z<<15|J<<30}jump(){this.seed=Math.imul(this.seed,1994129409)+916127744&4294967295}getState(){return[this.seed]}};function NF(X){return new ap(X)}var tp=class X{constructor(Y,Q){this.states=Y,this.index=Q}clone(){return new X(this.states.slice(),this.index)}next(){let Y=this.states[this.index];return Y^=Y>>>11,Y^=Y<<7&2636928640,Y^=Y<<15&4022730752,Y^=Y>>>18,this.index=KG(this.states,this.index),Y}getState(){return[this.index,...this.states]}jump(){let Y=this.states.slice(),Q=this.index;this.index=KG(this.states,this.index);for(let _=19932;_>0;--_){if("SUSgbA\\W`E[]KN2RUSo8XVU?HKBFRl11E\\KoWOg5B]XEWG;BE;1:oVK[`B^Z9Qd23^XTnhL>]Unda4f[X;_j9H5QD=cN<5H`3bW>9bk1mjoI2fK0obmAAINOV:>Mek_V9dd<hZ\\gC3?Fm7FEk07QH_3PLm^@?^i\\QMkgP<]oLHmFnlecg5F@7U^@4jhZ?WZS0k@GHehmM36:5^9;>Hmm`co>k:KOSkSbIINb1VFf>LXgP>GUAQTD>Ci>XMGkUflLlb?_FaFUk@?5N7i70@;1o68ah@I<HFH7R2^J:G][Gf962ITWID9GWK8ElD2G5=DcHcL]cA]P2n7A=[<bInM;IHDQnJMReRXDWbVldnGEIPij`E08Xdci3@0c:IBbD4:Nk]?lEN9j^;T`0blZX7eiWE8c`<ak7j05FZi>AjUDh?M1B?^??FAXKThf<aBOXZf7jXYGK>R<;NHk3S9YhM7STJ6`:MIE`S@7298X8W>PNK=@;lLX<i\\TXLL<W@X[X54H]in8M;;n?kkQbajgAMY=Tf9b;ZKf0QUB2FHYWfnfkDoU9YkcLd95T>lK6GM1YL\\lid:J>KYS=iJ]Y>QlF>?R5_[5QeYC=66;A32Ac>OHk_ne^0g>bK:g;KFPgbGUcPR_Z=TX3H9d03bKZ2IhEPKBo>LSGWd0iFdV8C<Y:<>T[O6lC\\blaZ>GoAYP4clf^j1IfnZJ]QeDe2X<HE[LJNWnaCg[P]Co^:IRbWPY?97UePBlZNNHY6LOBM8P>=h?Ye:_f_Sb9Ki5GDYBF4dWeMfdg^ccPllNWM7G1\\UMdoYeOOD5^e@foA22G?ADYo5:FVG[bWo96;>3kc_c1Ab30>30;1@4F8g2hY?DJ4[LOL;ZLLKo2]jo>[KMDUcR279N_kF=3WL@Dd620bMTdA\\U9k``ef2iD9JgJ8CZBHS>F^Uk;<laeaeHS<15OSeS`PcSSKBRBFY]aQ=EgUXGNg=?d56`KA@2BejY0^[_DCX`L=CGMT=BW^6S1i@2ATBVk>3_ocRA>2U:4GPQ6o>5jX2HIcV3S@On6KB<[SKB?FC_AAji9agbBFkAi\\;4I\\UJ]c36Ub@[;gQACVGY<V]SDJBUU]La\\_a@JdOO8gm2T0DJMa:8Hf7>E]noQ[1Kambn??QQ]S?1i0oMGOijb\\aGY6lQ^CJ?9bFle8<eH4UUjBINX;n8@VOA5ah^URV49B[A?ONHhHAC1J5;;h0SXYlG^0W=eJdHh^K4SGe=1HZLLam;D<Q3AOdbPcdX``82\\jo0En8jRVGC73WMCF9`d:0heS?80?C188cSn7H9<daZ]MgS4Pb^1HkA:1PU^5>^h_g[RQV@PnYBRI_]`B]Bh@Uk03eXGY`I16L76H28X`R>IROMeNVUdU[:lghLhPCQZ:4a<30YBZCYnXe[?;jc8gKI2QH2MjnWBm4nGCZW`aVU2a;P<AMI25mlW_Nm][2?b6o851X@lAm]YZ`bWRF1g<Ga:T]1NXH5Veja5P9S9>:aNg:Th1Y=5o78K>LQ8hW@5S?I83Lk5Xk;j5@I3o[d:4RjE^oS30:WP9gC\\i8aSI>QRE@4lP:7lDg8g2`Ql[2I8aBU\\BQ?B4_clL9Q]S;^e1Ob5[>3JER2`c7B=o]fPOWO<DGi;Niba1PoWPPE_Q3aX0OB0mZej\\f_M[J4Y6]1`h2MkF[GiW8Q^d3^_=<I1N2Q7]2<2j[iP7V3V821FaI]A`93bC^Z\\G=WJ;^Ih?B97_iIF@\\Dl<eK1je8SNTWo_=XFMZH<<JYLZ^YQMPgYOV45K_:]kSI8^XlO0]GY=VUfe_C_F6TOcoAlVUH:o=WhhT@K`2KFhe<3\\KXQ>W:M?S_4S5d@J^`[AGA7@3]DnGSCO`\\?E8HT75^d9\\:m\\m1egIfk8cd6bD9\\eU8\\n[Pb0Cgd^S0n9kGJHb]i5XodlKHc34Fhi9K>0U5WK`>7Ff2^KL=WC6:kc?e5C^a1T1:4:^S5flXlGNIj08AfO?Dh7T7dWO>E]NI9?ob7B7P_h[4TEP[EU;GllFTnSmg9:\\[N]<SAoKP_kPlG56A:I3T6EG8Hj=XnUE`KT5U@OQ?]7[N^MFN1_NU4KO_3::Le`8IL9[1Z1H1;V3SC\\N3]S@4U[F2mhT5dYM7[4Pg_Na0_8WTH0`bgceQS8]EG;XgD4Ib4iLTP@kE79Mn>AYRJA1U5^Blhgno:aHVYc03c3J0Vc9FjEV^M75Zfd8kVC9>iJDk`AJ[6f7DK2D^DL\\AX:6b5h31XH;RQB\\N<ZSM=J;6L[`UW^eOIFc1Y]6_dfedIe4ARh72mTXC0WND_IDHVCZRDE0eODARCEETQI5TPUQE=jEH5bS?LP[ai`F5ABRYDo2o\\@=]GT?_9;hc4Lm:\\SF9k1T<0E@fX9BG[]g0nY7k[Qmi@la8`PF0j6@Q?Ii7bLkXQ<lLHf]`:DCh@9JY5>hEVLTdhL\\b1EB0lLh<=WaO@F<;8g<d:@e:LA:cFIEdmQh7hNHfSRToW?8N4:Z1K;XEDRO;OIDh<UdVln?bjgL>?VE98[B\\K<BVjkG8LiSX;fb>jf?DUK00Aih<WY6QD6cEnHBZ8iN_fd<G8Ci`11RUW2QlW]IXV:m?;J0GXXHfGNQ>:D`=fLPbO?VOTEYLj^cNj5PM>jKB5HVjJ4U7lXaTQNL9<@\\1`m\\Ug@VQHd7>jW=ca0`miF7;N0F=GjoQ`RFchKMGTmn8cF@Oh4GGCm7m2`U9j93Tb>=kSERjE_J939F01I1;`<ijk_=_Vn=7RVAI6fnQI5KlF:C44bN<<8K=Z<2TP<1]5?<dB>^LA=ebloE2Y2:9lkh0\\<YKbHD97iE`<C5oj^1>X:??`H6BXF2hG1Q[dF0Q=>W=J?7C\\k1T?<;R44oW?1hY^G8Zm]ZKnfOf0eCFYo6?=D8?<`6HU5SXh1;=:23LmV_FSi;OJfV<^?GkIDPISeHg1LaGE:V3Y3K3H<QJfbY?=;ldZRhnhQT_mGXDLFXXhSONE6Do_0iNZagB:BPGOTH;VhHUTd6LhQm^[;dO]5Hlkg<R:F<Kn\\:I:EGojgWZ2X@SYO_dlH;G8S<>oEKabY`:oU;=JW7ig?S?EYb86b7n8ce\\]IRa]koiWY<RfO;5kUI;7lVeC?[@ZaXDiF04B8R]bg@>O<mQDoUcBLcf^f>m2kMBUloD>Ze@NN^Z11TM`inXYhE_I=kA`:ZF4d\\>`L@;ZP[`ENU5cL[BV6\\Z?Di76:jg3hE6oG6jFc8kP=[GS1;WSedYQW1:U4\\OF32GgmMC<AjO]872bdBb`bKAA?8j78b>T3VfcUB2m4J^CPRU;8dScI]LU]^bBYA5_3:Y0N5i^?200000".charCodeAt(_/6|0)-48&1<<_%6)BF(this.states,this.index,Y,Q);this.index=KG(this.states,this.index)}BF(this.states,this.index,Y,Q)}};function BF(X,Y,Q,_){let G=0;if(_>=Y){for(;G<624-_;G++)X[G+Y]^=Q[G+_];for(;G<624-Y;G++)X[G+Y]^=Q[G+_-624];for(;G<624;G++)X[G+Y-624]^=Q[G+_-624]}else{for(;G<624-Y;G++)X[G+Y]^=Q[G+_];for(;G<624-_;G++)X[G+Y-624]^=Q[G+_];for(;G<624;G++)X[G+Y-624]^=Q[G+_-624]}}function KG(X,Y){if(Y<227){let Q=X[Y]&2147483648|X[Y+1]&2147483647;return X[Y]=X[Y+397]^Q>>>1^-(Q&1)&2567483615,Y+1}else if(Y<623){let Q=X[Y]&2147483648|X[Y+1]&2147483647;return X[Y]=X[Y+397-624]^Q>>>1^-(Q&1)&2567483615,Y+1}else{let Q=X[Y]&2147483648|X[0]&2147483647;return X[Y]=X[396]^Q>>>1^-(Q&1)&2567483615,0}}function ep(X){for(let Y=0;Y!==624;++Y)KG(X,Y)}function VF(X){let Y=[X|0];for(let Q=1;Q!==624;++Q){let _=Y[Q-1]^Y[Q-1]>>>30;Y.push(Math.imul(1812433253,_)+Q|0)}return ep(Y),new tp(Y,0)}var Xu=[1667051007,2321340297,1548169110,304075285],Yu=class X{constructor(Y,Q,_,G){this.s01=Y,this.s00=Q,this.s11=_,this.s10=G}clone(){return new X(this.s01,this.s00,this.s11,this.s10)}next(){let Y=this.s00^this.s00<<23,Q=this.s01^(this.s01<<23|this.s00>>>9),_=this.s10,G=this.s11,J=this.s00+_|0;return this.s01=G,this.s00=_,this.s11=Q^G^Q>>>18^G>>>5,this.s10=Y^_^(Y>>>18|Q<<14)^(_>>>5|G<<27),J}jump(){let Y=0,Q=0,_=0,G=0,J=this.s01,Z=this.s00,K=this.s11,H=this.s10;for(let W=0;W!==4;++W){let D=Xu[W];for(let U=1;U;U<<=1){if(D&U)Y^=J,Q^=Z,_^=K,G^=H;let N=Z^Z<<23,B=J^(J<<23|Z>>>9);J=K,Z=H,H=N^H^(N>>>18|B<<14)^(H>>>5|K<<27),K=B^K^B>>>18^K>>>5}}this.s01=Y,this.s00=Q,this.s11=_,this.s10=G}getState(){return[this.s01,this.s00,this.s11,this.s10]}};function GH(X){return new Yu(-1,~X,X|0,0)}var Qu=[3639956645,3750757012,1261568508,386426335],_u=class X{constructor(Y,Q,_,G){this.s01=Y,this.s00=Q,this.s11=_,this.s10=G}clone(){return new X(this.s01,this.s00,this.s11,this.s10)}next(){let Y=this.s00+this.s10|0,Q=this.s10^this.s00,_=this.s11^this.s01,G=this.s00,J=this.s01;return this.s00=G<<24^J>>>8^Q^Q<<16,this.s01=J<<24^G>>>8^_^(_<<16|Q>>>16),this.s10=_<<5^Q>>>27,this.s11=Q<<5^_>>>27,Y}jump(){let Y=0,Q=0,_=0,G=0,J=this.s01,Z=this.s00,K=this.s11,H=this.s10;for(let W=0;W!==4;++W){let D=Qu[W];for(let U=1;U;U<<=1){if(D&U)Y^=J,Q^=Z,_^=K,G^=H;let N=H^Z,B=K^J,q=Z,O=J;Z=q<<24^O>>>8^N^N<<16,J=O<<24^q>>>8^B^(B<<16|N>>>16),H=B<<5^N>>>27,K=N<<5^B>>>27}}this.s01=Y,this.s00=Q,this.s11=_,this.s10=G}getState(){return[this.s01,this.s00,this.s11,this.s10]}};function qF(X){return new _u(-1,~X,X|0,0)}function zF(X,Y){for(let Q=0;Q!==Y;++Q)X.next()}var OF=BigInt,Gu=4294967296n;function TF(X,Y,Q){let _=Q-Y+1n,G=Gu,J=1;while(G<_)G<<=32n,++J;let Z=LF(J,X);if(Z<_)return Z+Y;if(Z+_<G)return Z%_+Y;let K=G-G%_;while(Z>=K)Z=LF(J,X);return Z%_+Y}function LF(X,Y){let Q=OF(Y.next()+2147483648);for(let _=1;_<X;++_){let G=Y.next();Q=(Q<<32n)+OF(G+2147483648)}return Q}function IQ(X,Y){let Q=Y>2?~~(4294967296/Y)*Y:4294967296,_=X.next()+2147483648;while(_>=Q)_=X.next()+2147483648;return _%Y}function JH(X,Y){if(Y<0){let Q=-Y;X.sign=-1,X.data[0]=~~(Q/4294967296),X.data[1]=Q>>>0}else X.sign=1,X.data[0]=~~(Y/4294967296),X.data[1]=Y>>>0;return X}function Ju(X,Y,Q){let _=Y.data[1],G=Y.data[0],J=Y.sign,Z=Q.data[1],K=Q.data[0],H=Q.sign;if(X.sign=1,J===1&&H===-1){let O=_+Z,R=G+K+(O>4294967295?1:0);return X.data[0]=R>>>0,X.data[1]=O>>>0,X}let W=_,D=G,U=Z,N=K;if(J===-1)W=Z,D=K,U=_,N=G;let B=0,q=W-U;if(q<0)B=1,q=q>>>0;return X.data[0]=D-N-B,X.data[1]=q,X}function $u(X,Y,Q){let _=Q[0]+1;Y[0]=IQ(X,_),Y[1]=IQ(X,4294967296);while(Y[0]>=Q[0]&&(Y[0]!==Q[0]||Y[1]>=Q[1]))Y[0]=IQ(X,_),Y[1]=IQ(X,4294967296);return Y}var Zu=Number.MAX_SAFE_INTEGER,Ku={sign:1,data:[0,0]},Hu={sign:1,data:[0,0]},RF={sign:1,data:[0,0]},$H=[0,0];function Wu(X,Y,Q,_){let G=_<=Zu?JH(RF,_):Ju(RF,JH(Ku,Q),JH(Hu,Y));if(G.data[1]===4294967295)G.data[0]+=1,G.data[1]=0;else G.data[1]+=1;return $u(X,$H,G.data),$H[0]*4294967296+$H[1]+Y}function HG(X,Y,Q){let _=Q-Y;if(_<=4294967295)return IQ(X,_+1)+Y;return Wu(X,Y,Q,_)}var FF=Symbol.for("fast-check/PreconditionFailure"),Q4=class extends Error{constructor(X=!1){super();this.interruptExecution=X,this.footprint=FF}static isFailure(X){return X!==null&&X!==void 0&&X.footprint===FF}};function Uu(X){if(!X)throw new Q4}var Du=class{[Symbol.iterator](){return this}next(X){return{value:X,done:!0}}},Nu=new Du;function Bu(){return Nu}function*Vu(X,Y){for(let Q of X)yield Y(Q)}function*qu(X,Y){for(let Q of X)yield*Y(Q)}function*zu(X,Y){for(let Q of X)if(Y(Q))yield Q}function*Ou(X,Y){for(let Q=0;Q<Y;++Q){let _=X.next();if(_.done)break;yield _.value}}function*Lu(X,Y){let Q=X.next();while(!Q.done&&Y(Q.value))yield Q.value,Q=X.next()}function*Tu(X,Y){for(let Q=X.next();!Q.done;Q=X.next())yield Q.value;for(let Q of Y)for(let _=Q.next();!_.done;_=Q.next())yield _.value}var Ru=Symbol.iterator,Z0=class X{static nil(){return new X(Bu())}static of(...Y){return new X(Y[Ru]())}constructor(Y){this.g=Y}next(){return this.g.next()}[Symbol.iterator](){return this.g}map(Y){return new X(Vu(this.g,Y))}flatMap(Y){return new X(qu(this.g,Y))}dropWhile(Y){let Q=!1;function*_(G){if(Q||!Y(G))Q=!0,yield G}return this.flatMap(_)}drop(Y){if(Y<=0)return this;let Q=0;function _(){return Q++<Y}return this.dropWhile(_)}takeWhile(Y){return new X(Lu(this.g,Y))}take(Y){return new X(Ou(this.g,Y))}filter(Y){return new X(zu(this.g,Y))}every(Y){for(let Q of this.g)if(!Y(Q))return!1;return!0}has(Y){for(let Q of this.g)if(Y(Q))return[!0,Q];return[!1,null]}join(...Y){return new X(Tu(this.g,Y))}getNthOrLast(Y){let Q=Y,_=null;for(let G of this.g){if(Q--===0)return G;_=G}return _}};function X4(X){return new Z0(X)}var J1=Symbol.for("fast-check/cloneMethod");function Z5(X){return X!==null&&(typeof X==="object"||typeof X==="function")&&J1 in X&&typeof X[J1]==="function"}function A9(X){return Z5(X)?X[J1]():X}var Fu=Object.defineProperty,g=class{constructor(X,Y,Q){if(this.value_=X,this.context=Y,this.hasToBeCloned=Q!==void 0||Z5(X),this.readOnce=!1,this.value=X,this.hasToBeCloned)Fu(this,"value",{get:Q!==void 0?Q:this.getValue,enumerable:!1,configurable:!1})}getValue(){if(this.hasToBeCloned){if(!this.readOnce)return this.readOnce=!0,this.value_;return this.value_[J1]()}return this.value_}},k0=class{filter(X){return new Pu(this,X)}map(X,Y){return new Au(this,X,Y)}chain(X){return new Eu(this,X)}},Eu=class extends k0{constructor(X,Y){super();this.arb=X,this.chainer=Y}generate(X,Y){let Q=X.clone(),_=this.arb.generate(X,Y);return this.valueChainer(_,X,Q,Y)}canShrinkWithoutContext(X){return!1}shrink(X,Y){if(this.isSafeContext(Y))return(!Y.stoppedForOriginal?this.arb.shrink(Y.originalValue,Y.originalContext).map((Q)=>this.valueChainer(Q,Y.clonedMrng.clone(),Y.clonedMrng,Y.originalBias)):Z0.nil()).join(Y.chainedArbitrary.shrink(X,Y.chainedContext).map((Q)=>{let _={...Y,chainedContext:Q.context,stoppedForOriginal:!0};return new g(Q.value_,_)}));return Z0.nil()}valueChainer(X,Y,Q,_){let G=this.chainer(X.value_),J=G.generate(Y,_),Z={originalBias:_,originalValue:X.value_,originalContext:X.context,stoppedForOriginal:!1,chainedArbitrary:G,chainedContext:J.context,clonedMrng:Q};return new g(J.value_,Z)}isSafeContext(X){return X!==null&&X!==void 0&&typeof X==="object"&&"originalBias"in X&&"originalValue"in X&&"originalContext"in X&&"stoppedForOriginal"in X&&"chainedArbitrary"in X&&"chainedContext"in X&&"clonedMrng"in X}};function LA(X,Y){let Q=X.value,_=Y(Q);if(X.hasToBeCloned&&(typeof _==="object"&&_!==null||typeof _==="function")&&Object.isExtensible(_)&&!Z5(_))Object.defineProperty(_,J1,{get:()=>()=>LA(X,Y)[0]});return[_,Q]}function EF(X,Y){let[Q,_]=LA(X,Y);return new g(Q,{originalValue:_,originalContext:X.context})}var Au=class extends k0{constructor(X,Y,Q){super();this.arb=X,this.mapper=Y,this.unmapper=Q,this.bindValueMapper=(_)=>EF(_,Y)}generate(X,Y){let Q=this.arb.generate(X,Y);if(!Q.hasToBeCloned){let _=Q.value;return new g(this.mapper(_),{originalValue:_,originalContext:Q.context})}return EF(Q,this.mapper)}canShrinkWithoutContext(X){if(this.unmapper!==void 0)try{let Y=this.unmapper(X);return this.arb.canShrinkWithoutContext(Y)}catch{return!1}return!1}shrink(X,Y){if(this.isSafeContext(Y))return this.arb.shrink(Y.originalValue,Y.originalContext).map(this.bindValueMapper);if(this.unmapper!==void 0){let Q=this.unmapper(X);return this.arb.shrink(Q,void 0).map(this.bindValueMapper)}return Z0.nil()}isSafeContext(X){return X!==null&&X!==void 0&&typeof X==="object"&&"originalValue"in X&&"originalContext"in X}},Pu=class extends k0{constructor(X,Y){super();this.arb=X,this.refinement=Y,this.bindRefinementOnValue=(Q)=>this.refinementOnValue(Q)}generate(X,Y){while(!0){let Q=this.arb.generate(X,Y);if(this.refinementOnValue(Q))return Q}}canShrinkWithoutContext(X){return this.arb.canShrinkWithoutContext(X)&&this.refinement(X)}shrink(X,Y){return this.arb.shrink(X,Y).filter(this.bindRefinementOnValue)}refinementOnValue(X){return this.refinement(X.value)}};function TA(X){return typeof X==="object"&&X!==null&&"generate"in X&&"shrink"in X&&"canShrinkWithoutContext"in X}function RA(X){if(!TA(X))throw Error("Unexpected value received: not an instance of Arbitrary")}var FA=Function.prototype.apply,ZH=Symbol("apply");function wu(X){try{return X.apply}catch{return}}function Cu(X,Y,Q){let _=X;_[ZH]=FA;let G=_[ZH](Y,Q);return delete _[ZH],G}function N0(X,Y,Q){if(wu(X)===FA)return X.apply(Y,Q);return Cu(X,Y,Q)}var EA=Array,b=BigInt,Mu=BigInt64Array,Iu=BigUint64Array,AA=Boolean,AG=Date,y=Error,PA=Float32Array,wA=Float64Array,ju=Int8Array,Su=Int16Array,vu=Int32Array,$8=Number,d1=String,sX=Set,xu=Uint8Array,ku=Uint8ClampedArray,bu=Uint16Array,gu=Uint32Array,yu=encodeURIComponent,Z8=Map,zG=Symbol,AF=Array.prototype.forEach,PF=Array.prototype.indexOf,wF=Array.prototype.join,CF=Array.prototype.map,MF=Array.prototype.flat,IF=Array.prototype.filter,jF=Array.prototype.push,SF=Array.prototype.pop,vF=Array.prototype.splice,xF=Array.prototype.slice,kF=Array.prototype.sort,bF=Array.prototype.every;function hu(X){try{return X.forEach}catch{return}}function mu(X){try{return X.indexOf}catch{return}}function du(X){try{return X.join}catch{return}}function fu(X){try{return X.map}catch{return}}function pu(X){try{return X.flat}catch{return}}function uu(X){try{return X.filter}catch{return}}function cu(X){try{return X.push}catch{return}}function lu(X){try{return X.pop}catch{return}}function ou(X){try{return X.splice}catch{return}}function ru(X){try{return X.slice}catch{return}}function iu(X){try{return X.sort}catch{return}}function nu(X){try{return X.every}catch{return}}function CA(X,Y){if(hu(X)===AF)return X.forEach(Y);return N0(AF,X,[Y])}function kQ(X,...Y){if(mu(X)===PF)return X.indexOf(...Y);return N0(PF,X,Y)}function x0(X,...Y){if(du(X)===wF)return X.join(...Y);return N0(wF,X,Y)}function q0(X,Y){if(fu(X)===CF)return X.map(Y);return N0(CF,X,[Y])}function su(X,Y){if(pu(X)===MF)return[].flat(),X.flat(Y);return N0(MF,X,[Y])}function au(X,Y){if(uu(X)===IF)return X.filter(Y);return N0(IF,X,[Y])}function S(X,...Y){if(cu(X)===jF)return X.push(...Y);return N0(jF,X,Y)}function MA(X){if(lu(X)===SF)return X.pop();return N0(SF,X,[])}function IA(X,...Y){if(ou(X)===vF)return X.splice(...Y);return N0(vF,X,Y)}function _1(X,...Y){if(ru(X)===xF)return X.slice(...Y);return N0(xF,X,Y)}function jA(X,...Y){if(iu(X)===kF)return X.sort(...Y);return N0(kF,X,Y)}function SA(X,...Y){if(nu(X)===bF)return X.every(...Y);return N0(bF,X,Y)}var gF=Date.prototype.getTime,yF=Date.prototype.toISOString;function tu(X){try{return X.getTime}catch{return}}function eu(X){try{return X.toISOString}catch{return}}function PG(X){if(tu(X)===gF)return X.getTime();return N0(gF,X,[])}function Xc(X){if(eu(X)===yF)return X.toISOString();return N0(yF,X,[])}var hF=Set.prototype.add,mF=Set.prototype.has;function Yc(X){try{return X.add}catch{return}}function Qc(X){try{return X.has}catch(Y){return}}function bQ(X,Y){if(Yc(X)===hF)return X.add(Y);return N0(hF,X,[Y])}function a8(X,Y){if(Qc(X)===mF)return X.has(Y);return N0(mF,X,[Y])}var dF=WeakMap.prototype.set,fF=WeakMap.prototype.get;function _c(X){try{return X.set}catch(Y){return}}function Gc(X){try{return X.get}catch(Y){return}}function Jc(X,Y,Q){if(_c(X)===dF)return X.set(Y,Q);return N0(dF,X,[Y,Q])}function $c(X,Y){if(Gc(X)===fF)return X.get(Y);return N0(fF,X,[Y])}var pF=Map.prototype.set,uF=Map.prototype.get,cF=Map.prototype.has;function Zc(X){try{return X.set}catch(Y){return}}function Kc(X){try{return X.get}catch(Y){return}}function Hc(X){try{return X.has}catch(Y){return}}function nX(X,Y,Q){if(Zc(X)===pF)return X.set(Y,Q);return N0(pF,X,[Y,Q])}function NX(X,Y){if(Kc(X)===uF)return X.get(Y);return N0(uF,X,[Y])}function Wc(X,Y){if(Hc(X)===cF)return X.has(Y);return N0(cF,X,[Y])}var lF=String.prototype.split,oF=String.prototype.startsWith,rF=String.prototype.endsWith,iF=String.prototype.substring,nF=String.prototype.toLowerCase,sF=String.prototype.toUpperCase,aF=String.prototype.padStart,tF=String.prototype.charCodeAt,eF=String.prototype.normalize,XE=String.prototype.replace;function Uc(X){try{return X.split}catch{return}}function Dc(X){try{return X.startsWith}catch{return}}function Nc(X){try{return X.endsWith}catch{return}}function Bc(X){try{return X.substring}catch{return}}function Vc(X){try{return X.toLowerCase}catch{return}}function qc(X){try{return X.toUpperCase}catch{return}}function zc(X){try{return X.padStart}catch{return}}function Oc(X){try{return X.charCodeAt}catch{return}}function Lc(X){try{return X.normalize}catch(Y){return}}function Tc(X){try{return X.replace}catch{return}}function f1(X,...Y){if(Uc(X)===lF)return X.split(...Y);return N0(lF,X,Y)}function Rc(X,...Y){if(Dc(X)===oF)return X.startsWith(...Y);return N0(oF,X,Y)}function Fc(X,...Y){if(Nc(X)===rF)return X.endsWith(...Y);return N0(rF,X,Y)}function m0(X,...Y){if(Bc(X)===iF)return X.substring(...Y);return N0(iF,X,Y)}function SH(X){if(Vc(X)===nF)return X.toLowerCase();return N0(nF,X,[])}function eH(X){if(qc(X)===sF)return X.toUpperCase();return N0(sF,X,[])}function Ec(X,...Y){if(zc(X)===aF)return X.padStart(...Y);return N0(aF,X,Y)}function P9(X,Y){if(Oc(X)===tF)return X.charCodeAt(Y);return N0(tF,X,[Y])}function Ac(X,Y){if(Lc(X)===eF)return X.normalize(Y);return N0(eF,X,[Y])}function Pc(X,Y,Q){if(Tc(X)===XE)return X.replace(Y,Q);return N0(XE,X,[Y,Q])}var YE=Number.prototype.toString;function wc(X){try{return X.toString}catch{return}}function gQ(X,...Y){if(wc(X)===YE)return X.toString(...Y);return N0(YE,X,Y)}var Cc=Object.prototype.hasOwnProperty,Mc=Object.prototype.toString;function vA(X,Y){return N0(Cc,X,[Y])}function vH(X){return N0(Mc,X,[])}var Ic=Error.prototype.toString;function jc(X){return N0(Ic,X,[])}var Sc=class{constructor(X){this.producer=X}[Symbol.iterator](){if(this.it===void 0)this.it=this.producer();return this.it}next(){if(this.it===void 0)this.it=this.producer();return this.it.next()}};function e8(X){return new Sc(X)}var xA=Array.isArray,vc=Object.defineProperty;function XW(X,Y,Q){return vc(X,J1,{value:()=>{let _=[];for(let G=0;G!==Q.length;++G){let J=Q[G];if(J===void 0)J=new g(X[G],Y[G]);S(_,J.value)}return XW(_,Y,Q),_}})}function kA(X,Y,Q){let _=[],G=xA(Q)?Q:[];for(let J=0;J!==X.length;++J)S(_,e8(()=>X[J].shrink(Y[J],G[J]).map((Z)=>{let K=!1,H=[],W=[],D=[];for(let U=0;U!==X.length;++U){let N=U===J?Z:new g(A9(Y[U]),G[U]);if(N.hasToBeCloned)K=!0,D[U]=N;S(H,N.value),S(W,N.context)}if(K)XW(H,W,D);return new g(H,W)})));return Z0.nil().join(..._)}var xc=class extends k0{constructor(X){super();this.arbs=X;for(let Y=0;Y!==X.length;++Y){let Q=X[Y];if(Q===null||Q===void 0||Q.generate===null||Q.generate===void 0)throw Error(`Invalid parameter encountered at index ${Y}: expecting an Arbitrary`)}}generate(X,Y){let Q=!1,_=[],G=[],J=[];for(let Z=0;Z!==this.arbs.length;++Z){let K=this.arbs[Z].generate(X,Y);if(K.hasToBeCloned)Q=!0,J[Z]=K;S(_,K.value),S(G,K.context)}if(Q)XW(_,G,J);return new g(_,G)}canShrinkWithoutContext(X){if(!xA(X)||X.length!==this.arbs.length)return!1;for(let Y=0;Y!==this.arbs.length;++Y)if(!this.arbs[Y].canShrinkWithoutContext(X[Y]))return!1;return!0}shrink(X,Y){return kA(this.arbs,X,Y)}};function $0(...X){return new xc(X)}var kc=Math.log;function bA(X){return 2+~~(kc(X+1)*0.4342944819032518)}var YW={};function bc(X){YW=X}function aX(){return YW}function gc(){YW={}}var yQ=Symbol("UndefinedContextPlaceholder");function w9(X){if(X.context!==void 0)return X;if(X.hasToBeCloned)return new g(X.value_,yQ,()=>X.value);return new g(X.value_,yQ)}var QE=()=>{},yc=class{constructor(X,Y){this.arb=X,this.predicate=Y;let{asyncBeforeEach:Q,asyncAfterEach:_,beforeEach:G,afterEach:J}=aX()||{};if(Q!==void 0&&G!==void 0)throw y(`Global "asyncBeforeEach" and "beforeEach" parameters can't be set at the same time when running async properties`);if(_!==void 0&&J!==void 0)throw y(`Global "asyncAfterEach" and "afterEach" parameters can't be set at the same time when running async properties`);this.beforeEachHook=Q||G||QE,this.afterEachHook=_||J||QE}isAsync(){return!0}generate(X,Y){return w9(this.arb.generate(X,Y!==void 0?bA(Y):void 0))}shrink(X){if(X.context===void 0&&!this.arb.canShrinkWithoutContext(X.value_))return Z0.nil();let Y=X.context!==yQ?X.context:void 0;return this.arb.shrink(X.value_,Y).map(w9)}async runBeforeEach(){await this.beforeEachHook()}async runAfterEach(){await this.afterEachHook()}async run(X){try{let Y=await this.predicate(X);return Y===void 0||Y===!0?null:{error:new y("Property failed by returning false")}}catch(Y){if(Q4.isFailure(Y))return Y;return{error:Y}}}beforeEach(X){let Y=this.beforeEachHook;return this.beforeEachHook=()=>X(Y),this}afterEach(X){let Y=this.afterEachHook;return this.afterEachHook=()=>X(Y),this}},gA=class extends k0{constructor(X){super();this.arb=X}generate(X,Y){return w9(this.arb.generate(X,Y))}canShrinkWithoutContext(X){return!0}shrink(X,Y){if(Y===void 0&&!this.arb.canShrinkWithoutContext(X))return Z0.nil();let Q=Y!==yQ?Y:void 0;return this.arb.shrink(X,Q).map(w9)}};function hc(...X){if(X.length<2)throw Error("asyncProperty expects at least two parameters");let Y=_1(X,0,X.length-1),Q=X[X.length-1];return CA(Y,RA),new yc($0(...q0(Y,(_)=>new gA(_))),(_)=>Q(..._))}var _E=()=>{},yA=class{constructor(X,Y){this.arb=X,this.predicate=Y;let{beforeEach:Q=_E,afterEach:_=_E,asyncBeforeEach:G,asyncAfterEach:J}=aX()||{};if(G!==void 0)throw y(`"asyncBeforeEach" can't be set when running synchronous properties`);if(J!==void 0)throw y(`"asyncAfterEach" can't be set when running synchronous properties`);this.beforeEachHook=Q,this.afterEachHook=_}isAsync(){return!1}generate(X,Y){return w9(this.arb.generate(X,Y!==void 0?bA(Y):void 0))}shrink(X){if(X.context===void 0&&!this.arb.canShrinkWithoutContext(X.value_))return Z0.nil();let Y=X.context!==yQ?X.context:void 0;return this.arb.shrink(X.value_,Y).map(w9)}runBeforeEach(){this.beforeEachHook()}runAfterEach(){this.afterEachHook()}run(X){try{let Y=this.predicate(X);return Y===void 0||Y===!0?null:{error:new y("Property failed by returning false")}}catch(Y){if(Q4.isFailure(Y))return Y;return{error:Y}}}beforeEach(X){let Y=this.beforeEachHook;return this.beforeEachHook=()=>X(Y),this}afterEach(X){let Y=this.afterEachHook;return this.afterEachHook=()=>X(Y),this}};function mc(...X){if(X.length<2)throw Error("property expects at least two parameters");let Y=_1(X,0,X.length-1),Q=X[X.length-1];return CA(Y,RA),new yA($0(...q0(Y,(_)=>new gA(_))),(_)=>Q(..._))}var dc=function(X){return X[X.None=0]="None",X[X.Verbose=1]="Verbose",X[X.VeryVerbose=2]="VeryVerbose",X}({});function xH(X){if("unsafeNext"in X){if(X.unsafeJump===void 0)return{clone:()=>xH(X),next:()=>X.unsafeNext(),getState:()=>X.getState()};return{clone:()=>xH(X),next:()=>X.unsafeNext(),jump:()=>X.unsafeJump(),getState:()=>X.getState()}}return X}function hA(X){if("jump"in X&&typeof X.jump==="function")return X;return{clone:()=>hA(X),next:()=>X.next(),jump:()=>zF(X,42),getState:()=>X.getState()}}function jG(X){return hA(xH(X))}var fc=Date.now,pc=Math.min,uc=Math.random,cc=class{constructor(X){let Y=X||{};this.seed=lc(Y),this.randomType=oc(Y),this.numRuns=rc(Y),this.verbose=ic(Y),this.maxSkipsPerRun=Y.maxSkipsPerRun!==void 0?Y.maxSkipsPerRun:100,this.timeout=HH(Y.timeout),this.skipAllAfterTimeLimit=HH(Y.skipAllAfterTimeLimit),this.interruptAfterTimeLimit=HH(Y.interruptAfterTimeLimit),this.markInterruptAsFailure=Y.markInterruptAsFailure===!0,this.skipEqualValues=Y.skipEqualValues===!0,this.ignoreEqualValues=Y.ignoreEqualValues===!0,this.logger=Y.logger!==void 0?Y.logger:(Q)=>{console.log(Q)},this.path=Y.path!==void 0?Y.path:"",this.unbiased=Y.unbiased===!0,this.examples=Y.examples!==void 0?Y.examples:[],this.endOnFailure=Y.endOnFailure===!0,this.reporter=Y.reporter,this.asyncReporter=Y.asyncReporter,this.includeErrorInReport=Y.includeErrorInReport===!0}toParameters(){return{seed:this.seed,randomType:this.randomType,numRuns:this.numRuns,maxSkipsPerRun:this.maxSkipsPerRun,timeout:this.timeout,skipAllAfterTimeLimit:this.skipAllAfterTimeLimit,interruptAfterTimeLimit:this.interruptAfterTimeLimit,markInterruptAsFailure:this.markInterruptAsFailure,skipEqualValues:this.skipEqualValues,ignoreEqualValues:this.ignoreEqualValues,path:this.path,logger:this.logger,unbiased:this.unbiased,verbose:this.verbose,examples:this.examples,endOnFailure:this.endOnFailure,reporter:this.reporter,asyncReporter:this.asyncReporter,includeErrorInReport:this.includeErrorInReport}}};function KH(X){return(Y)=>{return jG(X(Y))}}function lc(X){if(X.seed===void 0)return fc()^uc()*4294967296;let Y=X.seed|0;if(X.seed===Y)return Y;return Y^(X.seed-Y)*4294967296}function oc(X){if(X.randomType===void 0)return GH;if(typeof X.randomType==="string")switch(X.randomType){case"mersenne":return KH(VF);case"congruential":case"congruential32":return KH(NF);case"xorshift128plus":return GH;case"xoroshiro128plus":return qF;default:throw Error(`Invalid random specified: '${X.randomType}'`)}let Y=X.randomType(0);if("min"in Y&&Y.min!==-2147483648)throw Error(`Invalid random number generator: min must equal -0x80000000, got ${String(Y.min)}`);if("max"in Y&&Y.max!==2147483647)throw Error(`Invalid random number generator: max must equal 0x7fffffff, got ${String(Y.max)}`);if(Y===jG(Y))return X.randomType;return KH(X.randomType)}function rc(X){if(X.numRuns!==void 0)return X.numRuns;if(X.num_runs!==void 0)return X.num_runs;return 100}function ic(X){if(X.verbose===void 0)return 0;if(typeof X.verbose==="boolean")return X.verbose===!0?1:0;if(X.verbose<=0)return 0;if(X.verbose>=2)return 2;return X.verbose|0}function HH(X){if(X===void 0)return;return pc(X,2147483647)}function QW(X){return new cc(X)}function nc(X,Y,Q){let _=null;return{clear:()=>Q(_),promise:new Promise((G)=>{_=Y(()=>{G(new Q4(!0))},X)})}}var GE=class{constructor(X,Y,Q,_,G,J){this.property=X,this.getTime=Y,this.interruptExecution=_,this.setTimeoutSafe=G,this.clearTimeoutSafe=J,this.skipAfterTime=this.getTime()+Q}isAsync(){return this.property.isAsync()}generate(X,Y){return this.property.generate(X,Y)}shrink(X){return this.property.shrink(X)}run(X){let Y=this.skipAfterTime-this.getTime();if(Y<=0){let Q=new Q4(this.interruptExecution);if(this.isAsync())return Promise.resolve(Q);else return Q}if(this.interruptExecution&&this.isAsync()){let Q=nc(Y,this.setTimeoutSafe,this.clearTimeoutSafe),_=Promise.race([this.property.run(X),Q.promise]);return _.then(Q.clear,Q.clear),_}return this.property.run(X)}runBeforeEach(){return this.property.runBeforeEach()}runAfterEach(){return this.property.runAfterEach()}},sc=(X,Y,Q)=>{let _=null;return{clear:()=>Q(_),promise:new Promise((G)=>{_=Y(()=>{G({error:new y(`Property timeout: exceeded limit of ${X} milliseconds`)})},X)})}},ac=class{constructor(X,Y,Q,_){this.property=X,this.timeMs=Y,this.setTimeoutSafe=Q,this.clearTimeoutSafe=_}isAsync(){return!0}generate(X,Y){return this.property.generate(X,Y)}shrink(X){return this.property.shrink(X)}async run(X){let Y=sc(this.timeMs,this.setTimeoutSafe,this.clearTimeoutSafe),Q=Promise.race([this.property.run(X),Y.promise]);return Q.then(Y.clear,Y.clear),Q}runBeforeEach(){return Promise.resolve(this.property.runBeforeEach())}runAfterEach(){return Promise.resolve(this.property.runAfterEach())}},mA=class{constructor(X){this.property=X}isAsync(){return this.property.isAsync()}generate(X,Y){return this.property.generate(X,void 0)}shrink(X){return this.property.shrink(X)}run(X){return this.property.run(X)}runBeforeEach(){return this.property.runBeforeEach()}runAfterEach(){return this.property.runAfterEach()}},JE=Array.from,$E=typeof Buffer<"u"?Buffer.isBuffer:void 0,T9=JSON.stringify,ZE=Number.isNaN,tc=Object.keys,ec=Object.getOwnPropertySymbols,Xl=Object.getOwnPropertyDescriptor,KE=Object.getPrototypeOf,HE=Number.NEGATIVE_INFINITY,Yl=Number.POSITIVE_INFINITY,tX=Symbol.for("fast-check/toStringMethod");function _W(X){return X!==null&&(typeof X==="object"||typeof X==="function")&&tX in X&&typeof X[tX]==="function"}var K8=Symbol.for("fast-check/asyncToStringMethod");function GW(X){return X!==null&&(typeof X==="object"||typeof X==="function")&&K8 in X&&typeof X[K8]==="function"}var Ql=/^Symbol\((.*)\)$/;function _l(X){if(X.description!==void 0)return X.description;let Y=Ql.exec(d1(X));return Y&&Y[1].length?Y[1]:null}function WE(X){switch(X){case 0:return 1/X===HE?"-0":"0";case HE:return"Number.NEGATIVE_INFINITY";case Yl:return"Number.POSITIVE_INFINITY";default:return X===X?d1(X):"Number.NaN"}}function Gl(X){let Y=-1;for(let Q in X){let _=Number(Q);if(_!==Y+1)return!0;Y=_}return Y+1!==X.length}function DX(X,Y,Q){let _=[...Y,X];if(typeof X==="object"){if(kQ(Y,X)!==-1)return"[cyclic]"}if(GW(X)){let G=Q(X);if(G.state==="fulfilled")return G.value}if(_W(X))try{return X[tX]()}catch{}switch(vH(X)){case"[object Array]":{let G=X;if(G.length>=50&&Gl(G)){let Z=[];for(let K in G)if(!ZE(Number(K)))S(Z,`${K}:${DX(G[K],_,Q)}`);return Z.length!==0?`Object.assign(Array(${G.length}),{${x0(Z,",")}})`:`Array(${G.length})`}let J=x0(q0(G,(Z)=>DX(Z,_,Q)),",");return G.length===0||G.length-1 in G?`[${J}]`:`[${J},]`}case"[object BigInt]":return`${X}n`;case"[object Boolean]":{let G=X==!0?"true":"false";return typeof X==="boolean"?G:`new Boolean(${G})`}case"[object Date]":{let G=X;return ZE(PG(G))?"new Date(NaN)":`new Date(${T9(Xc(G))})`}case"[object Map]":return`new Map(${DX(Array.from(X),_,Q)})`;case"[object Null]":return"null";case"[object Number]":return typeof X==="number"?WE(X):`new Number(${WE(Number(X))})`;case"[object Object]":{try{let J=X.toString;if(typeof J==="function"&&J!==Object.prototype.toString)return X.toString()}catch{return"[object Object]"}let G=(J)=>`${J==="__proto__"?'["__proto__"]':typeof J==="symbol"?`[${DX(J,_,Q)}]`:T9(J)}:${DX(X[J],_,Q)}`;return"{"+x0([...KE(X)===null?["__proto__:null"]:[],...q0(tc(X),G),...q0(au(ec(X),(J)=>{let Z=Xl(X,J);return Z&&Z.enumerable}),G)],",")+"}"}case"[object Set]":return`new Set(${DX(Array.from(X),_,Q)})`;case"[object String]":return typeof X==="string"?T9(X):`new String(${T9(X)})`;case"[object Symbol]":{let G=X;if(zG.keyFor(G)!==void 0)return`Symbol.for(${T9(zG.keyFor(G))})`;let J=_l(G);if(J===null)return"Symbol()";return G===(J.startsWith("Symbol.")&&zG[J.substring(7)])?J:`Symbol(${T9(J)})`}case"[object Promise]":{let G=Q(X);switch(G.state){case"fulfilled":return`Promise.resolve(${DX(G.value,_,Q)})`;case"rejected":return`Promise.reject(${DX(G.value,_,Q)})`;case"pending":return"new Promise(() => {/*pending*/})";default:return"new Promise(() => {/*unknown*/})"}}case"[object Error]":if(X instanceof Error)return`new Error(${DX(X.message,_,Q)})`;break;case"[object Undefined]":return"undefined";case"[object Int8Array]":case"[object Uint8Array]":case"[object Uint8ClampedArray]":case"[object Int16Array]":case"[object Uint16Array]":case"[object Int32Array]":case"[object Uint32Array]":case"[object Float32Array]":case"[object Float64Array]":case"[object BigInt64Array]":case"[object BigUint64Array]":{if(typeof $E==="function"&&$E(X))return`Buffer.from(${X.buffer.detached?"/*detached ArrayBuffer*/":DX(JE(X.values()),_,Q)})`;let G=KE(X),J=G&&G.constructor&&G.constructor.name;if(typeof J==="string"){let Z=X;if(Z.buffer.detached)return`${J}.from(/*detached ArrayBuffer*/)`;let K=Z.values();return`${J}.from(${DX(JE(K),_,Q)})`}break}}try{return X.toString()}catch{return vH(X)}}function r0(X){return DX(X,[],()=>({state:"unknown",value:void 0}))}function dA(X){let Y=zG(),Q=[],_=new Z8;function G(){let H=null,W=()=>{if(H!==null)clearTimeout(H)};return{delay:new Promise((D)=>{H=setTimeout(()=>{H=null,D(Y)},0)}),cancel:W}}let J={state:"unknown",value:void 0},Z=function(W){let D=W;if(_.has(D))return _.get(D);let U=G(),N=K8 in W?Promise.resolve().then(()=>W[K8]()):W;return N.catch(()=>{}),Q.push(Promise.race([N,U.delay]).then((B)=>{if(B===Y)_.set(D,{state:"pending",value:void 0});else _.set(D,{state:"fulfilled",value:B});U.cancel()},(B)=>{_.set(D,{state:"rejected",value:B}),U.cancel()})),_.set(D,J),J};function K(){let H=DX(X,[],Z);if(Q.length===0)return H;return Promise.all(Q.splice(0)).then(K)}return K()}async function JW(X){return Promise.resolve(dA(X))}function UE(X){return X===null?new Q4:X}function Jl(...X){if(X[1])return X[0].then(UE);return UE(X[0])}function $l(X,Y){return Jl(X,Y)}var DE=class{constructor(X,Y){this.property=X,this.skipRuns=Y,this.coveredCases=new Map}isAsync(){return this.property.isAsync()}generate(X,Y){return this.property.generate(X,Y)}shrink(X){return this.property.shrink(X)}run(X){let Y=r0(X);if(this.coveredCases.has(Y)){let _=this.coveredCases.get(Y);if(!this.skipRuns)return _;return $l(_,this.property.isAsync())}let Q=this.property.run(X);return this.coveredCases.set(Y,Q),Q}runBeforeEach(){return this.property.runBeforeEach()}runAfterEach(){return this.property.runAfterEach()}},NE=Date.now,WH=setTimeout,UH=clearTimeout;function Zl(X,Y){let Q=X;if(X.isAsync()&&Y.timeout!==void 0)Q=new ac(Q,Y.timeout,WH,UH);if(Y.unbiased)Q=new mA(Q);if(Y.skipAllAfterTimeLimit!==void 0)Q=new GE(Q,NE,Y.skipAllAfterTimeLimit,!1,WH,UH);if(Y.interruptAfterTimeLimit!==void 0)Q=new GE(Q,NE,Y.interruptAfterTimeLimit,!0,WH,UH);if(Y.skipEqualValues)Q=new DE(Q,!0);if(Y.ignoreEqualValues)Q=new DE(Q,!1);return Q}var Kl=function(X){return X[X.Success=0]="Success",X[X.Skipped=-1]="Skipped",X[X.Failure=1]="Failure",X}({}),Hl=class X{constructor(Y,Q){this.verbosity=Y,this.interruptedAsFailure=Q,this.rootExecutionTrees=[],this.currentLevelExecutionTrees=this.rootExecutionTrees,this.failure=null,this.numSkips=0,this.numSuccesses=0,this.interrupted=!1}appendExecutionTree(Y,Q){let _={status:Y,value:Q,children:[]};return this.currentLevelExecutionTrees.push(_),_}fail(Y,Q,_){if(this.verbosity>=1){let G=this.appendExecutionTree(1,Y);this.currentLevelExecutionTrees=G.children}if(this.pathToFailure===void 0)this.pathToFailure=`${Q}`;else this.pathToFailure+=`:${Q}`;this.value=Y,this.failure=_}skip(Y){if(this.verbosity>=2)this.appendExecutionTree(-1,Y);if(this.pathToFailure===void 0)++this.numSkips}success(Y){if(this.verbosity>=2)this.appendExecutionTree(0,Y);if(this.pathToFailure===void 0)++this.numSuccesses}interrupt(){this.interrupted=!0}isSuccess(){return this.pathToFailure===void 0}firstFailure(){return this.pathToFailure!==void 0?+f1(this.pathToFailure,":")[0]:-1}numShrinks(){return this.pathToFailure!==void 0?f1(this.pathToFailure,":").length-1:0}extractFailures(){if(this.isSuccess())return[];let Y=[],Q=this.rootExecutionTrees;while(Q.length>0&&Q[Q.length-1].status===1){let _=Q[Q.length-1];Y.push(_.value),Q=_.children}return Y}static mergePaths(Y,Q){if(Y.length===0)return Q;let _=Y.split(":"),G=Q.split(":"),J=+_[_.length-1]+ +G[0];return[..._.slice(0,_.length-1),`${J}`,...G.slice(1)].join(":")}toRunDetails(Y,Q,_,G){if(!this.isSuccess())return{failed:!0,interrupted:this.interrupted,numRuns:this.firstFailure()+1-this.numSkips,numSkips:this.numSkips,numShrinks:this.numShrinks(),seed:Y,counterexample:this.value,counterexamplePath:X.mergePaths(Q,this.pathToFailure),errorInstance:this.failure.error,failures:this.extractFailures(),executionSummary:this.rootExecutionTrees,verbose:this.verbosity,runConfiguration:G.toParameters()};let J=this.interruptedAsFailure||this.numSuccesses===0;return{failed:this.numSkips>_||this.interrupted&&J,interrupted:this.interrupted,numRuns:this.numSuccesses,numSkips:this.numSkips,numShrinks:0,seed:Y,counterexample:null,counterexamplePath:null,error:null,errorInstance:null,failures:[],executionSummary:this.rootExecutionTrees,verbose:this.verbosity,runConfiguration:G.toParameters()}}},fA=class{constructor(X,Y,Q,_){this.sourceValues=X,this.shrink=Y,this.runExecution=new Hl(Q,_),this.currentIdx=-1,this.nextValues=X}[Symbol.iterator](){return this}next(){let X=this.nextValues.next();if(X.done||this.runExecution.interrupted)return{done:!0,value:void 0};return this.currentValue=X.value,++this.currentIdx,{done:!1,value:X.value.value_}}handleResult(X){if(X!==null&&typeof X==="object"&&!Q4.isFailure(X))this.runExecution.fail(this.currentValue.value_,this.currentIdx,X),this.currentIdx=-1,this.nextValues=this.shrink(this.currentValue);else if(X!==null)if(!X.interruptExecution)this.runExecution.skip(this.currentValue.value_),this.sourceValues.skippedOne();else this.runExecution.interrupt();else this.runExecution.success(this.currentValue.value_)}},Wl=class{constructor(X,Y,Q){this.initialValues=X,this.maxInitialIterations=Y,this.remainingSkips=Q}[Symbol.iterator](){return this}next(){if(--this.maxInitialIterations!==-1&&this.remainingSkips>=0){let X=this.initialValues.next();if(!X.done)return{value:X.value,done:!1}}return{value:void 0,done:!0}}skippedOne(){--this.remainingSkips,++this.maxInitialIterations}},Ul=-2147483648,Dl=2147483647,Nl=Math.pow(2,27),Bl=Math.pow(2,-53),$W=class X{constructor(Y){this.internalRng=jG(Y.clone())}clone(){return new X(this.internalRng)}next(Y){return HG(this.internalRng,0,(1<<Y)-1)}nextBoolean(){return HG(this.internalRng,0,1)===1}nextInt(Y,Q){return HG(this.internalRng,Y===void 0?Ul:Y,Q===void 0?Dl:Q)}nextBigInt(Y,Q){return TF(this.internalRng,Y,Q)}nextDouble(){let Y=this.next(26),Q=this.next(27);return(Y*Nl+Q)*Bl}getState(){if("getState"in this.internalRng&&typeof this.internalRng.getState==="function")return this.internalRng.getState()}};function Vl(X,Y,Q){return Y.jump(),X.generate(new $W(Y),Q)}function*pA(X,Y,Q,_){for(let G=0;G!==_.length;++G)yield new g(_[G],void 0);for(let G=0,J=Q(Y);;++G)yield Vl(X,J,G)}function ql(X,Y,Q){return()=>X.generate(new $W(Y),Q)}function*uA(X,Y,Q,_){yield*q0(_,(Z)=>()=>new g(Z,void 0));let G=0,J=jG(Q(Y));for(;;)J.jump(),yield ql(X,J,G++)}function BE(X){return X()}function cA(X,Y,Q){let _=Y,G=X.split(":").map((Z)=>+Z);if(G.length===0)return _.map(BE);if(!G.every((Z)=>!Number.isNaN(Z)))throw Error(`Unable to replay, got invalid path=${X}`);let J=_.drop(G[0]).map(BE);for(let Z of G.slice(1)){let K=J.getNthOrLast(0);if(K===null)throw Error(`Unable to replay, got wrong path=${X}`);J=Q(K).drop(Z)}return J}var zl=Object.assign;function Ol(X){if(X.length===1)return`Hint: ${X[0]}`;return X.map((Y,Q)=>`Hint (${Q+1}): ${Y}`).join(`
`)}function Ll(X,Y){return`Encountered failures were:
- ${X.map(Y).join(`
- `)}`}function ZW(X,Y){let Q=[],_=[];for(let G=X.length-1;G>=0;--G)_.push({depth:1,tree:X[G]});while(_.length!==0){let G=_.pop(),J=G.tree,Z=G.depth,K=J.status===0?"\x1B[32m√\x1B[0m":J.status===1?"\x1B[31m×\x1B[0m":"\x1B[33m!\x1B[0m",H=Z!==0?". ".repeat(Z-1):"";Q.push(`${H}${K} ${Y(J.value)}`);for(let W=J.children.length-1;W>=0;--W)_.push({depth:Z+1,tree:J.children[W]})}return`Execution summary:
${Q.join(`
`)}`}function Tl(X,Y){let Q=`Failed to run property, too many pre-condition failures encountered
{ seed: ${X.seed} }

Ran ${X.numRuns} time(s)
Skipped ${X.numSkips} time(s)`,_=null,G=["Try to reduce the number of rejected values by combining map, chain and built-in arbitraries","Increase failure tolerance by setting maxSkipsPerRun to an higher value"];if(X.verbose>=2)_=ZW(X.executionSummary,Y);else S(G,"Enable verbose mode at level VeryVerbose in order to check all generated values and their associated status");return{message:Q,details:_,hints:G}}function Rl(X){if(X instanceof y&&X.stack!==void 0)return X.stack;try{return d1(X)}catch(Y){}if(X instanceof y)try{return jc(X)}catch(Y){}if(X!==null&&typeof X==="object")try{return vH(X)}catch(Y){}return"Failed to serialize errorInstance"}function Fl(X,Y){let Q=X.runConfiguration.includeErrorInReport?`
Got ${Pc(Rl(X.errorInstance),/^Error: /,"error: ")}`:"",_=`Property failed after ${X.numRuns} tests
{ seed: ${X.seed}, path: "${X.counterexamplePath}", endOnFailure: true }
Counterexample: ${Y(X.counterexample)}
Shrunk ${X.numShrinks} time(s)${Q}`,G=null,J=[];if(X.verbose>=2)G=ZW(X.executionSummary,Y);else if(X.verbose===1)G=Ll(X.failures,Y);else S(J,"Enable verbose mode in order to have the list of all failing values encountered during the run");return{message:_,details:G,hints:J}}function El(X,Y){let Q=`Property interrupted after ${X.numRuns} tests
{ seed: ${X.seed} }`,_=null,G=[];if(X.verbose>=2)_=ZW(X.executionSummary,Y);else S(G,"Enable verbose mode at level VeryVerbose in order to check all generated values and their associated status");return{message:Q,details:_,hints:G}}function kH(X,Y){if(!X.failed)return;let{message:Q,details:_,hints:G}=X.counterexamplePath===null?X.interrupted?El(X,Y):Tl(X,Y):Fl(X,Y),J=Q;if(_!==null)J+=`

${_}`;if(G.length>0)J+=`

${Ol(G)}`;return J}function lA(X){return kH(X,r0)}async function oA(X){let Y=[];function Q(Z){let K=dA(Z);if(typeof K==="string")return K;return Y.push(Promise.all([Z,K])),"…"}let _=kH(X,Q);if(Y.length===0)return _;let G=new Z8(await Promise.all(Y));function J(Z){let K=NX(G,Z);if(K!==void 0)return K;return r0(Z)}return kH(X,J)}function rA(X,Y){if(Y.runConfiguration.includeErrorInReport)throw new y(X);let Q=new y(X,{cause:Y.errorInstance});if(!("cause"in Q))zl(Q,{cause:Y.errorInstance});return Q}function Al(X){if(!X.failed)return;throw rA(lA(X),X)}async function Pl(X){if(!X.failed)return;throw rA(await oA(X),X)}function wl(X){if(X.runConfiguration.asyncReporter)return X.runConfiguration.asyncReporter(X);else if(X.runConfiguration.reporter)return X.runConfiguration.reporter(X);else return Al(X)}async function Cl(X){if(X.runConfiguration.asyncReporter)return X.runConfiguration.asyncReporter(X);else if(X.runConfiguration.reporter)return X.runConfiguration.reporter(X);else return Pl(X)}function Ml(X,Y,Q,_,G){let J=new fA(Q,Y,_,G);for(let Z of J){X.runBeforeEach();let K=X.run(Z);X.runAfterEach(),J.handleResult(K)}return J.runExecution}async function Il(X,Y,Q,_,G){let J=new fA(Q,Y,_,G);for(let Z of J){await X.runBeforeEach();let K=await X.run(Z);await X.runAfterEach(),J.handleResult(K)}return J.runExecution}function iA(X,Y){if(X===null||X===void 0||X.generate===null||X.generate===void 0)throw Error("Invalid property encountered, please use a valid property");if(X.run===null||X.run===void 0)throw Error("Invalid property encountered, please use a valid property not an arbitrary");let Q=QW({...aX(),...Y});if(Q.reporter!==void 0&&Q.asyncReporter!==void 0)throw Error("Invalid parameters encountered, reporter and asyncReporter cannot be specified together");if(Q.asyncReporter!==void 0&&!X.isAsync())throw Error("Invalid parameters encountered, only asyncProperty can be used when asyncReporter specified");let _=Zl(X,Q),G=Q.path.length===0||Q.path.indexOf(":")===-1?Q.numRuns:-1,J=Q.numRuns*Q.maxSkipsPerRun,Z=(...W)=>_.shrink(...W),K=new Wl(Q.path.length===0?pA(_,Q.seed,Q.randomType,Q.examples):cA(Q.path,X4(uA(_,Q.seed,Q.randomType,Q.examples)),Z),G,J),H=!Q.endOnFailure?Z:Z0.nil;return _.isAsync()?Il(_,H,K,Q.verbose,Q.markInterruptAsFailure).then((W)=>W.toRunDetails(Q.seed,Q.path,J,Q)):Ml(_,H,K,Q.verbose,Q.markInterruptAsFailure).toRunDetails(Q.seed,Q.path,J,Q)}function jl(X,Y){let Q=iA(X,Y);if(X.isAsync())return Q.then(Cl);else wl(Q)}function Sl(X,Y){let Q=!Object.prototype.hasOwnProperty.call(X,"isAsync")?new yA(X,()=>!0):X;return Y.unbiased===!0?new mA(Q):Q}function nA(X,Y){let Q=QW(typeof Y==="number"?{...aX(),numRuns:Y}:{...aX(),...Y}),_=Sl(X,Q),G=_.shrink.bind(_);return(Q.path.length===0?X4(pA(_,Q.seed,Q.randomType,Q.examples)):cA(Q.path,X4(uA(_,Q.seed,Q.randomType,Q.examples)),G)).take(Q.numRuns).map((J)=>J.value_)}function vl(X,Y){return[...nA(X,Y)]}function xl(X){return(Math.round(X*100)/100).toFixed(2)}function kl(X,Y,Q){let _=QW(typeof Q==="number"?{...aX(),numRuns:Q}:{...aX(),...Q}),G={};for(let H of nA(X,Q)){let W=Y(H),D=Array.isArray(W)?W:[W];for(let U of D)G[U]=(G[U]||0)+1}let J=Object.entries(G).sort((H,W)=>W[1]-H[1]).map((H)=>[H[0],`${xl(H[1]*100/_.numRuns)}%`]),Z=J.map((H)=>H[0].length).reduce((H,W)=>Math.max(H,W),0),K=J.map((H)=>H[1].length).reduce((H,W)=>Math.max(H,W),0);for(let H of J)_.logger(`${H[0].padEnd(Z,".")}..${H[1].padStart(K,".")}`)}var bl=Object.assign;function bH(X,Y,Q,_){let G=Q(),J=X.clone(),Z={mrng:X.clone(),biasFactor:Y,history:[]},K=(W)=>{let D=G[Z.history.length];if(D!==void 0&&D.arb===W){let N=D.value;return S(Z.history,{arb:W,value:N,context:D.context,mrng:D.mrng}),J=D.mrng.clone(),N}let U=W.generate(J,Y);return S(Z.history,{arb:W,value:U.value_,context:U.context,mrng:J.clone()}),U.value};return new g(bl((W,...D)=>{return K(_(W,D))},{values(){return q0(Z.history,(W)=>W.value)},[J1](){return bH(X,Y,Q,_).value},[tX](){return r0(q0(Z.history,(W)=>W.value))}}),Z)}var DH=Array.isArray,VE=Object.keys,gl=Object.is;function yl(X){let Y=new Z8;return function(_,G){let J=NX(Y,_);if(J===void 0){let H=_(...G);return nX(Y,_,[{args:G,value:H}]),H}let Z=J;for(let H of Z)if(X(G,H.args))return H.value;let K=_(...G);return S(Z,{args:G,value:K}),K}}function sA(X,Y){if(X!==null&&typeof X==="object"&&Y!==null&&typeof Y==="object"){if(DH(X)){if(!DH(Y))return!1;if(X.length!==Y.length)return!1}else if(DH(Y))return!1;if(VE(X).length!==VE(Y).length)return!1;for(let Q in X){if(!(Q in Y))return!1;if(!sA(X[Q],Y[Q]))return!1}return!0}else return gl(X,Y)}var hl=class extends k0{constructor(...X){super(...X);this.arbitraryCache=yl(sA)}generate(X,Y){return bH(X,Y,()=>[],this.arbitraryCache)}canShrinkWithoutContext(X){return!1}shrink(X,Y){if(Y===void 0)return Z0.nil();let Q=Y,_=Q.mrng,G=Q.biasFactor,J=Q.history;return kA(J.map((Z)=>Z.arb),J.map((Z)=>Z.value),J.map((Z)=>Z.context)).map((Z)=>{function K(){let{value:H,context:W}=Z;return q0(J,(D,U)=>({arb:D.arb,value:H[U],context:W[U],mrng:D.mrng}))}return bH(_,G,K,this.arbitraryCache)})}};function ml(){return new hl}var{floor:dl,log:qE}=Math;function fl(X){return dl(qE(X)/qE(2))}function pl(X){if(X===b(0))return b(0);return b(d1(X).length)}function aA(X,Y,Q){if(X===Y)return[{min:X,max:Y}];if(X<0&&Y>0){let Z=Q(-X),K=Q(Y);return[{min:-Z,max:K},{min:Y-K,max:Y},{min:X,max:X+Z}]}let _=Q(Y-X),G={min:X,max:X+_},J={min:Y-_,max:Y};return X<0?[J,G]:[G,J]}var{ceil:ul,floor:cl}=Math;function zE(X){return cl(X/2)}function OE(X){return ul(X/2)}function LE(X,Y,Q){let _=X-Y;function*G(){let Z=Q?void 0:Y,K=Q?_:zE(_);for(let H=K;H>0;H=zE(H)){let W=H===_?Y:X-H;yield new g(W,Z),Z=W}}function*J(){let Z=Q?void 0:Y,K=Q?_:OE(_);for(let H=K;H<0;H=OE(H)){let W=H===_?Y:X-H;yield new g(W,Z),Z=W}}return _>0?X4(G()):X4(J())}var TE=Math.sign,ll=Number.isInteger,ol=Object.is,C9=class X extends k0{constructor(Y,Q){super();this.min=Y,this.max=Q,this.ranges=aA(Y,Q,fl)}generate(Y,Q){if(Q===void 0||Y.nextInt(1,Q)!==1)return new g(Y.nextInt(this.min,this.max),void 0);let _=this.ranges;if(_.length===1){let Z=_[0];return new g(Y.nextInt(Z.min,Z.max),void 0)}let G=Y.nextInt(-2*(_.length-1),_.length-2),J=G<0?_[0]:_[G+1];return new g(Y.nextInt(J.min,J.max),void 0)}canShrinkWithoutContext(Y){return typeof Y==="number"&&ll(Y)&&!ol(Y,-0)&&this.min<=Y&&Y<=this.max}shrink(Y,Q){if(!X.isValidContext(Y,Q))return LE(Y,this.min<=0&&this.max>=0?0:this.min<0?this.max:this.min,!0);if(this.isLastChanceTry(Y,Q))return Z0.of(new g(Q,void 0));return LE(Y,Q,!1)}isLastChanceTry(Y,Q){if(Y>0)return Y===Q+1&&Y>this.min;if(Y<0)return Y===Q-1&&Y<this.max;return!1}static isValidContext(Y,Q){if(Q===void 0)return!1;if(typeof Q!=="number")throw Error("Invalid context type passed to IntegerArbitrary (#1)");if(Q!==0&&TE(Y)!==TE(Q))throw Error("Invalid context value passed to IntegerArbitrary (#2)");return!0}},RE=Number.isInteger;function rl(X){return{min:X.min!==void 0?X.min:-2147483648,max:X.max!==void 0?X.max:2147483647}}function A0(X={}){let Y=rl(X);if(Y.min>Y.max)throw Error("fc.integer maximum value should be equal or greater than the minimum one");if(!RE(Y.min))throw Error("fc.integer minimum value should be an integer");if(!RE(Y.max))throw Error("fc.integer maximum value should be an integer");return new C9(Y.min,Y.max)}var FE=new Map;function KW(X){if(X===void 0)return{depth:0};if(typeof X!=="string")return X;let Y=NX(FE,X);if(Y!==void 0)return Y;let Q={depth:0};return nX(FE,X,Q),Q}function HW(){return{depth:0}}var il=class{constructor(X,Y,Q){this.arb=X,this.mrng=Y,this.biasFactor=Q}attemptExact(){}next(){return this.arb.generate(this.mrng,this.biasFactor)}},nl=Math.min,sl=Math.max,al=class{constructor(X,Y,Q,_){this.arb=X,this.mrng=Y,this.slices=Q,this.biasFactor=_,this.activeSliceIndex=0,this.nextIndexInSlice=0,this.lastIndexInSlice=-1}attemptExact(X){if(X!==0&&this.mrng.nextInt(1,this.biasFactor)===1){let Y=[];for(let Q=0;Q!==this.slices.length;++Q)if(this.slices[Q].length===X)S(Y,Q);if(Y.length===0)return;this.activeSliceIndex=Y[this.mrng.nextInt(0,Y.length-1)],this.nextIndexInSlice=0,this.lastIndexInSlice=X-1}}next(){if(this.nextIndexInSlice<=this.lastIndexInSlice)return new g(this.slices[this.activeSliceIndex][this.nextIndexInSlice++],void 0);if(this.mrng.nextInt(1,this.biasFactor)!==1)return this.arb.generate(this.mrng,this.biasFactor);this.activeSliceIndex=this.mrng.nextInt(0,this.slices.length-1);let X=this.slices[this.activeSliceIndex];if(this.mrng.nextInt(1,this.biasFactor)!==1)return this.nextIndexInSlice=1,this.lastIndexInSlice=X.length-1,new g(X[0],void 0);let Y=this.mrng.nextInt(0,X.length-1),Q=this.mrng.nextInt(0,X.length-1);return this.nextIndexInSlice=nl(Y,Q),this.lastIndexInSlice=sl(Y,Q),new g(X[this.nextIndexInSlice++],void 0)}};function EE(X,Y,Q,_){if(_===void 0||Q.length===0||Y.nextInt(1,_)!==1)return new il(X,Y,_);return new al(X,Y,Q,_)}var{floor:tl,log:AE}=Math,el=Array.isArray;function Xo(X,Y){if(X===Y)return X;return X+tl(AE(Y-X)/AE(2))}var tA=class X extends k0{constructor(Y,Q,_,G,J,Z,K){super();this.arb=Y,this.minLength=Q,this.maxGeneratedLength=_,this.maxLength=G,this.setBuilder=Z,this.customSlices=K,this.lengthArb=A0({min:Q,max:_}),this.depthContext=KW(J),this.cachedBiasedMaxLength=Xo(Q,_)}preFilter(Y){if(this.setBuilder===void 0)return Y;let Q=this.setBuilder();for(let _=0;_!==Y.length;++_)Q.tryAdd(Y[_]);return Q.getData()}static makeItCloneable(Y,Q){return Y[J1]=()=>{let _=[];for(let G=0;G!==Q.length;++G)S(_,Q[G].value);return this.makeItCloneable(_,Q),_},Y}generateNItemsNoDuplicates(Y,Q,_,G){let J=0,Z=Y(),K=EE(this.arb,_,this.customSlices,G);while(Z.size()<Q&&J<this.maxGeneratedLength){let H=K.next();if(Z.tryAdd(H))J=0;else J+=1}return Z.getData()}safeGenerateNItemsNoDuplicates(Y,Q,_,G){let J=Q-this.cachedBiasedMaxLength;if(J<=0)return this.generateNItemsNoDuplicates(Y,Q,_,G);this.depthContext.depth+=J;try{return this.generateNItemsNoDuplicates(Y,Q,_,G)}finally{this.depthContext.depth-=J}}generateNItems(Y,Q,_){let G=[],J=EE(this.arb,Q,this.customSlices,_);J.attemptExact(Y);for(let Z=0;Z!==Y;++Z)S(G,J.next());return G}safeGenerateNItems(Y,Q,_){let G=Y-this.cachedBiasedMaxLength;if(G<=0)return this.generateNItems(Y,Q,_);this.depthContext.depth+=G;try{return this.generateNItems(Y,Q,_)}finally{this.depthContext.depth-=G}}wrapper(Y,Q,_,G){let J=Q?this.preFilter(Y):Y,Z=!1,K=[],H=[];for(let W=0;W!==J.length;++W){let D=J[W];Z=Z||D.hasToBeCloned,S(K,D.value),S(H,D.context)}if(Z)X.makeItCloneable(K,J);return new g(K,{shrunkOnce:Q,lengthContext:Y.length===J.length&&_!==void 0?_:void 0,itemsContexts:H,startIndex:G})}generate(Y,Q){let _,G;if(Q===void 0)_=this.lengthArb.generate(Y,void 0).value;else if(this.minLength===this.maxGeneratedLength)_=this.lengthArb.generate(Y,void 0).value,G=Q;else if(Y.nextInt(1,Q)!==1)_=this.lengthArb.generate(Y,void 0).value;else if(Y.nextInt(1,Q)!==1)_=this.lengthArb.generate(Y,void 0).value,G=Q;else{let Z=this.cachedBiasedMaxLength;_=A0({min:this.minLength,max:Z}).generate(Y,void 0).value,G=Q}let J=this.setBuilder!==void 0?this.safeGenerateNItemsNoDuplicates(this.setBuilder,_,Y,G):this.safeGenerateNItems(_,Y,G);return this.wrapper(J,!1,void 0,0)}canShrinkWithoutContext(Y){if(!el(Y)||this.minLength>Y.length||Y.length>this.maxLength)return!1;for(let Q=0;Q!==Y.length;++Q){if(!(Q in Y))return!1;if(!this.arb.canShrinkWithoutContext(Y[Q]))return!1}return this.preFilter(q0(Y,(Q)=>new g(Q,void 0))).length===Y.length}shrinkItemByItem(Y,Q,_){let G=[];for(let J=Q.startIndex;J<_;++J)S(G,e8(()=>this.arb.shrink(Y[J],Q.itemsContexts[J]).map((Z)=>{let K=q0(_1(Y,0,J),(W,D)=>new g(A9(W),Q.itemsContexts[D])),H=q0(_1(Y,J+1),(W,D)=>new g(A9(W),Q.itemsContexts[D+J+1]));return[[...K,Z,...H],void 0,J]})));return Z0.nil().join(...G)}shrinkImpl(Y,Q){if(Y.length===0)return Z0.nil();let _=Q!==void 0?Q:{shrunkOnce:!1,lengthContext:void 0,itemsContexts:[],startIndex:0};return this.lengthArb.shrink(Y.length,_.lengthContext).drop(_.shrunkOnce&&_.lengthContext===void 0&&Y.length>this.minLength+1?1:0).map((G)=>{let J=Y.length-G.value;return[q0(_1(Y,J),(Z,K)=>new g(A9(Z),_.itemsContexts[K+J])),G.context,0]}).join(e8(()=>Y.length>this.minLength?this.shrinkItemByItem(Y,_,1):this.shrinkItemByItem(Y,_,Y.length))).join(Y.length>this.minLength?e8(()=>{let G={shrunkOnce:!1,lengthContext:void 0,itemsContexts:_1(_.itemsContexts,1),startIndex:0};return this.shrinkImpl(_1(Y,1),G).filter((J)=>this.minLength<=J[0].length+1).map((J)=>{return[[new g(A9(Y[0]),_.itemsContexts[0]),...J[0]],void 0,0]})}):Z0.nil())}shrink(Y,Q){return this.shrinkImpl(Y,Q).map((_)=>this.wrapper(_[0],!0,_[1],_[2]))}},Yo=Math.floor,Qo=Math.min,K5=2147483647,R9=["xsmall","small","medium","large","xlarge"],_o=["-4","-3","-2","-1","=","+1","+2","+3","+4"],WW="small";function Go(X,Y){switch(Y){case"xsmall":return Yo(1.1*X)+1;case"small":return 2*X+10;case"medium":return 11*X+100;case"large":return 101*X+1000;case"xlarge":return 1001*X+1e4;default:throw Error(`Unable to compute lengths based on received size: ${Y}`)}}function dQ(X,Y){let Q=kQ(_o,X);if(Q===-1)return X;let _=kQ(R9,Y);if(_===-1)throw Error(`Unable to offset size based on the unknown defaulted one: ${Y}`);let G=_+Q-4;return G<0?R9[0]:G>=R9.length?R9[R9.length-1]:R9[G]}function hQ(X,Y,Q,_){let{baseSize:G=WW,defaultSizeToMaxWhenMaxSpecified:J}=aX()||{},Z=X!==void 0?X:_&&J?"max":G;if(Z==="max")return Q;let K=dQ(Z,G);return Qo(Go(Y,K),Q)}function Jo(X,Y){if(typeof X==="number")return 1/X;let{baseSize:Q=WW,defaultSizeToMaxWhenMaxSpecified:_}=aX()||{},G=X!==void 0?X:Y&&_?"max":Q;if(G==="max")return 0;switch(dQ(G,Q)){case"xsmall":return 1;case"small":return 0.5;case"medium":return 0.25;case"large":return 0.125;case"xlarge":return 0.0625}}function UW(X){let{baseSize:Y=WW}=aX()||{};if(X===void 0)return Y;return dQ(X,Y)}function w0(X,Y={}){let Q=Y.size,_=Y.minLength||0,G=Y.maxLength,J=Y.depthIdentifier,Z=G!==void 0?G:K5;return new tA(X,_,hQ(Q,_,Z,G!==void 0),Z,J,void 0,Y.experimentalCustomSlices||[])}function WG(X){return X/b(2)}function PE(X,Y,Q){let _=X-Y;function*G(){let Z=Q?void 0:Y,K=Q?_:WG(_);for(let H=K;H>0;H=WG(H)){let W=X-H;yield new g(W,Z),Z=W}}function*J(){let Z=Q?void 0:Y,K=Q?_:WG(_);for(let H=K;H<0;H=WG(H)){let W=X-H;yield new g(W,Z),Z=W}}return _>0?X4(G()):X4(J())}var $o=class X extends k0{constructor(Y,Q){super();this.min=Y,this.max=Q}generate(Y,Q){let _=this.computeGenerateRange(Y,Q);return new g(Y.nextBigInt(_.min,_.max),void 0)}computeGenerateRange(Y,Q){if(Q===void 0||Y.nextInt(1,Q)!==1)return{min:this.min,max:this.max};let _=aA(this.min,this.max,pl);if(_.length===1)return _[0];let G=Y.nextInt(-2*(_.length-1),_.length-2);return G<0?_[0]:_[G+1]}canShrinkWithoutContext(Y){return typeof Y==="bigint"&&this.min<=Y&&Y<=this.max}shrink(Y,Q){if(!X.isValidContext(Y,Q))return PE(Y,this.defaultTarget(),!0);if(this.isLastChanceTry(Y,Q))return Z0.of(new g(Q,void 0));return PE(Y,Q,!1)}defaultTarget(){if(this.min<=0&&this.max>=0)return b(0);return this.min<0?this.max:this.min}isLastChanceTry(Y,Q){if(Y>0)return Y===Q+b(1)&&Y>this.min;if(Y<0)return Y===Q-b(1)&&Y<this.max;return!1}static isValidContext(Y,Q){if(Q===void 0)return!1;if(typeof Q!=="bigint")throw Error("Invalid context type passed to BigIntArbitrary (#1)");let _=Y>0&&Q<0||Y<0&&Q>0;if(Q!==b(0)&&_)throw Error("Invalid context value passed to BigIntArbitrary (#2)");return!0}};function Zo(X){let Q=b(-1)<<b(255),_=(b(1)<<b(255))-b(1),G=X.min,J=X.max;return{min:G!==void 0?G:Q-(J!==void 0&&J<b(0)?J*J:b(0)),max:J!==void 0?J:_+(G!==void 0&&G>b(0)?G*G:b(0))}}function Ko(X){if(X[0]===void 0)return{};if(X[1]===void 0)return X[0];return{min:X[0],max:X[1]}}function Y4(...X){let Y=Zo(Ko(X));if(Y.min>Y.max)throw Error("fc.bigInt expects max to be greater than or equal to min");return new $o(Y.min,Y.max)}var Ho=Object.getPrototypeOf,jQ=class extends k0{constructor(X){super();this.arb=X}generate(X,Y){return this.arb.generate(X,void 0)}canShrinkWithoutContext(X){return this.arb.canShrinkWithoutContext(X)}shrink(X,Y){return this.arb.shrink(X,Y)}};function wG(X){if(Ho(X)===jQ.prototype&&X.generate===jQ.prototype.generate&&X.canShrinkWithoutContext===jQ.prototype.canShrinkWithoutContext&&X.shrink===jQ.prototype.shrink)return X;return new jQ(X)}function Wo(X){return X===1}function Uo(X){if(typeof X!=="boolean")throw Error("Unsupported input type");return X===!0?1:0}function fQ(){return wG(A0({min:0,max:1}).map(Wo,Uo))}var xQ=Object.is,Do=class{constructor(X){this.values=X,this.fastValues=new sX(this.values);let Y=!1,Q=!1;if(a8(this.fastValues,0))for(let _=0;_!==this.values.length;++_){let G=this.values[_];Y=Y||xQ(G,-0),Q=Q||xQ(G,0)}this.hasMinusZero=Y,this.hasPlusZero=Q}has(X){if(X===0){if(xQ(X,0))return this.hasPlusZero;return this.hasMinusZero}return a8(this.fastValues,X)}},eA=class extends k0{constructor(X){super();this.values=X}generate(X,Y){let Q=this.values.length===1?0:X.nextInt(0,this.values.length-1),_=this.values[Q];if(!Z5(_))return new g(_,Q);return new g(_,Q,()=>_[J1]())}canShrinkWithoutContext(X){if(this.values.length===1)return xQ(this.values[0],X);if(this.fastValues===void 0)this.fastValues=new Do(this.values);return this.fastValues.has(X)}shrink(X,Y){if(Y===0||xQ(X,this.values[0]))return Z0.nil();return Z0.of(new g(this.values[0],0))}};function A6(...X){if(X.length===0)throw Error("fc.constantFrom expects at least one parameter");return new eA(X)}function No(X){if(!X||!X.withBigInt)return A6(!1,null,void 0,0,"",NaN);return A6(!1,null,void 0,0,"",NaN,b(0))}function v0(X){return new eA([X])}var Bo=class X{constructor(){this.receivedLogs=[]}log(Y){this.receivedLogs.push(Y)}size(){return this.receivedLogs.length}toString(){return JSON.stringify({logs:this.receivedLogs})}[J1](){return new X}};function Vo(){return v0(new Bo)}var qo=NaN,zo=Number.isNaN;function XP(X){return new AG(X)}function YP(X){if(!(X instanceof AG)||X.constructor!==AG)throw new y("Not a valid value for date unmapper");return PG(X)}function Oo(X){return(Y)=>{return Y===X?new AG(qo):XP(Y)}}function Lo(X){return(Y)=>{let Q=YP(Y);return zo(Q)?X:Q}}var wE=Number.isNaN;function QP(X={}){let Y=X.min!==void 0?PG(X.min):-8640000000000000,Q=X.max!==void 0?PG(X.max):8640000000000000,_=X.noInvalidDate;if(wE(Y))throw Error("fc.date min must be valid instance of Date");if(wE(Q))throw Error("fc.date max must be valid instance of Date");if(Y>Q)throw Error("fc.date max must be greater or equal to min");if(_)return A0({min:Y,max:Q}).map(XP,YP);let G=Q+1;return A0({min:Y,max:Q+1}).map(Oo(G),Lo(G))}var To=class extends k0{constructor(X,Y){super();this.startArb=X,this.chainer=Y}generate(X,Y){let Q=[],_=X.clone(),G=this.startArb.generate(X,Y);Q.push({arbitrary:this.startArb,value:G.value_,context:G.context,clonedMrng:_});while(!0){let Z=this.chainer(G.value_);if(Z===void 0)break;let K=X.clone();G=Z.generate(X,Y),Q.push({arbitrary:Z,value:G.value_,context:G.context,clonedMrng:K})}let J={biasFactor:Y,entries:Q,currentShrinkLevel:0};return new g(G.value_,J)}canShrinkWithoutContext(X){return!1}shrink(X,Y){if(!this.isSafeContext(Y))return Z0.nil();return new Z0(this.shrinkIterator(Y))}*shrinkIterator(X){let{entries:Y,currentShrinkLevel:Q,biasFactor:_}=X;for(let G=Q;G<Y.length;++G){let J=Y[G],Z=J.arbitrary.shrink(J.value,J.context);for(let K of Z){let H=Y.slice(0,G);H.push({arbitrary:J.arbitrary,value:K.value_,context:K.context,clonedMrng:J.clonedMrng});let W=K,D=J.clonedMrng.clone();while(!0){let B=this.chainer(W.value_);if(B===void 0)break;let q=D.clone(),O=B.generate(D,_);H.push({arbitrary:B,value:O.value_,context:O.context,clonedMrng:q}),W=O}let U=H[H.length-1],N={biasFactor:_,entries:H,currentShrinkLevel:G};yield new g(U.value,N)}}}isSafeContext(X){return X!==null&&X!==void 0&&typeof X==="object"&&"biasFactor"in X&&"entries"in X&&"currentShrinkLevel"in X}};function _P(X,Y){return new To(X,Y)}var Ro=Symbol.iterator,Fo=Array.isArray,Eo=Object.is,Ao=class X extends k0{constructor(Y,Q){super();this.arb=Y,this.numValues=Q}generate(Y,Q){let _=[];if(this.numValues<=0)return this.wrapper(_);for(let G=0;G!==this.numValues-1;++G)S(_,this.arb.generate(Y.clone(),Q));return S(_,this.arb.generate(Y,Q)),this.wrapper(_)}canShrinkWithoutContext(Y){if(!Fo(Y)||Y.length!==this.numValues)return!1;if(Y.length===0)return!0;for(let Q=1;Q<Y.length;++Q)if(!Eo(Y[0],Y[Q]))return!1;return this.arb.canShrinkWithoutContext(Y[0])}shrink(Y,Q){if(Y.length===0)return Z0.nil();return new Z0(this.shrinkImpl(Y,Q!==void 0?Q:[])).map((_)=>this.wrapper(_))}*shrinkImpl(Y,Q){let _=q0(Y,(J,Z)=>this.arb.shrink(J,Q[Z])[Ro]()),G=q0(_,(J)=>J.next());while(!G[0].done)yield q0(G,(J)=>J.value),G=q0(_,(J)=>J.next())}static makeItCloneable(Y,Q){return Y[J1]=()=>{let _=[];for(let G=0;G!==Q.length;++G)S(_,Q[G].value);return this.makeItCloneable(_,Q),_},Y}wrapper(Y){let Q=!1,_=[],G=[];for(let J=0;J!==Y.length;++J){let Z=Y[J];Q=Q||Z.hasToBeCloned,S(_,Z.value),S(G,Z.context)}if(Q)X.makeItCloneable(_,Y);return new g(_,G)}};function Po(X,Y){return new Ao(X,Y)}var CE=class{constructor(X){this.isEqual=X,this.data=[]}tryAdd(X){for(let Y=0;Y!==this.data.length;++Y)if(this.isEqual(this.data[Y],X))return!1;return S(this.data,X),!0}size(){return this.data.length}getData(){return this.data}},wo=Number.isNaN,Co=class{constructor(X){this.selector=X,this.selectedItemsExceptNaN=new sX,this.data=[]}tryAdd(X){let Y=this.selector(X);if(wo(Y))return S(this.data,X),!0;let Q=this.selectedItemsExceptNaN.size;if(bQ(this.selectedItemsExceptNaN,Y),Q!==this.selectedItemsExceptNaN.size)return S(this.data,X),!0;return!1}size(){return this.data.length}getData(){return this.data}},Mo=Object.is,Io=class{constructor(X){this.selector=X,this.selectedItemsExceptMinusZero=new sX,this.data=[],this.hasMinusZero=!1}tryAdd(X){let Y=this.selector(X);if(Mo(Y,-0)){if(this.hasMinusZero)return!1;return S(this.data,X),this.hasMinusZero=!0,!0}let Q=this.selectedItemsExceptMinusZero.size;if(bQ(this.selectedItemsExceptMinusZero,Y),Q!==this.selectedItemsExceptMinusZero.size)return S(this.data,X),!0;return!1}size(){return this.data.length}getData(){return this.data}},jo=class{constructor(X){this.selector=X,this.selectedItems=new sX,this.data=[]}tryAdd(X){let Y=this.selector(X),Q=this.selectedItems.size;if(bQ(this.selectedItems,Y),Q!==this.selectedItems.size)return S(this.data,X),!0;return!1}size(){return this.data.length}getData(){return this.data}};function So(X){if(typeof X.comparator==="function"){if(X.selector===void 0){let K=X.comparator,H=(W,D)=>K(W.value_,D.value_);return()=>new CE(H)}let{comparator:_,selector:G}=X,J=(K)=>G(K.value_),Z=(K,H)=>_(J(K),J(H));return()=>new CE(Z)}let Y=X.selector||((_)=>_),Q=(_)=>Y(_.value_);switch(X.comparator){case"IsStrictlyEqual":return()=>new Co(Q);case"SameValueZero":return()=>new jo(Q);case"SameValue":case void 0:return()=>new Io(Q)}}function H5(X,Y={}){let Q=Y.minLength!==void 0?Y.minLength:0,_=Y.maxLength!==void 0?Y.maxLength:K5,G=hQ(Y.size,Q,_,Y.maxLength!==void 0),J=Y.depthIdentifier,Z=new tA(X,Q,G,_,J,So(Y),[]);if(Q===0)return Z;return Z.filter((K)=>K.length>=Q)}var{create:vo,defineProperty:xo,getOwnPropertyDescriptor:ko,getPrototypeOf:ME,prototype:bo}=Object,go=Reflect.ownKeys;function yo(X){let Y=X[1]?vo(null):{},Q=X[0];for(let _=0;_!==Q.length;++_){let G=Q[_][0];if(G==="__proto__")xo(Y,G,{enumerable:!0,configurable:!0,writable:!0,value:Q[_][1]});else Y[G]=Q[_][1]}return Y}function ho(X){return X!==void 0&&!!X.configurable&&!!X.enumerable&&!!X.writable&&X.get===void 0&&X.set===void 0}function mo(X){if(typeof X!=="object"||X===null)throw new y("Incompatible instance received: should be a non-null object");let Y=ME(X)===null,Q=ME(X)===bo;if(!Y&&!Q)throw new y("Incompatible instance received: should be of exact type Object");let _=q0(go(X),(G)=>[G,ko(X,G)]);if(!SA(_,([,G])=>ho(G)))throw new y("Incompatible instance received: should contain only c/e/w properties without get/set");return[q0(_,([G,J])=>[G,J.value]),Y]}function fo(X){return X[0]}function DW(X,Y,Q={}){let _=!!Q.noNullPrototype;return $0(H5($0(X,Y),{minLength:Q.minKeys,maxLength:Q.maxKeys,size:Q.size,selector:fo,depthIdentifier:Q.depthIdentifier}),_?v0(!1):fQ()).map(yo,mo)}var{POSITIVE_INFINITY:po,MAX_SAFE_INTEGER:uo,isInteger:co}=Number,lo=Math.floor,oo=Math.pow,ro=Math.min,gH=class X extends k0{static from(Y,Q,_){if(Y.length===0)throw Error(`${_} expects at least one weighted arbitrary`);let G=0;for(let Z=0;Z!==Y.length;++Z){if(Y[Z].arbitrary===void 0)throw Error(`${_} expects arbitraries to be specified`);let K=Y[Z].weight;if(G+=K,!co(K))throw Error(`${_} expects weights to be integer values`);if(K<0)throw Error(`${_} expects weights to be superior or equal to 0`)}if(G<=0)throw Error(`${_} expects the sum of weights to be strictly superior to 0`);let J={depthBias:Jo(Q.depthSize,Q.maxDepth!==void 0),maxDepth:Q.maxDepth!==void 0?Q.maxDepth:po,withCrossShrink:!!Q.withCrossShrink};return new X(Y,J,KW(Q.depthIdentifier))}constructor(Y,Q,_){super();this.warbs=Y,this.constraints=Q,this.context=_;let G=0;this.cumulatedWeights=[];for(let J=0;J!==Y.length;++J)G+=Y[J].weight,S(this.cumulatedWeights,G);this.totalWeight=G}generate(Y,Q){if(this.mustGenerateFirst())return this.safeGenerateForIndex(Y,0,Q);let _=Y.nextInt(this.computeNegDepthBenefit(),this.totalWeight-1);for(let G=0;G!==this.cumulatedWeights.length;++G)if(_<this.cumulatedWeights[G])return this.safeGenerateForIndex(Y,G,Q);throw Error("Unable to generate from fc.frequency")}canShrinkWithoutContext(Y){return this.canShrinkWithoutContextIndex(Y)!==-1}shrink(Y,Q){if(Q!==void 0){let G=Q,J=G.selectedIndex,Z=G.originalBias,K=this.warbs[J].arbitrary.shrink(Y,G.originalContext).map((H)=>this.mapIntoValue(J,H,null,Z));if(G.clonedMrngForFallbackFirst!==null){if(G.cachedGeneratedForFirst===void 0)G.cachedGeneratedForFirst=this.safeGenerateForIndex(G.clonedMrngForFallbackFirst,0,Z);let H=G.cachedGeneratedForFirst;return Z0.of(H).join(K)}return K}let _=this.canShrinkWithoutContextIndex(Y);if(_===-1)return Z0.nil();return this.defaultShrinkForFirst(_).join(this.warbs[_].arbitrary.shrink(Y,void 0).map((G)=>this.mapIntoValue(_,G,null,void 0)))}defaultShrinkForFirst(Y){++this.context.depth;try{if(!this.mustFallbackToFirstInShrink(Y)||this.warbs[0].fallbackValue===void 0)return Z0.nil()}finally{--this.context.depth}let Q=new g(this.warbs[0].fallbackValue.default,void 0);return Z0.of(this.mapIntoValue(0,Q,null,void 0))}canShrinkWithoutContextIndex(Y){if(this.mustGenerateFirst())return this.warbs[0].arbitrary.canShrinkWithoutContext(Y)?0:-1;try{++this.context.depth;for(let Q=0;Q!==this.warbs.length;++Q){let _=this.warbs[Q];if(_.weight!==0&&_.arbitrary.canShrinkWithoutContext(Y))return Q}return-1}finally{--this.context.depth}}mapIntoValue(Y,Q,_,G){let J={selectedIndex:Y,originalBias:G,originalContext:Q.context,clonedMrngForFallbackFirst:_};return new g(Q.value,J)}safeGenerateForIndex(Y,Q,_){++this.context.depth;try{let G=this.warbs[Q].arbitrary.generate(Y,_),J=this.mustFallbackToFirstInShrink(Q)?Y.clone():null;return this.mapIntoValue(Q,G,J,_)}finally{--this.context.depth}}mustGenerateFirst(){return this.constraints.maxDepth<=this.context.depth}mustFallbackToFirstInShrink(Y){return Y!==0&&this.constraints.withCrossShrink&&this.warbs[0].weight!==0}computeNegDepthBenefit(){let Y=this.constraints.depthBias;if(Y<=0||this.warbs[0].weight===0)return 0;let Q=lo(oo(1+Y,this.context.depth))-1;return-ro(this.totalWeight*Q,uo)||0}};function io(X){return X!==null&&X!==void 0&&typeof X==="object"&&!("generate"in X)&&!("arbitrary"in X)&&!("weight"in X)}function IE(X){if(TA(X))return{arbitrary:X,weight:1};return X}function G1(...X){let Y=X[0];if(io(Y)){let _=q0(_1(X,1),IE);return gH.from(_,Y,"fc.oneof")}let Q=q0(X,IE);return gH.from(Q,{},"fc.oneof")}var no=Number.isInteger;function t8(X){let Y=typeof X==="number"?X:X&&X.max!==void 0?X.max:2147483647;if(Y<0)throw Error("fc.nat value should be greater than or equal to 0");if(!no(Y))throw Error("fc.nat maximum value should be an integer");return new C9(0,Y)}var so=Object.is;function ao(X){let Y=0,Q=[];for(let _ of X){let G=Y;Y=G+_.num;let J=Y-1;Q.push({from:G,to:J,entry:_})}return Q}function to(X,Y){let Q=0,_=X.length;while(_-Q>1){let G=~~((Q+_)/2);if(Y<X[G].from)_=G;else Q=G}return X[Q]}function eo(X){let Y=ao(X);return function(_){let G=to(Y,_);return G.entry.build(_-G.from)}}function Xr(X){let Y={mapping:new Z8,negativeZeroIndex:void 0},Q=0;for(let _=0;_!==X.length;++_){let G=X[_];for(let J=0;J!==G.num;++J){let Z=G.build(J);if(Z===0&&1/Z===$8.NEGATIVE_INFINITY)Y.negativeZeroIndex=Q;else nX(Y.mapping,Z,Q);++Q}}return Y}function Yr(X){let Y=null;return function(_){if(Y===null)Y=Xr(X);let G=so(_,-0)?Y.negativeZeroIndex:NX(Y.mapping,_);if(G===void 0)throw new y("Unknown value encountered cannot be built using this mapToConstant");return G}}function Qr(X){if(X.length===0)throw new y("fc.mapToConstant expects at least one option");let Y=0;for(let Q=0;Q!==X.length;++Q){if(X[Q].num<0)throw new y("fc.mapToConstant expects all options to have a number of entries greater or equal to zero");Y+=X[Q].num}if(Y===0)throw new y("fc.mapToConstant expects at least one choice among options");return Y}function M9(...X){return t8({max:Qr(X)-1}).map(eo(X),Yr(X))}function GP(X,Y,Q,_){if(Y.length===0){if(Q>0)return;return[]}if(_<=0)return;let G=[{endIndexChunks:0,nextStartIndex:1,chunks:[]}];while(G.length>0){let J=MA(G);for(let Z=J.nextStartIndex;Z<=Y.length;++Z){let K=m0(Y,J.endIndexChunks,Z);if(X.canShrinkWithoutContext(K)){let H=[...J.chunks,K];if(Z===Y.length){if(H.length<Q)break;return H}if(S(G,{endIndexChunks:J.endIndexChunks,nextStartIndex:Z+1,chunks:J.chunks}),H.length<_)S(G,{endIndexChunks:Z,nextStartIndex:Z+1,chunks:H});break}}}}function _r(X){return x0(X,"")}function JP(X){return X.minLength!==void 0?X.minLength:0}function $P(X){return X.maxLength!==void 0?X.maxLength:K5}function Gr(X,Y){return JP(Y)<=X.length&&X.length<=$P(Y)}function Jr(X,Y){return function(_){if(typeof _!=="string")throw new y("Unsupported value");let G=GP(X,_,JP(Y),$P(Y));if(G===void 0)throw new y("Unable to unmap received string");return G}}var ZP=["__defineGetter__","__defineSetter__","__lookupGetter__","__lookupSetter__","__proto__","constructor","hasOwnProperty","isPrototypeOf","propertyIsEnumerable","toLocaleString","toString","valueOf","apply","arguments","bind","call","caller","length","name","prototype","key","ref"];function $r(X,Y,Q){let _;try{_=Q(X)}catch{return}for(let G of _)if(!Y.canShrinkWithoutContext(G))return;return _}function Zr(X,Y){let Q=[];for(let _ of ZP){let G=$r(_,X,Y);if(G!==void 0)S(Q,G)}return Q}var jE=new WeakMap;function Kr(X){let Y=[];for(let Q of ZP){let _=GP(X,Q,0,K5);if(_!==void 0)S(Y,_)}return Y}function Hr(X,Y){let Q=$c(jE,X);if(Q===void 0)Q=Kr(X),Jc(jE,X,Q);let _=[];for(let G of Q)if(Gr(G,Y))S(_,G);return _}var Wr=[[0,127]],Ur=[[0,55295],[57344,1114111]],Dr=[[32,126],[160,172],[174,767],[880,887],[890,895],[900,906],[908],[910,929],[931,1154],[1162,1327],[1329,1366],[1369,1418],[1421,1423],[1470],[1472],[1475],[1478],[1488,1514],[1519,1524],[1542,1551],[1563],[1565,1610],[1632,1647],[1649,1749],[1758],[1765,1766],[1769],[1774,1805],[1808],[1810,1839],[1869,1957],[1969],[1984,2026],[2036,2042],[2046,2069],[2074],[2084],[2088],[2096,2110],[2112,2136],[2142],[2144,2154],[2160,2190],[2208,2249],[2308,2361],[2365],[2384],[2392,2401],[2404,2432],[2437,2444],[2447,2448],[2451,2472],[2474,2480],[2482],[2486,2489],[2493],[2510],[2524,2525],[2527,2529],[2534,2557],[2565,2570],[2575,2576],[2579,2600],[2602,2608],[2610,2611],[2613,2614],[2616,2617],[2649,2652],[2654],[2662,2671],[2674,2676],[2678],[2693,2701],[2703,2705],[2707,2728],[2730,2736],[2738,2739],[2741,2745],[2749],[2768],[2784,2785],[2790,2801],[2809],[2821,2828],[2831,2832],[2835,2856],[2858,2864],[2866,2867],[2869,2873],[2877],[2908,2909],[2911,2913],[2918,2935],[2947],[2949,2954],[2958,2960],[2962,2965],[2969,2970],[2972],[2974,2975],[2979,2980],[2984,2986],[2990,3001],[3024],[3046,3066],[3077,3084],[3086,3088],[3090,3112],[3114,3129],[3133],[3160,3162],[3165],[3168,3169],[3174,3183],[3191,3200],[3204,3212],[3214,3216],[3218,3240],[3242,3251],[3253,3257],[3261],[3293,3294],[3296,3297],[3302,3311],[3313,3314],[3332,3340],[3342,3344],[3346,3386],[3389],[3407],[3412,3414],[3416,3425],[3430,3455],[3461,3478],[3482,3505],[3507,3515],[3517],[3520,3526],[3558,3567],[3572],[3585,3632],[3634],[3647,3654],[3663,3675],[3713,3714],[3716],[3718,3722],[3724,3747],[3749],[3751,3760],[3762],[3773],[3776,3780],[3782],[3792,3801],[3804,3807],[3840,3863],[3866,3892],[3894],[3896],[3898,3901],[3904,3911],[3913,3948],[3973],[3976,3980],[4030,4037],[4039,4044],[4046,4058],[4096,4138],[4159,4181],[4186,4189],[4193],[4197,4198],[4206,4208],[4213,4225],[4238],[4240,4249],[4254,4293],[4295],[4301],[4304,4351],[4608,4680],[4682,4685],[4688,4694],[4696],[4698,4701],[4704,4744],[4746,4749],[4752,4784],[4786,4789],[4792,4798],[4800],[4802,4805],[4808,4822],[4824,4880],[4882,4885],[4888,4954],[4960,4988],[4992,5017],[5024,5109],[5112,5117],[5120,5788],[5792,5880],[5888,5905],[5919,5937],[5941,5942],[5952,5969],[5984,5996],[5998,6000],[6016,6067],[6100,6108],[6112,6121],[6128,6137],[6144,6154],[6160,6169],[6176,6264],[6272,6276],[6279,6312],[6314],[6320,6389],[6400,6430],[6464],[6468,6509],[6512,6516],[6528,6571],[6576,6601],[6608,6618],[6622,6678],[6686,6740],[6784,6793],[6800,6809],[6816,6829],[6917,6963],[6981,6988],[6992,7018],[7028,7038],[7043,7072],[7086,7141],[7164,7203],[7227,7241],[7245,7304],[7312,7354],[7357,7367],[7379],[7401,7404],[7406,7411],[7413,7414],[7418],[7424,7615],[7680,7957],[7960,7965],[7968,8005],[8008,8013],[8016,8023],[8025],[8027],[8029],[8031,8061],[8064,8116],[8118,8132],[8134,8147],[8150,8155],[8157,8175],[8178,8180],[8182,8190],[8192,8202],[8208,8233],[8239,8287],[8304,8305],[8308,8334],[8336,8348],[8352,8384],[8448,8587],[8592,9254],[9280,9290],[9312,11123],[11126,11157],[11159,11502],[11506,11507],[11513,11557],[11559],[11565],[11568,11623],[11631,11632],[11648,11670],[11680,11686],[11688,11694],[11696,11702],[11704,11710],[11712,11718],[11720,11726],[11728,11734],[11736,11742],[11776,11869],[11904,11929],[11931,12019],[12032,12245],[12272,12329],[12336,12351],[12353,12438],[12443,12543],[12549,12591],[12593,12686],[12688,12771],[12783,12830],[12832,13312],[19903,19968],[40959,42124],[42128,42182],[42192,42539],[42560,42606],[42611],[42622,42653],[42656,42735],[42738,42743],[42752,42954],[42960,42961],[42963],[42965,42969],[42994,43009],[43011,43013],[43015,43018],[43020,43042],[43048,43051],[43056,43065],[43072,43127],[43138,43187],[43214,43225],[43250,43262],[43264,43301],[43310,43334],[43359],[43396,43442],[43457,43469],[43471,43481],[43486,43492],[43494,43518],[43520,43560],[43584,43586],[43588,43595],[43600,43609],[43612,43642],[43646,43695],[43697],[43701,43702],[43705,43709],[43712],[43714],[43739,43754],[43760,43764],[43777,43782],[43785,43790],[43793,43798],[43808,43814],[43816,43822],[43824,43883],[43888,44002],[44011],[44016,44025],[44032],[55203],[63744,64109],[64112,64217],[64256,64262],[64275,64279],[64285],[64287,64310],[64312,64316],[64318],[64320,64321],[64323,64324],[64326,64450],[64467,64911],[64914,64967],[64975],[65008,65023],[65040,65049],[65072,65106],[65108,65126],[65128,65131],[65136,65140],[65142,65276],[65281,65437],[65440,65470],[65474,65479],[65482,65487],[65490,65495],[65498,65500],[65504,65510],[65512,65518],[65532,65533],[65536,65547],[65549,65574],[65576,65594],[65596,65597],[65599,65613],[65616,65629],[65664,65786],[65792,65794],[65799,65843],[65847,65934],[65936,65948],[65952],[66000,66044],[66176,66204],[66208,66256],[66273,66299],[66304,66339],[66349,66378],[66384,66421],[66432,66461],[66463,66499],[66504,66517],[66560,66717],[66720,66729],[66736,66771],[66776,66811],[66816,66855],[66864,66915],[66927,66938],[66940,66954],[66956,66962],[66964,66965],[66967,66977],[66979,66993],[66995,67001],[67003,67004],[67072,67382],[67392,67413],[67424,67431],[67456,67461],[67463,67504],[67506,67514],[67584,67589],[67592],[67594,67637],[67639,67640],[67644],[67647,67669],[67671,67742],[67751,67759],[67808,67826],[67828,67829],[67835,67867],[67871,67897],[67903],[67968,68023],[68028,68047],[68050,68096],[68112,68115],[68117,68119],[68121,68149],[68160,68168],[68176,68184],[68192,68255],[68288,68324],[68331,68342],[68352,68405],[68409,68437],[68440,68466],[68472,68497],[68505,68508],[68521,68527],[68608,68680],[68736,68786],[68800,68850],[68858,68899],[68912,68921],[69216,69246],[69248,69289],[69293],[69296,69297],[69376,69415],[69424,69445],[69457,69465],[69488,69505],[69510,69513],[69552,69579],[69600,69622],[69635,69687],[69703,69709],[69714,69743],[69745,69746],[69749],[69763,69807],[69819,69820],[69822,69825],[69840,69864],[69872,69881],[69891,69926],[69942,69956],[69959],[69968,70002],[70004,70006],[70019,70066],[70081],[70084,70088],[70093],[70096,70111],[70113,70132],[70144,70161],[70163,70187],[70200,70205],[70207,70208],[70272,70278],[70280],[70282,70285],[70287,70301],[70303,70313],[70320,70366],[70384,70393],[70405,70412],[70415,70416],[70419,70440],[70442,70448],[70450,70451],[70453,70457],[70461],[70480],[70493,70497],[70656,70708],[70727,70747],[70749],[70751,70753],[70784,70831],[70852,70855],[70864,70873],[71040,71086],[71105,71131],[71168,71215],[71233,71236],[71248,71257],[71264,71276],[71296,71338],[71352,71353],[71360,71369],[71424,71450],[71472,71494],[71680,71723],[71739],[71840,71922],[71935,71942],[71945],[71948,71955],[71957,71958],[71960,71983],[72004,72006],[72016,72025],[72096,72103],[72106,72144],[72161,72163],[72192],[72203,72242],[72255,72262],[72272],[72284,72323],[72346,72354],[72368,72440],[72448,72457],[72704,72712],[72714,72750],[72768,72773],[72784,72812],[72816,72847],[72960,72966],[72968,72969],[72971,73008],[73040,73049],[73056,73061],[73063,73064],[73066,73097],[73112],[73120,73129],[73440,73458],[73463,73464],[73476,73488],[73490,73523],[73539,73561],[73648],[73664,73713],[73727,74649],[74752,74862],[74864,74868],[74880,75075],[77712,77810],[77824,78895],[78913,78918],[82944,83526],[92160,92728],[92736,92766],[92768,92777],[92782,92862],[92864,92873],[92880,92909],[92917],[92928,92975],[92983,92997],[93008,93017],[93019,93025],[93027,93047],[93053,93071],[93760,93850],[93952,94026],[94032],[94099,94111],[94176,94179],[94208],[100343],[100352,101589],[101632],[101640],[110576,110579],[110581,110587],[110589,110590],[110592,110882],[110898],[110928,110930],[110933],[110948,110951],[110960,111355],[113664,113770],[113776,113788],[113792,113800],[113808,113817],[113820],[113823],[118608,118723],[118784,119029],[119040,119078],[119081,119140],[119146,119148],[119171,119172],[119180,119209],[119214,119274],[119296,119361],[119365],[119488,119507],[119520,119539],[119552,119638],[119648,119672],[119808,119892],[119894,119964],[119966,119967],[119970],[119973,119974],[119977,119980],[119982,119993],[119995],[119997,120003],[120005,120069],[120071,120074],[120077,120084],[120086,120092],[120094,120121],[120123,120126],[120128,120132],[120134],[120138,120144],[120146,120485],[120488,120779],[120782,121343],[121399,121402],[121453,121460],[121462,121475],[121477,121483],[122624,122654],[122661,122666],[122928,122989],[123136,123180],[123191,123197],[123200,123209],[123214,123215],[123536,123565],[123584,123627],[123632,123641],[123647],[124112,124139],[124144,124153],[124896,124902],[124904,124907],[124909,124910],[124912,124926],[124928,125124],[125127,125135],[125184,125251],[125259],[125264,125273],[125278,125279],[126065,126132],[126209,126269],[126464,126467],[126469,126495],[126497,126498],[126500],[126503],[126505,126514],[126516,126519],[126521],[126523],[126530],[126535],[126537],[126539],[126541,126543],[126545,126546],[126548],[126551],[126553],[126555],[126557],[126559],[126561,126562],[126564],[126567,126570],[126572,126578],[126580,126583],[126585,126588],[126590],[126592,126601],[126603,126619],[126625,126627],[126629,126633],[126635,126651],[126704,126705],[126976,127019],[127024,127123],[127136,127150],[127153,127167],[127169,127183],[127185,127221],[127232,127405],[127488,127490],[127504,127547],[127552,127560],[127568,127569],[127584,127589],[127744,127994],[128000,128727],[128732,128748],[128752,128764],[128768,128886],[128891,128985],[128992,129003],[129008],[129024,129035],[129040,129095],[129104,129113],[129120,129159],[129168,129197],[129200,129201],[129280,129619],[129632,129645],[129648,129660],[129664,129672],[129680,129725],[129727,129733],[129742,129755],[129760,129768],[129776,129784],[129792,129938],[129940,129994],[130032,130041],[131072],[173791],[173824],[177977],[177984],[178205],[178208],[183969],[183984],[191456],[191472],[192093],[194560,195101],[196608],[201546],[201552],[205743]],Nr=[[192,197],[199,207],[209,214],[217,221],[224,229],[231,239],[241,246],[249,253],[255,271],[274,293],[296,304],[308,311],[313,318],[323,328],[332,337],[340,357],[360,382],[416,417],[431,432],[461,476],[478,483],[486,496],[500,501],[504,539],[542,543],[550,563],[901,902],[904,906],[908],[910,912],[938,944],[970,974],[979,980],[1024,1025],[1027],[1031],[1036,1038],[1049],[1081],[1104,1105],[1107],[1111],[1116,1118],[1142,1143],[1217,1218],[1232,1235],[1238,1239],[1242,1247],[1250,1255],[1258,1269],[1272,1273],[1570,1574],[1728],[1730],[1747],[2345],[2353],[2356],[2392,2399],[2524,2525],[2527],[2611],[2614],[2649,2651],[2654],[2908,2909],[2964],[3907],[3917],[3922],[3927],[3932],[3945],[4134],[6918],[6920],[6922],[6924],[6926],[6930],[7680,7833],[7835],[7840,7929],[7936,7957],[7960,7965],[7968,8005],[8008,8013],[8016,8023],[8025],[8027],[8029],[8031,8048],[8050],[8052],[8054],[8056],[8058],[8060],[8064,8116],[8118,8122],[8124],[8129,8132],[8134,8136],[8138],[8140,8146],[8150,8154],[8157,8162],[8164,8170],[8172,8173],[8178,8180],[8182,8184],[8186],[8188],[8602,8603],[8622],[8653,8655],[8708],[8713],[8716],[8740],[8742],[8769],[8772],[8775],[8777],[8800],[8802],[8813,8817],[8820,8821],[8824,8825],[8832,8833],[8836,8837],[8840,8841],[8876,8879],[8928,8931],[8938,8941],[10972],[12364],[12366],[12368],[12370],[12372],[12374],[12376],[12378],[12380],[12382],[12384],[12386],[12389],[12391],[12393],[12400,12401],[12403,12404],[12406,12407],[12409,12410],[12412,12413],[12436],[12446],[12460],[12462],[12464],[12466],[12468],[12470],[12472],[12474],[12476],[12478],[12480],[12482],[12485],[12487],[12489],[12496,12497],[12499,12500],[12502,12503],[12505,12506],[12508,12509],[12532],[12535,12538],[12542],[44032],[55203],[64285],[64287],[64298,64310],[64312,64316],[64318],[64320,64321],[64323,64324],[64326,64334],[69786],[69788],[69803],[119134,119140],[119227,119232]],SE=String.fromCodePoint,Br=Math.min,Vr=Math.max;function yH(X){if(X.length===1){let Q=SE(X[0]);return{num:1,build:()=>Q}}let Y=X[0];return{num:X[1]-X[0]+1,build:(Q)=>SE(Y+Q)}}function vE(X,Y){let Q=[],_=0,G=0;while(_<X.length&&G<Y.length){let J=X[_],Z=J[0],K=J.length===1?J[0]:J[1],H=Y[G],W=H[0],D=H.length===1?H[0]:H[1];if(K<W)_+=1;else if(D<Z)G+=1;else{let U=Vr(Z,W),N=Br(K,D);if(Q.length>=1){let B=Q[Q.length-1];if((B.length===1?B[0]:B[1])+1===U)U=B[0],MA(Q)}if(S(Q,U===N?[U]:[U,N]),K<=N)_+=1;if(D<=N)G+=1}}return Q}var xE=Object.create(null);function qr(X){switch(X){case"full":return Ur;case"ascii":return Wr}}function zr(X,Y){let Q=`${X}:${Y}`,_=xE[Q];if(_!==void 0)return _;let G=qr(Y),J=X==="binary"?G:vE(G,Dr),Z=[];for(let H of J)S(Z,yH(H));if(X==="grapheme"){let H=vE(G,Nr);for(let W of H){let D=yH(W);S(Z,{num:D.num,build:(U)=>Ac(D.build(U),"NFD")})}}let K=M9(...Z);return xE[Q]=K,K}function SQ(X,Y){return zr(X,Y)}function Or(X){if(typeof X.unit==="object")return X.unit;switch(X.unit){case"grapheme":return SQ("grapheme","full");case"grapheme-composite":return SQ("composite","full");case"grapheme-ascii":case void 0:return SQ("grapheme","ascii");case"binary":return SQ("binary","full");case"binary-ascii":return SQ("binary","ascii")}}function s0(X={}){let Y=Or(X),Q=Jr(Y,X),_=Hr(Y,X);return w0(Y,{...X,experimentalCustomSlices:_}).map(_r,Q)}var KP=Map,NW=String.fromCharCode,BW={num:26,build:(X)=>NW(X+97)},Lr={num:26,build:(X)=>NW(X+65)},HP={num:10,build:(X)=>NW(X+48)};function Tr(X){let Y=yu(X);return X!==Y?Y:`%${gQ(P9(X,0),16)}`}function Rr(X){if(typeof X!=="string")throw Error("Unsupported");return decodeURIComponent(X)}var Fr=()=>s0({unit:"binary",minLength:1,maxLength:1}).map(Tr,Rr),NH=void 0;function Er(){if(NH===void 0)NH=M9(BW);return NH}var UG=void 0;function hH(X){if(UG===void 0)UG=new KP;let Y=NX(UG,X);if(Y===void 0)Y=M9(BW,HP,{num:X.length,build:(Q)=>X[Q]}),nX(UG,X,Y);return Y}function Ar(X){return M9(BW,Lr,HP,{num:X.length,build:(Y)=>X[Y]})}var DG=void 0;function VW(X){if(DG===void 0)DG=new KP;let Y=NX(DG,X);if(Y===void 0)Y=G1({weight:10,arbitrary:Ar(X)},{weight:1,arbitrary:Fr()}),nX(DG,X,Y);return Y}function H8(X,Y={}){let Q=Y.freq===void 0?6:Y.freq,_=vA(Y,"nil")?Y.nil:null,G=[{arbitrary:v0(_),weight:1,fallbackValue:{default:_}},{arbitrary:X,weight:Q-1}],J={withCrossShrink:!0,depthSize:Y.depthSize,maxDepth:Y.maxDepth,depthIdentifier:Y.depthIdentifier};return gH.from(G,J,"fc.option")}function Pr(X){if(X.length>63)return!1;return X.length<4||X[0]!=="x"||X[1]!=="n"||X[2]!=="-"||X[3]!=="-"}var WP=Symbol("adapted-value");function wr(X,Y){let Q=Y(X.value_);if(!Q.adapted)return X;return new g(Q.value,WP)}var Cr=class extends k0{constructor(X,Y){super();this.sourceArb=X,this.adapter=Y,this.adaptValue=(Q)=>wr(Q,Y)}generate(X,Y){let Q=this.sourceArb.generate(X,Y);return this.adaptValue(Q)}canShrinkWithoutContext(X){return this.sourceArb.canShrinkWithoutContext(X)&&!this.adapter(X).adapted}shrink(X,Y){if(Y===WP){if(!this.sourceArb.canShrinkWithoutContext(X))return Z0.nil();return this.sourceArb.shrink(X,void 0).map(this.adaptValue)}return this.sourceArb.shrink(X,Y).map(this.adaptValue)}};function UP(X,Y){return new Cr(X,Y)}function Mr([X,Y]){return Y===null?X:`${X}${Y[0]}${Y[1]}`}function Ir(X){if(typeof X!=="string"||X.length===0)throw Error("Unsupported");if(X.length===1)return[X[0],null];return[X[0],[m0(X,1,X.length-1),X[X.length-1]]]}function jr(X){let Y=hH("");return $0(Y,H8($0(s0({unit:hH("-"),size:X,maxLength:61}),Y))).map(Mr,Ir).filter(Pr)}function Sr(X){return`${x0(X[0],".")}.${X[1]}`}function vr(X){if(typeof X!=="string")throw Error("Unsupported type");let Y=X.lastIndexOf(".");return[f1(m0(X,0,Y),"."),m0(X,Y+1)]}function xr(X){let[Y,Q]=X,_=Q.length;for(let G=0;G!==Y.length;++G)if(_+=1+Y[G].length,_>255)return{adapted:!0,value:[_1(Y,0,G),Q]};return{adapted:!1,value:X}}function qW(X={}){let Y=UW(X.size),Q=dQ("-1",Y),_=s0({unit:Er(),minLength:2,maxLength:63,size:Q});return UP($0(w0(jr(Y),{size:Q,minLength:1,maxLength:127}),_),xr).map(Sr,vr)}function kr(X){let Y=X[0].length;for(let Q=1;Q!==X.length;++Q)if(Y+=1+X[Q].length,Y>64)return{adapted:!0,value:_1(X,0,Q)};return{adapted:!1,value:X}}function br(X){return x0(X,".")}function gr(X){if(typeof X!=="string")throw Error("Unsupported");return f1(X,".")}function yr(X){return`${X[0]}@${X[1]}`}function hr(X){if(typeof X!=="string")throw Error("Unsupported");return f1(X,"@",2)}function mr(X={}){return $0(UP(w0(s0({unit:hH("!#$%&'*+-/=?^_`{|}~"),minLength:1,maxLength:64,size:X.size}),{minLength:1,maxLength:32,size:X.size}),kr).map(br,gr),qW({size:X.size})).map(yr,hr)}var{NEGATIVE_INFINITY:dr,POSITIVE_INFINITY:mH,EPSILON:DP}=$8,zW=b(2146435072)*b(4294967296),fr=-zW-b(1),kE=4503599627370496,pr=b(4503599627370495),bE=b("9007199254740992"),dH=new Float64Array(1),gE=new Uint32Array(dH.buffer,dH.byteOffset);function ur(X){return dH[0]=X,[gE[1],gE[0]]}function cr(X){let{0:Y,1:Q}=ur(X),_=Y>>>31,G=Y>>>20&2047,J=(Y&1048575)*4294967296+Q,Z=G===0?-1022:G-1023,K=G===0?0:1;return K+=J*DP,K*=_===0?1:-1,{exponent:Z,significand:K}}function yE(X,Y){if(X===-1022)return b(Y*kE);return b((Y-1)*kE)+(b(X+1023)<<b(52))}function OW(X){if(X===mH)return zW;if(X===dr)return fr;let Y=cr(X),Q=Y.exponent,_=Y.significand;if(X>0||X===0&&1/X===mH)return yE(Q,_);else return-yE(Q,-_)-b(1)}function fH(X){if(X<0)return-fH(-X-b(1));if(X===zW)return mH;if(X<bE)return $8(X)*0.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005;let Y=X-bE,Q=-1021+$8(Y>>b(52));return(1+$8(Y&pr)*DP)*2**Q}var hE=Number.isInteger,mE=Object.is,BH=Number.NEGATIVE_INFINITY,VH=Number.POSITIVE_INFINITY;function NP(X,Y,Q,_){let{noDefaultInfinity:G=!1,minExcluded:J=!1,maxExcluded:Z=!1,min:K=G?-Y:BH,max:H=G?Y:VH}=X,W=J?K<-Q?-_:Math.max(K,-Q):K===BH?Math.max(K,-_):Math.max(K,-Q),D=Z?H>Q?_:Math.min(H,Q):H===VH?Math.min(H,_):Math.min(H,Q);return{noDefaultInfinity:!1,minExcluded:J||(K!==BH||J)&&hE(W),maxExcluded:Z||(H!==VH||Z)&&hE(D),min:mE(W,-0)?0:W,max:mE(D,0)?-0:D,noNaN:X.noNaN||!1}}var{NEGATIVE_INFINITY:BP,POSITIVE_INFINITY:VP,MAX_VALUE:lr}=Number,or=4503599627370495.5,qP=4503599627370496;function rr(X){return NP(X,lr,or,qP)}function ir(X){return X===4503599627370496?VP:X===-4503599627370496?BP:X}function nr(X){if(typeof X!=="number")throw Error("Unsupported type");return X===VP?qP:X===BP?-4503599627370496:X}var{isInteger:sr,isNaN:zP,NEGATIVE_INFINITY:ar,POSITIVE_INFINITY:tr,MAX_VALUE:dE}=Number,er=NaN;function fE(X,Y){if(zP(X))throw Error("fc.double constraints."+Y+" must be a 64-bit float");return OW(X)}function Xi(X){if(typeof X!=="number")throw Error("Unsupported type");return OW(X)}function Yi(X){return!sr(X)}function pE(X){let{noDefaultInfinity:Y=!1,noNaN:Q=!1,minExcluded:_=!1,maxExcluded:G=!1,min:J=Y?-dE:ar,max:Z=Y?dE:tr}=X,K=fE(J,"min"),H=_?K+b(1):K,W=fE(Z,"max"),D=G?W-b(1):W;if(D<H)throw Error("fc.double constraints.min must be smaller or equal to constraints.max");if(Q)return Y4({min:H,max:D}).map(fH,Xi);let U=D>b(0),N=U?H:H-b(1),B=U?D+b(1):D;return Y4({min:N,max:B}).map((q)=>{if(D<q||q<H)return er;else return fH(q)},(q)=>{if(typeof q!=="number")throw Error("Unsupported type");if(zP(q))return D!==B?B:N;return OW(q)})}function SG(X={}){if(!X.noInteger)return pE(X);return pE(rr(X)).map(ir,nr).filter(Yi)}var{NEGATIVE_INFINITY:Qi,POSITIVE_INFINITY:pH}=Number,_i=Math.imul,uH=340282346638528860000000000000000000000,OP=2139095040,Gi=-2139095041,cH=new Float32Array(1),Ji=new Uint32Array(cH.buffer,cH.byteOffset);function $i(X){return cH[0]=X,Ji[0]}function Zi(X){let Y=$i(X),Q=Y>>>31,_=Y>>>23&255,G=Y&8388607,J=_===0?-126:_-127,Z=_===0?0:1;return Z+=G/8388608,Z*=Q===0?1:-1,{exponent:J,significand:Z}}function uE(X,Y){if(X===-126)return Y*8388608;return _i(X+127,8388608)+(Y-1)*8388608}function LW(X){if(X===pH)return OP;if(X===Qi)return Gi;let Y=Zi(X),Q=Y.exponent,_=Y.significand;if(X>0||X===0&&1/X===pH)return uE(Q,_);else return-uE(Q,-_)-1}function lH(X){if(X<0)return-lH(-X-1);if(X===OP)return pH;if(X<16777216)return X*0.000000000000000000000000000000000000000000001401298464324817;let Y=X-16777216,Q=-125+(Y>>23);return(1+(Y&8388607)/8388608)*2**Q}var{NEGATIVE_INFINITY:LP,POSITIVE_INFINITY:TP}=Number,Ki=uH,Hi=8388607.5,RP=8388608;function Wi(X){return NP(X,Ki,Hi,RP)}function Ui(X){return X===8388608?TP:X===-8388608?LP:X}function Di(X){if(typeof X!=="number")throw Error("Unsupported type");return X===TP?RP:X===LP?-8388608:X}var{isInteger:Ni,isNaN:FP}=Number,Bi=Math.fround,Vi=Number.NEGATIVE_INFINITY,qi=Number.POSITIVE_INFINITY,zi=NaN;function cE(X,Y){let Q="fc.float constraints."+Y+" must be a 32-bit float - you can convert any double to a 32-bit float by using `Math.fround(myDouble)`";if(FP(X)||Bi(X)!==X)throw Error(Q);return LW(X)}function Oi(X){if(typeof X!=="number")throw Error("Unsupported type");return LW(X)}function Li(X){return!Ni(X)}function lE(X){let{noDefaultInfinity:Y=!1,noNaN:Q=!1,minExcluded:_=!1,maxExcluded:G=!1,min:J=Y?-uH:Vi,max:Z=Y?uH:qi}=X,K=cE(J,"min"),H=_?K+1:K,W=cE(Z,"max"),D=G?W-1:W;if(H>D)throw Error("fc.float constraints.min must be smaller or equal to constraints.max");if(Q)return A0({min:H,max:D}).map(lH,Oi);let U=D>0?H:H-1,N=D>0?D+1:D;return A0({min:U,max:N}).map((B)=>{if(B>D||B<H)return zi;else return lH(B)},(B)=>{if(typeof B!=="number")throw Error("Unsupported type");if(FP(B))return D!==N?N:U;return LW(B)})}function EP(X={}){if(!X.noInteger)return lE(X);return lE(Wi(X)).map(Ui,Di).filter(Li)}function Ti(X){return X.replace(/([$`\\])/g,"\\$1").replace(/\r/g,"\\r")}function AP(X){return X.replace(/\*\//g,"*\\/")}var UX=[0,1996959894,3993919788,2567524794,124634137,1886057615,3915621685,2657392035,249268274,2044508324,3772115230,2547177864,162941995,2125561021,3887607047,2428444049,498536548,1789927666,4089016648,2227061214,450548861,1843258603,4107580753,2211677639,325883990,1684777152,4251122042,2321926636,335633487,1661365465,4195302755,2366115317,997073096,1281953886,3579855332,2724688242,1006888145,1258607687,3524101629,2768942443,901097722,1119000684,3686517206,2898065728,853044451,1172266101,3705015759,2882616665,651767980,1373503546,3369554304,3218104598,565507253,1454621731,3485111705,3099436303,671266974,1594198024,3322730930,2970347812,795835527,1483230225,3244367275,3060149565,1994146192,31158534,2563907772,4023717930,1907459465,112637215,2680153253,3904427059,2013776290,251722036,2517215374,3775830040,2137656763,141376813,2439277719,3865271297,1802195444,476864866,2238001368,4066508878,1812370925,453092731,2181625025,4111451223,1706088902,314042704,2344532202,4240017532,1658658271,366619977,2362670323,4224994405,1303535960,984961486,2747007092,3569037538,1256170817,1037604311,2765210733,3554079995,1131014506,879679996,2909243462,3663771856,1141124467,855842277,2852801631,3708648649,1342533948,654459306,3188396048,3373015174,1466479909,544179635,3110523913,3462522015,1591671054,702138776,2966460450,3352799412,1504918807,783551873,3082640443,3233442989,3988292384,2596254646,62317068,1957810842,3939845945,2647816111,81470997,1943803523,3814918930,2489596804,225274430,2053790376,3826175755,2466906013,167816743,2097651377,4027552580,2265490386,503444072,1762050814,4150417245,2154129355,426522225,1852507879,4275313526,2312317920,282753626,1742555852,4189708143,2394877945,397917763,1622183637,3604390888,2714866558,953729732,1340076626,3518719985,2797360999,1068828381,1219638859,3624741850,2936675148,906185462,1090812512,3747672003,2825379669,829329135,1181335161,3412177804,3160834842,628085408,1382605366,3423369109,3138078467,570562233,1426400815,3317316542,2998733608,733239954,1555261956,3268935591,3050360625,752459403,1541320221,2607071920,3965973030,1969922972,40735498,2617837225,3943577151,1913087877,83908371,2512341634,3803740692,2075208622,213261112,2463272603,3855990285,2094854071,198958881,2262029012,4057260610,1759359992,534414190,2176718541,4139329115,1873836001,414664567,2282248934,4279200368,1711684554,285281116,2405801727,4167216745,1634467795,376229701,2685067896,3608007406,1308918612,956543938,2808555105,3495958263,1231636301,1047427035,2932959818,3654703836,1088359270,936918000,2847714899,3736837829,1202900863,817233897,3183342108,3401237130,1404277552,615818150,3134207493,3453421203,1423857449,601450431,3009837614,3294710456,1567103746,711928724,3020668471,3272380065,1510334235,755167117];function CG(X){let Y=4294967295;for(let Q=0;Q<X.length;++Q){let _=P9(X,Q);if(_<128)Y=UX[Y&255^_]^Y>>8;else if(_<2048)Y=UX[Y&255^(192|_>>6&31)]^Y>>8,Y=UX[Y&255^(128|_&63)]^Y>>8;else if(_>=55296&&_<57344){let G=P9(X,++Q);if(_>=56320||G<56320||G>57343||Number.isNaN(G))Q-=1,Y=UX[Y&255^239]^Y>>8,Y=UX[Y&255^191]^Y>>8,Y=UX[Y&255^189]^Y>>8;else{let J=(_&1023)+64,Z=G&1023;Y=UX[Y&255^(240|J>>8&7)]^Y>>8,Y=UX[Y&255^(128|J>>2&63)]^Y>>8,Y=UX[Y&255^(128|Z>>6&15|(J&3)<<4)]^Y>>8,Y=UX[Y&255^(128|Z&63)]^Y>>8}}else Y=UX[Y&255^(224|_>>12&15)]^Y>>8,Y=UX[Y&255^(128|_>>6&63)]^Y>>8,Y=UX[Y&255^(128|_&63)]^Y>>8}return(Y|0)+2147483648}var Ri=Object.getPrototypeOf,vQ=class extends k0{constructor(X){super();this.arb=X}generate(X,Y){return this.arb.generate(X,Y)}canShrinkWithoutContext(X){return this.arb.canShrinkWithoutContext(X)}shrink(X,Y){return Z0.nil()}};function MG(X){if(Ri(X)===vQ.prototype&&X.generate===vQ.prototype.generate&&X.canShrinkWithoutContext===vQ.prototype.canShrinkWithoutContext&&X.shrink===vQ.prototype.shrink)return X;return new vQ(X)}var{assign:Fi,keys:Ei}=Object;function PP(X){return $0(MG(A0()),MG(A0({min:1,max:4294967295}))).map(([Y,Q])=>{let _=()=>{let G={};return Fi((Z,K)=>{let H=r0(Z),W=r0(K),D=X(CG(`${Y}${H}`)%Q,CG(`${Y}${W}`)%Q);return G[`[${H},${W}]`]=D,D},{toString:()=>{let Z=Ei(G).sort().map((K)=>`${K} => ${r0(G[K])}`).map((K)=>`/* ${AP(K)} */`);return`function(a, b) {
  // With hash and stringify coming from fast-check${Z.length!==0?`
  ${x0(Z,`
  `)}`:""}
  const cmp = ${X};
  const hA = hash('${Y}' + stringify(a)) % ${Q};
  const hB = hash('${Y}' + stringify(b)) % ${Q};
  return cmp(hA, hB);
}`},[J1]:_})};return _()})}var Ai=Object.assign;function Pi(){return PP(Ai((X,Y)=>X<Y,{toString(){return"(hA, hB) => hA < hB"}}))}var wi=Object.assign;function Ci(){return PP(wi((X,Y)=>X-Y,{toString(){return"(hA, hB) => hA - hB"}}))}var{defineProperties:Mi,keys:Ii}=Object;function ji(X){return $0(w0(X,{minLength:1}),MG(A0())).map(([Y,Q])=>{let _=()=>{let G={},J=(...K)=>{let H=r0(K),W=Y[CG(`${Q}${H}`)%Y.length];return G[H]=W,Z5(W)?W[J1]():W};function Z(K){let H=q0(q0(jA(Ii(G)),(W)=>`${W} => ${r0(G[W])}`),(W)=>`/* ${AP(W)} */`);return`function(...args) {
  // With hash and stringify coming from fast-check${H.length!==0?`
  ${H.join(`
  `)}`:""}
  const outs = ${K};
  return outs[hash('${Q}' + stringify(args)) % outs.length];
}`}return Mi(J,{toString:{value:()=>Z(r0(Y))},[tX]:{value:()=>Z(r0(Y))},[K8]:{value:async()=>Z(await JW(Y))},[J1]:{value:_,configurable:!0}})};return _()})}var{MIN_SAFE_INTEGER:Si,MAX_SAFE_INTEGER:vi}=Number;function wP(){return new C9(Si,vi)}var xi=Number.MAX_SAFE_INTEGER;function ki(){return new C9(0,xi)}var bi=Number.parseInt;function gi(X){let[Y,Q]=X;switch(Y){case"oct":return`0${gQ(Q,8)}`;case"hex":return`0x${gQ(Q,16)}`;default:return`${Q}`}}function OG(X,Y){let Q=bi(X,Y);if(gQ(Q,Y)!==X)throw Error("Invalid value");return Q}function yi(X){if(typeof X!=="string")throw Error("Invalid type");if(X.length>=2&&X[0]==="0"){if(X[1]==="x")return["hex",OG(m0(X,2),16)];return["oct",OG(m0(X,1),8)]}return["dec",OG(X,10)]}function hi(X){return x0(X,".")}function mi(X){if(typeof X!=="string")throw Error("Invalid type");return q0(f1(X,"."),(Y)=>OG(Y,10))}function TW(){return $0(t8(255),t8(255),t8(255),t8(255)).map(hi,mi)}function E6(X){return $0(A6("dec","oct","hex"),t8(X)).map(gi,yi)}function qH(X){return x0(X,".")}function zH(X){if(typeof X!=="string")throw Error("Invalid type");return f1(X,".")}function CP(){return G1($0(E6(255),E6(255),E6(255),E6(255)).map(qH,zH),$0(E6(255),E6(255),E6(65535)).map(qH,zH),$0(E6(255),E6(16777215)).map(qH,zH),E6(4294967295))}function RW(X){if(X.length===0)return[];else return f1(X,":")}function FW(X){let Y=f1(X,":");if(Y.length>=2&&Y[Y.length-1].length<=4)return[_1(Y,0,Y.length-2),`${Y[Y.length-2]}:${Y[Y.length-1]}`];return[_1(Y,0,Y.length-1),Y[Y.length-1]]}function di(X){return`${x0(X[0],":")}:${X[1]}`}function fi(X){if(typeof X!=="string")throw Error("Invalid type");return FW(X)}function pi(X){return`::${x0(X[0],":")}:${X[1]}`}function ui(X){if(typeof X!=="string")throw Error("Invalid type");if(!Rc(X,"::"))throw Error("Invalid value");return FW(m0(X,2))}function LG(X){return`${x0(X[0],":")}::${x0(X[1],":")}:${X[2]}`}function TG(X){if(typeof X!=="string")throw Error("Invalid type");let[Y,Q]=f1(X,"::",2),[_,G]=FW(Q);return[RW(Y),_,G]}function ci(X){return LG([X[0],[X[1]],X[2]])}function li(X){let Y=TG(X);return[Y[0],x0(Y[1],":"),Y[2]]}function oE(X){return`${x0(X[0],":")}::${X[1]}`}function rE(X){if(typeof X!=="string")throw Error("Invalid type");let[Y,Q]=f1(X,"::",2);return[RW(Y),Q]}function oi(X){return`${x0(X[0],":")}::`}function ri(X){if(typeof X!=="string")throw Error("Invalid type");if(!Fc(X,"::"))throw Error("Invalid value");return[RW(m0(X,0,X.length-2))]}function ii([X,Y]){return`${X}:${Y}`}function ni(X){if(typeof X!=="string")throw new y("Invalid type");if(!X.includes(":"))throw new y("Invalid value");return X.split(":",2)}var si="0123456789abcdef",OH=void 0;function ai(){if(OH===void 0)OH=A0({min:0,max:15}).map((X)=>si[X],(X)=>{if(typeof X!=="string")throw new y("Not a string");if(X.length!==1)throw new y("Invalid length");let Y=P9(X,0);if(Y<=57)return Y-48;if(Y<97)throw new y("Invalid character");return Y-87});return OH}function MP(){let X=s0({unit:ai(),minLength:1,maxLength:4,size:"max"}),Y=G1($0(X,X).map(ii,ni),TW());return G1($0(w0(X,{minLength:6,maxLength:6,size:"max"}),Y).map(di,fi),$0(w0(X,{minLength:5,maxLength:5,size:"max"}),Y).map(pi,ui),$0(w0(X,{minLength:0,maxLength:1,size:"max"}),w0(X,{minLength:4,maxLength:4,size:"max"}),Y).map(LG,TG),$0(w0(X,{minLength:0,maxLength:2,size:"max"}),w0(X,{minLength:3,maxLength:3,size:"max"}),Y).map(LG,TG),$0(w0(X,{minLength:0,maxLength:3,size:"max"}),w0(X,{minLength:2,maxLength:2,size:"max"}),Y).map(LG,TG),$0(w0(X,{minLength:0,maxLength:4,size:"max"}),X,Y).map(ci,li),$0(w0(X,{minLength:0,maxLength:5,size:"max"}),Y).map(oE,rE),$0(w0(X,{minLength:0,maxLength:6,size:"max"}),X).map(oE,rE),$0(w0(X,{minLength:0,maxLength:7,size:"max"})).map(oi,ri))}var ti=class extends k0{constructor(X){super();this.name=X,this.underlying=null}generate(X,Y){if(this.underlying===null)throw Error(`Lazy arbitrary ${JSON.stringify(this.name)} not correctly initialized`);return this.underlying.generate(X,Y)}canShrinkWithoutContext(X){if(this.underlying===null)throw Error(`Lazy arbitrary ${JSON.stringify(this.name)} not correctly initialized`);return this.underlying.canShrinkWithoutContext(X)}shrink(X,Y){if(this.underlying===null)throw Error(`Lazy arbitrary ${JSON.stringify(this.name)} not correctly initialized`);return this.underlying.shrink(X,Y)}},ei=Object.getOwnPropertyNames;function Xn(){let X=new Z8;return(Q)=>{let _=NX(X,Q);if(_!==void 0)return _;return _=new ti(String(Q)),nX(X,Q,_),_}}function IP(X){let Y=Xn(),Q=X(Y),_=ei(Q);for(let G of _){let J=Y(G);J.underlying=Q[G]}return Q}function Yn(X,Y){for(let Q of X){let _=Y[Q]||{};if(_.maxLength===void 0||_.maxLength>0)return!0}return!1}function Qn(X,Y){if(X.length===0)return v0([]);if(!Yn(X,Y))throw new y("Contraints on pool must accept at least one entity, maxLength cannot sum to 0");return $0(...X.map((Q)=>w0(v0(Q),Y[Q]))).map((Q)=>su(Q)).filter((Q)=>Q.length>0)}var{assign:iE,create:RG,defineProperty:jP,getPrototypeOf:nE,prototype:_n}=Object;function Gn(X){return jP(RG(null),tX,{configurable:!1,enumerable:!1,writable:!1,value:()=>X})}function sE(X,Y){return Gn(`<${d1(X)}#${Y}>`)}function Jn(X,Y){let Q=RG(_n);for(let _ in X){let G=X[_],J=[];for(let Z of G){let K=iE(RG(nE(Z)),Z);J.push(K)}Q[_]=J}for(let _ in Y){let G=Y[_];for(let J=0;J!==G.length;++J){let Z=G[J],K=Q[_][J];for(let H in Z){let W=Z[H];K[H]=W.index===void 0?void 0:typeof W.index==="number"?Q[W.type][W.index]:q0(W.index,(D)=>Q[W.type][D])}jP(K,tX,{configurable:!1,enumerable:!1,writable:!1,value:()=>{let H=X[_][J],W=iE(RG(nE(H)),H);for(let D in Z){let U=Z[D];W[D]=U.index===void 0?void 0:typeof U.index==="number"?sE(U.type,U.index):q0(U.index,(N)=>sE(U.type,N))}return r0(W)}})}}return Q}function $n(X){let Y=0,Q=new Z8;for(let G in X){let J=X[G];for(let Z in J){let K=J[Z];if(K.arity!=="inverse")continue;let H=NX(Q,K.type);if(H===void 0)H=new Z8,nX(Q,K.type,H);if(Wc(H,K.forwardRelationship))throw new y(`Cannot declare multiple inverse relationships for the same forward relationship ${d1(K.forwardRelationship)} on type ${d1(K.type)}`);nX(H,K.forwardRelationship,{type:G,property:Z}),Y+=1}}let _=new Z8;if(Y===0)return _;for(let G in X){let J=X[G],Z=NX(Q,G);if(Z===void 0)continue;for(let K in J){let H=J[K];if(H.arity==="inverse")continue;let W=NX(Z,K);if(W===void 0)continue;if(W.type!==H.type)throw new y(`Inverse relationship ${d1(W.property)} on type ${d1(W.type)} references forward relationship ${d1(K)} but types do not match`);nX(_,H,W)}}if(_.size!==Y)throw new y("Some inverse relationships could not be matched with their corresponding forward relationships");return _}var{assign:aE,create:IG}=Object;function Zn(X,Y,Q){switch(X){case"exclusive":return v0(Q);case"successor":return wG(A0({min:Y!==void 0?Y+1:0,max:Q}));case"any":return wG(A0({min:0,max:Q}))}}function Kn(X,Y,Q,_,G){let J=Zn(Y,Q,_);switch(X){case"0-1":return H8(J,{nil:void 0,depthIdentifier:G});case"1":return J;case"many":{let Z=0;return H8(H5(J,{depthIdentifier:G,selector:(K)=>K===_?K+ ++Z:K,minLength:1}),{nil:[],depthIdentifier:G}).map((K)=>{let H=0;return q0(K,(W)=>W===_?W+H++:W)})}}}function SP(X,Y){let Q=IG(null),_=X[Y];for(let G in _){let J=_[G];if(J.arity==="inverse")Q[G]={type:J.type,index:[]}}return Q}function Hn(X){let Y=new sX,Q=new sX;for(let _ in X){let G=X[_];for(let J in G){let Z=G[J];if(Z.arity==="inverse")continue;if(Z.strategy==="exclusive"){if(a8(Y,Z.type))throw new y(`Cannot mix exclusive with other strategies for type ${d1(Z.type)}`);bQ(Q,Z.type)}else{if(a8(Q,Z.type))throw new y(`Cannot mix exclusive with other strategies for type ${d1(Z.type)}`);bQ(Y,Z.type)}if(Z.strategy==="successor"&&Z.type!==_)throw new y("Cannot mix types for the strategy successor");if(Z.strategy==="successor"&&Z.arity==="1")throw new y("Cannot use an arity of 1 for the strategy successor")}}}function Wn(X,Y){let{producedLinks:Q,toBeProducedEntities:_}=X,G=X.nextIndex+Y,J=aE(IG(null),Q);function Z(U){if(J[U]===Q[U])J[U]=_1(Q[U]);return J[U]}function K(U,N){let B=Z(U);if(B[N]===Q[U][N])B[N]=aE(IG(null),Q[U][N]);return B[N]}function H(U,N,B){let q=K(U,N),O=Q[U][N];if(O!==void 0&&q[B]===O[B]){let R=q[B];q[B]={type:R.type,index:typeof R.index==="object"?_1(R.index):R.index}}return q[B]}let W=void 0,D=_[G];return{setOutboundLink:(U,N)=>{let B=K(D.type,D.indexInType);B[U]=N},enqueueNewEntity:(U,N)=>{let B=Z(N),q=B.length;if(W===void 0)W=_1(_);return S(W,{type:N,indexInType:q,depth:D.depth+1}),S(B,SP(U,N)),q},appendBackReference:(U,N,B)=>{let q=H(U,N,B).index;S(q,D.indexInType)},commit:()=>({producedLinks:J,toBeProducedEntities:W!==void 0?W:_,nextIndex:G+1})}}function Un(X,Y){let Q=IG(null);for(let G in X)Q[G]=[];let _=[];for(let G of Y)S(_,{type:G,indexInType:Q[G].length,depth:0}),S(Q[G],SP(X,G));return{producedLinks:Q,toBeProducedEntities:_,nextIndex:0}}function Dn(X,Y,Q,_){let G=Q.producedLinks,J=Q.toBeProducedEntities[Q.nextIndex+_],Z=X[J.type],K=HW();K.depth=J.depth;let H=[],W=[];for(let D in Z){let U=Z[D];if(U.arity==="inverse")continue;let N=U.type,B=G[N].length;S(H,Kn(U.arity,U.strategy||"any",N===J.type?J.indexInType:void 0,B,K)),S(W,{name:D,relation:U,sentinelLinkIndex:B})}if(H.length===0)return;return $0(...H).map((D)=>{let U=Wn(Q,_);for(let N=0;N!==D.length;++N){let B=D[N],{name:q,relation:O,sentinelLinkIndex:R}=W[N],F=[],P=B===void 0?[]:typeof B==="number"?[B]:B;for(let C of P){let w;if(C>=R)w=U.enqueueNewEntity(X,O.type);else w=C;S(F,w);let L=NX(Y,O);if(L!==void 0)U.appendBackReference(O.type,w,L.property)}U.setOutboundLink(q,{type:O.type,index:B===void 0?void 0:typeof B==="number"?F[0]:F})}return U.commit()})}function Nn(X,Y){Hn(X);let Q=$n(X);return _P(v0(Un(X,Y)),(_)=>{if(_.nextIndex>=_.toBeProducedEntities.length)return;let G=0,J=void 0;while(J===void 0&&_.nextIndex+G<_.toBeProducedEntities.length)J=Dn(X,Q,_,G),G+=1;return J}).map((_)=>{return _.producedLinks})}var{keys:Bn,getOwnPropertySymbols:Vn,getOwnPropertyDescriptor:qn}=Object;function zn(X){let Y=Bn(X),Q=Vn(X);for(let _=0;_!==Q.length;++_){let G=Q[_],J=qn(X,G);if(J&&J.enumerable)Y.push(G)}return Y}var{create:On,defineProperty:Ln,getOwnPropertyDescriptor:Tn,getOwnPropertyNames:Rn,getOwnPropertySymbols:Fn}=Object;function En(X,Y){return function(_){let G=_[_.length-1]?On(null):{};for(let J=0;J!==X.length;++J){let Z=_[J];if(Z!==Y){let K=X[J];if(K==="__proto__")Ln(G,K,{value:Z,configurable:!0,enumerable:!0,writable:!0});else G[K]=Z}}return G}}function An(X,Y){return function(_){if(typeof _!=="object"||_===null)throw Error("Incompatible instance received: should be a non-null object");let G=Object.getPrototypeOf(_)===null,J="constructor"in _&&_.constructor===Object;if(!G&&!J)throw Error("Incompatible instance received: should be of exact type Object");let Z=0,K=[];for(let D=0;D!==X.length;++D){let U=Tn(_,X[D]);if(U!==void 0){if(!U.configurable||!U.enumerable||!U.writable)throw Error("Incompatible instance received: should contain only c/e/w properties");if(U.get!==void 0||U.set!==void 0)throw Error("Incompatible instance received: should contain only no get/set properties");++Z,S(K,U.value)}else S(K,Y)}let H=Rn(_).length,W=Fn(_).length;if(Z!==H+W)throw Error("Incompatible instance received: should not contain extra properties");return[...K,G]}}var LH=Symbol("no-key");function TH(X,Y,Q){let _=zn(X),G=[];for(let J=0;J!==_.length;++J){let Z=_[J],K=X[Z];if(Y===void 0||kQ(Y,Z)!==-1)S(G,K);else S(G,H8(K,{nil:LH}))}return $0(...G,Q?v0(!1):fQ()).map(En(_,LH),An(_,LH))}function oH(X,Y){let Q=Y!==void 0&&!!Y.noNullPrototype;if(Y===void 0)return TH(X,void 0,Q);if(!(("requiredKeys"in Y)&&Y.requiredKeys!==void 0))return TH(X,void 0,Q);let _=("requiredKeys"in Y?Y.requiredKeys:void 0)||[];for(let G=0;G!==_.length;++G){let J=Object.getOwnPropertyDescriptor(X,_[G]);if(J===void 0)throw Error("requiredKeys cannot reference keys that have not been defined in recordModel");if(!J.enumerable)throw Error("requiredKeys cannot reference keys that are not enumerable in recordModel")}return TH(X,_,Q)}var Pn=Object.create;function wn(X,Y,Q,_){let G=Pn(null);for(let J in X){let Z=X[J],K=oH(Z,_),H=Y(J),W=Q(J),D={minLength:H,maxLength:H};G[J]=W!==void 0?H5(K,{...D,selector:W}):w0(K,D)}return oH(G)}var{create:tE,keys:Cn}=Object;function Mn(X,Y,Q={}){let _=Cn(X),G=Q.initialPoolConstraints||tE(null),J=Q.unicityConstraints||tE(null),Z={noNullPrototype:Q.noNullPrototype};return Qn(_,G).chain((K)=>Nn(Y,K).chain((H)=>wn(X,(W)=>H[W].length,(W)=>J[W],Z).map((W)=>Jn(W,H))))}function In(X){return x0(q0(X,(Y)=>Y[Y.length-1]===","?m0(Y,0,Y.length-1):Y)," ")}function jn(X){return function(Q){if(typeof Q!=="string")throw Error("Unsupported type");let _=[];for(let G of f1(Q," "))if(X.canShrinkWithoutContext(G))S(_,G);else if(X.canShrinkWithoutContext(G+","))S(_,G+",");else throw Error("Unsupported word");return _}}function Sn(X){let Y=x0(X," ");if(Y[Y.length-1]===",")Y=m0(Y,0,Y.length-1);return eH(Y[0])+m0(Y,1)+"."}function vn(X){return function(Q){if(typeof Q!=="string")throw Error("Unsupported type");if(Q.length<2||Q[Q.length-1]!=="."||Q[Q.length-2]===","||eH(SH(Q[0]))!==Q[0])throw Error("Unsupported value");let _=SH(Q[0])+m0(Q,1,Q.length-1),G=[],J=f1(_," ");for(let Z=0;Z!==J.length;++Z){let K=J[Z];if(X.canShrinkWithoutContext(K))S(G,K);else if(Z===J.length-1&&X.canShrinkWithoutContext(K+","))S(G,K+",");else throw Error("Unsupported word")}return G}}function xn(X){return x0(X," ")}function kn(X){if(typeof X!=="string")throw Error("Unsupported type");let Y=f1(X,". ");for(let Q=0;Q<Y.length-1;++Q)Y[Q]+=".";return Y}var z=(X,Y)=>{return{arbitrary:v0(X),weight:Y}};function bn(){return G1(z("non",6),z("adipiscing",5),z("ligula",5),z("enim",5),z("pellentesque",5),z("in",5),z("augue",5),z("et",5),z("nulla",5),z("lorem",4),z("sit",4),z("sed",4),z("diam",4),z("fermentum",4),z("ut",4),z("eu",4),z("aliquam",4),z("mauris",4),z("vitae",4),z("felis",4),z("ipsum",3),z("dolor",3),z("amet,",3),z("elit",3),z("euismod",3),z("mi",3),z("orci",3),z("erat",3),z("praesent",3),z("egestas",3),z("leo",3),z("vel",3),z("sapien",3),z("integer",3),z("curabitur",3),z("convallis",3),z("purus",3),z("risus",2),z("suspendisse",2),z("lectus",2),z("nec,",2),z("ultricies",2),z("sed,",2),z("cras",2),z("elementum",2),z("ultrices",2),z("maecenas",2),z("massa,",2),z("varius",2),z("a,",2),z("semper",2),z("proin",2),z("nec",2),z("nisl",2),z("amet",2),z("duis",2),z("congue",2),z("libero",2),z("vestibulum",2),z("pede",2),z("blandit",2),z("sodales",2),z("ante",2),z("nibh",2),z("ac",2),z("aenean",2),z("massa",2),z("suscipit",2),z("sollicitudin",2),z("fusce",2),z("tempus",2),z("aliquam,",2),z("nunc",2),z("ullamcorper",2),z("rhoncus",2),z("metus",2),z("faucibus,",2),z("justo",2),z("magna",2),z("at",2),z("tincidunt",2),z("consectetur",1),z("tortor,",1),z("dignissim",1),z("congue,",1),z("non,",1),z("porttitor,",1),z("nonummy",1),z("molestie,",1),z("est",1),z("eleifend",1),z("mi,",1),z("arcu",1),z("scelerisque",1),z("vitae,",1),z("consequat",1),z("in,",1),z("pretium",1),z("volutpat",1),z("pharetra",1),z("tempor",1),z("bibendum",1),z("odio",1),z("dui",1),z("primis",1),z("faucibus",1),z("luctus",1),z("posuere",1),z("cubilia",1),z("curae,",1),z("hendrerit",1),z("velit",1),z("mauris,",1),z("gravida",1),z("ornare",1),z("ut,",1),z("pulvinar",1),z("varius,",1),z("turpis",1),z("nibh,",1),z("eros",1),z("id",1),z("aliquet",1),z("quis",1),z("lobortis",1),z("consectetuer",1),z("morbi",1),z("vehicula",1),z("tortor",1),z("tellus,",1),z("id,",1),z("eu,",1),z("quam",1),z("feugiat,",1),z("posuere,",1),z("iaculis",1),z("lectus,",1),z("tristique",1),z("mollis,",1),z("nisl,",1),z("vulputate",1),z("sem",1),z("vivamus",1),z("placerat",1),z("imperdiet",1),z("cursus",1),z("rutrum",1),z("iaculis,",1),z("augue,",1),z("lacus",1))}function gn(X={}){let{maxCount:Y,mode:Q="words",size:_}=X;if(Y!==void 0&&Y<1)throw Error("lorem has to produce at least one word/sentence");let G=bn();if(Q==="sentences")return w0(w0(G,{minLength:1,size:"small"}).map(Sn,vn(G)),{minLength:1,maxLength:Y,size:_}).map(xn,kn);else return w0(G,{minLength:1,maxLength:Y,size:_}).map(In,jn(G))}function yn(X){return new Map(X)}function hn(X){if(typeof X!=="object"||X===null)throw Error("Incompatible instance received: should be a non-null object");if(!("constructor"in X)||X.constructor!==Map)throw Error("Incompatible instance received: should be of exact type Map");return Array.from(X)}function mn(X){return X[0]}function rH(X,Y,Q={}){return H5($0(X,Y),{minLength:Q.minKeys,maxLength:Q.maxKeys,size:Q.size,selector:mn,depthIdentifier:Q.depthIdentifier,comparator:"SameValueZero"}).map(yn,hn)}var NG=10;function dn(X){let Y={};return(Q)=>{let _=Q!==void 0?Q:NG;if(!vA(Y,_)){let G=NG;NG=_-1,Y[_]=X(_),NG=G}return Y[_]}}function fn(X){let Y=0;while(X>b(0)){if(X&b(1))++Y;X>>=b(1)}return Y}function pn(X,Y){let Q=(b(1)<<b(Y))-b(1),_=X&Q,G=fn(X-_),J=_;for(let Z=b(1);Z<=Q&&G!==0;Z<<=b(1))if(!(J&Z))J|=Z,--G;return J}function BG(X,Y){let Q=[];for(let _=X.length-1;_!==-1;--_)if(Y(X[_])!==X[_])S(Q,_);return Q}function un(X,Y,Q){let _=b(0);for(let G=0,J=b(1);G!==Q.length;++G,J<<=b(1))if(X[Q[G]]!==Y[Q[G]])_|=J;return _}function RH(X,Y,Q,_){for(let G=0,J=b(1);G!==Q.length;++G,J<<=b(1))if(Y&J)X[Q[G]]=_(X[Q[G]])}var cn=class extends k0{constructor(X,Y,Q){super();this.stringArb=X,this.toggleCase=Y,this.untoggleAll=Q}buildContextFor(X,Y){return{rawString:X.value,rawStringContext:X.context,flags:Y.value,flagsContext:Y.context}}generate(X,Y){let Q=this.stringArb.generate(X,Y),_=[...Q.value],G=BG(_,this.toggleCase),J=Y4(b(0),(b(1)<<b(G.length))-b(1)).generate(X,void 0);return RH(_,J.value,G,this.toggleCase),new g(x0(_,""),this.buildContextFor(Q,J))}canShrinkWithoutContext(X){if(typeof X!=="string")return!1;return this.untoggleAll!==void 0?this.stringArb.canShrinkWithoutContext(this.untoggleAll(X)):this.stringArb.canShrinkWithoutContext(X)}shrink(X,Y){let Q;if(Y!==void 0)Q=Y;else if(this.untoggleAll!==void 0){let J=this.untoggleAll(X),Z=[...X],K=[...J];Q={rawString:J,rawStringContext:void 0,flags:un(K,Z,BG(K,this.toggleCase)),flagsContext:void 0}}else Q={rawString:X,rawStringContext:void 0,flags:b(0),flagsContext:void 0};let{rawString:_,flags:G}=Q;return this.stringArb.shrink(_,Q.rawStringContext).map((J)=>{let Z=[...J.value],K=BG(Z,this.toggleCase),H=pn(G,K.length);return RH(Z,H,K,this.toggleCase),new g(x0(Z,""),this.buildContextFor(J,new g(H,void 0)))}).join(e8(()=>{let J=[..._],Z=BG(J,this.toggleCase);return Y4(b(0),(b(1)<<b(Z.length))-b(1)).shrink(G,Q.flagsContext).map((K)=>{let H=_1(J);return RH(H,K.value,Z,this.toggleCase),new g(x0(H,""),this.buildContextFor(new g(_,Q.rawStringContext),K))})}))}};function ln(X){let Y=eH(X);if(Y!==X)return Y;return SH(X)}function on(X,Y){return new cn(X,Y&&Y.toggleCase||ln,Y&&Y.untoggleAll)}function rn(X){return PA.from(X)}function nn(X){if(!(X instanceof PA))throw Error("Unexpected type");return[...X]}function vP(X={}){return w0(EP(X),X).map(rn,nn)}function sn(X){return wA.from(X)}function an(X){if(!(X instanceof wA))throw Error("Unexpected type");return[...X]}function xP(X={}){return w0(SG(X),X).map(sn,an)}function W8(X,Y,Q,_,G){let J=_.name,{min:Z=Y,max:K=Q,...H}=X;if(Z>K)throw Error(`Invalid range passed to ${J}: min must be lower than or equal to max`);if(Z<Y)throw Error(`Invalid min value passed to ${J}: min must be greater than or equal to ${Y}`);if(K>Q)throw Error(`Invalid max value passed to ${J}: max must be lower than or equal to ${Q}`);return w0(G({min:Z,max:K}),H).map((W)=>_.from(W),(W)=>{if(!(W instanceof _))throw Error("Invalid type");return[...W]})}function kP(X={}){return W8(X,-32768,32767,Su,A0)}function bP(X={}){return W8(X,-2147483648,2147483647,vu,A0)}function gP(X={}){return W8(X,-128,127,ju,A0)}function yP(X={}){return W8(X,0,65535,bu,A0)}function hP(X={}){return W8(X,0,4294967295,gu,A0)}function mP(X={}){return W8(X,0,255,xu,A0)}function dP(X={}){return W8(X,0,255,ku,A0)}function tn(X){return X!==void 0}function eE(X){if(X.hasToBeCloned)return new g(X.value_,{generatorContext:X.context},()=>X.value);return new g(X.value_,{generatorContext:X.context})}function XA(X){if(X.hasToBeCloned)return new g(X.value_,{shrinkerContext:X.context},()=>X.value);return new g(X.value_,{shrinkerContext:X.context})}var en=class extends k0{constructor(X,Y){super();this.generatorArbitrary=X,this.shrinkerArbitrary=Y}generate(X,Y){return eE(this.generatorArbitrary.generate(X,Y))}canShrinkWithoutContext(X){return this.shrinkerArbitrary.canShrinkWithoutContext(X)}shrink(X,Y){if(!tn(Y))return this.shrinkerArbitrary.shrink(X,void 0).map(XA);if("generatorContext"in Y)return this.generatorArbitrary.shrink(X,Y.generatorContext).map(eE);return this.shrinkerArbitrary.shrink(X,Y.shrinkerContext).map(XA)}};function iH(X,Y,Q){let _=A0({min:X,max:Y});if(Y===Q)return _;return new en(_,A0({min:X,max:Q}))}var{min:Xs,max:nH}=Math,YA=EA.isArray,Ys=Object.entries;function Qs(X){let Y=-1;for(let Q=0;Q!==X.length;++Q)Y=nH(Y,X[Q][0]);return Y}function _s(X,Y){let Q=EA(X);for(let _=0;_!==Y.length;++_){let G=Y[_];if(G[0]<X)Q[G[0]]=G[1]}return Q}function fP(X,Y={}){let{size:Q,minNumElements:_=0,maxLength:G=K5,maxNumElements:J=G,noTrailingHole:Z,depthIdentifier:K}=Y,H=hQ(Q,hQ(Q,_,J,Y.maxNumElements!==void 0),G,Y.maxLength!==void 0);if(_>G)throw Error("The minimal number of non-hole elements cannot be higher than the maximal length of the array");if(_>J)throw Error("The minimal number of non-hole elements cannot be higher than the maximal number of non-holes");let W=Xs(J,G),D=Y.maxNumElements!==void 0||Q!==void 0?Q:"=",U=H5($0(iH(0,nH(H-1,0),nH(G-1,0)),X),{size:D,minLength:_,maxLength:W,selector:(N)=>N[0],depthIdentifier:K}).map((N)=>{return _s(Qs(N)+1,N)},(N)=>{if(!YA(N))throw Error("Not supported entry type");if(Z&&N.length!==0&&!(N.length-1 in N))throw Error("No trailing hole");return q0(Ys(N),(B)=>[Number(B[0]),B[1]])});if(Z||G===_)return U;return $0(U,iH(_,H,G)).map((N)=>{let B=N[0],q=N[1];if(B.length>=q)return B;let O=_1(B);return O.length=q,O},(N)=>{if(!YA(N))throw Error("Not supported entry type");return[N,N.length]})}function Gs(X){return new Set(X)}function Js(X){if(typeof X!=="object"||X===null)throw Error("Incompatible instance received: should be a non-null object");if(!("constructor"in X)||X.constructor!==Set)throw Error("Incompatible instance received: should be of exact type Set");return Array.from(X)}function pP(X,Y={}){return H5(X,{minLength:Y.minLength,maxLength:Y.maxLength,size:Y.size,depthIdentifier:Y.depthIdentifier,comparator:"SameValueZero"}).map(Gs,Js)}function $s(X,Y,Q,_,G,J){return DW(X,Y,{maxKeys:Q,noNullPrototype:!J,size:_,depthIdentifier:G})}function Zs(X){return G1(gP(X),mP(X),dP(X),kP(X),yP(X),bP(X),hP(X),vP(X),xP(X))}function uP(X){let{values:Y,depthSize:Q}=X,_=HW(),G=X.maxDepth,J=X.maxKeys,Z=X.size,K=G1(...Y,...X.withBigInt?[Y4()]:[],...X.withDate?[QP()]:[]);return IP((H)=>({anything:G1({maxDepth:G,depthSize:Q,depthIdentifier:_},K,H("array"),H("object"),...X.withMap?[H("map")]:[],...X.withSet?[H("set")]:[],...X.withObjectString?[H("anything").map((W)=>r0(W))]:[],...X.withTypedArray?[Zs({maxLength:J,size:Z})]:[],...X.withSparseArray?[fP(H("anything"),{maxNumElements:J,size:Z,depthIdentifier:_})]:[]),keys:X.withObjectString?G1({arbitrary:X.key,weight:10},{arbitrary:H("anything").map((W)=>r0(W)),weight:1}):X.key,array:w0(H("anything"),{maxLength:J,size:Z,depthIdentifier:_}),set:pP(H("anything"),{maxLength:J,size:Z,depthIdentifier:_}),map:G1(rH(H("keys"),H("anything"),{maxKeys:J,size:Z,depthIdentifier:_}),rH(H("anything"),H("anything"),{maxKeys:J,size:Z,depthIdentifier:_})),object:$s(H("keys"),H("anything"),J,Z,_,X.withNullPrototype)})).anything}function Ks(X){switch(typeof X){case"boolean":return new AA(X);case"number":return new $8(X);case"string":return new d1(X);default:return X}}function Hs(X){if(typeof X!=="object"||X===null||!("constructor"in X))return X;return X.constructor===AA||X.constructor===$8||X.constructor===d1?X.valueOf():X}function Ws(X){return X.map(Ks,Hs)}function Us(X,Y){return[fQ(),wP(),SG(),Y(X),G1(Y(X),v0(null),v0(void 0))]}function Ds(X){return X.map((Y)=>Ws(Y))}function Ns(X,Y){return Y?Ds(X).concat(X):X}function cP(X={}){let Y={size:X.size,unit:"stringUnit"in X?X.stringUnit:X.withUnicodeString?"binary":void 0};return{key:X.key!==void 0?X.key:s0(Y),values:Ns(X.values!==void 0?X.values:Us(Y,s0),X.withBoxedValues===!0),depthSize:X.depthSize,maxDepth:X.maxDepth,maxKeys:X.maxKeys,size:X.size,withSet:X.withSet===!0,withMap:X.withMap===!0,withObjectString:X.withObjectString===!0,withNullPrototype:X.withNullPrototype===!0,withBigInt:X.withBigInt===!0,withDate:X.withDate===!0,withTypedArray:X.withTypedArray===!0,withSparseArray:X.withSparseArray===!0}}function Bs(X){return DW(X.key,uP(X),{maxKeys:X.maxKeys,noNullPrototype:!X.withNullPrototype,size:X.size})}function Vs(X){return Bs(cP(X))}function qs(X,Y){let{depthSize:Q,maxDepth:_}=Y;return{key:X,values:[fQ(),SG({noDefaultInfinity:!0,noNaN:!0}),X,v0(null)],depthSize:Q,maxDepth:_}}function lP(X){return uP(cP(X))}function oP(X={}){let Y=X.noUnicodeString===void 0||X.noUnicodeString===!0;return lP(qs("stringUnit"in X?s0({unit:X.stringUnit}):Y?s0():s0({unit:"binary"}),X))}var{stringify:zs,parse:Os}=JSON;function Ls(X){if(typeof X!=="string")throw new y("Cannot unmap the passed value");return Os(X)}function Ts(X={}){return oP(X).map(zs,Ls)}var Rs=Object.defineProperties;function FH(X,Y){return`Stream(${Y!==void 0?`${x0(Y,",")}…`:`${X} emitted`})`}var Fs=class extends k0{constructor(X,Y){super();this.arb=X,this.history=Y}generate(X,Y){let Q=Y!==void 0&&X.nextInt(1,Y)===1?Y:void 0,_=()=>{let G=this.history?[]:null,J=0,K=new Z0(function*(H,W){while(!0){let D=H.generate(W,Q).value;if(J++,G!==null)S(G,D);yield D}}(this.arb,X.clone()));return Rs(K,{toString:{value:()=>FH(J,G!==null?G.map(r0):void 0)},[tX]:{value:()=>FH(J,G!==null?G.map(r0):void 0)},[K8]:{value:async()=>FH(J,G!==null?await Promise.all(G.map(JW)):void 0)},[J1]:{value:_,enumerable:!0}})};return new g(_(),void 0)}canShrinkWithoutContext(X){return!1}shrink(X,Y){return Z0.nil()}};function Es(X,Y){return new Fs(X,Y!==void 0&&typeof Y==="object"&&"noHistory"in Y?!Y.noHistory:!0)}function As(X){return x0(X,"")}function QA(X){if(typeof X!=="string")throw Error("Cannot unmap the passed value");return[...X]}function Ps(X){switch(X.length%4){case 0:return X;case 3:return`${X}=`;case 2:return`${X}==`;default:return m0(X,1)}}function ws(X){if(typeof X!=="string"||X.length%4!==0)throw Error("Invalid string received");let Y=X.indexOf("=");if(Y===-1)return X;if(X.length-Y>2)throw Error("Cannot unmap the passed value");return m0(X,0,Y)}var EH=String.fromCharCode;function Cs(X){if(X<26)return EH(X+65);if(X<52)return EH(X+97-26);if(X<62)return EH(X+48-52);return X===62?"+":"/"}function Ms(X){if(typeof X!=="string"||X.length!==1)throw new y("Invalid entry");let Y=P9(X,0);if(Y>=65&&Y<=90)return Y-65;if(Y>=97&&Y<=122)return Y-97+26;if(Y>=48&&Y<=57)return Y-48+52;return Y===43?62:Y===47?63:-1}function Is(){return A0({min:0,max:63}).map(Cs,Ms)}function js(X={}){let{minLength:Y=0,maxLength:Q=K5,size:_}=X,G=Y+3-(Y+3)%4,J=Q-Q%4,Z=X.maxLength===void 0&&_===void 0?"=":_;if(G>J)throw new y("Minimal length should be inferior or equal to maximal length");if(G%4!==0)throw new y("Minimal length of base64 strings must be a multiple of 4");if(J%4!==0)throw new y("Maximal length of base64 strings must be a multiple of 4");let K=Is();return w0(K,{minLength:G,maxLength:J,size:Z,experimentalCustomSlices:Zr(K,QA)}).map(As,QA).map(Ps,ws)}var _A=Object.is;function Ss(X,Y){let Q=new Z8,_=0;for(let G of X)if(_A(G,-0))++_;else nX(Q,G,(NX(Q,G)||0)+1);for(let G=0;G!==Y.length;++G){if(!(G in Y))return!1;let J=Y[G];if(_A(J,-0)){if(_===0)return!1;--_}else{let Z=NX(Q,J)||0;if(Z===0)return!1;nX(Q,J,Z-1)}}return!0}var{floor:vs,log:GA}=Math,xs=Array.isArray,rP=class extends k0{constructor(X,Y,Q,_){super();if(this.originalArray=X,this.isOrdered=Y,this.minLength=Q,this.maxLength=_,Q<0||Q>X.length)throw Error("fc.*{s|S}ubarrayOf expects the minimal length to be between 0 and the size of the original array");if(_<0||_>X.length)throw Error("fc.*{s|S}ubarrayOf expects the maximal length to be between 0 and the size of the original array");if(Q>_)throw Error("fc.*{s|S}ubarrayOf expects the minimal length to be inferior or equal to the maximal length");this.lengthArb=new C9(Q,_),this.biasedLengthArb=Q!==_?new C9(Q,Q+vs(GA(_-Q)/GA(2))):this.lengthArb}generate(X,Y){let Q=(Y!==void 0&&X.nextInt(1,Y)===1?this.biasedLengthArb:this.lengthArb).generate(X,void 0),_=Q.value,G=q0(this.originalArray,(Z,K)=>K),J=[];for(let Z=0;Z!==_;++Z){let K=X.nextInt(0,G.length-1);S(J,G[K]),IA(G,K,1)}if(this.isOrdered)jA(J,(Z,K)=>Z-K);return new g(q0(J,(Z)=>this.originalArray[Z]),Q.context)}canShrinkWithoutContext(X){if(!xs(X))return!1;if(!this.lengthArb.canShrinkWithoutContext(X.length))return!1;return Ss(this.originalArray,X)}shrink(X,Y){if(X.length===0)return Z0.nil();return this.lengthArb.shrink(X.length,Y).map((Q)=>{return new g(_1(X,X.length-Q.value),Q.context)}).join(X.length>this.minLength?e8(()=>this.shrink(_1(X,1),void 0).filter((Q)=>this.minLength<=Q.value.length+1).map((Q)=>new g([X[0],...Q.value],void 0))):Z0.nil())}};function ks(X,Y={}){let{minLength:Q=0,maxLength:_=X.length}=Y;return new rP(X,!0,Q,_)}function bs(X,Y={}){let{minLength:Q=0,maxLength:_=X.length}=Y;return new rP(X,!1,Q,_)}var gs={10:"A",11:"B",12:"C",13:"D",14:"E",15:"F",16:"G",17:"H",18:"J",19:"K",20:"M",21:"N",22:"P",23:"Q",24:"R",25:"S",26:"T",27:"V",28:"W",29:"X",30:"Y",31:"Z"},ys={"0":0,"1":1,"2":2,"3":3,"4":4,"5":5,"6":6,"7":7,"8":8,"9":9,A:10,B:11,C:12,D:13,E:14,F:15,G:16,H:17,J:18,K:19,M:20,N:21,P:22,Q:23,R:24,S:25,T:26,V:27,W:28,X:29,Y:30,Z:31};function hs(X){return X<10?d1(X):gs[X]}function JA(X,Y){let Q="";while(X.length+Q.length<Y)Q+="0";return Q+X}function $A(X){let Y="";for(let Q=X;Q!==0;){let _=Q>>5;Y=hs(Q-(_<<5))+Y,Q=_}return Y}function ms(X,Y){let Q=~~(X/1073741824),_=X&1073741823;return JA($A(Q),Y-6)+JA($A(_),6)}function iP(X){return function(Q){return ms(Q,X)}}function AH(X){if(typeof X!=="string")throw new y("Unsupported type");let Y=0,Q=1;for(let _=X.length-1;_>=0;--_){let G=X[_],J=ys[G];if(J===void 0)throw new y("Unsupported type");Y+=J*Q,Q*=32}return Y}var ds=iP(10),ZA=iP(8);function fs(X){return ds(X[0])+ZA(X[1])+ZA(X[2])}function ps(X){if(typeof X!=="string"||X.length!==26)throw Error("Unsupported type");return[AH(X.slice(0,10)),AH(X.slice(10,18)),AH(X.slice(18))]}function us(){return $0(A0({min:0,max:281474976710655}),A0({min:0,max:1099511627775}),A0({min:0,max:1099511627775})).map(fs,ps)}function nP(X){return Ec(gQ(X,16),8,"0")}function cs(X){if(typeof X!=="string")throw Error("Unsupported type");if(X.length!==8)throw Error("Unsupported value: invalid length");let Y=parseInt(X,16);if(X!==nP(Y))throw Error("Unsupported value: invalid content");return Y}function PH(X,Y){return A0({min:X,max:Y}).map(nP,cs)}function ls(X){return`${X[0]}-${m0(X[1],4)}-${m0(X[1],0,4)}-${m0(X[2],0,4)}-${m0(X[2],4)}${X[3]}`}var os=/^([0-9a-f]{8})-([0-9a-f]{4})-([0-9a-f]{4})-([0-9a-f]{4})-([0-9a-f]{12})$/;function rs(X){if(typeof X!=="string")throw Error("Unsupported type");let Y=os.exec(X);if(Y===null)throw Error("Unsupported type");return[Y[1],Y[3]+Y[2],Y[4]+m0(Y[5],0,4),m0(Y[5],4)]}var KA="0123456789abcdef";function is(X){let Y={},Q={};for(let J=0;J!==X.length;++J){let Z=KA[J],K=KA[X[J]];Y[Z]=K,Q[K]=Z}function _(J){return Y[J[0]]+m0(J,1)}function G(J){if(typeof J!=="string")throw new y("Cannot produce non-string values");let Z=Q[J[0]];if(Z===void 0)throw new y("Cannot produce strings not starting by the version in hexa code");return Z+m0(J,1)}return{versionsApplierMapper:_,versionsApplierUnmapper:G}}function ns(X){let Y={};for(let Q of X){if(Y[Q])throw new y(`Version ${Q} has been requested at least twice for uuid`);if(Y[Q]=!0,Q<1||Q>15)throw new y(`Version must be a value in [1-15] for uuid, but received ${Q}`);if(~~Q!==Q)throw new y(`Version must be an integer value for uuid, but received ${Q}`)}if(X.length===0)throw new y("Must provide at least one version for uuid")}function ss(X={}){let Y=PH(0,4294967295),Q=X.version!==void 0?typeof X.version==="number"?[X.version]:X.version:[1,2,3,4,5,6,7,8];ns(Q);let{versionsApplierMapper:_,versionsApplierUnmapper:G}=is(Q);return $0(Y,PH(0,268435456*Q.length-1).map(_,G),PH(2147483648,3221225471),Y).map(ls,rs)}function as(X){return s0({unit:VW("-._~!$&'()*+,;=:"),size:X})}function ts([X,Y,Q]){return(X===null?"":`${X}@`)+Y+(Q===null?"":`:${Q}`)}function es(X){if(typeof X!=="string")throw Error("Unsupported");let Y=X.indexOf("@"),Q=Y!==-1?X.substring(0,Y):null,_=/:(\d+)$/.exec(X),G=_!==null?Number(_[1]):null;return[Q,_!==null?X.substring(Y+1,X.length-_[1].length-1):X.substring(Y+1),G]}function Xa(X){return`[${X}]`}function Ya(X){if(typeof X!=="string"||X[0]!=="["||X[X.length-1]!=="]")throw Error("Unsupported");return X.substring(1,X.length-1)}function sP(X){let Y=X||{},Q=Y.size,_=[qW({size:Q}),...Y.withIPv4===!0?[TW()]:[],...Y.withIPv6===!0?[MP().map(Xa,Ya)]:[],...Y.withIPv4Extended===!0?[CP()]:[]];return $0(Y.withUserInfo===!0?H8(as(Q)):v0(null),G1(..._),Y.withPort===!0?H8(t8(65535)):v0(null)).map(ts,es)}function aP(X){return s0({unit:VW("-._~!$&'()*+,;=:@/?"),size:X})}function tP(X={}){return aP(X.size)}function eP(X={}){return s0({unit:VW("-._~!$&'()*+,;=:@"),size:X.size})}function Qa(X){let Y="";for(let Q=0;Q!==X.length;++Q)Y+="/"+X[Q];return Y}function _a(X){if(typeof X!=="string")throw Error("Incompatible value received: type");if(X.length!==0&&X[0]!=="/")throw Error("Incompatible value received: start");return IA(f1(X,"/"),1)}function Ga(X){switch(X){case"xsmall":return["xsmall","xsmall"];case"small":return["small","xsmall"];case"medium":return["small","small"];case"large":return["medium","small"];case"xlarge":return["medium","medium"]}}function wH(X,Y){return w0(eP({size:X}),{size:Y}).map(Qa,_a)}function Ja(X){let[Y,Q]=Ga(X);if(Y===Q)return wH(Y,Q);return G1(wH(Y,Q),wH(Q,Y))}function Xw(X){return Ja(UW((X||{}).size))}function Yw(X={}){return aP(X.size)}function $a(X){let[Y,Q,_]=X;return`${Y}://${Q}${_}${X[3]===null?"":`?${X[3]}`}${X[4]===null?"":`#${X[4]}`}`}var Za=/^([[A-Za-z][A-Za-z0-9+.-]*):\/\/([^/?#]*)([^?#]*)(\?[A-Za-z0-9\-._~!$&'()*+,;=:@/?%]*)?(#[A-Za-z0-9\-._~!$&'()*+,;=:@/?%]*)?$/;function Ka(X){if(typeof X!=="string")throw Error("Incompatible value received: type");let Y=Za.exec(X);if(Y===null)throw Error("Incompatible value received");let Q=Y[1],_=Y[2],G=Y[3],J=Y[4],Z=Y[5];return[Q,_,G,J!==void 0?J.substring(1):null,Z!==void 0?Z.substring(1):null]}function Ha(X){let Y=X||{},Q=UW(Y.size),_=Y.authoritySettings!==void 0&&Y.authoritySettings.size!==void 0?dQ(Y.authoritySettings.size,Q):Q,G={...Y.authoritySettings,size:_};return $0(A6(...Y.validSchemes||["http","https"]),sP(G),Xw({size:Q}),Y.withQueryParameters===!0?H8(Yw({size:Q})):v0(null),Y.withFragments===!0?H8(tP({size:Q})):v0(null)).map($a,Ka)}var Wa=class X{constructor(Y,Q){this.commands=Y,this.metadataForReplay=Q,this[J1]=function(){return new X(this.commands.map((_)=>_.clone()),this.metadataForReplay)}}[Symbol.iterator](){return this.commands[Symbol.iterator]()}toString(){let Y=this.commands.filter((_)=>_.hasRan).map((_)=>_.toString()).join(","),Q=this.metadataForReplay();return Q.length!==0?`${Y} /*${Q}*/`:Y}},Ua=class X{constructor(Y){if(this.cmd=Y,this.hasRan=!1,_W(Y)){let Q=Y[tX];this[tX]=function(){return Q.call(Y)}}if(GW(Y)){let Q=Y[K8];this[K8]=function(){return Q.call(Y)}}}check(Y){return this.cmd.check(Y)}run(Y,Q){return this.hasRan=!0,this.cmd.run(Y,Q)}clone(){if(Z5(this.cmd))return new X(this.cmd[J1]());return new X(this.cmd)}toString(){return this.cmd.toString()}},HA=class{static parse(X){let[Y,Q]=X.split(":"),_=this.parseCounts(Y),G=this.parseChanges(Q);return this.parseOccurences(_,G)}static stringify(X){let Y=this.countOccurences(X);return`${this.stringifyCounts(Y)}:${this.stringifyChanges(Y)}`}static intToB64(X){if(X<26)return String.fromCharCode(X+65);if(X<52)return String.fromCharCode(X+97-26);if(X<62)return String.fromCharCode(X+48-52);return String.fromCharCode(X===62?43:47)}static b64ToInt(X){if(X>="a")return X.charCodeAt(0)-97+26;if(X>="A")return X.charCodeAt(0)-65;if(X>="0")return X.charCodeAt(0)-48+52;return X==="+"?62:63}static countOccurences(X){return X.reduce((Y,Q)=>{if(Y.length===0||Y[Y.length-1].count===64||Y[Y.length-1].value!==Q)Y.push({value:Q,count:1});else Y[Y.length-1].count+=1;return Y},[])}static parseOccurences(X,Y){let Q=[];for(let _=0;_!==X.length;++_){let G=X[_],J=Y[_];for(let Z=0;Z!==G;++Z)Q.push(J)}return Q}static stringifyChanges(X){let Y="";for(let Q=0;Q<X.length;Q+=6){let _=X.slice(Q,Q+6).reduceRight((G,J)=>(G<<1)+(J.value?1:0),0);Y+=this.intToB64(_)}return Y}static parseChanges(X){let Y=X.split("").map((_)=>this.b64ToInt(_)),Q=[];for(let _=0;_!==Y.length;++_){let G=Y[_];for(let J=0;J!==6;++J,G>>=1)Q.push(G%2===1)}return Q}static stringifyCounts(X){return X.map(({count:Y})=>this.intToB64(Y-1)).join("")}static parseCounts(X){return X.split("").map((Y)=>this.b64ToInt(Y)+1)}},Da=class extends k0{constructor(X,Y,Q,_,G){super();this.sourceReplayPath=_,this.disableReplayLog=G,this.oneCommandArb=G1(...X).map((J)=>new Ua(J)),this.lengthArb=iH(0,Y,Q),this.replayPath=[],this.replayPathPosition=0}metadataForReplay(){return this.disableReplayLog?"":`replayPath=${JSON.stringify(HA.stringify(this.replayPath))}`}buildValueFor(X,Y){let Q=X.map((G)=>G.value_),_={shrunkOnce:Y,items:X};return new g(new Wa(Q,()=>this.metadataForReplay()),_)}generate(X){let Y=this.lengthArb.generate(X,void 0).value,Q=Array(Y);for(let _=0;_!==Y;++_)Q[_]=this.oneCommandArb.generate(X,void 0);return this.replayPathPosition=0,this.buildValueFor(Q,!1)}canShrinkWithoutContext(X){return!1}filterOnExecution(X){let Y=[];for(let Q of X)if(Q.value_.hasRan)this.replayPath.push(!0),Y.push(Q);else this.replayPath.push(!1);return Y}filterOnReplay(X){return X.filter((Y,Q)=>{let _=this.replayPath[this.replayPathPosition+Q];if(_===void 0)throw Error("Too short replayPath");if(!_&&Y.value_.hasRan)throw Error("Mismatch between replayPath and real execution");return _})}filterForShrinkImpl(X){if(this.replayPathPosition===0)this.replayPath=this.sourceReplayPath!==null?HA.parse(this.sourceReplayPath):[];let Y=this.replayPathPosition<this.replayPath.length?this.filterOnReplay(X):this.filterOnExecution(X);return this.replayPathPosition+=X.length,Y}shrink(X,Y){if(Y===void 0)return Z0.nil();let Q=Y,_=Q.shrunkOnce,G=Q.items,J=this.filterForShrinkImpl(G);if(J.length===0)return Z0.nil();let Z=_?Z0.nil():new Z0([[]][Symbol.iterator]()),K=[];for(let H=0;H!==J.length;++H)K.push(e8(()=>{let W=J.slice(0,H);return this.lengthArb.shrink(J.length-1-H,void 0).map((D)=>W.concat(J.slice(J.length-(D.value+1))))}));for(let H=0;H!==J.length;++H)K.push(e8(()=>this.oneCommandArb.shrink(J[H].value_,J[H].context).map((W)=>J.slice(0,H).concat([W],J.slice(H+1)))));return Z.join(...K).map((H)=>{return this.buildValueFor(H.map((W)=>new g(W.value_.clone(),W.context)),!0)})}};function Na(X,Y={}){let{size:Q,maxCommands:_=K5,disableReplayLog:G=!1,replayPath:J=null}=Y;return new Da(X,hQ(Q,0,_,Y.maxCommands!==void 0),_,J,G)}var Ba=class{constructor(X,Y){this.s=X,this.cmd=Y}async check(X){let Y=null,Q=!1;if((await this.s.scheduleSequence([{label:`check@${this.cmd.toString()}`,builder:async()=>{try{Q=await Promise.resolve(this.cmd.check(X))}catch(_){throw Y=_,_}}}]).task).faulty)throw Y;return Q}async run(X,Y){let Q=null;if((await this.s.scheduleSequence([{label:`run@${this.cmd.toString()}`,builder:async()=>{try{await this.cmd.run(X,Y)}catch(_){throw Q=_,_}}}]).task).faulty)throw Q}},Va=function*(X,Y){for(let Q of Y)yield new Ba(X,Q)},Qw=(X,Y,Q,_,G)=>{return X.then((J)=>{let{model:Z,real:K}=J,H=Q;for(let W of Y)H=G(H,()=>{return _(W,Z,K)});return H})},qa=(X,Y)=>{return Qw({then:(J)=>{J(X())}},Y,void 0,(J,Z,K)=>{if(J.check(Z))J.run(Z,K)},(J,Z)=>Z())},za=(X)=>{return typeof X.then==="function"},_w=async(X,Y,Q=Promise.resolve())=>{return await Qw({then:(Z)=>{let K=X();if(za(K))return K.then(Z);else return Z(K)}},Y,Q,async(Z,K,H)=>{if(await Z.check(K))await Z.run(K,H)},(Z,K)=>Z.then(K))};function Oa(X,Y){qa(X,Y)}async function La(X,Y){await _w(X,Y)}async function Ta(X,Y,Q){let _=Va(X,Q),G=_w(Y,_,X.schedule(Promise.resolve(),"startModel"));await X.waitFor(G),await X.waitAll()}var VG=(X)=>X(),Gw=class X{constructor(Y,Q){this.act=Y,this.taskSelector=Q,this.lastTaskId=0,this.sourceTaskSelector=Q.clone(),this.scheduledTasks=[],this.triggeredTasks=[],this.scheduledWatchers=[],this[J1]=function(){return new X(this.act,this.sourceTaskSelector)}}static buildLog(Y){return`[task\${${Y.taskId}}] ${Y.label.length!==0?`${Y.schedulingType}::${Y.label}`:Y.schedulingType} ${Y.status}${Y.outputValue!==void 0?` with value ${Ti(Y.outputValue)}`:""}`}log(Y,Q,_,G,J,Z){this.triggeredTasks.push({status:J,schedulingType:Y,taskId:Q,label:_,metadata:G,outputValue:Z!==void 0?r0(Z):void 0})}scheduleInternal(Y,Q,_,G,J,Z){let K=++this.lastTaskId,H=void 0,W=new Promise((D,U)=>{H=()=>{let N=Promise.resolve(Z!==void 0?_.then(()=>Z()):_);return N.then((B)=>{this.log(Y,K,Q,G,"resolved",B),D(B)},(B)=>{this.log(Y,K,Q,G,"rejected",B),U(B)}),N}});if(this.scheduledTasks.push({original:_,trigger:H,schedulingType:Y,taskId:K,label:Q,metadata:G,customAct:J}),this.scheduledWatchers.length!==0)this.scheduledWatchers[0]();return W}schedule(Y,Q,_,G){return this.scheduleInternal("promise",Q||"",Y,_,G||VG)}scheduleFunction(Y,Q){return(..._)=>this.scheduleInternal("function",`${Y.name}(${_.map(r0).join(",")})`,Y(..._),void 0,Q||VG)}scheduleSequence(Y,Q){let _={done:!1,faulty:!1},G={then:(D)=>D()},J=()=>{},Z=new Promise((D)=>{J=()=>D({done:_.done,faulty:_.faulty})}),K=()=>{_.faulty=!0,J()},H=()=>{_.done=!0,J()},W=(D,U)=>{if(D>=Y.length){U.then(H,K);return}U.then(()=>{let N=Y[D],[B,q,O]=typeof N==="function"?[N,N.name,void 0]:[N.builder,N.label,N.metadata],R=this.scheduleInternal("sequence",q,G,O,Q||VG,()=>B());W(D+1,R)},K)};return W(0,G),Object.assign(_,{task:Z})}count(){return this.scheduledTasks.length}internalWaitOne(){if(this.scheduledTasks.length===0)throw Error("No task scheduled");let Y=this.taskSelector.nextTaskIndex(this.scheduledTasks),[Q]=this.scheduledTasks.splice(Y,1);return Q.customAct(()=>{return Q.trigger().catch((_)=>{})})}waitOne(Y){let Q=Y||VG;return this.act(()=>Q(()=>this.internalWaitOne()))}async waitAll(Y){while(this.scheduledTasks.length>0)await this.waitOne(Y)}async internalWaitFor(Y,Q){let _=!1,G=Q.customAct,J=Q.onWaitStart,Z=Q.onWaitIdle,K=Q.launchAwaiterOnInit,H=void 0,W=void 0,D=0,U=null,N=null,B=async()=>{D=50;for(D=50;!_&&D>0;--D)await Promise.resolve();if(!_&&this.scheduledTasks.length>0){if(J!==void 0)J();return N=this.waitOne(G),N.then(()=>{return N=null,B()},(F)=>{throw N=null,_=!0,W(F),F})}if(!_&&Z!==void 0)Z();U=null},q=()=>{if(U!==null){D=51;return}U=B().catch(()=>{})},O=()=>{let F=this.scheduledWatchers.indexOf(q);if(F!==-1)this.scheduledWatchers.splice(F,1);if(F===0&&this.scheduledWatchers.length!==0)this.scheduledWatchers[0]()},R=new Promise((F,P)=>{H=(C)=>{O(),F(C)},W=(C)=>{O(),P(C)}});if(Y.then((F)=>{if(_=!0,N===null)H(F);else N.then(()=>H(F),(P)=>W(P))},(F)=>{if(_=!0,N===null)W(F);else N.then(()=>W(F),()=>W(F))}),(this.scheduledTasks.length>0||K)&&this.scheduledWatchers.length===0)q();return this.scheduledWatchers.push(q),R}waitNext(Y,Q){let _=void 0,G=Y,J=G<=0?Promise.resolve():new Promise((Z)=>{_=()=>{if(--G<=0)Z()}});return this.internalWaitFor(J,{customAct:Q,onWaitStart:_,onWaitIdle:void 0,launchAwaiterOnInit:!1})}waitIdle(Y){let Q=void 0,_=new Promise((G)=>Q=G);return this.internalWaitFor(_,{customAct:Y,onWaitStart:void 0,onWaitIdle:Q,launchAwaiterOnInit:!0})}waitFor(Y,Q){return this.internalWaitFor(Y,{customAct:Q,onWaitStart:void 0,onWaitIdle:void 0,launchAwaiterOnInit:!1})}report(){return[...this.triggeredTasks,...this.scheduledTasks.map((Y)=>({status:"pending",schedulingType:Y.schedulingType,taskId:Y.taskId,label:Y.label,metadata:Y.metadata}))]}toString(){return"schedulerFor()`\n"+this.report().map(X.buildLog).map((Y)=>`-> ${Y}`).join(`
`)+"`"}};function Jw(X){let Y=0;return{clone:()=>Jw(X),nextTaskIndex:(Q)=>{if(X.length<=Y)throw Error("Invalid schedulerFor defined: too many tasks have been scheduled");let _=Q.findIndex((G)=>G.taskId===X[Y]);if(_===-1)throw Error("Invalid schedulerFor defined: unable to find next task");return++Y,_}}}function WA(X,Y){return new Gw(X,Jw(Y))}function $w(X){let Y=X.clone();return{clone:()=>$w(Y),nextTaskIndex:(Q)=>{return X.nextInt(0,Q.length-1)}}}var Ra=class extends k0{constructor(X){super();this.act=X}generate(X,Y){return new g(new Gw(this.act,$w(X.clone())),void 0)}canShrinkWithoutContext(X){return!1}shrink(X,Y){return Z0.nil()}};function Fa(X){let{act:Y=(Q)=>Q()}=X||{};return new Ra(Y)}function Ea(X,Y){let{act:Q=(_)=>_()}=Array.isArray(X)?Y||{}:X||{};if(Array.isArray(X))return WA(Q,X);return function(_,...G){return WA(Q,G)}}function Aa(X={}){return W8(X,b("-9223372036854775808"),b("9223372036854775807"),Mu,Y4)}function Pa(X={}){return W8(X,b(0),b("18446744073709551615"),Iu,Y4)}function wa(X,Y){return Y}var{floor:CH,min:Ca}=Math;function MX(X,Y){switch(X.type){case"Char":return{astNode:X,minLength:1};case"Repetition":switch(X.quantifier.kind){case"*":{let Q=MX(X.expression,Y);return{astNode:{type:"Repetition",quantifier:{...X.quantifier,kind:"Range",from:0,to:Y},expression:Q.astNode},minLength:0}}case"+":{let Q=MX(X.expression,Y),_=Q.minLength>1?Q.minLength:1;return{astNode:{type:"Repetition",quantifier:{...X.quantifier,kind:"Range",from:1,to:CH(Y/_)},expression:Q.astNode},minLength:Q.minLength}}case"?":{let Q=MX(X.expression,Y);if(Y<Q.minLength)return{astNode:{type:"Repetition",quantifier:{...X.quantifier,kind:"Range",from:0,to:0},expression:Q.astNode},minLength:0};return{astNode:{...X,expression:Q.astNode},minLength:0}}case"Range":{let Q=X.quantifier.from>1?CH(Y/X.quantifier.from):Y,_=MX(X.expression,Q),G=_.minLength>1?_.minLength:1;if(X.quantifier.to===void 0||X.quantifier.to*G>Y)return{astNode:{type:"Repetition",quantifier:{...X.quantifier,kind:"Range",to:CH(Y/G)},expression:_.astNode},minLength:X.quantifier.from*_.minLength};return{astNode:{...X,expression:_.astNode},minLength:X.quantifier.from*_.minLength}}default:return wa(X.quantifier,{astNode:X,minLength:0})}case"Quantifier":return{astNode:X,minLength:0};case"Alternative":{let Q=0,_=[];for(let J=0;J!==X.expressions.length;++J){let Z=Y-Q,K=MX(X.expressions[J],Z);Q+=K.minLength,S(_,{value:K,allowance:Z})}let G=[];for(let J=0;J!==_.length;++J){let Z=_[J].value,K=_[J].allowance,H=Y-Q+Z.minLength;S(G,(H!==K?MX(Z.astNode,H):Z).astNode)}return{astNode:{...X,expressions:G},minLength:Q}}case"CharacterClass":return{astNode:X,minLength:1};case"ClassRange":return{astNode:X,minLength:1};case"Group":{let Q=MX(X.expression,Y);return{astNode:{...X,expression:Q.astNode},minLength:Q.minLength}}case"Disjunction":{if(X.left===null){if(X.right===null)return{astNode:X,minLength:0};let G=MX(X.right,Y),J=G.minLength>Y?null:G.astNode;return{astNode:{...X,left:null,right:J},minLength:0}}if(X.right===null){let G=MX(X.left,Y),J=G.minLength>Y?null:G.astNode;return{astNode:{...X,left:J,right:null},minLength:0}}let Q=MX(X.left,Y),_=MX(X.right,Y);if(Q.minLength>Y)return _;if(_.minLength>Y)return Q;return{astNode:{...X,left:Q.astNode,right:_.astNode},minLength:Ca(Q.minLength,_.minLength)}}case"Assertion":return{astNode:X,minLength:0};case"Backreference":return{astNode:X,minLength:0};case"UnicodeProperty":return{astNode:X,minLength:1}}}function Ma(X,Y){return MX(X,Y).astNode}function Ia(X){return Error(`Unsupported AST node! Received: ${r0(X)}`)}function FG(X,Y,Q){if(!Y&&!Q)return X;let _={hasStart:!1,hasEnd:!1},G=Zw(X,Y,Q,_),J=Y&&!_.hasStart,Z=Q&&!_.hasEnd;if(!J&&!Z)return G;let K=[];if(J)K.push({type:"Assertion",kind:"^"}),K.push({type:"Repetition",quantifier:{type:"Quantifier",kind:"*",greedy:!0},expression:{type:"Char",kind:"meta",symbol:".",value:".",codePoint:NaN}});if(K.push(G),Z)K.push({type:"Repetition",quantifier:{type:"Quantifier",kind:"*",greedy:!0},expression:{type:"Char",kind:"meta",symbol:".",value:".",codePoint:NaN}}),K.push({type:"Assertion",kind:"$"});return{type:"Group",capturing:!1,expression:{type:"Alternative",expressions:K}}}function Zw(X,Y,Q,_){switch(X.type){case"Char":return X;case"Repetition":return X;case"Quantifier":throw Error("Wrongly defined AST tree, Quantifier nodes not supposed to be scanned!");case"Alternative":return _.hasStart=!0,_.hasEnd=!0,{...X,expressions:X.expressions.map((G,J)=>FG(G,Y&&J===0,Q&&J===X.expressions.length-1))};case"CharacterClass":return X;case"ClassRange":return X;case"Group":return{...X,expression:Zw(X.expression,Y,Q,_)};case"Disjunction":return _.hasStart=!0,_.hasEnd=!0,{...X,left:X.left!==null?FG(X.left,Y,Q):null,right:X.right!==null?FG(X.right,Y,Q):null};case"Assertion":if(X.kind==="^"||X.kind==="Lookahead")return _.hasStart=!0,X;else if(X.kind==="$"||X.kind==="Lookbehind")return _.hasEnd=!0,X;else throw Error(`Assertions of kind ${X.kind} not implemented yet!`);case"Backreference":return X;case"UnicodeProperty":return X;default:throw Ia(X)}}function ja(X){return FG(X,!0,!0)}function UA(X,Y){return X[Y]>="\uD800"&&X[Y]<="\uDBFF"&&X[Y+1]>="\uDC00"&&X[Y+1]<="\uDFFF"?2:1}function n0(X){return X>="0"&&X<="9"||X>="a"&&X<="f"||X>="A"&&X<="F"}function sH(X){return X>="0"&&X<="9"}function Kw(X,Y){for(let Q=Y;Q!==X.length;++Q){let _=X[Q];if(_==="\\")Q+=1;else if(_==="]")return Q}throw Error("Missing closing ']'")}function Sa(X,Y){let Q=0;for(let _=Y;_!==X.length;++_){let G=X[_];if(G==="\\")_+=1;else if(G===")"){if(Q===0)return _;Q-=1}else if(G==="[")_=Kw(X,_);else if(G==="(")Q+=1}throw Error("Missing closing ')'")}function va(X,Y){let Q=!1;for(let _=Y;_!==X.length;++_){let G=X[_];if(sH(G));else if(Y===_)return-1;else if(G===","){if(Q)return-1;Q=!0}else if(G==="}")return _;else return-1}return-1}function xa(X,Y,Q,_){switch(X[Y]){case"[":if(_===1)return Y+1;return Kw(X,Y+1)+1;case"{":{if(_===1)return Y+1;let G=va(X,Y+1);if(G===-1)return Y+1;return G+1}case"(":if(_===1)return Y+1;return Sa(X,Y+1)+1;case"]":case"}":case")":return Y+1;case"\\":{let G=X[Y+1];switch(G){case"x":if(n0(X[Y+2])&&n0(X[Y+3]))return Y+4;throw Error(`Unexpected token '${X.substring(Y,Y+4)}' found`);case"u":if(X[Y+2]==="{"){if(!Q)return Y+2;if(X[Y+4]==="}"){if(n0(X[Y+3]))return Y+5;throw Error(`Unexpected token '${X.substring(Y,Y+5)}' found`)}if(X[Y+5]==="}"){if(n0(X[Y+3])&&n0(X[Y+4]))return Y+6;throw Error(`Unexpected token '${X.substring(Y,Y+6)}' found`)}if(X[Y+6]==="}"){if(n0(X[Y+3])&&n0(X[Y+4])&&n0(X[Y+5]))return Y+7;throw Error(`Unexpected token '${X.substring(Y,Y+7)}' found`)}if(X[Y+7]==="}"){if(n0(X[Y+3])&&n0(X[Y+4])&&n0(X[Y+5])&&n0(X[Y+6]))return Y+8;throw Error(`Unexpected token '${X.substring(Y,Y+8)}' found`)}if(X[Y+8]==="}"&&n0(X[Y+3])&&n0(X[Y+4])&&n0(X[Y+5])&&n0(X[Y+6])&&n0(X[Y+7]))return Y+9;throw Error(`Unexpected token '${X.substring(Y,Y+9)}' found`)}if(n0(X[Y+2])&&n0(X[Y+3])&&n0(X[Y+4])&&n0(X[Y+5]))return Y+6;throw Error(`Unexpected token '${X.substring(Y,Y+6)}' found`);case"p":case"P":{if(!Q)return Y+2;let J=Y+2;for(;J<X.length&&X[J]!=="}";J+=X[J]==="\\"?2:1);if(X[J]!=="}")throw Error("Invalid \\P definition");return J+1}case"k":{let J=Y+2;for(;J<X.length&&X[J]!==">";++J);if(X[J]!==">"){if(!Q)return Y+2;throw Error("Invalid \\k definition")}return J+1}default:if(sH(G)){let J=Q?X.length:Math.min(Y+4,X.length),Z=Y+2;for(;Z<J&&sH(X[Z]);++Z);return Z}return Y+(Q?UA(X,Y+1):1)+1}}default:return Y+(Q?UA(X,Y):1)}}function qG(X,Y,Q,_){let G=xa(X,Y,Q,_);return X.substring(Y,G)}var DA={gc:"General_Category",sc:"Script",scx:"Script_Extensions"},vG={ASCII:"ASCII",ASCII_Hex_Digit:"AHex",Alphabetic:"Alpha",Any:"Any",Assigned:"Assigned",Bidi_Control:"Bidi_C",Bidi_Mirrored:"Bidi_M",Case_Ignorable:"CI",Cased:"Cased",Changes_When_Casefolded:"CWCF",Changes_When_Casemapped:"CWCM",Changes_When_Lowercased:"CWL",Changes_When_NFKC_Casefolded:"CWKCF",Changes_When_Titlecased:"CWT",Changes_When_Uppercased:"CWU",Dash:"Dash",Default_Ignorable_Code_Point:"DI",Deprecated:"Dep",Diacritic:"Dia",Emoji:"Emoji",Emoji_Component:"Emoji_Component",Emoji_Modifier:"Emoji_Modifier",Emoji_Modifier_Base:"Emoji_Modifier_Base",Emoji_Presentation:"Emoji_Presentation",Extended_Pictographic:"Extended_Pictographic",Extender:"Ext",Grapheme_Base:"Gr_Base",Grapheme_Extend:"Gr_Ext",Hex_Digit:"Hex",IDS_Binary_Operator:"IDSB",IDS_Trinary_Operator:"IDST",ID_Continue:"IDC",ID_Start:"IDS",Ideographic:"Ideo",Join_Control:"Join_C",Logical_Order_Exception:"LOE",Lowercase:"Lower",Math:"Math",Noncharacter_Code_Point:"NChar",Pattern_Syntax:"Pat_Syn",Pattern_White_Space:"Pat_WS",Quotation_Mark:"QMark",Radical:"Radical",Regional_Indicator:"RI",Sentence_Terminal:"STerm",Soft_Dotted:"SD",Terminal_Punctuation:"Term",Unified_Ideograph:"UIdeo",Uppercase:"Upper",Variation_Selector:"VS",White_Space:"space",XID_Continue:"XIDC",XID_Start:"XIDS"},mQ=AW(vG),EW={Cased_Letter:"LC",Close_Punctuation:"Pe",Connector_Punctuation:"Pc",Control:["Cc","cntrl"],Currency_Symbol:"Sc",Dash_Punctuation:"Pd",Decimal_Number:["Nd","digit"],Enclosing_Mark:"Me",Final_Punctuation:"Pf",Format:"Cf",Initial_Punctuation:"Pi",Letter:"L",Letter_Number:"Nl",Line_Separator:"Zl",Lowercase_Letter:"Ll",Mark:["M","Combining_Mark"],Math_Symbol:"Sm",Modifier_Letter:"Lm",Modifier_Symbol:"Sk",Nonspacing_Mark:"Mn",Number:"N",Open_Punctuation:"Ps",Other:"C",Other_Letter:"Lo",Other_Number:"No",Other_Punctuation:"Po",Other_Symbol:"So",Paragraph_Separator:"Zp",Private_Use:"Co",Punctuation:["P","punct"],Separator:"Z",Space_Separator:"Zs",Spacing_Mark:"Mc",Surrogate:"Cs",Symbol:"S",Titlecase_Letter:"Lt",Unassigned:"Cn",Uppercase_Letter:"Lu"},aH=AW(EW),Hw={Adlam:"Adlm",Ahom:"Ahom",Anatolian_Hieroglyphs:"Hluw",Arabic:"Arab",Armenian:"Armn",Avestan:"Avst",Balinese:"Bali",Bamum:"Bamu",Bassa_Vah:"Bass",Batak:"Batk",Bengali:"Beng",Bhaiksuki:"Bhks",Bopomofo:"Bopo",Brahmi:"Brah",Braille:"Brai",Buginese:"Bugi",Buhid:"Buhd",Canadian_Aboriginal:"Cans",Carian:"Cari",Caucasian_Albanian:"Aghb",Chakma:"Cakm",Cham:"Cham",Cherokee:"Cher",Common:"Zyyy",Coptic:["Copt","Qaac"],Cuneiform:"Xsux",Cypriot:"Cprt",Cyrillic:"Cyrl",Deseret:"Dsrt",Devanagari:"Deva",Dogra:"Dogr",Duployan:"Dupl",Egyptian_Hieroglyphs:"Egyp",Elbasan:"Elba",Ethiopic:"Ethi",Georgian:"Geor",Glagolitic:"Glag",Gothic:"Goth",Grantha:"Gran",Greek:"Grek",Gujarati:"Gujr",Gunjala_Gondi:"Gong",Gurmukhi:"Guru",Han:"Hani",Hangul:"Hang",Hanifi_Rohingya:"Rohg",Hanunoo:"Hano",Hatran:"Hatr",Hebrew:"Hebr",Hiragana:"Hira",Imperial_Aramaic:"Armi",Inherited:["Zinh","Qaai"],Inscriptional_Pahlavi:"Phli",Inscriptional_Parthian:"Prti",Javanese:"Java",Kaithi:"Kthi",Kannada:"Knda",Katakana:"Kana",Kayah_Li:"Kali",Kharoshthi:"Khar",Khmer:"Khmr",Khojki:"Khoj",Khudawadi:"Sind",Lao:"Laoo",Latin:"Latn",Lepcha:"Lepc",Limbu:"Limb",Linear_A:"Lina",Linear_B:"Linb",Lisu:"Lisu",Lycian:"Lyci",Lydian:"Lydi",Mahajani:"Mahj",Makasar:"Maka",Malayalam:"Mlym",Mandaic:"Mand",Manichaean:"Mani",Marchen:"Marc",Medefaidrin:"Medf",Masaram_Gondi:"Gonm",Meetei_Mayek:"Mtei",Mende_Kikakui:"Mend",Meroitic_Cursive:"Merc",Meroitic_Hieroglyphs:"Mero",Miao:"Plrd",Modi:"Modi",Mongolian:"Mong",Mro:"Mroo",Multani:"Mult",Myanmar:"Mymr",Nabataean:"Nbat",New_Tai_Lue:"Talu",Newa:"Newa",Nko:"Nkoo",Nushu:"Nshu",Ogham:"Ogam",Ol_Chiki:"Olck",Old_Hungarian:"Hung",Old_Italic:"Ital",Old_North_Arabian:"Narb",Old_Permic:"Perm",Old_Persian:"Xpeo",Old_Sogdian:"Sogo",Old_South_Arabian:"Sarb",Old_Turkic:"Orkh",Oriya:"Orya",Osage:"Osge",Osmanya:"Osma",Pahawh_Hmong:"Hmng",Palmyrene:"Palm",Pau_Cin_Hau:"Pauc",Phags_Pa:"Phag",Phoenician:"Phnx",Psalter_Pahlavi:"Phlp",Rejang:"Rjng",Runic:"Runr",Samaritan:"Samr",Saurashtra:"Saur",Sharada:"Shrd",Shavian:"Shaw",Siddham:"Sidd",SignWriting:"Sgnw",Sinhala:"Sinh",Sogdian:"Sogd",Sora_Sompeng:"Sora",Soyombo:"Soyo",Sundanese:"Sund",Syloti_Nagri:"Sylo",Syriac:"Syrc",Tagalog:"Tglg",Tagbanwa:"Tagb",Tai_Le:"Tale",Tai_Tham:"Lana",Tai_Viet:"Tavt",Takri:"Takr",Tamil:"Taml",Tangut:"Tang",Telugu:"Telu",Thaana:"Thaa",Thai:"Thai",Tibetan:"Tibt",Tifinagh:"Tfng",Tirhuta:"Tirh",Ugaritic:"Ugar",Vai:"Vaii",Warang_Citi:"Wara",Yi:"Yiii",Zanabazar_Square:"Zanb"},NA=AW(Hw);function AW(X){let Y={};for(let Q of Object.keys(X)){let _=X[Q];if(Array.isArray(_))for(let G=0;G!==_.length;++G)Y[_[G]]=Q;else Y[_]=Q}return Y}function ka(X){return X in EW||X in aH}function ba(X){return X in vG||X in mQ}function BA(X){if(X in DA)return DA[X];if(X in mQ)return mQ[X];if(X in vG||X==="General_Category"||X==="Script"||X==="Script_Extensions")return X;throw Error(`Unknown Unicode property name: ${X}`)}function VA(X){if(X in aH)return aH[X];if(X in NA)return NA[X];if(X in mQ)return mQ[X];if(X in EW||X in Hw||X in vG)return X;throw Error(`Unknown Unicode property value: ${X}`)}function ga(X,Y){let Q=X.indexOf("=");if(Q!==-1){let _=X.substring(0,Q),G=X.substring(Q+1);return{type:"UnicodeProperty",name:_,value:G,negative:Y,shorthand:!1,binary:!1,canonicalName:BA(_),canonicalValue:VA(G)}}if(ka(X))return{type:"UnicodeProperty",name:"General_Category",value:X,negative:Y,shorthand:!0,binary:!1,canonicalName:"General_Category",canonicalValue:VA(X)};if(ba(X)){let _=BA(X);return{type:"UnicodeProperty",name:X,value:X,negative:Y,shorthand:!1,binary:!0,canonicalName:_,canonicalValue:_}}throw Error(`Invalid Unicode property: ${X}`)}var MH=String.fromCodePoint;function IH(X){let Y=X.pop();if(Y===void 0)throw Error("Unable to extract token preceeding the currently parsed one");return Y}function Ww(X){return X>="0"&&X<="9"}function EG(X,Y){return{type:"Char",kind:"simple",symbol:X,value:X,codePoint:X.codePointAt(0)||-1,escaped:Y}}function F9(X,Y){return{type:"Char",kind:"meta",symbol:Y,value:X,codePoint:Y.codePointAt(0)||-1}}function s8(X,Y){if(X.length>1)return{type:"Alternative",expressions:X};if(!Y&&X.length===0)throw Error("Unsupported no token");return X[0]}function jH(X){if(X[0]==="\\"){let Y=X[1];switch(Y){case"x":{let Q=X.substring(2),_=Number.parseInt(Q,16);return{type:"Char",kind:"hex",symbol:MH(_),value:X,codePoint:_}}case"u":{if(X==="\\u")return EG("u",!0);let Q=X[2]==="{"?X.substring(3,X.length-1):X.substring(2),_=Number.parseInt(Q,16);return{type:"Char",kind:"unicode",symbol:MH(_),value:X,codePoint:_}}case"0":return F9(X,"\x00");case"n":return F9(X,`
`);case"f":return F9(X,"\f");case"r":return F9(X,"\r");case"t":return F9(X,"\t");case"v":return F9(X,"\v");case"w":case"W":case"d":case"D":case"s":case"S":case"b":case"B":return{type:"Char",kind:"meta",symbol:void 0,value:X,codePoint:NaN};default:if(Ww(Y)){let Q=X.substring(1),_=Number(Q);return{type:"Char",kind:"decimal",symbol:MH(_),value:X,codePoint:_}}if(X.length>2&&(Y==="p"||Y==="P")){let Q=Y==="P";return ga(X.substring(3,X.length-1),Q)}return EG(X.substring(1),!0)}}return EG(X)}function E9(X,Y,Q,_){let G=null;for(let J=0,Z=qG(Y,J,Q,0);J!==Y.length;J+=Z.length,Z=qG(Y,J,Q,0)){let K=Z[0];switch(K){case"|":if(G===null)G=[];G.push(s8(X.splice(0),!0)||null);break;case".":X.push({type:"Char",kind:"meta",symbol:Z,value:Z,codePoint:NaN});break;case"*":case"+":{let H=IH(X);X.push({type:"Repetition",expression:H,quantifier:{type:"Quantifier",kind:K,greedy:!0}});break}case"?":{let H=IH(X);if(H.type==="Repetition")H.quantifier.greedy=!1,X.push(H);else X.push({type:"Repetition",expression:H,quantifier:{type:"Quantifier",kind:K,greedy:!0}});break}case"{":{if(Z==="{"){X.push(EG(Z));break}let H=IH(X),W=Z.substring(1,Z.length-1).split(","),D=Number(W[0]),U=W.length===1?D:W[1].length!==0?Number(W[1]):void 0;X.push({type:"Repetition",expression:H,quantifier:{type:"Quantifier",kind:"Range",greedy:!0,from:D,to:U}});break}case"[":{let H=Z.substring(1,Z.length-1),W=[],D=void 0,U=!1;for(let N=0,B=qG(H,N,Q,1);N!==H.length;N+=B.length,B=qG(H,N,Q,1)){if(N===0&&B==="^"){D=!0;continue}let q=jH(B);if(B==="-")W.push(q),U=!0;else{let O=W.length>=2?W[W.length-2]:void 0;if(U&&O!==void 0&&O.type==="Char"&&q.type==="Char")W.pop(),W.pop(),W.push({type:"ClassRange",from:O,to:q});else W.push(q);U=!1}}X.push({type:"CharacterClass",expressions:W,negative:D});break}case"(":{let H=Z.substring(1,Z.length-1),W=[];if(H[0]==="?")if(H[1]===":")E9(W,H.substring(2),Q,_),X.push({type:"Group",capturing:!1,expression:s8(W)});else if(H[1]==="="||H[1]==="!")E9(W,H.substring(2),Q,_),X.push({type:"Assertion",kind:"Lookahead",negative:H[1]==="!"?!0:void 0,assertion:s8(W)});else if(H[1]==="<"&&(H[2]==="="||H[2]==="!"))E9(W,H.substring(3),Q,_),X.push({type:"Assertion",kind:"Lookbehind",negative:H[2]==="!"?!0:void 0,assertion:s8(W)});else{let D=H.split(">");if(D.length<2||D[0][1]!=="<")throw Error(`Unsupported regex content found at ${JSON.stringify(Z)}`);let U=++_.lastIndex,N=D[0].substring(2);_.named.set(N,U),E9(W,D.slice(1).join(">"),Q,_),X.push({type:"Group",capturing:!0,nameRaw:N,name:N,number:U,expression:s8(W)})}else{let D=++_.lastIndex;E9(W,H,Q,_),X.push({type:"Group",capturing:!0,number:D,expression:s8(W)})}break}default:if(Z==="^")X.push({type:"Assertion",kind:Z});else if(Z==="$")X.push({type:"Assertion",kind:Z});else if(Z[0]==="\\"&&Ww(Z[1])){let H=Number(Z.substring(1));if(Q||H<=_.lastIndex)X.push({type:"Backreference",kind:"number",number:H,reference:H});else X.push(jH(Z))}else if(Z[0]==="\\"&&Z[1]==="k"&&Z.length!==2){let H=Z.substring(3,Z.length-1);X.push({type:"Backreference",kind:"name",number:_.named.get(H)||0,referenceRaw:H,reference:H})}else X.push(jH(Z));break}}if(G!==null){G.push(s8(X.splice(0),!0)||null);let J={type:"Disjunction",left:G[0],right:G[1]};for(let Z=2;Z<G.length;++Z)J={type:"Disjunction",left:J,right:G[Z]};X.push(J)}}function ya(X){let Y=kQ([...X.flags],"u")!==-1,Q=X.source,_=[];return E9(_,Q,Y,{lastIndex:0,named:new Map}),s8(_)}var ha=String.fromCodePoint;function ma(X){if(X.binary||X.shorthand)return X.canonicalValue;return`${X.canonicalName}=${X.canonicalValue}`}function qA(X,Y,Q,_){let G=-1;for(let J=Y;J<=Q;++J)if(X.test(ha(J))){if(G===-1)G=J}else if(G!==-1){let Z=J-1;_.push(G===Z?[Z]:[G,Z]),G=-1}if(G!==-1)_.push(G===Q?[Q]:[G,Q])}function da(X,Y){let Q=new RegExp(`^\\${Y?"P":"p"}{${X}}$`,"u"),_=[];return qA(Q,0,55295,_),qA(Q,57344,1114111,_),_}var zA=new Map;function fa(X,Y){let Q=`${Y?"P":"p"}:${X}`,_=zA.get(Q);if(_!==void 0)return _;let G=da(X,Y);return zA.set(Q,G),G}function pa(X){return M9(...q0(fa(ma(X),X.negative),(Y)=>yH(Y)))}var ua=String.fromCodePoint,Uw=[..."abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"],Dw=[..."0123456789"],Nw=[...` 	\r
\v\f`],tH=[...`\r
`],Bw=[..."\x1E\x15"],ca=[...tH,...Bw],la=new sX(Uw),oa=new sX(Dw),ra=new sX(Nw),ia=new sX(Bw),na=new sX(ca),J5=()=>s0({unit:"grapheme-ascii",minLength:1,maxLength:1});function OA(X){return new y(`Unsupported AST node! Received: ${r0(X)}`)}function $5(X,Y,Q){switch(X.type){case"Char":if(X.kind==="meta")switch(X.value){case"\\w":return A6(...Uw);case"\\W":return J5().filter((_)=>!a8(la,_));case"\\d":return A6(...Dw);case"\\D":return J5().filter((_)=>!a8(oa,_));case"\\s":return A6(...Nw);case"\\S":return J5().filter((_)=>!a8(ra,_));case"\\b":case"\\B":throw new y(`Meta character ${X.value} not implemented yet!`);case".":{let _=Q.dotAll?ia:na;return J5().filter((G)=>!a8(_,G))}}if(X.symbol===void 0)throw new y(`Unexpected undefined symbol received for non-meta Char! Received: ${r0(X)}`);return v0(X.symbol);case"Repetition":{let _=$5(X.expression,Y,Q);switch(X.quantifier.kind){case"*":return s0({...Y,unit:_});case"+":return s0({...Y,minLength:1,unit:_});case"?":return s0({...Y,minLength:0,maxLength:1,unit:_});case"Range":return s0({...Y,minLength:X.quantifier.from,maxLength:X.quantifier.to,unit:_});default:throw OA(X.quantifier)}}case"Quantifier":throw new y("Wrongly defined AST tree, Quantifier nodes not supposed to be scanned!");case"Alternative":{let _=[],G="";for(let J of X.expressions)if(J.type==="Char"&&J.kind!=="meta"&&J.symbol!==void 0)G+=J.symbol;else if(Q.multiline||J.type!=="Assertion"||J.kind!=="^"&&J.kind!=="$"){if(G!=="")S(_,v0(G)),G="";S(_,$5(J,Y,Q))}if(G!=="")S(_,v0(G));if(_.length===0)return v0("");if(_.length===1)return _[0];return $0(..._).map((J)=>x0(J,""))}case"CharacterClass":if(X.negative){let _=q0(X.expressions,(G)=>$5(G,Y,Q));return J5().filter((G)=>SA(_,(J)=>!J.canShrinkWithoutContext(G)))}return G1(...q0(X.expressions,(_)=>$5(_,Y,Q)));case"ClassRange":{let _=X.from.codePoint,G=X.to.codePoint;return A0({min:_,max:G}).map((J)=>ua(J),(J)=>{if(typeof J!=="string")throw new y("Invalid type");if([...J].length!==1)throw new y("Invalid length");return P9(J,0)})}case"Group":return $5(X.expression,Y,Q);case"Disjunction":{let _=[X.left,X.right],G=[];for(let J=0;J!==_.length;++J){let Z=_[J];if(Z===null)S(G,v0(""));else if(Z.type==="Disjunction")S(_,Z.left),S(_,Z.right);else S(G,$5(Z,Y,Q))}return G1(...G)}case"Assertion":if(X.kind==="^"||X.kind==="$"){if(Q.multiline)if(X.kind==="^")return G1(v0(""),$0(s0({unit:J5()}),A6(...tH)).map((_)=>`${_[0]}${_[1]}`,(_)=>{if(typeof _!=="string"||_.length===0)throw new y("Invalid type");return[m0(_,0,_.length-1),_[_.length-1]]}));else return G1(v0(""),$0(A6(...tH),s0({unit:J5()})).map((_)=>`${_[0]}${_[1]}`,(_)=>{if(typeof _!=="string"||_.length===0)throw new y("Invalid type");return[_[0],m0(_,1)]}));return v0("")}throw new y(`Assertions of kind ${X.kind} not implemented yet!`);case"Backreference":throw new y("Backreference nodes not implemented yet!");case"UnicodeProperty":return pa(X);default:throw OA(X)}}function sa(X,Y={}){for(let K of X.flags)if(K!=="d"&&K!=="g"&&K!=="m"&&K!=="s"&&K!=="u")throw new y(`Unable to use "stringMatching" against a regex using the flag ${K}`);let Q=Y.maxLength,_={size:Y.size,maxLength:Q},G={multiline:X.multiline,dotAll:X.dotAll},J=ja(ya(X));if(Q!==void 0)J=Ma(J,Q);let Z=$5(J,_,G);if(Q!==void 0)return Z.filter((K)=>[...K].length<=Q);return Z}function aa(X){let Y=[];for(let Q=0;Q!==X.length;++Q)Y.push(X[Q].next());return Y}function ta(X,Y){for(let Q=0;Q!==X.length;++Q)Y[Q]=X[Q].next()}function ea(X){for(let Y=0;Y!==X.length;++Y)if(X[Y].done)return!0;return!1}function*Xt(...X){let Y=aa(X);while(!ea(Y))yield Y.map((Q)=>Q.value),ta(X,Y)}function*Yt(X){let Y=X;while(!0)yield Y,++Y}var Qt=class extends k0{constructor(X,Y){super();this.arb=X,this.maxShrinks=Y}generate(X,Y){let Q=this.arb.generate(X,Y);return this.valueMapper(Q,0)}canShrinkWithoutContext(X){return this.arb.canShrinkWithoutContext(X)}shrink(X,Y){if(this.isSafeContext(Y))return this.safeShrink(X,Y.originalContext,Y.length);return this.safeShrink(X,void 0,0)}safeShrink(X,Y,Q){let _=this.maxShrinks-Q;if(_<=0)return Z0.nil();return new Z0(Xt(this.arb.shrink(X,Y),Yt(Q+1))).take(_).map((G)=>this.valueMapper(G[0],G[1]))}valueMapper(X,Y){let Q={originalContext:X.context,length:Y};return new g(X.value,Q)}isSafeContext(X){return X!==null&&X!==void 0&&typeof X==="object"&&"originalContext"in X&&"length"in X}};function _t(X,Y){return new Qt(X,Y)}var Gt="module",Jt="4.9.0",$t="0d3c2547dce556f72413607849377530d18ea283";var pQ=i3;function VX(){return(X,Y,Q)=>{return x(new Y5(X.map(NQ),(_)=>Y(_.map((G)=>x(G))),Q))}}function jX(X,Y){return VX()([],()=>(Q,_)=>X(Q)?p(Q):d(new l0(_,T(Q))),Y)}function Zt(X){return X}function Kt(X){return(Y)=>Y.annotate(X)}function Ht(X){return(Y)=>PW(PW(Y).annotate(X))}function Wt(X){return(Y)=>{return Y.rebuild(LQ(Y.ast,X))}}function Ut(X){return X}function Vw(X){return w1(X)?X.value:{issues:[{message:vq(X.cause)}]}}function Dt(X,Y){let Q=i0(X),_={errors:"all",...Y?.parseOptions},G=DL(Y),J=(Z)=>{let K=new b5,H=W2(K2(Q(Z,_),{onFailure:G,onSuccess:(D)=>({value:D})}),{scheduler:K});H.currentDispatcher?.flush();let W=H.pollUnsafe();if(W)return Vw(W);return new Promise((D)=>{H.addObserver((U)=>{D(Vw(U))})})};if("~standard"in X){let Z=X;if("validate"in Z["~standard"])return Z;return Object.assign(Z["~standard"],{validate:J}),Z}else return Object.assign(X,{"~standard":{version:1,vendor:"effect",validate:J}})}function qw(X,Y){let Q=EM(X);if(Y==="draft-2020-12"){let _=Q.schema;if(Object.keys(Q.definitions).length>0)_.$defs=Q.definitions;return _}else if(Y==="draft-07"){let _=XF(Q),G=_.schema;if(Object.keys(_.definitions).length>0)G.definitions=_.definitions;return G}throw new globalThis.Error(`Unsupported target: ${Y}`)}function Nt(X){let Y={input(Q){return qw(X,Q.target)},output(Q){return qw(p1(X),Q.target)}};if("~standard"in X){let Q=X;if("jsonSchema"in Q["~standard"])return Q;return Object.assign(Q["~standard"],{jsonSchema:Y}),Q}else return Object.assign(X,{"~standard":{version:1,vendor:"effect",jsonSchema:Y}})}var Mw=_R,Bt=JR;function yG(X,Y){let Q=i0(X,Y);return(_,G)=>{return n3(Q(_,G))}}var Vt=yG;function Iw(X,Y){let Q;for(let _ of X.reasons){if(!g7(_)||!mK(_.error))throw new globalThis.Error(Y,{cause:X});Q??=_.error}if(Q===void 0)throw new globalThis.Error(Y,{cause:X});return Q}function jw(X){return i7(X).then((Y)=>{if(w1(Y))return Y.value;throw Iw(Y.cause,"Promise adapter can only reject schema errors")})}function Sw(X){let Y=b8(X);if(w1(Y))return Y.value;throw Iw(Y.cause,"Sync adapter can only throw schema errors")}function vw(X,Y){let Q=$R(X,Y);return(_,G)=>{return xw(Q(_,G))}}function xw(X){return w1(X)?l5(X.value):v8(a6(X.cause,(Y)=>new i8(Y)))}var qt=vw,zt=fK,Ot=ZR;function kw(X,Y){let Q=KR(X,Y);return(_,G)=>{return w4(Q(_,G),(J)=>new i8(J))}}var Lt=kw;function bw(X,Y){let Q=yG(X,Y);return(_,G)=>{return jw(Q(_,G))}}var Tt=bw;function gw(X,Y){let Q=yG(X,Y);return(_,G)=>{return Sw(Q(_,G))}}var Rt=gw;function hG(X,Y){let Q=q9(X,Y);return(_,G)=>{return n3(Q(_,G))}}var yw=hG;function hw(X,Y){let Q=HR(X,Y);return(_,G)=>{return xw(Q(_,G))}}var Ft=hw,Et=uK,At=WR;function mw(X,Y){let Q=UR(X,Y);return(_,G)=>{return w4(Q(_,G),(J)=>new i8(J))}}var Pt=mw;function dw(X,Y){let Q=hG(X,Y);return(_,G)=>{return jw(Q(_,G))}}var wt=dw;function fw(X,Y){let Q=hG(X,Y);return(_,G)=>{return Sw(Q(_,G))}}var Ct=fw,x=AQ;function mG(X){return I(X,pQ)&&X[pQ]===pQ}var _4=C1((X)=>x(TQ(X.ast),{schema:X})),Mt=C1((X)=>X.schema),IX=C1((X)=>_4(pG(X))),It=C1((X)=>X.schema.members[0]),jt=C1((X)=>x(SK(X.ast),{schema:X})),St=C1((X)=>X.schema),p1=C1((X)=>x(O1(X.ast),{schema:X})),k9=C1((X)=>x(L1(X.ast),{schema:X})),uQ="~effect/Schema/flip";function vt(X){return I(X,uQ)&&X[uQ]===uQ}function PW(X){if(vt(X))return X.schema.rebuild(pX(X.ast));return x(pX(X.ast),{[uQ]:uQ,schema:X})}function d0(X){let Y=x(new WX(X),{literal:X,transform(Q){return Y.pipe(l(d0(Q),{decode:Y0(()=>Q),encode:Y0(()=>X)}))}});return Y}function pw(X){return new FK(X.map((Y)=>mG(Y)?Y.ast:new WX(Y)))}function xt(X){return x(pw(X),{parts:X})}function kt(X){return x(pw(X).asTemplateLiteralParser(),{parts:X})}function bt(X){return x(new RK(Object.keys(X).filter((Y)=>typeof X[X[Y]]!=="number").map((Y)=>[Y,X[Y]])),{enums:X})}var gt=x(LT),yt=x(RT),MW=x(a4),L0=x(TK),IW=x(VT),i=x(u8),dG=x(AK),uw=x(IT),cw=x(ST),P6=x(xT),ht=x(zT),mt=x(AT);function dt(X){return x(new EK(X))}function jW(X,Y){return x(X,{fields:Y,mapFields(Q,_){let G=Q(this.fields);return jW(x3(G,_?.unsafePreserveChecks?this.ast.checks:void 0),G)}})}function h(X){return jW(x3(X,void 0),X)}function ft(X){return C1((Y)=>Y.mapFields(LR(X)))}var pt=(X)=>typeof X==="symbol"?X:globalThis.String(X);function ut(X){return function(Y){let Q={},_=Object.create(null),G=Object.create(null),J=new Set;for(let Z of Reflect.ownKeys(Y.fields)){let K=k9(Y.fields[Z]),H=Object.hasOwn(X,Z),W=H?X[Z]:Z,D=pt(W);if(J.has(D))throw new globalThis.Error(`Duplicate encoded keys: ${x6(W)}`);if(J.add(D),k(Q,W,K),H)_[Z]=W,G[W]=Z}return h(Q).pipe(l(Y,y0({decode:oK(G),encode:oK(_)})))}}function ct(X,Y){return(Q)=>{let _=t_(Q.fields,p1),G=h({..._,...X});return Q.pipe(l(G,y0({decode:(J)=>{let Z={...J};for(let K in X){let H=Y[K],W=H(J);if(W1(W))k(Z,K,W.value)}return Z},encode:(J)=>{let Z={...J};for(let K in X)delete Z[K];return Z}})))}}function lw(X,Y,Q){let _=Q?.keyValueCombiner?.decode||Q?.keyValueCombiner?.encode?new S3(Q.keyValueCombiner.decode,Q.keyValueCombiner.encode):void 0;return x(uT(X.ast,Y.ast,_),{key:X,value:Y})}function lt(X,Y){return x(kT(X.ast,Y.map(NQ)),{schema:X,records:Y})}function ow(X,Y){return x(X,{elements:Y,mapElements(Q,_){let G=Q(this.elements);return ow(CK(G,_?.unsafePreserveChecks?this.ast.checks:void 0),G)}})}function j9(X){return ow(CK(X),X)}function ot(X,Y){return x(bT(X.ast,Y.map(NQ)),{schema:X,rest:Y})}var e0=C1((X)=>x(new cX(!1,[],[X.ast]),{value:X}));var rt=C1((X)=>x(new cX(!1,[X.ast],[X.ast]),{value:X}));function it(X){return X1([X,e0(X)]).pipe(l(e0(p1(X)),y0({decode:NN,encode:(Y)=>Y.length===1?Y[0]:Y})))}function nt(X){return e0(X).check(fW())}var st=C1((X)=>{return x(new cX(!0,X.ast.elements,X.ast.rest),{schema:X})});function rw(X,Y){return x(X,{members:Y,mapMembers(Q,_){let G=Q(this.members);return rw(k3(G,this.ast.mode,_?.unsafePreserveChecks?this.ast.checks:void 0),G)}})}function X1(X,Y){return rw(k3(X,Y?.mode??"anyOf",void 0),X)}function fG(X){let Y=X.map(d0);return x(k3(Y,"anyOf",void 0),{literals:X,members:Y,mapMembers(Q){return X1(Q(this.members))},pick(Q){return fG(Q)},transform(Q){return X1(Y.map((_,G)=>_.transform(Q[G])))}})}var SW=C1((X)=>X1([X,L0])),pG=C1((X)=>X1([X,IW])),iw=C1((X)=>X1([X,L0,IW]));function nw(X){return x(new b3(()=>X().ast))}function at(...X){return(Y)=>Y.check(...X)}function tt(X,Y){return(Q)=>x(lX(Q.ast,[y3(X,Y)]),{schema:Q})}function sw(X){return(Y)=>x(fT(Y.ast,X),{schema:Y,identifier:X})}function et(X,Y){return(Q)=>{return(Y.checks?Q.check(...Y.checks):Q).pipe(sw(X))}}function vW(X){return(Y)=>x(mT(Y.ast,new HQ(X,u)),{schema:Y})}function aw(X){return(Y)=>x(dT(Y.ast,new HQ(u,X)),{schema:Y})}function Xe(X){return tw(X)}function tw(X){return(Y)=>vW(n7(X))(Y)}function Ye(X){return ew(X)}function ew(X){return(Y)=>aw(n7(X))(Y)}function l(X,Y){return(Q)=>{return x(d3(Q.ast,X.ast,Y?E3(Y):K9()),{from:Q,to:X})}}function Qe(X){return(Y)=>{return l(p1(Y),X)(Y)}}function xW(X,Y){return(Q)=>{return Y?l(Q,Y)(X):l(Q)(X)}}function _e(X){return(Y)=>{return l(Y,X)(k9(Y))}}function XC(X){return(Y)=>x(pT(Y.ast,kW(X)),{schema:Y})}function kW(X){return p4(X,(Y)=>f4(()=>a6(Y,(Q)=>Q.issue)))}function bW(X,Y){let Q=Y?.encodingStrategy==="omit"?YK():fX();return(_)=>{return _4(k9(_)).pipe(l(_,{decode:ZQ(kW(X)),encode:Q}))}}function Ge(X,Y){return(Q)=>{return p1(Q).pipe(bW(X,Y),xW(_4(Q)))}}function YC(X,Y){let Q=Y?.encodingStrategy==="omit"?YK():fX();return(_)=>{return IX(k9(_)).pipe(l(_,{decode:ZQ(kW(X)),encode:Q}))}}function Je(X,Y){return(Q)=>{return p1(Q).pipe(YC(X,Y),xW(IX(Q)))}}function W5(X){return d0(X).pipe(XC(p(X)))}function $e(X){return W5(X).pipe(bW(p(X),{encodingStrategy:"omit"}))}function uG(X,Y){return h({_tag:W5(X),...Y})}function QC(X){return(Y)=>{let Q={},_=[],G=new Set,J={},Z=(W)=>(D)=>W.includes(D[X]);return K(Y),Object.assign(Y,{cases:Q,discriminants:_,isAnyOf:Z,guards:J,match:H});function K(W){let D=W.ast;if(DQ(D)&&"members"in W&&globalThis.Array.isArray(W.members)&&W.members.every(mG))return W.members.forEach(K);let U=BQ(D);if(U.length>0){let N=U.find((B)=>B.key===X)?.literal;if(L_(N)){let B=typeof N==="number"?globalThis.String(N):N;if(G.has(B))throw new globalThis.Error(`Duplicate discriminant: ${globalThis.String(N)}`);G.add(B),_.push(N),k(Q,N,W),k(J,N,Mw(p1(W)));return}}throw new globalThis.Error("No literal or unique symbol found")}function H(){if(arguments.length===1){let B=arguments[0];return function(q){let O=q[X];return(Object.hasOwn(B,O)?B[O]:void 0)(q)}}let W=arguments[0],D=arguments[1],U=W[X];return(Object.hasOwn(D,U)?D[U]:void 0)(W)}}}function Ze(X){let Y={},Q=[];for(let K of Object.keys(X)){let H=uG(K,X[K]);k(Y,K,H),Q.push(H)}let _=X1(Q),{guards:G,isAnyOf:J,match:Z}=QC("_tag")(_);return x(_.ast,{cases:Y,isAnyOf:J,guards:G,match:Z})}function Ke(){return(X)=>{return X}}function G4(X,Y){return jX((Q)=>Q instanceof X,Y)}function I0(){return(X,Y)=>{return new h0(X.ast,E3(Y))}}var C0=g3;function He(X,Y=void 0){return new p8(X,Y)}function M1(X,Y){return YX(X,L0,({annotations:Q})=>Q===void 0?Y:Y.annotate(Q))}var zw="^\\S[\\s\\S]*\\S$|^\\S$|^$";function gW(X){let Y=new globalThis.RegExp(zw);return C0((Q)=>Q.trim()===Q,{expected:"a string with no leading or trailing whitespace",representation:{id:"effect/schema/isTrimmed",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isTrimmed()"}),arbitrary:{constraint:{patterns:[zw]}},...X})}var We=n("effect/schema/isTrimmed",L0,({annotations:X})=>gW(X));function U5(X,Y){let{source:Q,flags:_}=X,G=_===""?`new RegExp(${A(Q)})`:`new RegExp(${A(Q)}, ${A(_)})`;return qQ(X,{toCode:()=>({runtime:`Schema.isPattern(${G})`}),...Y})}var Ue=h({source:i,flags:i}).check(C0((X)=>{let Y=Z$(()=>new globalThis.RegExp(X.source,X.flags));return t0(Y)&&Y.success.source===X.source&&Y.success.flags===X.flags})),De={id:"effect/schema/isPattern",payloadSchema:Ue,revive:({annotations:X,payload:Y})=>U5(new globalThis.RegExp(Y.source,Y.flags),X)};function _C(X){return xK({toCode:()=>({runtime:"Schema.isStringFinite()"}),...X})}var Ne=n("effect/schema/isStringFinite",L0,({annotations:X})=>_C(X));function GC(X){return kK({toCode:()=>({runtime:"Schema.isStringBigInt()"}),...X})}var Be=n("effect/schema/isStringBigInt",L0,({annotations:X})=>GC(X));function JC(X){return gK({toCode:()=>({runtime:"Schema.isStringSymbol()"}),...X})}var Ve=n("effect/schema/isStringSymbol",L0,({annotations:X})=>JC(X)),qe=(X)=>{if(X)return new globalThis.RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${X}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`);return/^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|[fF]{8}-[fF]{4}-[fF]{4}-[fF]{4}-[fF]{12})$/};function $C(X,Y){let Q=qe(X);return U5(Q,{expected:X?`a UUID v${X}`:"a UUID",representation:{id:"effect/schema/isUUID",payload:{version:X??null}},toJsonSchema:()=>({pattern:Q.source,format:"uuid"}),toCode:()=>({runtime:X===void 0?"Schema.isUUID()":`Schema.isUUID(${X})`}),...Y})}var ze=n("effect/schema/isUUID",h({version:X1([fG([1,2,3,4,5,6,7,8]),L0])}),({annotations:X,payload:Y})=>$C(Y.version??void 0,X)),Ow=/^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/;function ZC(X){return U5(Ow,{expected:"a GUID",representation:{id:"effect/schema/isGUID",payload:null},toJsonSchema:()=>({pattern:Ow.source}),toCode:()=>({runtime:"Schema.isGUID()"}),...X})}var Oe=n("effect/schema/isGUID",L0,({annotations:X})=>ZC(X));function KC(X){let Y=/^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/;return U5(Y,{representation:{id:"effect/schema/isULID",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isULID()"}),...X})}var Le=n("effect/schema/isULID",L0,({annotations:X})=>KC(X));function yW(X){let Y=/^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;return U5(Y,{expected:"a base64 encoded string",representation:{id:"effect/schema/isBase64",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isBase64()"}),...X})}var Te=n("effect/schema/isBase64",L0,({annotations:X})=>yW(X));function HC(X){let Y=/^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;return U5(Y,{expected:"a base64url encoded string",representation:{id:"effect/schema/isBase64Url",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isBase64Url()"}),...X})}var Re=n("effect/schema/isBase64Url",L0,({annotations:X})=>HC(X));function WC(X,Y){let Q=JSON.stringify(X),_=new globalThis.RegExp(`^${L9(X)}`);return C0((G)=>G.startsWith(X),{expected:`a string starting with ${Q}`,representation:{id:"effect/schema/isStartsWith",payload:{startsWith:X}},toJsonSchema:()=>({pattern:_.source}),toCode:()=>({runtime:`Schema.isStartsWith(${A(X)})`}),arbitrary:{constraint:{patterns:[_.source]}},...Y})}var Fe=n("effect/schema/isStartsWith",h({startsWith:i}),({annotations:X,payload:Y})=>WC(Y.startsWith,X));function UC(X,Y){let Q=JSON.stringify(X),_=new globalThis.RegExp(`${L9(X)}$`);return C0((G)=>G.endsWith(X),{expected:`a string ending with ${Q}`,representation:{id:"effect/schema/isEndsWith",payload:{endsWith:X}},toJsonSchema:()=>({pattern:_.source}),toCode:()=>({runtime:`Schema.isEndsWith(${A(X)})`}),arbitrary:{constraint:{patterns:[_.source]}},...Y})}var Ee=n("effect/schema/isEndsWith",h({endsWith:i}),({annotations:X,payload:Y})=>UC(Y.endsWith,X));function DC(X,Y){let Q=JSON.stringify(X),_=new globalThis.RegExp(L9(X));return C0((G)=>G.includes(X),{expected:`a string including ${Q}`,representation:{id:"effect/schema/isIncludes",payload:{includes:X}},toJsonSchema:()=>({pattern:_.source}),toCode:()=>({runtime:`Schema.isIncludes(${A(X)})`}),arbitrary:{constraint:{patterns:[_.source]}},...Y})}var Ae=n("effect/schema/isIncludes",h({includes:i}),({annotations:X,payload:Y})=>DC(Y.includes,X)),Lw="^[^a-z]*$";function NC(X){let Y=new globalThis.RegExp(Lw);return C0((Q)=>Q.toUpperCase()===Q,{expected:"a string with all characters in uppercase",representation:{id:"effect/schema/isUppercased",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isUppercased()"}),arbitrary:{constraint:{patterns:[Lw]}},...X})}var Pe=n("effect/schema/isUppercased",L0,({annotations:X})=>NC(X)),Tw="^[^A-Z]*$";function BC(X){let Y=new globalThis.RegExp(Tw);return C0((Q)=>Q.toLowerCase()===Q,{expected:"a string with all characters in lowercase",representation:{id:"effect/schema/isLowercased",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isLowercased()"}),arbitrary:{constraint:{patterns:[Tw]}},...X})}var we=n("effect/schema/isLowercased",L0,({annotations:X})=>BC(X)),Rw="^[^a-z]?.*$";function VC(X){let Y=new globalThis.RegExp(Rw);return C0((Q)=>Q.charAt(0).toUpperCase()===Q.charAt(0),{expected:"a string with the first character in uppercase",representation:{id:"effect/schema/isCapitalized",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isCapitalized()"}),arbitrary:{constraint:{patterns:[Rw]}},...X})}var Ce=n("effect/schema/isCapitalized",L0,({annotations:X})=>VC(X)),Fw="^[^A-Z]?.*$";function qC(X){let Y=new globalThis.RegExp(Fw);return C0((Q)=>Q.charAt(0).toLowerCase()===Q.charAt(0),{expected:"a string with the first character in lowercase",representation:{id:"effect/schema/isUncapitalized",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isUncapitalized()"}),arbitrary:{constraint:{patterns:[Fw]}},...X})}var Me=n("effect/schema/isUncapitalized",L0,({annotations:X})=>qC(X)),eX=x(M3),zC=MK,Ie=n("effect/schema/isFinite",L0,({annotations:X})=>zC(X));function cQ(X){let Y=R8(X.order),Q=X.formatter??A;return(_,G)=>{return C0((J)=>Y(J,_),{expected:`a value greater than ${Q(_)}`,arbitrary:{constraint:{ordered:{order:X.order,minimum:_,exclusiveMinimum:!0}}},...X.annotate?.(_),...G})}}function lQ(X){let Y=GY(X.order),Q=X.formatter??A;return(_,G)=>{return C0((J)=>Y(J,_),{expected:`a value greater than or equal to ${Q(_)}`,arbitrary:{constraint:{ordered:{order:X.order,minimum:_}}},...X.annotate?.(_),...G})}}function oQ(X){let Y=C5(X.order),Q=X.formatter??A;return(_,G)=>{return C0((J)=>Y(J,_),{expected:`a value less than ${Q(_)}`,arbitrary:{constraint:{ordered:{order:X.order,maximum:_,exclusiveMaximum:!0}}},...X.annotate?.(_),...G})}}function rQ(X){let Y=_Y(X.order),Q=X.formatter??A;return(_,G)=>{return C0((J)=>Y(J,_),{expected:`a value less than or equal to ${Q(_)}`,arbitrary:{constraint:{ordered:{order:X.order,maximum:_}}},...X.annotate?.(_),...G})}}function iQ(X){let Y=GY(X.order),Q=R8(X.order),_=_Y(X.order),G=C5(X.order),J=X.formatter??A;return(Z,K)=>{let H=Z.exclusiveMinimum?Q:Y,W=Z.exclusiveMaximum?G:_;return C0((D)=>H(D,Z.minimum)&&W(D,Z.maximum),{expected:`a value between ${J(Z.minimum)}${Z.exclusiveMinimum?" (excluded)":""} and ${J(Z.maximum)}${Z.exclusiveMaximum?" (excluded)":""}`,arbitrary:{constraint:{ordered:{order:X.order,minimum:Z.minimum,maximum:Z.maximum,...Z.exclusiveMinimum&&{exclusiveMinimum:!0},...Z.exclusiveMaximum&&{exclusiveMaximum:!0}}}},...X.annotate?.(Z),...K})}}function OC(X){return(Y,Q)=>{let _=X.formatter??A;return C0((G)=>X.remainder(G,Y)===X.zero,{expected:`a value that is a multiple of ${_(Y)}`,...X.annotate?.(Y),...Q})}}function S9(X){if(!globalThis.Number.isFinite(X))throw new globalThis.RangeError(`Expected a finite number, got ${A(X)}`);return X}var LC=cQ({order:q1,annotate:(X)=>({representation:{id:"effect/schema/isGreaterThan",payload:{exclusiveMinimum:S9(X)}},toJsonSchema:()=>({exclusiveMinimum:X}),toCode:()=>({runtime:`Schema.isGreaterThan(${A(X)})`})})}),je=n("effect/schema/isGreaterThan",h({exclusiveMinimum:eX}),({annotations:X,payload:Y})=>LC(Y.exclusiveMinimum,X)),hW=lQ({order:q1,annotate:(X)=>({representation:{id:"effect/schema/isGreaterThanOrEqualTo",payload:{minimum:S9(X)}},toJsonSchema:()=>({minimum:X}),toCode:()=>({runtime:`Schema.isGreaterThanOrEqualTo(${A(X)})`})})}),Se=n("effect/schema/isGreaterThanOrEqualTo",h({minimum:eX}),({annotations:X,payload:Y})=>hW(Y.minimum,X)),TC=oQ({order:q1,annotate:(X)=>({representation:{id:"effect/schema/isLessThan",payload:{exclusiveMaximum:S9(X)}},toJsonSchema:()=>({exclusiveMaximum:X}),toCode:()=>({runtime:`Schema.isLessThan(${A(X)})`})})}),ve=n("effect/schema/isLessThan",h({exclusiveMaximum:eX}),({annotations:X,payload:Y})=>TC(Y.exclusiveMaximum,X)),RC=rQ({order:q1,annotate:(X)=>({representation:{id:"effect/schema/isLessThanOrEqualTo",payload:{maximum:S9(X)}},toJsonSchema:()=>({maximum:X}),toCode:()=>({runtime:`Schema.isLessThanOrEqualTo(${A(X)})`})})}),xe=n("effect/schema/isLessThanOrEqualTo",h({maximum:eX}),({annotations:X,payload:Y})=>RC(Y.maximum,X)),cG=iQ({order:q1,annotate:(X)=>{let Y=X.exclusiveMinimum?!0:void 0,Q=X.exclusiveMaximum?!0:void 0;return{representation:{id:"effect/schema/isBetween",payload:{minimum:S9(X.minimum),maximum:S9(X.maximum),...Y&&{exclusiveMinimum:Y},...Q&&{exclusiveMaximum:Q}}},toJsonSchema:()=>({[Y?"exclusiveMinimum":"minimum"]:X.minimum,[Q?"exclusiveMaximum":"maximum"]:X.maximum}),toCode:()=>({runtime:`Schema.isBetween({ minimum: ${A(X.minimum)}, maximum: ${A(X.maximum)}, exclusiveMinimum: ${A(Y)}, exclusiveMaximum: ${A(Q)} })`})}}}),ke=n("effect/schema/isBetween",h({minimum:eX,maximum:eX,exclusiveMinimum:IX(d0(!0)),exclusiveMaximum:IX(d0(!0))}),({annotations:X,payload:Y})=>cG(Y,X)),FC=OC({remainder:iq,zero:0,annotate:(X)=>({expected:`a value that is a multiple of ${X}`,representation:{id:"effect/schema/isMultipleOf",payload:{divisor:X}},toJsonSchema:()=>({multipleOf:X}),toCode:()=>({runtime:`Schema.isMultipleOf(${A(X)})`})})}),be=n("effect/schema/isMultipleOf",h({divisor:eX}),({annotations:X,payload:Y})=>FC(Y.divisor,X));function nQ(X){return C0((Y)=>globalThis.Number.isSafeInteger(Y),{expected:"an integer",representation:{id:"effect/schema/isInt",payload:null},toJsonSchema:()=>({type:"integer"}),toCode:()=>({runtime:"Schema.isInt()"}),arbitrary:{constraint:{integer:!0}},...X})}var ge=n("effect/schema/isInt",L0,({annotations:X})=>nQ(X)),D5=dG.check(nQ()),BX=D5.check(hW(0));function ye(X){return new p8([nQ(),cG({minimum:-2147483648,maximum:2147483647})],{expected:"a 32-bit integer",...X})}function he(X){return new p8([nQ(),cG({minimum:0,maximum:4294967295})],{expected:"a 32-bit unsigned integer",...X})}function v9(X){if(globalThis.Number.isNaN(X.getTime()))throw new globalThis.RangeError(`Expected a valid Date, got ${A(X)}`);return X.toISOString()}function x9(X){return`new Date(${A(X.getTime())})`}var EC=cQ({order:R4,annotate:(X)=>{return{representation:{id:"effect/schema/isGreaterThanDate",payload:{exclusiveMinimum:v9(X)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isGreaterThanDate(${x9(X)})`})}}}),AC=lQ({order:R4,annotate:(X)=>{return{representation:{id:"effect/schema/isGreaterThanOrEqualToDate",payload:{minimum:v9(X)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isGreaterThanOrEqualToDate(${x9(X)})`})}}}),PC=oQ({order:R4,annotate:(X)=>{return{representation:{id:"effect/schema/isLessThanDate",payload:{exclusiveMaximum:v9(X)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isLessThanDate(${x9(X)})`})}}}),wC=rQ({order:R4,annotate:(X)=>{return{representation:{id:"effect/schema/isLessThanOrEqualToDate",payload:{maximum:v9(X)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isLessThanOrEqualToDate(${x9(X)})`})}}}),CC=iQ({order:R4,annotate:(X)=>{let Y=X.exclusiveMinimum?!0:void 0,Q=X.exclusiveMaximum?!0:void 0;return{representation:{id:"effect/schema/isBetweenDate",payload:{minimum:v9(X.minimum),maximum:v9(X.maximum),...Y&&{exclusiveMinimum:Y},...Q&&{exclusiveMaximum:Q}}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isBetweenDate({ minimum: ${x9(X.minimum)}, maximum: ${x9(X.maximum)}, exclusiveMinimum: ${A(Y)}, exclusiveMaximum: ${A(Q)} })`})}}}),MC=cQ({order:RX,annotate:(X)=>{return{representation:{id:"effect/schema/isGreaterThanBigInt",payload:{exclusiveMinimum:X.toString(10)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isGreaterThanBigInt(${A(X)})`})}}}),IC=lQ({order:RX,annotate:(X)=>{return{representation:{id:"effect/schema/isGreaterThanOrEqualToBigInt",payload:{minimum:X.toString(10)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isGreaterThanOrEqualToBigInt(${A(X)})`})}}}),jC=oQ({order:RX,annotate:(X)=>{return{representation:{id:"effect/schema/isLessThanBigInt",payload:{exclusiveMaximum:X.toString(10)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isLessThanBigInt(${A(X)})`})}}}),SC=rQ({order:RX,annotate:(X)=>{return{representation:{id:"effect/schema/isLessThanOrEqualToBigInt",payload:{maximum:X.toString(10)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isLessThanOrEqualToBigInt(${A(X)})`})}}}),vC=iQ({order:RX,annotate:(X)=>{let Y=X.exclusiveMinimum?!0:void 0,Q=X.exclusiveMaximum?!0:void 0;return{representation:{id:"effect/schema/isBetweenBigInt",payload:{minimum:X.minimum.toString(10),maximum:X.maximum.toString(10),...Y&&{exclusiveMinimum:Y},...Q&&{exclusiveMaximum:Q}}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isBetweenBigInt({ minimum: ${A(X.minimum)}, maximum: ${A(X.maximum)}, exclusiveMinimum: ${A(Y)}, exclusiveMaximum: ${A(Q)} })`})}}}),me=cQ({order:e6,formatter:(X)=>L6(X)}),de=lQ({order:e6,formatter:(X)=>L6(X)}),fe=oQ({order:e6,formatter:(X)=>L6(X)}),pe=rQ({order:e6,formatter:(X)=>L6(X)}),ue=iQ({order:e6,formatter:(X)=>L6(X)});function mW(X,Y){return X=Math.max(0,Math.floor(X)),C0((Q)=>Q.length>=X,{expected:`a value with a length of at least ${X}`,representation:{id:"effect/schema/isMinLength",payload:{minLength:X}},toJsonSchema:({type:Q})=>Q==="array"?{minItems:X}:{minLength:X},toCode:()=>({runtime:`Schema.isMinLength(${X})`}),[t1]:!0,arbitrary:{constraint:{minLength:X}},...Y})}var ce=n("effect/schema/isMinLength",h({minLength:BX}),({annotations:X,payload:Y})=>mW(Y.minLength,X));function xC(X){return mW(1,X)}function kC(X,Y){return X=Math.max(0,Math.floor(X)),C0((Q)=>Q.length<=X,{expected:`a value with a length of at most ${X}`,representation:{id:"effect/schema/isMaxLength",payload:{maxLength:X}},toJsonSchema:({type:Q})=>Q==="array"?{maxItems:X}:{maxLength:X},toCode:()=>({runtime:`Schema.isMaxLength(${X})`}),[t1]:!0,arbitrary:{constraint:{maxLength:X}},...Y})}var le=n("effect/schema/isMaxLength",h({maxLength:BX}),({annotations:X,payload:Y})=>kC(Y.maxLength,X));function dW(X,Y,Q){return X=Math.max(0,Math.floor(X)),Y=Math.max(0,Math.floor(Y)),C0((_)=>_.length>=X&&_.length<=Y,{expected:X===Y?`a value with a length of ${X}`:`a value with a length between ${X} and ${Y}`,representation:{id:"effect/schema/isLengthBetween",payload:{minimum:X,maximum:Y}},toJsonSchema:({type:_})=>_==="array"?{allOf:[{minItems:X},{maxItems:Y}]}:{allOf:[{minLength:X},{maxLength:Y}]},toCode:()=>({runtime:`Schema.isLengthBetween(${X}, ${Y})`}),[t1]:!0,arbitrary:{constraint:{minLength:X,maxLength:Y}},...Q})}var oe=n("effect/schema/isLengthBetween",h({minimum:BX,maximum:BX}),({annotations:X,payload:Y})=>dW(Y.minimum,Y.maximum,X));function bC(X,Y){return X=Math.max(0,Math.floor(X)),C0((Q)=>Q.size>=X,{expected:`a value with a size of at least ${X}`,representation:{id:"effect/schema/isMinSize",payload:{minSize:X}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isMinSize(${X})`}),[t1]:!0,arbitrary:{constraint:{minLength:X}},...Y})}var re=n("effect/schema/isMinSize",h({minSize:BX}),({annotations:X,payload:Y})=>bC(Y.minSize,X));function gC(X,Y){return X=Math.max(0,Math.floor(X)),C0((Q)=>Q.size<=X,{expected:`a value with a size of at most ${X}`,representation:{id:"effect/schema/isMaxSize",payload:{maxSize:X}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isMaxSize(${X})`}),[t1]:!0,arbitrary:{constraint:{maxLength:X}},...Y})}var ie=n("effect/schema/isMaxSize",h({maxSize:BX}),({annotations:X,payload:Y})=>gC(Y.maxSize,X));function yC(X,Y,Q){return X=Math.max(0,Math.floor(X)),Y=Math.max(0,Math.floor(Y)),C0((_)=>_.size>=X&&_.size<=Y,{expected:X===Y?`a value with a size of ${X}`:`a value with a size between ${X} and ${Y}`,representation:{id:"effect/schema/isSizeBetween",payload:{minimum:X,maximum:Y}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isSizeBetween(${X}, ${Y})`}),[t1]:!0,arbitrary:{constraint:{minLength:X,maxLength:Y}},...Q})}var ne=n("effect/schema/isSizeBetween",h({minimum:BX,maximum:BX}),({annotations:X,payload:Y})=>yC(Y.minimum,Y.maximum,X));function hC(X,Y){return X=Math.max(0,Math.floor(X)),C0((Q)=>Reflect.ownKeys(Q).length>=X,{expected:`a value with at least ${X===1?"1 entry":`${X} entries`}`,representation:{id:"effect/schema/isMinProperties",payload:{minProperties:X}},toJsonSchema:()=>({minProperties:X}),toCode:()=>({runtime:`Schema.isMinProperties(${X})`}),[t1]:!0,arbitrary:{constraint:{minLength:X}},...Y})}var se=n("effect/schema/isMinProperties",h({minProperties:BX}),({annotations:X,payload:Y})=>hC(Y.minProperties,X));function mC(X,Y){return X=Math.max(0,Math.floor(X)),C0((Q)=>Reflect.ownKeys(Q).length<=X,{expected:`a value with at most ${X===1?"1 entry":`${X} entries`}`,representation:{id:"effect/schema/isMaxProperties",payload:{maxProperties:X}},toJsonSchema:()=>({maxProperties:X}),toCode:()=>({runtime:`Schema.isMaxProperties(${X})`}),[t1]:!0,arbitrary:{constraint:{maxLength:X}},...Y})}var ae=n("effect/schema/isMaxProperties",h({maxProperties:BX}),({annotations:X,payload:Y})=>mC(Y.maxProperties,X));function dC(X,Y,Q){return X=Math.max(0,Math.floor(X)),Y=Math.max(0,Math.floor(Y)),C0((_)=>Reflect.ownKeys(_).length>=X&&Reflect.ownKeys(_).length<=Y,{expected:X===Y?`a value with exactly ${X===1?"1 entry":`${X} entries`}`:`a value with between ${X} and ${Y} entries`,representation:{id:"effect/schema/isPropertiesLengthBetween",payload:{minimum:X,maximum:Y}},toJsonSchema:()=>({minProperties:X,maxProperties:Y}),toCode:()=>({runtime:`Schema.isPropertiesLengthBetween(${X}, ${Y})`}),[t1]:!0,arbitrary:{constraint:{minLength:X,maxLength:Y}},...Q})}var te=n("effect/schema/isPropertiesLengthBetween",h({minimum:BX,maximum:BX}),({annotations:X,payload:Y})=>dC(Y.minimum,Y.maximum,X));function fC(X,Y){let Q=k9(X),_=GR(Q.ast);return C0((G,J,Z)=>{let K=Reflect.ownKeys(G),H=[];for(let W of K){let D=_(W,Z);if(D!==void 0){if(H.push(new M0([W],D)),Z.errors==="first")break}}if(W6(H))return new T0(J,T(G),H);return!0},{expected:"an object with property names matching the schema",representation:{id:"effect/schema/isPropertyNames",payload:null,schemas:[Q.ast]},toJsonSchema:({schemas:G})=>({propertyNames:G[0]}),toCode:({schemas:G})=>({runtime:`Schema.isPropertyNames(${G[0].runtime})`}),[t1]:!0,...Y})}var ee=n("effect/schema/isPropertyNames",L0,({annotations:X,schemas:Y})=>fC(Y[0],X));function fW(X){return C0((Y)=>Y7(Y).length===Y.length,{expected:"an array with unique items",representation:{id:"effect/schema/isUnique",payload:null},toJsonSchema:()=>({uniqueItems:!0}),toCode:()=>({runtime:"Schema.isUnique()"}),arbitrary:{constraint:{unique:!0}},...X})}var X00=n("effect/schema/isUnique",L0,({annotations:X})=>fW(X)),Y00=i.check(xC()),Q00=i.check(dW(1,1));function J4(X){let Y=VX()([X],([Q])=>(_,G,J)=>{if(p_(_)){if(E0(_))return mX;return U1(i0(Q)(_.value,J),{onSuccess:T,onFailure:(Z)=>new T0(G,T(_),[new M0(["value"],Z)])})}return d(new l0(G,T(_)))},{representation:{id:"effect/schema/Option",payload:null},toCode:({typeParameters:Q})=>({runtime:`Schema.Option(${Q[0].runtime})`,Type:`Option.Option<${Q[0].Type}>`,importDeclarations:['import * as Option from "effect/Option"']}),expected:"Option",toCodec:([Q])=>I0()(X1([h({_tag:d0("Some"),value:Q}),h({_tag:d0("None")})]),y0({decode:(_)=>_._tag==="None"?f():T(_.value),encode:(_)=>W1(_)?{_tag:"Some",value:_.value}:{_tag:"None"}})),toArbitrary:([Q])=>(_,G)=>{let J=_.constant(f()),Z=_.oneof(J,Q.arbitrary.map(T));return b9(_,G,J,Z)},toEquivalence:([Q])=>eD(Q),toFormatter:([Q])=>kX({onNone:()=>"none()",onSome:(_)=>`some(${Q(_)})`})});return x(Y.ast,{value:X})}var _00=YX("effect/schema/Option",L0,({annotations:X,typeParameters:Y})=>{let Q=J4(Y[0]);return X===void 0?Q:Q.annotate(X)});function G00(X){return SW(X).pipe(l(J4(p1(X)),lL()))}function J00(X){return pG(X).pipe(l(J4(p1(X)),oL()))}function $00(X,Y){return iw(X).pipe(l(J4(p1(X)),rL(Y)))}function Z00(X){return _4(X).pipe(l(J4(p1(X)),iL()))}function K00(X){return IX(X).pipe(l(J4(p1(X)),nL()))}function H00(X,Y){let Q=Y===void 0?"omit":Y.onNoneEncoding,_=Q===null?null:void 0;return IX(SW(X)).pipe(l(J4(p1(X)),A3({decode:(G)=>G.pipe(j5(T_),T),encode:Q==="omit"?I5:(G)=>T(u_(I5(G),()=>_))})))}function pC(X,Y){let Q=VX()([X,Y],([_,G])=>(J,Z,K)=>{if(!a_(J))return d(new l0(Z,T(J)));switch(J._tag){case"Success":return U1(dK(_)(J.success,K),{onSuccess:m,onFailure:(H)=>new T0(Z,T(J),[new M0(["success"],H)])});case"Failure":return U1(dK(G)(J.failure,K),{onSuccess:c,onFailure:(H)=>new T0(Z,T(J),[new M0(["failure"],H)])})}},{representation:{id:"effect/schema/Result",payload:null},toCode:({typeParameters:_})=>({runtime:`Schema.Result(${_[0].runtime}, ${_[1].runtime})`,Type:`Result.Result<${_[0].Type}, ${_[1].Type}>`,importDeclarations:['import * as Result from "effect/Result"']}),expected:"Result",toCodec:([_,G])=>I0()(X1([h({_tag:d0("Success"),success:_}),h({_tag:d0("Failure"),failure:G})]),y0({decode:(J)=>J._tag==="Success"?m(J.success):c(J.failure),encode:(J)=>t0(J)?{_tag:"Success",success:J.success}:{_tag:"Failure",failure:J.failure}})),toArbitrary:([_,G])=>(J,Z)=>{let K=eC(J,_.terminal?.map((W)=>m(W)),G.terminal?.map((W)=>c(W))),H=J.oneof(_.arbitrary.map((W)=>m(W)),G.arbitrary.map((W)=>c(W)));return b9(J,Z,K,H)},toEquivalence:([_,G])=>K$(_,G),toFormatter:([_,G])=>o1({onSuccess:(J)=>`success(${_(J)})`,onFailure:(J)=>`failure(${G(J)})`})});return x(Q.ast,{success:X,failure:Y})}var W00=YX("effect/schema/Result",L0,({annotations:X,typeParameters:Y})=>{let Q=pC(Y[0],Y[1]);return X===void 0?Q:Q.annotate(X)}),U00=jX((X)=>{if(!j1(X))return!1;let Y=globalThis.Object.keys(X);return Y.length>0&&Y.every((Q)=>{switch(Q){case"label":return typeof X[Q]==="string";case"disallowJsonEncode":return X[Q]===!0;default:return!1}})}),D00=X1([L0,U00]);function pW(X,Y){let Q=typeof Y?.label==="string"?Y.label:void 0,_=Y?.disallowJsonEncode===!0,G=Q!==void 0?_?{label:Q,disallowJsonEncode:!0}:{label:Q}:_?{disallowJsonEncode:!0}:void 0,J=Q!==void 0?i0(d0(Q)):void 0,Z=VX()([X],([K])=>(H,W,D)=>{if(r2(H)){let U=J!==void 0?X9(J(H.label,D),(N)=>new M0(["label"],N)):yY;return EX(U,()=>U1(i0(K)(J9(H),D),{onSuccess:()=>H,onFailure:()=>{let N=T(H);return new T0(W,N,[new M0(["value"],new W0(N))])}}))}return d(new l0(W,T(H)))},{representation:{id:"effect/schema/Redacted",payload:G??null},toCode:({typeParameters:K})=>({runtime:G!==void 0?`Schema.Redacted(${K[0].runtime}, ${A(G)})`:`Schema.Redacted(${K[0].runtime})`,Type:`Redacted.Redacted<${K[0].Type}>`,importDeclarations:['import * as Redacted from "effect/Redacted"']}),expected:"Redacted",toCodecJson:([K])=>I0()(uW(K),{decode:Y0((H)=>T6(H,{label:Q})),encode:_?e2((H)=>"Cannot serialize Redacted"+(W1(H)&&typeof H.value.label==="string"?` with label: "${H.value.label}"`:"")):Y0(J9)}),toArbitrary:([K])=>()=>({arbitrary:K.arbitrary.map((H)=>T6(H,{label:Q})),terminal:K.terminal?.map((H)=>T6(H,{label:Q}))}),toFormatter:()=>globalThis.String,toEquivalence:([K])=>JL(K)});return x(Z.ast,{value:X})}var N00=YX("effect/schema/Redacted",D00,({annotations:X,payload:Y,typeParameters:Q})=>{let _=pW(Q[0],Y??void 0);return X===void 0?_:_.annotate(X)});function uW(X){return vW(X9(B3))(X)}function B00(X,Y){return uW(X).pipe(l(pW(p1(X),{label:Y?.label,disallowJsonEncode:Y?.disallowEncode}),{decode:Y0((Q)=>T6(Q,{label:Y?.label})),encode:Y?.disallowEncode?e2((Q)=>"Cannot encode Redacted"+(W1(Q)&&typeof Q.value.label==="string"?` with label: "${Q.value.label}"`:"")):Y0(J9)}))}function kG(X,Y){let Q=VX()([X,Y],([_,G])=>(J,Z,K)=>{if(!jq(J))return d(new l0(Z,T(J)));switch(J._tag){case"Fail":return U1(i0(_)(J.error,K),{onSuccess:h7,onFailure:(H)=>new T0(Z,T(J),[new M0(["error"],H)])});case"Die":return U1(i0(G)(J.defect,K),{onSuccess:m7,onFailure:(H)=>new T0(Z,T(J),[new M0(["defect"],H)])});case"Interrupt":return p(J)}},{representation:{id:"effect/schema/CauseReason",payload:null},toCode:({typeParameters:_})=>({runtime:`Schema.CauseReason(${_[0].runtime}, ${_[1].runtime})`,Type:`Cause.Failure<${_[0].Type}, ${_[1].Type}>`,importDeclarations:['import * as Cause from "effect/Cause"']}),expected:"Cause.Failure",toCodec:([_,G])=>I0()(X1([h({_tag:d0("Fail"),error:_}),h({_tag:d0("Die"),defect:G}),h({_tag:d0("Interrupt"),fiberId:pG(eX)})]),y0({decode:(J)=>{switch(J._tag){case"Fail":return h7(J.error);case"Die":return m7(J.defect);case"Interrupt":return d7(J.fiberId)}},encode:u})),toArbitrary:([_,G])=>uC(_,G),toEquivalence:([_,G])=>cC(_,G),toFormatter:([_,G])=>lC(_,G)});return x(Q.ast,{error:X,defect:Y})}var V00=YX("effect/schema/CauseReason",L0,({annotations:X,typeParameters:Y})=>{let Q=kG(Y[0],Y[1]);return X===void 0?Q:Q.annotate(X)});function uC(X,Y){return(Q,_)=>{let G=Q.constant(d7()),J=Q.oneof(G,Q.integer({min:1}).map(d7),X.arbitrary.map((Z)=>h7(Z)),Y.arbitrary.map((Z)=>m7(Z)));return b9(Q,_,G,J)}}function cC(X,Y){return(Q,_)=>{if(Q._tag!==_._tag)return!1;switch(Q._tag){case"Fail":return X(Q.error,_.error);case"Die":return Y(Q.defect,_.defect);case"Interrupt":return Q.fiberId===_.fiberId}}}function lC(X,Y){return(Q)=>{switch(Q._tag){case"Fail":return`Fail(${X(Q.error)})`;case"Die":return`Die(${Y(Q.defect)})`;case"Interrupt":return"Interrupt"}}}function bG(X,Y){let Q=VX()([X,Y],([_,G])=>{let J=e0(kG(_,G));return(Z,K,H)=>{if(!Iq(Z))return d(new l0(K,T(Z)));return U1(i0(J)(Z.reasons,H),{onSuccess:y7,onFailure:(W)=>new T0(K,T(Z),[new M0(["failures"],W)])})}},{representation:{id:"effect/schema/Cause",payload:null},toCode:({typeParameters:_})=>({runtime:`Schema.Cause(${_[0].runtime}, ${_[1].runtime})`,Type:`Cause.Cause<${_[0].Type}, ${_[1].Type}>`,importDeclarations:['import * as Cause from "effect/Cause"']}),expected:"Cause",toCodec:([_,G])=>I0()(e0(kG(_,G)),y0({decode:y7,encode:({reasons:J})=>J})),toArbitrary:([_,G])=>oC(_,G),toEquivalence:([_,G])=>rC(_,G),toFormatter:([_,G])=>iC(_,G)});return x(Q.ast,{error:X,defect:Y})}var q00=YX("effect/schema/Cause",L0,({annotations:X,typeParameters:Y})=>{let Q=bG(Y[0],Y[1]);return X===void 0?Q:Q.annotate(X)});function oC(X,Y){return(Q,_)=>{let G=uC(X,Y)(Q,_),J=Q.constant(Sq),Z=Q.array(G.arbitrary).map(y7);return b9(Q,_,J,Z)}}function rC(X,Y){let Q=fD(cC(X,Y));return(_,G)=>Q(_.reasons,G.reasons)}function iC(X,Y){let Q=lC(X,Y);return(_)=>`Cause([${_.reasons.map(Q).join(", ")}])`}var z00=jX((X)=>{if(!j1(X))return!1;let Y=globalThis.Object.keys(X);return Y.length>0&&Y.every((Q)=>(Q==="includeStack"||Q==="excludeCause")&&X[Q]===!0)}),O00=X1([L0,z00]),nC=(X)=>(X?.includeStack===!0?1:0)|(X?.excludeCause===!0?2:0),sC=(X)=>{switch(X){case 0:return;case 1:return{includeStack:!0};case 2:return{excludeCause:!0};case 3:return{includeStack:!0,excludeCause:!0}}},Ew=[];function aC(X){let Y=nC(X),Q=Ew[Y];if(Q!==void 0)return Q;let _=sC(Y),G=G4(globalThis.Error,{representation:{id:"effect/schema/Error",payload:_??null},toCode:()=>({runtime:_!==void 0?`Schema.Error(${A(_)})`:"Schema.Error()",Type:"globalThis.Error"}),expected:"Error",toCodecJson:()=>I0()(HX0,uL(_)),toArbitrary:()=>(J)=>J.string().map((Z)=>new globalThis.Error(Z))});return Ew[Y]=G,G}var L00=YX("effect/schema/Error",O00,({annotations:X,payload:Y})=>{let Q=aC(Y??void 0);return X===void 0?Q:Q.annotate(X)}),Aw=[];function T00(X){let Y=nC(X),Q=Aw[Y];if(Q!==void 0)return Q;let _=rG.pipe(l(MW,cL(sC(Y))));return Aw[Y]=_,_}function tC(X,Y,Q){let _=VX()([X,Y,Q],([G,J,Z])=>{let K=bG(J,Z);return(H,W,D)=>{if(!Gq(H))return d(new l0(W,T(H)));switch(H._tag){case"Success":return U1(i0(G)(H.value,D),{onSuccess:l5,onFailure:(U)=>new T0(W,T(H),[new M0(["value"],U)])});case"Failure":return U1(i0(K)(H.cause,D),{onSuccess:v8,onFailure:(U)=>new T0(W,T(H),[new M0(["cause"],U)])})}}},{representation:{id:"effect/schema/Exit",payload:null},toCode:({typeParameters:G})=>({runtime:`Schema.Exit(${G[0].runtime}, ${G[1].runtime}, ${G[2].runtime})`,Type:`Exit.Exit<${G[0].Type}, ${G[1].Type}, ${G[2].Type}>`,importDeclarations:['import * as Exit from "effect/Exit"']}),expected:"Exit",toCodec:([G,J,Z])=>I0()(X1([h({_tag:d0("Success"),value:G}),h({_tag:d0("Failure"),cause:bG(J,Z)})]),y0({decode:(K)=>K._tag==="Success"?l5(K.value):v8(K.cause),encode:(K)=>w1(K)?{_tag:"Success",value:K.value}:{_tag:"Failure",cause:K.cause}})),toArbitrary:([G,J,Z])=>(K,H)=>{let W=oC(J,Z)(K,H),D=eC(K,G.terminal?.map((N)=>l5(N)),W.terminal?.map((N)=>v8(N))),U=K.oneof(G.arbitrary.map((N)=>l5(N)),W.arbitrary.map((N)=>v8(N)));return b9(K,H,D,U)},toEquivalence:([G,J,Z])=>{let K=rC(J,Z);return(H,W)=>{if(H._tag!==W._tag)return!1;switch(H._tag){case"Success":return G(H.value,W.value);case"Failure":return K(H.cause,W.cause)}}},toFormatter:([G,J,Z])=>{let K=iC(J,Z);return(H)=>{switch(H._tag){case"Success":return`Exit.Success(${G(H.value)})`;case"Failure":return`Exit.Failure(${K(H.cause)})`}}}});return x(_.ast,{value:X,error:Y,defect:Q})}var R00=YX("effect/schema/Exit",L0,({annotations:X,typeParameters:Y})=>{let Q=tC(Y[0],Y[1],Y[2]);return X===void 0?Q:Q.annotate(X)});function eC(X,Y,Q){return Y===void 0?Q:Q===void 0?Y:X.oneof(Y,Q)}function b9(X,Y,Q,_){return{arbitrary:Q===void 0||Y.recursion===void 0?_:X.oneof(Y.recursion,Q,_),terminal:Q}}function Pw(X,Y,Q,_){return _===void 0?X.array(Y,Q):X.uniqueArray(Y,{...Q,comparator:_})}function lG(X,Y,Q,_,G,J){let Z=Y.constraint,K=Z===void 0||Z.minLength===void 0&&Z.maxLength===void 0?void 0:{...Z.minLength!==void 0?{minLength:Z.minLength}:{},...Z.maxLength!==void 0?{maxLength:Z.maxLength}:{}};if(K?.minLength!==void 0&&K.maxLength!==void 0&&K.minLength>K.maxLength)throw new globalThis.Error("Unable to derive an arbitrary for size constraints");let H=K?.minLength??0,W=H===0?X.constant([]):_===void 0?void 0:Pw(X,_,{...K,maxLength:H},J),D=b9(X,Y,W,Pw(X,Q,K,J));return{arbitrary:D.arbitrary.map(G),terminal:D.terminal?.map(G)}}function XM(X,Y,Q,_,G){return lG(X,Y,X.tuple(Q.arbitrary,_.arbitrary),Q.terminal===void 0||_.terminal===void 0?void 0:X.tuple(Q.terminal,_.terminal),G,([J],[Z])=>o(J,Z))}function YM(X,Y){let Q=VX()([X,Y],([_,G])=>{let J=e0(j9([_,G]));return(Z,K,H)=>{if(Z instanceof globalThis.Map)return U1(i0(J)([...Z],H),{onSuccess:(W)=>new globalThis.Map(W),onFailure:(W)=>new T0(K,T(Z),[new M0(["entries"],W)])});return d(new l0(K,T(Z)))}},{representation:{id:"effect/schema/ReadonlyMap",payload:null},toCode:({typeParameters:_})=>({runtime:`Schema.ReadonlyMap(${_[0].runtime}, ${_[1].runtime})`,Type:`globalThis.ReadonlyMap<${_[0].Type}, ${_[1].Type}>`}),expected:"ReadonlyMap",toCodec:([_,G])=>I0()(e0(j9([_,G])),y0({decode:(J)=>new globalThis.Map(J),encode:(J)=>[...J.entries()]})),toArbitrary:([_,G])=>(J,Z)=>XM(J,Z,_,G,(K)=>new globalThis.Map(K)),toEquivalence:([_,G])=>A_(_,G),toFormatter:([_,G])=>(J)=>{let Z=J.size;if(Z===0)return"ReadonlyMap(0) {}";let K=globalThis.Array.from(J.entries()).sort().map(([H,W])=>`${_(H)} => ${G(W)}`);return`ReadonlyMap(${Z}) { ${K.join(", ")} }`}});return x(Q.ast,{key:X,value:Y})}var F00=YX("effect/schema/ReadonlyMap",L0,({annotations:X,typeParameters:Y})=>{let Q=YM(Y[0],Y[1]);return X===void 0?Q:Q.annotate(X)});function QM(X,Y){let Q=VX()([X,Y],([_,G])=>{let J=e0(j9([_,G]));return(Z,K,H)=>{if(T2(Z))return U1(i0(J)(rY(Z),H),{onSuccess:oY,onFailure:(W)=>new T0(K,T(Z),[new M0(["entries"],W)])});return d(new l0(K,T(Z)))}},{representation:{id:"effect/schema/HashMap",payload:null},toCode:({typeParameters:_})=>({runtime:`Schema.HashMap(${_[0].runtime}, ${_[1].runtime})`,Type:`HashMap.HashMap<${_[0].Type}, ${_[1].Type}>`,importDeclarations:['import * as HashMap from "effect/HashMap"']}),expected:"HashMap",toCodec:([_,G])=>I0()(e0(j9([_,G])),y0({decode:oY,encode:rY})),toArbitrary:([_,G])=>(J,Z)=>XM(J,Z,_,G,oY),toEquivalence:([_,G])=>A_(_,G),toFormatter:([_,G])=>(J)=>{let Z=R2(J);if(Z===0)return"HashMap(0) {}";let K=rY(J).sort().map(([H,W])=>`${_(H)} => ${G(W)}`);return`HashMap(${Z}) { ${K.join(", ")} }`}});return x(Q.ast,{key:X,value:Y})}var E00=YX("effect/schema/HashMap",L0,({annotations:X,typeParameters:Y})=>{let Q=QM(Y[0],Y[1]);return X===void 0?Q:Q.annotate(X)});function _M(X){let Y=VX()([X],([Q])=>{let _=e0(Q);return(G,J,Z)=>{if(G instanceof globalThis.Set)return U1(i0(_)([...G],Z),{onSuccess:(K)=>new globalThis.Set(K),onFailure:(K)=>new T0(J,T(G),[new M0(["values"],K)])});return d(new l0(J,T(G)))}},{representation:{id:"effect/schema/ReadonlySet",payload:null},toCode:({typeParameters:Q})=>({runtime:`Schema.ReadonlySet(${Q[0].runtime})`,Type:`globalThis.ReadonlySet<${Q[0].Type}>`}),expected:"ReadonlySet",toCodec:([Q])=>I0()(e0(Q),y0({decode:(_)=>new globalThis.Set(_),encode:(_)=>[..._.values()]})),toArbitrary:([Q])=>(_,G)=>lG(_,G,Q.arbitrary,Q.terminal,(J)=>new globalThis.Set(J),o),toEquivalence:([Q])=>P_(Q),toFormatter:([Q])=>(_)=>{let G=_.size;if(G===0)return"ReadonlySet(0) {}";let J=globalThis.Array.from(_.values()).sort().map((Z)=>`${Q(Z)}`);return`ReadonlySet(${G}) { ${J.join(", ")} }`}});return x(Y.ast,{value:X})}var A00=YX("effect/schema/ReadonlySet",L0,({annotations:X,typeParameters:Y})=>{let Q=_M(Y[0]);return X===void 0?Q:Q.annotate(X)});function GM(X){let Y=VX()([X],([Q])=>{let _=e0(Q);return(G,J,Z)=>{if(P2(G))return U1(i0(_)(A1(G),Z),{onSuccess:sY,onFailure:(K)=>new T0(J,T(G),[new M0(["values"],K)])});return d(new l0(J,T(G)))}},{representation:{id:"effect/schema/HashSet",payload:null},toCode:({typeParameters:Q})=>({runtime:`Schema.HashSet(${Q[0].runtime})`,Type:`HashSet.HashSet<${Q[0].Type}>`}),expected:"HashSet",toCodec:([Q])=>I0()(e0(Q),y0({decode:sY,encode:A1})),toArbitrary:([Q])=>(_,G)=>lG(_,G,Q.arbitrary,Q.terminal,sY,o),toEquivalence:([Q])=>P_(Q),toFormatter:([Q])=>(_)=>{let G=w2(_);if(G===0)return"HashSet(0) {}";let J=globalThis.Array.from(_).sort().map((Z)=>`${Q(Z)}`);return`HashSet(${G}) { ${J.join(", ")} }`}});return x(Y.ast,{value:X})}var P00=YX("effect/schema/HashSet",L0,({annotations:X,typeParameters:Y})=>{let Q=GM(Y[0]);return X===void 0?Q:Q.annotate(X)});function JM(X){let Y=VX()([X],([Q])=>{let _=e0(Q);return(G,J,Z)=>{if(G3(G))return U1(i0(_)(A1(G),Z),{onSuccess:J3,onFailure:(K)=>new T0(J,T(G),[new M0(["values"],K)])});return d(new l0(J,T(G)))}},{representation:{id:"effect/schema/Chunk",payload:null},toCode:({typeParameters:Q})=>({runtime:`Schema.Chunk(${Q[0].runtime})`,Type:`Chunk.Chunk<${Q[0].Type}>`}),expected:"Chunk",toCodec:([Q])=>I0()(e0(Q),y0({decode:J3,encode:A1})),toArbitrary:([Q])=>(_,G)=>lG(_,G,Q.arbitrary,Q.terminal,J3),toEquivalence:([Q])=>k2(Q),toFormatter:([Q])=>(_)=>{let G=IO(_);if(G===0)return"Chunk(0) {}";let J=globalThis.Array.from(_).sort().map((Z)=>`${Q(Z)}`);return`Chunk(${G}) { ${J.join(", ")} }`}});return x(Y.ast,{value:X})}var w00=YX("effect/schema/Chunk",L0,({annotations:X,typeParameters:Y})=>{let Q=JM(Y[0]);return X===void 0?Q:Q.annotate(X)}),$M=G4(globalThis.RegExp,{representation:{id:"effect/schema/RegExp",payload:null},toCode:()=>({runtime:"Schema.RegExp",Type:"globalThis.RegExp"}),expected:"RegExp",toCodecJson:()=>I0()(h({source:i,flags:i}),PX({decode:(X)=>e5({try:()=>new globalThis.RegExp(X.source,X.flags),catch:(Y)=>new W0(T(Y),{message:globalThis.String(Y)})}),encode:(X)=>p({source:X.source,flags:X.flags})})),toArbitrary:()=>(X)=>X.tuple(X.constantFrom(".",".*","\\d+","\\w+","[a-z]+","[A-Z]+","[0-9]+","^[a-zA-Z0-9]+$","^\\d{4}-\\d{2}-\\d{2}$"),X.uniqueArray(X.constantFrom("g","i","m","s","u","y"),{minLength:0,maxLength:6}).map((Y)=>Y.join(""))).map(([Y,Q])=>new globalThis.RegExp(Y,Q)),toEquivalence:()=>(X,Y)=>X.source===Y.source&&X.flags===Y.flags}),C00=M1("effect/schema/RegExp",$M),ZM=i.annotate({expected:"a string that will be decoded as a URL"}),cW=G4(globalThis.URL,{representation:{id:"effect/schema/URL",payload:null},toCode:()=>({runtime:"Schema.URL",Type:"globalThis.URL"}),expected:"URL",toCodecJson:()=>I0()(ZM,ZK),toArbitrary:()=>(X)=>X.webUrl().map((Y)=>new globalThis.URL(Y)),toEquivalence:()=>(X,Y)=>X.toString()===Y.toString()}),M00=M1("effect/schema/URL",cW),I00=ZM.pipe(l(cW,ZK));function lW(X,Y,Q){let _={...Y};if(X?.minimum!==void 0){let G=Q===void 0?X.minimum:Q(X.minimum),J=X.exclusiveMinimum?new globalThis.Date(G.getTime()+1):G;if(_.min===void 0||J.getTime()>_.min.getTime())_.min=J}if(X?.maximum!==void 0){let G=Q===void 0?X.maximum:Q(X.maximum),J=X.exclusiveMaximum?new globalThis.Date(G.getTime()-1):G;if(_.max===void 0||J.getTime()<_.max.getTime())_.max=J}return _}var KM=i.annotate({expected:"a string that will be decoded as a Date"}),X6=jX((X)=>X instanceof globalThis.Date&&!globalThis.Number.isNaN(X.getTime()),{representation:{id:"effect/schema/Date",payload:null},toCode:()=>({runtime:"Schema.Date",Type:"globalThis.Date"}),expected:"a valid Date",toCodecJson:()=>I0()(KM,$K),toArbitrary:()=>(X,Y)=>X.date(lW(Y?.constraint?.ordered?.order===R4?Y.constraint.ordered:void 0,{noInvalidDate:!0}))}),j00=M1("effect/schema/Date",X6),S00=KM.pipe(l(X6,$K)),v00=D5.pipe(l(X6,gL)),sQ=jX(G$,{representation:{id:"effect/schema/Duration",payload:null},toCode:()=>({runtime:"Schema.Duration",Type:"Duration.Duration",importDeclarations:['import * as Duration from "effect/Duration"']}),expected:"Duration",toCodecJson:()=>I0()(X1([h({_tag:d0("Infinity")}),h({_tag:d0("NegativeInfinity")}),h({_tag:d0("Nanos"),value:P6}),h({_tag:d0("Millis"),value:D5})]),y0({decode:(X)=>{switch(X._tag){case"Infinity":return p6;case"NegativeInfinity":return P4;case"Nanos":return H6(X.value);case"Millis":return E8(X.value)}},encode:(X)=>{switch(X.value._tag){case"Infinity":return{_tag:"Infinity"};case"NegativeInfinity":return{_tag:"NegativeInfinity"};case"Nanos":return{_tag:"Nanos",value:X.value.nanos};case"Millis":return{_tag:"Millis",value:X.value.millis}}}})),toArbitrary:()=>(X)=>X.oneof(X.constant(p6),X.constant(P4),X.bigInt().map(H6),X.maxSafeInteger().map(E8)),toFormatter:()=>globalThis.String,toEquivalence:()=>J$}),x00=M1("effect/schema/Duration",sQ),k00=i.annotate({expected:"a string that will be decoded as a Duration"}),b00=k00.pipe(l(sQ,yL)),g00=P6.pipe(l(sQ,hL)),y00=dG.pipe(l(sQ,mL)),HM=i.annotate({expected:"a string that will be decoded as a BigDecimal"}),WM=20,UM="Unable to derive an arbitrary for the ordered BigDecimal constraints";function gG(X,Y){return h8(X,Y).value}function h00(X,Y,Q){return Q?gG(v2(X,Y),Y)+globalThis.BigInt(1):gG(S2(X,Y),Y)}function m00(X,Y,Q){return Q?gG(S2(X,Y),Y)-globalThis.BigInt(1):gG(v2(X,Y),Y)}function d00(X){return Math.max(WM,X.minimum?.scale??0,X.maximum?.scale??0,X.exclusiveMinimum&&X.minimum!==void 0?X.minimum.scale+1:0,X.exclusiveMaximum&&X.maximum!==void 0?X.maximum.scale+1:0)}function wW(X,Y){let Q={};if(X.minimum!==void 0)Q.min=h00(X.minimum,Y,X.exclusiveMinimum===!0);if(X.maximum!==void 0)Q.max=m00(X.maximum,Y,X.exclusiveMaximum===!0);if(Q.min!==void 0&&Q.max!==void 0&&Q.min>Q.max)return;return Q}function f00(X){let Y=d00(X);if(wW(X,Y)===void 0)throw new globalThis.Error(UM);let Q=0,_=Y;while(Q<_){let G=Q+Math.floor((_-Q)/2);if(wW(X,G)===void 0)Q=G+1;else _=G}return{min:Q,max:Y}}var oW=jX(_3,{representation:{id:"effect/schema/BigDecimal",payload:null},toCode:()=>({runtime:"Schema.BigDecimal",Type:"BigDecimal.BigDecimal",importDeclarations:['import * as BigDecimal from "effect/BigDecimal"']}),expected:"BigDecimal",toCodecJson:()=>I0()(HM,KK),toArbitrary:()=>(X,Y)=>{let Q=Y.constraint?.ordered?.order===e6?Y.constraint.ordered:void 0;if(Q===void 0)return X.tuple(X.bigInt(),X.integer({min:0,max:WM})).map(([_,G])=>a1(_,G));return X.integer(f00(Q)).chain((_)=>{let G=wW(Q,_);if(G===void 0)throw new globalThis.Error(UM);return X.bigInt(G).map((J)=>a1(J,_))})},toFormatter:()=>(X)=>L6(X),toEquivalence:()=>I2}),p00=M1("effect/schema/BigDecimal",oW),u00=HM.pipe(l(oW,KK)),c00=i.annotate({expected:"a string that will be decoded as JSON",contentMediaType:"application/json"}),l00=DM(MW);function DM(X){return c00.pipe(l(X,XT))}var rW=G4(globalThis.File,{representation:{id:"effect/schema/File",payload:null},toCode:()=>({runtime:"Schema.File",Type:"globalThis.File"}),expected:"File",toCodecJson:()=>I0()(h({data:i.check(yW()),type:i,name:i,lastModified:D5}),PX({decode:(X)=>o1(G9(X.data),{onFailure:(Y)=>d(new W0(T(X.data),{message:Y.message})),onSuccess:(Y)=>{let Q=new globalThis.Uint8Array(Y);return p(new globalThis.File([Q],X.name,{type:X.type,lastModified:X.lastModified}))}}),encode:(X)=>G2({try:async()=>{let Y=new globalThis.Uint8Array(await X.arrayBuffer());return{data:U3(Y),type:X.type,name:X.name,lastModified:X.lastModified}},catch:(Y)=>new W0(T(X),{message:globalThis.String(Y)})})}))}),o00=M1("effect/schema/File",rW),iW=G4(globalThis.FormData,{representation:{id:"effect/schema/FormData",payload:null},toCode:()=>({runtime:"Schema.FormData",Type:"globalThis.FormData"}),expected:"FormData",toCodecJson:()=>I0()(e0(j9([i,X1([h({_tag:W5("String"),value:i}),h({_tag:W5("File"),value:rW})])])),PX({decode:(X)=>{let Y=new globalThis.FormData;for(let[Q,_]of X)Y.append(Q,_.value);return p(Y)},encode:(X)=>{return p(globalThis.Array.from(X.entries()).map(([Y,Q])=>{if(typeof Q==="string")return[Y,{_tag:"String",value:Q}];else return[Y,{_tag:"File",value:Q}]}))}}))}),r00=M1("effect/schema/FormData",iW);function i00(X){return iW.pipe(l(X,YT))}var nW=G4(globalThis.URLSearchParams,{representation:{id:"effect/schema/URLSearchParams",payload:null},toCode:()=>({runtime:"Schema.URLSearchParams",Type:"globalThis.URLSearchParams"}),expected:"URLSearchParams",toCodecJson:()=>I0()(i.annotate({expected:"a query string that will be decoded as URLSearchParams"}),y0({decode:(X)=>new globalThis.URLSearchParams(X),encode:(X)=>X.toString()}))}),n00=M1("effect/schema/URLSearchParams",nW);function s00(X){return nW.pipe(l(X,QT))}var a00=i.annotate({expected:"a string that will be decoded as a number"}).pipe(l(dG,H9)),t00=i.annotate({expected:"a string that will be decoded as a finite number"}).pipe(l(eX,H9)),e00=x(bK).pipe(l(P6,P3)),NM=i.check(gW()),X10=i.annotate({expected:"a string that will be decoded as a trimmed string"}).pipe(l(NM,bL())),Y10=i.annotate({expected:"a base64 encoded string that will be decoded as a UTF-8 string"}).pipe(l(i,sL)),Q10=i.annotate({expected:"a base64 (URL) encoded string that will be decoded as a UTF-8 string"}).pipe(l(i,aL)),_10=i.annotate({expected:"a hex encoded string that will be decoded as a UTF-8 string"}).pipe(l(i,tL)),G10=i.annotate({expected:"a URI component encoded string that will be decoded as a UTF-8 string"}).pipe(l(i,eL)),CW=X1([eX,cw,i]),J10=h({issues:e0(h({message:i,path:IX(e0(X1([CW,h({key:CW})])))}))}),$10=fG([0,1]).pipe(l(uw,y0({decode:(X)=>X===1,encode:(X)=>X?1:0}))),BM=i.annotate({expected:"a base64 encoded string that will be decoded as Uint8Array",format:"byte",contentEncoding:"base64"}),aQ=G4(globalThis.Uint8Array,{representation:{id:"effect/schema/Uint8Array",payload:null},toCode:()=>({runtime:"Schema.Uint8Array",Type:"globalThis.Uint8Array"}),expected:"Uint8Array",toCodecJson:()=>I0()(BM,HK),toArbitrary:()=>(X)=>X.uint8Array()}),Z10=M1("effect/schema/Uint8Array",aQ),K10=BM.pipe(l(aQ,HK)),H10=i.annotate({expected:"a base64 (URL) encoded string that will be decoded as a Uint8Array"}).pipe(l(aQ,{decode:EL(),encode:R3()})),W10=i.annotate({expected:"a hex encoded string that will be decoded as a Uint8Array"}).pipe(l(aQ,{decode:PL(),encode:F3()})),tQ=jX((X)=>g2(X)&&xO(X),{representation:{id:"effect/schema/DateTimeUtc",payload:null},toCode:()=>({runtime:"Schema.DateTimeUtc",Type:"DateTime.Utc",importDeclarations:['import * as DateTime from "effect/DateTime"']}),expected:"DateTime.Utc",toCodecJson:()=>I0()(i,DK),toArbitrary:()=>(X,Y)=>X.date(lW(Y?.constraint?.ordered?.order===h2?Y.constraint.ordered:void 0,{noInvalidDate:!0},K3)).map((Q)=>bO(Q)),toFormatter:()=>(X)=>X.toString(),toEquivalence:()=>y2}),U10=M1("effect/schema/DateTimeUtc",tQ),D10=X6.pipe(l(tQ,{decode:GK(),encode:Y0(K3)})),N10=i.annotate({expected:"a string that will be decoded as a DateTime.Utc"}).pipe(l(tQ,DK)),B10=D5.pipe(l(tQ,{decode:GK(),encode:Y0(dO)})),VM=jX(SO,{representation:{id:"effect/schema/TimeZoneOffset",payload:null},toCode:()=>({runtime:"Schema.TimeZoneOffset",Type:"DateTime.TimeZone.Offset",importDeclarations:['import * as DateTime from "effect/DateTime"']}),expected:"DateTime.TimeZone.Offset",toCodecJson:()=>I0()(D5,_T),toArbitrary:()=>(X)=>X.integer({min:-43200000,max:50400000}).map((Y)=>eY(Y)),toFormatter:()=>(X)=>m8(X),toEquivalence:()=>(X,Y)=>X.offset===Y.offset}),V10=M1("effect/schema/TimeZoneOffset",VM),qM=i.annotate({expected:"an IANA time zone identifier"}),sW=jX(vO,{representation:{id:"effect/schema/TimeZoneNamed",payload:null},toCode:()=>({runtime:"Schema.TimeZoneNamed",Type:"DateTime.TimeZone.Named",importDeclarations:['import * as DateTime from "effect/DateTime"']}),expected:"DateTime.TimeZone.Named",toCodecJson:()=>I0()(qM,WK),toArbitrary:()=>(X)=>X.constantFrom(...["UTC","Europe/London","America/New_York","Asia/Tokyo","Australia/Sydney"].map(m2)),toFormatter:()=>(X)=>m8(X),toEquivalence:()=>(X,Y)=>X.id===Y.id}),q10=M1("effect/schema/TimeZoneNamed",sW),z10=qM.pipe(l(sW,WK)),zM=i.annotate({expected:"a time zone string (IANA identifier or offset like +03:00)"}),aW=jX(jO,{representation:{id:"effect/schema/TimeZone",payload:null},toCode:()=>({runtime:"Schema.TimeZone",Type:"DateTime.TimeZone",importDeclarations:['import * as DateTime from "effect/DateTime"']}),expected:"DateTime.TimeZone",toCodecJson:()=>I0()(zM,UK),toArbitrary:()=>(X)=>X.oneof(X.integer({min:-43200000,max:50400000}).map((Y)=>eY(Y)),X.constantFrom(...["UTC","Europe/London","America/New_York","Asia/Tokyo","Australia/Sydney"].map(m2))),toFormatter:()=>(X)=>m8(X),toEquivalence:()=>(X,Y)=>m8(X)===m8(Y)}),O10=M1("effect/schema/TimeZone",aW),L10=zM.pipe(l(aW,UK)),OM=i.annotate({expected:"a zoned DateTime string (e.g. 2024-01-01T00:00:00.000+00:00[Europe/London])"}),tW=jX((X)=>g2(X)&&kO(X),{representation:{id:"effect/schema/DateTimeZoned",payload:null},toCode:()=>({runtime:"Schema.DateTimeZoned",Type:"DateTime.Zoned",importDeclarations:['import * as DateTime from "effect/DateTime"']}),expected:"DateTime.Zoned",toCodecJson:()=>I0()(OM,NK),toArbitrary:()=>(X,Y)=>X.tuple(X.date(lW(Y?.constraint?.ordered?.order===h2?Y.constraint.ordered:void 0,{max:new globalThis.Date(8639999949600000),min:new globalThis.Date(-8639999949600000),noInvalidDate:!0},K3)),X.constantFrom("UTC","Europe/London","America/New_York","Asia/Tokyo","Australia/Sydney")).map(([Q,_])=>gO(Q,{timeZone:_})),toFormatter:()=>(X)=>H3(X),toEquivalence:()=>y2}),T10=M1("effect/schema/DateTimeZoned",tW),R10=OM.pipe(l(tW,NK)),F10=globalThis.Symbol.for("immer-draftable"),ww={};function eW(X,Y,Q,_,G){let J=A10(Q,Y,_),Z=LM(Y),K=class extends X{constructor(...[H,W]){let U=W?.["~payload"],N=U?.token===ww?U.value:Q.make(H??{},W);super(N,{...W,disableChecks:!0,"~payload":{token:ww,value:N}})}static[pQ]=pQ;get[Z](){return Z}static[F10]=!0;static identifier=Y;static fields=Q.fields;static get ast(){return J(this).ast}static pipe(){return G0(this,arguments)}static rebuild(H){return J(this).rebuild(H)}static make(H,W){return new this(H,W)}static makeOption(H,W){return r3(J(this))(H??{},W)}static makeEffect(H,W){return J(this).makeEffect(H??{},W)}static annotate(H){return this.rebuild(R6(this.ast,H))}static annotateKey(H){return this.rebuild(LQ(this.ast,H))}static check(...H){return this.rebuild(lX(this.ast,H))}static extend(H){return(W,D)=>{let U=eQ(W)?W:h(W),N={...Q.fields,...U.fields},B=x3(N,Q.ast.checks,{identifier:H});return eW(this,H,jW(lX(B,U.ast.checks),N),D,G)}}static mapFields(H,W){return Q.mapFields(H,W)}};if(G!==void 0)Object.assign(K.prototype,G(Y));return K}function E10(X){return new V0(Y0((Y)=>new X(Y)),fX())}function LM(X){return`~effect/Schema/Class/${X}`}function A10(X,Y,Q){let _;return(G)=>{if(_!==void 0)return _;let J=E10(G),Z=x(new Y5([X.ast],()=>(K,H)=>{return K instanceof G||I(K,LM(Y))?p(K):d(new l0(H,T(K)))},{identifier:Y,[c3]:([K])=>new h0(K,J),toCodec:([K])=>new h0(K.ast,J),toArbitrary:([K])=>()=>({arbitrary:K.arbitrary.map((H)=>new G(H)),terminal:K.terminal?.map((H)=>new G(H))}),toFormatter:([K])=>(H)=>`${G.identifier}(${K(H)})`,[QQ]:BQ(X.ast),...Q}));return _=l(Z,J)(X)}}function eQ(X){return mG(X)}var TM=(X)=>(Y,Q)=>{let _=eQ(Y)?Y:h(Y);return eW(i_,X,_,Q,(G)=>({toString(){return`${G}(${A({...this})})`}}))},P10=(X)=>{return(Y,Q,_)=>{let G=eQ(Q)?Q.mapFields((J)=>({_tag:W5(Y),...J}),{unsafePreserveChecks:!0}):uG(Y,Q);return TM(X??Y)(G,_)}},RM=(X)=>(Y,Q)=>{let _=eQ(Y)?Y:h(Y);return eW(YY,X,_,Q,(J)=>({name:J}))},w10=(X)=>{return(Y,Q,_)=>{let G=eQ(Q)?Q.mapFields((J)=>({_tag:W5(Y),...J}),{unsafePreserveChecks:!0}):uG(Y,Q);return RM(X??Y)(G,_)}};function FM(X){let Y=sK(X.ast);return(Q)=>Y(Q,{})}function C10(X,Y){if(Y?.report===!0){let Q=sK(X.ast),_=kR();return mR(X.ast,_),{value:Q(xG,{}),report:bR(_)}}return FM(X)(xG)}function M10(X){return(Y)=>{return Y.annotate({toFormatter:X})}}function I10(X,Y){return Q(X.ast);function Q(G){let J=Q8(G)?.toFormatter;if(typeof J==="function")return J(e4(G)?G.typeParameters.map(Q):[]);if(Y?.onBefore){let Z=Y.onBefore(G,Q);if(Z!==void 0)return Z}return _(G)}function _(G){switch(G._tag){default:return A;case"Never":return()=>"never";case"Void":return()=>"void";case"Arrays":{let J=G.elements.map(Q),Z=G.rest.map(Q);return(K)=>{let H=[],W=0;for(;W<J.length;W++)if(K.length<W+1){if(p0(G.elements[W]))continue}else H.push(J[W](K[W]));if(Z.length>0){let[D,...U]=Z;for(;W<K.length-U.length;W++)H.push(D(K[W]));for(let N=0;N<U.length;N++)H.push(U[N](K[W+N]))}return"["+H.join(", ")+"]"}}case"Objects":{let J=G.propertySignatures.map((K)=>Q(K.type)),Z=G.indexSignatures.map((K)=>Q(K.type));if(G.propertySignatures.length===0&&G.indexSignatures.length===0)return A;return(K)=>{let H=[],W=new Set;for(let D=0;D<J.length;D++){let U=G.propertySignatures[D],N=U.name;if(W.add(N),p0(U.type)&&!Object.hasOwn(K,N))continue;H.push(`${x6(N)}: ${J[D](K[N])}`)}for(let D=0;D<Z.length;D++){let U=D9(K,G.indexSignatures[D].parameter);for(let N of U){if(W.has(N))continue;W.add(N),H.push(`${x6(N)}: ${Z[D](K[N])}`)}}return H.length>0?"{ "+H.join(", ")+" }":"{}"}}case"Union":{let J=O1(G).types,Z=(H)=>VQ(H,J),K=new Map(J.map((H,W)=>[H,[EQ(H),Q(G.types[W])]]));return(H)=>{let W=Z(H);for(let D=0;D<W.length;D++){let[U,N]=K.get(W[D]);if(U(H))return N(H)}return A(H)}}case"Suspend":{let J=Q5(()=>Q(G.thunk()));return(Z)=>J()(Z)}}}}function j10(X){return(Y)=>Y.annotate({toEquivalence:X})}function S10(X){return dR(X.ast)}function v10(X){return aK(X.ast)}function EM(X,Y){let Q=aK(oG(X.ast));return lR(Q,Y)}function AM(X){return x(oG(X.ast),{schema:X})}var x10=o8((X)=>{let Y=b10(X,oG),Q=X.context;if(Y===X||Q===void 0)return Y;return m3(Y,XU(Q))}),oG=a0((X)=>{let Y=f8(X),Q=x10(X);if(Y===void 0||Q.encoding===void 0)return Q;let _=c8(Q);if(f8(_)!==void 0||D3(_)===Y)return Q;let G=R6(_,{[YQ]:Y});return o8(()=>G)(Q)});function XU(X){return X.defaultValue===void 0?X:new uX(X.isOptional,X.isMutable,void 0,X.annotations)}function PM(X){if(X.propertySignatures.some((Y)=>typeof Y.name!=="string"))throw new globalThis.Error("Objects property names must be strings",{cause:X})}function wM(X){return(Y)=>{let Q=new Map;for(let J=0;J<Y.length;J++)Q.set(L1(Y[J]),J);let _=[...Y].sort((J,Z)=>{J=L1(J),Z=L1(Z);let K=X(J),H=X(Z);if(K!==H)return K-H;return Q.get(J)-Q.get(Z)});if(!_.some((J,Z)=>J!==Y[Z]))return Y;return _}}var k10=wM((X)=>{switch(X._tag){case"BigInt":case"Symbol":case"UniqueSymbol":return 0;default:return 1}});function b10(X,Y){switch(X._tag){case"Declaration":{let Q=X.annotations?.toCodecJson??X.annotations?.toCodec;if(!u1(Q))return R0(X,[yK]);let _=X.typeParameters.map((J)=>AQ(L1(J))),G=Q(_);return G===void 0?X:R0(X,[l8(G,Y)])}case"Unknown":return R0(X,[yK]);case"ObjectKeyword":return R0(X,[YR]);case"Undefined":case"Void":case"Literal":case"Number":return X.toCodecJson();case"UniqueSymbol":case"Symbol":case"BigInt":return X.toCodecStringTree();case"Objects":return PM(X),X.recur(Y,u3);case"Union":{let Q=k10(X.types);if(Q!==X.types)return new XX(Q,X.mode,X.annotations,X.checks,X.encoding,X.context,X.encodingChecks).recur(Y);return X.recur(Y)}case"Arrays":case"Suspend":return X.recur(Y)}return X}function CM(X){return x(MM(O1(X.ast)))}var MM=a0((X)=>{let Y=g10(X,MM);return Y!==X&&X.context!==void 0?m3(Y,XU(X.context)):Y});function g10(X,Y){switch(X._tag){case"Declaration":{let Q=X.annotations?.toCodecIso??X.annotations?.toCodec;if(u1(Q)){let _=Q(X.typeParameters.map((G)=>AQ(G)));return R0(X,[l8(_,Y)])}return X}case"Arrays":case"Objects":case"Union":case"Suspend":return X.recur(Y)}return X}function IM(X){return x(vM(X.ast),{schema:X})}function y10(X){return x(xM(X.ast))}function h10(X,Y){let Q=f8(X.ast)??o2(X.ast),_=yw(IM(X));return(G)=>_(G).pipe(Z2((J)=>m10(J,{rootName:Q,...Y})))}function m10(X,Y){let Q=Y.rootName??"root",_=Y.arrayItemName??"item",G=Y.pretty??!0,J=Y.indent??"  ",Z=Y.sortKeys??!0,K=new Set,H=[];return D(Q,X,0),H.join(G?`
`:"");function W(U,N){H.push(G?J.repeat(U)+N:N)}function D(U,N,B,q){let{attrs:O,safe:R}=I9.tagInfo(U,q);if(N===void 0)W(B,`<${R}${O}/>`);else if(typeof N==="string")W(B,`<${R}${O}>${I9.escapeText(N)}</${R}>`);else if(typeof N!=="object"||N===null)W(B,`<${R}${O}>${I9.escapeText(A(N))}</${R}>`);else{if(K.has(N))throw new globalThis.Error("Cycle detected while serializing to XML.",{cause:N});K.add(N);try{if(globalThis.globalThis.Array.isArray(N)){if(N.length===0){W(B,`<${R}${O}/>`);return}W(B,`<${R}${O}>`);for(let C of N)D(_,C,B+1);W(B,`</${R}>`);return}let F=N,P=Object.keys(F);if(Z)P.sort();if(P.length===0){W(B,`<${R}${O}/>`);return}W(B,`<${R}${O}>`);for(let C of P)D(I9.parseTagName(C).safe,F[C],B+1,C);W(B,`</${R}>`)}finally{K.delete(N)}}}}var I9={escapeText(X){return X.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")},escapeAttribute(X){return X.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;")},parseTagName(X){let Y=X,Q=X;if(!/^[A-Za-z_]/.test(Q))Q="_"+Q;if(Q=Q.replace(/[^A-Za-z0-9._-]/g,"_"),/^xml/i.test(Q))Q="_"+Q;return{safe:Q,changed:Q!==Y}},tagInfo(X,Y){let{changed:Q,safe:_}=I9.parseTagName(X),J=Q||Y&&Y!==X?` data-name="${I9.escapeAttribute(Y??X)}"`:"";return{safe:_,attrs:J}}},d10=wM((X)=>{switch(X._tag){case"Null":case"Boolean":case"Number":case"BigInt":case"Symbol":case"UniqueSymbol":return 0;default:return 1}});function f10(X,Y,Q){switch(X._tag){case"Declaration":{let _=X.typeParameters.map((W)=>x(Y(L1(W)))),G=X.annotations?.toCodecStringTree;if(u1(G)){let W=G(_);if(W===void 0)return X;return R0(X,[l8(W,Y)])}let J=X.annotations?.toCodecJson,Z=u1(J)?J(_):void 0,K=Z===void 0?X.annotations?.toCodec:void 0,H=Z??(u1(K)?K(_):void 0);return H===void 0?Q(X):R0(X,[l8(H,Y)])}case"Null":return R0(X,[p10]);case"Boolean":return R0(X,[u10]);case"Unknown":case"ObjectKeyword":return R0(X,[hK]);case"Enum":case"Number":case"Literal":case"UniqueSymbol":case"Symbol":case"BigInt":return X.toCodecStringTree();case"Objects":return PM(X),X.recur(Y,u3);case"Union":{let _=d10(X.types);if(_!==X.types)return new XX(_,X.mode,X.annotations,X.checks,X.encoding,X.context,X.encodingChecks).recur(Y);return X.recur(Y)}case"Arrays":case"Suspend":return X.recur(Y)}return X}var p10=new h0(new WX("null"),new V0(Y0(()=>null),Y0(()=>"null"))),u10=new h0(new XX([new WX("true"),new WX("false")],"anyOf"),new V0(Y0((X)=>X==="true"),s4())),jM="~effect/Schema/SERIALIZER_ENSURE_ARRAY",SM=(X)=>DQ(X)&&X.annotations?.[jM]===!0,vM=o8((X)=>{if(SM(X))return X;let Y=f10(X,vM,(Q)=>{throw new globalThis.Error("Missing structural codec for StringTree",{cause:Q})});if(Y!==X&&X.context!==void 0)return m3(Y,XU(X.context));return Y}),Cw=(X)=>p0(X)?TQ(a4):a4,c10=new V0(Y0((X)=>typeof X==="string"?[X]:X),fX()),xM=o8((X)=>{if(SM(X))return X;let Y=l10(X);if(UQ(Y)){let Q=d3(new XX([new cX(Y.isMutable,Y.elements.map(Cw),Y.rest.map(Cw)),u8],"anyOf",{[jM]:!0}),Y,c10);return p0(X)?TQ(Q):Q}return Y});function l10(X){return X._tag==="Declaration"||X._tag==="Arrays"||X._tag==="Objects"||X._tag==="Union"||X._tag==="Suspend"?X.recur(xM):X}var o10=n("effect/schema/isGreaterThanDate",h({exclusiveMinimum:X6}),({annotations:X,payload:Y})=>EC(Y.exclusiveMinimum,X)),r10=n("effect/schema/isGreaterThanOrEqualToDate",h({minimum:X6}),({annotations:X,payload:Y})=>AC(Y.minimum,X)),i10=n("effect/schema/isLessThanDate",h({exclusiveMaximum:X6}),({annotations:X,payload:Y})=>PC(Y.exclusiveMaximum,X)),n10=n("effect/schema/isLessThanOrEqualToDate",h({maximum:X6}),({annotations:X,payload:Y})=>wC(Y.maximum,X)),s10=n("effect/schema/isBetweenDate",h({minimum:X6,maximum:X6,exclusiveMinimum:IX(d0(!0)),exclusiveMaximum:IX(d0(!0))}),({annotations:X,payload:Y})=>CC(Y,X)),a10=n("effect/schema/isGreaterThanBigInt",h({exclusiveMinimum:P6}),({annotations:X,payload:Y})=>MC(Y.exclusiveMinimum,X)),t10=n("effect/schema/isGreaterThanOrEqualToBigInt",h({minimum:P6}),({annotations:X,payload:Y})=>IC(Y.minimum,X)),e10=n("effect/schema/isLessThanBigInt",h({exclusiveMaximum:P6}),({annotations:X,payload:Y})=>jC(Y.exclusiveMaximum,X)),XX0=n("effect/schema/isLessThanOrEqualToBigInt",h({maximum:P6}),({annotations:X,payload:Y})=>SC(Y.maximum,X)),YX0=n("effect/schema/isBetweenBigInt",h({minimum:P6,maximum:P6,exclusiveMinimum:IX(d0(!0)),exclusiveMaximum:IX(d0(!0))}),({annotations:X,payload:Y})=>vC(Y,X));function QX0(X){let Y=CM(X);return QF(cK(Y),pK(Y))}function _X0(X){return ZG()}function GX0(X){return ZG()}function JX0(X,Y){return(Q)=>{return x(R6(Q.ast,{toCodecIso:()=>new h0(X.ast,E3(Y))}),{schema:Q})}}function $X0(X){let Y=AM(X),Q=cK(Y),_=pK(Y);return{empty:[],diff:(G,J)=>YG(Q(G),Q(J)),combine:(G,J)=>[...G,...J],patch:(G,J)=>{let Z=Q(G),K=aR(J,Z);return Object.is(K,Z)?G:_(K)}}}function ZX0(X){let Y=nw(()=>Q),Q=X1([X,e0(Y),lw(i,Y)]);return Q}var rG=x(R6(U9,{toCode:()=>({runtime:"Schema.Json",Type:"Schema.Json"})})),KX0=M1("effect/schema/Json",rG),HX0=h({message:i,name:_4(i),stack:_4(i),cause:_4(rG)}),kM=x(R6(XR,{toCode:()=>({runtime:"Schema.MutableJson",Type:"Schema.MutableJson"})})),WX0=M1("effect/schema/MutableJson",kM);function UX0(X){return Q8(X.ast)}function DX0(X){return X.ast.context?.annotations}var X_=32,Y_=8;var bM=4096;var gM=16384,yM=262144;var YU=4096;var BX0=new TextEncoder,hM=(X)=>BX0.encode(X).byteLength,iG=(X,Y)=>Number.isInteger(Y)&&Y>=0&&hM(X)<=Y;var VX0=/^[A-Za-z0-9][A-Za-z0-9._:-]*$/,mM=(X)=>typeof X==="string"&&X.length>0&&iG(X,256)&&VX0.test(X);var qX0=$.Literals(["unauthorized","bad_request","invalid","not_found","forbidden","timeout","cancelled","resource_exhausted","unsupported_capability","unsupported_result","result_too_large","failed","runtime_down"]),zX0=$.String.pipe($.check($.makeFilter((X)=>iG(X,YU),{message:`control error exceeds ${YU} UTF-8 bytes`}))),OX0=$.Struct({_tag:qX0,message:zX0});var qZ0=$.Union([$.Struct({ok:$.Literal(!0),data:$.Unknown}),$.Struct({ok:$.Literal(!1),error:OX0})]);var QU=(X,Y)=>$.String.pipe($.check($.makeFilter((Q)=>iG(Q,Y),{message:`${X} exceeds ${Y} UTF-8 bytes`}))),Q_=$.String.pipe($.check($.makeFilter(mM,{message:"sessionId must be nonempty bounded ASCII"}))),dM=$.Struct({ref:QU("ref",bM)}),fM=$.Struct({sessionId:Q_,url:QU("url",gM)}),pM=$.Struct({sessionId:Q_,code:QU("code",yM)}),uM=$.Struct({sessionId:Q_}),cM=$.Struct({sessionId:Q_}),lM=$.Struct({sessionId:Q_}),zZ0=$.Struct({status:$.Literal("ok")}),OZ0=$.Struct({id:$.String,label:$.optionalKey($.String),default:$.optionalKey($.Boolean)}),LZ0=$.Struct({sessionId:$.String,ref:$.String,nodeId:$.String,hostId:$.String,url:$.String,profile:$.String,state:$.String,attached:$.Boolean,title:$.optionalKey($.String),lastError:$.optionalKey($.String)}),TZ0=$.Struct({result:$.Unknown}),RZ0=$.Struct({path:$.String,bytes:$.Number}),FZ0=$.Struct({ref:$.String,sessionId:$.NullOr($.String),canvas:$.String,nodeId:$.String,hostId:$.String,url:$.String,profile:$.optionalKey($.String)});var QX=(X)=>{try{return process.env[X]==="1"}catch{return!1}},AZ0=typeof __VELLUM_COMMAND_HERDR_ENABLED__==="boolean"?__VELLUM_COMMAND_HERDR_ENABLED__:QX("VELLUM_COMMAND_HERDR"),PZ0=typeof __VELLUM_COMMAND_CRON_ENABLED__==="boolean"?__VELLUM_COMMAND_CRON_ENABLED__:QX("VELLUM_COMMAND_CRON"),wZ0=typeof __VELLUM_COMMAND_RELAY_ENABLED__==="boolean"?__VELLUM_COMMAND_RELAY_ENABLED__:QX("VELLUM_COMMAND_RELAY"),nG=typeof __VELLUM_COMMAND_BROWSER_ENABLED__==="boolean"?__VELLUM_COMMAND_BROWSER_ENABLED__:QX("VELLUM_COMMAND_BROWSER"),CZ0=typeof __VELLUM_COMMAND_FLEET_UI_ENABLED__==="boolean"?__VELLUM_COMMAND_FLEET_UI_ENABLED__:QX("VELLUM_COMMAND_FLEET_UI"),MZ0=typeof __VELLUM_COMMAND_USAGE_ENABLED__==="boolean"?__VELLUM_COMMAND_USAGE_ENABLED__:QX("VELLUM_COMMAND_USAGE"),IZ0=typeof __VELLUM_COMMAND_HELP_MAP_ENABLED__==="boolean"?__VELLUM_COMMAND_HELP_MAP_ENABLED__:QX("VELLUM_COMMAND_HELP_MAP"),jZ0=typeof __VELLUM_COMMAND_AUDIO_ENABLED__==="boolean"?__VELLUM_COMMAND_AUDIO_ENABLED__:QX("VELLUM_COMMAND_AUDIO"),SZ0=typeof __VELLUM_COMMAND_HERMES_INTEGRATION_ENABLED__==="boolean"?__VELLUM_COMMAND_HERMES_INTEGRATION_ENABLED__:QX("VELLUM_COMMAND_HERMES"),vZ0=typeof __VELLUM_COMMAND_DEV_TOOLS_ENABLED__==="boolean"?__VELLUM_COMMAND_DEV_TOOLS_ENABLED__:QX("VELLUM_COMMAND_DEV_TOOLS"),xZ0=typeof __VELLUM_COMMAND_HARNESS_KIMI_ENABLED__==="boolean"?__VELLUM_COMMAND_HARNESS_KIMI_ENABLED__:QX("VELLUM_COMMAND_HARNESS_KIMI"),kZ0=typeof __VELLUM_COMMAND_HARNESS_MUSE_ENABLED__==="boolean"?__VELLUM_COMMAND_HARNESS_MUSE_ENABLED__:QX("VELLUM_COMMAND_HARNESS_MUSE"),bZ0=typeof __VELLUM_COMMAND_HARNESS_PRIME_AGENT_ENABLED__==="boolean"?__VELLUM_COMMAND_HARNESS_PRIME_AGENT_ENABLED__:QX("VELLUM_COMMAND_HARNESS_PRIME_AGENT"),gZ0=typeof __VELLUM_COMMAND_HARNESS_SETTINGS_ENABLED__==="boolean"?__VELLUM_COMMAND_HARNESS_SETTINGS_ENABLED__:QX("VELLUM_COMMAND_HARNESS_SETTINGS");var _U=$.Literals(["claude","codex","grok","hermes","pi","prime-agent","kimi","muse","devin"]),fZ0=_U.literals;var cZ0=$.String.pipe($.brand("NodeId")),lZ0=$.String.pipe($.brand("EdgeId"));var oZ0=$.Literals(["actor","sink","scheduler","geography"]),GU=$.Literals(["tasks.list","tasks.create","tasks.claim","tasks.update","msg.list","msg.send","request.escalate","artifact.publish","browser.automate","board.list","board.create_topic","board.post","board.mark_read","pad.read","pad.patch","relay.trigger"]);var w6=(...X)=>KX.fromIterable(X),oM=$.Literals(["agent"]),rM=$.Literals(["page","task","requests","artifacts","board","pad","terminal"]),iM=$.Literals(["watcher","timer","cron","relay"]),rZ0=$.Union([oM,rM,iM]),LX0=oM.literals,TX0=rM.literals,RX0=iM.literals,nM=[...LX0,...TX0,...RX0];var FX0=$.Literals(["full","empty","subset"]);class U8 extends $.Class("PortGrant")({mode:FX0,ports:$.HashSet(GU)}){static empty=new U8({mode:"empty",ports:KX.empty()});static full=new U8({mode:"full",ports:KX.empty()});static subset(X){if(KX.size(X)===0)return U8.empty;return new U8({mode:"subset",ports:X})}static of(...X){return U8.subset(w6(...X))}attenuate(X){if(this.mode==="empty")return U8.empty;if(this.mode==="full")return U8.subset(X);return U8.subset(KX.intersection(this.ports,X))}allows(X,Y){if(!KX.has(Y,X))return!1;if(this.mode==="empty")return!1;if(this.mode==="full")return!0;return KX.has(this.ports,X)}isEmpty(){return this.mode==="empty"}isFull(){return this.mode==="full"}}var N5=$.String.pipe($.check($.isPattern(/^seat_[a-f0-9]{64}$/)),$.brand("ActorSeatId"));var sM=256,aM=256,tM=256,SX=$.String.pipe($.check($.isMinLength(1)),$.check($.isMaxLength(sM))),eM=$.String.pipe($.check($.isMinLength(1)),$.check($.isMaxLength(aM))),XI=$.String.pipe($.check($.isMinLength(1)),$.check($.isMaxLength(tM))),sG=$.Struct({canvasName:eM,nodeId:XI});var Y6=$.Struct({seatId:N5,canvasName:eM,nodeId:XI}),eZ0=$.decodeUnknownSync(N5)(`seat_${"c".repeat(64)}`);var YI=$.Literals(["task","proposal","request","message","artifact","delivery","topic","post","pad"]),QI={itemId:SX,sink:sG},aG=$.Struct({kind:YI,...QI}),JU=$.Struct({kind:$.Literal("task"),...QI});var __=$.String.pipe($.check($.isPattern(/^[a-f0-9]{64}$/)),$.brand("ContentSha256")),G_=$.Number.pipe($.check($.isInt()),$.check($.isGreaterThanOrEqualTo(0)),$.check($.makeFilter(Number.isSafeInteger,{message:"content byteLength must be a safe integer"})),$.brand("ContentByteLength")),$U=$.String.pipe($.check($.isMinLength(1)),$.check($.isMaxLength(255)),$.check($.isPattern(/^[^\u0000-\u001f\u007f]+$/)),$.brand("ContentMediaType")),ZU=$.String.pipe($.check($.isMinLength(1)),$.check($.isMaxLength(255)),$.check($.isPattern(/^[^\u0000-\u001f\u007f]+$/)),$.brand("ContentDisplayName")),KU=$.Struct({sha256:__,byteLength:G_}),qX=$.Struct({...KU.fields,mediaType:$U,displayName:$.optionalKey(ZU)});var GI=$.Struct({kind:$.Literal("local-path"),ref:qX,path:$.String.pipe($.check($.isMinLength(1)),$.check($.isMaxLength(4096)),$.check($.isPattern(/^[^\u0000]+$/)))});var HU=$.String.pipe($.check($.isMinLength(1)),$.check($.isMaxLength(1024)),$.check($.isPattern(/^[^\u0000-\u001f\u007f]+$/)),$.brand("ContentAvailabilityReason")),WU=$.String.pipe($.check($.isMinLength(1)),$.check($.isMaxLength(64)),$.brand("ContentTimestamp")),UU=$.Struct({ref:qX,state:$.Literal("verified"),verifiedSha256:__,verifiedByteLength:G_,verifiedAt:WU}).pipe($.check($.makeFilter(({ref:X,verifiedSha256:Y,verifiedByteLength:Q})=>X.sha256===Y&&X.byteLength===Q||"verified receipt does not match its ContentRef"))),DU=$.Struct({ref:qX,state:$.Literal("missing"),reason:HU}),NU=$.Struct({ref:qX,state:$.Literal("corrupt"),reason:HU,observedSha256:$.optionalKey(__),observedByteLength:$.optionalKey(G_)}),BU=$.Struct({ref:qX,state:$.Literal("unavailable"),reason:HU}),JI=$.Union([UU,DU,NU,BU]),D8=$.Struct({kind:$.Literal("content"),ref:qX}),$I=$.decodeUnknownResult(D8,{onExcessProperty:"error"});var vX0=$.decodeUnknownResult(qX,{onExcessProperty:"error"});var ZI=$.Struct({kind:$.Literal("text"),text:$.String}),KI=$.Struct({kind:$.Literal("url"),url:$.String,mediaType:$.optionalKey($.String)}),HI=$.Struct({kind:$.Literal("data"),data:$.Unknown}),tG=$.Struct({kind:$.Literal("raw"),bytesBase64:$.String,mediaType:$.optionalKey($.String)}),B5=$.Union([ZI,KI,HI,tG,D8]),WI=$.Literals(["user","agent"]),Z4=$.Record($.String,$.Unknown),N8=$.Struct({messageId:$.String,role:WI,parts:$.Array(B5),taskId:$.optionalKey($.String),contextId:$.optionalKey($.String),referenceTaskIds:$.optionalKey($.Array($.String)),metadata:$.optionalKey(Z4)}),g9=$.Literals(["submitted","working","input-required","completed","canceled","failed","rejected","auth-required","archived"]),y9=$.Struct({description:$.optionalKey($.String),artifacts:$.optionalKey($.Struct({nodeId:$.String.pipe($.check($.isMinLength(1))),instruction:$.optionalKey($.String),names:$.optionalKey($.Array($.String))})),git:$.optionalKey($.Struct({minCommits:$.Number.pipe($.check($.isInt()),$.check($.isGreaterThanOrEqualTo(1)))}))}),h9=$.Struct({artifacts:$.Array($.Struct({artifactId:$.String.pipe($.check($.isMinLength(1))),nodeId:$.String.pipe($.check($.isMinLength(1)))})),git:$.optionalKey($.Struct({commits:$.Array($.String)}))}),$4={dependsOn:$.optionalKey($.Array($.String)),finishCriteria:$.optionalKey(y9),metadata:$.optionalKey(Z4),reason:$.optionalKey($.String)},zX=$.Struct({id:$.String,state:g9,claimedBy:$.optionalKey(N5),history:$.Array(N8),artifactIds:$.optionalKey($.Array($.String)),dependsOn:$4.dependsOn,finishCriteria:$4.finishCriteria,completionEvidence:$.optionalKey(h9),metadata:$4.metadata,reason:$4.reason,response:$.optionalKey($.String)}).pipe($.check($.makeFilter(({id:X,state:Y,claimedBy:Q,metadata:_,dependsOn:G,completionEvidence:J})=>{if(_!==void 0&&Object.prototype.hasOwnProperty.call(_,"claimedBy"))return"metadata.claimedBy is retired; use Task.claimedBy";if(Y==="submitted"&&Q!==void 0)return"submitted tasks must be unclaimed";if((Y==="working"||Y==="input-required"||Y==="auth-required")&&Q===void 0)return`${Y} tasks require claimedBy`;if(J!==void 0&&Y!=="completed")return"completionEvidence is only valid on completed tasks";if(G!==void 0){let Z=new Set;for(let K of G){if(typeof K!=="string"||K.trim().length===0)return"dependsOn entries must be non-empty task ids";if(K===X)return"dependsOn cannot include the task itself";if(Z.has(K))return"dependsOn must not contain duplicates";Z.add(K)}}return!0}))),bX0=$.Literals(["pending","approved","rejected"]),V5=$.Struct({id:$.String,state:bX0,brief:N8,proposedBy:Y6,approvedTaskId:$.optionalKey($.String),dependsOn:$4.dependsOn,finishCriteria:$4.finishCriteria,metadata:$4.metadata,reason:$4.reason}).pipe($.check($.makeFilter(({state:X,approvedTaskId:Y})=>X==="approved"===(Y!==void 0)||"approved proposals require approvedTaskId; other proposal states forbid it"))),J_=$.Struct({artifactId:$.String,name:$.optionalKey($.String),parts:$.Array(B5),task:$.optionalKey(JU),metadata:$.optionalKey(Z4)}),VU=$.Struct({items:$.Array(zX),proposals:$.optionalKey($.Array(V5))}),qU=$.Struct({items:$.Array(zX)}),zU=$.Struct({items:$.Array(J_)}),OU=$.Struct({items:$.Array(N8)}),gX0=$.Literals(["operator","actor"]),vX=$.Struct({kind:gX0,seatId:$.optionalKey(N5),nodeId:$.optionalKey($.String),label:$.optionalKey($.String)}),UI=$.Literals(["open","archived"]),$_=$.Struct({postId:$.String,topicId:$.String,author:vX,parts:$.Array(B5).pipe($.check($.isMinLength(1))),position:$.Number.pipe($.check($.isInt()),$.check($.isGreaterThanOrEqualTo(0))),createdAt:$.String,tags:$.optionalKey($.Array($.String.pipe($.check($.isMinLength(1)))))}),Z_=$.Struct({topicId:$.String,title:$.String.pipe($.check($.isMinLength(1)),$.check($.isMaxLength(512))),state:UI,openedBy:vX,openedAt:$.String,postCount:$.Number.pipe($.check($.isInt()),$.check($.isGreaterThanOrEqualTo(0))),lastActivityAt:$.String,parts:$.optionalKey($.Array(B5)),posts:$.optionalKey($.Array($_))}),DI=$.Struct({topics:$.Array(Z_)}),NI=$.Struct({topicId:$.String,title:$.String,state:UI,postCount:$.Number,lastActivityAt:$.String,authorLabel:$.optionalKey($.String)}),LU=$.Struct({topics:$.Array(NI),unread:$.optionalKey($.Number.pipe($.check($.isInt()),$.check($.isGreaterThanOrEqualTo(0))))}),eG=$.Struct({revision:$.Number.pipe($.check($.isInt()),$.check($.isGreaterThanOrEqualTo(0))),shapeCount:$.Number.pipe($.check($.isInt()),$.check($.isGreaterThanOrEqualTo(0))),unreadPinCount:$.Number.pipe($.check($.isInt()),$.check($.isGreaterThanOrEqualTo(0)))}),TU=VU,RU=qU,FU=zU,EU=OU,yX0=$.Struct({canvasName:$.String,nodeId:$.String,tasks:VU,requests:qU,messages:OU,artifacts:zU,board:DI,pad:$.optionalKey(eG)});var V20=$.Struct({brief:$.String,reason:$.optionalKey($.String),metadata:$.optionalKey(Z4),dependsOn:$.optionalKey($.Array($.String)),finishCriteria:$.optionalKey(y9)}).pipe($.check($.makeFilter((X)=>{let Y=X.metadata?.details;return typeof Y==="string"&&Y.trim().length>0||"description (metadata.details) must be non-empty"}))).annotate({parseOptions:{onExcessProperty:"error"}}),q20=$.Struct({title:$.String,body:$.optionalKey($.String),notify:$.optionalKey($.Boolean)}).annotate({parseOptions:{onExcessProperty:"error"}}),z20=$.Struct({topicId:$.String,text:$.String}).annotate({parseOptions:{onExcessProperty:"error"}});var qI=$.String,BI=$.Literals(["top","right","bottom","left"]),VI=$.Literals(["none","arrow"]),hX0=$.Literals(["blocks","relates"]);var AU=$.Literals(["blocker","parked","attention"]);var mX0=$.Literals(["detach","kill-pane"]),dX0=$.Struct({host:$.String,session:$.optionalKey($.NullOr($.String)),workspaceId:$.optionalKey($.String),tabId:$.optionalKey($.String),paneId:$.optionalKey($.String),terminalId:$.optionalKey($.String),label:$.optionalKey($.String),onDelete:$.optionalKey(mX0)});var fX0=$.Literals(["detach","kill-session"]),pX0=$.Literals(["shell","command","harness"]),uX0=$.Struct({kind:pX0,argv:$.optionalKey($.Array($.String)),cwd:$.optionalKey($.String),env:$.optionalKey($.Record($.String,$.String))}),cX0=$.Struct({bindingId:$.String,label:$.optionalKey($.String),onDelete:$.optionalKey(fX0),launch:$.optionalKey(uX0),harness:$.optionalKey(_U),sessionId:$.optionalKey($.String)});var lX0=$.Literals(["detach","kill-session"]),oX0=$.Struct({profile:$.String,onDelete:$.optionalKey(lX0)});var rX0=$.Struct({kind:$.String,name:$.optionalKey($.String)}),zI=$.String.pipe($.check($.isMinLength(1)),$.check($.isMaxLength(64)),$.check($.isPattern(/^(?!-)[A-Za-z0-9][A-Za-z0-9._-]*$/))),iX0=$.Struct({host:$.String,session:$.optionalKey($.NullOr($.String)),workspaceId:$.optionalKey($.String),tabId:$.optionalKey($.String)}),nX0=$.Struct({url:$.optionalKey($.String),profile:$.optionalKey($.String),host:$.optionalKey(zI)}),sX0=$.Record($.String,$.String),aX0=$.Struct({herdr:$.optionalKey(iX0),page:$.optionalKey(nX0),paths:$.optionalKey(sX0)}),tX0=$.Struct({hold:$.optionalKey($.Boolean),instruction:$.optionalKey($.String),defaults:$.optionalKey(aX0)}),eX0=$.Literal("stat_threshold"),X60=$.Struct({kind:eX0,source:$.optionalKey($.Literal("hermes")),key:$.optionalKey($.String),stat:$.optionalKey($.String),op:$.optionalKey($.Literals(["gt","lt","eq"])),value:$.optionalKey($.Number),flagOnUnsatisfied:$.optionalKey($.Boolean)}),Y60=$.Struct({everyMinutes:$.optionalKey($.Number),expression:$.optionalKey($.String)}),Q60=$.Literals(["input","output","trigger","recipient"]),OI=$.Struct({word:$.Literal("completes"),equals:$.optionalKey($.String),itemId:$.optionalKey($.String)}),LI=$.Struct({word:$.Literal("flagged"),flag:AU}),_60=$.Union([OI,LI]),G60=$.Struct({word:$.Literal("any"),any:$.Array(_60).pipe($.check($.isMinLength(1)))}),J60=$.Union([OI,LI,G60]),$60=$.Struct({mode:$.Literal("enqueue_task"),data:$.Unknown}),Z60=$.Struct({mode:$.Literal("board_create_topic"),data:$.Unknown}),K60=$.Struct({mode:$.Literal("board_post"),data:$.Unknown}),H60=$.Struct({mode:$.Literal("set_flag"),flag:AU,enabled:$.Union([$.Boolean,$.Literal("mirror")])}),W60=$.Struct({mode:$.Literal("inject_prompt"),text:$.optionalKey($.String)}),U60=$.Union([$60,Z60,K60,H60,W60]),D60=$.Struct({mode:$.Literal("tasks"),itemIds:$.optionalKey($.Array($.String))}),N60=D60,B60=$.Struct({entity:$.optionalKey(rX0),flags:$.optionalKey($.Array(AU)),region:$.optionalKey(tX0),watch:$.optionalKey(X60),timer:$.optionalKey(Y60),tasks:$.optionalKey(TU),requests:$.optionalKey(RU),artifacts:$.optionalKey(FU),messages:$.optionalKey(EU),board:$.optionalKey(LU),pad:$.optionalKey(eG),herdr:$.optionalKey(dX0),terminal:$.optionalKey(cX0),browser:$.optionalKey(oX0),host:$.optionalKey(zI)}),V60=$.Struct({ports:$.optionalKey($.Array(GU)),stops:$.optionalKey(N60),wake:$.optionalKey($.Boolean),slot:$.optionalKey(Q60),when:$.optionalKey(J60),does:$.optionalKey(U60),kind:$.optionalKey(hX0)});var XJ={id:$.String,x:$.Number,y:$.Number,width:$.Number,height:$.Number,color:$.optionalKey(qI),ether:$.optionalKey(B60)},q60=$.Struct({type:$.Literal("text"),text:$.String,...XJ}),z60=$.Struct({type:$.Literal("file"),file:$.String,subpath:$.optionalKey($.String),...XJ}),O60=$.Struct({type:$.Literal("link"),url:$.String,...XJ}),L60=$.Struct({type:$.Literal("group"),label:$.optionalKey($.String),background:$.optionalKey($.String),backgroundStyle:$.optionalKey($.Literals(["cover","ratio","repeat"])),...XJ}),T60=$.Union([q60,z60,O60,L60]),R60=$.Struct({id:$.String,fromNode:$.String,fromSide:$.optionalKey(BI),fromEnd:$.optionalKey(VI),toNode:$.String,toSide:$.optionalKey(BI),toEnd:$.optionalKey(VI),color:$.optionalKey(qI),label:$.optionalKey($.String),ether:$.optionalKey(V60)}),TI=$.Struct({nodes:$.Array(T60),edges:$.Array(R60)}),P20=$.decodeUnknownResult(TI,{onExcessProperty:"error"}),w20=$.encodeResult(TI);var H4={onExcessProperty:"error"},B8=$.Number.pipe($.check($.makeFilter(Number.isFinite,{message:"must be a finite number"}))),q5=B8.pipe($.check($.isGreaterThan(0))),K_=$.Number.pipe($.check($.isInt())),K4=$.String.pipe($.check($.isMinLength(1))),Q6=K4.pipe($.check($.isMaxLength(256)),$.brand("PadElementId"));var F60=K4.pipe($.check($.isMaxLength(256)),$.brand("PadPostId"));var E60=$.Literals(["box","ellipse","triangle","label"]),A60=$.Literals(["none","active","done","blocked"]),RI=$.Literals(["top","right","bottom","left"]),v20=$.Literals(["image","shape","edge","ink","pin"]),P60=$.Struct({x:B8,y:B8}),w60=$.Struct({w:q5,h:q5}),PU=$.Struct({id:Q6,type:E60,x:B8,y:B8,w:q5,h:q5,z:K_,fill:$.optionalKey(K4),stroke:$.optionalKey(K4),text:$.optionalKey(K4),status:$.optionalKey(A60)}),wU=$.Struct({id:Q6,from:Q6,to:Q6,fromSide:$.optionalKey(RI),toSide:$.optionalKey(RI),label:$.optionalKey(K4)}),CU=$.Struct({id:Q6,x:B8,y:B8,w:q5,h:q5,z:K_,ref:qX}),MU=$.Struct({id:Q6,z:K_,color:K4,width:q5,points:$.Array(P60).pipe($.check($.isMinLength(2)))}),IU=$.Struct({postId:F60,author:vX,parts:$.Array(B5).pipe($.check($.isMinLength(1)))}),FI=$.Struct({id:Q6,x:B8,y:B8,bounds:$.optionalKey(w60),mentions:$.Array(K4)}),EI=$.Struct({...FI.fields,posts:$.Array(IU)}),C60=(X)=>[...X.images.map((Y)=>Y.id),...X.shapes.map((Y)=>Y.id),...X.edges.map((Y)=>Y.id),...X.inks.map((Y)=>Y.id),...X.pins.map((Y)=>Y.id)],M60=(X)=>{let Y=C60(X);if(new Set(Y).size!==Y.length)return"ids must be unique within the pad";let Q=new Set(X.shapes.map((_)=>_.id));for(let _ of X.edges)if(!Q.has(_.from)||!Q.has(_.to))return"edge endpoints must exist";for(let _ of X.pins){let G=_.posts.map((J)=>J.postId);if(new Set(G).size!==G.length)return"post ids must be unique on a pin";if(_.posts.some((J)=>I60(J.parts)))return"bytes never live in pad JSON"}return!0},I60=(X)=>X.some((Y)=>Y.kind==="raw"),j60=$.Struct({revision:K_.pipe($.check($.isGreaterThanOrEqualTo(0))),images:$.Array(CU),shapes:$.Array(PU),edges:$.Array(wU),inks:$.Array(MU),pins:$.Array(EI)}).pipe($.check($.makeFilter(M60))),S60=$.Struct({op:$.Literal("upsert"),layer:$.Literal("shape"),shape:PU}),v60=$.Struct({op:$.Literal("upsert"),layer:$.Literal("edge"),edge:wU}),x60=$.Struct({op:$.Literal("upsert"),layer:$.Literal("image"),image:CU}),k60=$.Struct({op:$.Literal("upsert"),layer:$.Literal("ink"),ink:MU}),b60=$.Struct({op:$.Literal("pin.upsert"),pin:FI}),g60=$.Struct({op:$.Literal("pin.reply"),pinId:Q6,post:IU}),y60=$.Struct({op:$.Literal("delete"),id:Q6}),h60=$.Struct({op:$.Literal("z"),id:Q6,z:K_}),m9=$.Union([S60,v60,x60,k60,b60,g60,y60,h60]),m60=$.Literals(["invalid","duplicate_id","zero_size","dangling_edge","empty_ink","layer_mismatch","missing"]);class d60 extends $.TaggedErrorClass()("PadError",{code:m60,message:$.String,id:$.optionalKey(Q6)}){}var x20=$.decodeUnknownResult(j60,H4),k20=$.decodeUnknownResult(m9,H4),b20=$.decodeUnknownResult(PU,H4),g20=$.decodeUnknownResult(wU,H4),y20=$.decodeUnknownResult(CU,H4),h20=$.decodeUnknownResult(MU,H4),m20=$.decodeUnknownResult(EI,H4),d20=$.decodeUnknownResult(IU,H4);var jU=$.Literals(["ping","doctor","capabilities","onboard","preamble","tasks.list","tasks.create","tasks.claim","tasks.update","content.path","content.stat","content.materialize","msg.list","msg.send","msg.read","msg.reply","msg.react","request.escalate","artifact.publish","board.list","board.create_topic","board.post","board.mark_read","board.tags","pad.read","pad.patch","relay.trigger"]),f60=$.Literals(["ScopeError","ClaimConflict","UnknownTarget","StaleNodeRef","InvalidTransition","RuntimeDown","AuthError","InputError","ProtocolError","InternalError","Paused","Blocked"]),p60=$.Struct({path:$.optionalKey($.String),expected:$.optionalKey($.Unknown),received:$.optionalKey($.Unknown),hint:$.optionalKey($.String),next_step:$.optionalKey($.String),retryable:$.optionalKey($.Boolean),from:$.optionalKey($.String),to:$.optionalKey($.String),holder:$.optionalKey($.String),target:$.optionalKey($.String),caller:$.optionalKey($.String),missing:$.optionalKey($.String),requestId:$.optionalKey($.String),stop_directive:$.optionalKey($.Unknown)}),u60=$.Struct({type:f60,message:$.String,details:$.optionalKey(p60)}),c60=$.Struct({token:$.String,op:jU,args:$.optionalKey($.Unknown),id:$.optionalKey($.String)}),l60=$.Struct({ok:$.Literal(!0),op:jU,data:$.Unknown,id:$.optionalKey($.String),protocol_version:$.optionalKey($.String)}),o60=$.Struct({ok:$.Literal(!1),op:$.optionalKey(jU),error:u60,id:$.optionalKey($.String),protocol_version:$.optionalKey($.String)}),r60=$.Union([l60,o60]),r20=$.decodeUnknownResult(c60,{onExcessProperty:"error"}),i20=$.decodeUnknownResult(r60,{onExcessProperty:"error"});var AI=$.Struct({target:$.String}),PI=$.Struct({target:$.String,brief:$.String,reason:$.optionalKey($.String),metadata:$.optionalKey(Z4),media:$.optionalKey($.Array($.Union([tG,D8]))),dependsOn:$.optionalKey($.Array($.String)),finishCriteria:$.optionalKey(y9)}).pipe($.check($.makeFilter((X)=>{let Y=X.metadata?.details;return typeof Y==="string"&&Y.trim().length>0||"description (metadata.details) must be non-empty"}))).annotate({parseOptions:{onExcessProperty:"error"}}),wI=$.Struct({target:$.String,task:$.String}).annotate({parseOptions:{onExcessProperty:"error"}}),CI=$.Struct({target:$.String,task:$.String,state:g9,note:$.optionalKey($.String),completionEvidence:$.optionalKey(h9)}).pipe($.check($.makeFilter(({state:X,completionEvidence:Y})=>Y===void 0||X==="completed"||"completionEvidence is only allowed when state is completed"))).annotate({parseOptions:{onExcessProperty:"error"}}),i60=qX.annotate({parseOptions:{onExcessProperty:"error"}}),SU={target:$.String.pipe($.check($.isMinLength(1))),task:$.String.pipe($.check($.isMinLength(1))),ref:i60},MI=$.Struct(SU).annotate({parseOptions:{onExcessProperty:"error"}}),II=$.Struct(SU).annotate({parseOptions:{onExcessProperty:"error"}}),jI=$.Struct({...SU,name:$.optionalKey($.String)}).annotate({parseOptions:{onExcessProperty:"error"}}),SI=$.Struct({target:$.optionalKey($.String),taskId:$.optionalKey($.String)}),vI=$.Struct({target:$.String,text:$.String,taskId:$.optionalKey($.String)}),xI=$.Struct({target:$.optionalKey($.String),messageId:$.String}),kI=$.Struct({target:$.optionalKey($.String),messageId:$.String,reaction:$.optionalKey($.Literals(["ack"]))}),bI=$.Struct({target:$.String,text:$.String,inReplyTo:$.String}),gI=$.Struct({text:$.String}).annotate({parseOptions:{onExcessProperty:"error"}}),yI=$.Struct({target:$.String,brief:$.String,reason:$.optionalKey($.String),metadata:$.optionalKey($.Record($.String,$.Unknown))}).pipe($.check($.makeFilter((X)=>{if(!X.brief.trim())return"brief must be non-empty";let Q=typeof X.reason==="string"?X.reason.trim():"",_=X.metadata?.details,G=typeof _==="string"?_.trim():"";if(!Q&&!G)return"request body required: provide reason and/or metadata.details (not title-only)";return!0}))).annotate({parseOptions:{onExcessProperty:"error"}});var n60=$.Union([$.Struct({kind:$.Literal("text"),text:$.String}),$.Struct({kind:$.Literal("url"),url:$.String,mediaType:$.optionalKey($.String)}),$.Struct({kind:$.Literal("data"),data:$.Unknown}),$.Struct({kind:$.Literal("raw"),bytesBase64:$.String,mediaType:$.optionalKey($.String)}),D8]),hI=$.Struct({target:$.String,id:$.String}),n20=$.Struct({target:$.String,name:$.optionalKey($.String),artifactId:$.optionalKey($.String),parts:$.Array(n60),task:$.optionalKey(hI),metadata:$.optionalKey($.Record($.String,$.Unknown))}),s60=$.Union([$.Struct({kind:$.Literal("text"),text:$.String}),$.Struct({kind:$.Literal("url"),url:$.String,mediaType:$.optionalKey($.String)}),$.Struct({kind:$.Literal("data"),data:$.Unknown}),$.Struct({kind:$.Literal("raw"),bytesBase64:$.optionalKey($.String),path:$.optionalKey($.String),mediaType:$.optionalKey($.String)}),D8]),mI=$.Struct({target:$.String,name:$.optionalKey($.String),artifactId:$.optionalKey($.String),parts:$.Array(s60),task:$.optionalKey(hI),metadata:$.optionalKey($.Record($.String,$.Unknown))}),dI=$.Struct({}),fI=$.Struct({target:$.String,topicId:$.optionalKey($.String)}),s20=$.Struct({target:$.String,title:$.String,body:$.optionalKey($.String),notify:$.optionalKey($.Boolean)}),pI=$.Struct({target:$.String,topicId:$.String,text:$.String,tags:$.optionalKey($.Array($.String))}),uI=$.Struct({target:$.String,topicId:$.optionalKey($.String)}),a20=$.Struct({target:$.String,topicId:$.String,upToPosition:$.optionalKey($.Number)}),cI=$.Struct({target:$.String,pinId:$.optionalKey($.String)}).annotate({parseOptions:{onExcessProperty:"error"}}),lI=$.Struct({target:$.String,patches:$.Array(m9).pipe($.check($.isMinLength(1)))}).annotate({parseOptions:{onExcessProperty:"error"}}),YJ=$.Struct({target:$.String.pipe($.check($.isMinLength(1)))}).annotate({parseOptions:{onExcessProperty:"error"}}),oI=$.Struct({target:$.String.pipe($.check($.isMinLength(1))),pinId:$.String.pipe($.check($.isMinLength(1)))}).annotate({parseOptions:{onExcessProperty:"error"}}),rI=$.Struct({target:$.String.pipe($.check($.isMinLength(1))),id:$.optionalKey($.String.pipe($.check($.isMinLength(1))))}).annotate({parseOptions:{onExcessProperty:"error"}}),t20=$.Struct({target:$.String}).annotate({parseOptions:{onExcessProperty:"error"}});var C6=5;var iI={command:"tasks claim",args:["tasks","claim",'{"target":"n7","task":"t1"}'],lesson:"Claim only unclaimed tasks; the factory queue decides what is available."};var nI={command:"tasks update",args:["tasks","update",'{"target":"n7","task":"t1","state":"completed","note":"done","completionEvidence":{"artifacts":[{"artifactId":"a1","nodeId":"art1"}],"git":{"commits":["abc123"]}}}'],lesson:"completed is a factory verdict, not a self-declaration — attach evidence first, or the server rejects the transition."},sI={command:"escalate",args:["escalate",'{"target":"req1","brief":"need API key for staging","reason":"cannot continue without operator secret"}'],lesson:"Escalating blocks the seat and returns a stop directive — stop work ops until the operator answers."};var b0=["inline-json","@file","stdin"],aI={command_id:"tasks.list",command:"tasks list",schema_id:"tasks.list.input/v1",description:"List tasks on a connected task node.",schema:AI,input_modes:b0},tI={command_id:"tasks.claim",command:"tasks claim",schema_id:"tasks.claim.input/v1",description:"Claim a task (submitted → working).",schema:wI,accepts_batch:!0,input_modes:b0},QJ={command_id:"tasks.create",command:"tasks create",schema_id:"tasks.create.input/v2",description:"Create a proposal on a connected task node for operator review. Same authoring fields as executable tasks (brief, required metadata.details description, reason, media, dependsOn, finishCriteria); approval mints a submitted Task.",schema:PI,accepts_batch:!0,input_modes:b0},eI={command_id:"tasks.update",command:"tasks update",schema_id:"tasks.update.input/v2",description:"Transition a task to a new task state. On completed, optional completionEvidence supplies artifacts + git commits for finish-criteria gates.",schema:CI,accepts_batch:!0,input_modes:b0},Xj={command_id:"msg.list",command:"msg list",schema_id:"msg.list.input/v1",description:"List this seat's inbox (no target) or a connected mailbox. Own-inbox list marks listed inbound mail read and includes sent mail with readAt.",schema:SI,input_modes:b0},Yj={command_id:"msg.send",command:"msg send",schema_id:"msg.send.input/v1",description:"Append a message to a connected node.",schema:vI,accepts_batch:!0,input_modes:b0},Qj={command_id:"msg.read",command:"msg read",schema_id:"msg.read.input/v1",description:"Mark one mailbox message read (own seat only). Own `msg list` already does this for every listed item.",schema:xI,accepts_batch:!0,input_modes:b0},_j={command_id:"msg.reply",command:"msg reply",schema_id:"msg.reply.input/v1",description:"Reply to factory mail: send text to target and mark inReplyTo read on own mailbox.",schema:bI,accepts_batch:!0,input_modes:b0},Gj={command_id:"msg.react",command:"msg react",schema_id:"msg.react.input/v1",description:"Acknowledge own-inbox mail without a reply (reaction defaults to ack).",schema:kI,accepts_batch:!0,input_modes:b0},Jj={command_id:"preamble",command:"preamble",schema_id:"preamble.input/v1",description:"Show a short-lived thought bubble above this agent node.",schema:gI,input_modes:b0},$j={command_id:"request.escalate",command:"escalate",schema_id:"request.escalate.input/v1",description:"Escalate to the operator: create a request, block this seat, return a stop directive. Subsequent work ops return Blocked until the request is answered.",schema:yI,input_modes:b0},Zj={command_id:"artifact.publish",command:"artifact publish",schema_id:"artifact.publish.input/v2",description:"Publish an artifact; raw parts may use path and optional task provenance names the exact task sink and id.",schema:mI,accepts_batch:!0,input_modes:b0},Kj={command_id:"content.path",command:"content path",schema_id:"content.path.input/v1",description:"Resolve an authorized task ContentRef to its verified canonical local path.",schema:MI,input_modes:b0},Hj={command_id:"content.stat",command:"content stat",schema_id:"content.stat.input/v1",description:"Read availability, identity, metadata, and local path for an authorized task ContentRef.",schema:II,input_modes:b0},Wj={command_id:"content.materialize",command:"content materialize",schema_id:"content.materialize.input/v1",description:"Stream an authorized task ContentRef into a stable Vellum Command task-scoped workspace path.",schema:jI,input_modes:b0},a60={command_id:"board.list",command:"board list",schema_id:"board.list.input/v1",description:"List topics/posts on a connected board plus metadata of connected actors.",schema:fI,input_modes:b0},t60={command_id:"board.post",command:"board post",schema_id:"board.post.input/v1",description:"Post under a topic; optional tags (actor node ids) soft-notify tagged seats.",schema:pI,accepts_batch:!0,input_modes:b0},e60={command_id:"board.tags",command:"board tags",schema_id:"board.tags.input/v1",description:"List posts on a connected board that tag this process-bound seat.",schema:uI,input_modes:b0},Uj={command_id:"pad.read",command:"pad read",schema_id:"pad.read.input/v1",description:"Read a connected pad (grant pad.read): revision, IR, digest, SVG. Optional pinId adds look-here. Agents never write the factory canvas.",schema:cI,input_modes:b0},Dj={command_id:"pad.patch",command:"pad patch",schema_id:"pad.patch.input/v1",description:"Apply PadPatch on a connected pad (grant pad.patch). Agents may upsert shapes, edges, and pin posts. Agent ink or image upserts are refused. Mentions must be inbound actor node ids.",schema:lI,accepts_batch:!0,input_modes:b0},Nj={command_id:"pad.digest",command:"pad digest",schema_id:"pad.digest.input/v1",description:"Text IR of a connected pad (grant pad.read). Working copy for a wired seat — not the factory canvas.",schema:YJ,input_modes:b0},Bj={command_id:"pad.svg",command:"pad svg",schema_id:"pad.svg.input/v1",description:"SVG picture of a connected pad (grant pad.read). Agents read the page; they never write the factory canvas.",schema:YJ,input_modes:b0},Vj={command_id:"pad.look-here",command:"pad look-here",schema_id:"pad.look-here.input/v1",description:"Crop around a pin on a connected pad (grant pad.read). pinId required. Mentions are inbound wired actors — @ cannot name an unwired agent.",schema:oI,input_modes:b0},qj={command_id:"pad.get",command:"pad get",schema_id:"pad.get.input/v1",description:"Compact focused items from a connected pad (grant pad.read). Optional id returns that item. Agents never write the factory canvas.",schema:rI,input_modes:b0},zj={command_id:"pad.tagged",command:"pad tagged",schema_id:"pad.tagged.input/v1",description:"Pins that mention this process-bound seat (grant pad.read). Mention universe is inbound actor edges; unwired names are refused on pad.patch.",schema:YJ,input_modes:b0},z5=(X,Y,Q,_)=>({command_id:`browser.${X}`,command:`browser ${Y}`,schema_id:`browser.${X}.input/v1`,description:Q,schema:_,input_modes:["positional"]}),Oj=z5("pages","pages","List page nodes admitted by the caller's live browser.automate edges.",dI),Lj=z5("open","open <vellum-ref>","Open or reuse a granted page session.",dM),Tj=z5("goto","goto <sessionId> <url>","Navigate an admitted browser session.",fM),Rj=z5("eval","eval <sessionId> <code>","Evaluate JavaScript in an admitted browser session.",pM),Fj=z5("screenshot","shot <sessionId>","Capture a server-owned PNG from an admitted browser session.",uM),Ej=z5("close","close <sessionId>","Detach a browser surface while keeping its session warm.",cM),Aj=z5("stop","stop <sessionId>","Destroy an admitted browser session.",lM),ZK0=[aI,QJ,tI,eI,Xj,Yj,Qj,_j,Gj,Jj,$j,Zj,Kj,Hj,Wj,a60,t60,e60,Uj,Dj,Nj,Bj,Vj,qj,zj,...nG?[Oj,Lj,Tj,Rj,Fj,Ej,Aj]:[]],f0=[{command_id:"tasks.create",command:"tasks create",name:"propose work",description:"Create an attributed proposal for operator review.",input:{target:"n7",brief:"Add keyboard navigation",metadata:{title:"Keyboard navigation",details:"Cover the task board first."}},args:["tasks","create",'{"target":"n7","brief":"Add keyboard navigation","metadata":{"title":"Keyboard navigation","details":"Cover the task board first."}}']},{command_id:"tasks.create",command:"tasks create",name:"propose with deps and finish criteria",description:"Same authoring contract as task create: dependsOn + finishCriteria carry onto the minted Task on approve.",input:{target:"n7",brief:"Ship media migration graph",reason:"needs prior content-ref work complete",dependsOn:["t_prereq"],finishCriteria:{description:"graph claimable and media uses ContentRef",git:{minCommits:1}},metadata:{title:"Media migration graph",details:"Wire ContentRef media and make the graph claimable."}},args:["tasks","create",'{"target":"n7","brief":"Ship media migration graph","reason":"needs prior content-ref work complete","dependsOn":["t_prereq"],"finishCriteria":{"description":"graph claimable and media uses ContentRef","git":{"minCommits":1}},"metadata":{"title":"Media migration graph","details":"Wire ContentRef media and make the graph claimable."}}']},{command_id:"tasks.claim",command:"tasks claim",name:"claim one",description:"Claim task t1 on target node n7.",args:iI.args,input:{target:"n7",task:"t1"}},{command_id:"tasks.claim",command:"tasks claim",name:"batch claim",description:"Claim several tasks with bounded concurrency.",args:["tasks","claim","@claims.json","--concurrency","5"],input:[{target:"n7",task:"t1"},{target:"n7",task:"t2"}]},{command_id:"tasks.update",command:"tasks update",name:"complete",input:{target:"n7",task:"t1",state:"completed",note:"done"},args:["tasks","update",'{"target":"n7","task":"t1","state":"completed","note":"done"}']},{command_id:"tasks.update",command:"tasks update",name:"complete with evidence",input:{target:"n7",task:"t1",state:"completed",note:"done",completionEvidence:{artifacts:[{artifactId:"a1",nodeId:"art1"}],git:{commits:["abc123"]}}},args:nI.args},{command_id:"msg.send",command:"msg send",name:"note on task",input:{target:"n7",text:"working",taskId:"t1"},args:["msg","send",'{"target":"n7","text":"working","taskId":"t1"}']},{command_id:"msg.read",command:"msg read",name:"ack mailbox",input:{target:"seat-a",messageId:"msg_01"},args:["msg","read",'{"target":"seat-a","messageId":"msg_01"}']},{command_id:"msg.reply",command:"msg reply",name:"reply to mail",input:{target:"seat-b",text:"ack, starting",inReplyTo:"msg_01"},args:["msg","reply",'{"target":"seat-b","text":"ack, starting","inReplyTo":"msg_01"}']},{command_id:"msg.list",command:"msg list",name:"open own inbox",input:{},args:["msg","list"]},{command_id:"msg.react",command:"msg react",name:"ack without reply",input:{messageId:"msg_01"},args:["msg","react",'{"messageId":"msg_01"}']},{command_id:"preamble",command:"preamble",name:"share a brief thought",description:"Show a sentence above this agent node for about 30 seconds.",input:{text:"Inspecting the task and choosing the smallest safe change."},args:["preamble",'{"text":"Inspecting the task and choosing the smallest safe change."}']},{command_id:"request.escalate",command:"escalate",name:"block until answer",description:"File a request and block this seat. Server returns stop_directive; further work ops return Blocked.",input:{target:"req1",brief:"need API key for staging",reason:"cannot continue without operator secret"},args:sI.args},{command_id:"artifact.publish",command:"artifact publish",name:"publish file",input:{target:"art1",name:"report",parts:[{kind:"raw",path:"/abs/x.png"}],task:{target:"tasks",id:"t1"}},args:["artifact","publish",'{"target":"art1","name":"report","parts":[{"kind":"raw","path":"/abs/x.png"}],"task":{"target":"tasks","id":"t1"}}']},{command_id:"tasks.list",command:"tasks list",name:"list",input:{target:"n7"},args:["tasks","list",'{"target":"n7"}']},{command_id:"content.path",command:"content path",name:"resolve task content",description:"Resolve a ContentRef carried by task t1 on target n7.",input:{target:"n7",task:"t1",ref:{sha256:"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",byteLength:12,mediaType:"application/octet-stream"}},args:["content","path",'{"target":"n7","task":"t1","ref":{"sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","byteLength":12,"mediaType":"application/octet-stream"}}']},{command_id:"content.stat",command:"content stat",name:"inspect task content",input:{target:"n7",task:"t1",ref:{sha256:"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",byteLength:12,mediaType:"application/octet-stream"}},args:["content","stat",'{"target":"n7","task":"t1","ref":{"sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","byteLength":12,"mediaType":"application/octet-stream"}}']},{command_id:"content.materialize",command:"content materialize",name:"materialize task content",input:{target:"n7",task:"t1",name:"record.bin",ref:{sha256:"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",byteLength:12,mediaType:"application/octet-stream"}},args:["content","materialize",'{"target":"n7","task":"t1","name":"record.bin","ref":{"sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","byteLength":12,"mediaType":"application/octet-stream"}}']},{command_id:"pad.read",command:"pad read",name:"read pad",description:"Read revision, IR, digest, and SVG on a wired pad.",input:{target:"pad-1"},args:["pad","read",'{"target":"pad-1"}']},{command_id:"pad.read",command:"pad read",name:"read with look-here",description:"Read the pad and crop around pin-1.",input:{target:"pad-1",pinId:"pin-1"},args:["pad","read",'{"target":"pad-1","pinId":"pin-1"}']},{command_id:"pad.patch",command:"pad patch",name:"upsert box",description:"Upsert a named box. Agent ink/image upserts are refused; mentions must be inbound actors.",input:{target:"pad-1",patches:[{op:"upsert",layer:"shape",shape:{id:"box-1",type:"box",x:0,y:0,w:80,h:40,z:0,text:"inbox"}}]},args:["pad","patch",'{"target":"pad-1","patches":[{"op":"upsert","layer":"shape","shape":{"id":"box-1","type":"box","x":0,"y":0,"w":80,"h":40,"z":0,"text":"inbox"}}]}']},{command_id:"pad.patch",command:"pad patch",name:"pin mention",description:"Place a pin that mentions a wired inbound actor. Unwired names are refused.",input:{target:"pad-1",patches:[{op:"pin.upsert",pin:{id:"pin-1",x:16,y:16,mentions:["agent-1"]}}]},args:["pad","patch",'{"target":"pad-1","patches":[{"op":"pin.upsert","pin":{"id":"pin-1","x":16,"y":16,"mentions":["agent-1"]}}]}']},{command_id:"pad.digest",command:"pad digest",name:"text IR",input:{target:"pad-1"},args:["pad","digest",'{"target":"pad-1"}']},{command_id:"pad.svg",command:"pad svg",name:"picture",input:{target:"pad-1"},args:["pad","svg",'{"target":"pad-1"}']},{command_id:"pad.look-here",command:"pad look-here",name:"crop pin",description:"Crop the page around pin-1.",input:{target:"pad-1",pinId:"pin-1"},args:["pad","look-here",'{"target":"pad-1","pinId":"pin-1"}']},{command_id:"pad.get",command:"pad get",name:"focused items",input:{target:"pad-1"},args:["pad","get",'{"target":"pad-1"}']},{command_id:"pad.get",command:"pad get",name:"one item",input:{target:"pad-1",id:"box-1"},args:["pad","get",'{"target":"pad-1","id":"box-1"}']},{command_id:"pad.tagged",command:"pad tagged",name:"pins mentioning this seat",description:"List pins that mention the process-bound seat.",input:{target:"pad-1"},args:["pad","tagged",'{"target":"pad-1"}']},...nG?[{command_id:"browser.pages",command:"browser pages",name:"list granted pages",args:["browser","pages","--json"],input:{}},{command_id:"browser.open",command:"browser open <vellum-ref>",name:"open a granted page",args:["browser","open","vellum-command://canvas/work?node=page-1","--json"],input:{ref:"vellum-command://canvas/work?node=page-1"}}]:[]],KK0=[{command_id:"ping",command:"ping",category:"diagnostic",description:"Liveness probe against the work control socket."},{command_id:"doctor",command:"doctor",category:"diagnostic",description:"Env socket+token present, perms 0600, protocol version match."},{command_id:"capabilities",command:"capabilities",category:"discovery",description:"Live wiring from the caller's edges as a contract."},{command_id:"onboard",command:"onboard",category:"discovery",description:"Node, region, connected, co-members, capabilities from live state."},{command_id:"schema.list",command:"schema list",category:"discovery",description:"List JSON input schemas."},{command_id:"schema.show",command:"schema show",category:"discovery",description:"Show one JSON input schema."},{command_id:"examples.list",command:"examples list",category:"discovery",description:"List executable examples."},{command_id:"examples.show",command:"examples show",category:"discovery",description:"Show examples for one command."},{command_id:"tasks.list",command:"tasks list",category:"workflow",description:"List tasks on a connected target.",schemas:[aI],examples:f0.filter((X)=>X.command_id==="tasks.list")},{command_id:"tasks.create",command:"tasks create",category:"workflow",description:"Create one or more proposals (batch-capable).",schemas:[QJ],examples:f0.filter((X)=>X.command_id==="tasks.create"),batch:{accepts_batch:!0,default_concurrency:C6,supports_concurrency_option:!0}},{command_id:"tasks.claim",command:"tasks claim",category:"workflow",description:"Claim one or more tasks (batch-capable).",schemas:[tI],examples:f0.filter((X)=>X.command_id==="tasks.claim"),batch:{accepts_batch:!0,default_concurrency:C6,supports_concurrency_option:!0}},{command_id:"tasks.update",command:"tasks update",category:"workflow",description:"Update task state (batch-capable).",schemas:[eI],examples:f0.filter((X)=>X.command_id==="tasks.update"),batch:{accepts_batch:!0,default_concurrency:C6,supports_concurrency_option:!0}},{command_id:"msg.list",command:"msg list",category:"workflow",description:"List own inbox (marks listed mail read; includes sent with readAt) or a peer mailbox.",schemas:[Xj],examples:f0.filter((X)=>X.command_id==="msg.list")},{command_id:"msg.send",command:"msg send",category:"workflow",description:"Send a message (batch-capable).",schemas:[Yj],examples:f0.filter((X)=>X.command_id==="msg.send"),batch:{accepts_batch:!0,default_concurrency:C6,supports_concurrency_option:!0}},{command_id:"msg.read",command:"msg read",category:"workflow",description:"Mark a mailbox message read (own seat; batch-capable).",schemas:[Qj],examples:f0.filter((X)=>X.command_id==="msg.read"),batch:{accepts_batch:!0,default_concurrency:C6,supports_concurrency_option:!0}},{command_id:"msg.reply",command:"msg reply",category:"workflow",description:"Reply to factory mail and mark parent read (batch-capable).",schemas:[_j],examples:f0.filter((X)=>X.command_id==="msg.reply"),batch:{accepts_batch:!0,default_concurrency:C6,supports_concurrency_option:!0}},{command_id:"msg.react",command:"msg react",category:"workflow",description:"Acknowledge own-inbox mail without a reply (batch-capable).",schemas:[Gj],examples:f0.filter((X)=>X.command_id==="msg.react"),batch:{accepts_batch:!0,default_concurrency:C6,supports_concurrency_option:!0}},{command_id:"preamble",command:"preamble",category:"workflow",description:"Show a short-lived thought bubble above this agent node.",schemas:[Jj],examples:f0.filter((X)=>X.command_id==="preamble")},{command_id:"request.escalate",command:"escalate",category:"workflow",description:"Escalate to operator: create request, block seat, return stop directive.",schemas:[$j],examples:f0.filter((X)=>X.command_id==="request.escalate")},{command_id:"artifact.publish",command:"artifact publish",category:"workflow",description:"Publish an artifact (batch-capable).",schemas:[Zj],examples:f0.filter((X)=>X.command_id==="artifact.publish"),batch:{accepts_batch:!0,default_concurrency:C6,supports_concurrency_option:!0}},{command_id:"content.path",command:"content path",category:"workflow",description:"Resolve an authorized task ContentRef to a local path.",schemas:[Kj],examples:f0.filter((X)=>X.command_id==="content.path")},{command_id:"content.stat",command:"content stat",category:"workflow",description:"Inspect availability for an authorized task ContentRef.",schemas:[Hj],examples:f0.filter((X)=>X.command_id==="content.stat")},{command_id:"content.materialize",command:"content materialize",category:"workflow",description:"Materialize an authorized task ContentRef into the task workspace.",schemas:[Wj],examples:f0.filter((X)=>X.command_id==="content.materialize")},{command_id:"pad.read",command:"pad read",category:"workflow",description:"Read a connected pad (grant pad.read): revision, IR, digest, SVG.",schemas:[Uj],examples:f0.filter((X)=>X.command_id==="pad.read")},{command_id:"pad.patch",command:"pad patch",category:"workflow",description:"Apply PadPatch (grant pad.patch). Agent ink/image refused; mentions must be inbound actors.",schemas:[Dj],examples:f0.filter((X)=>X.command_id==="pad.patch"),batch:{accepts_batch:!0,default_concurrency:C6,supports_concurrency_option:!0}},{command_id:"pad.digest",command:"pad digest",category:"workflow",description:"Text IR of a connected pad (grant pad.read).",schemas:[Nj],examples:f0.filter((X)=>X.command_id==="pad.digest")},{command_id:"pad.svg",command:"pad svg",category:"workflow",description:"SVG picture of a connected pad (grant pad.read).",schemas:[Bj],examples:f0.filter((X)=>X.command_id==="pad.svg")},{command_id:"pad.look-here",command:"pad look-here",category:"workflow",description:"Crop around a pin (grant pad.read). Mentions are inbound wired actors.",schemas:[Vj],examples:f0.filter((X)=>X.command_id==="pad.look-here")},{command_id:"pad.get",command:"pad get",category:"workflow",description:"Focused items from a connected pad (grant pad.read).",schemas:[qj],examples:f0.filter((X)=>X.command_id==="pad.get")},{command_id:"pad.tagged",command:"pad tagged",category:"workflow",description:"Pins mentioning this process-bound seat (grant pad.read).",schemas:[zj],examples:f0.filter((X)=>X.command_id==="pad.tagged")},...nG?[{command_id:"browser.pages",command:"browser pages",category:"discovery",description:"List page nodes granted through browser.automate edges.",schemas:[Oj],examples:f0.filter((X)=>X.command_id==="browser.pages")},{command_id:"browser.open",command:"browser open",category:"workflow",description:"Open or reuse a granted page session.",schemas:[Lj],examples:f0.filter((X)=>X.command_id==="browser.open")},{command_id:"browser.goto",command:"browser goto",category:"workflow",description:"Navigate an admitted browser session.",schemas:[Tj]},{command_id:"browser.eval",command:"browser eval",category:"workflow",description:"Evaluate JavaScript in an admitted browser session.",schemas:[Rj]},{command_id:"browser.screenshot",command:"browser shot",category:"workflow",description:"Capture a server-owned page screenshot.",schemas:[Fj]},{command_id:"browser.close",command:"browser close",category:"workflow",description:"Detach a browser surface while keeping its session warm.",schemas:[Ej]},{command_id:"browser.stop",command:"browser stop",category:"workflow",description:"Destroy an admitted browser session.",schemas:[Aj]}]:[]];import{constants as K0}from"node:sqlite";var Pj=`
  CREATE TABLE IF NOT EXISTS browser_profiles (
    id TEXT PRIMARY KEY
      CHECK (
        length(id) BETWEEN 1 AND 63
        AND substr(id, 1, 1) GLOB '[a-z0-9]'
        AND id NOT GLOB '*[^a-z0-9-]*'
      ),
    label TEXT
      CHECK (
        label IS NULL
        OR (
          length(label) > 0
          AND length(CAST(label AS BLOB)) <= 128
        )
      ),
    created_at TEXT NOT NULL CHECK (length(created_at) > 0),
    last_used_at TEXT CHECK (last_used_at IS NULL OR length(last_used_at) > 0),
    sort_order INTEGER NOT NULL UNIQUE CHECK (sort_order >= 0)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS browser_profile_settings (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    version INTEGER NOT NULL CHECK (version = 1),
    default_profile TEXT NOT NULL
      REFERENCES browser_profiles(id) ON DELETE RESTRICT,
    max_warm_sessions INTEGER NOT NULL
      CHECK (max_warm_sessions BETWEEN 1 AND ${X_}),
    max_visible_surfaces INTEGER NOT NULL
      CHECK (max_visible_surfaces BETWEEN 1 AND ${Y_})
  ) STRICT;

  CREATE TABLE IF NOT EXISTS browser_profile_canvas_defaults (
    canvas_name TEXT PRIMARY KEY
      CHECK (
        length(canvas_name) BETWEEN 1 AND 63
        AND substr(canvas_name, 1, 1) GLOB '[a-z0-9]'
        AND canvas_name NOT GLOB '*[^a-z0-9-]*'
      ),
    profile_id TEXT NOT NULL
      REFERENCES browser_profiles(id) ON DELETE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS browser_profile_pending_wipe (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    wipe_id TEXT NOT NULL UNIQUE CHECK (length(wipe_id) = 36),
    profile_id TEXT NOT NULL UNIQUE
      REFERENCES browser_profiles(id) ON DELETE RESTRICT,
    partition TEXT NOT NULL
      CHECK (partition = 'persist:vellum-profile-' || profile_id),
    requested_at TEXT NOT NULL CHECK (length(requested_at) > 0),
    stage TEXT NOT NULL
      CHECK (stage IN ('live_clear_pending', 'restart_delete_pending')),
    storage_path TEXT NOT NULL
      CHECK (length(CAST(storage_path AS BLOB)) BETWEEN 1 AND 4096),
    user_data_path TEXT NOT NULL
      CHECK (length(CAST(user_data_path AS BLOB)) BETWEEN 1 AND 4096),
    session_data_path TEXT NOT NULL
      CHECK (length(CAST(session_data_path AS BLOB)) BETWEEN 1 AND 4096)
  ) STRICT;

  CREATE TRIGGER IF NOT EXISTS browser_profiles_limit
  BEFORE INSERT ON browser_profiles
  WHEN (SELECT count(*) FROM browser_profiles) >= 64
  BEGIN
    SELECT RAISE(ABORT, 'browser profile limit reached');
  END;

  CREATE TRIGGER IF NOT EXISTS browser_profile_canvas_defaults_limit
  BEFORE INSERT ON browser_profile_canvas_defaults
  WHEN (SELECT count(*) FROM browser_profile_canvas_defaults) >= 256
  BEGIN
    SELECT RAISE(ABORT, 'browser canvas-default limit reached');
  END;
`;var wj=`
  CREATE TABLE IF NOT EXISTS box_resources (
    box_id TEXT PRIMARY KEY
      CHECK (
        length(box_id) = 11
        AND box_id GLOB 'bx_[23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz]'
      ),
    host_id TEXT UNIQUE
      REFERENCES host_registry(id) ON DELETE RESTRICT,
    name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 255),
    machine_ip TEXT,
    machine_state TEXT NOT NULL CHECK (length(machine_state) BETWEEN 1 AND 32),
    provider_created_at TEXT CHECK (
      provider_created_at IS NULL OR length(provider_created_at) > 0
    ),
    provider_updated_at TEXT CHECK (
      provider_updated_at IS NULL OR length(provider_updated_at) > 0
    ),
    ssh_prepared_at TEXT CHECK (
      ssh_prepared_at IS NULL OR length(ssh_prepared_at) > 0
    ),
    ssh_verified_at TEXT CHECK (
      ssh_verified_at IS NULL OR length(ssh_verified_at) > 0
    ),
    enrolled_at TEXT NOT NULL CHECK (length(enrolled_at) > 0)
  ) STRICT;

  CREATE TRIGGER IF NOT EXISTS box_resources_immutable_identity
  BEFORE UPDATE OF box_id ON box_resources
  BEGIN
    SELECT RAISE(ABORT, 'Box ownership identity is immutable');
  END;
`;var _J=`
  CREATE TABLE IF NOT EXISTS canvas_entities (
    canvas_name TEXT NOT NULL
      CHECK (
        length(canvas_name) BETWEEN 1 AND 64
        AND canvas_name GLOB '[a-z0-9]*'
        AND canvas_name NOT GLOB '*[^a-z0-9_-]*'
      ),
    entity_id TEXT NOT NULL
      CHECK (length(entity_id) BETWEEN 1 AND 256),
    kind TEXT
      CHECK (kind IS NULL OR length(kind) BETWEEN 1 AND 128),
    binding_id TEXT
      CHECK (
        binding_id IS NULL
        OR length(binding_id) BETWEEN 1 AND 256
      ),
    lifecycle TEXT NOT NULL
      CHECK (lifecycle IN ('active', 'archived', 'soft_deleted')),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    archived_at TEXT
      CHECK (archived_at IS NULL OR length(archived_at) BETWEEN 1 AND 64),
    soft_deleted_at TEXT
      CHECK (
        soft_deleted_at IS NULL
        OR length(soft_deleted_at) BETWEEN 1 AND 64
      ),
    PRIMARY KEY (canvas_name, entity_id),
    CHECK (
      (lifecycle = 'active' AND archived_at IS NULL AND soft_deleted_at IS NULL)
      OR (
        lifecycle = 'archived'
        AND archived_at IS NOT NULL
        AND soft_deleted_at IS NULL
      )
      OR (
        lifecycle = 'soft_deleted'
        AND archived_at IS NOT NULL
        AND soft_deleted_at IS NOT NULL
      )
    )
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS canvas_entities_lifecycle
    ON canvas_entities(canvas_name, lifecycle, updated_at, entity_id);

  -- Only one *active* entity may hold a binding on a canvas. Archived and
  -- soft_deleted rows retain binding_id for audit without blocking re-bind.
  CREATE UNIQUE INDEX IF NOT EXISTS canvas_entities_canvas_binding
    ON canvas_entities(canvas_name, binding_id)
    WHERE binding_id IS NOT NULL AND lifecycle = 'active';
`;var Cj=`
  CREATE TABLE IF NOT EXISTS host_registry (
    id TEXT PRIMARY KEY
      CHECK (
        length(id) BETWEEN 1 AND 64
        AND substr(id, 1, 1) GLOB '[A-Za-z0-9]'
        AND id NOT GLOB '*[^A-Za-z0-9._-]*'
      ),
    label TEXT NOT NULL
      CHECK (length(label) BETWEEN 1 AND 64),
    kind TEXT NOT NULL
      CHECK (kind IN ('local', 'remote')),
    ssh_endpoint TEXT UNIQUE,
    ssh_identity_file TEXT
      CHECK (
        ssh_identity_file IS NULL
        OR (
          length(ssh_identity_file) BETWEEN 1 AND 1024
          AND substr(ssh_identity_file, 1, 1) = '/'
        )
      ),
    ssh_host_key_policy TEXT
      CHECK (
        ssh_host_key_policy IS NULL
        OR ssh_host_key_policy IN ('system', 'accept-new')
      ),
    capability_mask INTEGER,
    hermes_id TEXT
      CHECK (
        hermes_id IS NULL
        OR (
          length(hermes_id) BETWEEN 1 AND 64
          AND substr(hermes_id, 1, 1) GLOB '[A-Za-z0-9]'
          AND hermes_id NOT GLOB '*[^A-Za-z0-9._-]*'
        )
      ),
    effective_hermes_id TEXT UNIQUE,
    appearance_color TEXT,
    appearance_glyph TEXT,
    sort_order INTEGER NOT NULL UNIQUE
      CHECK (sort_order >= 0),
    CHECK (
      (
        kind = 'local'
        AND id = 'local'
        AND ssh_endpoint IS NULL
        AND ssh_identity_file IS NULL
        AND ssh_host_key_policy IS NULL
        AND capability_mask IS NULL
        AND sort_order = 0
      )
      OR
      (
        kind = 'remote'
        AND id <> 'local'
        AND (
          ssh_endpoint IS NULL
          OR length(ssh_endpoint) BETWEEN 1 AND 255
        )
        AND (
          ssh_endpoint IS NOT NULL
          OR (
            ssh_identity_file IS NULL
            AND ssh_host_key_policy IS NULL
          )
        )
        AND capability_mask BETWEEN 1 AND 15
        AND sort_order > 0
      )
    ),
    CHECK (
      (
        (
          kind = 'local'
          OR (capability_mask & 8) <> 0
        )
        AND effective_hermes_id IS NOT NULL
        AND effective_hermes_id = coalesce(hermes_id, id)
      )
      OR
      (
        kind = 'remote'
        AND (capability_mask & 8) = 0
        AND effective_hermes_id IS NULL
      )
    )
  ) STRICT;

  CREATE TABLE IF NOT EXISTS host_registry_state (
    singleton INTEGER PRIMARY KEY
      CHECK (singleton = 1),
    version INTEGER NOT NULL
      CHECK (version = 1),
    initialized_at TEXT NOT NULL
      CHECK (length(initialized_at) > 0)
  ) STRICT;

  CREATE TRIGGER IF NOT EXISTS host_registry_retain_local
  BEFORE DELETE ON host_registry
  WHEN OLD.id = 'local'
  BEGIN
    SELECT RAISE(ABORT, 'the local host is immutable');
  END;
`;var Mj=`
  CREATE TABLE IF NOT EXISTS kernel_armed_regions (
    canvas_name TEXT NOT NULL
      CHECK (
        length(canvas_name) BETWEEN 1 AND 64
        AND canvas_name GLOB '[a-z0-9]*'
        AND canvas_name NOT GLOB '*[^a-z0-9_-]*'
      ),
    region_id TEXT NOT NULL CHECK (length(region_id) BETWEEN 1 AND 1024),
    armed_at TEXT NOT NULL CHECK (length(armed_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, region_id)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS kernel_debug_pulses (
    position INTEGER PRIMARY KEY CHECK (position BETWEEN 0 AND 19),
    id TEXT NOT NULL CHECK (length(id) BETWEEN 1 AND 256),
    at_epoch_ms INTEGER NOT NULL CHECK (at_epoch_ms >= 0),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 64),
    source_node_id TEXT NOT NULL
      CHECK (length(source_node_id) BETWEEN 1 AND 1024),
    region_id TEXT CHECK (
      region_id IS NULL OR length(region_id) BETWEEN 1 AND 1024
    ),
    kind TEXT NOT NULL CHECK (kind IN ('watcher', 'timer', 'manual')),
    summary TEXT NOT NULL CHECK (length(summary) BETWEEN 1 AND 4096),
    delivered_json TEXT NOT NULL
      CHECK (
        json_valid(delivered_json)
        AND json_type(delivered_json) = 'array'
        AND length(CAST(delivered_json AS BLOB)) <= 65536
      ),
    dry INTEGER NOT NULL CHECK (dry IN (0, 1)),
    recorded_at TEXT NOT NULL CHECK (length(recorded_at) BETWEEN 1 AND 64)
  ) STRICT;
`;var Ij=[`
    CREATE TABLE IF NOT EXISTS license_activation (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      record_version INTEGER NOT NULL
        CHECK (record_version = 1),
      activated_license_json TEXT NOT NULL
        CHECK (
          length(CAST(activated_license_json AS BLOB)) BETWEEN 2
            AND 16384
          AND json_valid(activated_license_json)
          AND json_type(activated_license_json) = 'object'
        ),
      updated_at TEXT NOT NULL
        CHECK (length(updated_at) BETWEEN 20 AND 64)
    ) STRICT, WITHOUT ROWID
  `],GJ=`${Ij.join(`;
`)};
`,jj=[`
    CREATE TABLE IF NOT EXISTS license_entitlement (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      record_version INTEGER NOT NULL
        CHECK (record_version = 2),
      activated_license_json TEXT NOT NULL
        CHECK (
          length(CAST(activated_license_json AS BLOB)) BETWEEN 2
            AND 16384
          AND json_valid(activated_license_json)
          AND json_type(activated_license_json) = 'object'
        ),
      updated_at TEXT NOT NULL
        CHECK (length(updated_at) BETWEEN 20 AND 64)
    ) STRICT, WITHOUT ROWID
  `],JJ=`${jj.join(`;
`)};
`,X80=[...Ij,...jj],qK0=`${X80.join(`;
`)};
`;var Sj=`
  CREATE TABLE IF NOT EXISTS factory_pause_canvases (
    canvas_name TEXT PRIMARY KEY
      CHECK (
        length(canvas_name) BETWEEN 1 AND 64
        AND canvas_name GLOB '[a-z0-9]*'
        AND canvas_name NOT GLOB '*[^a-z0-9_-]*'
      ),
    playing INTEGER NOT NULL CHECK (playing IN (0, 1)),
    ever_played INTEGER NOT NULL CHECK (ever_played IN (0, 1)),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS factory_pause_scopes (
    canvas_name TEXT NOT NULL
      REFERENCES factory_pause_canvases(canvas_name) ON DELETE CASCADE,
    scope_kind TEXT NOT NULL CHECK (scope_kind IN ('node', 'region')),
    scope_id TEXT NOT NULL CHECK (length(scope_id) BETWEEN 1 AND 1024),
    paused_at TEXT NOT NULL CHECK (length(paused_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, scope_kind, scope_id)
  ) STRICT, WITHOUT ROWID;
`;var vj=64;var xj=/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/;var $J=KX.empty(),Y80=["msg.list","msg.send"],Q80=w6(...Y80),_80=w6("tasks.list","tasks.create","tasks.claim","tasks.update","msg.list","msg.send"),G80=w6("request.escalate","msg.list","msg.send"),J80=w6("artifact.publish"),$80=w6("browser.automate"),Z80=w6("board.list","board.create_topic","board.post","board.mark_read"),K80=w6("pad.read","pad.patch"),H80={agent:{kind:"agent",role:"actor",offers:Q80},page:{kind:"page",role:"sink",offers:$80},task:{kind:"task",role:"sink",offers:_80},requests:{kind:"requests",role:"sink",offers:G80},artifacts:{kind:"artifacts",role:"sink",offers:J80},board:{kind:"board",role:"sink",offers:Z80},pad:{kind:"pad",role:"sink",offers:K80},terminal:{kind:"terminal",role:"sink",offers:$J},watcher:{kind:"watcher",role:"scheduler",offers:$J},timer:{kind:"timer",role:"scheduler",offers:$J},cron:{kind:"cron",role:"scheduler",offers:$J},relay:{kind:"relay",role:"scheduler",offers:w6("relay.trigger")}},EK0=iY.fromIterable(nM.map((X)=>[X,H80[X]])),AK0=A4.taggedEnum();var kj=["command-center","remote"];var vU=1,bj=$.Literals(["dark","bright","system"]),gj=$.Literals(["comfortable","compact"]),U_=(X,Y)=>$.Number.pipe($.check($.isInt()),$.check($.isBetween({minimum:X,maximum:Y}))),yj=$.Literals(["follow","agent"]),xU=$.Struct({theme:bj,density:gj,reduceMotion:$.Boolean,agentAppearance:$.optionalKey(yj)}),hj=$.String.pipe($.check($.isMaxLength(vj)),$.check($.isPattern(new RegExp(`^$|${xj.source}`)))),kU=$.Struct({defaultCanvas:hj,showMinimap:$.Boolean,fitOnOpen:$.Boolean}),bU=$.Struct({pulseLogRetention:$.optionalKey(U_(5,500)),debugVerbose:$.Boolean}),gU=$.Struct({maxVisibleSurfaces:U_(1,Y_),maxWarmSessions:U_(1,X_)}),yU=$.Struct({openLastCanvas:$.Boolean,logsExplorer:$.optionalKey($.Boolean)}),d9=(X)=>$.String.pipe($.check($.isMaxLength(X))),W80=$.Struct({enabled:$.optionalKey($.Boolean),model:$.optionalKey(d9(200)),effort:$.optionalKey(d9(64)),permissionMode:$.optionalKey(d9(64))}),hU=$.Struct({byHarness:$.Record($.String,W80)}),mj=$.Literals(["fine","balanced","coarse"]),mU=$.Struct({ditherLevel:mj,remoteManagedInstalls:$.Boolean}),dj=$.Literals([...kj,""]),ZJ=$.String.pipe($.check($.isMinLength(1)),$.check($.isMaxLength(64)),$.check($.isPattern(/^(?!-)[A-Za-z0-9][A-Za-z0-9._-]*$/))),kK0=$.Unknown.pipe($.check($.makeFilter((X)=>!(X!==null&&typeof X==="object"&&!Array.isArray(X)&&Object.prototype.hasOwnProperty.call(X,"topologyIntegrity")),{message:"topologyIntegrity is retired and must not be supplied"}))),U80=$.Struct({role:dj,hostId:ZJ,agentHostId:$.optionalKey(ZJ),supervisedPreferred:$.Boolean}),dU=U80,KJ=$.Number.pipe($.check($.isBetween({minimum:0,maximum:1}))),H_=$.Struct({enabled:$.Boolean,volume:KJ}),D80=$.Struct({blocked:H_,permission:H_,herdrDone:H_,orphan:H_,cycle:H_}),fU=$.Struct({muted:$.Boolean,masterVolume:KJ,clips:D80}),bK0=$.Struct({version:$.Literal(vU),appearance:xU,canvas:kU,kernel:bU,browser:gU,advanced:yU,audio:fU,station:dU,fleet:mU,harnesses:$.optionalKey(hU)}),N80=$.Struct({theme:$.optionalKey(bj),density:$.optionalKey(gj),reduceMotion:$.optionalKey($.Boolean),agentAppearance:$.optionalKey(yj)}),B80=$.Struct({defaultCanvas:$.optionalKey(hj),showMinimap:$.optionalKey($.Boolean),fitOnOpen:$.optionalKey($.Boolean)}),V80=$.Struct({debugVerbose:$.optionalKey($.Boolean)}),q80=$.Struct({maxVisibleSurfaces:$.optionalKey(U_(1,Y_)),maxWarmSessions:$.optionalKey(U_(1,X_))}),z80=$.Struct({openLastCanvas:$.optionalKey($.Boolean),logsExplorer:$.optionalKey($.Boolean)}),O80=$.Struct({enabled:$.optionalKey($.Boolean),model:$.optionalKey(d9(200)),effort:$.optionalKey(d9(64)),permissionMode:$.optionalKey(d9(64))}),L80=$.Struct({byHarness:$.optionalKey($.Record($.String,O80))}),T80=$.Struct({ditherLevel:$.optionalKey(mj),remoteManagedInstalls:$.optionalKey($.Boolean)}),R80=$.Struct({role:$.optionalKey(dj),hostId:$.optionalKey(ZJ),agentHostId:$.optionalKey(ZJ),supervisedPreferred:$.optionalKey($.Boolean)}),F80=R80,W_=$.Struct({enabled:$.optionalKey($.Boolean),volume:$.optionalKey(KJ)}),E80=$.Struct({blocked:$.optionalKey(W_),permission:$.optionalKey(W_),herdrDone:$.optionalKey(W_),orphan:$.optionalKey(W_),cycle:$.optionalKey(W_)}),A80=$.Struct({muted:$.optionalKey($.Boolean),masterVolume:$.optionalKey(KJ),clips:$.optionalKey(E80)}),gK0=$.Struct({appearance:$.optionalKey(N80),canvas:$.optionalKey(B80),kernel:$.optionalKey(V80),browser:$.optionalKey(q80),advanced:$.optionalKey(z80),audio:$.optionalKey(A80),station:$.optionalKey(F80),fleet:$.optionalKey(T80),harnesses:$.optionalKey(L80)}),yK0=$.Literals(["appearance","canvas","kernel","browser","advanced","audio","station","fleet","harnesses"]);var P80=$.Literals(["validation","io","corrupt","unsupported"]);class fj extends $.TaggedErrorClass()("SettingsError",{message:$.String,code:P80}){}var pj=`
  CREATE TABLE IF NOT EXISTS settings_preferences (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    version INTEGER NOT NULL CHECK (version = ${vU}),
    body TEXT NOT NULL
      CHECK (
        json_valid(body)
        AND json_type(body) = 'object'
        AND length(CAST(body AS BLOB)) <= 65536
      ),
    updated_at TEXT NOT NULL CHECK (length(updated_at) > 0)
  ) STRICT;

  CREATE TABLE IF NOT EXISTS settings_initialization (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    initialized_at TEXT NOT NULL CHECK (length(initialized_at) > 0)
  ) STRICT;
`,w80=$.Struct({appearance:xU,canvas:kU,kernel:bU,browser:gU,advanced:yU,audio:fU,fleet:mU,harnesses:$.optionalKey(hU)}),pK0=$.decodeUnknownResult(w80,{onExcessProperty:"error"}),uK0=$.decodeUnknownResult(dU,{onExcessProperty:"error"});var uj=`
  CREATE TABLE IF NOT EXISTS scheduler_interval_state (
    home_station TEXT NOT NULL
      CHECK (
        length(home_station) BETWEEN 1 AND 64
        AND substr(home_station, 1, 1) <> '-'
        AND home_station GLOB '[A-Za-z0-9]*'
        AND home_station NOT GLOB '*[^A-Za-z0-9._-]*'
      ),
    timer_key TEXT NOT NULL CHECK (length(timer_key) BETWEEN 1 AND 512),
    schedule_id TEXT NOT NULL CHECK (length(schedule_id) BETWEEN 1 AND 256),
    interval_milliseconds INTEGER NOT NULL
      CHECK (interval_milliseconds > 0),
    catch_up_policy TEXT NOT NULL
      CHECK (catch_up_policy = 'coalesce-latest'),
    next_due_at_epoch_ms INTEGER NOT NULL
      CHECK (next_due_at_epoch_ms >= 0),
    next_due_slot TEXT NOT NULL
      CHECK (
        length(next_due_slot) > 0
        AND next_due_slot NOT GLOB '*[^0-9]*'
        AND (
          next_due_slot = '0'
          OR substr(next_due_slot, 1, 1) <> '0'
        )
      ),
    last_fired_slot TEXT
      CHECK (
        last_fired_slot IS NULL
        OR (
          length(last_fired_slot) > 0
          AND last_fired_slot NOT GLOB '*[^0-9]*'
          AND (
            last_fired_slot = '0'
            OR substr(last_fired_slot, 1, 1) <> '0'
          )
        )
      ),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (home_station, timer_key)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS scheduler_interval_firings (
    home_station TEXT NOT NULL
      CHECK (length(home_station) BETWEEN 1 AND 64),
    timer_key TEXT NOT NULL CHECK (length(timer_key) BETWEEN 1 AND 512),
    schedule_id TEXT NOT NULL CHECK (length(schedule_id) BETWEEN 1 AND 256),
    catch_up_policy TEXT NOT NULL
      CHECK (catch_up_policy = 'coalesce-latest'),
    claim_slot TEXT NOT NULL
      CHECK (
        length(claim_slot) > 0
        AND claim_slot NOT GLOB '*[^0-9]*'
        AND (
          claim_slot = '0'
          OR substr(claim_slot, 1, 1) <> '0'
        )
      ),
    due_slot TEXT NOT NULL
      CHECK (
        length(due_slot) > 0
        AND due_slot NOT GLOB '*[^0-9]*'
        AND (
          due_slot = '0'
          OR substr(due_slot, 1, 1) <> '0'
        )
      ),
    scheduled_for_epoch_ms INTEGER NOT NULL
      CHECK (scheduled_for_epoch_ms >= 0),
    observed_at_epoch_ms INTEGER NOT NULL
      CHECK (observed_at_epoch_ms >= 0),
    coalesced_missed_slots TEXT NOT NULL
      CHECK (
        length(coalesced_missed_slots) > 0
        AND coalesced_missed_slots NOT GLOB '*[^0-9]*'
        AND (
          coalesced_missed_slots = '0'
          OR substr(coalesced_missed_slots, 1, 1) <> '0'
        )
      ),
    claimed_at TEXT NOT NULL CHECK (length(claimed_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      home_station,
      timer_key,
      schedule_id,
      claim_slot
    )
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS scheduler_interval_due
    ON scheduler_interval_state(
      home_station,
      next_due_at_epoch_ms,
      timer_key
    );
`;var C80=[`
    CREATE TABLE IF NOT EXISTS station_known_installations (
      installation_id TEXT PRIMARY KEY
        CHECK (
          length(installation_id) BETWEEN 1 AND 128
          AND installation_id GLOB '[A-Za-z0-9]*'
          AND installation_id NOT GLOB '*[^A-Za-z0-9._:-]*'
        ),
      registered_at TEXT NOT NULL
        CHECK (length(registered_at) BETWEEN 1 AND 64)
    ) STRICT, WITHOUT ROWID
  `,`
    CREATE TABLE IF NOT EXISTS station_installation (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      installation_id TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL
        CHECK (length(created_at) BETWEEN 1 AND 64),
      FOREIGN KEY (installation_id)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT
  `,`
    CREATE TABLE IF NOT EXISTS station_pairing (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      command_center_installation_id TEXT NOT NULL,
      station_label TEXT NOT NULL
        CHECK (length(station_label) BETWEEN 1 AND 128),
      app_version TEXT NOT NULL
        CHECK (length(app_version) BETWEEN 1 AND 64),
      paired_at TEXT NOT NULL
        CHECK (length(paired_at) BETWEEN 1 AND 64),
      FOREIGN KEY (command_center_installation_id)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT
  `,`
    CREATE TABLE IF NOT EXISTS station_configuration (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      role TEXT NOT NULL
        CHECK (role IN ('command-center', 'remote')),
      host_id TEXT NOT NULL CHECK (length(host_id) BETWEEN 1 AND 64),
      agent_host_id TEXT,
      command_center_installation_id TEXT,
      supervised_preferred INTEGER NOT NULL
        CHECK (supervised_preferred IN (0, 1)),
      configured_at TEXT NOT NULL
        CHECK (length(configured_at) BETWEEN 1 AND 64),
      CHECK (
        (
          role = 'command-center'
          AND agent_host_id IS NULL
          AND command_center_installation_id IS NULL
        )
        OR
        (
          role = 'remote'
          AND agent_host_id IS NOT NULL
          AND length(agent_host_id) BETWEEN 1 AND 64
          AND command_center_installation_id IS NOT NULL
        )
      ),
      FOREIGN KEY (command_center_installation_id)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT
  `,`
    CREATE TABLE IF NOT EXISTS station_projection_versions (
      generation TEXT NOT NULL
        CHECK (
          length(generation) BETWEEN 1 AND 32
          AND generation NOT GLOB '*[^0-9]*'
          AND (generation = '0' OR substr(generation, 1, 1) <> '0')
        ),
      content_sha256 TEXT NOT NULL
        CHECK (
          length(content_sha256) = 64
          AND content_sha256 NOT GLOB '*[^a-f0-9]*'
        ),
      source_canvas_generation TEXT NOT NULL
        CHECK (
          length(source_canvas_generation) BETWEEN 1 AND 32
          AND source_canvas_generation NOT GLOB '*[^0-9]*'
          AND (
            source_canvas_generation = '0'
            OR substr(source_canvas_generation, 1, 1) <> '0'
          )
        ),
      source_intent_sha256 TEXT NOT NULL
        CHECK (
          length(source_intent_sha256) = 64
          AND source_intent_sha256 NOT GLOB '*[^a-f0-9]*'
        ),
      body TEXT NOT NULL
        CHECK (length(body) BETWEEN 1 AND 67108864),
      created_at TEXT NOT NULL
        CHECK (length(created_at) BETWEEN 1 AND 64),
      received_at TEXT NOT NULL
        CHECK (length(received_at) BETWEEN 1 AND 64),
      PRIMARY KEY (generation),
      UNIQUE (generation, content_sha256)
    ) STRICT, WITHOUT ROWID
  `,`
    CREATE TABLE IF NOT EXISTS station_projection_head (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      generation TEXT NOT NULL,
      content_sha256 TEXT NOT NULL,
      FOREIGN KEY (generation, content_sha256)
        REFERENCES station_projection_versions(
          generation,
          content_sha256
        )
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT
  `,`
    CREATE TABLE IF NOT EXISTS station_received_cursors (
      event_home TEXT NOT NULL,
      entity_home TEXT NOT NULL,
      through_sequence TEXT NOT NULL
        CHECK (
          length(through_sequence) BETWEEN 1 AND 32
          AND through_sequence NOT GLOB '*[^0-9]*'
          AND substr(through_sequence, 1, 1) <> '0'
        ),
      updated_at TEXT NOT NULL
        CHECK (length(updated_at) BETWEEN 1 AND 64),
      PRIMARY KEY (event_home, entity_home),
      FOREIGN KEY (event_home)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
      FOREIGN KEY (entity_home)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT, WITHOUT ROWID
  `,`
    CREATE TABLE IF NOT EXISTS station_peer_ack_cursors (
      peer_installation_id TEXT NOT NULL,
      event_home TEXT NOT NULL,
      entity_home TEXT NOT NULL,
      through_sequence TEXT NOT NULL
        CHECK (
          length(through_sequence) BETWEEN 1 AND 32
          AND through_sequence NOT GLOB '*[^0-9]*'
          AND substr(through_sequence, 1, 1) <> '0'
        ),
      acknowledged_at TEXT NOT NULL
        CHECK (length(acknowledged_at) BETWEEN 1 AND 64),
      PRIMARY KEY (
        peer_installation_id,
        event_home,
        entity_home
      ),
      CHECK (peer_installation_id <> event_home),
      FOREIGN KEY (peer_installation_id)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
      FOREIGN KEY (event_home)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
      FOREIGN KEY (entity_home)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT, WITHOUT ROWID
  `,`
    CREATE TABLE IF NOT EXISTS station_fleet_targets (
      host_id TEXT PRIMARY KEY
        CHECK (
          length(host_id) BETWEEN 1 AND 64
          AND substr(host_id, 1, 1) <> '-'
          AND host_id GLOB '[A-Za-z0-9]*'
          AND host_id NOT GLOB '*[^A-Za-z0-9._-]*'
        ),
      station_installation_id TEXT NOT NULL UNIQUE,
      bound_at TEXT NOT NULL
        CHECK (length(bound_at) BETWEEN 1 AND 64),
      retired_at TEXT
        CHECK (
          retired_at IS NULL
          OR length(retired_at) BETWEEN 1 AND 64
        ),
      FOREIGN KEY (station_installation_id)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT, WITHOUT ROWID
  `,`
    CREATE TRIGGER IF NOT EXISTS station_known_installation_identity_immutable
    BEFORE UPDATE OF installation_id ON station_known_installations
    WHEN OLD.installation_id <> NEW.installation_id
    BEGIN
      SELECT RAISE(ABORT, 'known installation identity is immutable');
    END
  `,`
    CREATE TRIGGER IF NOT EXISTS station_local_installation_identity_immutable
    BEFORE UPDATE OF installation_id ON station_installation
    WHEN OLD.installation_id <> NEW.installation_id
    BEGIN
      SELECT RAISE(ABORT, 'local installation identity is immutable');
    END
  `,`
    CREATE TRIGGER IF NOT EXISTS station_projection_version_immutable_update
    BEFORE UPDATE ON station_projection_versions
    BEGIN
      SELECT RAISE(ABORT, 'station projection versions are immutable');
    END
  `,`
    CREATE TRIGGER IF NOT EXISTS station_projection_version_immutable_delete
    BEFORE DELETE ON station_projection_versions
    BEGIN
      SELECT RAISE(ABORT, 'station projection versions are immutable');
    END
  `],cj=`${C80.join(`;
`)};`;var M80=[`
    CREATE TABLE IF NOT EXISTS station_status_facts (
      kind TEXT NOT NULL
        CHECK (
          kind IN (
            'kernel',
            'deployment'
          )
        ),
      host_id TEXT NOT NULL CHECK (length(host_id) <= 64),
      record_json TEXT NOT NULL
        CHECK (
          json_valid(record_json)
          AND json_type(record_json) = 'object'
        ),
      updated_at TEXT NOT NULL CHECK (length(updated_at) > 0),
      PRIMARY KEY (kind, host_id),
      CHECK (
        (kind = 'kernel' AND host_id = '')
        OR (kind = 'deployment' AND length(host_id) > 0)
      )
    ) STRICT, WITHOUT ROWID
  `],lj=`${M80.join(`;
`)};
`;var oj=`
  CREATE TABLE IF NOT EXISTS usage_state (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    snapshots_json TEXT NOT NULL
      CHECK (
        json_valid(snapshots_json)
        AND json_type(snapshots_json) = 'array'
      ),
    last_live_at TEXT NOT NULL CHECK (length(last_live_at) > 0),
    updated_at TEXT NOT NULL CHECK (length(updated_at) > 0)
  ) STRICT;
`;var HJ=`
  -- Immutable verified object identity. Media type / display name live on
  -- content_refs (descriptive metadata is not part of byte identity).
  CREATE TABLE IF NOT EXISTS content_objects (
    sha256 TEXT PRIMARY KEY
      CHECK (
        length(sha256) = 64
        AND sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    byte_length INTEGER NOT NULL
      CHECK (
        typeof(byte_length) = 'integer'
        AND byte_length >= 0
      ),
    created_at TEXT NOT NULL
      CHECK (length(created_at) BETWEEN 1 AND 64),
    verified_at TEXT NOT NULL
      CHECK (length(verified_at) BETWEEN 1 AND 64)
  ) STRICT, WITHOUT ROWID;

  -- Portable references bound to durable work after the object exists.
  CREATE TABLE IF NOT EXISTS content_refs (
    ref_id TEXT PRIMARY KEY
      CHECK (length(ref_id) BETWEEN 1 AND 256),
    sha256 TEXT NOT NULL
      CHECK (
        length(sha256) = 64
        AND sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    byte_length INTEGER NOT NULL
      CHECK (
        typeof(byte_length) = 'integer'
        AND byte_length >= 0
      ),
    media_type TEXT NOT NULL
      CHECK (length(media_type) BETWEEN 1 AND 255),
    display_name TEXT
      CHECK (
        display_name IS NULL
        OR length(display_name) BETWEEN 1 AND 255
      ),
    owner_kind TEXT NOT NULL
      CHECK (
        owner_kind IN (
          'task',
          'message',
          'artifact',
          'board_topic',
          'board_post',
          'other'
        )
      ),
    owner_canvas TEXT NOT NULL
      CHECK (length(owner_canvas) BETWEEN 1 AND 256),
    owner_node TEXT NOT NULL
      CHECK (length(owner_node) BETWEEN 1 AND 256),
    owner_record_id TEXT NOT NULL
      CHECK (length(owner_record_id) BETWEEN 1 AND 256),
    created_at TEXT NOT NULL
      CHECK (length(created_at) BETWEEN 1 AND 64),
    FOREIGN KEY (sha256)
      REFERENCES content_objects(sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS content_refs_by_object
    ON content_refs(sha256, created_at, ref_id);

  CREATE INDEX IF NOT EXISTS content_refs_by_owner
    ON content_refs(owner_canvas, owner_node, owner_kind, owner_record_id);

  -- Verification receipts. Only the verified state is durable here; missing /
  -- corrupt / unavailable are computed at read time from object + file state.
  CREATE TABLE IF NOT EXISTS content_receipts (
    sha256 TEXT PRIMARY KEY
      CHECK (
        length(sha256) = 64
        AND sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    verified_sha256 TEXT NOT NULL
      CHECK (
        length(verified_sha256) = 64
        AND verified_sha256 NOT GLOB '*[^a-f0-9]*'
        AND verified_sha256 = sha256
      ),
    verified_byte_length INTEGER NOT NULL
      CHECK (
        typeof(verified_byte_length) = 'integer'
        AND verified_byte_length >= 0
      ),
    verified_at TEXT NOT NULL
      CHECK (length(verified_at) BETWEEN 1 AND 64),
    FOREIGN KEY (sha256)
      REFERENCES content_objects(sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  -- Transfer bookkeeping for a future cross-Station data plane. Local ingest
  -- does not require rows; schema exists so the next migration is not blocked.
  CREATE TABLE IF NOT EXISTS content_transfers (
    transfer_id TEXT PRIMARY KEY
      CHECK (length(transfer_id) BETWEEN 1 AND 256),
    sha256 TEXT NOT NULL
      CHECK (
        length(sha256) = 64
        AND sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    byte_length INTEGER NOT NULL
      CHECK (
        typeof(byte_length) = 'integer'
        AND byte_length >= 0
      ),
    state TEXT NOT NULL
      CHECK (
        state IN (
          'pending',
          'receiving',
          'verifying',
          'complete',
          'failed',
          'canceled'
        )
      ),
    direction TEXT NOT NULL
      CHECK (direction IN ('inbound', 'outbound')),
    peer_installation_id TEXT
      CHECK (
        peer_installation_id IS NULL
        OR length(peer_installation_id) BETWEEN 1 AND 128
      ),
    error_reason TEXT
      CHECK (
        error_reason IS NULL
        OR length(error_reason) BETWEEN 1 AND 1024
      ),
    created_at TEXT NOT NULL
      CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL
      CHECK (length(updated_at) BETWEEN 1 AND 64)
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS content_transfers_by_object
    ON content_transfers(sha256, state, updated_at);
`,WJ=`
  CREATE TABLE IF NOT EXISTS content_inline_media_migration (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    status TEXT NOT NULL
      CHECK (status IN ('pending', 'complete')),
    objects_ingested INTEGER NOT NULL DEFAULT 0
      CHECK (
        typeof(objects_ingested) = 'integer'
        AND objects_ingested >= 0
      ),
    completed_at TEXT
      CHECK (
        completed_at IS NULL
        OR length(completed_at) BETWEEN 1 AND 64
      )
  ) STRICT;
`;var rj=`
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;
`,pU=`
  CREATE TABLE IF NOT EXISTS work_event_sequences (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    last_seq TEXT NOT NULL
      CHECK (
        length(last_seq) BETWEEN 1 AND 32
        AND last_seq NOT GLOB '*[^0-9]*'
        AND (last_seq = '0' OR substr(last_seq, 1, 1) <> '0')
      ),
    PRIMARY KEY (event_home, entity_home),
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    protocol TEXT NOT NULL CHECK (protocol = 'vellum/work/v2'),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, record_type),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'command'
      CHECK (record_type = 'command'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    action_json TEXT NOT NULL
      CHECK (
        length(action_json) BETWEEN 2 AND 262144
        AND json_valid(action_json)
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home <> entity_home),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_facts (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'fact'
      CHECK (record_type = 'fact'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    result_json TEXT NOT NULL
      CHECK (
        length(result_json) BETWEEN 2 AND 262144
        AND json_valid(result_json)
      ),
    basis_kind TEXT NOT NULL
      CHECK (
        basis_kind IN (
          'authorial-intent',
          'projected-intent',
          'command'
        )
      ),
    basis_authorial_generation TEXT
      CHECK (
        basis_authorial_generation IS NULL
        OR (
          length(basis_authorial_generation) BETWEEN 1 AND 32
          AND basis_authorial_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_authorial_generation = '0'
            OR substr(basis_authorial_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_authorial_content_sha256 TEXT
      CHECK (
        basis_authorial_content_sha256 IS NULL
        OR (
          length(basis_authorial_content_sha256) = 64
          AND basis_authorial_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_projected_generation TEXT
      CHECK (
        basis_projected_generation IS NULL
        OR (
          length(basis_projected_generation) BETWEEN 1 AND 32
          AND basis_projected_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_projected_generation = '0'
            OR substr(basis_projected_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_projected_content_sha256 TEXT
      CHECK (
        basis_projected_content_sha256 IS NULL
        OR (
          length(basis_projected_content_sha256) = 64
          AND basis_projected_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_command_event_home TEXT,
    basis_command_entity_home TEXT,
    basis_command_seq TEXT
      CHECK (
        basis_command_seq IS NULL
        OR (
          length(basis_command_seq) BETWEEN 1 AND 32
          AND basis_command_seq NOT GLOB '*[^0-9]*'
          AND substr(basis_command_seq, 1, 1) <> '0'
        )
      ),
    basis_command_sha256 TEXT
      CHECK (
        basis_command_sha256 IS NULL
        OR (
          length(basis_command_sha256) = 64
          AND basis_command_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home = entity_home),
    CHECK (
      (
        basis_kind = 'authorial-intent'
        AND basis_authorial_generation IS NOT NULL
        AND basis_authorial_content_sha256 IS NOT NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'projected-intent'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NOT NULL
        AND basis_projected_content_sha256 IS NOT NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'command'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NOT NULL
        AND basis_command_entity_home IS NOT NULL
        AND basis_command_seq IS NOT NULL
        AND basis_command_sha256 IS NOT NULL
        AND basis_command_entity_home = entity_home
      )
    ),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (basis_authorial_generation)
      REFERENCES canvas_generations(generation)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_projected_generation,
      basis_projected_content_sha256
    ) REFERENCES station_projection_versions(generation, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq
    ) REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq,
      basis_command_sha256
    ) REFERENCES work_events(
      event_home,
      entity_home,
      seq,
      content_sha256
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_dispositions (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'disposition'
      CHECK (record_type = 'disposition'),
    status TEXT NOT NULL CHECK (status IN ('applied', 'rejected')),
    command_event_home TEXT NOT NULL,
    command_entity_home TEXT NOT NULL,
    command_seq TEXT NOT NULL,
    command_sha256 TEXT NOT NULL
      CHECK (
        length(command_sha256) = 64
        AND command_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT,
    fact_entity_home TEXT,
    fact_seq TEXT,
    fact_sha256 TEXT
      CHECK (
        fact_sha256 IS NULL
        OR (
          length(fact_sha256) = 64
          AND fact_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    rejection_reason TEXT
      CHECK (
        rejection_reason IS NULL
        OR rejection_reason IN (
          'authority-mismatch',
          'capability-denied',
          'causal-conflict',
          'claim-contention',
          'identity-conflict',
          'invalid-transition',
          'locality-mismatch',
          'missing-entity',
          'projection-conflict',
          'target-mismatch'
        )
      ),
    rejection_message TEXT
      CHECK (
        rejection_message IS NULL
        OR length(rejection_message) BETWEEN 1 AND 2048
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, status),
    CHECK (event_home = entity_home),
    CHECK (command_entity_home = entity_home),
    CHECK (
      (
        status = 'applied'
        AND fact_event_home IS NOT NULL
        AND fact_entity_home IS NOT NULL
        AND fact_seq IS NOT NULL
        AND fact_sha256 IS NOT NULL
        AND fact_event_home = event_home
        AND fact_entity_home = entity_home
        AND rejection_reason IS NULL
        AND rejection_message IS NULL
      )
      OR
      (
        status = 'rejected'
        AND fact_event_home IS NULL
        AND fact_entity_home IS NULL
        AND fact_seq IS NULL
        AND fact_sha256 IS NULL
        AND rejection_reason IS NOT NULL
        AND rejection_message IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (command_event_home, command_entity_home, command_seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      command_event_home,
      command_entity_home,
      command_seq,
      command_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      fact_event_home,
      fact_entity_home,
      fact_seq,
      fact_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    claim_actor_seat_id TEXT
      CHECK (
        claim_actor_seat_id IS NULL
        OR (
          length(claim_actor_seat_id) = 69
          AND substr(claim_actor_seat_id, 1, 5) = 'seat_'
          AND substr(claim_actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT
      CHECK (resolved_at IS NULL OR length(resolved_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        operation = 'task.claim'
        AND item_kind = 'task'
        AND claim_actor_seat_id IS NOT NULL
      )
      OR
      (
        operation <> 'task.claim'
        AND claim_actor_seat_id IS NULL
      )
    ),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      resolution_event_home,
      resolution_entity_home,
      resolution_seq,
      resolution_status
    ) REFERENCES work_dispositions(event_home, entity_home, seq, status)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_tasks (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    task_id TEXT NOT NULL CHECK (length(task_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, task_id),
    UNIQUE (canvas_name, node_id, task_id, entity_home),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'submitted' AND actor_seat_id IS NULL)
      OR state IN ('completed', 'canceled', 'failed', 'rejected')
      OR (
        state IN ('working', 'input-required', 'auth-required')
        AND actor_seat_id IS NOT NULL
      )
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_requests (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    request_id TEXT NOT NULL CHECK (length(request_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'input-required',
          'auth-required',
          'completed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, request_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    parent_lane TEXT NOT NULL CHECK (parent_lane IN ('task', 'request')),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    message_kind TEXT NOT NULL CHECK (message_kind IN ('brief', 'history')),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      message_id
    ),
    UNIQUE (canvas_name, node_id, parent_lane, item_id, position),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, message_id),
    UNIQUE (canvas_name, node_id, position),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_artifacts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    artifact_id TEXT NOT NULL CHECK (length(artifact_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    name TEXT,
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_canvas_name TEXT
      CHECK (
        task_canvas_name IS NULL
        OR length(task_canvas_name) BETWEEN 1 AND 256
      ),
    task_node_id TEXT
      CHECK (
        task_node_id IS NULL
        OR length(task_node_id) BETWEEN 1 AND 256
      ),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    task_entity_home TEXT,
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, artifact_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (
        task_canvas_name IS NULL
        AND task_node_id IS NULL
        AND task_id IS NULL
        AND task_entity_home IS NULL
      )
      OR
      (
        task_canvas_name IS NOT NULL
        AND task_node_id IS NOT NULL
        AND task_id IS NOT NULL
        AND task_entity_home IS NOT NULL
      )
    ),
    CHECK (
      task_entity_home IS NULL
      OR task_entity_home = entity_home
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      task_canvas_name,
      task_node_id,
      task_id,
      task_entity_home
    ) REFERENCES work_tasks(
      canvas_name,
      node_id,
      task_id,
      entity_home
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_transitions (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    lane TEXT NOT NULL CHECK (lane IN ('task', 'request')),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve'
        )
      ),
    from_state TEXT,
    to_state TEXT NOT NULL
      CHECK (
        to_state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, item_id, lane, ordinal),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (
      from_state IS NULL
      OR from_state IN (
        'submitted',
        'working',
        'input-required',
        'auth-required',
        'completed',
        'canceled',
        'failed',
        'rejected'
      )
    ),
    CHECK (
      to_state NOT IN ('working', 'input-required', 'auth-required')
      OR actor_seat_id IS NOT NULL
    ),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_delivery_receipts (
    delivery_id TEXT NOT NULL CHECK (length(delivery_id) BETWEEN 1 AND 256),
    delivered_item_kind TEXT NOT NULL
      CHECK (
        delivered_item_kind IN (
          'task',
          'request',
          'message',
          'artifact',
          'delivery'
        )
      ),
    delivered_item_id TEXT NOT NULL
      CHECK (length(delivered_item_id) BETWEEN 1 AND 256),
    delivered_canvas_name TEXT NOT NULL
      CHECK (length(delivered_canvas_name) BETWEEN 1 AND 256),
    delivered_node_id TEXT NOT NULL
      CHECK (length(delivered_node_id) BETWEEN 1 AND 256),
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    actor_canvas_name TEXT NOT NULL
      CHECK (length(actor_canvas_name) BETWEEN 1 AND 256),
    actor_node_id TEXT NOT NULL
      CHECK (length(actor_node_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    accepted_at TEXT NOT NULL CHECK (length(accepted_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      delivered_canvas_name,
      delivered_node_id,
      delivery_id
    ),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_events_route_order
    ON work_events(event_home, entity_home, length(seq), seq);
  CREATE INDEX IF NOT EXISTS work_events_item_history
    ON work_events(
      item_canvas_name,
      item_node_id,
      item_kind,
      item_id,
      entity_home,
      length(seq),
      seq
    );
  CREATE INDEX IF NOT EXISTS work_pending_commands_route
    ON work_pending_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_item
    ON work_pending_commands(
      item_canvas_name,
      item_node_id,
      item_id
    )
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_actor
    ON work_pending_commands(claim_actor_seat_id)
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE INDEX IF NOT EXISTS work_tasks_node
    ON work_tasks(canvas_name, node_id, created_at, task_id);
  CREATE UNIQUE INDEX IF NOT EXISTS work_tasks_one_active_per_actor
    ON work_tasks(actor_seat_id)
    WHERE
      actor_seat_id IS NOT NULL
      AND state IN ('working', 'input-required', 'auth-required');
  CREATE INDEX IF NOT EXISTS work_requests_node
    ON work_requests(canvas_name, node_id, created_at, request_id);
  CREATE INDEX IF NOT EXISTS work_task_messages_thread
    ON work_task_messages(
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      position
    );
  CREATE UNIQUE INDEX IF NOT EXISTS work_task_messages_sink_identity
    ON work_task_messages(canvas_name, node_id, message_id);
  CREATE INDEX IF NOT EXISTS work_messages_inbox
    ON work_messages(canvas_name, node_id, position);
  CREATE INDEX IF NOT EXISTS work_artifacts_node
    ON work_artifacts(canvas_name, node_id, artifact_id);
  CREATE INDEX IF NOT EXISTS work_delivery_receipts_actor
    ON work_delivery_receipts(
      actor_seat_id,
      accepted_at,
      delivery_id
    );

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_update
  BEFORE UPDATE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_delete
  BEFORE DELETE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_update
  BEFORE UPDATE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_delete
  BEFORE DELETE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_fact_authorial_basis_resolves
  BEFORE INSERT ON work_facts
  WHEN
    NEW.basis_kind = 'authorial-intent'
    AND NOT EXISTS (
      SELECT 1
      FROM canvas_generations AS generation
      JOIN canvas_generation_documents AS document
        ON document.generation = generation.generation
      JOIN work_events AS record
        ON record.event_home = NEW.event_home
        AND record.entity_home = NEW.entity_home
        AND record.seq = NEW.seq
      WHERE generation.generation = NEW.basis_authorial_generation
        AND generation.intent_sha256 =
          NEW.basis_authorial_content_sha256
        AND document.name = record.item_canvas_name
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'authorial fact basis must resolve its exact sink canvas generation'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_update
  BEFORE UPDATE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_delete
  BEFORE DELETE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_applied_disposition_fact_basis_matches
  BEFORE INSERT ON work_dispositions
  WHEN
    NEW.status = 'applied'
    AND NOT EXISTS (
      SELECT 1
      FROM work_facts AS fact
      WHERE fact.event_home = NEW.fact_event_home
        AND fact.entity_home = NEW.fact_entity_home
        AND fact.seq = NEW.fact_seq
        AND fact.basis_kind = 'command'
        AND fact.basis_command_event_home = NEW.command_event_home
        AND fact.basis_command_entity_home = NEW.command_entity_home
        AND fact.basis_command_seq = NEW.command_seq
        AND fact.basis_command_sha256 = NEW.command_sha256
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'applied disposition fact must carry its exact command basis'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_update
  BEFORE UPDATE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_delete
  BEFORE DELETE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_matches_record
  BEFORE INSERT ON work_pending_commands
  WHEN NOT EXISTS (
    SELECT 1
    FROM work_events AS record
    WHERE record.event_home = NEW.event_home
      AND record.entity_home = NEW.entity_home
      AND record.seq = NEW.seq
      AND record.record_type = 'command'
      AND record.operation = NEW.operation
      AND record.item_kind = NEW.item_kind
      AND record.item_canvas_name = NEW.item_canvas_name
      AND record.item_node_id = NEW.item_node_id
      AND record.item_id = NEW.item_id
  )
  BEGIN
    SELECT RAISE(ABORT, 'pending command metadata must match its Work command');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_identity_immutable
  BEFORE UPDATE OF
    event_home,
    entity_home,
    seq,
    operation,
    item_kind,
    item_canvas_name,
    item_node_id,
    item_id,
    claim_actor_seat_id
  ON work_pending_commands
  WHEN
    OLD.event_home IS NOT NEW.event_home
    OR OLD.entity_home IS NOT NEW.entity_home
    OR OLD.seq IS NOT NEW.seq
    OR OLD.operation IS NOT NEW.operation
    OR OLD.item_kind IS NOT NEW.item_kind
    OR OLD.item_canvas_name IS NOT NEW.item_canvas_name
    OR OLD.item_node_id IS NOT NEW.item_node_id
    OR OLD.item_id IS NOT NEW.item_id
    OR OLD.claim_actor_seat_id IS NOT NEW.claim_actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'pending command identity is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_initial_resolution_matches
  BEFORE INSERT ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = NEW.event_home
        AND disposition.command_entity_home = NEW.entity_home
        AND disposition.command_seq = NEW.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_matches
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = OLD.event_home
        AND disposition.command_entity_home = OLD.entity_home
        AND disposition.command_seq = OLD.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_once
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    OLD.resolution_event_home IS NOT NULL
    AND (
      OLD.resolution_status IS NOT NEW.resolution_status
      OR OLD.resolution_event_home IS NOT NEW.resolution_event_home
      OR OLD.resolution_entity_home IS NOT NEW.resolution_entity_home
      OR OLD.resolution_seq IS NOT NEW.resolution_seq
      OR OLD.resolved_at IS NOT NEW.resolved_at
    )
  BEGIN
    SELECT RAISE(ABORT, 'pending command resolution is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_home_immutable
  BEFORE UPDATE OF entity_home ON work_tasks
  WHEN
    OLD.entity_home <> NEW.entity_home
    AND NOT (
      OLD.state = 'submitted'
      AND OLD.actor_seat_id IS NULL
      AND NEW.state = 'working'
      AND NEW.actor_seat_id IS NOT NULL
      AND NEW.entity_home = NEW.fact_entity_home
      AND NEW.fact_event_home = NEW.fact_entity_home
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task home is immutable except for first claim adoption'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_tasks
  WHEN
    OLD.actor_seat_id IS NOT NULL
    AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
    AND NOT (
      NEW.actor_seat_id IS NULL
      AND NEW.state = 'submitted'
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task actor seat is immutable except for operator release'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_home_immutable
  BEFORE UPDATE OF entity_home ON work_requests
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work request home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_requests
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work request actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work task message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_require_exact_parent
  BEFORE INSERT ON work_task_messages
  WHEN NOT (
    (
      NEW.parent_lane = 'task'
      AND EXISTS (
        SELECT 1
        FROM work_tasks
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND task_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
    OR
    (
      NEW.parent_lane = 'request'
      AND EXISTS (
        SELECT 1
        FROM work_requests
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND request_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
  )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task message requires an exact same-home parent'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_require_cc_home
  BEFORE INSERT ON work_messages
  WHEN
    NOT EXISTS (
      SELECT 1
      FROM station_configuration AS configuration
      JOIN station_installation AS installation
        ON installation.singleton = configuration.singleton
      WHERE configuration.singleton = 1
        AND configuration.role = 'command-center'
        AND NEW.entity_home = installation.installation_id
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work mailbox messages must be Command Center-homed'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_messages
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work message actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_home_immutable
  BEFORE UPDATE OF entity_home ON work_artifacts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_artifacts
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work artifact actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_require_claimed_task
  BEFORE INSERT ON work_artifacts
  WHEN
    NEW.task_id IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
    )
    AND NOT EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
        AND actor_seat_id IS NOT NULL
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work artifact requires an exact claimed same-home task'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_task_reference_immutable
  BEFORE UPDATE OF
    task_canvas_name,
    task_node_id,
    task_id,
    task_entity_home
  ON work_artifacts
  WHEN
    OLD.task_canvas_name IS NOT NEW.task_canvas_name
    OR OLD.task_node_id IS NOT NEW.task_node_id
    OR OLD.task_id IS NOT NEW.task_id
    OR OLD.task_entity_home IS NOT NEW.task_entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact task reference is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_transitions_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_transitions
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work transition home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_delivery_receipts_home_immutable
  BEFORE UPDATE OF entity_home ON work_delivery_receipts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work delivery receipt home is immutable');
  END;
  
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;

`,UJ=`
  CREATE TABLE IF NOT EXISTS work_task_dependencies (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    task_id TEXT NOT NULL CHECK (length(task_id) BETWEEN 1 AND 256),
    depends_on_task_id TEXT NOT NULL
      CHECK (length(depends_on_task_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    PRIMARY KEY (canvas_name, node_id, task_id, depends_on_task_id),
    FOREIGN KEY (canvas_name, node_id, task_id)
      REFERENCES work_tasks(canvas_name, node_id, task_id)
      ON DELETE CASCADE
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_dependencies_dep
    ON work_task_dependencies(canvas_name, node_id, depends_on_task_id);
`,DJ=`
  CREATE TABLE IF NOT EXISTS work_task_finish (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    task_id TEXT NOT NULL CHECK (length(task_id) BETWEEN 1 AND 256),
    finish_criteria_json TEXT
      CHECK (finish_criteria_json IS NULL OR json_valid(finish_criteria_json)),
    completion_evidence_json TEXT
      CHECK (
        completion_evidence_json IS NULL
        OR json_valid(completion_evidence_json)
      ),
    PRIMARY KEY (canvas_name, node_id, task_id),
    FOREIGN KEY (canvas_name, node_id, task_id)
      REFERENCES work_tasks(canvas_name, node_id, task_id)
      ON DELETE CASCADE
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;
`,NJ=`
  CREATE TABLE IF NOT EXISTS work_proposal_planning (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    depends_on_json TEXT
      CHECK (depends_on_json IS NULL OR json_valid(depends_on_json)),
    finish_criteria_json TEXT
      CHECK (finish_criteria_json IS NULL OR json_valid(finish_criteria_json)),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    FOREIGN KEY (canvas_name, node_id, proposal_id)
      REFERENCES work_task_proposals(canvas_name, node_id, proposal_id)
      ON DELETE CASCADE
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;
`,D_=`
  CREATE TABLE IF NOT EXISTS work_board_topics (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    title TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 512),
    state TEXT NOT NULL CHECK (state IN ('open', 'archived')),
    author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
    author_seat_id TEXT
      CHECK (
        author_seat_id IS NULL
        OR (
          length(author_seat_id) = 69
          AND substr(author_seat_id, 1, 5) = 'seat_'
          AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    author_node_id TEXT
      CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
    author_label TEXT
      CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    post_count INTEGER NOT NULL DEFAULT 0 CHECK (post_count >= 0),
    last_activity_at TEXT NOT NULL CHECK (length(last_activity_at) BETWEEN 1 AND 64),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_board_posts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    post_id TEXT NOT NULL CHECK (length(post_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
    author_seat_id TEXT
      CHECK (
        author_seat_id IS NULL
        OR (
          length(author_seat_id) = 69
          AND substr(author_seat_id, 1, 5) = 'seat_'
          AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    author_node_id TEXT
      CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
    author_label TEXT
      CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, post_id),
    UNIQUE (canvas_name, node_id, topic_id, position),
    FOREIGN KEY (canvas_name, node_id, topic_id)
      REFERENCES work_board_topics(canvas_name, node_id, topic_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_board_read_cursors (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    principal_key TEXT NOT NULL CHECK (length(principal_key) BETWEEN 1 AND 256),
    last_read_position INTEGER NOT NULL CHECK (last_read_position >= -1),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, principal_key)
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_board_topics_node
    ON work_board_topics(canvas_name, node_id, last_activity_at, topic_id);
  CREATE INDEX IF NOT EXISTS work_board_posts_thread
    ON work_board_posts(canvas_name, node_id, topic_id, position);
`;var ij=`
  CREATE TABLE IF NOT EXISTS work_board_topics (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    title TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 512),
    state TEXT NOT NULL CHECK (state IN ('open', 'archived')),
    author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
    author_seat_id TEXT
      CHECK (
        author_seat_id IS NULL
        OR (
          length(author_seat_id) = 69
          AND substr(author_seat_id, 1, 5) = 'seat_'
          AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    author_node_id TEXT
      CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
    author_label TEXT
      CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    post_count INTEGER NOT NULL DEFAULT 0 CHECK (post_count >= 0),
    last_activity_at TEXT NOT NULL CHECK (length(last_activity_at) BETWEEN 1 AND 64),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_board_posts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    post_id TEXT NOT NULL CHECK (length(post_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
    author_seat_id TEXT
      CHECK (
        author_seat_id IS NULL
        OR (
          length(author_seat_id) = 69
          AND substr(author_seat_id, 1, 5) = 'seat_'
          AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    author_node_id TEXT
      CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
    author_label TEXT
      CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, post_id),
    UNIQUE (canvas_name, node_id, topic_id, position),
    FOREIGN KEY (canvas_name, node_id, topic_id)
      REFERENCES work_board_topics(canvas_name, node_id, topic_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_board_read_cursors (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    principal_key TEXT NOT NULL CHECK (length(principal_key) BETWEEN 1 AND 256),
    last_read_position INTEGER NOT NULL CHECK (last_read_position >= -1),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, principal_key)
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_board_topics_node
    ON work_board_topics(canvas_name, node_id, last_activity_at, topic_id);
  CREATE INDEX IF NOT EXISTS work_board_posts_thread
    ON work_board_posts(canvas_name, node_id, topic_id, position);
`.replace(`parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, post_id),`,`parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    tags_json TEXT
      CHECK (tags_json IS NULL OR json_valid(tags_json)),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, post_id),`),O5=`
  CREATE TABLE IF NOT EXISTS work_event_sequences (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    last_seq TEXT NOT NULL
      CHECK (
        length(last_seq) BETWEEN 1 AND 32
        AND last_seq NOT GLOB '*[^0-9]*'
        AND (last_seq = '0' OR substr(last_seq, 1, 1) <> '0')
      ),
    PRIMARY KEY (event_home, entity_home),
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    protocol TEXT NOT NULL CHECK (protocol = 'vellum/work/v2'),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, record_type),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'command'
      CHECK (record_type = 'command'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    action_json TEXT NOT NULL
      CHECK (
        length(action_json) BETWEEN 2 AND 262144
        AND json_valid(action_json)
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home <> entity_home),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_facts (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'fact'
      CHECK (record_type = 'fact'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    result_json TEXT NOT NULL
      CHECK (
        length(result_json) BETWEEN 2 AND 262144
        AND json_valid(result_json)
      ),
    basis_kind TEXT NOT NULL
      CHECK (
        basis_kind IN (
          'authorial-intent',
          'projected-intent',
          'command'
        )
      ),
    basis_authorial_generation TEXT
      CHECK (
        basis_authorial_generation IS NULL
        OR (
          length(basis_authorial_generation) BETWEEN 1 AND 32
          AND basis_authorial_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_authorial_generation = '0'
            OR substr(basis_authorial_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_authorial_content_sha256 TEXT
      CHECK (
        basis_authorial_content_sha256 IS NULL
        OR (
          length(basis_authorial_content_sha256) = 64
          AND basis_authorial_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_projected_generation TEXT
      CHECK (
        basis_projected_generation IS NULL
        OR (
          length(basis_projected_generation) BETWEEN 1 AND 32
          AND basis_projected_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_projected_generation = '0'
            OR substr(basis_projected_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_projected_content_sha256 TEXT
      CHECK (
        basis_projected_content_sha256 IS NULL
        OR (
          length(basis_projected_content_sha256) = 64
          AND basis_projected_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_command_event_home TEXT,
    basis_command_entity_home TEXT,
    basis_command_seq TEXT
      CHECK (
        basis_command_seq IS NULL
        OR (
          length(basis_command_seq) BETWEEN 1 AND 32
          AND basis_command_seq NOT GLOB '*[^0-9]*'
          AND substr(basis_command_seq, 1, 1) <> '0'
        )
      ),
    basis_command_sha256 TEXT
      CHECK (
        basis_command_sha256 IS NULL
        OR (
          length(basis_command_sha256) = 64
          AND basis_command_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home = entity_home),
    CHECK (
      (
        basis_kind = 'authorial-intent'
        AND basis_authorial_generation IS NOT NULL
        AND basis_authorial_content_sha256 IS NOT NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'projected-intent'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NOT NULL
        AND basis_projected_content_sha256 IS NOT NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'command'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NOT NULL
        AND basis_command_entity_home IS NOT NULL
        AND basis_command_seq IS NOT NULL
        AND basis_command_sha256 IS NOT NULL
        AND basis_command_entity_home = entity_home
      )
    ),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (basis_authorial_generation)
      REFERENCES canvas_generations(generation)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_projected_generation,
      basis_projected_content_sha256
    ) REFERENCES station_projection_versions(generation, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq
    ) REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq,
      basis_command_sha256
    ) REFERENCES work_events(
      event_home,
      entity_home,
      seq,
      content_sha256
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_dispositions (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'disposition'
      CHECK (record_type = 'disposition'),
    status TEXT NOT NULL CHECK (status IN ('applied', 'rejected')),
    command_event_home TEXT NOT NULL,
    command_entity_home TEXT NOT NULL,
    command_seq TEXT NOT NULL,
    command_sha256 TEXT NOT NULL
      CHECK (
        length(command_sha256) = 64
        AND command_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT,
    fact_entity_home TEXT,
    fact_seq TEXT,
    fact_sha256 TEXT
      CHECK (
        fact_sha256 IS NULL
        OR (
          length(fact_sha256) = 64
          AND fact_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    rejection_reason TEXT
      CHECK (
        rejection_reason IS NULL
        OR rejection_reason IN (
          'authority-mismatch',
          'capability-denied',
          'causal-conflict',
          'claim-contention',
          'identity-conflict',
          'invalid-transition',
          'locality-mismatch',
          'missing-entity',
          'projection-conflict',
          'target-mismatch'
        )
      ),
    rejection_message TEXT
      CHECK (
        rejection_message IS NULL
        OR length(rejection_message) BETWEEN 1 AND 2048
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, status),
    CHECK (event_home = entity_home),
    CHECK (command_entity_home = entity_home),
    CHECK (
      (
        status = 'applied'
        AND fact_event_home IS NOT NULL
        AND fact_entity_home IS NOT NULL
        AND fact_seq IS NOT NULL
        AND fact_sha256 IS NOT NULL
        AND fact_event_home = event_home
        AND fact_entity_home = entity_home
        AND rejection_reason IS NULL
        AND rejection_message IS NULL
      )
      OR
      (
        status = 'rejected'
        AND fact_event_home IS NULL
        AND fact_entity_home IS NULL
        AND fact_seq IS NULL
        AND fact_sha256 IS NULL
        AND rejection_reason IS NOT NULL
        AND rejection_message IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (command_event_home, command_entity_home, command_seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      command_event_home,
      command_entity_home,
      command_seq,
      command_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      fact_event_home,
      fact_entity_home,
      fact_seq,
      fact_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    claim_actor_seat_id TEXT
      CHECK (
        claim_actor_seat_id IS NULL
        OR (
          length(claim_actor_seat_id) = 69
          AND substr(claim_actor_seat_id, 1, 5) = 'seat_'
          AND substr(claim_actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT
      CHECK (resolved_at IS NULL OR length(resolved_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        operation = 'task.claim'
        AND item_kind = 'task'
        AND claim_actor_seat_id IS NOT NULL
      )
      OR
      (
        operation <> 'task.claim'
        AND claim_actor_seat_id IS NULL
      )
    ),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      resolution_event_home,
      resolution_entity_home,
      resolution_seq,
      resolution_status
    ) REFERENCES work_dispositions(event_home, entity_home, seq, status)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_tasks (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    task_id TEXT NOT NULL CHECK (length(task_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, task_id),
    UNIQUE (canvas_name, node_id, task_id, entity_home),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'submitted' AND actor_seat_id IS NULL)
      OR state IN ('completed', 'canceled', 'failed', 'rejected')
      OR (
        state IN ('working', 'input-required', 'auth-required')
        AND actor_seat_id IS NOT NULL
      )
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_requests (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    request_id TEXT NOT NULL CHECK (length(request_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'input-required',
          'auth-required',
          'completed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, request_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    parent_lane TEXT NOT NULL CHECK (parent_lane IN ('task', 'request')),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    message_kind TEXT NOT NULL CHECK (message_kind IN ('brief', 'history')),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      message_id
    ),
    UNIQUE (canvas_name, node_id, parent_lane, item_id, position),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, message_id),
    UNIQUE (canvas_name, node_id, position),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_artifacts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    artifact_id TEXT NOT NULL CHECK (length(artifact_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    name TEXT,
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_canvas_name TEXT
      CHECK (
        task_canvas_name IS NULL
        OR length(task_canvas_name) BETWEEN 1 AND 256
      ),
    task_node_id TEXT
      CHECK (
        task_node_id IS NULL
        OR length(task_node_id) BETWEEN 1 AND 256
      ),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    task_entity_home TEXT,
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, artifact_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (
        task_canvas_name IS NULL
        AND task_node_id IS NULL
        AND task_id IS NULL
        AND task_entity_home IS NULL
      )
      OR
      (
        task_canvas_name IS NOT NULL
        AND task_node_id IS NOT NULL
        AND task_id IS NOT NULL
        AND task_entity_home IS NOT NULL
      )
    ),
    CHECK (
      task_entity_home IS NULL
      OR task_entity_home = entity_home
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      task_canvas_name,
      task_node_id,
      task_id,
      task_entity_home
    ) REFERENCES work_tasks(
      canvas_name,
      node_id,
      task_id,
      entity_home
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_transitions (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    lane TEXT NOT NULL CHECK (lane IN ('task', 'request')),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve'
        )
      ),
    from_state TEXT,
    to_state TEXT NOT NULL
      CHECK (
        to_state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, item_id, lane, ordinal),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (
      from_state IS NULL
      OR from_state IN (
        'submitted',
        'working',
        'input-required',
        'auth-required',
        'completed',
        'canceled',
        'failed',
        'rejected'
      )
    ),
    CHECK (
      to_state NOT IN ('working', 'input-required', 'auth-required')
      OR actor_seat_id IS NOT NULL
    ),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_delivery_receipts (
    delivery_id TEXT NOT NULL CHECK (length(delivery_id) BETWEEN 1 AND 256),
    delivered_item_kind TEXT NOT NULL
      CHECK (
        delivered_item_kind IN (
          'task',
          'request',
          'message',
          'artifact',
          'delivery'
        )
      ),
    delivered_item_id TEXT NOT NULL
      CHECK (length(delivered_item_id) BETWEEN 1 AND 256),
    delivered_canvas_name TEXT NOT NULL
      CHECK (length(delivered_canvas_name) BETWEEN 1 AND 256),
    delivered_node_id TEXT NOT NULL
      CHECK (length(delivered_node_id) BETWEEN 1 AND 256),
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    actor_canvas_name TEXT NOT NULL
      CHECK (length(actor_canvas_name) BETWEEN 1 AND 256),
    actor_node_id TEXT NOT NULL
      CHECK (length(actor_node_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    accepted_at TEXT NOT NULL CHECK (length(accepted_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      delivered_canvas_name,
      delivered_node_id,
      delivery_id
    ),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_events_route_order
    ON work_events(event_home, entity_home, length(seq), seq);
  CREATE INDEX IF NOT EXISTS work_events_item_history
    ON work_events(
      item_canvas_name,
      item_node_id,
      item_kind,
      item_id,
      entity_home,
      length(seq),
      seq
    );
  CREATE INDEX IF NOT EXISTS work_pending_commands_route
    ON work_pending_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_item
    ON work_pending_commands(
      item_canvas_name,
      item_node_id,
      item_id
    )
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_actor
    ON work_pending_commands(claim_actor_seat_id)
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE INDEX IF NOT EXISTS work_tasks_node
    ON work_tasks(canvas_name, node_id, created_at, task_id);
  CREATE UNIQUE INDEX IF NOT EXISTS work_tasks_one_active_per_actor
    ON work_tasks(actor_seat_id)
    WHERE
      actor_seat_id IS NOT NULL
      AND state IN ('working', 'input-required', 'auth-required');
  CREATE INDEX IF NOT EXISTS work_requests_node
    ON work_requests(canvas_name, node_id, created_at, request_id);
  CREATE INDEX IF NOT EXISTS work_task_messages_thread
    ON work_task_messages(
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      position
    );
  CREATE UNIQUE INDEX IF NOT EXISTS work_task_messages_sink_identity
    ON work_task_messages(canvas_name, node_id, message_id);
  CREATE INDEX IF NOT EXISTS work_messages_inbox
    ON work_messages(canvas_name, node_id, position);
  CREATE INDEX IF NOT EXISTS work_artifacts_node
    ON work_artifacts(canvas_name, node_id, artifact_id);
  CREATE INDEX IF NOT EXISTS work_delivery_receipts_actor
    ON work_delivery_receipts(
      actor_seat_id,
      accepted_at,
      delivery_id
    );

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_update
  BEFORE UPDATE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_delete
  BEFORE DELETE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_update
  BEFORE UPDATE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_delete
  BEFORE DELETE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_fact_authorial_basis_resolves
  BEFORE INSERT ON work_facts
  WHEN
    NEW.basis_kind = 'authorial-intent'
    AND NOT EXISTS (
      SELECT 1
      FROM canvas_generations AS generation
      JOIN canvas_generation_documents AS document
        ON document.generation = generation.generation
      JOIN work_events AS record
        ON record.event_home = NEW.event_home
        AND record.entity_home = NEW.entity_home
        AND record.seq = NEW.seq
      WHERE generation.generation = NEW.basis_authorial_generation
        AND generation.intent_sha256 =
          NEW.basis_authorial_content_sha256
        AND document.name = record.item_canvas_name
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'authorial fact basis must resolve its exact sink canvas generation'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_update
  BEFORE UPDATE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_delete
  BEFORE DELETE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_applied_disposition_fact_basis_matches
  BEFORE INSERT ON work_dispositions
  WHEN
    NEW.status = 'applied'
    AND NOT EXISTS (
      SELECT 1
      FROM work_facts AS fact
      WHERE fact.event_home = NEW.fact_event_home
        AND fact.entity_home = NEW.fact_entity_home
        AND fact.seq = NEW.fact_seq
        AND fact.basis_kind = 'command'
        AND fact.basis_command_event_home = NEW.command_event_home
        AND fact.basis_command_entity_home = NEW.command_entity_home
        AND fact.basis_command_seq = NEW.command_seq
        AND fact.basis_command_sha256 = NEW.command_sha256
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'applied disposition fact must carry its exact command basis'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_update
  BEFORE UPDATE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_delete
  BEFORE DELETE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_matches_record
  BEFORE INSERT ON work_pending_commands
  WHEN NOT EXISTS (
    SELECT 1
    FROM work_events AS record
    WHERE record.event_home = NEW.event_home
      AND record.entity_home = NEW.entity_home
      AND record.seq = NEW.seq
      AND record.record_type = 'command'
      AND record.operation = NEW.operation
      AND record.item_kind = NEW.item_kind
      AND record.item_canvas_name = NEW.item_canvas_name
      AND record.item_node_id = NEW.item_node_id
      AND record.item_id = NEW.item_id
  )
  BEGIN
    SELECT RAISE(ABORT, 'pending command metadata must match its Work command');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_identity_immutable
  BEFORE UPDATE OF
    event_home,
    entity_home,
    seq,
    operation,
    item_kind,
    item_canvas_name,
    item_node_id,
    item_id,
    claim_actor_seat_id
  ON work_pending_commands
  WHEN
    OLD.event_home IS NOT NEW.event_home
    OR OLD.entity_home IS NOT NEW.entity_home
    OR OLD.seq IS NOT NEW.seq
    OR OLD.operation IS NOT NEW.operation
    OR OLD.item_kind IS NOT NEW.item_kind
    OR OLD.item_canvas_name IS NOT NEW.item_canvas_name
    OR OLD.item_node_id IS NOT NEW.item_node_id
    OR OLD.item_id IS NOT NEW.item_id
    OR OLD.claim_actor_seat_id IS NOT NEW.claim_actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'pending command identity is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_initial_resolution_matches
  BEFORE INSERT ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = NEW.event_home
        AND disposition.command_entity_home = NEW.entity_home
        AND disposition.command_seq = NEW.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_matches
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = OLD.event_home
        AND disposition.command_entity_home = OLD.entity_home
        AND disposition.command_seq = OLD.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_once
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    OLD.resolution_event_home IS NOT NULL
    AND (
      OLD.resolution_status IS NOT NEW.resolution_status
      OR OLD.resolution_event_home IS NOT NEW.resolution_event_home
      OR OLD.resolution_entity_home IS NOT NEW.resolution_entity_home
      OR OLD.resolution_seq IS NOT NEW.resolution_seq
      OR OLD.resolved_at IS NOT NEW.resolved_at
    )
  BEGIN
    SELECT RAISE(ABORT, 'pending command resolution is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_home_immutable
  BEFORE UPDATE OF entity_home ON work_tasks
  WHEN
    OLD.entity_home <> NEW.entity_home
    AND NOT (
      OLD.state = 'submitted'
      AND OLD.actor_seat_id IS NULL
      AND NEW.state = 'working'
      AND NEW.actor_seat_id IS NOT NULL
      AND NEW.entity_home = NEW.fact_entity_home
      AND NEW.fact_event_home = NEW.fact_entity_home
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task home is immutable except for first claim adoption'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_tasks
  WHEN
    OLD.actor_seat_id IS NOT NULL
    AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
    AND NOT (
      NEW.actor_seat_id IS NULL
      AND NEW.state = 'submitted'
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task actor seat is immutable except for operator release'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_home_immutable
  BEFORE UPDATE OF entity_home ON work_requests
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work request home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_requests
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work request actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work task message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_require_exact_parent
  BEFORE INSERT ON work_task_messages
  WHEN NOT (
    (
      NEW.parent_lane = 'task'
      AND EXISTS (
        SELECT 1
        FROM work_tasks
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND task_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
    OR
    (
      NEW.parent_lane = 'request'
      AND EXISTS (
        SELECT 1
        FROM work_requests
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND request_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
  )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task message requires an exact same-home parent'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_require_cc_home
  BEFORE INSERT ON work_messages
  WHEN
    NOT EXISTS (
      SELECT 1
      FROM station_configuration AS configuration
      JOIN station_installation AS installation
        ON installation.singleton = configuration.singleton
      WHERE configuration.singleton = 1
        AND configuration.role = 'command-center'
        AND NEW.entity_home = installation.installation_id
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work mailbox messages must be Command Center-homed'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_messages
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work message actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_home_immutable
  BEFORE UPDATE OF entity_home ON work_artifacts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_artifacts
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work artifact actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_require_claimed_task
  BEFORE INSERT ON work_artifacts
  WHEN
    NEW.task_id IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
    )
    AND NOT EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
        AND actor_seat_id IS NOT NULL
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work artifact requires an exact claimed same-home task'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_task_reference_immutable
  BEFORE UPDATE OF
    task_canvas_name,
    task_node_id,
    task_id,
    task_entity_home
  ON work_artifacts
  WHEN
    OLD.task_canvas_name IS NOT NEW.task_canvas_name
    OR OLD.task_node_id IS NOT NEW.task_node_id
    OR OLD.task_id IS NOT NEW.task_id
    OR OLD.task_entity_home IS NOT NEW.task_entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact task reference is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_transitions_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_transitions
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work transition home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_delivery_receipts_home_immutable
  BEFORE UPDATE OF entity_home ON work_delivery_receipts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work delivery receipt home is immutable');
  END;
  
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;

`.replaceAll("item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')","item_kind IN ('task', 'request', 'message', 'artifact', 'delivery', 'topic', 'post')").replaceAll(`'delivery.accepted'
        )`,`'delivery.accepted',
          'board.topic.create',
          'board.post.append'
        )`),uU=O5.replaceAll("operation IN ('proposal.create', 'proposal.approve')","operation IN ('proposal.create', 'proposal.approve', 'proposal.reject')"),f9=uU.replaceAll(`'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, task_id),`,`'completed',
          'canceled',
          'failed',
          'rejected',
          'archived'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, task_id),`).replaceAll("OR state IN ('completed', 'canceled', 'failed', 'rejected')","OR state IN ('completed', 'canceled', 'failed', 'rejected', 'archived')").replaceAll(`to_state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )`,`to_state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected',
          'archived'
        )`).replaceAll(`from_state IN (
        'submitted',
        'working',
        'input-required',
        'auth-required',
        'completed',
        'canceled',
        'failed',
        'rejected'
      )`,`from_state IN (
        'submitted',
        'working',
        'input-required',
        'auth-required',
        'completed',
        'canceled',
        'failed',
        'rejected',
        'archived'
      )`),nj=`
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;
`.replaceAll("operation IN ('proposal.create', 'proposal.approve')","operation IN ('proposal.create', 'proposal.approve', 'proposal.reject')"),cU=`
  CREATE TABLE IF NOT EXISTS work_event_sequences (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    last_seq TEXT NOT NULL
      CHECK (
        length(last_seq) BETWEEN 1 AND 32
        AND last_seq NOT GLOB '*[^0-9]*'
        AND (last_seq = '0' OR substr(last_seq, 1, 1) <> '0')
      ),
    PRIMARY KEY (event_home, entity_home),
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    protocol TEXT NOT NULL CHECK (protocol = 'vellum/work/v2'),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, record_type),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'command'
      CHECK (record_type = 'command'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    action_json TEXT NOT NULL
      CHECK (
        length(action_json) BETWEEN 2 AND 262144
        AND json_valid(action_json)
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home <> entity_home),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_facts (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'fact'
      CHECK (record_type = 'fact'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    result_json TEXT NOT NULL
      CHECK (
        length(result_json) BETWEEN 2 AND 262144
        AND json_valid(result_json)
      ),
    basis_kind TEXT NOT NULL
      CHECK (
        basis_kind IN (
          'authorial-intent',
          'projected-intent',
          'command'
        )
      ),
    basis_authorial_generation TEXT
      CHECK (
        basis_authorial_generation IS NULL
        OR (
          length(basis_authorial_generation) BETWEEN 1 AND 32
          AND basis_authorial_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_authorial_generation = '0'
            OR substr(basis_authorial_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_authorial_content_sha256 TEXT
      CHECK (
        basis_authorial_content_sha256 IS NULL
        OR (
          length(basis_authorial_content_sha256) = 64
          AND basis_authorial_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_projected_generation TEXT
      CHECK (
        basis_projected_generation IS NULL
        OR (
          length(basis_projected_generation) BETWEEN 1 AND 32
          AND basis_projected_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_projected_generation = '0'
            OR substr(basis_projected_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_projected_content_sha256 TEXT
      CHECK (
        basis_projected_content_sha256 IS NULL
        OR (
          length(basis_projected_content_sha256) = 64
          AND basis_projected_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_command_event_home TEXT,
    basis_command_entity_home TEXT,
    basis_command_seq TEXT
      CHECK (
        basis_command_seq IS NULL
        OR (
          length(basis_command_seq) BETWEEN 1 AND 32
          AND basis_command_seq NOT GLOB '*[^0-9]*'
          AND substr(basis_command_seq, 1, 1) <> '0'
        )
      ),
    basis_command_sha256 TEXT
      CHECK (
        basis_command_sha256 IS NULL
        OR (
          length(basis_command_sha256) = 64
          AND basis_command_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home = entity_home),
    CHECK (
      (
        basis_kind = 'authorial-intent'
        AND basis_authorial_generation IS NOT NULL
        AND basis_authorial_content_sha256 IS NOT NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'projected-intent'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NOT NULL
        AND basis_projected_content_sha256 IS NOT NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'command'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NOT NULL
        AND basis_command_entity_home IS NOT NULL
        AND basis_command_seq IS NOT NULL
        AND basis_command_sha256 IS NOT NULL
        AND basis_command_entity_home = entity_home
      )
    ),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (basis_authorial_generation)
      REFERENCES canvas_generations(generation)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_projected_generation,
      basis_projected_content_sha256
    ) REFERENCES station_projection_versions(generation, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq
    ) REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq,
      basis_command_sha256
    ) REFERENCES work_events(
      event_home,
      entity_home,
      seq,
      content_sha256
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_dispositions (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'disposition'
      CHECK (record_type = 'disposition'),
    status TEXT NOT NULL CHECK (status IN ('applied', 'rejected')),
    command_event_home TEXT NOT NULL,
    command_entity_home TEXT NOT NULL,
    command_seq TEXT NOT NULL,
    command_sha256 TEXT NOT NULL
      CHECK (
        length(command_sha256) = 64
        AND command_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT,
    fact_entity_home TEXT,
    fact_seq TEXT,
    fact_sha256 TEXT
      CHECK (
        fact_sha256 IS NULL
        OR (
          length(fact_sha256) = 64
          AND fact_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    rejection_reason TEXT
      CHECK (
        rejection_reason IS NULL
        OR rejection_reason IN (
          'authority-mismatch',
          'capability-denied',
          'causal-conflict',
          'claim-contention',
          'identity-conflict',
          'invalid-transition',
          'locality-mismatch',
          'missing-entity',
          'projection-conflict',
          'target-mismatch'
        )
      ),
    rejection_message TEXT
      CHECK (
        rejection_message IS NULL
        OR length(rejection_message) BETWEEN 1 AND 2048
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, status),
    CHECK (event_home = entity_home),
    CHECK (command_entity_home = entity_home),
    CHECK (
      (
        status = 'applied'
        AND fact_event_home IS NOT NULL
        AND fact_entity_home IS NOT NULL
        AND fact_seq IS NOT NULL
        AND fact_sha256 IS NOT NULL
        AND fact_event_home = event_home
        AND fact_entity_home = entity_home
        AND rejection_reason IS NULL
        AND rejection_message IS NULL
      )
      OR
      (
        status = 'rejected'
        AND fact_event_home IS NULL
        AND fact_entity_home IS NULL
        AND fact_seq IS NULL
        AND fact_sha256 IS NULL
        AND rejection_reason IS NOT NULL
        AND rejection_message IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (command_event_home, command_entity_home, command_seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      command_event_home,
      command_entity_home,
      command_seq,
      command_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      fact_event_home,
      fact_entity_home,
      fact_seq,
      fact_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    claim_actor_seat_id TEXT
      CHECK (
        claim_actor_seat_id IS NULL
        OR (
          length(claim_actor_seat_id) = 69
          AND substr(claim_actor_seat_id, 1, 5) = 'seat_'
          AND substr(claim_actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT
      CHECK (resolved_at IS NULL OR length(resolved_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        operation = 'task.claim'
        AND item_kind = 'task'
        AND claim_actor_seat_id IS NOT NULL
      )
      OR
      (
        operation <> 'task.claim'
        AND claim_actor_seat_id IS NULL
      )
    ),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      resolution_event_home,
      resolution_entity_home,
      resolution_seq,
      resolution_status
    ) REFERENCES work_dispositions(event_home, entity_home, seq, status)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_tasks (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    task_id TEXT NOT NULL CHECK (length(task_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, task_id),
    UNIQUE (canvas_name, node_id, task_id, entity_home),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'submitted' AND actor_seat_id IS NULL)
      OR state IN ('completed', 'canceled', 'failed', 'rejected')
      OR (
        state IN ('working', 'input-required', 'auth-required')
        AND actor_seat_id IS NOT NULL
      )
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_requests (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    request_id TEXT NOT NULL CHECK (length(request_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'input-required',
          'auth-required',
          'completed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, request_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    parent_lane TEXT NOT NULL CHECK (parent_lane IN ('task', 'request')),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    message_kind TEXT NOT NULL CHECK (message_kind IN ('brief', 'history')),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      message_id
    ),
    UNIQUE (canvas_name, node_id, parent_lane, item_id, position),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, message_id),
    UNIQUE (canvas_name, node_id, position),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_artifacts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    artifact_id TEXT NOT NULL CHECK (length(artifact_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    name TEXT,
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_canvas_name TEXT
      CHECK (
        task_canvas_name IS NULL
        OR length(task_canvas_name) BETWEEN 1 AND 256
      ),
    task_node_id TEXT
      CHECK (
        task_node_id IS NULL
        OR length(task_node_id) BETWEEN 1 AND 256
      ),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    task_entity_home TEXT,
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, artifact_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (
        task_canvas_name IS NULL
        AND task_node_id IS NULL
        AND task_id IS NULL
        AND task_entity_home IS NULL
      )
      OR
      (
        task_canvas_name IS NOT NULL
        AND task_node_id IS NOT NULL
        AND task_id IS NOT NULL
        AND task_entity_home IS NOT NULL
      )
    ),
    CHECK (
      task_entity_home IS NULL
      OR task_entity_home = entity_home
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      task_canvas_name,
      task_node_id,
      task_id,
      task_entity_home
    ) REFERENCES work_tasks(
      canvas_name,
      node_id,
      task_id,
      entity_home
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_transitions (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    lane TEXT NOT NULL CHECK (lane IN ('task', 'request')),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve'
        )
      ),
    from_state TEXT,
    to_state TEXT NOT NULL
      CHECK (
        to_state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, item_id, lane, ordinal),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (
      from_state IS NULL
      OR from_state IN (
        'submitted',
        'working',
        'input-required',
        'auth-required',
        'completed',
        'canceled',
        'failed',
        'rejected'
      )
    ),
    CHECK (
      to_state NOT IN ('working', 'input-required', 'auth-required')
      OR actor_seat_id IS NOT NULL
    ),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_delivery_receipts (
    delivery_id TEXT NOT NULL CHECK (length(delivery_id) BETWEEN 1 AND 256),
    delivered_item_kind TEXT NOT NULL
      CHECK (
        delivered_item_kind IN (
          'task',
          'request',
          'message',
          'artifact',
          'delivery'
        )
      ),
    delivered_item_id TEXT NOT NULL
      CHECK (length(delivered_item_id) BETWEEN 1 AND 256),
    delivered_canvas_name TEXT NOT NULL
      CHECK (length(delivered_canvas_name) BETWEEN 1 AND 256),
    delivered_node_id TEXT NOT NULL
      CHECK (length(delivered_node_id) BETWEEN 1 AND 256),
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    actor_canvas_name TEXT NOT NULL
      CHECK (length(actor_canvas_name) BETWEEN 1 AND 256),
    actor_node_id TEXT NOT NULL
      CHECK (length(actor_node_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    accepted_at TEXT NOT NULL CHECK (length(accepted_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      delivered_canvas_name,
      delivered_node_id,
      delivery_id
    ),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_events_route_order
    ON work_events(event_home, entity_home, length(seq), seq);
  CREATE INDEX IF NOT EXISTS work_events_item_history
    ON work_events(
      item_canvas_name,
      item_node_id,
      item_kind,
      item_id,
      entity_home,
      length(seq),
      seq
    );
  CREATE INDEX IF NOT EXISTS work_pending_commands_route
    ON work_pending_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_item
    ON work_pending_commands(
      item_canvas_name,
      item_node_id,
      item_id
    )
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_actor
    ON work_pending_commands(claim_actor_seat_id)
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE INDEX IF NOT EXISTS work_tasks_node
    ON work_tasks(canvas_name, node_id, created_at, task_id);
  CREATE UNIQUE INDEX IF NOT EXISTS work_tasks_one_active_per_actor
    ON work_tasks(actor_seat_id)
    WHERE
      actor_seat_id IS NOT NULL
      AND state IN ('working', 'input-required', 'auth-required');
  CREATE INDEX IF NOT EXISTS work_requests_node
    ON work_requests(canvas_name, node_id, created_at, request_id);
  CREATE INDEX IF NOT EXISTS work_task_messages_thread
    ON work_task_messages(
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      position
    );
  CREATE UNIQUE INDEX IF NOT EXISTS work_task_messages_sink_identity
    ON work_task_messages(canvas_name, node_id, message_id);
  CREATE INDEX IF NOT EXISTS work_messages_inbox
    ON work_messages(canvas_name, node_id, position);
  CREATE INDEX IF NOT EXISTS work_artifacts_node
    ON work_artifacts(canvas_name, node_id, artifact_id);
  CREATE INDEX IF NOT EXISTS work_delivery_receipts_actor
    ON work_delivery_receipts(
      actor_seat_id,
      accepted_at,
      delivery_id
    );

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_update
  BEFORE UPDATE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_delete
  BEFORE DELETE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_update
  BEFORE UPDATE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_delete
  BEFORE DELETE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_fact_authorial_basis_resolves
  BEFORE INSERT ON work_facts
  WHEN
    NEW.basis_kind = 'authorial-intent'
    AND NOT EXISTS (
      SELECT 1
      FROM canvas_generations AS generation
      JOIN canvas_generation_documents AS document
        ON document.generation = generation.generation
      JOIN work_events AS record
        ON record.event_home = NEW.event_home
        AND record.entity_home = NEW.entity_home
        AND record.seq = NEW.seq
      WHERE generation.generation = NEW.basis_authorial_generation
        AND generation.intent_sha256 =
          NEW.basis_authorial_content_sha256
        AND document.name = record.item_canvas_name
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'authorial fact basis must resolve its exact sink canvas generation'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_update
  BEFORE UPDATE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_delete
  BEFORE DELETE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_applied_disposition_fact_basis_matches
  BEFORE INSERT ON work_dispositions
  WHEN
    NEW.status = 'applied'
    AND NOT EXISTS (
      SELECT 1
      FROM work_facts AS fact
      WHERE fact.event_home = NEW.fact_event_home
        AND fact.entity_home = NEW.fact_entity_home
        AND fact.seq = NEW.fact_seq
        AND fact.basis_kind = 'command'
        AND fact.basis_command_event_home = NEW.command_event_home
        AND fact.basis_command_entity_home = NEW.command_entity_home
        AND fact.basis_command_seq = NEW.command_seq
        AND fact.basis_command_sha256 = NEW.command_sha256
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'applied disposition fact must carry its exact command basis'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_update
  BEFORE UPDATE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_delete
  BEFORE DELETE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_matches_record
  BEFORE INSERT ON work_pending_commands
  WHEN NOT EXISTS (
    SELECT 1
    FROM work_events AS record
    WHERE record.event_home = NEW.event_home
      AND record.entity_home = NEW.entity_home
      AND record.seq = NEW.seq
      AND record.record_type = 'command'
      AND record.operation = NEW.operation
      AND record.item_kind = NEW.item_kind
      AND record.item_canvas_name = NEW.item_canvas_name
      AND record.item_node_id = NEW.item_node_id
      AND record.item_id = NEW.item_id
  )
  BEGIN
    SELECT RAISE(ABORT, 'pending command metadata must match its Work command');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_identity_immutable
  BEFORE UPDATE OF
    event_home,
    entity_home,
    seq,
    operation,
    item_kind,
    item_canvas_name,
    item_node_id,
    item_id,
    claim_actor_seat_id
  ON work_pending_commands
  WHEN
    OLD.event_home IS NOT NEW.event_home
    OR OLD.entity_home IS NOT NEW.entity_home
    OR OLD.seq IS NOT NEW.seq
    OR OLD.operation IS NOT NEW.operation
    OR OLD.item_kind IS NOT NEW.item_kind
    OR OLD.item_canvas_name IS NOT NEW.item_canvas_name
    OR OLD.item_node_id IS NOT NEW.item_node_id
    OR OLD.item_id IS NOT NEW.item_id
    OR OLD.claim_actor_seat_id IS NOT NEW.claim_actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'pending command identity is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_initial_resolution_matches
  BEFORE INSERT ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = NEW.event_home
        AND disposition.command_entity_home = NEW.entity_home
        AND disposition.command_seq = NEW.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_matches
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = OLD.event_home
        AND disposition.command_entity_home = OLD.entity_home
        AND disposition.command_seq = OLD.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_once
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    OLD.resolution_event_home IS NOT NULL
    AND (
      OLD.resolution_status IS NOT NEW.resolution_status
      OR OLD.resolution_event_home IS NOT NEW.resolution_event_home
      OR OLD.resolution_entity_home IS NOT NEW.resolution_entity_home
      OR OLD.resolution_seq IS NOT NEW.resolution_seq
      OR OLD.resolved_at IS NOT NEW.resolved_at
    )
  BEGIN
    SELECT RAISE(ABORT, 'pending command resolution is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_home_immutable
  BEFORE UPDATE OF entity_home ON work_tasks
  WHEN
    OLD.entity_home <> NEW.entity_home
    AND NOT (
      OLD.state = 'submitted'
      AND OLD.actor_seat_id IS NULL
      AND NEW.state = 'working'
      AND NEW.actor_seat_id IS NOT NULL
      AND NEW.entity_home = NEW.fact_entity_home
      AND NEW.fact_event_home = NEW.fact_entity_home
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task home is immutable except for first claim adoption'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_tasks
  WHEN
    OLD.actor_seat_id IS NOT NULL
    AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
    AND NOT (
      NEW.actor_seat_id IS NULL
      AND NEW.state = 'submitted'
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task actor seat is immutable except for operator release'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_home_immutable
  BEFORE UPDATE OF entity_home ON work_requests
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work request home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_requests
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work request actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work task message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_require_exact_parent
  BEFORE INSERT ON work_task_messages
  WHEN NOT (
    (
      NEW.parent_lane = 'task'
      AND EXISTS (
        SELECT 1
        FROM work_tasks
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND task_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
    OR
    (
      NEW.parent_lane = 'request'
      AND EXISTS (
        SELECT 1
        FROM work_requests
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND request_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
  )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task message requires an exact same-home parent'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_require_cc_home
  BEFORE INSERT ON work_messages
  WHEN
    NOT EXISTS (
      SELECT 1
      FROM station_configuration AS configuration
      JOIN station_installation AS installation
        ON installation.singleton = configuration.singleton
      WHERE configuration.singleton = 1
        AND configuration.role = 'command-center'
        AND NEW.entity_home = installation.installation_id
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work mailbox messages must be Command Center-homed'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_messages
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work message actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_home_immutable
  BEFORE UPDATE OF entity_home ON work_artifacts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_artifacts
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work artifact actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_require_claimed_task
  BEFORE INSERT ON work_artifacts
  WHEN
    NEW.task_id IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
    )
    AND NOT EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
        AND actor_seat_id IS NOT NULL
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work artifact requires an exact claimed same-home task'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_task_reference_immutable
  BEFORE UPDATE OF
    task_canvas_name,
    task_node_id,
    task_id,
    task_entity_home
  ON work_artifacts
  WHEN
    OLD.task_canvas_name IS NOT NEW.task_canvas_name
    OR OLD.task_node_id IS NOT NEW.task_node_id
    OR OLD.task_id IS NOT NEW.task_id
    OR OLD.task_entity_home IS NOT NEW.task_entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact task reference is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_transitions_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_transitions
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work transition home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_delivery_receipts_home_immutable
  BEFORE UPDATE OF entity_home ON work_delivery_receipts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work delivery receipt home is immutable');
  END;
  
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;

`.replace(`  
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;

`,"").replace(`  CREATE TRIGGER IF NOT EXISTS work_tasks_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_tasks
  WHEN
    OLD.actor_seat_id IS NOT NULL
    AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
    AND NOT (
      NEW.actor_seat_id IS NULL
      AND NEW.state = 'submitted'
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task actor seat is immutable except for operator release'
    );
  END;`,`  CREATE TRIGGER IF NOT EXISTS work_tasks_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_tasks
  WHEN
    OLD.actor_seat_id IS NOT NULL
    AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work task actor seat is immutable after first claim');
  END;`),BJ=`
  CREATE TABLE IF NOT EXISTS work_pad_meta (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    revision INTEGER NOT NULL CHECK (revision >= 0),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_images (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    element_id TEXT NOT NULL CHECK (length(element_id) BETWEEN 1 AND 256),
    x REAL NOT NULL,
    y REAL NOT NULL,
    w REAL NOT NULL CHECK (w > 0),
    h REAL NOT NULL CHECK (h > 0),
    z INTEGER NOT NULL,
    ref_json TEXT NOT NULL CHECK (json_valid(ref_json)),
    PRIMARY KEY (canvas_name, node_id, element_id),
    FOREIGN KEY (canvas_name, node_id)
      REFERENCES work_pad_meta(canvas_name, node_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_shapes (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    element_id TEXT NOT NULL CHECK (length(element_id) BETWEEN 1 AND 256),
    type TEXT NOT NULL CHECK (type IN ('box', 'ellipse', 'triangle', 'label')),
    x REAL NOT NULL,
    y REAL NOT NULL,
    w REAL NOT NULL CHECK (w > 0),
    h REAL NOT NULL CHECK (h > 0),
    z INTEGER NOT NULL,
    fill TEXT CHECK (fill IS NULL OR length(fill) BETWEEN 1 AND 256),
    stroke TEXT CHECK (stroke IS NULL OR length(stroke) BETWEEN 1 AND 256),
    text TEXT CHECK (text IS NULL OR length(text) >= 1),
    status TEXT CHECK (
      status IS NULL OR status IN ('none', 'active', 'done', 'blocked')
    ),
    PRIMARY KEY (canvas_name, node_id, element_id),
    FOREIGN KEY (canvas_name, node_id)
      REFERENCES work_pad_meta(canvas_name, node_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_edges (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    element_id TEXT NOT NULL CHECK (length(element_id) BETWEEN 1 AND 256),
    from_id TEXT NOT NULL CHECK (length(from_id) BETWEEN 1 AND 256),
    to_id TEXT NOT NULL CHECK (length(to_id) BETWEEN 1 AND 256),
    from_side TEXT CHECK (
      from_side IS NULL OR from_side IN ('top', 'right', 'bottom', 'left')
    ),
    to_side TEXT CHECK (
      to_side IS NULL OR to_side IN ('top', 'right', 'bottom', 'left')
    ),
    label TEXT CHECK (label IS NULL OR length(label) >= 1),
    PRIMARY KEY (canvas_name, node_id, element_id),
    FOREIGN KEY (canvas_name, node_id)
      REFERENCES work_pad_meta(canvas_name, node_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_inks (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    element_id TEXT NOT NULL CHECK (length(element_id) BETWEEN 1 AND 256),
    z INTEGER NOT NULL,
    color TEXT NOT NULL CHECK (length(color) BETWEEN 1 AND 256),
    width REAL NOT NULL CHECK (width > 0),
    points_json TEXT NOT NULL CHECK (json_valid(points_json)),
    PRIMARY KEY (canvas_name, node_id, element_id),
    FOREIGN KEY (canvas_name, node_id)
      REFERENCES work_pad_meta(canvas_name, node_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_pins (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    element_id TEXT NOT NULL CHECK (length(element_id) BETWEEN 1 AND 256),
    x REAL NOT NULL,
    y REAL NOT NULL,
    bounds_json TEXT CHECK (bounds_json IS NULL OR json_valid(bounds_json)),
    mentions_json TEXT NOT NULL CHECK (json_valid(mentions_json)),
    PRIMARY KEY (canvas_name, node_id, element_id),
    FOREIGN KEY (canvas_name, node_id)
      REFERENCES work_pad_meta(canvas_name, node_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_posts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    pin_id TEXT NOT NULL CHECK (length(pin_id) BETWEEN 1 AND 256),
    post_id TEXT NOT NULL CHECK (length(post_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
    author_seat_id TEXT
      CHECK (
        author_seat_id IS NULL
        OR (
          length(author_seat_id) = 69
          AND substr(author_seat_id, 1, 5) = 'seat_'
          AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    author_node_id TEXT
      CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
    author_label TEXT
      CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    PRIMARY KEY (canvas_name, node_id, pin_id, post_id),
    UNIQUE (canvas_name, node_id, pin_id, position),
    FOREIGN KEY (canvas_name, node_id, pin_id)
      REFERENCES work_pad_pins(canvas_name, node_id, element_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_pad_shapes_node
    ON work_pad_shapes(canvas_name, node_id, z, element_id);
  CREATE INDEX IF NOT EXISTS work_pad_posts_pin
    ON work_pad_posts(canvas_name, node_id, pin_id, position);
`,VJ=`
  CREATE TABLE IF NOT EXISTS work_pad_read_cursors (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    pin_id TEXT NOT NULL CHECK (length(pin_id) BETWEEN 1 AND 256),
    principal_key TEXT NOT NULL CHECK (length(principal_key) BETWEEN 1 AND 256),
    last_read_position INTEGER NOT NULL CHECK (last_read_position >= -1),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, pin_id, principal_key)
  ) STRICT, WITHOUT ROWID;
`,qJ=f9.replaceAll("item_kind IN ('task', 'request', 'message', 'artifact', 'delivery', 'topic', 'post')","item_kind IN ('task', 'request', 'message', 'artifact', 'delivery', 'topic', 'post', 'pad')").replaceAll(`'board.topic.create',
          'board.post.append'
        )`,`'board.topic.create',
          'board.post.append',
          'pad.patch'
        )`);var I80=`
  CREATE TABLE IF NOT EXISTS state_schema_identity (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    actual_schema_sha256 TEXT NOT NULL
      CHECK (
        length(actual_schema_sha256) = 64
        AND actual_schema_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    source_schema_sha256 TEXT NOT NULL
      CHECK (
        length(source_schema_sha256) = 64
        AND source_schema_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    verified_at TEXT NOT NULL
      CHECK (length(verified_at) BETWEEN 1 AND 64)
  ) STRICT;
`,j80=`
  CREATE TABLE IF NOT EXISTS canvas_generations (
    generation TEXT PRIMARY KEY
      CHECK (
        length(generation) > 0
        AND generation NOT GLOB '*[^0-9]*'
        AND (generation = '0' OR substr(generation, 1, 1) <> '0')
      ),
    created_at TEXT NOT NULL CHECK (length(created_at) > 0),
    cause TEXT NOT NULL CHECK (length(cause) > 0),
    intent_sha256 TEXT NOT NULL CHECK (length(intent_sha256) = 64),
    document_count INTEGER NOT NULL
      CHECK (document_count >= 0)
  ) STRICT;

  CREATE TABLE IF NOT EXISTS canvas_generation_documents (
    generation TEXT NOT NULL
      REFERENCES canvas_generations(generation) ON DELETE CASCADE,
    name TEXT NOT NULL CHECK (length(name) > 0),
    body TEXT NOT NULL,
    sha256 TEXT NOT NULL CHECK (length(sha256) = 64),
    modified_at TEXT NOT NULL CHECK (length(modified_at) > 0),
    PRIMARY KEY (generation, name)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS canvas_head (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    generation TEXT NOT NULL
      REFERENCES canvas_generations(generation) ON DELETE RESTRICT
  ) STRICT;
`,sj=[I80,j80,Pj,Cj,wj,Mj,Sj,pj,uj,cj,lj,oj,cU],UH0=sj.join(`
`),aj=[...sj,GJ],DH0=aj.join(`
`),S80=[...aj,JJ],tj=S80.map((X)=>X===cU?pU:X),NH0=tj.join(`
`),ej=[...tj,_J],BH0=ej.join(`
`),XS=[...ej,UJ],VH0=XS.join(`
`),YS=[...XS,DJ],qH0=YS.join(`
`),QS=[...YS,D_],zH0=QS.join(`
`),_S=QS.map((X)=>X===pU?O5:X),OH0=_S.join(`
`),GS=[..._S,NJ],LH0=GS.join(`
`),JS=[...GS,HJ],TH0=JS.join(`
`),lU=[...JS,WJ],RH0=lU.join(`
`),v80=lU.map((X)=>X===O5?uU:X),FH0=v80.join(`
`),$S=lU.map((X)=>X===O5?f9:X),EH0=$S.join(`
`),ZS=$S.map((X)=>X===D_?ij:X),AH0=ZS.join(`
`),KS=[...ZS.map((X)=>X===f9?qJ:X),BJ],PH0=KS.join(`
`),x80=[...KS,VJ],HS=x80.join(`
`);import{createHash as k80}from"node:crypto";import{DatabaseSync as b80}from"node:sqlite";var g80="0".repeat(64),y80=(X)=>k80("sha256").update(X).digest("hex"),h80=(X)=>{let Y=[],Q=0,_=(G)=>{let J=G==="["?"]":G,Z=G;Q+=1;while(Q<X.length){let K=X[Q];if(Z+=K,Q+=1,K!==J)continue;if(X[Q]===J){Z+=J,Q+=1;continue}break}Y.push(Z)};while(Q<X.length){let G=X[Q];if(/\s/u.test(G)){Q+=1;continue}if(G==="-"&&X[Q+1]==="-"){Q+=2;while(Q<X.length&&X[Q]!==`
`)Q+=1;continue}if(G==="/"&&X[Q+1]==="*"){let H=X.indexOf("*/",Q+2);Q=H===-1?X.length:H+2;continue}if(G==="'"||G==='"'||G==="`"||G==="["){_(G);continue}let J=X.slice(Q,Q+3);if(J==="->>"){Y.push(J),Q+=3;continue}let Z=X.slice(Q,Q+2);if(["||","<<",">>","<=",">=","==","!=","<>","->"].includes(Z)){Y.push(Z),Q+=2;continue}if(/[\[\]\(\),.;+\-*/%<>=!|&~]/u.test(G)){Y.push(G),Q+=1;continue}let K=Q;while(Q<X.length&&!/[\s'"`\[\]\(\),.;+\-*/%<>=!|&~]/u.test(X[Q]))Q+=1;Y.push(X.slice(K,Q).toLowerCase())}return JSON.stringify(Y)},OJ=(X)=>X.prepare(`
          SELECT type, name, tbl_name AS table_name, sql
          FROM sqlite_schema
          WHERE type IN ('table', 'index', 'view', 'trigger')
            AND name NOT GLOB 'sqlite_*'
          ORDER BY type COLLATE BINARY, name COLLATE BINARY
        `).all().map((Y)=>({type:String(Y.type),name:String(Y.name),tableName:String(Y.table_name),sql:Y.sql===null?null:h80(String(Y.sql))})),zJ=(X)=>y80(JSON.stringify(X)),oU=(X)=>zJ(OJ(X)),rU=(X)=>OJ(X).length===0,WS=(X)=>`${X.type}:${X.name}`,m80=(X,Y)=>{let Q=new Map(X.map((K)=>[WS(K),K])),_=new Map(Y.map((K)=>[WS(K),K])),G=[...Q.keys()].filter((K)=>!_.has(K)).sort(),J=[..._.keys()].filter((K)=>!Q.has(K)).sort(),Z=[..._.keys()].filter((K)=>{let H=Q.get(K),W=_.get(K);return H!==void 0&&W!==void 0&&JSON.stringify(H)!==JSON.stringify(W)}).sort();return[G.length>0?`unexpected=${G.join(",")}`:"",J.length>0?`missing=${J.join(",")}`:"",Z.length>0?`changed=${Z.join(",")}`:""].filter(Boolean).join("; ")},US=(X)=>{let Y=new b80(":memory:",{open:!0,readOnly:!1,allowExtension:!1,enableForeignKeyConstraints:!0,enableDoubleQuotedStringLiterals:!1,allowBareNamedParameters:!1,allowUnknownNamedParameters:!1});try{return Y.exec(`
      PRAGMA foreign_keys = ON;
      PRAGMA trusted_schema = OFF;
    `),Y.exec(X),OJ(Y)}finally{Y.close()}},DS=(X)=>({actualSchemaSha256:zJ(US(X))}),LJ=(X)=>{if(X.prepare(`
        SELECT 1
        FROM sqlite_schema
        WHERE type = 'table'
          AND name = 'state_schema_identity'
      `).get()===void 0)throw Error("state schema identity table is missing");let Q=X.prepare(`
        SELECT
          actual_schema_sha256,
          verified_at
        FROM state_schema_identity
        WHERE singleton = 1
      `).get();if(Q===void 0)throw Error("state schema identity witness is missing");return{actualSchemaSha256:String(Q.actual_schema_sha256),verifiedAt:String(Q.verified_at)}},iU=(X)=>{let Y=LJ(X),Q=oU(X);if(Y.actualSchemaSha256!==Q)throw Error("state schema changed after its recorded identity was stamped");return Y},nU=(X,Y)=>{X.prepare(`
        INSERT INTO state_schema_identity(
          singleton,
          actual_schema_sha256,
          source_schema_sha256,
          verified_at
        ) VALUES (1, ?, ?, ?)
        ON CONFLICT(singleton) DO UPDATE SET
          actual_schema_sha256 = excluded.actual_schema_sha256,
          source_schema_sha256 = excluded.source_schema_sha256,
          verified_at = excluded.verified_at
      `).run(Y.actualSchemaSha256,g80,new Date().toISOString())},sU=(X,Y)=>{let Q=US(Y),_=OJ(X),G=zJ(Q),J=zJ(_);if(J!==G){let Z=m80(_,Q);throw Error(`state schema identity mismatch${Z.length>0?` (${Z})`:""}`)}return{actualSchemaSha256:J}},aU=(X,Y)=>{let Q=sU(X,Y);return nU(X,Q),Q};var D1="expand-only",BS={actualSchemaSha256:"376d0448e43bda8373930f74140ff2f11c315bcf9c9382daf25bd4cb7b910195"},d80={actualSchemaSha256:"c7050c73efcea27e7ccb6e7c687f213cae8d2c32e8903d1ab7c7f1e8aeb953c3"},f80={actualSchemaSha256:"4a8d0fd0545e2108c79c611fc4f56acb1ce96a1972cae13cbf7e716b241bc941"},p80={actualSchemaSha256:"8870c6e4b932ee4a2895bfc9926e2be97f0baa3c538bdfa1e9e8cca5eb354d7f"},u80={actualSchemaSha256:"4c0fd324cb37c9c609acdeade50a10325b2bffddaae40c0ee8fa464d6cfc6b6f"},c80={actualSchemaSha256:"f097722579ffcaad121b0e5eb62076a8ab70cb9c5d66a78978d572612703be53"},l80={actualSchemaSha256:"9f2aace6eaefaa20c1141304d5d4d62544a0500ff3bc7f30acda94d4099006bc"},o80={actualSchemaSha256:"8239ad37bd9fb890d585f5fedef69086890a75b1c01b5fb257bb4573c2809e71"},r80={actualSchemaSha256:"00777be6fb3361c057a799d0f58c86d364518d24a1eb2d8a08b6f32c58d7bcef"},i80={actualSchemaSha256:"7844862b7ed357a60b4e78a336ae7229aab8dd812622862f0de56c916e12269e"},n80={actualSchemaSha256:"66e16dda9d6d938b107ec25b0edd58f1a964d40192fd1d9fe35793665d03e99f"},s80={actualSchemaSha256:"a4bf3db00027fc2a52b5b73592d3d33b1f7d739c5ec7f32cdde41e3d95d5d53e"},a80={actualSchemaSha256:"fd6f5b73d474c83ed8ff93c24b60b8587f7cfe3783d2fe65274c7611ae431abf"},t80={actualSchemaSha256:"646f7b553d54bd55cbdab2562132c22508b8ea9b4f29b7f9ae31c8f93d9bf06f"},e80={actualSchemaSha256:"419206d0b4a3e52fa7d24a04c0cf07fb17f25cbf60b83e64e6d89bb32d4fb5c9"},X40={actualSchemaSha256:"68c01a84360fe399ea98c2963aa763f86cfd0c2c5262ecea9996ee984a3cb3bb"},Y40={actualSchemaSha256:"5f580bc42f6e3332256ca6bfadda1489f42889616c75acd1cf4a3af1259249bb"};var p9=18,Q40=[{fromVersion:1,toVersion:2,name:"add-license-activation",safety:D1,fromIdentity:BS,migrate:(X)=>{X.exec(GJ)}},{fromVersion:2,toVersion:3,name:"bind-license-entitlement-to-dodo-product",safety:D1,fromIdentity:d80,migrate:(X)=>{X.exec(JJ)}},{fromVersion:3,toVersion:4,name:"allow-atomic-task-release",safety:D1,fromIdentity:f80,replacesObjects:["trigger:work_tasks_actor_immutable"],migrate:(X)=>{X.exec(`
          DROP TRIGGER work_tasks_actor_immutable;
          CREATE TRIGGER work_tasks_actor_immutable
          BEFORE UPDATE OF actor_seat_id ON work_tasks
          WHEN
            OLD.actor_seat_id IS NOT NULL
            AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
            AND NOT (
              NEW.actor_seat_id IS NULL
              AND NEW.state = 'submitted'
            )
          BEGIN
            SELECT RAISE(
              ABORT,
              'work task actor seat is immutable except for operator release'
            );
          END;
        `)}},{fromVersion:4,toVersion:5,name:"add-task-proposals",safety:D1,fromIdentity:p80,migrate:(X)=>{X.exec(rj)}},{fromVersion:5,toVersion:6,name:"add-canvas-entities",safety:D1,fromIdentity:u80,migrate:(X)=>{X.exec(_J),_40(X)}},{fromVersion:6,toVersion:7,name:"add-work-task-dependencies",safety:D1,fromIdentity:c80,migrate:(X)=>{X.exec(UJ)}},{fromVersion:7,toVersion:8,name:"add-work-task-finish-criteria",safety:D1,fromIdentity:l80,migrate:(X)=>{X.exec(DJ)}},{fromVersion:8,toVersion:9,name:"add-work-board",safety:D1,fromIdentity:o80,migrate:(X)=>{X.exec(D_)}},{fromVersion:9,toVersion:10,name:"board-event-vocabulary",safety:D1,fromIdentity:r80,replacesTables:["work_events","work_pending_commands"],migrate:(X)=>{X.exec(`
          CREATE TABLE work_events__migrate_bak AS SELECT * FROM work_events;
          CREATE TABLE work_pending_commands__migrate_bak AS
            SELECT * FROM work_pending_commands;

          DROP TABLE work_pending_commands;
          DROP TABLE work_events;
        `),X.exec(O5),X.exec(`
          INSERT INTO work_events SELECT * FROM work_events__migrate_bak;
          INSERT INTO work_pending_commands
            SELECT * FROM work_pending_commands__migrate_bak;
          DROP TABLE work_events__migrate_bak;
          DROP TABLE work_pending_commands__migrate_bak;
        `)}},{fromVersion:10,toVersion:11,name:"add-work-proposal-planning",safety:D1,fromIdentity:i80,migrate:(X)=>{X.exec(NJ)}},{fromVersion:11,toVersion:12,name:"add-content-manifest",safety:D1,fromIdentity:n80,migrate:(X)=>{X.exec(HJ)}},{fromVersion:12,toVersion:13,name:"add-content-inline-media-migration-marker",safety:D1,fromIdentity:s80,migrate:(X)=>{X.exec(WJ)}},{fromVersion:13,toVersion:14,name:"proposal-reject-event-vocabulary",safety:D1,fromIdentity:a80,replacesTables:["work_proposal_events","work_pending_proposal_commands"],migrate:(X)=>{X.exec(`
          CREATE TABLE work_proposal_events__migrate_bak AS
            SELECT * FROM work_proposal_events;
          CREATE TABLE work_pending_proposal_commands__migrate_bak AS
            SELECT * FROM work_pending_proposal_commands;

          DROP TABLE work_pending_proposal_commands;
          DROP TABLE work_proposal_events;
        `),X.exec(nj),X.exec(`
          INSERT INTO work_proposal_events
            SELECT * FROM work_proposal_events__migrate_bak;
          INSERT INTO work_pending_proposal_commands
            SELECT * FROM work_pending_proposal_commands__migrate_bak;
          DROP TABLE work_proposal_events__migrate_bak;
          DROP TABLE work_pending_proposal_commands__migrate_bak;
        `)}},{fromVersion:14,toVersion:15,name:"task-archived-soft-delete",safety:D1,fromIdentity:t80,replacesTables:["work_tasks","work_task_transitions"],migrate:(X)=>{X.exec(`
          CREATE TABLE work_tasks__migrate_bak AS SELECT * FROM work_tasks;
          CREATE TABLE work_task_transitions__migrate_bak AS
            SELECT * FROM work_task_transitions;

          DROP TABLE work_task_transitions;
          DROP TABLE work_tasks;
        `),X.exec(f9),X.exec(`
          INSERT INTO work_tasks SELECT * FROM work_tasks__migrate_bak;
          INSERT INTO work_task_transitions
            SELECT * FROM work_task_transitions__migrate_bak;
          DROP TABLE work_tasks__migrate_bak;
          DROP TABLE work_task_transitions__migrate_bak;
        `)}},{fromVersion:15,toVersion:16,name:"board-post-tags",safety:D1,fromIdentity:e80,replacesTables:["work_board_posts"],migrate:(X)=>{X.exec(`
          CREATE TABLE work_board_posts__migrate_bak AS
            SELECT * FROM work_board_posts;
          DROP TABLE work_board_posts;
        `),X.exec(`
          CREATE TABLE work_board_posts (
            canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
            node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
            topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
            post_id TEXT NOT NULL CHECK (length(post_id) BETWEEN 1 AND 256),
            position INTEGER NOT NULL CHECK (position >= 0),
            author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
            author_seat_id TEXT
              CHECK (
                author_seat_id IS NULL
                OR (
                  length(author_seat_id) = 69
                  AND substr(author_seat_id, 1, 5) = 'seat_'
                  AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
                )
              ),
            author_node_id TEXT
              CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
            author_label TEXT
              CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
            parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
            tags_json TEXT
              CHECK (tags_json IS NULL OR json_valid(tags_json)),
            created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
            PRIMARY KEY (canvas_name, node_id, topic_id, post_id),
            UNIQUE (canvas_name, node_id, topic_id, position),
            FOREIGN KEY (canvas_name, node_id, topic_id)
              REFERENCES work_board_topics(canvas_name, node_id, topic_id)
              ON DELETE RESTRICT
              ON UPDATE RESTRICT
          ) STRICT, WITHOUT ROWID;
          CREATE INDEX IF NOT EXISTS work_board_posts_thread
            ON work_board_posts(canvas_name, node_id, topic_id, position);
        `),X.exec(`
          INSERT INTO work_board_posts(
            canvas_name, node_id, topic_id, post_id, position,
            author_kind, author_seat_id, author_node_id, author_label,
            parts_json, tags_json, created_at
          )
          SELECT
            canvas_name, node_id, topic_id, post_id, position,
            author_kind, author_seat_id, author_node_id, author_label,
            parts_json, NULL, created_at
          FROM work_board_posts__migrate_bak;
          DROP TABLE work_board_posts__migrate_bak;
        `)}},{fromVersion:16,toVersion:17,name:"add-work-pad",safety:D1,fromIdentity:X40,replacesTables:["work_events","work_pending_commands"],migrate:(X)=>{X.exec(BJ),X.exec(`
          CREATE TABLE work_events__migrate_bak AS SELECT * FROM work_events;
          CREATE TABLE work_pending_commands__migrate_bak AS
            SELECT * FROM work_pending_commands;

          DROP TABLE work_pending_commands;
          DROP TABLE work_events;
        `),X.exec(qJ),X.exec(`
          INSERT INTO work_events SELECT * FROM work_events__migrate_bak;
          INSERT INTO work_pending_commands
            SELECT * FROM work_pending_commands__migrate_bak;
          DROP TABLE work_events__migrate_bak;
          DROP TABLE work_pending_commands__migrate_bak;
        `)}},{fromVersion:17,toVersion:18,name:"add-work-pad-read-cursors",safety:D1,fromIdentity:Y40,migrate:(X)=>{X.exec(VJ)}}],_40=(X)=>{let Y=X.prepare("SELECT generation FROM canvas_head WHERE singleton = 1").get();if(Y===void 0)return;let Q=X.prepare(`
        SELECT name, body
        FROM canvas_generation_documents
        WHERE generation = ?
      `).all(Y.generation),_=new Date().toISOString(),G=X.prepare(`
      INSERT INTO canvas_entities(
        canvas_name,
        entity_id,
        kind,
        binding_id,
        lifecycle,
        created_at,
        updated_at,
        archived_at,
        soft_deleted_at
      ) VALUES (?, ?, ?, ?, 'active', ?, ?, NULL, NULL)
      ON CONFLICT(canvas_name, entity_id) DO NOTHING
    `);for(let J of Q){if(J.body.length===0)continue;let Z;try{Z=JSON.parse(J.body)}catch{throw Error(`canvas entity backfill: document "${J.name}" is not valid JSON`)}if(Z===null||typeof Z!=="object"||!("nodes"in Z)||!Array.isArray(Z.nodes))throw Error(`canvas entity backfill: document "${J.name}" is not a canvas body with nodes[]`);let K=new Set;for(let H of Z.nodes){if(H===null||typeof H!=="object"||!("id"in H)||typeof H.id!=="string")throw Error(`canvas entity backfill: document "${J.name}" has a node without a string id`);let W=H.id;if(W.length===0||W.length>256)throw Error(`canvas entity backfill: document "${J.name}" has an out-of-range entity id`);let D=null,U=null,N=H.ether;if(N!==null&&typeof N==="object"){let B=N.entity;if(B!==null&&typeof B==="object"&&typeof B.kind==="string"){let O=B.kind;if(O.length>0&&O.length<=128)D=O}let q=N.terminal;if(q!==null&&typeof q==="object"&&typeof q.bindingId==="string"){let O=q.bindingId;if(O.length>0&&O.length<=256)U=O}}if(D===null){let B=H.type;if(typeof B==="string"&&B.length>0&&B.length<=128)D=B}if(U!==null)if(K.has(U))U=null;else K.add(U);G.run(J.name,W,D,U,_,_)}}},VS={baselineVersion:1,baselineIdentity:BS,currentVersion:p9,currentSchemaSql:HS,migrations:Q40},qS=(X)=>{let Y=X.prepare("PRAGMA user_version").get(),Q=Number(Y?.user_version);if(!Number.isSafeInteger(Q)||Q<0||Q>2147483647)throw Error(`state schema user_version is invalid: ${String(Y?.user_version)}`);return Q},tU=(X,Y)=>{if(!Number.isSafeInteger(Y)||Y<0||Y>2147483647)throw Error(`refusing invalid state schema version ${Y}`);X.exec(`PRAGMA user_version = ${Y}`)},G40=(X,Y)=>X.actualSchemaSha256===Y.actualSchemaSha256,W4=(X,Y,Q)=>{if(!G40(Y,Q))throw Error(`${X} identity is not a recognized Vellum Command schema`)},J40=(X)=>{let Y=X.prepare("PRAGMA foreign_key_check").all();if(Y.length>0)throw Error(`state schema migration leaves ${Y.length} foreign-key violation(s)`)},zS=(X)=>{let Y=X.prepare(`
        SELECT type, name, sql
        FROM sqlite_schema
        WHERE type IN ('table', 'index', 'view', 'trigger')
          AND name NOT GLOB 'sqlite_*'
        ORDER BY type COLLATE BINARY, name COLLATE BINARY
      `).all(),Q=new Map,_=new Map;for(let G of Y){let J=String(G.type),Z=String(G.name);if(J!=="table"){_.set(`${J}:${Z}`,G.sql===null?null:String(G.sql));continue}let K=X.prepare(`
          SELECT
            name,
            type,
            "notnull" AS not_null,
            dflt_value AS default_value,
            pk AS primary_key,
            hidden
          FROM pragma_table_xinfo(?)
          ORDER BY cid
        `).all(Z);Q.set(Z,new Map(K.map((H)=>[String(H.name),{name:String(H.name),type:String(H.type),notNull:Number(H.not_null),defaultValue:H.default_value===null?null:String(H.default_value),primaryKey:Number(H.primary_key),hidden:Number(H.hidden)}])))}return{tables:Q,retainedObjects:_}},$40=(X,Y,Q,_={indexes:new Set,triggers:new Set})=>{let G=zS(Y);for(let[J,Z]of X.tables){let K=G.tables.get(J);if(K===void 0)throw Error(`state schema startup migration removed table ${J}`);for(let[H,W]of Z){let D=K.get(H);if(D===void 0||JSON.stringify(D)!==JSON.stringify(W))throw Error(`state schema startup migration changed durable column ${J}.${H}`)}}for(let[J,Z]of X.retainedObjects){if(Q.has(J))continue;let K=J.indexOf(":");if(K>0){let H=J.slice(0,K),W=J.slice(K+1);if(H==="trigger"&&_.triggers.has(W))continue;if(H==="index"&&_.indexes.has(W))continue}if(G.retainedObjects.get(J)!==Z)throw Error(`state schema startup migration changed durable ${J}`)}},Z40=new Set([K0.SQLITE_DELETE,K0.SQLITE_DROP_INDEX,K0.SQLITE_DROP_TABLE,K0.SQLITE_DROP_TEMP_INDEX,K0.SQLITE_DROP_TEMP_TABLE,K0.SQLITE_DROP_TEMP_TRIGGER,K0.SQLITE_DROP_TEMP_VIEW,K0.SQLITE_DROP_TRIGGER,K0.SQLITE_DROP_VIEW,K0.SQLITE_DROP_VTABLE,K0.SQLITE_ATTACH,K0.SQLITE_DETACH,K0.SQLITE_REINDEX,K0.SQLITE_ANALYZE]),K40=new Set(["application_id","journal_mode","legacy_alter_table","schema_version","user_version","writable_schema"]),NS=(X)=>{let Y=X.replace(/--[^\r\n]*/gu," ").replace(/\/\*[\s\S]*?\*\//gu," ");if(/\balter\s+table\b[\s\S]*?\b(?:rename(?:\s+(?:to|column))?|drop\s+column)\b/iu.test(Y))throw Error("state schema startup migrations may not rename or drop tables or columns");if(/\b(?:insert\s+or\s+replace|replace\s+into)\b/iu.test(Y))throw Error("state schema startup migrations may not replace existing rows")},H40=(X,Y)=>{if(Y.size===0)return{indexes:new Set,triggers:new Set};let Q=[...Y],_=Q.map(()=>"?").join(", "),G=X.prepare(`
        SELECT type, name
        FROM sqlite_schema
        WHERE type IN ('index', 'trigger')
          AND tbl_name IN (${_})
      `).all(...Q),J=new Set,Z=new Set;for(let K of G)if(K.type==="index")J.add(K.name);else if(K.type==="trigger")Z.add(K.name);return{indexes:J,triggers:Z}},W40=(X,Y,Q,_)=>{if(Y)return!1;if(X>=Q.currentVersion)return!1;let G=X===0?Q.baselineVersion:X;if(G<Q.baselineVersion)return!1;while(G<Q.currentVersion){let J=_.get(G);if(J===void 0)return!1;if((J.replacesTables?.length??0)>0)return!0;G=J.toVersion}return!1},U40=(X,Y)=>{let Q=zS(X),_=new Set(Y.replacesObjects??[]),G=new Set(Y.replacesTables??[]),J=H40(X,G),Z={exec:(K)=>{NS(K),X.exec(K)},prepare:(K,H)=>{return NS(K),X.prepare(K,H)}};X.setAuthorizer((K,H,W)=>{let D=H===null?"":H.toLowerCase(),U=H==="sqlite_schema"||H==="sqlite_master",N=H!==null&&G.has(H),B=H!==null&&H.endsWith("__migrate_bak"),q=H!==null&&J.indexes.has(H),O=H!==null&&J.triggers.has(H);return K===K0.SQLITE_TRANSACTION||K===K0.SQLITE_SAVEPOINT||Z40.has(K)&&!(K===K0.SQLITE_REINDEX&&H!==null&&(!Q.retainedObjects.has(`index:${H}`)||q))&&!(K===K0.SQLITE_DROP_TRIGGER&&H!==null&&(_.has(`trigger:${H}`)||O))&&!(K===K0.SQLITE_DELETE&&(U&&(_.size>0||G.size>0)||N||B))&&!(K===K0.SQLITE_DROP_TABLE&&(N||B))&&!(K===K0.SQLITE_DROP_INDEX&&q)||K===K0.SQLITE_INSERT&&H!==null&&Q.tables.has(H)&&!G.has(H)||K===K0.SQLITE_UPDATE&&H!==null&&W!==null&&Q.tables.get(H)?.has(W)===!0||K===K0.SQLITE_PRAGMA&&H!==null&&K40.has(D)?K0.SQLITE_DENY:K0.SQLITE_OK});try{Y.migrate(Z),$40(Q,X,_,J)}finally{X.setAuthorizer(null)}if(!X.isTransaction)throw Error(`state schema migration ${Y.fromVersion} -> ${Y.toVersion} escaped its startup transaction`)},D40=(X,Y)=>{let Q,_;try{Q=LJ(X)}catch(J){_=J}let G=aU(X,Y);if(Q===void 0)throw _;return W4("recorded current state schema",Q,G),Q},N40=(X,Y)=>{let Q,_;try{Q=LJ(X)}catch(J){_=J}let G=sU(X,Y);if(Q===void 0)throw _;return W4("recorded current state schema",Q,G),Q},OS=(X)=>{if(!Number.isSafeInteger(X.baselineVersion)||X.baselineVersion<1||!Number.isSafeInteger(X.currentVersion)||X.currentVersion<X.baselineVersion)throw Error("state schema migration version bounds are invalid");let Y=new Map;for(let Q of X.migrations){if(!Number.isSafeInteger(Q.fromVersion)||Q.fromVersion<X.baselineVersion||Q.toVersion!==Q.fromVersion+1||Q.toVersion>X.currentVersion||Q.name.length===0||Q.safety!==D1)throw Error(`invalid state schema migration ${Q.fromVersion} -> ${Q.toVersion}`);if(Y.has(Q.fromVersion))throw Error(`duplicate state schema migration from version ${Q.fromVersion}`);Y.set(Q.fromVersion,Q)}for(let Q=X.baselineVersion;Q<X.currentVersion;Q+=1)if(!Y.has(Q))throw Error(`missing state schema migration ${Q} -> ${Q+1}`);return Y},LS=(X,Y=VS)=>{let Q=OS(Y),_=qS(X);if(_>Y.currentVersion)throw Error(`state schema version ${_} is newer than supported version ${Y.currentVersion}`);if(rU(X)){if(_!==0)throw Error(`fresh state database carries unexpected user_version ${_}`);return!1}if(_===Y.currentVersion&&_!==0)return!1;if(_===0&&Y.baselineVersion===Y.currentVersion)return N40(X,Y.currentSchemaSql),!0;let G=iU(X),J=_===0?Y.baselineVersion:_;if(_===0)W4("unversioned state schema baseline",G,Y.baselineIdentity);else if(_<Y.baselineVersion)throw Error(`state schema version ${_} predates the supported baseline ${Y.baselineVersion}`);let Z=Q.get(J);if(J<Y.currentVersion&&Z===void 0)throw Error(`missing state schema migration ${J} -> ${J+1}`);if(Z!==void 0)W4(`state schema version ${J}`,G,Z.fromIdentity);return!0},TS=(X,Y=VS)=>{let Q=OS(Y),_=qS(X);if(_>Y.currentVersion)throw Error(`state schema version ${_} is newer than supported version ${Y.currentVersion}`);let G=rU(X),J=W40(_,G,Y,Q),Z=!1;try{if(J)X.exec("PRAGMA foreign_keys = OFF"),Z=!0;X.exec("BEGIN IMMEDIATE");try{let K=_;if(G){if(K!==0)throw Error(`fresh state database carries unexpected user_version ${K}`);X.exec(Y.currentSchemaSql),K=Y.currentVersion}else{let W=K===Y.currentVersion||K===0&&Y.baselineVersion===Y.currentVersion?D40(X,Y.currentSchemaSql):iU(X);if(K===0)W4("unversioned state schema baseline",W,Y.baselineIdentity),K=Y.baselineVersion,tU(X,K);else if(K<Y.baselineVersion)throw Error(`state schema version ${K} predates the supported baseline ${Y.baselineVersion}`);while(K<Y.currentVersion){let D=Q.get(K);if(D===void 0)throw Error(`missing state schema migration ${K} -> ${K+1}`);if(W4(`state schema version ${K}`,W,D.fromIdentity),U40(X,D),K=D.toVersion,tU(X,K),K<Y.currentVersion){let U=Q.get(K);if(U===void 0)throw Error(`missing state schema migration ${K} -> ${K+1}`);let N=oU(X);W4(`migrated state schema version ${K}`,{actualSchemaSha256:N},U.fromIdentity),nU(X,U.fromIdentity),W=U.fromIdentity}}if(_===Y.currentVersion)W4(`state schema version ${Y.currentVersion}`,W,DS(Y.currentSchemaSql))}let H=aU(X,Y.currentSchemaSql);return J40(X),tU(X,Y.currentVersion),X.exec("COMMIT"),{...H,schemaVersion:Y.currentVersion,previousVersion:_,initialized:G}}catch(K){try{X.exec("ROLLBACK")}catch{}throw K}}finally{if(Z)try{X.exec("PRAGMA foreign_keys = ON")}catch{}}};import{existsSync as n40,lstatSync as s40}from"node:fs";import{resolve as a40}from"node:path";import{DatabaseSync as t40}from"node:sqlite";import{chmodSync as vS,lstatSync as xS,mkdirSync as m40}from"node:fs";import{homedir as B40}from"node:os";import{isAbsolute as V40,join as fH0,resolve as q40}from"node:path";var eU,z40=(X)=>{if(X===void 0)return;let Y=X.trim();if(Y.length===0)return;if(Y.length>4096)return;if(/[\u0000-\u001f\u007f]/.test(Y))return;if(!V40(Y))return;return q40(Y)},RS=()=>{if(eU===void 0)eU=z40(process.env.VELLUM_COMMAND_HOME)??B40();return eU};import{dirname as d40,join as f40,resolve as kS}from"node:path";import{DatabaseSync as p40}from"node:sqlite";class N_ extends $.TaggedErrorClass()("StateEngineError",{operation:$.String,message:$.String,cause:$.Unknown}){}class B_ extends k1.Service()("@vellum/StateEngine"){}import{mkdtempDisposableSync as O40}from"node:fs";import{tmpdir as L40}from"node:os";import{join as _D}from"node:path";var XD,YD=()=>{if(XD===void 0)XD=process.argv.includes("--vellum-demo")||process.env.VELLUM_COMMAND_DEMO==="1";return XD};var u9,QD=!1,FS=()=>{T40()},ES=()=>{if(u9!==void 0)return u9;return u9=O40(_D(L40(),"vellum-command-demo-runtime-")),process.once("exit",FS),QD=!0,u9},AS=()=>YD()?_D(ES().path,"vellum-command.db"):void 0,T40=()=>{if(QD)process.off("exit",FS),QD=!1;let X=u9;u9=void 0,X?.remove()};if(YD()&&!process.env.VELLUM_COMMAND_CANVASES_DIR)process.env.VELLUM_COMMAND_CANVASES_DIR=_D(ES().path,"projections");import{randomUUID as R40}from"node:crypto";import{chmodSync as F40,closeSync as JD,constants as L5,fchmodSync as E40,fstatSync as $D,fsyncSync as CS,linkSync as A40,lstatSync as _6,mkdirSync as P40,openSync as ZD,readdirSync as w40,unlinkSync as MS}from"node:fs";import{join as RJ}from"node:path";import{DatabaseSync as C40}from"node:sqlite";var PS=448,M40=384,IS="backups",I40="vellum-command-backup-",j40=".pending",S40=/^vellum-command-backup-[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\.db\.pending$/u,TJ=(X)=>{try{let Y=_6(X);if(!Y.isFile()||Y.isSymbolicLink())throw Error(`state backup is not a regular file: ${X}`);return!0}catch(Y){if(typeof Y==="object"&&Y!==null&&"code"in Y&&Y.code==="ENOENT")return!1;throw Y}},v40=(X)=>{let Y=ZD(X,L5.O_RDONLY|L5.O_NOFOLLOW);try{let Q=$D(Y);if(!Q.isFile())throw Error(`state backup is not a regular file: ${X}`);E40(Y,M40);let _=_6(X);if(!_.isFile()||_.isSymbolicLink()||_.dev!==Q.dev||_.ino!==Q.ino)throw Error(`state backup path changed during creation: ${X}`);return{device:Q.dev,inode:Q.ino}}finally{JD(Y)}},x40=(X,Y)=>{try{let Q=_6(X);if(Q.isFile()&&!Q.isSymbolicLink()&&Q.dev===Y.device&&Q.ino===Y.inode)MS(X)}catch{}},GD=(X,Y)=>{let Q=_6(X);if(!Q.isFile()||Q.isSymbolicLink()||Q.dev!==Y.device||Q.ino!==Y.inode)throw Error(`state backup path changed before removal: ${X}`);MS(X)},k40=(X,Y)=>{let Q=ZD(X,L5.O_RDONLY|L5.O_NOFOLLOW);try{let _=$D(Q),G=_6(X);if(!_.isFile()||!G.isFile()||G.isSymbolicLink()||_.dev!==Y.device||_.ino!==Y.inode||G.dev!==Y.device||G.ino!==Y.inode)throw Error(`state backup path changed before sync: ${X}`);CS(Q)}finally{JD(Q)}},FJ=(X)=>{let Y=ZD(X,L5.O_RDONLY|L5.O_NOFOLLOW|L5.O_DIRECTORY);try{if(!$D(Y).isDirectory())throw Error(`state backup path is not a real directory: ${X}`);CS(Y)}finally{JD(Y)}},b40=(X)=>{let Y=RJ(X,IS),Q=!1;try{P40(Y,{mode:PS}),Q=!0}catch(G){if(typeof G!=="object"||G===null||!("code"in G)||G.code!=="EEXIST")throw G}let _=_6(Y);if(!_.isDirectory()||_.isSymbolicLink())throw Error(`state backup path is not a real directory: ${Y}`);if(F40(Y,PS),Q)FJ(X);return Y},g40=(X)=>{let Y=RJ(X,IS),Q;try{let G=_6(Y);if(!G.isDirectory()||G.isSymbolicLink())throw Error(`state backup path is not a real directory: ${Y}`);Q=w40(Y)}catch(G){if(typeof G==="object"&&G!==null&&"code"in G&&G.code==="ENOENT")return;throw G}let _=!1;for(let G of Q){if(!S40.test(G))continue;let J=RJ(Y,G),Z=_6(J);if(!Z.isFile()||Z.isSymbolicLink())throw Error(`pending state backup is not a regular file: ${J}`);GD(J,{device:Z.dev,inode:Z.ino}),_=!0}if(_)FJ(Y)},y40=(X)=>`"${X.replaceAll('"','""')}"`,wS=(X)=>{let Y=X.prepare("PRAGMA user_version").get(),Q=X.prepare(`
      SELECT actual_schema_sha256
      FROM state_schema_identity
      WHERE singleton = 1
    `).get();if(Q===void 0)throw Error("state backup source has no schema identity witness");let _=X.prepare(`
      SELECT type, name, tbl_name AS table_name, sql
      FROM sqlite_schema
      WHERE type IN ('table', 'index', 'view', 'trigger')
        AND name NOT GLOB 'sqlite_*'
      ORDER BY type COLLATE BINARY, name COLLATE BINARY
    `).all(),G=_.filter((J)=>J.type==="table");return{userVersion:Number(Y?.user_version),identity:{actualSchemaSha256:String(Q.actual_schema_sha256)},schema:_.map((J)=>({type:String(J.type),name:String(J.name),tableName:String(J.table_name),sql:J.sql===null?null:String(J.sql)})),rowCounts:G.map((J)=>{let Z=String(J.name),K=X.prepare(`SELECT count(*) AS count FROM ${y40(Z)}`).get();return{tableName:Z,count:Number(K?.count)}})}},h40=(X,Y)=>{if(JSON.stringify(X)!==JSON.stringify(Y))throw Error("state backup witness does not match its live source")},KD=(X,Y)=>{let Q=wS(X);g40(Y);let _=b40(Y),G=R40(),J=RJ(_,`${I40}${G}.db`),Z=`${J}${j40}`;if(TJ(J))throw Error(`backup destination already exists: ${J}`);if(TJ(Z))throw Error(`backup destination already exists: ${Z}`);try{X.prepare("VACUUM INTO ?").run(Z)}catch(U){if(TJ(Z)){let N=_6(Z);GD(Z,{device:N.dev,inode:N.ino}),FJ(_)}throw U}let K=_6(Z);if(!K.isFile()||K.isSymbolicLink())throw Error(`state backup is not a regular file: ${Z}`);let H={device:K.dev,inode:K.ino},W,D=!1;try{let U=v40(Z);if(U.device!==H.device||U.inode!==H.inode)throw Error(`state backup path changed during creation: ${Z}`);W=new C40(Z,{open:!0,readOnly:!0,allowExtension:!1,enableForeignKeyConstraints:!0,enableDoubleQuotedStringLiterals:!1,allowBareNamedParameters:!1,allowUnknownNamedParameters:!1});let N=W.prepare("PRAGMA quick_check").all();if(N.length!==1||String(N[0]?.quick_check)!=="ok")throw Error("state backup quick_check failed");let B=W.prepare("PRAGMA foreign_key_check").all();if(B.length>0)throw Error(`state backup has ${B.length} foreign-key violation(s)`);if(h40(Q,wS(W)),W.close(),W=void 0,k40(Z,H),TJ(J))throw Error(`backup destination already exists: ${J}`);A40(Z,J);let q=_6(J);if(!q.isFile()||q.isSymbolicLink()||q.dev!==H.device||q.ino!==H.inode)throw Error(`state backup changed during publication: ${J}`);GD(Z,H),FJ(_),D=!0}finally{if(W?.close(),!D)x40(Z,H)}return{path:J,schemaSha256:Q.identity.actualSchemaSha256,schemaVersion:Q.userVersion}};var jS=448,u40=384,SS=5000,c40=64,EJ=(X,Y)=>Y instanceof N_?Y:N_.make({operation:X,message:Y instanceof Error?Y.message:String(Y),cause:Y}),WD=()=>kS(AS()??f40(RS(),".vellum-command","state","vellum-command.db")),l40=(X)=>{m40(X,{recursive:!0,mode:jS});let Y=xS(X);if(!Y.isDirectory()||Y.isSymbolicLink())throw Error(`state path is not a real directory: ${X}`);vS(X,jS)},o40=(X)=>{try{let Y=xS(X);if(!Y.isFile()||Y.isSymbolicLink())throw Error(`state database is not a regular file: ${X}`);return!0}catch(Y){if(typeof Y==="object"&&Y!==null&&"code"in Y&&Y.code==="ENOENT")return!1;throw Y}},HD=(X,Y,Q,_)=>{if(Y===void 0)return Q();if(Array.isArray(Y))return Q(...Y);return _({...Y})},r40=(X)=>c0.try({try:()=>{let Y=kS(X??WD()),Q=d40(Y);l40(Q),o40(Y);let _=new p40(Y,{open:!0,readOnly:!1,allowExtension:!1,enableForeignKeyConstraints:!0,enableDoubleQuotedStringLiterals:!1,allowBareNamedParameters:!1,allowUnknownNamedParameters:!1,timeout:SS}),G=!1,J=new Map,Z=!1,K=(()=>{try{if(vS(Y,u40),_.exec(`
            PRAGMA foreign_keys = ON;
            PRAGMA busy_timeout = ${SS};
            PRAGMA trusted_schema = OFF;
          `),LS(_))KD(_,Q);let w=TS(_);return _.exec(`
            PRAGMA journal_mode = WAL;
            PRAGMA synchronous = NORMAL;
          `),w}catch(w){throw _.close(),w}})(),H=()=>{if(G)throw Error("state engine is closed")},W=(w)=>{H();let L=J.get(w);if(L)return L;let E=_.prepare(w);return J.set(w,E),E},D={get:(w,L)=>HD(W(w),L,(...E)=>W(w).get(...E),(E)=>W(w).get(E)),all:(w,L)=>HD(W(w),L,(...E)=>W(w).all(...E),(E)=>W(w).all(E))},U={...D,run:(w,L)=>HD(W(w),L,(...E)=>W(w).run(...E),(E)=>W(w).run(E))},N=(w,L)=>c0.try({try:()=>{return H(),L(D)},catch:(E)=>EJ(w,E)}).pipe(c0.withSpan(`state.${w}`)),B=(w,L)=>c0.try({try:()=>{if(H(),Z)throw Error(`nested state transaction is not allowed (${w})`);Z=!0,_.exec("BEGIN IMMEDIATE");try{let E=L(U);return _.exec("COMMIT"),E}catch(E){try{_.exec("ROLLBACK")}catch{}throw E}finally{Z=!1}},catch:(E)=>EJ(w,E)}).pipe(c0.withSpan(`state.${w}`)),q=(w,L,E,j={})=>c0.gen(function*(){let t=Math.max(1,Math.floor(j.chunkRows??c40));for(let z0=0;z0<L.length;z0+=t){let I1=L.slice(z0,z0+t);if(yield*B(`${w}.chunk`,($1)=>E($1,I1)),z0+t<L.length)yield*c0.sleep("1 millis")}}).pipe(c0.withSpan(`state.${w}`)),O=()=>c0.try({try:()=>{return H(),KD(_,Q)},catch:(w)=>EJ("backup",w)}).pipe(c0.withSpan("state.backup")),R=D.get("PRAGMA journal_mode")?.journal_mode,F=D.get("PRAGMA synchronous")?.synchronous,P=D.get("PRAGMA foreign_keys")?.foreign_keys,C={path:Y,journalMode:String(R??""),synchronous:Number(F??-1),foreignKeys:Number(P??0)===1,schemaSha256:K.actualSchemaSha256,schemaVersion:K.schemaVersion};return{service:B_.of({info:C,read:N,transaction:B,chunkedWrite:q,backup:O}),close:()=>{if(G)return;G=!0,J.clear(),_.close()}}},catch:(Y)=>EJ("open",Y)}),i40=(X)=>i5.effect(B_,c0.acquireRelease(r40(X),({close:Y})=>c0.sync(Y)).pipe(c0.map(({service:Y})=>Y))),DW0=i40();var e40=(X)=>{try{let Y=s40(X);return Y.isFile()&&!Y.isSymbolicLink()}catch{return!1}},UD=(X)=>{let Y=a40(X??WD());if(!n40(Y))return{kind:"missing"};if(!e40(Y))return{kind:"unreadable",message:`state database path is not a regular file: ${Y}`};let Q;try{Q=new t40(Y,{open:!0,readOnly:!0,allowExtension:!1,enableForeignKeyConstraints:!0,enableDoubleQuotedStringLiterals:!1,allowBareNamedParameters:!1,allowUnknownNamedParameters:!1,timeout:2000});let _=Q.prepare("PRAGMA user_version").get(),G=Number(_?.user_version??0);if(!Number.isSafeInteger(G)||G<0)return{kind:"unreadable",message:`state schema user_version is invalid: ${String(_?.user_version)}`};return{kind:"present",userVersion:G,path:Y}}catch(_){return{kind:"unreadable",message:_ instanceof Error?_.message:String(_)}}finally{try{Q?.close()}catch{}}},bS=(X=UD(),Y=p9)=>{if(X.kind==="missing")return{ok:!0,userVersion:null};if(X.kind==="unreadable")return{ok:!0,userVersion:null};if(X.userVersion>Y)return{ok:!1,reason:"newer-than-supported",userVersion:X.userVersion,supportedVersion:Y,path:X.path};return{ok:!0,userVersion:X.userVersion}};var T5=5,AJ=$.Number.pipe($.check($.isInt()),$.check($.isGreaterThan(0)),$.check($.makeFilter(Number.isSafeInteger,{message:"Station protocol version must be a safe integer"}))),gS=$.Struct({preferred:AJ,compatibleFrom:AJ,warnBelow:AJ}).pipe($.check($.makeFilter(({compatibleFrom:X,warnBelow:Y,preferred:Q})=>X<=Y&&Y<=Q,{message:"Station protocol support must satisfy compatibleFrom <= warnBelow <= preferred"}))),PJ=gS.make({preferred:T5,compatibleFrom:T5,warnBelow:T5}),yS=(X,Y)=>{let Q=Math.max(X.compatibleFrom,Y.compatibleFrom),_=Math.min(X.preferred,Y.preferred);if(Q>_)return{_tag:"no-common",local:X,peer:Y};let G=_<X.warnBelow,J=_<Y.warnBelow;return{_tag:"selected",selected:_,deprecatedForLocal:G,deprecatedForPeer:J,warning:G||J}},X50=$.NonEmptyString.pipe($.check($.isMaxLength(64))),Y50=$.Number.pipe($.check($.isInt()),$.check($.isGreaterThan(0)),$.check($.makeFilter(Number.isSafeInteger,{message:"state schema version must be a safe integer"}))),wJ="vellum-command/station-protocol-preface/v1",DD={appVersion:X50,stateSchemaVersion:Y50,support:gS},Q50=$.Struct({protocol:$.Literal(wJ),frame:$.Literal("offer"),...DD}),_50=$.Struct({protocol:$.Literal(wJ),frame:$.Literal("accept"),...DD,selected:AJ}),hS=$.Struct({protocol:$.Literal(wJ),frame:$.Literal("reject"),...DD,reason:$.Literal("no-common-version"),retryable:$.Literal(!1)}),G50=$.Union([Q50,_50,hS]),FW0=$.decodeUnknownResult(G50,{onExcessProperty:"error"});var mS=(X)=>hS.make({protocol:wJ,frame:"reject",...X,reason:"no-common-version",retryable:!1}),ND=(X)=>X===T5?g0.succeed(T5):g0.fail("unsupported-station-protocol");var U4=$.String.pipe($.check($.isMinLength(1)),$.check($.isMaxLength(128)),$.check($.isPattern(/^[A-Za-z0-9][A-Za-z0-9._:-]*$/)),$.brand("InstallationId"));var BD="vellum/work/v2",dS=262144,J50=2048,$50=64,fS=$.String.pipe($.check($.isPattern(/^[1-9][0-9]*$/)),$.check($.isMaxLength(32)),$.brand("WorkLogicalSequence")),R5=$.String.pipe($.check($.isPattern(/^[a-f0-9]{64}$/)),$.brand("WorkSha256")),VD=$.String.pipe($.check($.isMinLength(1)),$.check($.isMaxLength($50))),Z50=$.String.pipe($.check($.isMinLength(1)),$.check($.isMaxLength(J50))),K50=$.Struct({eventHome:U4,entityHome:U4}),D4=$.Struct({route:K50,seq:fS}),pS=$.String.pipe($.check($.isPattern(/^(0|[1-9][0-9]*)$/)),$.check($.isMaxLength(32)),$.brand("FactBasisGeneration")),uS=$.Struct({kind:$.Literal("authorial-intent"),generation:pS,contentSha256:R5}),cS=$.Struct({kind:$.Literal("projected-intent"),generation:pS,contentSha256:R5}),H50=$.Struct({kind:$.Literal("command"),command:D4,commandSha256:R5}),W50=$.Union([uS,cS,H50]),dW0=$.Union([uS,cS]),fW0=$.Struct({eventHome:U4,entityHome:U4,through:fS}),U50=$.Literals(["proposal.create","proposal.approve","proposal.reject","task.create","task.describe","task.transition","task.claim","request.create","request.resolve","message.append","artifact.publish","delivery.accepted","board.topic.create","board.post.append","pad.patch"]),D50=$.Struct({operation:$.Literal("proposal.create"),proposal:V5}).pipe($.check($.makeFilter(({proposal:X})=>X.state==="pending"||"proposal.create requires a pending proposal"))),N50=$.Struct({operation:$.Literal("proposal.approve"),proposalId:SX,task:zX}).pipe($.check($.makeFilter(({task:X})=>X.state==="submitted"&&X.claimedBy===void 0||"proposal.approve requires a submitted unclaimed task"))),B50=$.Struct({operation:$.Literal("proposal.reject"),proposalId:SX}),lS=$.Struct({deliveryId:SX,deliveredItem:aG,actor:Y6,acceptedAt:VD}),V50=$.Struct({operation:$.Literal("task.create"),task:zX}).pipe($.check($.makeFilter(({task:X})=>X.state==="submitted"&&X.claimedBy===void 0||"task.create requires a submitted task snapshot"))),q50=$.Struct({operation:$.Literal("task.describe"),taskId:SX,message:N8}),z50=$.Struct({operation:$.Literal("task.transition"),taskId:SX,state:g9,message:$.optionalKey(N8),completionEvidence:$.optionalKey(h9)}).pipe($.check($.makeFilter(({state:X,completionEvidence:Y})=>Y===void 0||X==="completed"||"completionEvidence is only allowed when state is completed"))),O50=$.Struct({operation:$.Literal("task.claim"),sourceQueueHome:U4,sourcePredecessor:$.NullOr(D4),sourceTask:zX,sink:sG,actor:Y6,targetHome:U4}).pipe($.check($.makeFilter((X)=>{if(X.sourceTask.state!=="submitted")return"task.claim requires a submitted source task snapshot";if(X.sourceTask.claimedBy!==void 0)return"task.claim requires an unclaimed source task snapshot";if(X.sourceQueueHome===X.targetHome)return"task.claim command must cross authority installations";if(X.sourcePredecessor!==null&&(X.sourcePredecessor.route.eventHome!==X.sourceQueueHome||X.sourcePredecessor.route.entityHome!==X.sourceQueueHome))return"task.claim source predecessor must belong to the source queue authority lane";return!0}))),L50=$.Struct({operation:$.Literal("request.create"),request:zX,raisedBy:Y6}).pipe($.check($.makeFilter(({request:X,raisedBy:Y})=>X.state==="input-required"&&X.claimedBy===Y.seatId||"request.create requires an input-required request claimed by its raiser"))),T50=$.Struct({operation:$.Literal("request.resolve"),requestId:SX,response:$.String,disposition:$.Literals(["completed","rejected"]),message:$.optionalKey(N8)}),R50=$.Union([$.Struct({kind:$.Literal("mailbox")}),$.Struct({kind:$.Literal("task"),itemId:SX}),$.Struct({kind:$.Literal("request"),itemId:SX})]),oS={message:N8,sentBy:Y6,destination:R50},rS=(X)=>X.destination.kind==="mailbox"||X.message.taskId===X.destination.itemId?!0:"task/request message destination must equal Message.taskId",F50=$.Struct({operation:$.Literal("message.append"),...oS}).pipe($.check($.makeFilter(rS))),E50=$.Struct({operation:$.Literal("artifact.publish"),artifact:J_,publishedBy:Y6}),A50=$.Struct({operation:$.Literal("delivery.accepted"),receipt:lS}),P50=$.Struct({operation:$.Literal("board.topic.create"),topic:Z_,createdBy:vX}),w50=$.Struct({operation:$.Literal("board.post.append"),post:$_,createdBy:vX}),C50=$.Struct({operation:$.Literal("pad.patch"),patchId:SX,patches:$.Array(m9).pipe($.check($.isMinLength(1))),author:vX}),iS=$.Union([D50,N50,B50,V50,q50,z50,O50,L50,T50,F50,E50,A50,P50,w50,C50]),M50=$.Struct({operation:$.Literal("proposal.create"),proposal:V5}).pipe($.check($.makeFilter(({proposal:X})=>X.state==="pending"||"proposal.create result requires a pending proposal"))),I50=$.Struct({operation:$.Literal("proposal.approve"),proposal:V5,task:zX}).pipe($.check($.makeFilter(({proposal:X,task:Y})=>X.state==="approved"&&X.approvedTaskId===Y.id&&Y.state==="submitted"&&Y.claimedBy===void 0||"proposal.approve result must bind the approved proposal to its submitted task"))),j50=$.Struct({operation:$.Literal("proposal.reject"),proposal:V5}).pipe($.check($.makeFilter(({proposal:X})=>X.state==="rejected"||"proposal.reject result requires a rejected proposal"))),S50=$.Struct({operation:$.Literal("task.create"),task:zX}).pipe($.check($.makeFilter(({task:X})=>X.state==="submitted"&&X.claimedBy===void 0||"task.create result requires a submitted unclaimed task"))),v50=$.Struct({operation:$.Literals(["task.describe","task.transition"]),task:zX}),x50=$.Struct({operation:$.Literal("task.claim"),task:zX,claimedBy:Y6,previousHome:U4}).pipe($.check($.makeFilter(({task:X,claimedBy:Y})=>X.state==="working"&&X.claimedBy===Y.seatId||"task.claim result requires a working task claimed by the exact actor seat"))),k50=$.Struct({operation:$.Literals(["request.create","request.resolve"]),request:zX}).pipe($.check($.makeFilter((X)=>{if(X.operation==="request.create")return X.request.state==="input-required"&&X.request.claimedBy!==void 0||"request.create result requires an input-required request with a claimant";return(X.request.state==="completed"||X.request.state==="rejected")&&X.request.claimedBy!==void 0||"request.resolve result requires a completed or rejected request with its original claimant"}))),b50=$.Struct({operation:$.Literal("message.append"),...oS}).pipe($.check($.makeFilter(rS))),g50=$.Struct({operation:$.Literal("artifact.publish"),artifact:J_,publishedBy:Y6}),y50=$.Struct({operation:$.Literal("delivery.accepted"),receipt:lS}),h50=$.Struct({operation:$.Literal("board.topic.create"),topic:Z_,createdBy:vX}),m50=$.Struct({operation:$.Literal("board.post.append"),post:$_,createdBy:vX}),d50=$.Struct({operation:$.Literal("pad.patch"),patchId:SX,patches:$.Array(m9).pipe($.check($.isMinLength(1))),author:vX,revision:$.Number.pipe($.check($.isInt()),$.check($.isGreaterThanOrEqualTo(0)))}),nS=$.Union([M50,I50,j50,S50,v50,x50,k50,b50,g50,y50,h50,m50,d50]),f50=$.Literals(["authority-mismatch","capability-denied","causal-conflict","claim-contention","identity-conflict","invalid-transition","locality-mismatch","missing-entity","projection-conflict","target-mismatch"]),p50=$.Struct({status:$.Literal("applied"),command:D4,commandSha256:R5,fact:D4,factSha256:R5}),u50=$.Struct({status:$.Literal("rejected"),command:D4,commandSha256:R5,reason:f50,message:Z50}),c50=$.Union([p50,u50]),qD=$.Struct({protocol:$.Literal(BD),id:D4,recordType:$.Literals(["command","fact","disposition"]),item:aG,operation:U50,contentSha256:R5,originAt:VD}),l50=(X,Y)=>X.canvasName===Y.canvasName&&X.nodeId===Y.nodeId,sS=(X,Y,Q)=>X.kind==="artifact"&&X.itemId===Y.artifactId&&Q.canvasName===X.sink.canvasName&&(Y.task===void 0||Y.task.sink.canvasName===X.sink.canvasName),o50=(X,Y)=>{switch(Y.operation){case"proposal.create":return X.kind==="proposal"&&X.itemId===Y.proposal.id;case"proposal.approve":case"proposal.reject":return X.kind==="proposal"&&X.itemId===Y.proposalId;case"task.create":return X.kind==="task"&&X.itemId===Y.task.id;case"task.describe":case"task.transition":return X.kind==="task"&&X.itemId===Y.taskId;case"task.claim":return X.kind==="task"&&X.itemId===Y.sourceTask.id&&l50(X.sink,Y.sink);case"request.create":return X.kind==="request"&&X.itemId===Y.request.id;case"request.resolve":return X.kind==="request"&&X.itemId===Y.requestId;case"message.append":return X.kind==="message"&&X.itemId===Y.message.messageId;case"artifact.publish":return sS(X,Y.artifact,Y.publishedBy);case"delivery.accepted":return X.kind==="delivery"&&X.itemId===Y.receipt.deliveryId;case"board.topic.create":return X.kind==="topic"&&X.itemId===Y.topic.topicId;case"board.post.append":return X.kind==="post"&&X.itemId===Y.post.postId;case"pad.patch":return X.kind==="pad"&&X.itemId===Y.patchId}},r50=(X,Y)=>{switch(Y.operation){case"proposal.create":case"proposal.approve":case"proposal.reject":return X.kind==="proposal"&&X.itemId===Y.proposal.id;case"task.create":case"task.describe":case"task.transition":case"task.claim":return X.kind==="task"&&X.itemId===Y.task.id;case"request.create":case"request.resolve":return X.kind==="request"&&X.itemId===Y.request.id;case"message.append":return X.kind==="message"&&X.itemId===Y.message.messageId;case"artifact.publish":return sS(X,Y.artifact,Y.publishedBy);case"delivery.accepted":return X.kind==="delivery"&&X.itemId===Y.receipt.deliveryId;case"board.topic.create":return X.kind==="topic"&&X.itemId===Y.topic.topicId;case"board.post.append":return X.kind==="post"&&X.itemId===Y.post.postId;case"pad.patch":return X.kind==="pad"&&X.itemId===Y.patchId}},aS=(X)=>X==="proposal.create"||X==="task.create"||X==="task.claim"||X==="request.create"||X==="message.append"||X==="artifact.publish"||X==="delivery.accepted"||X==="board.topic.create"||X==="board.post.append"||X==="pad.patch",i50=(X)=>{try{let Y=JSON.stringify(X);return Y===void 0?void 0:new TextEncoder().encode(Y).byteLength}catch{return}};var zD=(X)=>{let Y=i50(X);if(Y===void 0)return"Work record must be JSON-serializable";return Y<=dS||`Work record exceeds ${dS} encoded bytes`},n50=$.Struct({...qD.fields,recordType:$.Literal("command"),predecessor:$.NullOr(D4),body:iS}),s50=n50.pipe($.check($.makeFilter((X)=>{if(X.id.route.eventHome===X.id.route.entityHome)return"Work command event and entity homes must be different";if(X.operation!==X.body.operation)return"Work command operation must match its action";if(!o50(X.item,X.body))return"Work command item must match its action identity";if(X.body.operation==="task.claim"){if(X.predecessor!==null)return"Cross-home task.claim command predecessor must be null";if(X.id.route.entityHome!==X.body.targetHome)return"task.claim targetHome must match command entityHome";return!0}if(aS(X.operation))return X.predecessor===null||"Create command predecessor must be null";return X.predecessor!==null||"Mutation command must name its predecessor"})),$.check($.makeFilter(zD))),a50=$.Struct({...qD.fields,recordType:$.Literal("fact"),basis:W50,predecessor:$.NullOr(D4),body:nS}),t50=a50.pipe($.check($.makeFilter((X)=>{if(X.id.route.eventHome!==X.id.route.entityHome)return"Work fact must be emitted by its entity authority home";if(X.operation!==X.body.operation)return"Work fact operation must match its result";if(!r50(X.item,X.body))return"Work fact item must match its result identity";if(X.basis.kind==="command"&&X.basis.command.route.entityHome!==X.id.route.entityHome)return"Command fact basis must address the fact authority lane";if(X.body.operation==="task.claim"){if(X.body.previousHome!==X.id.route.entityHome)return X.predecessor===null||"First cross-home task.claim fact predecessor must be null";return X.predecessor!==null||"Same-home task.claim fact must name its submitted predecessor"}if(aS(X.operation))return X.predecessor===null||"Create fact predecessor must be null";return X.predecessor!==null||"Mutation fact must name its predecessor"})),$.check($.makeFilter(zD))),e50=$.Struct({...qD.fields,recordType:$.Literal("disposition"),body:c50}),X90=e50.pipe($.check($.makeFilter((X)=>{if(X.id.route.eventHome!==X.id.route.entityHome)return"Work disposition must be emitted by its entity authority home";if(X.body.command.route.entityHome!==X.id.route.entityHome)return"Work disposition must address the command entity authority lane";if(X.body.status==="applied"&&(X.body.fact.route.eventHome!==X.id.route.eventHome||X.body.fact.route.entityHome!==X.id.route.entityHome))return"Applied disposition fact must belong to the disposition authority lane";return!0})),$.check($.makeFilter(zD))),tS=$.Union([s50,t50,X90]),Y90=$.Struct({record:tS,receivedAt:VD}),CJ={onExcessProperty:"error"},pW0=$.decodeUnknownResult(iS,CJ),uW0=$.decodeUnknownResult(nS,CJ),OD=$.decodeUnknownResult(tS,CJ),cW0=$.decodeUnknownResult(Y90,CJ);var eS=(X)=>g0.isSuccess(X)?{ok:!0,value:X.success}:{ok:!1,error:String(X.failure)},Xv=(X)=>{let Y=OD(X);return g0.isSuccess(Y)?{accepted:!0}:{accepted:!1,error:String(Y.failure),namesAdmission:/admission/u.test(String(Y.failure)),namesRaisedBy:/raisedBy/u.test(String(Y.failure))}},Yv=()=>JSON.parse(Q90(0,"utf8")),Qv=()=>({tasksCreateSchemaId:QJ.schema_id,stateSchemaVersion:p9,stationProtocolBaseline:T5,stationProtocolSupport:PJ,workProtocol:BD}),_90=()=>mS({appVersion:"qualification-probe",stateSchemaVersion:p9,support:PJ}),_v=process.argv[2],V_;switch(_v){case"cohort":V_=Qv();break;case"decode-work-record":V_=eS(OD(Yv()));break;case"matrix":{let X=Yv(),Y=yS(PJ,X.peer),Q=0,_=Y._tag==="no-common"?{accepted:!1,reason:"no-common-version"}:(()=>{let G=ND(Y.selected);if(g0.isFailure(G))return{accepted:!1,reason:String(G.failure)};return Q+=1,Xv(X.guardedRecord)})();V_={cohort:Qv(),records:Object.fromEntries(Object.entries(X.records).map(([G,J])=>[G,Xv(J)])),negotiation:Y,localCodecForPeerPreferred:eS(ND(X.peer.preferred)),guarded:{versionedDecoderInvocations:Q,result:_,...Y._tag==="no-common"?{rejection:_90()}:{}}};break}case"schema-probe":{let X=process.argv[3];if(X===void 0)throw TypeError("schema-probe requires a path");let Y=UD(X);V_={probe:Y,compatibility:bS(Y)};break}default:throw TypeError(`unknown command: ${String(_v)}`)}process.stdout.write(`${JSON.stringify(V_)}
`);
