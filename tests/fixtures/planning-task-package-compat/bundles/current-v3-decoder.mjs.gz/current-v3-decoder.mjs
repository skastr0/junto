var yv=Object.defineProperty;var hv=(X)=>X;function mv(X,Y){this[X]=hv.bind(null,Y)}var k6=(X,Y)=>{for(var Q in Y)yv(X,Q,{get:Y[Q],enumerable:!0,configurable:!0,set:mv.bind(Y,Q)})};import{readFileSync as lQ0}from"node:fs";var b1={};k6(b1,{pick:()=>jk,omit:()=>Ik,mutate:()=>xk,mergeAll:()=>LZ,merge:()=>b5,makeUnsafe:()=>j8,make:()=>D6,isReference:()=>BZ,isKey:()=>Pk,isContext:()=>t7,getUnsafe:()=>PX,getReferenceUnsafe:()=>zZ,getOrUndefined:()=>VZ,getOrElse:()=>Ek,getOption:()=>qZ,get:()=>v1,empty:()=>k1,addOrOmit:()=>Ck,add:()=>i1,ServiceTypeId:()=>s7,Service:()=>hX,Reference:()=>O0});var G0=(X,Y)=>{switch(Y.length){case 0:return X;case 1:return Y[0](X);case 2:return Y[1](Y[0](X));case 3:return Y[2](Y[1](Y[0](X)));case 4:return Y[3](Y[2](Y[1](Y[0](X))));case 5:return Y[4](Y[3](Y[2](Y[1](Y[0](X)))));case 6:return Y[5](Y[4](Y[3](Y[2](Y[1](Y[0](X))))));case 7:return Y[6](Y[5](Y[4](Y[3](Y[2](Y[1](Y[0](X)))))));case 8:return Y[7](Y[6](Y[5](Y[4](Y[3](Y[2](Y[1](Y[0](X))))))));case 9:return Y[8](Y[7](Y[6](Y[5](Y[4](Y[3](Y[2](Y[1](Y[0](X)))))))));default:{let Q=X;for(let J=0,$=Y.length;J<$;J++)Q=Y[J](Q);return Q}}},fv={pipe(){return G0(this,arguments)}},O4=function(){function X(){}return X.prototype=fv,X}();var V=function(X,Y){if(typeof X==="function")return function(){return X(arguments)?Y.apply(this,arguments):(Q)=>Y(Q,...arguments)};switch(X){case 0:case 1:throw RangeError(`Invalid arity ${X}`);case 2:return function(Q,J){if(arguments.length>=2)return Y(Q,J);return function($){return Y($,Q)}};case 3:return function(Q,J,$){if(arguments.length>=3)return Y(Q,J,$);return function(G){return Y(G,Q,J)}};default:return function(){if(arguments.length>=X)return Y.apply(this,arguments);let Q=arguments;return function(J){return Y(J,...Q)}}}};var u=(X)=>X;var W1=(X)=>()=>X,b6=W1(!0),R7=W1(!1),A7=W1(null),TX=W1(void 0),P7=TX;function cG(X,...Y){return G0(X,Y)}function X1(X){let Y=new WeakMap;return(Q)=>{if(Y.has(Q))return Y.get(Q);let J=X(Q);return Y.set(Q,J),J}}var a9=(X)=>{let Y=new Set(Reflect.ownKeys(X));if(X.constructor===Object)return Y;if(X instanceof Error)Y.delete("stack");let Q=Object.getPrototypeOf(X),J=Q;while(J!==null&&J!==Object.prototype){let $=Reflect.ownKeys(J);for(let G=0;G<$.length;G++)Y.add($[G]);J=Object.getPrototypeOf(J)}if(Y.has("constructor")&&typeof X.constructor==="function"&&Q===X.constructor.prototype)Y.delete("constructor");return Y},C5=new WeakSet;function gX(X){return typeof X==="string"}function t9(X){return typeof X==="number"}function sD(X){return typeof X==="boolean"}function aD(X){return typeof X==="bigint"}function lG(X){return typeof X==="symbol"}function w7(X){return gX(X)||t9(X)||lG(X)}function l1(X){return typeof X==="function"}function tD(X){return X===void 0}function V1(X){return X!==void 0}function C7(X){return X!=null}function eD(X){return!1}function oG(X){return!0}function x1(X){return typeof X==="object"&&X!==null&&!Array.isArray(X)}function iG(X){return typeof X==="object"&&X!==null||l1(X)}var j=V(2,(X,Y)=>iG(X)&&(Y in X)),g6=V(2,(X,Y)=>j(X,"_tag")&&X._tag===Y);function XN(X){return X instanceof Error}function y6(X){return j(X,Symbol.iterator)||gX(X)}var D0="~effect/interfaces/Hash",X0=(X)=>{switch(typeof X){case"number":return h6(X);case"bigint":return b0(X.toString(10));case"boolean":return b0(String(X));case"symbol":return b0(String(X));case"string":return b0(X);case"undefined":return b0("undefined");case"function":case"object":if(X===null)return b0("null");else if(X instanceof Date)return b0(X.toISOString());else if(X instanceof RegExp)return b0(X.toString());else{if(C5.has(X))return E7(X);if(nG.has(X))return nG.get(X);let Y=lv(X,()=>{if(pv(X))return X[D0]();else if(typeof X==="function")return E7(X);else if(Array.isArray(X)||ArrayBuffer.isView(X))return e9(X);else if(X instanceof Map)return uv(X);else if(X instanceof Set)return cv(X);return tG(X)});return nG.set(X,Y),Y}default:throw Error(`BUG: unhandled typeof ${typeof X} - please report an issue at https://github.com/Effect-TS/effect/issues`)}},E7=(X)=>{if(!rG.has(X))rG.set(X,h6(Math.floor(Math.random()*Number.MAX_SAFE_INTEGER)));return rG.get(X)},G1=V(2,(X,Y)=>X*53^Y),M7=(X)=>X&3221225471|X>>>1&1073741824,pv=(X)=>j(X,D0),h6=(X)=>{if(X!==X)return b0("NaN");if(X===1/0)return b0("Infinity");if(X===-1/0)return b0("-Infinity");let Y=X|0;if(Y!==X)Y^=X*4294967295;while(X>4294967295)Y^=X/=4294967295;return M7(Y)},b0=(X)=>{let Y=5381,Q=X.length;while(Q)Y=Y*33^X.charCodeAt(--Q);return M7(Y)},aG=(X,Y)=>{let Q=12289;for(let J of Y)Q^=G1(X0(J),X0(X[J]));return M7(Q)},tG=(X)=>aG(X,a9(X)),eG=(X,Y)=>(Q)=>{let J=X;for(let $ of Q)J^=Y($);return M7(J)},e9=eG(6151,X0),uv=eG(b0("Map"),([X,Y])=>G1(X0(X),X0(Y))),cv=eG(b0("Set"),X0),rG=new WeakMap,nG=new WeakMap,sG=new WeakSet;function lv(X,Y){if(sG.has(X))return b0("[Circular]");sG.add(X);let Q=Y();return sG.delete(X),Q}var N0="~effect/interfaces/Equal";function o(){if(arguments.length===1)return(X)=>T4(X,arguments[0]);return T4(arguments[0],arguments[1])}function T4(X,Y){if(X===Y)return!0;if(X==null||Y==null)return!1;let Q=typeof X;if(Q!==typeof Y)return!1;if(Q==="number"&&X!==X&&Y!==Y)return!0;if(Q!=="object"&&Q!=="function")return!1;if(C5.has(X)||C5.has(Y))return!1;return rv(X,Y,iv)}function ov(X,Y,Q){let J=XZ.has(X),$=YZ.has(Y);if(J&&$)return!0;if(J||$)return!1;XZ.add(X),YZ.add(Y);let G=Q();return XZ.delete(X),YZ.delete(Y),G}var XZ=new WeakSet,YZ=new WeakSet;function iv(X,Y){if(X0(X)!==X0(Y))return!1;else if(X instanceof Date){if(!(Y instanceof Date))return!1;return X.toISOString()===Y.toISOString()}else if(X instanceof RegExp){if(!(Y instanceof RegExp))return!1;return X.toString()===Y.toString()}let Q=YN(X),J=YN(Y);if(Q!==J)return!1;let $=Q&&J;if(typeof X==="function"&&!$)return!1;return ov(X,Y,()=>{if($)return X[N0](Y);else if(Array.isArray(X)){if(!Array.isArray(Y)||X.length!==Y.length)return!1;return nv(X,Y)}else if(ArrayBuffer.isView(X)){if(!ArrayBuffer.isView(Y)||X.byteLength!==Y.byteLength)return!1;return sv(X,Y)}else if(X instanceof Map){if(!(Y instanceof Map)||X.size!==Y.size)return!1;return tv(X,Y)}else if(X instanceof Set){if(!(Y instanceof Set)||X.size!==Y.size)return!1;return ev(X,Y)}return av(X,Y)})}function rv(X,Y,Q){let J=j7.get(X);if(!J)J=new WeakMap,j7.set(X,J);else if(J.has(Y))return J.get(Y);let $=Q(X,Y);J.set(Y,$);let G=j7.get(Y);if(!G)G=new WeakMap,j7.set(Y,G);return G.set(X,$),$}var j7=new WeakMap;function nv(X,Y){for(let Q=0;Q<X.length;Q++)if(!T4(X[Q],Y[Q]))return!1;return!0}function sv(X,Y){if(X.length!==Y.length)return!1;for(let Q=0;Q<X.length;Q++)if(X[Q]!==Y[Q])return!1;return!0}function av(X,Y){let Q=a9(X),J=a9(Y);if(Q.size!==J.size)return!1;for(let $ of Q)if(!J.has($)||!T4(X[$],Y[$]))return!1;return!0}function I7(X,Y){return function(J,$){for(let[G,_]of J){let K=!1;for(let[H,W]of $)if(X(G,H)&&Y(_,W)){K=!0;break}if(!K)return!1}return!0}}var tv=I7(T4,T4);function x7(X){return function(Q,J){for(let $ of Q){let G=!1;for(let _ of J)if(X($,_)){G=!0;break}if(!G)return!1}return!0}}var ev=x7(T4),YN=(X)=>j(X,N0);var QN=(X)=>{return C5.add(X),X};var S7=Symbol.for("~effect/Redactable"),Xk=(X)=>j(X,S7);function XY(X){if(Xk(X))return QZ(X);return X}function QZ(X){return X[S7](globalThis[E5]?.context??Yk)}var E5="~effect/Fiber/currentFiber",Yk={"~effect/Context":{},mapUnsafe:new Map,pipe(){return G0(this,arguments)}};function P(X,Y){let Q=Y?.space??0,J=new WeakSet,$=!Q?"":typeof Q==="number"?" ".repeat(Q):Q,G=(W)=>$.repeat(W),_=(W,D)=>{let U=W?.constructor;return U&&U!==Object.prototype.constructor&&U.name?`${U.name}(${D})`:D},K=(W)=>{try{return Reflect.ownKeys(W)}catch{return["[ownKeys threw]"]}};function H(W,D=0){if(Array.isArray(W)){if(J.has(W))return JN;if(J.add(W),!$||W.length<=1)return`[${W.map((N)=>H(N,D)).join(",")}]`;let U=W.map((N)=>H(N,D+1)).join(`,
`+G(D+1));return`[
${G(D+1)}${U}
${G(D)}]`}if(W instanceof Date)return JZ(W);if(!Y?.ignoreToString&&j(W,"toString")&&typeof W.toString==="function"&&W.toString!==Object.prototype.toString&&W.toString!==Array.prototype.toString){let U=Qk(W);if(W instanceof Error&&W.cause)return`${U} (cause: ${H(W.cause,D)})`;return U}if(typeof W==="string")return JSON.stringify(W);if(typeof W==="number"||W==null||typeof W==="boolean"||typeof W==="symbol")return String(W);if(typeof W==="bigint")return String(W)+"n";if(typeof W==="object"||typeof W==="function"){if(J.has(W))return JN;if(J.add(W),S7 in W)return P(QZ(W));if(Symbol.iterator in W)return`${W.constructor.name}(${H(Array.from(W),D)})`;let U=K(W);if(!$||U.length<=1){let B=`{${U.map((z)=>`${m6(z)}:${H(W[z],D)}`).join(",")}}`;return _(W,B)}let N=`{
${U.map((B)=>`${G(D+1)}${m6(B)}: ${H(W[B],D+1)}`).join(`,
`)}
${G(D)}}`;return _(W,N)}return String(W)}return H(X,0)}var JN="[Circular]";function m6(X){return typeof X==="string"?JSON.stringify(X):String(X)}function v7(X){return X.map((Y)=>`[${m6(Y)}]`).join("")}function JZ(X){try{return X.toISOString()}catch{return"Invalid Date"}}function Qk(X){try{let Y=X.toString();return typeof Y==="string"?Y:String(Y)}catch{return"[toString threw]"}}function F4(X,Y){let Q=[];return JSON.stringify(X,function(J,$){let G=XY($);if(typeof G!=="object"||G===null)return G;while(Q.length>0&&Q[Q.length-1]!==this)Q.pop();if(Q.includes(G))return;return Q.push(G),G},Y?.space)}var U1=Symbol.for("nodejs.util.inspect.custom"),A1=(X)=>{try{if(j(X,"toJSON")&&l1(X.toJSON)&&X.toJSON.length===0)return X.toJSON();else if(Array.isArray(X))return X.map(A1)}catch{return"[toJSON threw]"}return XY(X)},$N=(X,Y=2)=>{if(typeof X==="string")return X;try{return typeof X==="object"?F4(X,{space:Y}):String(X)}catch{return String(X)}},H70={toJSON(){return A1(this)},[U1](){return this.toJSON()},toString(){return P(this.toJSON())}};class R8{called=!1;self;constructor(X){this.self=X}next(X){return this.called?{value:X,done:!0}:(this.called=!0,{value:this.self,done:!1})}[Symbol.iterator](){return new R8(this.self)}}var $k=()=>{let Y={["~effect/Utils/internal"]:($)=>{return $()}},Q={["~effect/Utils/internal"]:($)=>{try{return $()}finally{}}};return Y["~effect/Utils/internal"](()=>Error().stack)?.includes("~effect/Utils/internal")===!0?Y["~effect/Utils/internal"]:Q["~effect/Utils/internal"]},W0=$k();function k(X,Y,Q){if(Y==="__proto__")Object.defineProperty(X,Y,{value:Q,writable:!0,enumerable:!0,configurable:!0});else X[Y]=Q}function k7(X,Y){for(let Q of Reflect.ownKeys(Y))if(Object.prototype.propertyIsEnumerable.call(Y,Q))k(X,Q,Y[Q])}var K6="~effect/Effect",R4="~effect/Exit",Gk={_A:u,_E:u,_R:u},ZN=`${K6}/identifier`,Z0=`${K6}/args`,o0=`${K6}/evaluate`,S1=`${K6}/successCont`,FX=`${K6}/failureCont`,A8=`${K6}/ensureCont`,A4=Symbol.for("effect/Effect/Yield"),f6={pipe(){return G0(this,arguments)},toJSON(){return{...this}},toString(){return P(this.toJSON(),{ignoreToString:!0,space:2})},[U1](){return this.toJSON()}},_N={[D0](){return aG(this,Object.keys(this))},[N0](X){let Y=Object.keys(this),Q=Object.keys(X);if(Y.length!==Q.length)return!1;for(let J=0;J<Y.length;J++)if(Y[J]!==Q[J]||!o(this[Y[J]],X[Y[J]]))return!1;return!0}},Zk={[K6]:Gk,...f6,[Symbol.iterator](){return new R8(this)},toJSON(){return{_id:"Effect",op:this[ZN],...Z0 in this?{args:this[Z0]}:void 0}}},i=(X)=>j(X,K6),$Z=(X)=>j(X,R4),YY="~effect/Cause",QY="~effect/Cause/Reason",j5=(X)=>j(X,YY),KN=(X)=>j(X,QY);class d6{[YY];reasons;constructor(X){this[YY]=YY,this.reasons=X}pipe(){return G0(this,arguments)}toJSON(){return{_id:"Cause",failures:this.reasons.map((X)=>X.toJSON())}}toString(){return`Cause(${P(this.reasons)})`}[U1](){return this.toJSON()}[N0](X){return j5(X)&&this.reasons.length===X.reasons.length&&this.reasons.every((Y,Q)=>o(Y,X.reasons[Q]))}[D0](){return e9(this.reasons)}}var GN=new WeakMap;class JY{[QY];annotations;_tag;constructor(X,Y,Q){if(this[QY]=QY,this._tag=X,Y!==$Y&&typeof Q==="object"&&Q!==null&&Y.size>0){let J=GN.get(Q);if(J)Y=new Map([...J,...Y]);GN.set(Q,Y)}this.annotations=Y}annotate(X,Y){if(X.mapUnsafe.size===0)return this;let Q=new Map(this.annotations);X.mapUnsafe.forEach(($,G)=>{if(Y?.overwrite!==!0&&Q.has(G))return;Q.set(G,$)});let J=Object.assign(Object.create(Object.getPrototypeOf(this)),this);return J.annotations=Q,J}pipe(){return G0(this,arguments)}toString(){return P(this)}[U1](){return this.toString()}}var $Y=new Map;class I5 extends JY{error;constructor(X,Y=$Y){super("Fail",Y,X);this.error=X}toString(){return`Fail(${P(this.error)})`}toJSON(){return{_tag:"Fail",error:this.error}}[N0](X){return P4(X)&&o(this.error,X.error)&&o(this.annotations,X.annotations)}[D0](){return G1(b0(this._tag))(G1(X0(this.error))(X0(this.annotations)))}}var p6=(X)=>new d6(X),g7=new d6([]),HN=(X)=>new d6([new I5(X)]);class y7 extends JY{defect;constructor(X,Y=$Y){super("Die",Y,X);this.defect=X}toString(){return`Die(${P(this.defect)})`}toJSON(){return{_tag:"Die",defect:this.defect}}[N0](X){return ZY(X)&&o(this.defect,X.defect)&&o(this.annotations,X.annotations)}[D0](){return G1(b0(this._tag))(G1(X0(this.defect))(X0(this.annotations)))}}var WN=(X)=>new d6([new y7(X)]),GY=V((X)=>j5(X[0]),(X,Y,Q)=>{if(Y.mapUnsafe.size===0)return X;return new d6(X.reasons.map((J)=>J.annotate(Y,Q)))}),P4=(X)=>X._tag==="Fail",ZY=(X)=>X._tag==="Die",h7=(X)=>X._tag==="Interrupt";function _k(X){return W6("Effect.evaluate: Not implemented")}var u6=(X)=>({...Zk,[ZN]:X.op,[o0]:X[o0]??_k,[S1]:X[S1],[FX]:X[FX],[A8]:X[A8]}),RX=(X)=>{let Y=u6(X);return function(){let Q=Object.create(Y);return Q[Z0]=X.single===!1?arguments:arguments[0],Q}},UN=(X)=>{let Y={...u6(X),[R4]:R4,_tag:X.op,get[X.prop](){return this[Z0]},toString(){return`${X.op}(${P(this[Z0])})`},toJSON(){return{_id:"Exit",_tag:X.op,[X.prop]:this[Z0]}},[N0](Q){return $Z(Q)&&Q._tag===this._tag&&o(this[Z0],Q[Z0])},[D0](){return G1(b0(X.op),X0(this[Z0]))}};return function(Q){let J=Object.create(Y);return J[Z0]=Q,J}},Z1=UN({op:"Success",prop:"value",[o0](X){let Y=X.getCont(S1);return Y?Y[S1](this[Z0],X,this):X.yieldWith(this)}}),m7={key:"effect/Cause/StackTrace"},GZ={key:"effect/Cause/InterruptorStackTrace"},GX=UN({op:"Failure",prop:"cause",[o0](X){let Y=this[Z0],Q=!1;if(X.currentStackFrame)Y=GY(Y,{mapUnsafe:new Map([[m7.key,X.currentStackFrame]])}),Q=!0;let J=X.getCont(FX);while(X.interruptible&&X._interruptedCause&&J)J=X.getCont(FX);return J?J[FX](Y,X,Q?void 0:this):X.yieldWith(Q?GX(Y):this)}}),H6=(X)=>GX(HN(X)),W6=(X)=>GX(WN(X)),t=RX({op:"WithFiber",[o0](X){return this[Z0](X)}}),Kk=function(){class X extends globalThis.Error{}let Y=u6({op:"YieldableError",[o0](){return H6(this)}});return delete Y.toString,Object.assign(X.prototype,Y),X}(),_Y=function(){let X=Symbol.for("effect/Data/Error/plainArgs");return class extends Kk{constructor(Q){super(Q?.message,Q?.cause?{cause:Q.cause}:void 0);if(Q)k7(this,Q),Object.defineProperty(this,X,{value:Q,enumerable:!1})}toJSON(){return{...this[X],...this}}}}(),P8=(X)=>{class Y extends _Y{_tag=X}return Y.prototype.name=X,Y},b7="~effect/Cause/NoSuchElementError",ZZ=(X)=>j(X,b7);class c6 extends P8("NoSuchElementError"){[b7]=b7;constructor(X){super({message:X})}}var M5="~effect/Cause/Done",KY=(X)=>j(X,M5),DN={[M5]:M5,_tag:"Done",value:void 0},NN=(X)=>{if(X===void 0)return DN;return{[M5]:M5,_tag:"Done",value:X}},Hk=H6(DN),BN=(X)=>{if(X===void 0)return Hk;return H6(NN(X))};var VN=(X)=>u6({op:X.label,[o0]:X.evaluate});var Uk=()=>{let X=Object.getOwnPropertyDescriptor(Error,"stackTraceLimit");if(X===void 0)return Object.isExtensible(Error);return Object.hasOwn(X,"writable")?X.writable===!0:X.set!==void 0},Dk=Uk(),U6=()=>Error.stackTraceLimit,P1=(X)=>{if(Dk)Error.stackTraceLimit=X};function zN(X){return{combine:X}}function l6(X,Y,Q){return{combine:X,initialValue:Y,combineAll:Q??((J)=>{let $=Y;for(let G of J)$=X($,G);return $})}}var D1=(X)=>(Y,Q)=>Y===Q||X(Y,Q),Bk=(X,Y)=>X===Y,qN=()=>Bk;function LN(X){return D1((Y,Q)=>{if(Y.length!==Q.length)return!1;for(let J=0;J<Y.length;J++)if(!X(Y[J],Q[J]))return!1;return!0})}var d7=(X)=>V(3,(Y,Q,J)=>X(Y,($)=>({...$,[Q]:J($)}))),p7=(X)=>V(2,(Y,Q)=>X(Y,(J)=>({[Q]:J}))),u7=(X,Y)=>V(3,(Q,J,$)=>Y(Q,(G)=>X($(G),(_)=>({...G,[J]:_}))));var TN="~effect/data/Option",FN={[TN]:{_A:(X)=>X},...f6,[Symbol.iterator](){return new R8(this)}},Vk=Object.defineProperty(Object.assign(Object.create(FN),{_tag:"Some",_op:"Some",[N0](X){return c7(X)&&_Z(X)&&o(this.value,X.value)},[D0](){return G1(X0(this._tag))(X0(this.value))},toString(){return`some(${P(this.value)})`},toJSON(){return{_id:"Option",_tag:this._tag,value:A1(this.value)}}}),"valueOrUndefined",{get(){return this.value}}),zk=X0("None"),qk=Object.assign(Object.create(FN),{_tag:"None",_op:"None",valueOrUndefined:void 0,[N0](X){return c7(X)&&E8(X)},[D0](){return zk},toString(){return"none()"},toJSON(){return{_id:"Option",_tag:this._tag}}}),c7=(X)=>j(X,TN),E8=(X)=>X._tag==="None",_Z=(X)=>X._tag==="Some",w4=Object.create(qk),o6=(X)=>{let Y=Object.create(Vk);return Y.value=X,Y};var RN="~effect/data/Result",AN={[RN]:{_A:(X)=>X,_E:(X)=>X},...f6,[Symbol.iterator](){return new R8(this)}},Lk=Object.assign(Object.create(AN),{_tag:"Success",_op:"Success",[N0](X){return l7(X)&&i7(X)&&o(this.success,X.success)},[D0](){return G1(X0(this._tag))(X0(this.success))},toString(){return`success(${P(this.success)})`},toJSON(){return{_id:"Result",_tag:this._tag,value:A1(this.success)}}}),Ok=Object.assign(Object.create(AN),{_tag:"Failure",_op:"Failure",[N0](X){return l7(X)&&o7(X)&&o(this.failure,X.failure)},[D0](){return G1(X0(this._tag))(X0(this.failure))},toString(){return`failure(${P(this.failure)})`},toJSON(){return{_id:"Result",_tag:this._tag,failure:A1(this.failure)}}}),l7=(X)=>j(X,RN),o7=(X)=>X._tag==="Failure",i7=(X)=>X._tag==="Success",HZ=(X)=>{let Y=Object.create(Ok);return Y.failure=X,Y},WZ=(X)=>{let Y=Object.create(Lk);return Y.success=X,Y},PN=(X)=>i7(X)?w4:o6(X.failure),wN=(X)=>o7(X)?w4:o6(X.success),CN=V(2,(X,Y)=>E8(X)?HZ(Y()):WZ(X.value));function C4(X){return(Y,Q)=>Y===Q?0:X(Y,Q)}var L1=C4((X,Y)=>{if(globalThis.Number.isNaN(X)&&globalThis.Number.isNaN(Y))return 0;if(globalThis.Number.isNaN(X))return-1;if(globalThis.Number.isNaN(Y))return 1;return X<Y?-1:1});var AX=C4((X,Y)=>X<Y?-1:1);var UZ=V(2,(X,Y)=>C4((Q,J)=>X(Y(Q),Y(J)))),E4=UZ(L1,(X)=>X.getTime());var x5=(X)=>V(2,(Y,Q)=>X(Y,Q)===-1),M8=(X)=>V(2,(Y,Q)=>X(Y,Q)===1),HY=(X)=>V(2,(Y,Q)=>X(Y,Q)!==1),WY=(X)=>V(2,(Y,Q)=>X(Y,Q)!==-1);var d=()=>w4,T=o6,r7=c7,P0=E8,N1=_Z,yX=V(2,(X,{onNone:Y,onSome:Q})=>P0(X)?Y():Q(X.value));var n7=V(2,(X,Y)=>P0(X)?Y():X.value);var EN=(X)=>X==null?d():T(X),MN=(X)=>X===void 0?d():T(X),jN=(X)=>X===null?d():T(X);var DZ=n7(A7),M4=n7(TX),j4=(X)=>(...Y)=>{try{return T(X(...Y))}catch{return d()}};var i6=V(2,(X,Y)=>P0(X)?d():T(Y(X.value)));var Fk=V(2,(X,Y)=>P0(X)?d():Y(X.value));var v5=Fk(u);var k5=V(2,(X,Y)=>P0(X)?d():Y(X.value)?T(X.value):d()),IN=(X)=>D1((Y,Q)=>P0(Y)?P0(Q):P0(Q)?!1:X(Y.value,Q.value));var s7="~effect/Context/Service",hX=function(){let X=U6();P1(2);let Y=Error();P1(X);function Q(){}let J=Q;if(Object.setPrototypeOf(J,Rk),Object.defineProperty(J,"stack",{get(){return Y.stack}}),arguments.length>0){if(J.key=arguments[0],arguments[1]?.defaultValue)J[a7]=a7,J.defaultValue=arguments[1].defaultValue;return J}return function($,G){if(J.key=$,G?.make)J.make=G.make;return J}},Rk={[s7]:s7,...VN({label:"Service",evaluate(X){return Z1(v1(X.context,this))}}),toJSON(){return{_id:"Service",key:this.key,stack:this.stack}},of(X){return X},context(X){return D6(this,X)},use(X){return t((Y)=>X(v1(Y.context,this)))},useSync(X){return t((Y)=>Z1(X(v1(Y.context,this))))}},a7="~effect/Context/Reference",xN="~effect/Context",j8=(X)=>{let Y=Object.create(Ak);return Y.mapUnsafe=X,Y.mutable=!1,Y},Ak={...f6,[xN]:{_Services:(X)=>X},toJSON(){return{_id:"Context",services:Array.from(this.mapUnsafe).map(([X,Y])=>({key:X,value:Y}))}},[N0](X){if(!t7(X)||this.mapUnsafe.size!==X.mapUnsafe.size)return!1;for(let Y of this.mapUnsafe.keys())if(!X.mapUnsafe.has(Y)||!o(this.mapUnsafe.get(Y),X.mapUnsafe.get(Y)))return!1;return!0},[D0](){return h6(this.mapUnsafe.size)}},t7=(X)=>j(X,xN),Pk=(X)=>j(X,s7),BZ=(X)=>j(X,a7),k1=()=>wk,wk=j8(new Map),D6=(X,Y)=>j8(new Map([[X.key,Y]])),i1=V(3,(X,Y,Q)=>UY(X,(J)=>{J.set(Y.key,Q)})),Ck=V(3,(X,Y,Q)=>UY(X,(J)=>{if(Q._tag==="None")J.delete(Y.key);else J.set(Y.key,Q.value)})),Ek=V(3,(X,Y,Q)=>{if(X.mapUnsafe.has(Y.key))return X.mapUnsafe.get(Y.key);return BZ(Y)?e7(Y):Q()}),VZ=V(2,(X,Y)=>X.mapUnsafe.get(Y.key)),PX=V(2,(X,Y)=>{if(!X.mapUnsafe.has(Y.key)){if(a7 in Y)return e7(Y);throw Mk(Y)}return X.mapUnsafe.get(Y.key)}),v1=PX,zZ=(X,Y)=>{if(!X.mapUnsafe.has(Y.key))return e7(Y);return X.mapUnsafe.get(Y.key)},NZ="~effect/Context/defaultValue",e7=(X)=>{if(NZ in X)return X[NZ];return X[NZ]=X.defaultValue()},Mk=(X)=>{let Y=Error(`Service not found${X.key?`: ${String(X.key)}`:""}`);if(X.stack){let Q=X.stack.split(`
`);if(Q.length>2){let J=Q[2].match(/at (.*)/);if(J)Y.message=Y.message+` (defined at ${J[1]})`}}if(Y.stack){let Q=Y.stack.split(`
`);Q.splice(1,3),Y.stack=Q.join(`
`)}return Y},qZ=V(2,(X,Y)=>{if(X.mapUnsafe.has(Y.key))return T(X.mapUnsafe.get(Y.key));return BZ(Y)?T(e7(Y)):d()}),b5=V(2,(X,Y)=>{if(X.mapUnsafe.size===0)return Y;if(Y.mapUnsafe.size===0)return X;return UY(X,(Q)=>{Y.mapUnsafe.forEach((J,$)=>Q.set($,J))})}),LZ=(...X)=>{let Y=new Map;for(let Q=0;Q<X.length;Q++)X[Q].mapUnsafe.forEach((J,$)=>{Y.set($,J)});return j8(Y)},jk=(...X)=>(Y)=>UY(Y,(Q)=>{let J=new Set(X.map(($)=>$.key));Q.forEach(($,G)=>{if(J.has(G))return;Q.delete(G)})}),Ik=(...X)=>(Y)=>UY(Y,(Q)=>{for(let J=0;J<X.length;J++)Q.delete(X[J].key)}),xk=V(2,(X,Y)=>{let Q=j8(new Map(X.mapUnsafe));Q.mutable=!0;let J=Y(Q);return J.mutable=!1,J}),UY=(X,Y)=>{if(X.mutable)return Y(X.mapUnsafe),X;let Q=new Map(X.mapUnsafe);return Y(Q),j8(Q)},O0=hX;var r6={};k6(r6,{taggedEnum:()=>vk,TaggedError:()=>DY,TaggedClass:()=>Sk,Error:()=>bk,Class:()=>X3});var X3=class extends O4{constructor(X){super();if(X)k7(this,X)}},Sk=(X)=>class extends X3{_tag=X},vk=()=>new Proxy({},{get(X,Y,Q){if(Y==="$is")return g6;else if(Y==="$match")return kk;return(J)=>({...J,_tag:Y})}});function kk(){if(arguments.length===1){let Q=arguments[0];return function(J){return Q[J._tag](J)}}let X=arguments[0];return arguments[1][X._tag](X)}var bk=_Y,DY=P8;var i0={};k6(i0,{zipWith:()=>gh,zip:()=>bh,yieldNowWith:()=>Ah,yieldNow:()=>Rh,withTracerTiming:()=>wf,withTracerEnabled:()=>Pf,withTracer:()=>Af,withSpanScoped:()=>yf,withSpan:()=>gf,withParentSpan:()=>hf,withLogger:()=>Bd,withLogSpan:()=>qd,withFiber:()=>eq,withExecutionPlan:()=>_m,withErrorReporting:()=>Km,whileLoop:()=>nq,when:()=>Mm,void:()=>uY,validate:()=>Kh,useSpan:()=>bf,updateServiceScoped:()=>om,updateService:()=>lm,updateContext:()=>cm,unwrapReason:()=>ph,uninterruptibleMask:()=>ZL,uninterruptible:()=>Nf,undefined:()=>Nh,txRetry:()=>Ed,tx:()=>Ad,tryPromise:()=>T_,try:()=>J9,transposeOption:()=>wh,trackSuccesses:()=>Od,trackErrors:()=>Td,trackDuration:()=>Rd,trackDefects:()=>Fd,track:()=>Ld,tracer:()=>Rf,timeoutOrElse:()=>Nm,timeoutOption:()=>Dm,timeout:()=>Um,timed:()=>zm,tapErrorTag:()=>th,tapError:()=>YL,tapDefect:()=>JL,tapCauseIf:()=>eh,tapCauseFilter:()=>Xm,tapCause:()=>QL,tap:()=>XL,sync:()=>aq,suspend:()=>sq,succeedSome:()=>pY,succeedNone:()=>pX,succeed:()=>p,spanLinks:()=>xf,spanAnnotations:()=>If,sleep:()=>Vm,setContext:()=>dm,serviceOption:()=>um,service:()=>pm,scopedWith:()=>sm,scoped:()=>nm,scope:()=>rm,scheduleFrom:()=>_L,schedule:()=>Ff,satisfiesSuccessType:()=>jd,satisfiesServicesType:()=>xd,satisfiesErrorType:()=>Id,sandbox:()=>$m,runSyncWith:()=>Qd,runSyncExitWith:()=>Jd,runSyncExit:()=>p8,runSync:()=>Yd,runPromiseWith:()=>ef,runPromiseExitWith:()=>Xd,runPromiseExit:()=>XJ,runPromise:()=>tf,runForkWith:()=>nf,runFork:()=>C_,runCallbackWith:()=>sf,runCallback:()=>af,retryOrElse:()=>Jm,retry:()=>Qm,result:()=>jh,requestUnsafe:()=>ff,request:()=>mf,replicateEffect:()=>Tf,replicate:()=>Of,repeatOrElse:()=>Lf,repeat:()=>qf,reduce:()=>_h,raceFirst:()=>Tm,raceAllFirst:()=>Lm,raceAll:()=>qm,race:()=>Om,provideServiceEffect:()=>im,provideService:()=>$L,provideContext:()=>fm,provide:()=>mm,promise:()=>Dh,partition:()=>Zh,orElseSucceed:()=>Hm,orDie:()=>ah,option:()=>Ih,onInterrupt:()=>Df,onExitPrimitive:()=>Gf,onExitIf:()=>Zf,onExitFilter:()=>_f,onExit:()=>w_,onErrorIf:()=>Jf,onErrorFilter:()=>$f,onError:()=>Qf,never:()=>Bh,matchEffect:()=>km,matchEager:()=>jm,matchCauseEffectEager:()=>Sm,matchCauseEffect:()=>vm,matchCauseEager:()=>xm,matchCause:()=>Im,match:()=>P_,mapErrorEager:()=>$9,mapError:()=>nh,mapEager:()=>r4,mapBothEager:()=>B1,mapBoth:()=>sh,map:()=>A_,makeSpanScoped:()=>kf,makeSpan:()=>vf,logWithLevel:()=>Zd,logWarning:()=>Hd,logTrace:()=>Nd,logInfo:()=>Ud,logFatal:()=>Kd,logError:()=>Wd,logDebug:()=>Dd,log:()=>_d,linkSpans:()=>Sf,let:()=>qh,isSuccess:()=>gm,isFailure:()=>bm,isEffect:()=>l4,interruptibleMask:()=>Bf,interruptible:()=>Uf,interrupt:()=>GL,ignoreCause:()=>Zm,ignore:()=>Gm,gen:()=>Oh,fromResult:()=>R_,fromOption:()=>Ph,fromNullishOr:()=>Ch,forkScoped:()=>uf,forkIn:()=>pf,forkDetach:()=>cf,forkChild:()=>df,forever:()=>zf,forEach:()=>Uh,fnUntracedEager:()=>oY,fnUntraced:()=>$d,fn:()=>Gd,flip:()=>kh,flatten:()=>Eh,flatMapEager:()=>wX,flatMap:()=>cY,firstSuccessOf:()=>Wm,findFirstFilter:()=>Wh,findFirst:()=>Hh,filterOrFail:()=>Cm,filterOrElse:()=>Pm,filterMapOrFail:()=>Em,filterMapOrElse:()=>wm,filterMapEffect:()=>Am,filterMap:()=>Rm,filter:()=>Fm,fiberId:()=>rf,fiber:()=>of,failSync:()=>Th,failCauseSync:()=>o4,failCause:()=>Fh,fail:()=>f,exit:()=>lY,eventually:()=>Ym,ensuring:()=>Yf,effectify:()=>Md,die:()=>tq,delay:()=>Bm,currentSpan:()=>Mf,currentParentSpan:()=>jf,contextWith:()=>hm,context:()=>ym,clockWith:()=>KL,catchTags:()=>mh,catchTag:()=>hh,catchReasons:()=>dh,catchReason:()=>fh,catchNoSuchElement:()=>oh,catchIf:()=>ch,catchFilter:()=>lh,catchEager:()=>YJ,catchDefect:()=>uh,catchCauseIf:()=>ih,catchCauseFilter:()=>rh,catchCause:()=>i4,catch:()=>yh,callback:()=>F_,cachedWithTTL:()=>Hf,cachedInvalidateWithTTL:()=>Wf,cached:()=>Kf,bindTo:()=>zh,bind:()=>Lh,awaitAllChildren:()=>lf,asVoid:()=>vh,asSome:()=>Sh,as:()=>xh,annotateSpans:()=>Cf,annotateLogsScoped:()=>zd,annotateLogs:()=>Vd,annotateCurrentSpan:()=>Ef,andThen:()=>Mh,all:()=>Gh,addFinalizer:()=>Xf,acquireUseRelease:()=>em,acquireRelease:()=>am,acquireDisposable:()=>tm,abortSignal:()=>Vf,TypeId:()=>$h,Transaction:()=>dY,Do:()=>Vh});var Y3="~effect/time/Duration",gk=BigInt(0),yk=BigInt(1);var hk=BigInt(1000);var Q3=(X)=>BigInt(X<0?Math.ceil(X-0.5):Math.floor(X+0.5)),bN=(X)=>Q3(X*1e6),SN=(X,Y)=>X.includes(".")?Q3(Number(X)*Number(Y)):BigInt(X)*Y;var mk=/^(-?\d+(?:\.\d+)?)\s+(nanos?|micros?|millis?|seconds?|minutes?|hours?|days?|weeks?)$/,ZX=(X)=>{switch(typeof X){case"number":return I8(X);case"bigint":return N6(X);case"string":{if(X==="Infinity")return n6;if(X==="-Infinity")return I4;let Y=mk.exec(X);if(!Y)break;let[Q,J,$]=Y;if($==="nano"||$==="nanos")return N6(SN(J,yk));if($==="micro"||$==="micros")return N6(SN(J,hk));let G=Number(J);switch($){case"milli":case"millis":return I8(G);case"second":case"seconds":return uk(G);case"minute":case"minutes":return ck(G);case"hour":case"hours":return lk(G);case"day":case"days":return ok(G);case"week":case"weeks":return ik(G)}break}case"object":{if(X===null)break;if(Y3 in X)return X;if(Array.isArray(X)){if(X.length!==2||!X.every(t9))return vN(X);if(Number.isNaN(X[0])||Number.isNaN(X[1]))return g5;if(X[0]===-1/0||X[1]===-1/0)return I4;if(X[0]===1/0||X[1]===1/0)return n6;return g1(Q3(X[0]*1e9+X[1]))}let Y=X,Q=0;if(Y.weeks)Q+=Y.weeks*604800000;if(Y.days)Q+=Y.days*86400000;if(Y.hours)Q+=Y.hours*3600000;if(Y.minutes)Q+=Y.minutes*60000;if(Y.seconds)Q+=Y.seconds*1000;if(Y.milliseconds)Q+=Y.milliseconds;if(!Y.microseconds&&!Y.nanoseconds)return g1(Q);return g1(Q3(Q*1e6+(Y.microseconds??0)*1000+(Y.nanoseconds??0)))}}return vN(X)},vN=(X)=>{throw Error(`Invalid Input: ${X}`)},gN=j4(ZX),kN={_tag:"Millis",millis:0},fk={_tag:"Infinity"},dk={_tag:"NegativeInfinity"},pk={[Y3]:Y3,[D0](){return tG(this.value)},[N0](X){return TZ(X)&&nk(this,X)},toString(){switch(this.value._tag){case"Infinity":return"Infinity";case"NegativeInfinity":return"-Infinity";case"Nanos":return`${this.value.nanos} nanos`;case"Millis":return`${this.value.millis} millis`}},toJSON(){switch(this.value._tag){case"Millis":return{_id:"Duration",_tag:"Millis",millis:this.value.millis};case"Nanos":return{_id:"Duration",_tag:"Nanos",nanos:String(this.value.nanos)};case"Infinity":return{_id:"Duration",_tag:"Infinity"};case"NegativeInfinity":return{_id:"Duration",_tag:"NegativeInfinity"}}},[U1](){return this.toJSON()},pipe(){return G0(this,arguments)}},g1=(X)=>{let Y=Object.create(pk);if(typeof X==="number")if(isNaN(X)||X===0||Object.is(X,-0))Y.value=kN;else if(!Number.isFinite(X))Y.value=X>0?fk:dk;else if(!Number.isInteger(X))Y.value={_tag:"Nanos",nanos:bN(X)};else Y.value={_tag:"Millis",millis:X};else if(X===gk)Y.value=kN;else Y.value={_tag:"Nanos",nanos:X};return Y},TZ=(X)=>j(X,Y3);var g5=g1(0),n6=g1(1/0),I4=g1(-1/0),N6=(X)=>g1(X);var I8=(X)=>g1(X),uk=(X)=>g1(X*1000),ck=(X)=>g1(X*60000),lk=(X)=>g1(X*3600000),ok=(X)=>g1(X*86400000),ik=(X)=>g1(X*604800000),x8=(X)=>rk(ZX(X),{onMillis:u,onNanos:(Y)=>Number(Y)/1e6,onInfinity:()=>1/0,onNegativeInfinity:()=>-1/0});var OZ=(X)=>{let Y=ZX(X);switch(Y.value._tag){case"Infinity":case"NegativeInfinity":throw Error("Cannot convert infinite duration to nanos");case"Nanos":return Y.value.nanos;case"Millis":return bN(Y.value.millis)}},yN=j4(OZ);var rk=V(2,(X,Y)=>{switch(X.value._tag){case"Millis":return Y.onMillis(X.value.millis);case"Nanos":return Y.onNanos(X.value.nanos);case"Infinity":return Y.onInfinity();case"NegativeInfinity":return(Y.onNegativeInfinity??Y.onInfinity)()}}),hN=V(3,(X,Y,Q)=>{if(X.value._tag==="Infinity"||X.value._tag==="NegativeInfinity"||Y.value._tag==="Infinity"||Y.value._tag==="NegativeInfinity")return Q.onInfinity(X,Y);if(X.value._tag==="Millis")return Y.value._tag==="Millis"?Q.onMillis(X.value.millis,Y.value.millis):Q.onNanos(OZ(X),Y.value.nanos);else return Q.onNanos(X.value.nanos,OZ(Y))});var FZ=(X,Y)=>hN(X,Y,{onMillis:(Q,J)=>Q===J,onNanos:(Q,J)=>Q===J,onInfinity:(Q,J)=>Q.value._tag===J.value._tag});var mN=V(2,(X,Y)=>hN(X,Y,{onMillis:(Q,J)=>g1(Q-J),onNanos:(Q,J)=>g1(Q-J),onInfinity:(Q,J)=>{let $=Q.value._tag,G=J.value._tag;if($==="Infinity")return G==="Infinity"?g5:n6;if($==="NegativeInfinity")return G==="NegativeInfinity"?g5:I4;return G==="Infinity"?I4:n6}}));var nk=V(2,(X,Y)=>FZ(X,Y));var RZ=(X)=>X.length>0;var g0={};k6(g0,{void:()=>ak,try:()=>AZ,transposeOption:()=>Lb,transposeMapOption:()=>Ob,tap:()=>Fb,succeedSome:()=>Tb,succeedNone:()=>wZ,succeed:()=>m,orElse:()=>Hb,merge:()=>Gb,match:()=>r1,mapError:()=>x4,mapBoth:()=>fN,map:()=>_X,makeEquivalence:()=>PZ,liftPredicate:()=>Jb,let:()=>qb,isSuccess:()=>Y1,isResult:()=>J3,isFailure:()=>J0,getSuccess:()=>Yb,getOrUndefined:()=>_b,getOrThrowWith:()=>dN,getOrThrow:()=>Kb,getOrNull:()=>Zb,getOrElse:()=>S8,getFailure:()=>Qb,gen:()=>Nb,fromOption:()=>Xb,fromNullishOr:()=>ek,flip:()=>Db,flatMap:()=>v8,filterOrFail:()=>$b,failVoid:()=>tk,fail:()=>c,bindTo:()=>zb,bind:()=>Vb,andThen:()=>Wb,all:()=>Ub,Do:()=>Bb});var m=WZ,c=HZ,ak=m(void 0);var tk=c(void 0),ek=V(2,(X,Y)=>X==null?c(Y(X)):m(X)),Xb=CN,AZ=(X)=>{if(l1(X))try{return m(X())}catch(Y){return c(Y)}else try{return m(X.try())}catch(Y){return c(X.catch(Y))}};var J3=l7,J0=o7,Y1=i7,Yb=wN,Qb=PN,PZ=(X,Y)=>D1((Q,J)=>J0(Q)?J0(J)&&Y(Q.failure,J.failure):Y1(J)&&X(Q.success,J.success)),fN=V(2,(X,{onFailure:Y,onSuccess:Q})=>J0(X)?c(Y(X.failure)):m(Q(X.success))),x4=V(2,(X,Y)=>J0(X)?c(Y(X.failure)):m(X.success)),_X=V(2,(X,Y)=>Y1(X)?m(Y(X.success)):c(X.failure)),r1=V(2,(X,{onFailure:Y,onSuccess:Q})=>J0(X)?Y(X.failure):Q(X.success)),Jb=V(3,(X,Y,Q)=>Y(X)?m(X):c(Q(X))),$b=V(3,(X,Y,Q)=>v8(X,(J)=>Y(J)?m(J):c(Q(J)))),Gb=r1({onFailure:u,onSuccess:u}),S8=V(2,(X,Y)=>J0(X)?Y(X.failure):X.success),Zb=S8(A7),_b=S8(TX),dN=V(2,(X,Y)=>{if(Y1(X))return X.success;throw Y(X.failure)}),Kb=dN(u),Hb=V(2,(X,Y)=>J0(X)?Y(X.failure):m(X.success)),v8=V(2,(X,Y)=>J0(X)?c(X.failure):Y(X.success)),Wb=V(2,(X,Y)=>v8(X,(Q)=>{let J=l1(Y)?Y(Q):Y;return J3(J)?J:m(J)})),Ub=(X)=>{if(Symbol.iterator in X){let Q=[];for(let J of X){if(J0(J))return J;Q.push(J.success)}return m(Q)}let Y={};for(let Q of Object.keys(X)){let J=X[Q];if(J0(J))return J;k(Y,Q,J.success)}return m(Y)},Db=(X)=>J0(X)?m(X.failure):c(X.success),Nb=(...X)=>{let Q=(X.length===1?X[0]:X[1].bind(X[0]))(),J=Q.next();while(!J.done){let $=J.value;if(J0($))return $;J=Q.next($.success)}return m(J.value)},Bb=m({}),Vb=u7(_X,v8),zb=p7(_X),qb=d7(_X);var Lb=(X)=>{return E8(X)?wZ:_X(X.value,o6)},Ob=V(2,(X,Y)=>E8(X)?wZ:_X(Y(X.value),o6)),wZ=m(w4),Tb=(X)=>m(o6(X)),Fb=V(2,(X,Y)=>{if(Y1(X))Y(X.success);return X});var o70={[Symbol.iterator](){return Rb}},Rb={next(){return{done:!0,value:void 0}}};var pN=V(2,(X,Y)=>({[Symbol.iterator](){let Q=X[Symbol.iterator](),J=0;return{next(){let $=Q.next();while(!$.done){if(Y($.value,J++))return{done:!1,value:$.value};$=Q.next()}return{done:!0,value:void 0}}}}}));var $3=V(2,(X,Y)=>{let Q={...X};for(let J of Pb(X))k(Q,J,Y(X[J],J));return Q});var Pb=(X)=>Object.keys(X);var h5=globalThis.Array;var CZ=(X)=>new h5(X);var C1=(X)=>h5.isArray(X)?X:h5.from(X),cN=(X)=>h5.isArray(X)?X:[X];var G3=V(2,(X,Y)=>[...X,Y]),wb=V(2,(X,Y)=>C1(X).concat(C1(Y)));var a70=h5.isArray;var B6=RZ,k8=RZ;var NY=V(2,(X,Y)=>{let Q=h5.from(X);return Q.sort(Y),Q});var Cb=(X,Y)=>{let Q=X0(Y),J=X.get(Q);if(J===void 0)return X.set(Q,[Y]),!0;for(let $ of J)if(o($,Y))return!1;return J.push(Y),!0};var EZ=V(2,(X,Y)=>{let Q=C1(X),J=C1(Y);if(k8(Q))return k8(J)?_3(wb(Q,J)):Q;return J});var Z3=()=>[];var V6=V(2,(X,Y)=>X.map(Y));var MZ=(X)=>{let Y=[];for(let Q of X)if(N1(Q))Y.push(Q.value);return Y};var jZ=V(2,(X,Y)=>{let Q=[],J=[],$=0;for(let G of X){let _=Y(G,$++);if(Y1(_))J.push(_.success);else Q.push(_.failure)}return[Q,J]});var _3=(X)=>{let Y=C1(X);if(Y.length<2)return[...Y];let Q=new Map,J=[];for(let $ of Y)if(Cb(Q,$))J.push($);return J};var Eb=l6((X,Y)=>X.concat(Y),[]);function lN(){return Eb}var IZ=V(2,(X,Y)=>(Q)=>{let J=X(Q);if(J0(J))return c(Q);let $=Y(J.success);if(J0($))return c(Q);return $});var BY=O0("effect/Scheduler",{defaultValue:()=>new m5}),oN="setImmediate"in globalThis?(X)=>{let Y=globalThis.setImmediate(X);return()=>globalThis.clearImmediate(Y)}:(X)=>{let Y=setTimeout(X,0);return()=>clearTimeout(Y)};class iN{buckets=[];scheduleTask(X,Y){let Q=this.buckets,J=Q.length,$,G=0;for(;G<J;G++){if(Q[G][0]>Y)break;$=Q[G]}if($&&$[0]===Y)$[1].push(X);else if(G===J)Q.push([Y,[X]]);else Q.splice(G,0,[Y,[X]])}drain(){let X=this.buckets;return this.buckets=[],X}}class m5{executionMode;setImmediate;constructor(X="async",Y=oN){this.executionMode=X,this.setImmediate=Y}shouldYield(X){return X.currentOpCount>=X.maxOpsBeforeYield}makeDispatcher(){return new rN(this.setImmediate)}}class rN{tasks=new iN;running=void 0;setImmediate;constructor(X=oN){this.setImmediate=X}scheduleTask(X,Y){if(this.tasks.scheduleTask(X,Y),this.running===void 0)this.running=this.setImmediate(this.afterScheduled)}afterScheduled=()=>{this.running=void 0,this.runTasks()};runTasks(){let X=this.tasks.drain();for(let Y=0;Y<X.length;Y++){let Q=X[Y][1];for(let J=0;J<Q.length;J++)Q[J]()}}flush(){while(this.tasks.buckets.length>0){if(this.running!==void 0)this.running(),this.running=void 0;this.runTasks()}}}var nN=O0("effect/Scheduler/MaxOpsBeforeYield",{defaultValue:()=>2048}),sN=O0("effect/Scheduler/PreventSchedulerYield",{defaultValue:()=>!1});var xZ="effect/Tracer/ParentSpan";class S4 extends hX()(xZ){}var jb=(X)=>X;var K3=O0("effect/Tracer/DisablePropagation",{defaultValue:R7}),eN=O0("effect/Tracer/CurrentTraceLevel",{defaultValue:()=>"Info"}),XB=O0("effect/Tracer/MinimumTraceLevel",{defaultValue:()=>"All"}),SZ="effect/Tracer",H3=O0(SZ,{defaultValue:()=>jb({span:(X)=>new YB(X)})});class YB{_tag="Span";spanId;traceId="native";sampled;name;parent;annotations;links;startTime;kind;status;attributes;events=[];constructor(X){this.name=X.name,this.parent=X.parent,this.annotations=X.annotations,this.links=X.links,this.startTime=X.startTime,this.kind=X.kind,this.sampled=X.sampled,this.status={_tag:"Started",startTime:X.startTime},this.attributes=new Map,this.traceId=M4(X.parent)?.traceId??tN(32),this.spanId=tN(16)}end(X,Y){this.status={_tag:"Ended",endTime:X,exit:Y,startTime:this.status.startTime}}attribute(X,Y){this.attributes.set(X,Y)}event(X,Y,Q){this.events.push([X,Y,Q??{}])}addLinks(X){this.links.push(...X)}}var tN=function(){return function(Q){let J="";for(let $=0;$<Q;$++)J+="abcdef0123456789".charAt(Math.floor(Math.random()*16));return J}}();var JB="effect/observability/Metric/FiberRuntimeMetricsKey";var $B=O0("effect/ErrorReporter/CurrentErrorReporters",{defaultValue:()=>new Set}),f5=O0("effect/References/CurrentStackFrame",{defaultValue:TX}),W3=O0("effect/References/TracerEnabled",{defaultValue:b6}),VY=O0("effect/References/TracerTimingEnabled",{defaultValue:b6}),zY=O0("effect/References/TracerSpanAnnotations",{defaultValue:()=>({})}),qY=O0("effect/References/TracerSpanLinks",{defaultValue:()=>[]}),s6=O0("effect/References/CurrentLogAnnotations",{defaultValue:()=>({})}),vZ=O0("effect/References/CurrentLogLevel",{defaultValue:()=>"Info"}),kZ=O0("effect/References/MinimumLogLevel",{defaultValue:()=>"Info"});var U3=O0("effect/References/CurrentLogSpans",{defaultValue:()=>[]});var b8=(X)=>{if(X?.captureStackTrace===!1)return X;else if(X?.captureStackTrace!==void 0&&typeof X.captureStackTrace!=="boolean")return X;let Y=U6();P1(3);let Q=Error();return P1(Y),{...X,captureStackTrace:Sb(()=>Q.stack)}},bZ=(X)=>(Y)=>{let Q;return()=>{if(Q!==void 0)return Q;let J=Y();if(!J)return;let $=J.split(`
`);if($[X]!==void 0)return Q=$[X].trim(),Q}},Sb=bZ(3);var GB="dev";class rZ extends JY{fiberId;constructor(X,Y=$Y){super("Interrupt",Y,"Interrupted");this.fiberId=X}toString(){return`Interrupt(${this.fiberId})`}toJSON(){return{_tag:"Interrupt",fiberId:this.fiberId}}[N0](X){return h7(X)&&this.fiberId===X.fiberId&&this.annotations===X.annotations}[D0](){return G1(b0(`${this._tag}:${this.fiberId}`))(E7(this.annotations))}}var DB=(X)=>new rZ(X),N3=(X)=>new d6([new rZ(X)]);var NB=(X)=>{let Y=X.reasons.find(P4);return Y?m(Y):c(X)},L6=(X)=>{for(let Y=0;Y<X.reasons.length;Y++){let Q=X.reasons[Y];if(Q._tag==="Fail")return m(Q.error)}return c(X)};var BB=(X)=>X.reasons.some(ZY);var nZ=(X)=>{let Y=X.reasons.find(ZY);return Y?m(Y.defect):c(X)},VB=(X)=>X.reasons.some(h7);var zB=(X)=>{let Y;for(let Q=0;Q<X.reasons.length;Q++){let J=X.reasons[Q];if(J._tag!=="Interrupt")continue;if(Y??=new Set,J.fiberId!==void 0)Y.add(J.fiberId)}return Y?m(Y):c(X)};var qB=V(2,(X,Y)=>{if(X.reasons.length===0)return Y;else if(Y.reasons.length===0)return X;let Q=new d6(EZ(X.reasons,Y.reasons));return o(X,Q)?X:Q}),LB=V(2,(X,Y)=>{let Q=!1,J=X.reasons.map(($)=>{if(P4($))return Q=!0,new I5(Y($.error));return $});return Q?p6(J):X}),kb=(X)=>{let Y={Fail:[],Die:[],Interrupt:[]};for(let Q=0;Q<X.reasons.length;Q++)Y[X.reasons[Q]._tag].push(X.reasons[Q]);return Y},sZ=(X)=>{let Y=kb(X);if(Y.Fail.length>0)return Y.Fail[0].error;else if(Y.Die.length>0)return Y.Die[0].defect;else if(Y.Interrupt.length>0)return new globalThis.Error("All fibers interrupted without error");return new globalThis.Error("Empty cause")},OB=(X,Y)=>{let Q=[],J=[];if(X.reasons.length===0)return Q;let $=U6();P1(1);for(let G of X.reasons){if(G._tag==="Interrupt"){J.push(G);continue}Q.push(yZ(G._tag==="Die"?G.defect:G.error,G.annotations,Y))}if(Q.length===0){let G=Error("The fiber was interrupted by:");G.name="InterruptCause",G.stack=hb(G,J);let _=new globalThis.Error("All fibers interrupted without error",{cause:G});_.name="InterruptError",_.stack=`${_.name}: ${_.message}`,Q.push(yZ(_,J[0].annotations,Y))}return P1($),Q},yZ=(X,Y,Q)=>{let J=typeof X,$;if(X&&J==="object"){if($=new globalThis.Error(bb(X),{cause:X.cause?yZ(X.cause):void 0}),typeof X.name==="string")$.name=X.name;if(typeof X.stack==="string")$.stack=yb(X.stack,$,Y);else{let G=`${$.name}: ${$.message}`;$.stack=Y?TB(G,Y):G}if(Q?.includeCauseInStack)$.stack=RB($);for(let G of Object.keys(X))if(!(G in $))$[G]=X[G]}else $=new globalThis.Error(!X?`Unknown error: ${X}`:J==="string"?X:F4(X));return $},bb=(X)=>{if(typeof X.message==="string")return X.message;else if(typeof X.toString==="function"&&X.toString!==Object.prototype.toString&&X.toString!==Array.prototype.toString)try{return X.toString()}catch{}return F4(X)},gb=/\((.*)\)/g,yb=(X,Y,Q)=>{let J=`${Y.name}: ${Y.message}`,$=(X.startsWith(J)?X.slice(J.length):X).split(`
`),G=[J];for(let _=1;_<$.length;_++){if(/(?:Generator\.next|~effect\/Effect)/.test($[_]))break;G.push($[_])}return Q?TB(G.join(`
`),Q):G.join(`
`)},TB=(X,Y)=>{let Q=Y?.get(m7.key);if(Q)X=`${X}
${FB(Q)}`;return X},hb=(X,Y)=>{let Q=[`${X.name}: ${X.message}`];for(let J of Y){let $=J.fiberId!==void 0?`#${J.fiberId}`:"unknown",G=J.annotations.get(GZ.key);if(Q.push(`    at fiber (${$})`),G)Q.push(FB(G))}return Q.join(`
`)},FB=(X)=>{let Y=[],Q=X,J=0;while(Q&&J<10){let $=Q.stack();if($){let G=$.matchAll(gb),_=!1;for(let[,K]of G)_=!0,Y.push(`    at ${Q.name} (${K})`);if(!_)Y.push(`    at ${Q.name} (${$.replace(/^at /,"")})`)}else Y.push(`    at ${Q.name}`);Q=Q.parent,J++}return Y.join(`
`)},B3=(X)=>OB(X).map(RB).join(`
`),RB=(X)=>X.cause?`${X.stack} {
${AB(X.cause,"  ")}
}`:X.stack,AB=(X,Y)=>{let Q=X.stack.split(`
`),J=`${Y}[cause]: ${Q[0]}`;for(let $=1,G=Q.length;$<G;$++)J+=`
${Y}${Q[$]}`;if(X.cause)J+=` {
${AB(X.cause,`${Y}  `)}
${Y}}`;return J},hZ=`~effect/Fiber/${GB}`,mb={_A:u,_E:u},fb={id:0},V3=()=>globalThis[E5];class aZ{constructor(X,Y=!0){this[hZ]=mb,this.setContext(X),this.id=++fb.id,this.currentOpCount=0,this.interruptible=Y,this._stack=[],this._observers=[],this._exit=void 0,this._children=void 0,this._interruptedCause=void 0,this._yielded=void 0,this._running=!1,this._deferredInterrupt=!1,this.runtimeMetrics?.recordFiberStart(this.context)}[hZ];id;interruptible;currentOpCount;_stack;_observers;_exit;_children;_interruptedCause;_yielded;_running;_deferredInterrupt;context;currentScheduler;currentTracerContext;currentSpan;currentLogLevel;minimumLogLevel;currentStackFrame;runtimeMetrics;maxOpsBeforeYield;currentPreventYield;_dispatcher=void 0;get currentDispatcher(){return this._dispatcher??=this.currentScheduler.makeDispatcher()}getRef(X){return zZ(this.context,X)}addObserver(X){if(this._exit)return X(this._exit),P7;return this._observers.push(X),()=>{let Y=this._observers.indexOf(X);if(Y>=0)this._observers.splice(Y,1)}}interruptUnsafe(X,Y){if(this._exit)return;let Q=N3(X);if(this.currentStackFrame)Q=GY(Q,D6(m7,this.currentStackFrame));if(Y)Q=GY(Q,Y);if(this._interruptedCause=this._interruptedCause?qB(this._interruptedCause,Q):Q,this.interruptible)if(this._running)this._deferredInterrupt=!0;else this.evaluate(A0(this._interruptedCause))}pollUnsafe(){return this._exit}evaluate(X){if(this._exit)return;else if(this._yielded!==void 0){let J=this._yielded;this._yielded=void 0,J()}let Y=this.runLoop(X);if(Y===A4)return;let Q=mZ.interruptChildren&&mZ.interruptChildren(this);if(Q!==void 0)return this.evaluate(S(Q,()=>Y));this._exit=Y,this.runtimeMetrics?.recordFiberEnd(this.context,this._exit);for(let J=0;J<this._observers.length;J++)this._observers[J](Y);this._observers.length=0,this._stack.length=0,this._children=void 0,this.context=k1()}runLoop(X){let Y=globalThis[E5];globalThis[E5]=this;let Q=this._running;this._running=!0;let J=!1,$=X;this.currentOpCount=0;try{while(!0){if(this._deferredInterrupt)this._deferredInterrupt=!1,$=A0(this._interruptedCause);if(this.currentOpCount++,!J&&!this.currentPreventYield&&this.currentScheduler.shouldYield(this)){J=!0;let G=$;$=S(c5,()=>G)}if($=this.currentTracerContext?this.currentTracerContext($,this):$[o0](this),$===A4){let G=this._yielded;if(R4 in G)return this._deferredInterrupt=!1,this._yielded=void 0,G;else if(this._deferredInterrupt){this._yielded=void 0,G();continue}return A4}}}catch(G){if(!j($,o0))return W6(`Fiber.runLoop: Not a valid effect: ${String($)}`);return this.runLoop(W6(G))}finally{this._running=Q,globalThis[E5]=Y}}getCont(X){if(this._deferredInterrupt)return this._deferredInterrupt=!1,db;while(!0){let Y=this._stack.pop();if(!Y)return;let Q=Y[A8]&&Y[A8](this);if(Q)return Q[X]=Q,Q;if(Y[X])return Y}}yieldWith(X){return this._yielded=X,A4}children(){return this._children??=new Set}pipe(){return G0(this,arguments)}setContext(X){this.context=X;let Y=this.getRef(BY);if(Y!==this.currentScheduler)this.currentScheduler=Y,this._dispatcher=void 0;this.currentSpan=X.mapUnsafe.get(xZ),this.currentLogLevel=this.getRef(vZ),this.minimumLogLevel=this.getRef(kZ),this.currentStackFrame=X.mapUnsafe.get(f5.key),this.maxOpsBeforeYield=this.getRef(nN),this.currentPreventYield=this.getRef(sN),this.runtimeMetrics=X.mapUnsafe.get(JB);let Q=X.mapUnsafe.get(SZ);this.currentTracerContext=Q?Q.context:void 0}get currentSpanLocal(){return this.currentSpan?._tag==="Span"?this.currentSpan:void 0}}var db={[S1](X,Y){return A0(Y._interruptedCause)},[FX](X,Y){return A0(Y._interruptedCause)}},mZ={interruptChildren:void 0},z3=(X)=>{if(!X.currentStackFrame)return;let Y=new Map;return Y.set(GZ.key,X.currentStackFrame),j8(Y)},pb=(X)=>{if(X._children===void 0||X._children.size===0)return;return k4(X._children)},ub=(X)=>{let Y=X;if(Y._exit)return M(Y._exit);return n1((Q)=>{if(Y._exit)return Q(M(Y._exit));return Y0(X.addObserver((J)=>Q(M(J))))})},tZ=(X)=>n1((Y)=>{let Q=X[Symbol.iterator](),J=[],$=void 0;function G(){let _=Q.next();while(!_.done){if(_.value._exit){J.push(_.value._exit),_=Q.next();continue}$=_.value.addObserver((K)=>{J.push(K),G()});return}Y(M(J))}return G(),Y0(()=>$?.())});var cb=(X)=>t((Y)=>lb(X,Y.id)),lb=V((X)=>j(X[0],hZ),(X,Y,Q)=>t((J)=>{let $=z3(J);return $=$&&Q?b5($,Q):$??Q,X.interruptUnsafe(Y,$),FY(ub(X))})),k4=(X)=>t((Y)=>{let Q=z3(Y),J=Z3();for(let $ of X)$.interruptUnsafe(Y.id,Q),J.push($);return FY(tZ(J))});var M=Z1,A0=GX,E0=H6,Y0=RX({op:"Sync",[o0](X){let Y=this[Z0](),Q=X.getCont(S1);return Q?Q[S1](Y,X):X.yieldWith(Z1(Y))}}),e=RX({op:"Suspend",[o0](X){return this[Z0]()}}),PB=V((X)=>X.length>=2||r7(X[0]),(X,Y)=>P0(X)?E0(Y?Y():new c6("Effect.fromOption: Option.none")):M(X.value)),u5=r1({onFailure:E0,onSuccess:M}),wB=(X)=>X==null?E0(new c6):M(X),eZ=RX({op:"Yield",[o0](X){let Y=!1;return X.currentDispatcher.scheduleTask(()=>{if(Y)return;X.evaluate(HX)},this[Z0]??0),X.yieldWith(()=>{Y=!0})}}),c5=eZ(0),X2=(X)=>M(T(X)),OY=M(d()),CB=(X)=>P0(X)?OY:z0(X.value,T),EB=(X)=>e(()=>A0(W0(X))),a6=(X)=>W6(X),q3=(X)=>e(()=>E0(W0(X))),$0=M(void 0);var MB=(X)=>{let Y=typeof X==="function"?X:X.try,Q=typeof X==="function"?(J)=>new k3(J,"An error occurred in Effect.try"):X.catch;return e(()=>{try{return M(W0(Y))}catch(J){return E0(W0(()=>Q(J)))}})};var Y2=(X)=>Q2(function(Y,Q){W0(()=>X(Q)).then((J)=>Y(M(J)),(J)=>Y(a6(J)))},X.length!==0),jB=(X)=>{let Y=typeof X==="function"?X:X.try,Q=typeof X==="function"?(J)=>new k3(J,"An error occurred in Effect.tryPromise"):X.catch;return Q2(function(J,$){let G=(_)=>{try{J(E0(W0(()=>Q(_))))}catch(K){J(a6(K))}};try{W0(()=>Y($)).then((_)=>J(M(_)),G)}catch(_){G(_)}},Y.length!==0)},IB=(X)=>t((Y)=>X(Y.id)),xB=t(M),SB=IB(M),Q2=RX({op:"Async",single:!1,[o0](X){let Y=W0(()=>this[Z0][0].bind(X.currentScheduler)),Q=!1,J=!1,$=this[Z0][1]?new AbortController:void 0,G=Y((_)=>{if(Q)return;if(Q=!0,J)X.evaluate(_);else J=_},$?.signal);if(J!==!1)return J;if(J=!0,X._yielded=()=>{Q=!0},$===void 0&&G===void 0)return A4;return X._stack.push(ob(()=>{return Q=!0,$?.abort(),G??HX})),A4}}),ob=RX({op:"AsyncFinalizer",[A8](X){if(X.interruptible)X.interruptible=!1,X._stack.push(x3)},[FX](X,Y){return VB(X)?S(this[Z0](),()=>A0(X)):A0(X)}}),n1=(X)=>Q2(X,X.length>=2),TY=n1(P7),vB=(...X)=>e(()=>d5(X.length===1?X[0]():X[1].call(X[0].self))),J2=(X,...Y)=>{let Q=Y.length===0?function(){return e(()=>d5(X.apply(this,arguments)))}:function(){let J=e(()=>d5(X.apply(this,arguments)));for(let $=0;$<Y.length;$++)J=Y[$](J,...arguments);return J};return $2(X.length,Q)},$2=(X,Y)=>Object.defineProperty(Y,"length",{value:X,configurable:!0}),ZB=bZ(2),kB=function(){let X=typeof arguments[0]==="string",Y=X?arguments[0]:"Effect.fn",Q=X?arguments[1]:void 0,J=U6();P1(2);let $=new globalThis.Error;if(P1(J),X)return(G,..._)=>_B(Y,G,$,_,X,Q);return _B(Y,arguments[0],$,Array.prototype.slice.call(arguments,1),X,Q)},_B=(X,Y,Q,J,$,G)=>{let _=typeof Y==="function"?Y:J.pop().bind(Y.self);return $2(_.length,function(...K){let H=e(()=>{let U=_.apply(this,arguments);return i(U)?U:d5(U)});for(let U=0;U<J.length;U++)H=J[U](H,...K);if(!i(H))return H;let W=U6();P1(2);let D=new globalThis.Error;return P1(W),t6($?LY(X,G,(U)=>uZ(H,U)):H,f5,(U)=>({name:X,stack:ZB(()=>D.stack),parent:{name:`${X} (definition)`,stack:ZB(()=>Q.stack),parent:U}}))})},bB=(X,...Y)=>$2(X.length,Y.length===0?function(){return KB(()=>X.apply(this,arguments))}:function(){let Q=KB(()=>X.apply(this,arguments));for(let J of Y)Q=J(Q);return Q}),KB=(X)=>{try{let Y=X(),Q=void 0;while(!0){let J=Y.next(Q);if(J.done)return M(J.value);let $=J.value;if($&&$._tag==="Success"){Q=$.value;continue}else if($&&$._tag==="Failure")return J.value;else{let G=!0;return e(()=>{if(G)return G=!1,S(J.value,(_)=>d5(Y,_));else return e(()=>d5(X()))})}}}catch(Y){return a6(Y)}},d5=RX({op:"Iterator",single:!1,[S1](X,Y){let Q=this[Z0][0];while(!0){let J=Q.next(X);if(J.done)return M(J.value);if(!E1(J.value))return Y._stack.push(this),J.value;else if(J.value._tag==="Failure")return J.value;X=J.value.value}},[o0](X){return this[S1](this[Z0][1],X)}}),y1=V(2,(X,Y)=>{let Q=M(Y);return S(X,(J)=>Q)}),L3=(X)=>z0(X,T),gB=(X)=>b4(X,{onFailure:M,onSuccess:E0}),fX=V(2,(X,Y)=>S(X,(Q)=>i(Y)?Y:W0(()=>Y(Q)))),O6=V(2,(X,Y)=>S(X,(Q)=>y1(i(Y)?Y:W0(()=>Y(Q)),Q))),FY=(X)=>S(X,(Y)=>HX),yB=(X)=>s1(X,E0),G2=(X,Y)=>t((Q)=>n1((J)=>{let $=C1(X),G=$.length,_=0,K=!1,H=new Set,W=[],D=(U,N,B)=>{if(_++,U._tag==="Failure"){if(W.push(...U.cause.reasons),_>=G)J(A0(p6(W)));return}let z=!K;if(K=!0,J(H.size===0?U:S(Y8(k4(H)),()=>U)),z&&Y?.onWinner)Y.onWinner({fiber:N,index:B,parentFiber:Q})};for(let U=0;U<G;U++){let N=g4(Q,$[U],!0,!0,!1);if(H.add(N),N.addObserver((B)=>{H.delete(N),D(B,N,U)}),K)break}return k4(H)})),Z2=(X,Y)=>t((Q)=>n1((J)=>{let $=!1,G=new Set,_=(H)=>{$=!0,J(G.size===0?H:S(Y8(k4(G)),()=>H))},K=0;for(let H of X){if($)break;let W=K++,D=g4(Q,H,!0,!0,!1);G.add(D),D.addObserver((U)=>{G.delete(D);let N=!$;if(_(U),N&&Y?.onWinner)Y.onWinner({fiber:D,index:W,parentFiber:Q})})}return k4(G)})),hB=V((X)=>i(X[1]),(X,Y,Q)=>G2([X,Y],Q)),O3=V((X)=>i(X[1]),(X,Y,Q)=>Z2([X,Y],Q)),S=V(2,(X,Y)=>{let Q=Object.create(ib);return Q[Z0]=X,Q[S1]=Y.length!==1?(J)=>Y(J):Y,Q}),ib=u6({op:"OnSuccess",[o0](X){return X._stack.push(this),this[Z0]}}),mB=V(2,(X,Y)=>{if(E1(X))return X._tag==="Success"?Y.onSuccess(X.value):Y.onFailure(X.cause);return q6(X,Y)}),E1=(X)=>(R4 in X),fB=V(2,(X,Y)=>{if(E1(X))return X._tag==="Success"?Y(X.value):X;return S(X,Y)}),dB=(X)=>S(X,u),z0=V(2,(X,Y)=>S(X,(Q)=>M(W0(()=>Y(Q))))),pB=V(2,(X,Y)=>E1(X)?rB(X,Y):z0(X,Y)),uB=V(2,(X,Y)=>E1(X)?nB(X,Y):N2(X,Y)),cB=V(2,(X,Y)=>E1(X)?sB(X,Y):B2(X,Y)),lB=V(2,(X,Y)=>{if(E1(X)){if(X._tag==="Success")return X;let Q=L6(X.cause);if(J0(Q))return X;return Y(Q.success)}return m1(X,Y)});var _2=(X)=>X._tag==="Success";var oB=(X)=>X._tag==="Failure";var iB=(X)=>X._tag==="Failure"?m(X.cause):c(X);var HX=Z1(void 0),rB=V(2,(X,Y)=>X._tag==="Success"?Z1(Y(X.value)):X),nB=V(2,(X,Y)=>{if(X._tag==="Success")return X;let Q=L6(X.cause);if(J0(Q))return X;return H6(Y(Q.success))}),sB=V(2,(X,Y)=>{if(X._tag==="Success")return Z1(Y.onSuccess(X.value));let Q=L6(X.cause);if(J0(Q))return X;return H6(Y.onFailure(Q.success))});var aB=(X)=>{let Y=[];for(let Q of X)if(Q._tag==="Failure")Y.push(...Q.cause.reasons);return Y.length===0?HX:GX(p6(Y))};var tB=(X)=>X,eB=(X)=>t((Y)=>M(qZ(Y.context,X))),rb=(X)=>t((Y)=>Y.context.mapUnsafe.has(X.key)?M(PX(Y.context,X)):E0(new c6)),l5=V(2,(X,Y)=>t((Q)=>{let J=Q.context,$=Y(J);if(J===$)return X;return Q.setContext($),r5(X,()=>{Q.setContext(J);return})})),t6=V(3,(X,Y,Q)=>l5(X,(J)=>{let $=PX(J,Y),G=Q($);if($===G)return J;return i1(J,Y,G)})),XV=(X,Y,Q)=>Y8(t((J)=>{let $=PX(J.context,X),G=Y($);return J.setContext(i1(J.context,X,G)),X8(PX(J.context,h8),(_)=>{let K=PX(J.context,X),H;if(Q?.reset===void 0){if(K!==G)return $0;H=$}else H=Q.reset($,G,K);return J.setContext(i1(J.context,X,H)),$0})})),K2=()=>nb,nb=t((X)=>M(X.context)),y8=(X)=>t((Y)=>X(Y.context)),YV=V(2,(X,Y)=>l5(X,W1(Y))),e6=V(2,(X,Y)=>{if(E1(X))return X;return l5(X,b5(Y))}),h1=function(){if(arguments.length===1)return V(2,(X,Y)=>HB(X,arguments[0],Y));return V(3,(X,Y,Q)=>HB(X,Y,Q)).apply(this,arguments)},HB=(X,Y,Q)=>l5(X,(J)=>{if(J.mapUnsafe.get(Y.key)===Q)return J;return i1(J,Y,Q)}),T3=V(3,(X,Y,Q)=>S(Q,(J)=>h1(X,Y,J))),QV=V((X)=>i(X[1]),(X,Y,Q)=>H2(X,Y,(J,$)=>[J,$],Q)),H2=V((X)=>i(X[1]),(X,Y,Q,J)=>J?.concurrent?z0(MY([X,Y],{concurrency:2}),([$,G])=>W0(()=>Q($,G))):S(X,($)=>z0(Y,(G)=>W0(()=>Q($,G))))),JV=V((X)=>i(X[0]),(X,Y,Q)=>E2(X,Y,Q?(J)=>E0(Q(J)):()=>E0(new c6))),$V=V(2,(X,Y)=>S(Y,(Q)=>Q?L3(X):OY)),W2=V(2,(X,Y)=>Array.from({length:Y},()=>X)),GV=V((X)=>i(X[0]),(X,Y,Q)=>MY(W2(X,Y),Q)),F3=V((X)=>i(X[0]),(X,Y)=>Q8({while:b6,body:W1(Y?.disableYield?X:S(X,(Q)=>c5)),step:P7})),s1=V(2,(X,Y)=>{let Q=Object.create(sb);return Q[Z0]=X,Q[FX]=Y.length!==1?(J)=>Y(J):Y,Q}),sb=u6({op:"OnFailure",[o0](X){return X._stack.push(this),this[Z0]}}),U2=V(3,(X,Y,Q)=>s1(X,(J)=>{if(!Y(J))return A0(J);return W0(()=>Q(J))})),o5=V(3,(X,Y,Q)=>s1(X,(J)=>{let $=Y(J);return J0($)?A0($.failure):W0(()=>Q($.success,J))})),m1=V(2,(X,Y)=>o5(X,L6,(Q)=>Y(Q))),ZV=(X)=>b4(X,{onFailure:(Y)=>ZZ(Y)?OY:E0(Y),onSuccess:X2}),_V=V(2,(X,Y)=>o5(X,nZ,Y)),KV=V(2,(X,Y)=>s1(X,(Q)=>fX(W0(()=>Y(Q)),A0(Q)))),HV=V(3,(X,Y,Q)=>U2(X,Y,(J)=>fX(W0(()=>Q(J)),A0(J)))),R3=V(3,(X,Y,Q)=>s1(X,(J)=>{let $=Y(J);if(J0($))return A0(J);return fX(W0(()=>Q($.success,J)),A0(J))})),D2=V(2,(X,Y)=>R3(X,L6,(Q)=>Y(Q))),WV=V(3,(X,Y,Q)=>{let J=Array.isArray(Y)?($)=>j($,"_tag")&&Y.includes($._tag):g6(Y);return D2(X,($)=>J($)?Q($):$0)}),UV=V(2,(X,Y)=>R3(X,nZ,(Q)=>Y(Q))),RY=V((X)=>i(X[0]),(X,Y,Q,J)=>s1(X,($)=>{let G=L6($);if(J0(G))return A0(G.failure);if(!Y(G.success))return J?W0(()=>J(G.success)):A0($);return W0(()=>Q(G.success))})),A3=V((X)=>i(X[0]),(X,Y,Q,J)=>s1(X,($)=>{let G=L6($);if(J0(G))return A0(G.failure);let _=Y(G.success);if(J0(_))return J?W0(()=>J(_.failure)):A0($);return W0(()=>Q(_.success))})),P3=V((X)=>i(X[0]),(X,Y,Q,J)=>{let $=Array.isArray(Y)?(G)=>j(G,"_tag")&&Y.includes(G._tag):g6(Y);return RY(X,$,Q,J)}),DV=V((X)=>i(X[0]),(X,Y,Q)=>{let J;return A3(X,($)=>{return J??=Object.keys(Y),j($,"_tag")&&gX($._tag)&&J.includes($._tag)?m($):c($)},($)=>W0(()=>Y[$._tag]($)),Q)}),NV=V((X)=>i(X[0]),(X,Y,Q,J,$)=>RY(X,(G)=>g6(G,Y)&&j(G,"reason"),(G)=>{let _=G.reason;if(g6(_,Q))return J(_,G);return $?W0(()=>$(_,G)):E0(G)})),BV=V((X)=>i(X[0]),(X,Y,Q,J)=>{let $;return RY(X,(G)=>g6(G,Y)&&j(G,"reason")&&j(G.reason,"_tag")&&gX(G.reason._tag),(G)=>{let _=G.reason;if($??=Object.keys(Q),$.includes(_._tag))return W0(()=>Q[_._tag](_,G));return J?W0(()=>J(_,G)):E0(G)})}),VV=V(2,(X,Y)=>A3(X,(Q)=>{if(g6(Q,Y)&&j(Q,"reason"))return m(Q.reason);return c(Q)},E0)),N2=V(2,(X,Y)=>m1(X,(Q)=>q3(()=>Y(Q)))),B2=V(2,(X,Y)=>b4(X,{onFailure:(Q)=>q3(()=>Y.onFailure(Q)),onSuccess:(Q)=>Y0(()=>Y.onSuccess(Q))})),w3=(X)=>m1(X,a6),zV=V(2,(X,Y)=>m1(X,(Q)=>Y0(Y))),qV=(X)=>e(()=>{let Y=X[Symbol.iterator](),Q=Y.next();if(Q.done)return a6(Error("Received an empty collection of effects"));function J($){let G=Y.next();if(G.done)return $.value;return m1($.value,(_)=>J(G))}return J(Q)}),V2=(X)=>m1(X,(Y)=>S(c5,()=>V2(X))),LV=V((X)=>i(X[0]),(X,Y)=>{if(!Y?.log)return b4(X,{onFailure:(J)=>$0,onSuccess:(J)=>$0});let Q=dX(Y.log===!0?void 0:Y.log);return q6(X,{onFailure(J){let $=NB(J);return J0($)?A0($.failure):Y.message===void 0?Q(J):Q(Y.message,J)},onSuccess:(J)=>$0})}),OV=V((X)=>i(X[0]),(X,Y)=>{if(!Y?.log)return q6(X,{onFailure:(J)=>$0,onSuccess:(J)=>$0});let Q=dX(Y.log===!0?void 0:Y.log);return q6(X,{onFailure:(J)=>Y.message===void 0?Q(J):Q(Y.message,J),onSuccess:(J)=>$0})}),TV=(X)=>C3(X,{onFailure:d,onSuccess:T}),g8=(X)=>AY(X,{onFailure:c,onSuccess:m}),q6=V(2,(X,Y)=>{let Q=Object.create(ab);return Q[Z0]=X,Q[S1]=Y.onSuccess.length!==1?(J)=>Y.onSuccess(J):Y.onSuccess,Q[FX]=Y.onFailure.length!==1?(J)=>Y.onFailure(J):Y.onFailure,Q}),ab=u6({op:"OnSuccessAndFailure",[o0](X){return X._stack.push(this),this[Z0]}}),z2=V(2,(X,Y)=>q6(X,{onFailure:(Q)=>Y0(()=>Y.onFailure(Q)),onSuccess:(Q)=>Y0(()=>Y.onSuccess(Q))})),b4=V(2,(X,Y)=>q6(X,{onFailure:(Q)=>{let J=Q.reasons.find(P4);return J?W0(()=>Y.onFailure(J.error)):A0(Q)},onSuccess:Y.onSuccess})),C3=V(2,(X,Y)=>b4(X,{onFailure:(Q)=>Y0(()=>Y.onFailure(Q)),onSuccess:(Q)=>Y0(()=>Y.onSuccess(Q))})),AY=V(2,(X,Y)=>{if(E1(X)){if(X._tag==="Success")return Z1(Y.onSuccess(X.value));let Q=L6(X.cause);if(J0(Q))return X;return Z1(Y.onFailure(Q.success))}return C3(X,Y)}),FV=V(2,(X,Y)=>{if(E1(X)){if(X._tag==="Success")return Z1(Y.onSuccess(X.value));return Z1(Y.onFailure(X.cause))}return z2(X,Y)}),PY=(X)=>E1(X)?Z1(X):tb(X),tb=RX({op:"Exit",[o0](X){return X._stack.push(this),this[Z0]},[S1](X,Y,Q){return M(Q??Z1(X))},[FX](X,Y,Q){return M(Q??GX(X))}}),RV=AY({onFailure:()=>!0,onSuccess:()=>!1}),AV=AY({onFailure:()=>!1,onSuccess:()=>!0}),PV=V(2,(X,Y)=>fX(h4(Y),X)),q2=V(2,(X,Y)=>O3(X,S(h4(Y.duration),Y.orElse))),wV=V(2,(X,Y)=>q2(X,{duration:Y,orElse:()=>E0(new k2)})),CV=V(2,(X,Y)=>O3(L3(X),y1(h4(Y),d()))),EV=(X)=>y4((Y)=>{let Q=Y.currentTimeNanosUnsafe();return z0(X,(J)=>[N6(Y.currentTimeNanosUnsafe()-Q),J])}),fZ="~effect/Scope",dZ="~effect/Scope/Closeable",h8=hX("effect/Scope"),L2=(X,Y)=>e(()=>E3(X,Y)??$0),E3=(X,Y)=>{if(X.state._tag==="Closed")return;let Q={_tag:"Closed",exit:Y};if(X.state._tag==="Empty"){X.state=Q;return}let{finalizers:J}=X.state;if(X.state=Q,J.size===0)return;else if(J.size===1)return J.values().next().value(Y);return eb(X,J,Y)},eb=J2(function*(X,Y,Q){let J=[],$=[],G=Array.from(Y.values()),_=V3();for(let K=G.length-1;K>=0;K--){let H=G[K];if(X.strategy==="sequential")J.push(yield*PY(H(Q)));else $.push(g4(_,H(Q),!0,!0,"inherit"))}if($.length>0)J=yield*tZ($);return yield*aB(J)});var MV=(X,Y)=>{let Q=wY(Y);if(X.state._tag==="Closed")return Q.state=X.state,Q;let J={};return D3(X,J,($)=>L2(Q,$)),D3(Q,J,($)=>Y0(()=>jV(X,J))),Q},X8=(X,Y)=>{return e(()=>{if(X.state._tag==="Closed")return Y(X.state.exit);return D3(X,{},Y),$0})};var D3=(X,Y,Q)=>{if(X.state._tag==="Empty")X.state={_tag:"Open",finalizers:new Map([[Y,Q]])};else if(X.state._tag==="Open")X.state.finalizers.set(Y,Q)},jV=(X,Y)=>{if(X.state._tag==="Open")X.state.finalizers.delete(Y)},wY=(X="sequential")=>({[dZ]:dZ,[fZ]:fZ,strategy:X,state:Xg}),Xg={_tag:"Empty"};var CY=h8,IV=h1(h8),M3=(X)=>t((Y)=>{let Q=Y.context,J=wY();return Y.setContext(i1(Y.context,h8,J)),r5(X,($)=>{return Y.setContext(Q),E3(J,$)})});var j3=(X)=>e(()=>{let Y=wY();return f1(X(Y),(Q)=>e(()=>E3(Y,Q)??$0))}),I3=(X,Y,Q)=>y8((J)=>EY(($)=>S(CY,(G)=>O6(Q?.interruptible?$(X):X,(_)=>X8(G,(K)=>e6(Y(_,K),J)))))),i5=(X)=>S(CY,(Y)=>y8((Q)=>X8(Y,(J)=>e6(X(J),Q)))),r5=RX({op:"OnExit",single:!1,[o0](X){return X._stack.push(this),this[Z0][0]},[A8](X){if(X.interruptible&&this[Z0][2]!==!0)X._stack.push(x3),X.interruptible=!1},[S1](X,Y,Q){Q??=Z1(X);let J=this[Z0][1](Q);return J?S(J,($)=>Q):Q},[FX](X,Y,Q){Q??=GX(X);let J=this[Z0][1](Q);return J?S(J,($)=>Q):Q}}),f1=V(2,r5),xV=V(2,(X,Y)=>f1(X,(Q)=>Y)),O2=V(3,(X,Y,Q)=>f1(X,(J)=>{if(!Y(J))return $0;return Q(J)})),T2=V(3,(X,Y,Q)=>f1(X,(J)=>{let $=Y(J);return J0($)?$0:Q($.success,J)})),F2=V(2,(X,Y)=>T2(X,iB,Y)),SV=V(3,(X,Y,Q)=>O2(X,(J)=>{if(J._tag!=="Failure")return!1;return Y(J.cause)},(J)=>Q(J.cause))),R2=V(3,(X,Y,Q)=>f1(X,(J)=>{if(J._tag!=="Failure")return $0;let $=Y(J.cause);return J0($)?$0:Q($.success,J.cause)})),vV=V(2,(X,Y)=>R2(zB,Y)(X)),kV=(X,Y,Q)=>EY((J)=>S(X,($)=>r5(J(Y($)),(G)=>Q($,G),!0))),bV=(X)=>I3(X,(Y)=>j(Y,Symbol.asyncDispose)?Y2(()=>Y[Symbol.asyncDispose]()):Y0(()=>Y[Symbol.dispose]())),A2=V(2,(X,Y)=>Y0(()=>{let Q=x8(ZX(Y)),J=Number.isFinite(Q),$=$g(!1),G=0,_=!1,K,H=S($.await,()=>K);return[t((W)=>{let D=W.getRef(T6),U=J?D.currentTimeMillisUnsafe():0;if(_||U<G)return K??H;return _=!0,$.closeUnsafe(),K=void 0,f1(X,(N)=>Y0(()=>{_=!1,G=D.currentTimeMillisUnsafe()+Q,K=N,$.openUnsafe()}))}),Y0(()=>{G=0,$.closeUnsafe(),K=void 0})]})),P2=V(2,(X,Y)=>z0(A2(X,Y),(Q)=>Q[0])),gV=(X)=>P2(X,n6),yV=t((X)=>A0(N3(X.id))),Y8=(X)=>t((Y)=>{if(!Y.interruptible)return X;return Y.interruptible=!1,Y._stack.push(x3),X}),hV=RX({op:"SetInterruptible",[A8](X){if(X.interruptible=this[Z0],X._interruptedCause&&X.interruptible)return()=>A0(X._interruptedCause)}}),x3=hV(!0),Yg=hV(!1),mV=(X)=>{if(X.interruptible=!0,X._stack.push(Yg),X._interruptedCause)return A0(X._interruptedCause)},w2=(X)=>t((Y)=>{if(Y.interruptible)return X;return mV(Y)??X}),EY=(X)=>t((Y)=>{if(!Y.interruptible)return X(u);return Y.interruptible=!1,Y._stack.push(x3),X(w2)}),fV=(X)=>t((Y)=>{if(Y.interruptible)return X(u);let Q=mV(Y),J=X(Y8);return Q??J}),dV=z0(I3(Y0(()=>new AbortController),(X)=>Y0(()=>X.abort())),(X)=>X.signal),MY=(X,Y)=>{if(y6(X))return Y?.mode==="result"?KX(X,g8,Y):KX(X,u,Y);else if(Y?.discard)return Y.mode==="result"?KX(Object.values(X),g8,Y):KX(Object.values(X),u,Y);return e(()=>{let Q={};return y1(KX(Object.entries(X),([J,$])=>z0(Y?.mode==="result"?g8($):$,(G)=>{k(Q,J,G)}),{discard:!0,concurrency:Y?.concurrency}),Q)})},C2=V((X)=>y6(X[0])&&!i(X[0]),(X,Y,Q)=>z0(KX(X,(J,$)=>g8(Y(J,$)),Q),(J)=>jZ(J,u))),pV=V(3,(X,Y,Q)=>{let J=C1(X);if(J.length===0)return Y0(Y);return e(()=>{let $=0,G=Y();return z0(Q8({while:()=>$<J.length,body:()=>Q(G,J[$],$),step(_){G=_,$++}}),()=>G)})}),uV=V((X)=>y6(X[0])&&!i(X[0]),(X,Y,Q)=>S(C2(X,Y,{concurrency:Q?.concurrency}),([J,$])=>{if(B6(J))return E0(J);return Q?.discard?$0:M($)})),cV=V((X)=>y6(X[0])&&!i(X[0]),(X,Y)=>e(()=>{let Q=X[Symbol.iterator](),J=Q.next();if(!J.done)return lV(Q,0,Y,J.value);return M(d())})),lV=(X,Y,Q,J)=>S(Q(J,Y),($)=>{if($)return M(T(J));let G=X.next();if(!G.done)return lV(X,Y+1,Q,G.value);return M(d())}),oV=V((X)=>y6(X[0])&&!i(X[0]),(X,Y)=>e(()=>{let Q=X[Symbol.iterator](),J=Q.next();if(!J.done)return iV(Q,0,Y,J.value);return M(d())})),iV=(X,Y,Q,J)=>S(Q(J,Y),($)=>{if(Y1($))return M(T($.success));let G=X.next();if(!G.done)return iV(X,Y+1,Q,G.value);return M(d())}),Q8=RX({op:"While",[S1](X,Y){if(this[Z0].step(X),this[Z0].while())return Y._stack.push(this),this[Z0].body();return HX},[o0](X){if(this[Z0].while())return X._stack.push(this),this[Z0].body();return HX}}),KX=V((X)=>typeof X[1]==="function",(X,Y,Q)=>e(()=>{let J=Q?.concurrency??1,$=J==="unbounded"?Number.POSITIVE_INFINITY:Math.max(1,J);if($===1)return Qg(X,Y,Q);let G=C1(X),_=G.length;if(_===0)return Q?.discard?$0:M([]);let K=Q?.discard?void 0:Array(_),H=Jg({f:Y,out:K},G,{concurrency:$});return H?y1(H,K):M(K)})),Qg=(X,Y,Q)=>e(()=>{let J=Q?.discard?void 0:[],$=X[Symbol.iterator](),G=$.next(),_=0;return y1(Q8({while:()=>!G.done,body:()=>Y(G.value,_++),step:(K)=>{if(J)J.push(K);G=$.next()}}),J)}),rV=(X)=>{let{onItem:Y,step:Q}=X;return(J,$,G)=>{let _=G?.start??0,K=G?.end??$.length,H=G?.concurrency??1,W=G?.orderedStep===!0&&H>1,D=!1,U,N,B,z=!1,q,F,R=_,C=W?Array(K):void 0,E=(w)=>{let A=W6(w);return q=A,D=!0,z=!0,N&&N.size>0?S(Y8(k4(Array.from(N))),()=>A):A},a=(w,A,x)=>{if(!W)return Q(J,w,A,x);if(q)return q;C[x]=A;while(R<K){let n=C[R];if(n===void 0)return;C[R]=void 0;let x0=R++,f0=Q(J,$[x0],n,x0);if(f0)return f0}},L=()=>{let w=!1;for(;!q&&_<K;_++){let A=$[_],x=F??Y(J,A,_);if(E1(x)){if(q=a(A,x,_),q)break}else if(H===1)return S(PY(x),(n)=>{return q=a(A,n,_),_++,q??L()??$0});else if(!U)return n1((n)=>{U=V3(),N=new Set,F=x,B=n;let x0;try{x0=L()}catch(f0){return n(E(f0))}if(x0)return n(x0);return e(()=>{return q=HX,z=!0,N?k4(N):$0})});else{F=void 0;let n=g4(U,x,!0,!0,"inherit");if(n._exit){if(q=a(A,n._exit,_),q)break;continue}N.add(n);let x0=_;if(n.addObserver((f0)=>{N.delete(n);try{if(q){if(!z&&f0._tag==="Failure")for(let V0 of f0.cause.reasons)if(V0._tag==="Interrupt")continue;else if(q._tag==="Failure")q.cause.reasons.push(V0);else q=GX(p6([V0]))}else{let V0=a(A,f0,x0);if(V0)q=V0._tag==="Failure"?GX(p6(V0.cause.reasons.slice())):V0,L()}if(w){let V0=L();if(V0)B(V0)}else if(D&&N.size===0)B(q??$0)}catch(V0){B(E(V0))}}),N.size<H)continue;w=!0,_++;return}}if(D=!0,q){if(N&&N.size>0){let A=z3(U);N.forEach((x)=>x.interruptUnsafe(U.id,A));return}if(B||q._tag==="Failure")return q}else if(B){if(!N)return HX;else if(N.size===0)B($0)}};return L()}},jY=()=>rV,Jg=rV({onItem(X,Y,Q){return X.f(Y,Q)},step(X,Y,Q,J){if(Q._tag==="Failure")return Q;else if(X.out)X.out[J]=Q.value}}),E2=V(3,(X,Y,Q)=>S(X,(J)=>Y(J)?M(J):Q(J))),M2=V(3,(X,Y,Q)=>S(X,(J)=>{let $=Y(J);return J0($)?Q($.failure):M($.success)})),nV=V((X)=>i(X[0]),(X,Y,Q)=>M2(X,Y,Q?(J)=>E0(Q(J)):()=>E0(new c6))),sV=V((X)=>y6(X[0])&&!i(X[0]),(X,Y,Q)=>e(()=>{let J=[];return y1(KX(X,($,G)=>{let _=Y($,G);if(typeof _==="boolean"){if(_)J.push($);return $0}return z0(_,(K)=>{if(K)J.push($)})},{discard:!0,concurrency:Q?.concurrency}),J)})),aV=V((X)=>y6(X[0])&&!i(X[0]),(X,Y)=>e(()=>{let Q=[];for(let J of X){let $=Y(J);if(Y1($))Q.push($.success)}return M(Q)})),tV=V((X)=>y6(X[0])&&!i(X[0]),(X,Y,Q)=>e(()=>{let J=[];return y1(KX(X,($)=>z0(Y($),(G)=>{if(Y1(G))J.push(G.success)}),{discard:!0,concurrency:Q?.concurrency}),J)})),eV=M({}),Xz=p7(z0),Yz=u7(z0,S),Qz=d7(z0);var Jz=V((X)=>i(X[0]),(X,Y)=>t((Q)=>{return Rg(),M(g4(Q,X,Y?.startImmediately,!1,Y?.uninterruptible??!1))})),g4=(X,Y,Q=!1,J=!1,$=!1)=>{let G=$==="inherit"?X.interruptible:!$,_=new aZ(X.context,G);if(Q)_.evaluate(Y);else X.currentDispatcher.scheduleTask(()=>_.evaluate(Y),0);if(!J&&!_._exit)X.children().add(_),_.addObserver(()=>X._children.delete(_));return _},$z=V((X)=>i(X[0]),(X,Y)=>t((Q)=>M(g4(Q,X,Y?.startImmediately,!0,Y?.uninterruptible)))),Gz=(X)=>t((Y)=>{let Q=Y._children&&new Set(Y._children);return f1(X,(J)=>{let $=Y._children;if($===void 0||$.size===0)return $0;else if(Q)$=pN($,(G)=>!Q.has(G));return FY(tZ($))})}),j2=V((X)=>i(X[0]),(X,Y,Q)=>t((J)=>{let $=g4(J,X,Q?.startImmediately,!0,Q?.uninterruptible);if(!$._exit)if(Y.state._tag!=="Closed"){let G={};D3(Y,G,()=>IB((K)=>K===$.id?$0:cb($))),$.addObserver(()=>jV(Y,G))}else $.interruptUnsafe(J.id,z3(J));return M($)})),Zz=V((X)=>i(X[0]),(X,Y)=>S(CY,(Q)=>j2(X,Q,Y))),J8=(X)=>(Y,Q)=>{let J=new aZ(Q?.scheduler?i1(X,BY,Q.scheduler):X,Q?.uninterruptible!==!0);if(J.evaluate(Y),J._exit)return J;if(Q?.signal)if(Q.signal.aborted)J.interruptUnsafe();else{let $=()=>J.interruptUnsafe();Q.signal.addEventListener("abort",$,{once:!0}),J.addObserver(()=>Q.signal.removeEventListener("abort",$))}if(Q?.onFiberStart)Q.onFiberStart(J);return J};var _z=J8(k1()),I2=(X)=>{let Y=J8(X);return(Q,J)=>{let $=Y(Q,J);if(J?.onExit)$.addObserver(J.onExit);return(G)=>{return $.interruptUnsafe(G)}}},Kz=I2(k1()),S3=(X)=>{let Y=J8(X);return(Q,J)=>{let $=Y(Q,J);return new Promise((G)=>{$.addObserver((_)=>G(_))})}},Hz=S3(k1()),x2=(X)=>{let Y=S3(X);return(Q,J)=>Y(Q,J).then(($)=>{if($._tag==="Failure")throw sZ($.cause);return $.value})},Wz=x2(k1()),v3=(X)=>{let Y=J8(X);return(Q)=>{if(E1(Q))return Q;let J=new m5("sync"),$=Y(Q,{scheduler:J});return $._dispatcher?.flush(),$._exit??W6(new g2($))}},Uz=v3(k1()),S2=(X)=>{let Y=v3(X);return(Q)=>{let J=Y(Q);if(J._tag==="Failure")throw sZ(J.cause);return J.value}},Dz=S2(k1()),WB=M(!0),UB=M(!1);class Nz{waiters=[];scheduled=void 0;_isOpen;constructor(X){this._isOpen=X}scheduleUnsafe(X){if(this.waiters.length===0)return WB;if(this.scheduled===void 0)this.scheduled=this.waiters,X.currentDispatcher.scheduleTask(this.flushScheduled,0);else for(let Y=0;Y<this.waiters.length;Y++)this.scheduled.push(this.waiters[Y]);return this.waiters=[],WB}flushScheduled=()=>{if(this.scheduled===void 0)return;let X=this.scheduled;this.scheduled=void 0;for(let Y=0;Y<X.length;Y++)X[Y](HX)};flushWaiters(){let X=this.waiters;this.waiters=[],this.flushScheduled();for(let Y=0;Y<X.length;Y++)X[Y](HX)}open=t((X)=>{if(this._isOpen)return UB;return this._isOpen=!0,this.scheduleUnsafe(X)});release=t((X)=>this._isOpen?UB:this.scheduleUnsafe(X));openUnsafe(){if(this._isOpen)return!1;return this._isOpen=!0,this.flushWaiters(),!0}await=n1((X)=>{if(this._isOpen)return X($0);return this.waiters.push(X),Y0(()=>{let Y=this.waiters.indexOf(X);if(Y!==-1)this.waiters.splice(Y,1);else if(this.scheduled!==void 0){if(Y=this.scheduled.indexOf(X),Y!==-1)this.scheduled.splice(Y,1)}})});closeUnsafe(){if(!this._isOpen)return!1;return this._isOpen=!1,!0}close=Y0(()=>this.closeUnsafe());whenOpen=(X)=>S(this.await,()=>X);isOpen(){return this._isOpen}}var $g=(X)=>new Nz(X??!1);var Bz=t((X)=>M(X.getRef(H3))),Vz=V(2,(X,Y)=>h1(X,H3,Y)),zz=h1(W3),qz=h1(VY),pZ=BigInt(0),Gg={_tag:"Span",spanId:"noop",traceId:"noop",sampled:!1,status:{_tag:"Ended",startTime:pZ,endTime:pZ,exit:HX},attributes:new Map,links:[],kind:"internal",attribute(){},event(){},end(){},addLinks(){}},Zg=(X)=>Object.assign(Object.create(Gg),X),Lz=(X)=>{if(!X)return d();return v1(X.annotations,K3)?X._tag==="Span"?Lz(M4(X.parent)):d():T(X)},v2=(X,Y,Q)=>{let J=!X.getRef(W3)||Q?.annotations&&v1(Q.annotations,K3),$=Q?.parent!==void 0?T(Q.parent):Q?.root?d():Lz(X.currentSpan),G;if(J)G=Zg({name:Y,parent:$,annotations:i1(Q?.annotations??k1(),K3,!0)});else{let _=X.getRef(H3),K=X.getRef(T6),H=X.getRef(VY),W=X.getRef(zY),D=X.getRef(qY),U=Q?.level??X.getRef(eN),N=Q?.links!==void 0?[...D,...Q.links]:D.slice();G=_.span({name:Y,parent:$,annotations:Q?.annotations??k1(),links:N,startTime:H?K.currentTimeNanosUnsafe():BigInt(0),kind:Q?.kind??"internal",root:Q?.root??P0($),sampled:Q?.sampled??(N1($)&&$.value.sampled===!1?!1:!xz(X.getRef(XB),U))});for(let[B,z]of Object.entries(W))G.attribute(B,z);if(Q?.attributes!==void 0)for(let[B,z]of Object.entries(Q.attributes))G.attribute(B,z)}return G},Oz=(X,Y)=>t((Q)=>M(v2(Q,X,Y))),mX=(X,Y)=>Y8(t((Q)=>{let J=PX(Q.context,h8),$=v2(Q,X,Y??{}),G=Q.getRef(T6),_=Q.getRef(VY);return y1(X8(J,(K)=>Kg($,K,G,_)),$)})),Tz=function(){let X=typeof arguments[0]!=="string",Y=X?arguments[1]:arguments[0],Q=b8(X?arguments[2]:arguments[1]);if(X){let J=arguments[0];return S(mX(Y,Q),($)=>p5(J,$,Q))}return(J)=>S(mX(Y,Q),($)=>p5(J,$,Q))},_g=(X,Y)=>{return Y=typeof Y==="function"?Y:TX,t6(f5,(Q)=>({name:X,stack:Y,parent:Q}))},Fz=zY,Rz=qY,Az=V((X)=>i(X[0]),(X,Y,Q={})=>{let $=(Array.isArray(Y)?Y:[Y]).map((G)=>({span:G,attributes:Q}));return t6(X,qY,(G)=>[...G,...$])}),Kg=(X,Y,Q,J)=>Y0(()=>{if(X.status._tag==="Ended")return;X.end(J?Q.currentTimeNanosUnsafe():pZ,Y)}),LY=(X,...Y)=>{let Q=Y.length===1?void 0:Y[0],J=Y[Y.length-1];return t(($)=>{let G=v2($,X,Q),_=$.getRef(T6);return f1(W0(()=>J(G)),(K)=>Y0(()=>{if(G.status._tag==="Ended")return;G.end(_.currentTimeNanosUnsafe(),K)}))})},uZ=h1(S4),p5=function(){let X=i(arguments[0]),Y=X?arguments[1]:arguments[0],Q=X?arguments[2]:arguments[1],J=u;if(Y._tag==="Span")Q=b8(Q),J=_g(Y.name,Q?.captureStackTrace);if(X)return uZ(J(arguments[0]),Y);return($)=>uZ(J($),Y)},Pz=function(){let X=typeof arguments[0]!=="string",Y=X?arguments[1]:arguments[0],Q=b8(arguments[2]);if(X){let G=arguments[0];return LY(Y,arguments[2],(_)=>p5(G,_,Q))}let J=typeof arguments[1]==="function"?arguments[1]:void 0,$=J?void 0:arguments[1];return(G,..._)=>LY(Y,J?J(..._):$,(K)=>p5(G,K,Q))},wz=V((X)=>i(X[0]),(X,...Y)=>t6(X,zY,(Q)=>{let J=Y.length===1?{...Q,...Y[0]}:{...Q};if(Y.length===1)return J;else k(J,Y[0],Y[1]);return J})),Cz=(...X)=>t((Y)=>{let Q=Y.currentSpanLocal;if(Q)if(X.length===1)for(let[J,$]of Object.entries(X[0]))Q.attribute(J,$);else Q.attribute(X[0],X[1]);return $0}),Ez=t((X)=>{let Y=X.currentSpanLocal;return Y?M(Y):E0(new c6)}),Mz=rb(S4),T6=O0("effect/Clock",{defaultValue:()=>new jz}),gZ=2147483647;class jz{currentTimeMillisUnsafe(){return Date.now()}currentTimeMillis=Y0(()=>this.currentTimeMillisUnsafe());currentTimeNanosUnsafe(){return Wg()}currentTimeNanos=Y0(()=>this.currentTimeNanosUnsafe());sleep(X){return this.sleepMillis(x8(X))}sleepMillis(X){if(X<=0)return c5;else if(!Number.isFinite(X))return TY;return n1((Y)=>{let Q=X>gZ?this.sleepMillis(X-gZ):$0,J=setTimeout(()=>Y(Q),Math.min(X,gZ));return Y0(()=>clearTimeout(J))})}}var Hg=function(){let X=BigInt(1e6);if(typeof performance>"u"||typeof performance.now>"u")return()=>BigInt(Date.now())*X;let Y;return()=>{return Y??=BigInt(Date.now())*X-BigInt(Math.round(performance.now()*1e6)),Y+BigInt(Math.round(performance.now()*1e6))}}(),Wg=function(){let X=typeof process==="object"&&"hrtime"in process&&typeof process.hrtime.bigint==="function"?process.hrtime:void 0;if(!X)return Hg;let Y=BigInt(Date.now())*BigInt(1e6)-X.bigint();return()=>Y+X.bigint()}(),y4=(X)=>t((Y)=>X(Y.getRef(T6))),h4=(X)=>y4((Y)=>Y.sleep(ZX(X))),Iz=y4((X)=>X.currentTimeMillis);var cZ="~effect/Cause/TimeoutError";class k2 extends P8("TimeoutError"){[cZ]=cZ;constructor(X){super({message:X})}}var lZ="~effect/Cause/IllegalArgumentError";class b2 extends P8("IllegalArgumentError"){[lZ]=lZ;constructor(X){super({message:X})}}var oZ="~effect/Cause/AsyncFiberError";class g2 extends P8("AsyncFiberError"){[oZ]=oZ;constructor(X){super({message:"An asynchronous Effect was executed with Effect.runSync",fiber:X})}}var iZ="~effect/Cause/UnknownError";class k3 extends P8("UnknownError"){[iZ]=iZ;constructor(X,Y){super({message:Y,cause:X})}}var Ug=O0("effect/Console/CurrentConsole",{defaultValue:()=>globalThis.console}),Dg=(X)=>{switch(X){case"All":return Number.MIN_SAFE_INTEGER;case"Fatal":return 50000;case"Error":return 40000;case"Warn":return 30000;case"Info":return 20000;case"Debug":return 1e4;case"Trace":return 0;case"None":return Number.MAX_SAFE_INTEGER}},Ng=UZ(L1,Dg),xz=M8(Ng),y2=O0("effect/Loggers/CurrentLoggers",{defaultValue:()=>new Set([Tg,Fg])}),Bg=O0("effect/Logger/LogToStderr",{defaultValue:R7}),Sz=function(){let X=typeof arguments[0]==="string"?[[arguments[0],arguments[1]]]:Object.entries(arguments[0]);return Y8(t((Y)=>{let Q=Y.getRef(s6),J={...Q};for(let $=0;$<X.length;$++){let[G,_]=X[$];k(J,G,_)}return Y.setContext(i1(Y.context,s6,J)),X8(PX(Y.context,h8),($)=>{let G=Y.getRef(s6),_={...G};for(let K=0;K<X.length;K++){let[H,W]=X[K];if(G[H]!==W)continue;if(Object.hasOwn(Q,H))k(_,H,Q[H]);else delete _[H]}return Y.setContext(i1(Y.context,s6,_)),$0})}))},Vg="~effect/Logger",zg={[Vg]:{_Message:u,_Output:u},pipe(){return G0(this,arguments)}},vz=(X)=>{let Y=Object.create(zg);return Y.log=X,Y},qg=(X)=>X.replace(/[\s="]/g,"_"),Lg=(X,Y)=>{return`${qg(X[0])}=${Y-X[1]}ms`};var dX=(X)=>(...Y)=>{let Q=void 0;for(let J=0,$=Y.length;J<$;J++){let G=Y[J];if(j5(G)){if(Q)Y.splice(J,1);else Y=Y.slice(0,J).concat(Y.slice(J+1));Q=Q?p6(Q.reasons.concat(G.reasons)):G,J--}}if(Q===void 0)Q=g7;return t((J)=>{let $=X??J.currentLogLevel;if(xz(J.minimumLogLevel,$))return $0;let G=J.getRef(T6),_=J.getRef(y2);if(_.size>0){let K=new Date(G.currentTimeMillisUnsafe());for(let H of _)H.log({cause:Q,fiber:J,date:K,logLevel:$,message:Y})}return $0})};var v4={bold:"1",red:"31",green:"32",yellow:"33",blue:"34",cyan:"36",white:"37",gray:"90",black:"30",bgBrightRed:"101"},V30={None:[],All:[],Trace:[v4.gray],Debug:[v4.blue],Info:[v4.green],Warn:[v4.yellow],Error:[v4.red],Fatal:[v4.bgBrightRed,v4.black]};var Og=(X)=>`${X.getHours().toString().padStart(2,"0")}:${X.getMinutes().toString().padStart(2,"0")}:${X.getSeconds().toString().padStart(2,"0")}.${X.getMilliseconds().toString().padStart(3,"0")}`;var Tg=vz(({cause:X,date:Y,fiber:Q,logLevel:J,message:$})=>{let G=Array.isArray($)?$.slice():[$];if(X.reasons.length>0)G.push(B3(X));let _=Y.getTime(),K=Q.getRef(U3),H="";for(let N of K)H+=` ${Lg(N,_)}`;let W=Q.getRef(s6);if(Object.keys(W).length>0)G.push(W);let D=Q.getRef(Ug);(Q.getRef(Bg)?D.error:D.log)(`[${Og(Y)}] ${J.toUpperCase()} (#${Q.id})${H}:`,...G)}),Fg=vz(({cause:X,fiber:Y,logLevel:Q,message:J})=>{let $=Y.getRef(T6),G=Y.getRef(s6),_=Y.currentSpan;if(_===void 0||_._tag==="ExternalSpan")return;let K={};for(let[H,W]of Object.entries(G))k(K,H,W);if(K["effect.fiberId"]=Y.id,K["effect.logLevel"]=Q.toUpperCase(),X.reasons.length>0)K["effect.cause"]=B3(X);_.event($N(Array.isArray(J)&&J.length===1?J[0]:J),$.currentTimeNanosUnsafe(),K)});function Rg(){mZ.interruptChildren??=pb}var h2=M(void 0);var kz=V((X)=>i(X[0]),(X,Y)=>F2(X,(Q)=>t((J)=>{return Ag(J,Q,Y?.defectsOnly),$0}))),Ag=(X,Y,Q)=>{let J=X.getRef($B);if(J.size===0)return;if(Q&&!BB(Y))return;let $={cause:Y,fiber:X,timestamp:X.getRef(T6).currentTimeNanosUnsafe()};J.forEach((G)=>G.report($))};var bz=$Z,n5=Z1,m8=GX,IY=H6;var gz=HX;var M1=_2,yz=oB;var t5={};k6(t5,{withSpan:()=>Qy,withParentSpan:()=>p2,updateService:()=>Qq,unwrap:()=>d2,tapError:()=>pg,tapCause:()=>ug,tap:()=>dg,syncContext:()=>f2,sync:()=>gg,suspend:()=>hg,succeedContext:()=>f4,succeed:()=>tz,span:()=>Yy,satisfiesSuccessType:()=>tg,satisfiesServicesType:()=>Xy,satisfiesErrorType:()=>eg,provideMerge:()=>fg,provide:()=>s5,parentSpan:()=>Jq,orDie:()=>cg,mock:()=>sg,mergeAll:()=>d3,merge:()=>mg,makeMemoMapUnsafe:()=>a5,makeMemoMap:()=>vg,launch:()=>ng,isLayer:()=>h3,fromBuildMemo:()=>m3,fromBuild:()=>f8,fresh:()=>rg,forkMemoMapUnsafe:()=>c2,forkMemoMap:()=>kg,flatMap:()=>Yq,empty:()=>bg,effectDiscard:()=>yg,effectContext:()=>o2,effect:()=>f3,catchTag:()=>og,catchCause:()=>ig,catch:()=>lg,buildWithScope:()=>l2,buildWithMemoMap:()=>SY,build:()=>az,CurrentMemoMap:()=>m4});var Pg="~effect/Deferred";var wg={[Pg]:{_A:u,_E:u},pipe(){return G0(this,arguments)}},hz=()=>{let X=Object.create(wg);return X.resumes=void 0,X.effect=void 0,X};var mz=(X)=>n1((Y)=>{if(X.effect)return Y(X.effect);return X.resumes??=[],X.resumes.push(Y),Y0(()=>{let Q=X.resumes.indexOf(Y);X.resumes.splice(Q,1)})});var Cg=V(2,(X,Y)=>Y0(()=>Eg(X,Y))),fz=Cg;var Eg=(X,Y)=>{if(X.effect)return!1;if(X.effect=Y,X.resumes){for(let Q=0;Q<X.resumes.length;Q++)X.resumes[Q](Y);X.resumes=void 0}return!0};var dz=s6;var pz=U3,uz=f5;var cz=h8;var lz=wY,xY=IV;var g3=MV,m2=L2;var sz="~effect/Layer",oz="~effect/Layer/MemoMap",Ig=(X,Y)=>{return X.observers++,fX(X8(Y,(Q)=>X.finalizer(Q)),X.effect)},h3=(X)=>j(X,sz),xg={[sz]:{_ROut:u,_E:u,_RIn:u},pipe(){return G0(this,arguments)}},d4=(X)=>{let Y=Object.create(xg);return Y.build=X,Y},f8=(X)=>d4((Y,Q)=>{let J=g3(Q);return f1(X(Y,J),($)=>$._tag==="Failure"?m2(J,$):$0)}),m3=(X)=>{let Y=f8((Q,J)=>Q.getOrElseMemoize(Y,J,X));return Y},Sg=(X,Y,Q,J)=>{let $=lz(),G=hz(),_={observers:1,effect:mz(G),finalizer:(K)=>e(()=>{if(_.observers--,_.observers===0)return X.map.delete(Y),m2($,K);return $0})};return X.map.set(Y,_),X8(Q,_.finalizer).pipe(S(()=>J(X,$)),f1((K)=>{return _.effect=K,fz(G,K)}))};class u2{get[oz](){return oz}parent;constructor(X){this.parent=X}map=new Map;get(X,Y){let Q=this.map.get(X);if(Q)return Ig(Q,Y);return this.parent?.get(X,Y)}getOrElseMemoize(X,Y,Q){let J=this.get(X,Y);if(J)return J;return Sg(this,X,Y,Q)}}var a5=()=>new u2,c2=(X)=>new u2(X),vg=Y0(a5),kg=(X)=>Y0(()=>c2(X));class m4 extends hX()("effect/Layer/CurrentMemoMap"){static forkOrCreate(X){let Y=VZ(X,m4);return Y?c2(Y):a5()}}var SY=V(3,(X,Y,Q)=>h1(z0(X.build(Y,Q),i1(m4,Y)),m4,Y)),az=(X)=>t((Y)=>SY(X,m4.forkOrCreate(Y.context),PX(Y.context,cz))),l2=V(2,(X,Y)=>t((Q)=>SY(X,m4.forkOrCreate(Q.context),Y))),tz=function(){if(arguments.length===1)return(X)=>f4(D6(arguments[0],X));return f4(D6(arguments[0],arguments[1]))},f4=(X)=>d4(W1(M(X))),bg=f4(k1()),gg=function(){if(arguments.length===1)return(X)=>f2(()=>D6(arguments[0],X()));return f2(()=>D6(arguments[0],arguments[1]()))},f2=(X)=>m3(W1(Y0(X))),f3=function(){if(arguments.length===1)return(X)=>iz(arguments[0],X);return iz(arguments[0],arguments[1])},iz=(X,Y)=>o2(z0(Y,(Q)=>D6(X,Q))),o2=(X)=>m3((Y,Q)=>xY(X,Q)),yg=(X)=>o2(y1(X,k1())),hg=(X)=>m3((Y,Q)=>e(()=>X().build(Y,Q))),d2=(X)=>{let Y=hX("effect/Layer/unwrap");return Yq(f3(Y)(X),v1(Y))},ez=(X,Y,Q)=>{let J=g3(Q,"parallel");return KX(X,($)=>$.build(Y,g3(J,"sequential")),{concurrency:X.length}).pipe(z0(($)=>LZ(...$)))},d3=(...X)=>f8((Y,Q)=>ez(X,Y,Q)),mg=V(2,(X,Y)=>d3(X,...Array.isArray(Y)?Y:[Y])),Xq=(X,Y,Q)=>f8((J,$)=>S(Array.isArray(Y)?ez(Y,J,$):Y.build(J,$),(G)=>X.build(J,$).pipe(e6(G),z0((_)=>Q(_,G))))),s5=V(2,(X,Y)=>Xq(X,Y,u)),fg=V(2,(X,Y)=>Xq(X,Y,(Q,J)=>b5(J,Q))),Yq=V(2,(X,Y)=>f8((Q,J)=>S(X.build(Q,J),($)=>Y($).build(Q,J)))),dg=V(2,(X,Y)=>f8((Q,J)=>S(X.build(Q,J),($)=>xY(y1(Y($),$),J)))),pg=V(2,(X,Y)=>f8((Q,J)=>m1(X.build(Q,J),($)=>xY(fX(Y($),E0($)),J)))),ug=V(2,(X,Y)=>f8((Q,J)=>s1(X.build(Q,J),($)=>xY(fX(Y($),A0($)),J)))),cg=(X)=>d4((Y,Q)=>w3(X.build(Y,Q))),lg=V(2,(X,Y)=>d4((Q,J)=>m1(X.build(Q,J),($)=>Y($).build(Q,J))));var og=V(3,(X,Y,Q)=>d4((J,$)=>P3(X.build(J,$),Y,(G)=>Q(G).build(J,$)))),ig=V(2,(X,Y)=>d4((Q,J)=>s1(X.build(Q,J),($)=>Y($).build(Q,J)))),Qq=V(3,(X,Y,Q)=>s5(X,f3(Y,z0(Y,Q)))),rg=(X)=>d4((Y,Q)=>X.build(a5(),Q)),ng=(X)=>M3(fX(az(X),TY)),sg=function(){if(arguments.length===1)return(X)=>rz(arguments[0],X);return rz(arguments[0],arguments[1])},rz=(X,Y)=>tz(X)(new Proxy({...Y},{get(Q,J,$){if(J in Q)return Q[J];let G=U6();P1(2);let _=Error(`${X.key}: Unimplemented method "${J.toString()}"`);return P1(G),_.name="UnimplementedError",ag(_)},has:b6})),ag=(X)=>{let Y=Object.assign(a6(X),{[nz]:nz,channel:{[y3]:y3,transform:()=>M(Y),pipe(){return G0(this,arguments)}},[y3]:y3,transform:()=>M(Y)});function Q(){return Y}return Object.assign(Q,Y),Object.setPrototypeOf(Q,Object.getPrototypeOf(Y)),Q},nz="~effect/Stream",y3="~effect/Channel",tg=()=>(X)=>X,eg=()=>(X)=>X,Xy=()=>(X)=>X,Yy=(X,Y)=>{return Y=b8(Y),f3(S4,Y?.onEnd?O6(mX(X,Y),(Q)=>i5((J)=>Y.onEnd(Q,J))):mX(X,Y))},Jq=(X)=>f4(S4.context(X)),Qy=function(){let X=typeof arguments[0]!=="string",Y=X?arguments[1]:arguments[0],Q=b8(X?arguments[2]:arguments[1]);if(X){let J=arguments[0];return d2(z0(Q?.onEnd!==void 0?O6(mX(Y,Q),($)=>i5((G)=>Q.onEnd($,G))):mX(Y,Q),($)=>p2(J,$)))}return(J)=>d2(z0(Q?.onEnd!==void 0?O6(mX(Y,Q),($)=>i5((G)=>Q.onEnd($,G))):mX(Y,Q),($)=>p2(J,$)))},p2=function(){let X=h3(arguments[0]),Y=X?arguments[1]:arguments[0],Q=X?arguments[2]:arguments[1],J=u;if(Y._tag==="Span")Q=b8(Q),J=Jy(Y.name,Q?.captureStackTrace);let $=Jq(Y);if(X)return s5(J(arguments[0]),$);return(G)=>s5(J(G),$)},Jy=(X,Y)=>{return Y=typeof Y==="function"?Y:TX,Qq(uz,(Q)=>({name:X,stack:Y,parent:Q}))};var $q="~effect/ExecutionPlan";var $y={[$q]:$q,get captureRequirements(){let X=this;return y8((Y)=>M(Gy(X.steps.map((Q)=>({...Q,provide:h3(Q.provide)?s5(Q.provide,f4(Y)):Q.provide})))))},pipe(){return G0(this,arguments)}},Gy=(X)=>{let Y=Object.create($y);return Y.steps=X,Y};var Gq=O0("effect/ExecutionPlan/CurrentMetadata",{defaultValue:W1({attempt:0,stepIndex:0})});var Zq=j5,_q=KN,p3=P4;var u3=p6,Kq=g7;var c3=(X)=>new I5(X),l3=(X)=>new y7(X),o3=DB;var $8=LB;var i2=L6;var Hq=B3;var r2=KY;var n2=BN;var i3=b2;var r3="~effect/time/DateTime",n3="~effect/time/DateTime/TimeZone",Uq={[r3]:r3,pipe(){return G0(this,arguments)},[U1](){return this.toString()},toJSON(){return gY(this).toJSON()}},Uy={...Uq,_tag:"Utc",[D0](){return h6(this.epochMilliseconds)},[N0](X){return X9(X)&&X._tag==="Utc"&&this.epochMilliseconds===X.epochMilliseconds},toString(){return`DateTime.Utc(${gY(this).toJSON()})`}},Dy={...Uq,_tag:"Zoned",[D0](){return G1(h6(this.epochMilliseconds))(X0(this.zone))},[N0](X){return X9(X)&&X._tag==="Zoned"&&this.epochMilliseconds===X.epochMilliseconds&&o(this.zone,X.zone)},toString(){return`DateTime.Zoned(${H_(this)})`}},Dq={[n3]:n3,[U1](){return this.toString()}},Ny={...Dq,_tag:"Named",[D0](){return b0(`Named:${this.id}`)},[N0](X){return u4(X)&&X._tag==="Named"&&this.id===X.id},toString(){return`TimeZone.Named(${this.id})`},toJSON(){return{_id:"TimeZone",_tag:"Named",id:this.id}}},By={...Dq,_tag:"Offset",[D0](){return b0(`Offset:${this.offset}`)},[N0](X){return u4(X)&&X._tag==="Offset"&&this.offset===X.offset},toString(){return`TimeZone.Offset(${Z_(this.offset)})`},toJSON(){return{_id:"TimeZone",_tag:"Offset",offset:this.offset}}},F6=(X,Y,Q)=>{let J=Object.create(Dy);return J.epochMilliseconds=X,J.zone=Y,Object.defineProperty(J,"partsUtc",{value:Q,enumerable:!1,writable:!0}),Object.defineProperty(J,"adjustedEpochMillis",{value:void 0,enumerable:!1,writable:!0}),Object.defineProperty(J,"partsAdjusted",{value:void 0,enumerable:!1,writable:!0}),J},X9=(X)=>j(X,r3);var u4=(X)=>j(X,n3),Nq=(X)=>u4(X)&&X._tag==="Offset",Bq=(X)=>u4(X)&&X._tag==="Named",Vq=(X)=>X._tag==="Utc",t2=(X)=>X._tag==="Zoned",zq=D1((X,Y)=>X.epochMilliseconds===Y.epochMilliseconds),qq=C4((X,Y)=>X.epochMilliseconds<Y.epochMilliseconds?-1:X.epochMilliseconds>Y.epochMilliseconds?1:0);var e2=(X)=>{let Y=Object.create(Uy);return Y.epochMilliseconds=X,Object.defineProperty(Y,"partsUtc",{value:void 0,enumerable:!1,writable:!0}),Y},e5=(X)=>{let Y=X.getTime();if(Number.isNaN(Y))throw new i3("Invalid date");return e2(Y)},X_=(X)=>{if(X9(X))return X;else if(X instanceof Date)return e5(X);else if(typeof X==="object"){if("epochMilliseconds"in X)return e2(X.epochMilliseconds);let Y=new Date(0);return Ry(Y,X),e5(Y)}else if(typeof X==="string"&&!Vy(X))return e5(new Date(X+"Z"));return e5(new Date(X))},Vy=(X)=>/Z|GMT|[+-]\d{2}$|[+-]\d{2}:?\d{2}$|\]$/.test(X),zy=-8639999956800000,qy=8639999949600000,Y_=(X,Y)=>{let Q=Y?.timeZone;if(Q===void 0&&X9(X)&&t2(X))return X;let J=X_(X);if(J.epochMilliseconds<zy||J.epochMilliseconds>qy)throw RangeError(`Epoch millis out of range: ${J.epochMilliseconds}`);if(Q===void 0&&typeof X==="object"&&"timeZoneId"in X)Q=X.timeZoneId;let $;if(Q===void 0){let G=new Date(J.epochMilliseconds).getTimezoneOffset()*-60*1000;$=bY(G)}else if(u4(Q))$=Q;else if(typeof Q==="number")$=bY(Q);else{let G=$_(Q);if(P0(G))throw new i3(`Invalid time zone: ${Q}`);$=G.value}if(Y?.adjustForTimeZone!==!0)return F6(J.epochMilliseconds,$,J.partsUtc);return Ay(J.epochMilliseconds,$,Y?.disambiguation??"compatible")},s2=j4(Y_),Lq=j4(X_),Ly=/^(.{17,35})\[(.+)\]$/,Oq=(X)=>{let Y=Ly.exec(X);if(Y===null){let $=K_(X);return $!==null?s2(X,{timeZone:$}):d()}let[,Q,J]=Y;return s2(Q,{timeZone:J})};var Tq=(X)=>e2(X.epochMilliseconds);var kY=new Map,Oy={day:"numeric",month:"numeric",year:"numeric",hour:"numeric",minute:"numeric",second:"numeric",timeZoneName:"longOffset",fractionalSecondDigits:3,hourCycle:"h23"},Ty=(X)=>{let Y=X.resolvedOptions().timeZone;if(kY.has(Y))return kY.get(Y);let Q=Object.create(Ny);return Q.id=Y,Q.format=X,kY.set(Y,Q),Q},Q_=(X)=>{if(kY.has(X))return kY.get(X);try{return Ty(new Intl.DateTimeFormat("en-US",{...Oy,timeZone:X}))}catch{throw new i3(`Invalid time zone: ${X}`)}},bY=(X)=>{let Y=Object.create(By);return Y.offset=X,Y},J_=j4(Q_);var Fy=/^(?:GMT|[+-])/,$_=(X)=>{if(Fy.test(X)){let Y=K_(X);return Y===null?d():T(bY(Y))}return J_(X)},Fq=(X)=>{if(X._tag==="Offset")return Z_(X.offset);return X.id};var gY=(X)=>new Date(X.epochMilliseconds),s3=(X)=>{if(X._tag==="Utc")return new Date(X.epochMilliseconds);else if(X.zone._tag==="Offset")return new Date(X.epochMilliseconds+X.zone.offset);else if(X.adjustedEpochMilliseconds!==void 0)return new Date(X.adjustedEpochMilliseconds);let Y=X.zone.format.formatToParts(X.epochMilliseconds).filter((J)=>J.type!=="literal"),Q=new Date(0);return Q.setUTCFullYear(Number(Y[2].value),Number(Y[0].value)-1,Number(Y[1].value)),Q.setUTCHours(Number(Y[3].value),Number(Y[4].value),Number(Y[5].value),Number(Y[6].value)),X.adjustedEpochMilliseconds=Q.getTime(),Q},G_=(X)=>{return s3(X).getTime()-__(X)},Z_=(X)=>{let Y=Math.abs(X),Q=Math.floor(Y/3600000),J=Math.round(Y%3600000/60000);if(J===60)Q+=1,J=0;return`${X<0?"-":"+"}${String(Q).padStart(2,"0")}:${String(J).padStart(2,"0")}`},Rq=(X)=>Z_(G_(X)),__=(X)=>X.epochMilliseconds;var Ry=(X,Y)=>{if(Y.year!==void 0)X.setUTCFullYear(Y.year);if(Y.month!==void 0)X.setUTCMonth(Y.month-1);if(Y.day!==void 0)X.setUTCDate(Y.day);if(Y.weekDay!==void 0){let Q=Y.weekDay-X.getUTCDay();X.setUTCDate(X.getUTCDate()+Q)}if(Y.hour!==void 0)X.setUTCHours(Y.hour);if(Y.minute!==void 0)X.setUTCMinutes(Y.minute);if(Y.second!==void 0)X.setUTCSeconds(Y.second);if(Y.millisecond!==void 0)X.setUTCMilliseconds(Y.millisecond)};var Wq=86400000,Ay=(X,Y,Q)=>{if(Y._tag==="Offset")return F6(X-Y.offset,Y);let J=vY(X-Wq,X,Y),$=vY(X+Wq,X,Y);if(J===$)return F6(X-J,Y);let G=J<$,_=J-$;if(G){if(vY(X-$,X,Y)===$)return F6(X-$,Y);let W=F6(X-J,Y),D=s3(W).getTime();if(X!==D)switch(Q){case"reject":{let U=new Date(X).toISOString();throw RangeError(`Gap time: ${U} does not exist in time zone ${Y.id}`)}case"earlier":return F6(X-$,Y);case"compatible":case"later":return W}return W}if(vY(X-J,X,Y)===J){if(Q==="earlier"||Q==="compatible")return F6(X-J,Y);if(vY(X-J+_,X+_,Y)===J)return F6(X-J,Y);if(Q==="reject"){let W=new Date(X).toISOString();throw RangeError(`Ambiguous time: ${W} occurs twice in time zone ${Y.id}`)}}return F6(X-$,Y)},Py=/([+-])(\d{2}):(\d{2})$/,K_=(X)=>{let Y=Py.exec(X);if(Y===null)return null;let[,Q,J,$]=Y;return(Q==="+"?1:-1)*(Number(J)*60+Number($))*60*1000},vY=(X,Y,Q)=>{let J=Q.format.formatToParts(X).find((G)=>G.type==="timeZoneName")?.value??"";if(J==="GMT")return 0;let $=K_(J);if($===null)return G_(F6(Y,Q));return $};var Aq=(X)=>gY(X).toISOString();var a2=(X)=>{let Y=s3(X);return X._tag==="Utc"?Y.toISOString():`${Y.toISOString().slice(0,-1)}${Rq(X)}`},H_=(X)=>X.zone._tag==="Offset"?a2(X):`${a2(X)}[${X.zone.id}]`;var HJ0=globalThis.Number;var wq=V(2,(X,Y)=>{let Q=X.toString(),J=Y.toString();if(Q.includes("e")||J.includes("e")){if(!globalThis.Number.isFinite(X)||!globalThis.Number.isFinite(Y)||Y===0)return NaN;return Cy(X,Y)}let $=(Q.split(".")[1]||"").length,G=(J.split(".")[1]||"").length,_=$>G?$:G,K=parseInt(X.toFixed(_).replace(".","")),H=parseInt(Y.toFixed(_).replace(".",""));return K%H/Math.pow(10,_)});function Cy(X,Y){let[Q,J]=Pq(X),[$,G]=Pq(Y),_=Math.min(J,G),K=Q*BigInt(10)**BigInt(J-_),H=$*BigInt(10)**BigInt(G-_),W=K%H;if(W===BigInt(0))return X<0||Object.is(X,-0)?-0:0;let D=globalThis.Number(`${W}e${_}`);return D===0?Math.sign(X)*globalThis.Number.MIN_VALUE:D}function Pq(X){let Y=Math.abs(X).toExponential(),Q=Y.indexOf("e"),J=Y.slice(0,Q).replace(".","");return[BigInt(J)*(X<0?-BigInt(1):BigInt(1)),globalThis.Number(Y.slice(Q+1))-J.length+1]}var Cq=l6((X,Y)=>Math.max(X,Y),-1/0),Eq=l6((X,Y)=>Math.min(X,Y),1/0);var WJ0=globalThis.String;var Mq=(X)=>X.trim();var W_=V(2,(X,Y)=>o5(X,Iy,(Q)=>Y(Q)));var jy=IZ(i2,(X)=>r2(X)?m(X):c(X));var Iy=IZ(i2,(X)=>r2(X)?m(X.value):c(X));var jq=V(2,(X,Y)=>q6(X,{onSuccess:Y.onSuccess,onFailure:(Q)=>{let J=jy(Q);return!J0(J)?Y.onDone(J.success.value):Y.onFailure(J.failure)}}));var xq="~effect/Schedule";var c4=O0("effect/Schedule/CurrentMetadata",{defaultValue:W1({input:void 0,output:void 0,duration:g5,attempt:0,start:0,now:0,elapsed:0,elapsedSincePrevious:0})}),xy={[xq]:{_Out:u,_In:u,_Env:u},pipe(){return G0(this,arguments)}},U_=(X)=>j(X,xq),D_=(X)=>{let Y=Object.create(xy);return Y.step=X,Y},N_=()=>{let X=0,Y,Q;return(J,$)=>{if(Q===void 0)Q=J;let G=J-Q,_=Y===void 0?0:J-Y;return Y=J,{input:$,attempt:++X,start:Q,now:J,elapsed:G,elapsedSincePrevious:_}}},Sy=(X)=>D_(z0(X,(Y)=>{let Q=N_();return(J,$)=>Y(Q(J,$))})),B_=(X)=>s1(X.step,(Y)=>M(()=>A0(Y))),a3=(X)=>y4((Y)=>z0(B_(X),(Q)=>{let J=N_();return($)=>e(()=>{let G=Y.currentTimeMillisUnsafe();return S(Q(G,$),([_,K])=>{let H=J(G,$);return H.output=_,H.duration=K,y1(h4(K),H)})})}));var V_=(X)=>D_(z0(B_(X),(Y)=>(Q,J)=>jq(Y(Q,J),{onSuccess:($)=>M([J,$[1]]),onFailure:A0,onDone:()=>n2(J)}))),Sq=(X)=>yY(z_,({attempt:Y})=>M(Y<=X)),vy=(X)=>{let Y=ZX(X);return Sy(M((Q)=>M([Q.attempt-1,Y])))};var yY=V(2,(X,Y)=>D_(z0(B_(X),(Q)=>{let J=N_();return($,G)=>S(Q($,G),(_)=>{let[K,H]=_,W=Y({...J($,G),output:K,duration:H});return S(i(W)?W:M(W),(D)=>D?M(_):n2(K))})})));var z_=vy(g5);var ky=(X,Y,Q)=>j3((J)=>S(Q?.local?SY(Y,a5(),J):l2(Y,J),($)=>e6(X,$))),t3=V((X)=>i(X[0]),(X,Y,Q)=>t7(Y)?e6(X,Y):ky(X,Array.isArray(Y)?d3(...Y):Y,Q));var q_=V(3,(X,Y,Q)=>S(a3(Y),(J)=>{let $=c4.defaultValue();return m1(F3(O6(S(e(()=>h1(X,c4,$)),J),(G)=>Y0(()=>{$=G})),{disableYield:!0}),(G)=>KY(G)?M(G.value):Q(G,$.attempt===0?d():T($)))})),L_=V(3,(X,Y,Q)=>S(a3(Y),(J)=>{let $=c4.defaultValue(),G,_=m1(e(()=>h1(X,c4,$)),(K)=>{return G=K,S(J(K),(H)=>{return $=H,_})});return W_(_,(K)=>W0(()=>Q(G,K)))})),bq=V(2,(X,Y)=>{let Q=typeof Y==="function"?Y(u):U_(Y)?Y:mY(Y);return q_(X,Q,E0)}),hY=V(2,(X,Y)=>{let Q=typeof Y==="function"?Y(u):U_(Y)?Y:mY(Y);return L_(X,Q,E0)}),gq=V(3,(X,Y,Q)=>S(a3(Q),(J)=>{let $=c4.defaultValue(),G=e(()=>h1(X,c4,$));return m1(S(J(Y),(_)=>{$=_;let K=W1(S(G,J));return Q8({while:b6,body:K,step(H){$=H}})}),(_)=>KY(_)?M(_.value):E0(_))})),by=V_(z_),mY=(X)=>{let Y=X.schedule?V_(X.schedule):by;if(X.while)Y=yY(Y,({input:Q})=>{let J=X.while(Q);return i(J)?J:M(J)});if(X.until)Y=yY(Y,({input:Q})=>{let J=X.until(Q);return i(J)?z0(J,($)=>!$):M(!J)});if(X.times!==void 0)Y=yY(Y,({attempt:Q})=>M(Q<=X.times));return Y};var mq=V(2,(X,Y)=>e(()=>{let Q=0,J={attempt:0,stepIndex:0},$=T3(Gq,Y0(()=>{return J={attempt:J.attempt+1,stepIndex:Q},J})),G;return S(Q8({while:()=>Q<Y.steps.length&&(G===void 0||J0(G)),body(){let _=Y.steps[Q],K=$(t3(X,_.provide));if(G){let H=!1,W=K;K=e(()=>{if(H)return W;return H=!0,u5(G)}),K=hY(K,hq(_,!1))}else{let H=hq(_,!0);K=H?hY(K,H):K}return g8(K)},step(_){G=_,Q++}}),()=>u5(G))})),hq=(X,Y)=>{if(!Y)return mY({schedule:X.schedule?X.schedule:X.attempts?void 0:gy,times:X.attempts,while:X.while});else if(X.attempts===1||!(X.schedule||X.attempts))return;return mY({schedule:X.schedule,while:X.while,times:X.attempts?X.attempts-1:void 0})},gy=Sq(1);var hy="~effect/Request",my=QN({_E:(X)=>X,_A:(X)=>X,_R:(X)=>X}),CJ0={..._N,[hy]:my};var fq=(X)=>X;var pq=V(2,(X,Y)=>{let Q=(J)=>n1(($)=>{let G=cq(J,X,$,V3());return fy(J,G)});return i(Y)?S(Y,Q):Q(Y)}),uq=(X,Y)=>{let Q=cq(Y.resolver,X,Y.onExit,{context:Y.context,currentScheduler:v1(Y.context,BY)});return()=>lq(Y.resolver,Q)},e3=[],O_=new WeakMap,cq=(X,Y,Q,J)=>{let $=O_.get(X);if(!$)$=new Map,O_.set(X,$);let G,_=!1,K=fq({request:Y,context:J.context,uninterruptible:!1,completeUnsafe(W){if(_)return;_=!0,Q(W),G?.entrySet.delete(K)}});if(X.preCheck!==void 0&&!X.preCheck(K))return K;let H=X.batchKey(K);if(G=$.get(H),!G){if(e3.length>0)G=e3.pop(),G.key=H,G.resolver=X,G.map=$;else{let W={key:H,resolver:X,map:$,entrySet:new Set,entries:new Set,delayEffect:S(e(()=>W.resolver.delay),(D)=>dq(W)),run:f1(e(()=>W.resolver.runAll(Array.from(W.entries),W.key)),(D)=>{for(let U of W.entrySet)U.completeUnsafe(D._tag==="Success"?W6(Error("Effect.request: RequestResolver did not complete request",{cause:U.request})):D);if(W.entries.clear(),e3.length<128)W.entrySet.clear(),W.key=void 0,W.fiber=void 0,W.resolver=void 0,W.map=void 0,e3.push(W);return $0})};G=W}$.set(H,G),G.fiber=J8(J.context)(G.delayEffect,{scheduler:J.currentScheduler})}if(G.entrySet.add(K),G.entries.add(K),G.resolver.collectWhile(G.entries))return K;return G.fiber.interruptUnsafe(J.id),G.fiber=J8(J.context)(dq(G),{scheduler:J.currentScheduler}),K},lq=(X,Y)=>{if(Y.uninterruptible)return;let Q=O_.get(X);if(!Q)return;let J=X.batchKey(Y),$=Q.get(J);if(!$)return;if($.entries.delete(Y),$.entrySet.delete(Y),$.entries.size===0)Q.delete(J),$.fiber?.interruptUnsafe()},fy=(X,Y)=>Y0(()=>lq(X,Y));function dq(X){if(!X.map.has(X.key))return $0;return X.map.delete(X.key),X.run}var cy="effect/Metric/CurrentMetricAttributes",ly=O0(cy,{defaultValue:()=>({})}),oy="~effect/observability/Metric/MetricRegistryKey",iy=O0(oy,{defaultValue:()=>new Map}),oq="~effect/observability/Metric";class Y9{[oq]=oq;#X=new WeakMap;#Y;id;description;attributes;constructor(X,Y,Q){this.id=X,this.description=Y,this.attributes=Q}valueUnsafe(X){return this.hook(X).get(X)}modifyUnsafe(X,Y){return this.hook(Y).modify(X,Y)}updateUnsafe(X,Y){return this.hook(Y).update(X,Y)}hook(X){let Y=v1(X,ly);if(Object.keys(Y).length===0){if(V1(this.#Y))return this.#Y.hooks;return this.#Y=this.getOrCreate(X,this.attributes),this.#Y.hooks}let Q=Qh(this.attributes,Y),J=this.#X.get(Q);if(V1(J))return J.hooks;return J=this.getOrCreate(X,Q),this.#X.set(Q,J),J.hooks}getOrCreate(X,Y){let Q=ey(this,Y),J=v1(X,iy);if(J.has(Q))return J.get(Q);let $=this.createHooks(),G={id:this.id,type:this.type,description:this.description,attributes:d8(Y),hooks:$};return J.set(Q,G),G}pipe(){return G0(this,arguments)}}var iq=BigInt(0);class ry extends Y9{type="Counter";#X;#Y;constructor(X,Y){super(X,Y?.description,d8(Y?.attributes));this.#X=Y?.bigint??!1,this.#Y=Y?.incremental??!1}createHooks(){let X=this.#X?iq:0,Y=this.#Y?this.#X?(J)=>J>=iq:(J)=>J>=0:(J)=>!0;return fY(()=>({count:X,incremental:this.#Y}),(J)=>{if(Y(J))X=X+J})}}class ny extends Y9{type="Gauge";#X;constructor(X,Y){super(X,Y?.description,d8(Y?.attributes));this.#X=Y?.bigint??!1}createHooks(){let X=this.#X?BigInt(0):0;return fY(()=>({value:X}),(J)=>{X=J},(J)=>{X=X+J})}}class sy extends Y9{type="Frequency";#X;constructor(X,Y){super(X,Y?.description,d8(Y?.attributes));this.#X=Y?.preregisteredWords}createHooks(){let X=new Map;if(V1(this.#X))for(let Q of this.#X)X.set(Q,0);return fY(()=>({occurrences:X}),(Q)=>{let J=X.get(Q)??0;X.set(Q,J+1)})}}class ay extends Y9{type="Histogram";#X;constructor(X,Y){super(X,Y?.description,d8(Y?.attributes));this.#X=Y.boundaries}createHooks(){let X=this.#X,Y=X.length,Q=new Uint32Array(Y+1),J=new Float64Array(Y),$=0,G=0,_=Number.MAX_VALUE,K=-Number.MAX_VALUE;V6(NY(X,L1),(D,U)=>{J[U]=D});let H=(D)=>{let U=0,N=Y;while(U!==N){let B=Math.floor(U+(N-U)/2),z=J[B];if(D<=z)N=B;else U=B;if(N===U+1)if(D<=J[U])N=U;else U=N}if(Q[U]=Q[U]+1,$=$+1,G=G+D,D<_)_=D;if(D>K)K=D},W=()=>{let D=CZ(Y),U=0;for(let N=0;N<Y;N++){let B=J[N],z=Q[N];U=U+z,D[N]=[B,U]}return D};return fY(()=>({buckets:W(),count:$,min:_,max:K,sum:G}),H)}}class ty extends Y9{type="Summary";#X;#Y;#Q;constructor(X,Y){super(X,Y?.description,d8(Y?.attributes));this.#X=Math.max(x8(ZX(Y.maxAge)),0),this.#Y=Y.maxSize,this.#Q=Y.quantiles}createHooks(){let X=NY(this.#Q,L1),Y=CZ(this.#Y);for(let U of this.#Q)if(U<0||U>1)throw Error(`Quantile must be between 0 and 1, found: ${U}`);let Q=0,J=0,$=0,G=Number.MAX_VALUE,_=-Number.MAX_VALUE,K=(U)=>{let N=[],B=0;while(B<this.#Y){let F=Y[B];if(V1(F)){let[R,C]=F,E=U-R;if(E>=0&&E<=this.#X)N.push(C)}B=B+1}let z=NY(N,L1),q=z.length;if(q===0)return X.map((F)=>[F,void 0]);return X.map((F)=>{if(F<=0)return[F,z[0]];if(F>=1)return[F,z[q-1]];let R=Math.ceil(F*q)-1;return[F,z[R]]})},H=(U,N)=>{if(this.#Y>0){let B=Q%this.#Y;Y[B]=[N,U],Q=Q+1}if(J=J+1,$=$+U,U<G)G=U;if(U>_)_=U};return fY((U)=>{let N=v1(U,T6);return{quantiles:K(N.currentTimeMillisUnsafe()),count:J,min:G,max:_,sum:$}},([U,N])=>H(U,N))}}var Q9=V(2,(X,Y)=>y8((Q)=>Y0(()=>X.updateUnsafe(Y,Q))));function ey(X,Y){let Q=`${X.type}:${X.id}`;if(V1(X.description))Q+=`:${X.description}`;if(V1(Y))Q+=`:${Xh(Y)}`;return Q}function fY(X,Y,Q){return{get:X,update:Y,modify:Q??Y}}function Xh(X){return Yh(Array.isArray(X)?X:Object.entries(X))}function Yh(X){return X.map(([Y,Q])=>`${Y}=${Q}`).join(",")}function Qh(X,Y){return{...d8(X),...d8(Y)}}function d8(X){if(V1(X)&&Array.isArray(X))return X.reduce((Y,[Q,J])=>{return k(Y,Q,J),Y},{});return X}var $h=K6,l4=i,Gh=MY,Zh=C2,_h=pV,Kh=uV,Hh=cV,Wh=oV,Uh=KX,nq=Q8,Dh=Y2,T_=jB,p=M,pX=OY,pY=X2,sq=e,aq=Y0,uY=$0;var Nh=h2;var F_=n1,Bh=TY,Vh=eV,zh=Xz,qh=Qz;var Lh=Yz,Oh=vB,f=E0,Th=q3,Fh=A0,o4=EB,tq=a6,J9=MB;var Rh=c5,Ah=eZ,eq=t,R_=u5,Ph=PB,wh=CB,Ch=wB,cY=S,Eh=dB,Mh=fX,XL=O6,jh=g8,Ih=TV,lY=PY,A_=z0,xh=y1,Sh=L3,vh=FY,kh=gB,bh=QV,gh=H2,yh=m1;var hh=P3,mh=DV,fh=NV,dh=BV,ph=VV,i4=s1,uh=_V,ch=RY,lh=A3,oh=ZV,ih=U2,rh=o5,nh=N2,sh=B2,ah=w3,YL=D2,th=WV,QL=KV,eh=HV,Xm=R3,JL=UV,Ym=V2,Qm=hY,Jm=L_,$m=yB,Gm=LV,Zm=OV,_m=mq,Km=kz,Hm=zV,Wm=qV,Um=wV,Dm=CV,Nm=q2,Bm=PV,Vm=h4,zm=EV,qm=G2,Lm=Z2,Om=hB,Tm=O3,Fm=sV,Rm=aV,Am=tV,Pm=E2,wm=M2,Cm=JV,Em=nV,Mm=$V,P_=C3,jm=AY,Im=z2,xm=FV,Sm=mB,vm=q6,km=b4,bm=RV,gm=AV,ym=K2,hm=y8,mm=t3,fm=e6,dm=YV,pm=tB,um=eB,cm=l5,lm=t6,om=XV,$L=h1,im=T3,rm=CY,nm=M3,sm=j3,am=I3,tm=bV,em=kV,Xf=i5,Yf=xV,Qf=F2,Jf=SV,$f=R2,Gf=r5,w_=f1,Zf=O2,_f=T2,Kf=gV,Hf=P2,Wf=A2,GL=yV,Uf=w2,Df=vV,Nf=Y8,ZL=EY,Bf=fV,Vf=dV,zf=F3,qf=bq,Lf=q_,Of=W2,Tf=GV,Ff=V(2,(X,Y)=>_L(X,void 0,Y)),_L=gq,Rf=Bz,Af=Vz,Pf=zz,wf=qz,Cf=wz,Ef=Cz,Mf=Ez,jf=Mz,If=Fz,xf=Rz,Sf=Az,vf=Oz,kf=mX,bf=LY,gf=Pz,yf=Tz,hf=p5,mf=pq,ff=uq,df=Jz,pf=j2,uf=Zz,cf=$z,lf=Gz,of=xB,rf=SB,C_=_z,nf=J8,sf=I2,af=Kz,tf=Wz,ef=x2,XJ=Hz,Xd=S3,Yd=Dz,Qd=S2,p8=Uz,Jd=v3,$d=J2,Gd=kB,KL=y4,Zd=dX,_d=dX(),Kd=dX("Fatal"),Hd=dX("Warn"),Wd=dX("Error"),Ud=dX("Info"),Dd=dX("Debug"),Nd=dX("Trace"),Bd=V(2,(X,Y)=>t6(X,y2,(Q)=>new Set([...Q,Y]))),Vd=V((X)=>l4(X[0]),(X,...Y)=>t6(X,dz,(Q)=>{let J=Y.length===1?{...Q,...Y[0]}:{...Q};if(Y.length===1)return J;else k(J,Y[0],Y[1]);return J})),zd=Sz,qd=V(2,(X,Y)=>S(Iz,(Q)=>t6(X,pz,(J)=>{return[[Y,Q],...J]}))),Ld=V((X)=>l4(X[0]),(X,Y,Q)=>w_(X,(J)=>{let $=Q===void 0?J:W0(()=>Q(J));return Q9(Y,$)})),Od=V((X)=>l4(X[0]),(X,Y,Q)=>XL(X,(J)=>{let $=Q===void 0?J:Q(J);return Q9(Y,$)})),Td=V((X)=>l4(X[0]),(X,Y,Q)=>YL(X,(J)=>{let $=Q===void 0?J:W0(()=>Q(J));return Q9(Y,$)})),Fd=V((X)=>l4(X[0]),(X,Y,Q)=>JL(X,(J)=>{let $=Q===void 0?J:W0(()=>Q(J));return Q9(Y,$)})),Rd=V((X)=>l4(X[0]),(X,Y,Q)=>KL((J)=>{let $=J.currentTimeNanosUnsafe();return w_(X,()=>{let G=J.currentTimeNanosUnsafe(),_=mN(ZX(G),ZX($)),K=Q===void 0?_:W0(()=>Q(_));return Q9(Y,K)})}));class dY extends hX()("effect/Effect/Transaction"){}var Ad=(X)=>eq((Y)=>{if(Y.context.mapUnsafe.has(dY.key))return X;let Q={journal:new Map,retry:!1},J;return ZL(($)=>cY(nq({while:()=>!J,body:W1($(X).pipe($L(dY,Q),QL(()=>{if(!Q.retry)return uY;return $(wd(Q))}),lY)),step(G){if(Q.retry||!Pd(Q))return rq(Q);if(M1(G))Cd(Y,Q);else rq(Q);J=G}}),()=>J))}),Pd=(X)=>{for(let[Y,{version:Q}]of X.journal)if(Y.version!==Q)return!1;return!0},wd=(X)=>sq(()=>{let Y={},Q=Array.from(X.journal.keys()),J=()=>{for(let $ of Q)$.pending.delete(Y)};return F_(($)=>{let G=()=>{J(),$(uY)};for(let _ of Q)_.pending.set(Y,G);return aq(J)})});function Cd(X,Y){for(let[Q,{value:J}]of Y.journal){if(J!==Q.value)Q.version=Q.version+1,Q.value=J;for(let $ of Q.pending.values())X.currentDispatcher.scheduleTask($,0);Q.pending.clear()}}function rq(X){X.retry=!1,X.journal.clear()}var Ed=cY(dY,(X)=>{return X.retry=!0,GL}),Md=(X,Y,Q)=>(...J)=>F_(($)=>{try{X(...J,(G,_)=>{if(G)$(f(Y?Y(G,J):G));else $(p(_))})}catch(G){$(Q?f(Q(G,J)):tq(G))}}),jd=()=>(X)=>X,Id=()=>(X)=>X,xd=()=>(X)=>X,r4=pB,$9=uB,B1=cB,wX=fB,YJ=lB,oY=bB;var XQ={};k6(XQ,{values:()=>vL,union:()=>ed,toValues:()=>od,toEntries:()=>eY,some:()=>Up,size:()=>y_,setMany:()=>Qp,set:()=>cd,removeMany:()=>Yp,remove:()=>Xp,reduce:()=>Zp,mutate:()=>nd,modifyHash:()=>ad,modifyAt:()=>sd,modify:()=>td,map:()=>Jp,make:()=>gd,keys:()=>ld,isHashMap:()=>g_,isEmpty:()=>yd,hasHash:()=>pd,hasBy:()=>ud,has:()=>dd,getUnsafe:()=>fd,getHash:()=>md,get:()=>hd,fromIterable:()=>tY,forEach:()=>Gp,flatMap:()=>$p,findFirst:()=>Wp,filterMap:()=>Hp,filter:()=>_p,every:()=>Dp,entries:()=>kL,endMutation:()=>rd,empty:()=>bd,compact:()=>Kp,beginMutation:()=>id});var JJ="~effect/collections/HashMap",uX=5,sY=1<<uX,Sd=sY/4,HL=sY/2,vd=sY-1,kd=(X)=>{return X=X-(X>>>1&1431655765),X=(X&858993459)+(X>>>2&858993459),(X+(X>>>4)&252645135)*16843009>>>24},iY=(X,Y)=>X>>>Y&vd,u8=(X,Y)=>1<<iY(X,Y),QJ=(X,Y)=>kd(X&Y-1);function WL(X,Y,Q,J,$,G){if(Y>32)throw Error("HashMap: max depth exceeded");let _=u8(Q,Y),K=u8($,Y);if(_===K){let D=WL(X,Y+uX,Q,J,$,G);return new R6(X,_,[D])}let H=_|K,W=_>>>0<K>>>0?[J,G]:[G,J];return new R6(X,H,W)}class G9{canEdit(X){return this.edit===X}}class UL extends G9{_tag="EmptyNode";edit=0;get size(){return 0}get(X,Y,Q){return d()}has(X,Y,Q){return!1}set(X,Y,Q,J,$,G){return G.value=!0,new G8(X,Q,J,$)}remove(X,Y,Q,J,$){return this}iterator(){return[][Symbol.iterator]()}[Symbol.iterator](){return this.iterator()}canEdit(X){return!1}}class G8 extends G9{_tag="LeafNode";edit;hash;key;value;constructor(X,Y,Q,J){super();this.edit=X,this.hash=Y,this.key=Q,this.value=J}get size(){return 1}get(X,Y,Q){if(this.hash===Y&&o(this.key,Q))return T(this.value);return d()}has(X,Y,Q){return this.hash===Y&&o(this.key,Q)}set(X,Y,Q,J,$,G){if(this.hash===Q&&o(this.key,J)){if(o(this.value,$))return this;if(this.canEdit(X))return this.value=$,this;return new G8(X,Q,J,$)}if(G.value=!0,this.hash===Q)return new rY(X,Q,[[this.key,this.value],[J,$]]);let _=u8(Q,Y),K=u8(this.hash,Y);if(_===K)return new R6(X,_,[this.set(X,Y+uX,Q,J,$,G)]);let H=_|K,W=_>>>0<K>>>0?[new G8(X,Q,J,$),this]:[this,new G8(X,Q,J,$)];return new R6(X,H,W)}remove(X,Y,Q,J,$){if(this.hash===Q&&o(this.key,J)){$.value=!0;return}return this}iterator(){return[[this.key,this.value]][Symbol.iterator]()}[Symbol.iterator](){return this.iterator()}}class rY extends G9{_tag="CollisionNode";edit;hash;entries;constructor(X,Y,Q){super();this.edit=X,this.hash=Y,this.entries=Q}get size(){return this.entries.length}get(X,Y,Q){if(this.hash!==Y)return d();for(let[J,$]of this.entries)if(o(J,Q))return T($);return d()}has(X,Y,Q){if(this.hash!==Y)return!1;for(let[J]of this.entries)if(o(J,Q))return!0;return!1}set(X,Y,Q,J,$,G){if(this.hash!==Q)return G.value=!0,WL(X,Y,this.hash,this,Q,new G8(X,Q,J,$));for(let _=0;_<this.entries.length;_++)if(o(this.entries[_][0],J)){if(o(this.entries[_][1],$))return this;if(this.canEdit(X))return this.entries[_]=[J,$],this;let K=[...this.entries];return K[_]=[J,$],new rY(X,this.hash,K)}if(G.value=!0,this.canEdit(X))return this.entries.push([J,$]),this;return new rY(X,this.hash,[...this.entries,[J,$]])}remove(X,Y,Q,J,$){if(this.hash!==Q)return this;let G=this.entries.findIndex(([K])=>o(K,J));if(G===-1)return this;if($.value=!0,this.entries.length===1)return;if(this.entries.length===2){let K=this.entries[G===0?1:0];return new G8(X,this.hash,K[0],K[1])}if(this.canEdit(X))return this.entries.splice(G,1),this;let _=[...this.entries];return _.splice(G,1),new rY(X,this.hash,_)}iterator(){return this.entries[Symbol.iterator]()}[Symbol.iterator](){return this.iterator()}}class R6 extends G9{_tag="IndexedNode";edit;_size;bitmap;children;constructor(X,Y,Q){super();this.edit=X,this.bitmap=Y,this.children=Q}get size(){if(this._size===void 0)this._size=this.children.reduce((X,Y)=>X+Y.size,0);return this._size}get(X,Y,Q){let J=u8(Y,X);if((this.bitmap&J)===0)return d();let $=QJ(this.bitmap,J);return this.children[$].get(X+uX,Y,Q)}has(X,Y,Q){let J=u8(Y,X);if((this.bitmap&J)===0)return!1;let $=QJ(this.bitmap,J);return this.children[$].has(X+uX,Y,Q)}set(X,Y,Q,J,$,G){let _=u8(Q,Y),K=QJ(this.bitmap,_);if((this.bitmap&_)!==0){let H=this.children[K],W=H.set(X,Y+uX,Q,J,$,G);if(H===W)return this;if(this.canEdit(X))return this.children[K]=W,this;let D=[...this.children];return D[K]=W,new R6(X,this.bitmap,D)}else{G.value=!0;let H=new G8(X,Q,J,$),W=this.bitmap|_;if(this.canEdit(X)){if(this.children.splice(K,0,H),this.bitmap=W,this._size=void 0,this.children.length>HL)return this.expand(X,W,this.children);return this}let D=[...this.children];if(D.splice(K,0,H),D.length>HL)return this.expand(X,W,D);return new R6(X,W,D)}}remove(X,Y,Q,J,$){let G=u8(Q,Y);if((this.bitmap&G)===0)return this;let _=QJ(this.bitmap,G),K=this.children[_],H=K.remove(X,Y+uX,Q,J,$);if(!$.value)return this;if(H===void 0){let D=this.bitmap^G;if(D===0)return;if(this.children.length===2){let N=this.children[_===0?1:0];if(N._tag==="LeafNode")return N}if(this.canEdit(X))return this.children.splice(_,1),this.bitmap=D,this._size=void 0,this;let U=[...this.children];return U.splice(_,1),new R6(X,D,U)}if(K===H)return this;if(this.canEdit(X))return this.children[_]=H,this;let W=[...this.children];return W[_]=H,new R6(X,this.bitmap,W)}expand(X,Y,Q){let J=new globalThis.Array(sY),$=0;for(let G=0;G<sY;G++)if((Y&1<<G)!==0)J[G]=Q[$++];return new nY(X,Q.length,J)}iterator(){let X=0,Y;return{next:()=>{while(X<this.children.length){if(!Y)Y=this.children[X].iterator();let Q=Y.next();if(!Q.done)return Q;Y=void 0,X++}return{done:!0,value:void 0}}}}[Symbol.iterator](){return this.iterator()}}class nY extends G9{_tag="ArrayNode";edit;_size;count;children;constructor(X,Y,Q){super();this.edit=X,this.count=Y,this.children=Q}get size(){if(this._size===void 0)this._size=this.children.reduce((X,Y)=>X+(Y?.size??0),0);return this._size}get(X,Y,Q){let J=iY(Y,X),$=this.children[J];return $?$.get(X+uX,Y,Q):d()}has(X,Y,Q){let J=iY(Y,X),$=this.children[J];return $?$.has(X+uX,Y,Q):!1}set(X,Y,Q,J,$,G){let _=iY(Q,Y),K=this.children[_];if(K){let H=K.set(X,Y+uX,Q,J,$,G);if(K===H)return this;if(this.canEdit(X))return this.children[_]=H,this;let W=[...this.children];return W[_]=H,new nY(X,this.count,W)}else{G.value=!0;let H=new G8(X,Q,J,$);if(this.canEdit(X))return this.children[_]=H,this.count++,this._size=void 0,this;let W=[...this.children];return W[_]=H,new nY(X,this.count+1,W)}}remove(X,Y,Q,J,$){let G=iY(Q,Y),_=this.children[G];if(!_)return this;let K=_.remove(X,Y+uX,Q,J,$);if(!$.value)return this;let H=this.count-(K?0:1);if(H<Sd)return this.pack(X,G,K);if(_===K)return this;if(this.canEdit(X)){if(this.children[G]=K,!K)this.count=H;return this._size=void 0,this}let W=[...this.children];return W[G]=K,new nY(X,H,W)}pack(X,Y,Q){let J=[],$=0,G=1;for(let _=0;_<this.children.length;_++){let K=_===Y?Q:this.children[_];if(K)J.push(K),$|=G;G<<=1}return new R6(X,$,J)}iterator(){let X=0,Y;return{next:()=>{while(X<this.children.length){let Q=this.children[X];if(!Q){X++;continue}if(!Y)Y=Q.iterator();let J=Y.next();if(!J.done)return J;Y=void 0,X++}return{done:!0,value:void 0}}}}[Symbol.iterator](){return this.iterator()}}class Z9{[JJ]=JJ;_editable;_edit;_root;_size;constructor(X,Y,Q,J){this._editable=X,this._edit=Y,this._root=Q,this._size=J}get size(){return this._size}[Symbol.iterator](){return this._root.iterator()}[N0](X){if(M_(X)){let Y=X;if(this.size!==Y.size)return!1;for(let[Q,J]of this){let $=cG(X,aY(Q));if(P0($)||!o(J,$.value))return!1}return!0}return!1}[D0](){let X=b0("HashMap");for(let[Y,Q]of this)X=X^X0(Y)+X0(Q);return X}[U1](){return A1(this)}toString(){return`HashMap(${P(Array.from(this))})`}toJSON(){return{_id:"HashMap",values:Array.from(this).map(([X,Y])=>[A1(X),A1(Y)])}}pipe(){return G0(this,arguments)}}var E_=new UL,M_=(X)=>j(X,JJ),t1=()=>new Z9(!1,0,E_,0),DL=(...X)=>j_(X),j_=(X)=>{let Y=E_,Q=0,J={value:!1};for(let[$,G]of X){let _=X0($);if(J.value=!1,Y=Y.set(NaN,0,_,$,G,J),J.value)Q++}return new Z9(!1,0,Y,Q)},$J=(X)=>X.size===0,aY=V(2,(X,Y)=>{return X._root.get(0,X0(Y),Y)}),I_=V(3,(X,Y,Q)=>{return X._root.get(0,Q,Y)}),NL=V(2,(X,Y)=>{let Q=aY(X,Y);if(N1(Q))return Q.value;throw Error(`HashMap.getUnsafe: key not found: ${Y}`)}),n4=V(2,(X,Y)=>{return X._root.has(0,X0(Y),Y)}),x_=V(3,(X,Y,Q)=>{return X._root.has(0,Q,Y)}),BL=V(2,(X,Y)=>{for(let[Q,J]of X)if(Y(J,Q))return!0;return!1}),O1=V(3,(X,Y,Q)=>{let J=X,$=X0(Y),G={value:!1},_=J._editable?J._edit:NaN,K=J._root.set(_,0,$,Y,Q,G);if(J._editable){if(J._root=K,G.value)J._size++;return X}if(J._root===K)return X;return new Z9(!1,J._edit,K,J._size+(G.value?1:0))}),GJ=(X)=>{let Y=X[Symbol.iterator]();return{[Symbol.iterator](){return this},next(){let Q=Y.next();if(Q.done)return{done:!0,value:void 0};return{done:!1,value:Q.value[0]}}}},VL=(X)=>{let Y=X[Symbol.iterator]();return{[Symbol.iterator](){return this},next(){let Q=Y.next();if(Q.done)return{done:!0,value:void 0};return{done:!1,value:Q.value[1]}}}},zL=(X)=>{let Y=X[Symbol.iterator]();return{[Symbol.iterator](){return this},next(){return Y.next()}}},ZJ=(X)=>X.size,S_=(X)=>{let Y=X;return new Z9(!0,Y._edit+1,Y._root,Y._size)},v_=(X)=>{let Y=X;return Y._editable=!1,X},qL=V(2,(X,Y)=>{let Q=S_(X);return Y(Q),v_(Q)}),k_=V(3,(X,Y,Q)=>{let J=aY(X,Y),$=Q(J);if(P0($))return n4(X,Y)?s4(X,Y):X;return O1(X,Y,$.value)}),LL=V(4,(X,Y,Q,J)=>{let $=I_(X,Y,Q),G=J($);if(P0(G))return x_(X,Y,Q)?s4(X,Y):X;return O1(X,Y,G.value)}),OL=V(3,(X,Y,Q)=>{return k_(X,Y,i6(Q))}),b_=V(2,(X,Y)=>{let Q=X;for(let[J,$]of Y)Q=O1(Q,J,$);return Q}),s4=V(2,(X,Y)=>{let Q=X,J=X0(Y),$={value:!1},G=Q._editable?Q._edit:NaN,_=Q._root.remove(G,0,J,Y,$);if(!$.value)return X;if(Q._editable)return Q._root=_??E_,Q._size--,X;if(_===void 0)return t1();return new Z9(!1,Q._edit,_,Q._size-1)}),TL=V(2,(X,Y)=>{let Q=X;for(let J of Y)Q=s4(Q,J);return Q}),FL=V(2,(X,Y)=>{let Q=X;for(let[J,$]of Y)Q=O1(Q,J,$);return Q}),RL=V(2,(X,Y)=>{let Q=t1();for(let[J,$]of X)Q=O1(Q,J,Y($,J));return Q}),AL=V(2,(X,Y)=>{let Q=t1();for(let[J,$]of X)Q=b_(Q,Y($,J));return Q}),PL=V(2,(X,Y)=>{for(let[Q,J]of X)Y(J,Q)}),wL=V(3,(X,Y,Q)=>{let J=Y;for(let[$,G]of X)J=Q(J,G,$);return J}),CL=V(2,(X,Y)=>{let Q=t1();for(let[J,$]of X)if(Y($,J))Q=O1(Q,J,$);return Q}),EL=(X)=>{let Y=t1();for(let[Q,J]of X)if(N1(J))Y=O1(Y,Q,J.value);return Y},ML=V(2,(X,Y)=>{let Q=t1();for(let[J,$]of X){let G=Y($,J);if(Y1(G))Q=O1(Q,J,G.success)}return Q}),jL=V(2,(X,Y)=>{for(let[Q,J]of X)if(Y(J,Q))return T([Q,J]);return d()}),IL=V(2,(X,Y)=>{for(let[Q,J]of X)if(Y(J,Q))return!0;return!1}),xL=V(2,(X,Y)=>{for(let[Q,J]of X)if(!Y(J,Q))return!1;return!0});var g_=M_,bd=t1,gd=DL,tY=j_,yd=$J,hd=aY,md=I_,fd=NL,dd=n4,pd=x_,ud=BL,cd=O1,ld=GJ,vL=VL,od=(X)=>Array.from(vL(X)),kL=zL,eY=(X)=>Array.from(kL(X)),y_=ZJ,id=S_,rd=v_,nd=qL,sd=k_,ad=LL,td=OL,ed=b_,Xp=s4,Yp=TL,Qp=FL,Jp=RL,$p=AL,Gp=PL,Zp=wL,_p=CL,Kp=EL,Hp=ML,Wp=jL,Up=IL,Dp=xL;var WX={};k6(WX,{union:()=>Fp,some:()=>Ep,size:()=>p_,remove:()=>Op,reduce:()=>jp,map:()=>wp,make:()=>zp,isSubset:()=>Pp,isHashSet:()=>d_,isEmpty:()=>Tp,intersection:()=>Rp,has:()=>Lp,fromIterable:()=>QQ,filter:()=>Cp,every:()=>Mp,empty:()=>Vp,difference:()=>Ap,add:()=>qp});var YQ="~effect/collections/HashSet",Np={[D0](){return X0(YQ)},[N0](X){return h_(X)&&_J(this)===_J(X)&&f_(this,(Y)=>_9(X,Y))},[Symbol.iterator](){return GJ(a4(this))},toString(){return`HashSet(${P(Array.from(this))})`},toJSON(){return{_id:"HashSet",values:A1(Array.from(this))}},[U1](){return this.toJSON()},pipe(){return G0(this,arguments)}},c8=(X)=>{let Y=Object.create(Np);return Y[YQ]=YQ,Y.keyMap=X,Y},h_=(X)=>j(X,YQ),a4=(X)=>X.keyMap,bL=()=>c8(t1()),gL=(...X)=>m_(X),m_=(X)=>{let Y=t1();for(let Q of X)Y=O1(Y,Q,!0);return c8(Y)},_9=(X,Y)=>n4(a4(X),Y),yL=(X,Y)=>{let Q=a4(X);return n4(Q,Y)?X:c8(O1(Q,Y,!0))},hL=(X,Y)=>{let Q=a4(X);return n4(Q,Y)?c8(s4(Q,Y)):X},_J=(X)=>ZJ(a4(X)),mL=(X)=>$J(a4(X)),fL=(X,Y)=>{let Q=t1();for(let J of X)if(Y(J))Q=O1(Q,J,!0);return c8(Q)},dL=(X,Y)=>{let J=a4(X);for(let $ of Y)J=O1(J,$,!0);return c8(J)},pL=(X,Y)=>{let Q=t1();for(let J of X)if(_9(Y,J))Q=O1(Q,J,!0);return c8(Q)},uL=(X,Y)=>fL(X,(Q)=>!_9(Y,Q)),cL=(X,Y)=>{for(let Q of X)if(!_9(Y,Q))return!1;return!0},lL=(X,Y)=>{let Q=t1();for(let J of X)Q=O1(Q,Y(J),!0);return c8(Q)},oL=(X,Y)=>fL(X,Y),iL=(X,Y)=>{for(let Q of X)if(Y(Q))return!0;return!1},f_=(X,Y)=>{for(let Q of X)if(!Y(Q))return!1;return!0},rL=(X,Y,Q)=>{let J=Y;for(let $ of X)J=Q(J,$);return J};var Vp=bL,zp=gL,QQ=m_,d_=h_,qp=V(2,yL),Lp=V(2,_9),Op=V(2,hL),p_=_J,Tp=mL,Fp=V(2,dL),Rp=V(2,pL),Ap=V(2,uL),Pp=V(2,cL),wp=V(2,lL),Cp=V(2,oL),Ep=V(2,iL),Mp=V(2,f_),jp=V(3,rL);var Z={};k6(Z,{withDecodingDefaultTypeKey:()=>y00,withDecodingDefaultType:()=>h00,withDecodingDefaultKey:()=>aW,withDecodingDefault:()=>SE,withConstructorDefault:()=>xE,toType:()=>u1,toTaggedUnion:()=>vE,toStandardSchemaV1:()=>le,toStandardJSONSchemaV1:()=>oe,toRepresentation:()=>U60,toJsonSchemaDocument:()=>Xj,toIsoSource:()=>g60,toIsoFocus:()=>y60,toIso:()=>b60,toFormatter:()=>K60,toEquivalence:()=>W60,toEncoderXml:()=>q60,toEncoded:()=>h9,toDifferJsonPatch:()=>m60,toCodecStringTree:()=>Zj,toCodecJsonAST:()=>t$,toCodecJson:()=>Yj,toCodecIso:()=>$j,toCodecArrayFromSingle:()=>z60,toArbitraryLazy:()=>eM,toArbitrary:()=>Z60,tagDefaultOmit:()=>m00,tag:()=>V5,suspend:()=>CE,revealCodec:()=>ce,revealBottom:()=>fe,resolveAnnotationsKey:()=>l60,resolveAnnotations:()=>c60,requiredKey:()=>_00,required:()=>K00,refine:()=>x00,redact:()=>GU,readonlyKey:()=>W00,overrideToFormatter:()=>_60,overrideToEquivalence:()=>H60,overrideToCodecIso:()=>h60,optionalKey:()=>W4,optional:()=>xX,mutableKey:()=>H00,mutable:()=>j00,middlewareEncoding:()=>ME,middlewareDecoding:()=>rW,makeIsMultipleOf:()=>nE,makeIsLessThanOrEqualTo:()=>eQ,makeIsLessThan:()=>tQ,makeIsGreaterThanOrEqualTo:()=>aQ,makeIsGreaterThan:()=>sQ,makeIsBetween:()=>X7,makeFilterGroup:()=>p00,makeFilter:()=>j0,make:()=>v,link:()=>v0,isUppercasedReviver:()=>$10,isUppercased:()=>cE,isUniqueReviver:()=>v10,isUnique:()=>JU,isUncapitalizedReviver:()=>_10,isUncapitalized:()=>iE,isUint32:()=>q10,isUUIDReviver:()=>s00,isUUID:()=>yE,isULIDReviver:()=>t00,isULID:()=>mE,isTrimmedReviver:()=>u00,isTrimmed:()=>tW,isStringSymbolReviver:()=>r00,isStringSymbol:()=>gE,isStringFiniteReviver:()=>o00,isStringFinite:()=>kE,isStringBigIntReviver:()=>i00,isStringBigInt:()=>bE,isStartsWithReviver:()=>Y10,isStartsWith:()=>dE,isSizeBetweenReviver:()=>M10,isSizeBetween:()=>BM,isSchemaError:()=>YH,isSchema:()=>l$,isPropertyNamesReviver:()=>S10,isPropertyNames:()=>LM,isPropertiesLengthBetweenReviver:()=>x10,isPropertiesLengthBetween:()=>qM,isPatternReviver:()=>l00,isPattern:()=>z5,isNonEmpty:()=>WM,isMultipleOfReviver:()=>B10,isMultipleOf:()=>eE,isMinSizeReviver:()=>C10,isMinSize:()=>DM,isMinPropertiesReviver:()=>j10,isMinProperties:()=>VM,isMinLengthReviver:()=>A10,isMinLength:()=>YU,isMaxSizeReviver:()=>E10,isMaxSize:()=>NM,isMaxPropertiesReviver:()=>I10,isMaxProperties:()=>zM,isMaxLengthReviver:()=>P10,isMaxLength:()=>UM,isLowercasedReviver:()=>G10,isLowercased:()=>lE,isLessThanReviver:()=>U10,isLessThanOrEqualToReviver:()=>D10,isLessThanOrEqualToDateReviver:()=>M60,isLessThanOrEqualToDate:()=>JM,isLessThanOrEqualToBigIntReviver:()=>v60,isLessThanOrEqualToBigInt:()=>KM,isLessThanOrEqualToBigDecimal:()=>F10,isLessThanOrEqualTo:()=>tE,isLessThanDateReviver:()=>E60,isLessThanDate:()=>QM,isLessThanBigIntReviver:()=>S60,isLessThanBigInt:()=>_M,isLessThanBigDecimal:()=>T10,isLessThan:()=>aE,isLengthBetweenReviver:()=>w10,isLengthBetween:()=>QU,isIntReviver:()=>V10,isInt32:()=>z10,isInt:()=>Y7,isIncludesReviver:()=>J10,isIncludes:()=>uE,isGreaterThanReviver:()=>H10,isGreaterThanOrEqualToReviver:()=>W10,isGreaterThanOrEqualToDateReviver:()=>C60,isGreaterThanOrEqualToDate:()=>YM,isGreaterThanOrEqualToBigIntReviver:()=>x60,isGreaterThanOrEqualToBigInt:()=>ZM,isGreaterThanOrEqualToBigDecimal:()=>O10,isGreaterThanOrEqualTo:()=>XU,isGreaterThanDateReviver:()=>w60,isGreaterThanDate:()=>XM,isGreaterThanBigIntReviver:()=>I60,isGreaterThanBigInt:()=>GM,isGreaterThanBigDecimal:()=>L10,isGreaterThan:()=>sE,isGUIDReviver:()=>a00,isGUID:()=>hE,isFiniteReviver:()=>K10,isFinite:()=>rE,isEndsWithReviver:()=>Q10,isEndsWith:()=>pE,isCapitalizedReviver:()=>Z10,isCapitalized:()=>oE,isBetweenReviver:()=>N10,isBetweenDateReviver:()=>j60,isBetweenDate:()=>$M,isBetweenBigIntReviver:()=>k60,isBetweenBigInt:()=>HM,isBetweenBigDecimal:()=>R10,isBetween:()=>s$,isBase64UrlReviver:()=>X10,isBase64Url:()=>fE,isBase64Reviver:()=>e00,isBase64:()=>eW,is:()=>GE,instanceOf:()=>U4,fromURLSearchParams:()=>jX0,fromJsonString:()=>uM,fromFormData:()=>EX0,fromBrand:()=>S00,flip:()=>dW,fieldsAssign:()=>T00,extendTo:()=>A00,encodeUnknownSync:()=>LE,encodeUnknownResult:()=>zE,encodeUnknownPromise:()=>qE,encodeUnknownOption:()=>Q00,encodeUnknownExit:()=>VE,encodeUnknownEffect:()=>c$,encodeTo:()=>nW,encodeSync:()=>Z00,encodeResult:()=>$00,encodePromise:()=>G00,encodeOption:()=>J00,encodeKeys:()=>R00,encodeExit:()=>Y00,encodeEffect:()=>BE,encode:()=>g00,decodeUnknownSync:()=>NE,decodeUnknownResult:()=>UE,decodeUnknownPromise:()=>DE,decodeUnknownOption:()=>se,decodeUnknownExit:()=>HE,decodeUnknownEffect:()=>u$,decodeTo:()=>l,decodeSync:()=>X00,decodeResult:()=>te,decodePromise:()=>ee,decodeOption:()=>ae,decodeExit:()=>ne,decodeEffect:()=>re,decode:()=>b00,declareConstructor:()=>qX,declare:()=>SX,check:()=>I00,catchEncodingWithContext:()=>IE,catchEncoding:()=>k00,catchDecodingWithContext:()=>jE,catchDecoding:()=>v00,brand:()=>EE,asserts:()=>ie,annotateKey:()=>ue,annotateEncoded:()=>pe,annotate:()=>de,Void:()=>q00,UnknownFromJsonString:()=>PX0,Unknown:()=>cW,UniqueSymbol:()=>O00,UniqueArray:()=>M00,Union:()=>J1,UndefinedOr:()=>r$,Undefined:()=>lW,Uint8ArrayReviver:()=>fX0,Uint8ArrayFromHex:()=>uX0,Uint8ArrayFromBase64Url:()=>pX0,Uint8ArrayFromBase64:()=>dX0,Uint8Array:()=>J7,URLSearchParamsReviver:()=>MX0,URLSearchParams:()=>UU,URLReviver:()=>_X0,URLFromString:()=>KX0,URL:()=>ZU,TupleWithRest:()=>w00,Tuple:()=>k9,Trimmed:()=>cM,Trim:()=>vX0,Tree:()=>f60,TimeZoneReviver:()=>aX0,TimeZoneOffsetReviver:()=>rX0,TimeZoneOffset:()=>oM,TimeZoneNamedReviver:()=>nX0,TimeZoneNamedFromString:()=>sX0,TimeZoneNamed:()=>DU,TimeZoneFromString:()=>tX0,TimeZone:()=>NU,TemplateLiteralParser:()=>N00,TemplateLiteral:()=>D00,TaggedUnion:()=>f00,TaggedStruct:()=>n$,TaggedErrorClass:()=>G60,TaggedClass:()=>$60,Symbol:()=>FE,StructWithRest:()=>P00,Struct:()=>h,StringFromUriComponent:()=>yX0,StringFromHex:()=>gX0,StringFromBase64Url:()=>bX0,StringFromBase64:()=>kX0,String:()=>r,StandardSchemaV1FailureResult:()=>hX0,SchemaError:()=>Y4,ResultReviver:()=>u10,Result:()=>OM,RegExpReviver:()=>ZX0,RegExp:()=>yM,RedactedReviver:()=>o10,RedactedFromValue:()=>i10,Redacted:()=>$U,Record:()=>RE,ReadonlySetReviver:()=>JX0,ReadonlySet:()=>kM,ReadonlyMapReviver:()=>YX0,ReadonlyMap:()=>SM,PropertyKey:()=>uW,OptionReviver:()=>g10,OptionFromUndefinedOr:()=>h10,OptionFromOptionalNullOr:()=>p10,OptionFromOptionalKey:()=>f10,OptionFromOptional:()=>d10,OptionFromNullishOr:()=>m10,OptionFromNullOr:()=>y10,Option:()=>D4,Opaque:()=>d00,ObjectKeyword:()=>L00,NumberFromString:()=>IX0,Number:()=>o$,NullishOr:()=>wE,NullOr:()=>iW,Null:()=>T0,NonEmptyString:()=>k10,NonEmptyArray:()=>C00,Never:()=>V00,Natural:()=>zX,MutableJsonReviver:()=>u60,MutableJson:()=>Uj,Literals:()=>i$,Literal:()=>c0,JsonReviver:()=>d60,Json:()=>e$,Int:()=>q5,HashSetReviver:()=>$X0,HashSet:()=>bM,HashMapReviver:()=>QX0,HashMap:()=>vM,FormDataReviver:()=>CX0,FormData:()=>WU,FiniteFromString:()=>xX0,Finite:()=>Q6,FileReviver:()=>wX0,File:()=>HU,ExitReviver:()=>XX0,Exit:()=>jM,ErrorReviver:()=>t10,ErrorClass:()=>tM,Error:()=>MM,Enum:()=>B00,DurationReviver:()=>DX0,DurationFromString:()=>BX0,DurationFromNanos:()=>VX0,DurationFromMillis:()=>zX0,Duration:()=>Q7,Defect:()=>e10,DateTimeZonedReviver:()=>eX0,DateTimeZonedFromString:()=>X60,DateTimeZoned:()=>BU,DateTimeUtcReviver:()=>cX0,DateTimeUtcFromString:()=>oX0,DateTimeUtcFromMillis:()=>iX0,DateTimeUtcFromDate:()=>lX0,DateTimeUtc:()=>$7,DateReviver:()=>HX0,DateFromString:()=>WX0,DateFromMillis:()=>UX0,Date:()=>J6,Class:()=>aM,ChunkReviver:()=>GX0,Chunk:()=>gM,Char:()=>b10,CauseReviver:()=>n10,CauseReasonReviver:()=>r10,CauseReason:()=>f$,Cause:()=>d$,BooleanFromBit:()=>mX0,Boolean:()=>TE,BigIntFromString:()=>SX0,BigInt:()=>j6,BigDecimalReviver:()=>FX0,BigDecimalFromString:()=>RX0,BigDecimal:()=>KU,ArrayEnsure:()=>E00,Array:()=>Q1,Any:()=>z00});var nL=/^[+-]?\d+$/,u_="~effect/BigDecimal",Ip={[u_]:u_,[D0](){let X=c_(this);return G1(X0(X.value),h6(X.scale))},[N0](X){return HJ(X)&&gp(this,X)},toString(){return`BigDecimal(${A6(this)})`},toJSON(){return{_id:"BigDecimal",value:String(this.value),scale:this.scale}},[U1](){return this.toJSON()},pipe(){return G0(this,arguments)}},HJ=(X)=>j(X,u_),e1=(X,Y)=>{let Q=Object.create(Ip);return Q.value=X,Q.scale=Y,Q},aL=(X,Y)=>{if(X!==UX&&X%KJ===UX)throw RangeError("Value must be normalized");let Q=e1(X,Y);return Q.normalized=Q,Q},UX=BigInt(0),xp=BigInt(1),Sp=BigInt(-1);var KJ=BigInt(10),tL=aL(UX,0);var c_=(X)=>{if(X.normalized===void 0)if(X.value===UX)X.normalized=tL;else{let Y=`${X.value}`,Q=0;for(let G=Y.length-1;G>=0;G--)if(Y[G]==="0")Q++;else break;if(Q===0)X.normalized=X;let J=BigInt(Y.substring(0,Y.length-Q)),$=X.scale-Q;X.normalized=aL(J,$)}return X.normalized},l8=V(2,(X,Y)=>{if(Y>X.scale)return e1(X.value*KJ**BigInt(Y-X.scale),Y);if(Y<X.scale)return e1(X.value/KJ**BigInt(X.scale-Y),Y);return X}),eL=V(2,(X,Y)=>{if(Y.value===UX)return X;if(X.value===UX)return Y;if(X.scale>Y.scale)return e1(l8(Y,X.scale).value+X.value,X.scale);if(X.scale<Y.scale)return e1(l8(X,Y.scale).value+Y.value,Y.scale);return e1(X.value+Y.value,X.scale)});var Z8=C4((X,Y)=>{let Q=L1(sL(X),sL(Y));if(Q!==0)return Q;if(X.scale>Y.scale)return AX(X.value,l8(Y,X.scale).value);if(X.scale<Y.scale)return AX(l8(X,Y.scale).value,Y.value);return AX(X.value,Y.value)}),vp=x5(Z8);var kp=M8(Z8);var sL=(X)=>X.value===UX?0:X.value<UX?-1:1,bp=(X)=>X.value<UX?e1(-X.value,X.scale):X;var l_=D1((X,Y)=>{if(X.scale>Y.scale)return l8(Y,X.scale).value===X.value;if(X.scale<Y.scale)return l8(X,Y.scale).value===Y.value;return X.value===Y.value}),gp=V(2,(X,Y)=>l_(X,Y));var XO=(X)=>{if(X==="")return T(tL);let Y,Q,J=X.search(/[eE]/);if(J!==-1){let H=X.slice(J+1);if(Y=X.slice(0,J),Q=Number(H),Y===""||!Number.isSafeInteger(Q)||!nL.test(H))return d()}else Y=X,Q=0;let $,G,_=Y.search(/\./);if(_!==-1){let H=Y.slice(0,_),W=Y.slice(_+1);$=`${H}${W}`,G=W.length}else $=Y,G=0;if(!nL.test($))return d();let K=G-Q;if(!Number.isSafeInteger(K))return d();return T(e1(BigInt($),K))};var A6=(X)=>{let Y=c_(X);if(Math.abs(Y.scale)>=16)return yp(Y);let Q=Y.value<UX,J=Q?`${Y.value}`.substring(1):`${Y.value}`,$,G;if(Y.scale>=J.length)$="0",G="0".repeat(Y.scale-J.length)+J;else{let K=J.length-Y.scale;if(K>J.length){let H=K-J.length;$=`${J}${"0".repeat(H)}`,G=""}else G=J.slice(K),$=J.slice(0,K)}let _=G===""?$:`${$}.${G}`;return Q?`-${_}`:_},yp=(X)=>{if(hp(X))return"0e+0";let Y=c_(X),Q=`${bp(Y).value}`,J=Q.slice(0,1),$=Q.slice(1),G=`${YO(Y)?"-":""}${J}`;if($!=="")G+=`.${$}`;let _=$.length-Y.scale;return`${G}e${_>=0?"+":""}${_}`};var hp=(X)=>X.value===UX,YO=(X)=>X.value<UX,mp=(X)=>X.value>UX,o_=(X)=>HJ(X[0]);var QO=V(o_,(X,Y=0)=>{if(X.scale<=Y)return X;return e1(X.value/KJ**BigInt(X.scale-Y),Y)}),i_=V(o_,(X,Y=0)=>{let Q=QO(X,Y);if(mp(X)&&vp(Q,X))return eL(Q,e1(xp,Y));return Q});var r_=V(o_,(X,Y=0)=>{let Q=QO(X,Y);if(YO(X)&&kp(Q,X))return eL(Q,e1(Sp,Y));return Q});var $O="~effect/collections/Chunk";function fp(X,Y,Q,J,$){for(let G=Y;G<Math.min(X.length,Y+$);G++)Q[J+G-Y]=X[G];return Q}var GO=[],s_=(X)=>D1((Y,Q)=>Y.length===Q.length&&JQ(Y).every((J,$)=>X(J,$Q(Q,$)))),dp=s_(o),pp={[$O]:{_A:(X)=>X},toString(){return`Chunk(${P(JQ(this))})`},toJSON(){return{_id:"Chunk",values:A1(JQ(this))}},[U1](){return this.toJSON()},[N0](X){return WJ(X)&&dp(this,X)},[D0](){return e9(JQ(this))},[Symbol.iterator](){switch(this.backing._tag){case"IArray":return this.backing.array[Symbol.iterator]();case"IEmpty":return GO[Symbol.iterator]();default:return JQ(this)[Symbol.iterator]()}},pipe(){return G0(this,arguments)}},a_=(X)=>{let Y=Object.create(pp);switch(Y.backing=X,X._tag){case"IEmpty":{Y.length=0,Y.depth=0,Y.left=Y,Y.right=Y;break}case"IConcat":{Y.length=X.left.length+X.right.length,Y.depth=1+Math.max(X.left.depth,X.right.depth),Y.left=X.left,Y.right=X.right;break}case"IArray":{Y.length=X.array.length,Y.depth=0,Y.left=_8,Y.right=_8;break}case"ISingleton":{Y.length=1,Y.depth=0,Y.left=_8,Y.right=_8;break}case"ISlice":{Y.length=X.length,Y.depth=X.chunk.depth+1,Y.left=_8,Y.right=_8;break}}return Y},WJ=(X)=>j(X,$O),_8=a_({_tag:"IEmpty"}),up=()=>_8;var cp=(X)=>a_({_tag:"ISingleton",a:X}),UJ=(X)=>WJ(X)?X:op(C1(X)),n_=(X,Y,Q)=>{switch(X.backing._tag){case"IArray":{fp(X.backing.array,0,Y,Q,X.length);break}case"IConcat":{n_(X.left,Y,Q),n_(X.right,Y,Q+X.left.length);break}case"ISingleton":{Y[Q]=X.backing.a;break}case"ISlice":{let J=0,$=Q;while(J<X.length)Y[$]=$Q(X,J),J+=1,$+=1;break}}};var lp=(X)=>{switch(X.backing._tag){case"IEmpty":return GO;case"IArray":return X.backing.array;default:{let Y=Array(X.length);return n_(X,Y,0),X.backing={_tag:"IArray",array:Y},X.left=_8,X.right=_8,X.depth=0,Y}}},JQ=lp;var op=(X)=>X.length===0?up():X.length===1?cp(X[0]):a_({_tag:"IArray",array:X});var $Q=V(2,(X,Y)=>{let Q=Math.floor(Y);switch(X.backing._tag){case"IEmpty":throw Error(`Index out of bounds: ${Q}`);case"ISingleton":{if(Y!==0)throw Error(`Index out of bounds: ${Q}`);return X.backing.a}case"IArray":{if(Q>=X.length||Q<0)throw Error(`Index out of bounds: ${Q}`);return X.backing.array[Q]}case"IConcat":return Q<X.left.length?$Q(X.left,Q):$Q(X.right,Q-X.left.length);case"ISlice":return $Q(X.backing.chunk,Q+X.backing.offset)}});var ZO=(X)=>X.length;var t_=X9,_O=u4,KO=Nq,HO=Bq,WO=Vq,UO=t2,e_=zq,XK=qq;var DO=e5;var NO=Y_;var DJ=Lq,BO=Oq;var NJ=Tq;var YK=Q_,GQ=bY,VO=J_;var zO=$_,o8=Fq;var BJ=gY;var qO=__;var LO=Aq;var VJ=H_;var OO="~effect/encoding/EncodingError";class i8 extends DY("EncodingError"){[OO]=OO}var qJ=(X)=>typeof X==="string"?JK(ZK.encode(X)):JK(X),K9=(X)=>{let Y=jO(X),Q=Y.length;if(Q%4!==0)return c(new i8({kind:"Decode",module:"Base64",input:Y,message:`Length must be a multiple of 4, but is ${Q}`}));let J=Y.indexOf("=");if(J!==-1&&(J<Q-2||J===Q-2&&Y[Q-1]!=="="))return c(new i8({kind:"Decode",module:"Base64",input:Y,message:"Found a '=' character, but it is not at the end"}));try{let $=Y.endsWith("==")?2:Y.endsWith("=")?1:0,G=new Uint8Array(3*(Q/4)-$);for(let _=0,K=0;_<Q;_+=4,K+=3){let H=zJ(Y.charCodeAt(_))<<18|zJ(Y.charCodeAt(_+1))<<12|zJ(Y.charCodeAt(_+2))<<6|zJ(Y.charCodeAt(_+3));G[K]=H>>16,G[K+1]=H>>8&255,G[K+2]=H&255}return m(G)}catch($){return c(new i8({kind:"Decode",module:"Base64",input:Y,message:$ instanceof Error?$.message:"Invalid input"}))}},PO=(X)=>_X(K9(X),(Y)=>_K.decode(Y)),wO=(X)=>typeof X==="string"?FO(ZK.encode(X)):FO(X),$K=(X)=>{let Y=jO(X),Q=Y.length;if(Q%4===1)return c(new i8({module:"Base64Url",kind:"Decode",input:Y,message:`Length should be a multiple of 4, but is ${Q}`}));if(!/^[-_A-Z0-9]*?={0,2}$/i.test(Y))return c(new i8({module:"Base64Url",kind:"Decode",input:Y,message:"Invalid input"}));let J=Q%4===2?`${Y}==`:Q%4===3?`${Y}=`:Y;return J=J.replace(/-/g,"+").replace(/_/g,"/"),K9(J)},CO=(X)=>_X($K(X),(Y)=>_K.decode(Y)),EO=(X)=>typeof X==="string"?RO(ZK.encode(X)):RO(X),GK=(X)=>{let Y=new TextEncoder().encode(X);if(Y.length%2!==0)return c(new i8({module:"Hex",kind:"Decode",input:X,message:`Length must be a multiple of 2, but is ${Y.length}`}));try{let Q=Y.length/2,J=new Uint8Array(Q);for(let $=0;$<Q;$++){let G=AO(Y[$*2]),_=AO(Y[$*2+1]);J[$]=G<<4|_}return m(J)}catch(Q){return c(new i8({module:"Hex",kind:"Decode",input:X,message:Q instanceof Error?Q.message:"Invalid input"}))}},MO=(X)=>_X(GK(X),(Y)=>_K.decode(Y)),ZK=new TextEncoder,_K=new TextDecoder,jO=(X)=>X.replace(/[\n\r]/g,""),JK=(X)=>{let Y=X.length,Q="",J;for(J=2;J<Y;J+=3)Q+=K8[X[J-2]>>2],Q+=K8[(X[J-2]&3)<<4|X[J-1]>>4],Q+=K8[(X[J-1]&15)<<2|X[J]>>6],Q+=K8[X[J]&63];if(J===Y+1)Q+=K8[X[J-2]>>2],Q+=K8[(X[J-2]&3)<<4],Q+="==";if(J===Y)Q+=K8[X[J-2]>>2],Q+=K8[(X[J-2]&3)<<4|X[J-1]>>4],Q+=K8[(X[J-1]&15)<<2],Q+="=";return Q};function zJ(X){if(X>=TO.length)throw TypeError(`Invalid character ${String.fromCharCode(X)}`);let Y=TO[X];if(Y===255)throw TypeError(`Invalid character ${String.fromCharCode(X)}`);return Y}var K8=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","0","1","2","3","4","5","6","7","8","9","+","/"],TO=[255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,62,255,255,255,63,52,53,54,55,56,57,58,59,60,61,255,255,255,0,255,255,255,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,255,255,255,255,255,255,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51],FO=(X)=>JK(X).replace(/=/g,"").replace(/\+/g,"-").replace(/\//g,"_"),RO=(X)=>{let Y="";for(let Q=0;Q<X.length;++Q)Y+=rp[X[Q]];return Y},AO=(X)=>{if(48<=X&&X<=57)return X-48;if(97<=X&&X<=102)return X-97+10;if(65<=X&&X<=70)return X-65+10;throw TypeError("Invalid input")},rp=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];function H8(X){return X.checks?X.checks[X.checks.length-1].annotations:X.annotations}function ZQ(X){return(Y)=>H8(Y)?.[X]}var XX="~structural",_Q="~identifier",KQ="~sentinels",xO=["title","description","default","examples","readOnly","writeOnly","format","contentEncoding","contentMediaType","contentSchema"],r8=ZQ("identifier"),LJ=ZQ(_Q),KK=ZQ("title");var SO=ZQ("brands"),OJ=X1((X)=>{let Y=r8(X);if(typeof Y==="string")return Y;return X.getExpected(OJ)});var vO=new Set([KQ,XX,"representation","arbitrary","brands","toJsonSchema","toCode","toArbitrary","toEquivalence","toFormatter","toCodec","toCodecJson","toCodecStringTree","toCodecIso"]);var e4=new WeakMap,kO=(X)=>{if(e4.has(X))return e4.get(X);else throw Error("Unable to get redacted value"+(X.label?` with label: "${X.label}"`:""))};var bO="~effect/data/Redacted",HK=(X)=>j(X,bO),P6=(X,Y)=>{let Q=Object.create(sp);if(Y?.label)Q.label=Y.label;return e4.set(Q,X),Q},sp={[bO]:{_A:(X)=>X},label:void 0,...f6,toJSON(){return this.toString()},toString(){return`<redacted${gX(this.label)?":"+this.label:""}>`},[D0](){return X0(e4.get(this))},[N0](X){return HK(X)&&o(e4.get(this),e4.get(X))}},H9=kO;var gO=(X)=>D1((Y,Q)=>X(H9(Y),H9(Q)));var WQ="~effect/SchemaIssue/Issue";function DK(X){return j(X,WQ)&&X[WQ]===WQ}class CX{[WQ]=WQ;toString(){return tp(this)}}class FJ extends CX{_tag="Filter";actual;filter;issue;constructor(X,Y,Q){super();this.actual=X,this.filter=Y,this.issue=Q}}class NK extends CX{_tag="Encoding";ast;actual;issue;constructor(X,Y,Q){super();this.ast=X,this.actual=Y,this.issue=Q}}class S0 extends CX{_tag="Pointer";path;issue;constructor(X,Y){super();this.path=X,this.issue=Y}}class DQ extends CX{_tag="MissingKey";annotations;constructor(X){super();this.annotations=X}}class RJ extends CX{_tag="UnexpectedKey";ast;actual;constructor(X,Y){super();this.ast=X,this.actual=Y}}class F0 extends CX{_tag="Composite";ast;actual;issues;constructor(X,Y,Q){super();this.ast=X,this.actual=Y,this.issues=Q}}class r0 extends CX{_tag="InvalidType";ast;actual;constructor(X,Y){super();this.ast=X,this.actual=Y}}class U0 extends CX{_tag="InvalidValue";actual;annotations;constructor(X,Y){super();this.actual=X,this.annotations=Y}}class W9 extends CX{_tag="Forbidden";actual;annotations;constructor(X,Y){super();this.actual=X,this.annotations=Y}}class AJ extends CX{_tag="AnyOf";ast;actual;issues;constructor(X,Y,Q){super();this.ast=X,this.actual=Y,this.issues=Q}}class BK extends CX{_tag="OneOf";ast;actual;successes;constructor(X,Y,Q){super();this.ast=X,this.actual=Y,this.successes=Q}}function WK(X,Y){if(DK(Y))return Y;if(typeof Y==="string")return new U0(T(X),{message:Y});let Q=typeof Y.issue==="string"?new U0(T(X),{message:Y.issue}):Y.issue;return new S0(Y.path,Q)}function mO(X,Y){if(Y===void 0)return;if(typeof Y==="boolean")return Y?void 0:new U0(T(X));return WK(X,Y)}function fO(X,Y,Q){if(Array.isArray(Q)){if(k8(Q)){if(Q.length===1)return WK(X,Q[0]);return new F0(Y,T(X),V6(Q,(J)=>WK(X,J)))}return}return mO(X,Q)}var dO=(X)=>{let Y=UQ(X);if(Y!==void 0)return Y;switch(X._tag){case"InvalidType":return UK(OJ(X.ast),hO(X.actual));case"InvalidValue":return`Invalid data ${hO(X.actual)}`;case"MissingKey":return"Missing key";case"UnexpectedKey":return`Unexpected key with value ${P(X.actual)}`;case"Forbidden":return"Forbidden operation";case"OneOf":return`Expected exactly one member to match the input ${P(X.actual)}`}},pO=(X)=>{return UQ(X.issue)??UQ(X)};function uO(X){return(Y)=>({issues:X5(Y,[],X?.leafHook??dO,X?.checkHook??pO)})}function UK(X,Y){return`Expected ${X}, got ${Y}`}function X5(X,Y,Q,J){switch(X._tag){case"Filter":{let $=J(X);if($!==void 0)return[{path:Y,message:$}];switch(X.issue._tag){case"InvalidValue":return[{path:Y,message:UK(cO(X.filter),P(X.actual))}];default:return X5(X.issue,Y,Q,J)}}case"Encoding":return X5(X.issue,Y,Q,J);case"Pointer":return X5(X.issue,[...Y,...X.path],Q,J);case"Composite":return X.issues.flatMap(($)=>X5($,Y,Q,J));case"AnyOf":{let $=UQ(X);if(X.issues.length===0){if($!==void 0)return[{path:Y,message:$}];let G=UK(OJ(X.ast),P(X.actual));return[{path:Y,message:G}]}return X.issues.flatMap((G)=>X5(G,Y,Q,J))}default:return[{path:Y,message:Q(X)}]}}function cO(X){let Y=X.annotations?.expected;if(typeof Y==="string")return Y;switch(X._tag){case"Filter":return"<filter>";case"FilterGroup":return X.checks.map((Q)=>cO(Q)).join(" & ")}}function ap(){return(X)=>X5(X,[],dO,pO).map(ep).join(`
`)}var tp=ap();function ep(X){let Y=X.message;if(X.path&&X.path.length>0){let Q=v7(X.path);Y+=`
  at ${Q}`}return Y}function UQ(X){switch(X._tag){case"InvalidType":case"OneOf":case"Composite":case"AnyOf":return HQ(X.ast.annotations);case"InvalidValue":case"Forbidden":return HQ(X.annotations);case"MissingKey":return HQ(X.annotations,"messageMissingKey");case"UnexpectedKey":return HQ(X.ast.annotations,"messageUnexpectedKey");case"Filter":return HQ(X.filter.annotations);case"Encoding":return UQ(X.issue)}}function HQ(X,Y="message"){let Q=X?.[Y];if(typeof Q==="string")return Q}function hO(X){if(P0(X))return"no value provided";return P(X.value)}function TJ(X){switch(X._tag){case"MissingKey":return X;case"Forbidden":return new W9(i6(X.actual,P6),X.annotations);case"Filter":return new FJ(P6(X.actual),X.filter,TJ(X.issue));case"Pointer":return new S0(X.path,TJ(X.issue));case"Encoding":case"InvalidType":case"InvalidValue":case"Composite":return new U0(i6(X.actual,P6));case"AnyOf":case"OneOf":case"UnexpectedKey":return new U0(T(P6(X.actual)))}}function PJ(X){let Y;for(let Q of X.reasons){if(!p3(Q)||!DK(Q.error))return;Y??=Q.error}return Y}function W8(X,Y){let Q=PJ(X);if(Q===void 0)throw Error(Y,{cause:X});return Q}class U8 extends O4{run;constructor(X){super();this.run=X}map(X){return new U8((Y,Q)=>this.run(Y,Q).pipe(r4(i6(X))))}compose(X){if(oO(this))return X;if(oO(X))return this;return new U8((Y,Q)=>this.run(Y,Q).pipe(wX((J)=>X.run(J,Q))))}}function Xu(X){return new U8((Y)=>f(X(Y)))}function VK(X){return Xu((Y)=>new W9(Y,{message:X(Y)}))}var iO=new U8(p);function oO(X){return X.run===iO.run}function cX(){return iO}function zK(X){return new U8((Y,Q)=>P0(Y)?pX:X(Y.value,Q))}function Q0(X){return wJ(i6(X))}function YX(X){return zK((Y,Q)=>X(Y,Q).pipe(r4(T)))}function wJ(X){return new U8((Y)=>p(X(Y)))}function qK(){return new U8(()=>pX)}function NQ(X){return new U8((Y)=>{let Q=k5(Y,V1);return N1(Q)?p(Q):r4(X,T)})}function Y5(){return Q0(globalThis.String)}function CJ(){return Q0(globalThis.Number)}function rO(){return Q0(globalThis.BigInt)}function LK(){return Q0((X)=>new globalThis.Date(X))}function nO(){return Q0(Mq)}function sO(X){return zK((Y)=>J9({try:()=>T(JSON.parse(Y,X?.reviver)),catch:(Q)=>new U0(T(Y),{message:globalThis.String(Q)})}))}function aO(X){return zK((Y)=>J9({try:()=>{let Q=JSON.stringify(Y,X?.replacer,X?.space);if(Q===void 0)throw TypeError("Value cannot be represented as JSON");return T(Q)},catch:(Q)=>new U0(T(Y),{message:globalThis.String(Q)})}))}function OK(){return Q0(qJ)}function EJ(){return Q0(wO)}function MJ(){return Q0(EO)}function tO(){return YX((X)=>$9(R_(K9(X)),(Y)=>new U0(T(X),{message:Y.message})))}function eO(){return YX((X)=>r1(PO(X),{onFailure:(Y)=>f(new U0(T(X),{message:Y.message})),onSuccess:p}))}function XT(){return YX((X)=>r1($K(X),{onFailure:(Y)=>f(new U0(T(X),{message:Y.message})),onSuccess:p}))}function YT(){return YX((X)=>r1(CO(X),{onFailure:(Y)=>f(new U0(T(X),{message:Y.message})),onSuccess:p}))}function QT(){return YX((X)=>r1(GK(X),{onFailure:(Y)=>f(new U0(T(X),{message:Y.message})),onSuccess:p}))}function JT(){return YX((X)=>r1(MO(X),{onFailure:(Y)=>f(new U0(T(X),{message:Y.message})),onSuccess:p}))}function $T(){return Q0(encodeURIComponent)}function GT(){return YX((X)=>{try{return p(globalThis.decodeURIComponent(X))}catch(Y){return f(new U0(T(X),{message:Y instanceof URIError?Y.message:"Invalid URI component"}))}})}function TK(){return YX((X)=>{return yX(DJ(X),{onNone:()=>f(new U0(T(X),{message:"Invalid DateTime input"})),onSome:(Y)=>p(NJ(Y))})})}function ZT(){return Q0((X)=>WT(Array.from(X.entries())))}var Yu=UT((X)=>typeof X==="string"||typeof Blob<"u"&&X instanceof Blob);function _T(){return Q0((X)=>{let Y=new FormData;if(typeof X==="object"&&X!==null)Yu(X).forEach(([J,$])=>{Y.append(J,$)});return Y})}function KT(){return Q0((X)=>WT(Array.from(X.entries())))}var Qu=UT(gX);function HT(){return Q0((X)=>{if(typeof X==="object"&&X!==null)return new URLSearchParams(Qu(X));return new URLSearchParams})}var Ju=/^\d+$/;function $u(X){if(X==="")return[""];let Y=X.replace(/\[(.*?)\]/g,".$1"),Q=Y.split("."),J=Y.startsWith(".")?1:0;return Q.slice(J).map(($)=>Ju.test($)?globalThis.Number($):$)}function WT(X){let Y={},Q=new WeakSet;function J($,G,_){let K=Object.hasOwn($,G)?$[G]:void 0;if(Q.has(K)&&Array.isArray(K)===_)return K;let H=_?[]:{};return Q.add(H),k($,G,H),H}return X.forEach(([$,G])=>{let _=$u($),K=Y;_.forEach((H,W)=>{let D=W===_.length-1;if(Array.isArray(K)&&H==="")if(D)K.push(G);else{let U=_[W+1],N=typeof U==="number"||U==="",B=K.length;K=J(K,B,N)}else if(D){let U=Object.hasOwn(K,H);if(U&&Array.isArray(K[H]))K[H].push(G);else if(U)k(K,H,[K[H],G]);else k(K,H,G)}else{let U=_[W+1];K=J(K,H,typeof U==="number"||U==="")}})}),Y}function UT(X){return(Y)=>{let Q=[];function J($,G){if(X(G))Q.push([$,G]);else if(Array.isArray(G))if(G.every(X))G.forEach((K)=>{Q.push([$,K])});else G.forEach((K,H)=>{J(`${$}[${H}]`,K)});else if(typeof G==="object"&&G!==null)for(let[_,K]of Object.entries(G))J(`${$}[${_}]`,K)}for(let[$,G]of Object.entries(Y))J($,G);return Q}}class VQ{_tag="Middleware";decode;encode;constructor(X,Y){this.decode=X,this.encode=Y}flip(){return new VQ(this.encode,this.decode)}}var BQ="~effect/SchemaTransformation/Transformation";class q0{[BQ]=BQ;_tag="Transformation";decode;encode;constructor(X,Y){this.decode=X,this.encode=Y}flip(){return new q0(this.encode,this.decode)}compose(X){return new q0(this.decode.compose(X.decode),X.encode.compose(this.encode))}}function Gu(X){return j(X,BQ)&&X[BQ]===BQ}var jJ=(X)=>{if(Gu(X))return X;return new q0(X.decode,X.encode)};function EX(X){return new q0(YX(X.decode),YX(X.encode))}function d0(X){return new q0(Q0(X.decode),Q0(X.encode))}function IJ(X){return new q0(wJ(X.decode),wJ(X.encode))}function DT(){return new q0(nO(),cX())}var Zu=new q0(cX(),cX());function D9(){return Zu}var N9=new q0(CJ(),Y5()),xJ=new q0(rO(),Y5()),RK=new q0(LK(),Q0(JZ)),NT=new q0(LK(),Q0((X)=>X.getTime())),BT=EX({decode:(X)=>yX(gN(X),{onNone:()=>f(new U0(T(X),{message:`Invalid Duration string: ${X}`})),onSome:p}),encode:(X)=>p(globalThis.String(X))}),VT=EX({decode:(X)=>p(N6(X)),encode:(X)=>yX(yN(X),{onNone:()=>f(new U0(T(X),{message:`Unable to encode ${X} into a bigint`})),onSome:(Y)=>p(Y)})}),zT=d0({decode:(X)=>I8(X),encode:(X)=>x8(X)}),_u=(X)=>x1(X)&&typeof X.message==="string",qT=(X)=>{let Q=Object.hasOwn(X,"cause")?Error(X.message,{cause:OT(X.cause)}):Error(X.message);if(typeof X.name==="string"&&X.name!=="Error")Q.name=X.name;if(typeof X.stack==="string")Q.stack=X.stack;return Q},Ku=(X)=>{try{let Y=F4(X);return Y===void 0?P(X):JSON.parse(Y)}catch{return P(X)}},Hu=(X,Y,Q)=>{let J={name:X.name,message:typeof X.message==="string"?X.message:""};if(Y?.includeStack&&typeof X.stack==="string")J.stack=X.stack;if(!Y?.excludeCause&&X.cause!==void 0)J.cause=Q(X.cause);return J},LT=(X)=>{let Y=new WeakSet,Q=(J)=>{if(XN(J)){if(Y.has(J))return"[Circular]";Y.add(J);let $=Hu(J,X,Q);return Y.delete(J),$}return Ku(J)};return Q},OT=(X)=>_u(X)?qT(X):X,TT=(X)=>d0({decode:qT,encode:(Y)=>LT(X)(Y)}),FT=(X)=>d0({decode:OT,encode:LT(X)});function RT(){return d0({decode:jN,encode:DZ})}function AT(){return d0({decode:MN,encode:M4})}function PT(X){return d0({decode:EN,encode:X?.onNoneEncoding===null?DZ:M4})}function wT(){return IJ({decode:T,encode:v5})}function CT(){return IJ({decode:(X)=>X.pipe(k5(V1),T),encode:v5})}var AK=EX({decode:(X)=>URL.canParse(X)?p(new URL(X)):f(new U0(T(X),{message:`Invalid URL string: ${X}`})),encode:(X)=>p(X.href)}),PK=EX({decode:(X)=>{let Y=XO(X);return P0(Y)?f(new U0(T(X),{message:`Invalid BigDecimal string: ${X}`})):p(Y.value)},encode:(X)=>p(A6(X))}),wK=new q0(tO(),OK()),ET=new q0(eO(),OK()),MT=new q0(YT(),EJ()),jT=new q0(JT(),MJ()),IT=new q0(GT(),$T()),xT=new q0(sO(),aO()),ST=new q0(ZT(),_T()),vT=new q0(KT(),HT()),kT=d0({decode:(X)=>GQ(X),encode:(X)=>X.offset}),CK=EX({decode:(X)=>{return yX(VO(X),{onNone:()=>f(new U0(T(X),{message:`Invalid IANA time zone: ${X}`})),onSome:p})},encode:(X)=>p(X.id)}),EK=EX({decode:(X)=>{return yX(zO(X),{onNone:()=>f(new U0(T(X),{message:`Invalid time zone: ${X}`})),onSome:p})},encode:(X)=>p(o8(X))}),MK=EX({decode:(X)=>{return yX(DJ(X),{onNone:()=>f(new U0(T(X),{message:`Invalid UTC DateTime string: ${X}`})),onSome:(Y)=>p(NJ(Y))})},encode:(X)=>p(LO(X))}),jK=EX({decode:(X)=>{return yX(BO(X),{onNone:()=>f(new U0(T(X),{message:`Invalid Zoned DateTime string: ${X}`})),onSome:p})},encode:(X)=>p(VJ(X))});function J5(X){return(Y)=>Y._tag===X}var $5=J5("Declaration");var Wu=J5("Never");var SJ=J5("Literal"),Uu=J5("UniqueSymbol");var qQ=J5("Arrays"),bK=J5("Objects"),LQ=J5("Union");class p0{to;transformation;constructor(X,Y){this.to=X,this.transformation=Y}}var G5={};class oX{isOptional;isMutable;defaultValue;annotations;constructor(X,Y,Q=void 0,J=void 0){this.isOptional=X,this.isMutable=Y,this.defaultValue=Q,this.annotations=J}}var gT="~effect/Schema";class n0{[gT]=gT;annotations;checks;encoding;context;constructor(X=void 0,Y=void 0,Q=void 0,J=void 0){this.annotations=X,this.checks=Y,this.encoding=Q,this.context=J}toString(){return`<${this._tag}>`}}class Z5 extends n0{_tag="Declaration";typeParameters;run;encodingChecks;constructor(X,Y,Q,J,$,G,_){super(Q,J,$,G);this.typeParameters=X,this.run=Y,this.encodingChecks=_}getParser(){let X=this.run(this.typeParameters);return(Y,Q)=>{if(P0(Y))return pX;return r4(X(Y.value,this,Q),T)}}_rebuild(X,Y,Q){let J=B9(this.typeParameters,X);return J===this.typeParameters&&Y===this.checks&&Q===this.encodingChecks?this:new Z5(J,this.run,this.annotations,Y,void 0,this.context,Q)}recur(X){return this._rebuild(X,this.checks,this.encodingChecks)}flip(X){return this._rebuild(X,this.encodingChecks,this.checks)}getExpected(){let X=this.annotations?.expected;if(typeof X==="string")return X;return"<Declaration>"}}class uT extends n0{_tag="Null";getParser(){return iJ(this,null)}getExpected(){return"null"}}var gK=new uT;class cT extends n0{_tag="Undefined";getParser(){return iJ(this,void 0)}toCodecJson(){return R0(this,[lT])}getExpected(){return"undefined"}}var lT=new p0(gK,new q0(Q0(()=>{return}),Q0(()=>null))),oT=new cT;class iT extends n0{_tag="Void";getParser(){return Pu(void 0)}toCodecJson(){return R0(this,[lT])}getExpected(){return"void"}}var rT=new iT;class nT extends n0{_tag="Never";getParser(){return nX(this,eD)}getExpected(){return"never"}}var sT=new nT;class aT extends n0{_tag="Any";getParser(){return nX(this,oG)}getExpected(){return"any"}}var tT=new aT;class eT extends n0{_tag="Unknown";getParser(){return nX(this,oG)}getExpected(){return"unknown"}}var Q5=new eT;class XF extends n0{_tag="ObjectKeyword";getParser(){return nX(this,iG)}getExpected(){return"object | array | function"}}var YF=new XF;class yK extends n0{_tag="Enum";enums;constructor(X,Y,Q,J,$){super(Y,Q,J,$);this.enums=X}getParser(){let X=new Set(this.enums.map(([,Y])=>Y));return nX(this,(Y)=>X.has(Y))}toCodecStringTree(){if(this.enums.some(([X,Y])=>typeof Y==="number")){let X=Object.fromEntries(this.enums.map(([Y,Q])=>[globalThis.String(Q),Q]));return R0(this,[new p0(new QX(Object.keys(X).map((Y)=>new DX(Y)),"anyOf"),new q0(Q0((Y)=>X[Y]),Y5()))])}return this}getExpected(){return this.enums.map(([X,Y])=>JSON.stringify(Y)).join(" | ")}}function QF(X){switch(X._tag){case"String":case"Number":case"BigInt":return!0;case"Literal":case"TemplateLiteral":return X.checks===void 0;case"Union":return X.checks===void 0&&X.types.every(QF);default:return!1}}class hK extends n0{_tag="TemplateLiteral";parts;encodedParts;constructor(X,Y,Q,J,$){super(Y,Q,J,$);let G=[];for(let _ of X){let K=F1(_);if(QF(K))G.push(K);else throw Error(`Invalid TemplateLiteral part ${K._tag}`)}this.parts=X,this.encodedParts=G}getParser(X){let Y=X(this.asTemplateLiteralParser());return(Q,J)=>B1(Y(Q,J),{onSuccess:()=>Q,onFailure:($)=>new F0(this,Q,[$])})}getExpected(){return"string"}matchPart(X,Y){return pT(this.encodedParts,X,Y)===void 0?void 0:X}asTemplateLiteralParser(){let X=new iX(!1,this.parts.map(wF),[]);return oJ(s8,X,new q0(YX((Y,Q)=>{let J=pT(this.encodedParts,Y,Q);if(J!==void 0)return p(J);return f(new U0(T(Y),{message:`Expected a string matching template literal parts, got ${P(Y)}`}))}),Q0((Y)=>Y.join(""))))}}class mK extends n0{_tag="UniqueSymbol";symbol;constructor(X,Y,Q,J,$){super(Y,Q,J,$);this.symbol=X}getParser(){return iJ(this,this.symbol)}toCodecStringTree(){return R0(this,[MF])}getExpected(){return globalThis.String(this.symbol)}}class DX extends n0{_tag="Literal";literal;constructor(X,Y,Q,J,$){super(Y,Q,J,$);if(typeof X==="number"&&!globalThis.Number.isFinite(X))throw Error(`A numeric literal must be finite, got ${P(X)}`);this.literal=X}getParser(){return iJ(this,this.literal)}matchPart(X,Y){return X===globalThis.String(this.literal)?this.literal:void 0}toCodecJson(){return typeof this.literal==="bigint"?yT(this):this}toCodecStringTree(){return typeof this.literal==="string"?this:yT(this)}getExpected(){return typeof this.literal==="string"?JSON.stringify(this.literal):globalThis.String(this.literal)}}function yT(X){let Y=globalThis.String(X.literal);return R0(X,[new p0(new DX(Y),new q0(Q0(()=>X.literal),Q0(()=>Y)))])}class JF extends n0{_tag="String";getParser(){return nX(this,gX)}matchPart(X,Y){return rJ(this,X,Y)}getExpected(){return"string"}}var s8=new JF;class $F extends n0{_tag="Number";getParser(){return nX(this,t9)}matchKey(X,Y){return this._match(wu,X,Y)}matchPart(X,Y){return this._match(SK,X,Y)}_match(X,Y,Q){return X.test(Y)?rJ(this,globalThis.Number(Y),Q):void 0}toCodecJson(){if(this.checks&&(IK(this.checks,"effect/schema/isFinite")||IK(this.checks,"effect/schema/isInt")))return this;return R0(this,[Du(this.checks)])}toCodecStringTree(){if(this.toCodecJson()===this)return R0(this,[Cu]);return R0(this,[Eu])}getExpected(){return"number"}}function IK(X,Y){return X.some((Q)=>Q.annotations?.representation?.id===Y||Q._tag==="FilterGroup"&&IK(Q.checks,Y))}function Du(X){let Y=X===void 0?kJ:rX(kJ,X);return new p0(new QX([Y,BF],"anyOf"),new q0(CJ(),Q0((Q)=>globalThis.Number.isFinite(Q)?Q:globalThis.String(Q))))}var fK=new $F;class GF extends n0{_tag="Boolean";getParser(){return nX(this,sD)}getExpected(){return"boolean"}}var ZF=new GF;class _F extends n0{_tag="Symbol";getParser(){return nX(this,lG)}matchKey(X,Y){return rJ(this,X,Y)}toCodecStringTree(){return R0(this,[MF])}getExpected(){return"symbol"}}var KF=new _F;class HF extends n0{_tag="BigInt";getParser(){return nX(this,aD)}matchPart(X,Y){return vK.test(X)?rJ(this,globalThis.BigInt(X),Y):void 0}toCodecStringTree(){return R0(this,[ju])}getExpected(){return"bigint"}}var WF=new HF;class iX extends n0{_tag="Arrays";isMutable;elements;rest;encodingChecks;constructor(X,Y,Q,J,$,G,_,K){super(J,$,G,_);this.isMutable=X,this.elements=Y,this.rest=Q,this.encodingChecks=K;let H=Y.findIndex(l0);if(H!==-1&&(Y.slice(H+1).some((W)=>!l0(W))||Q.length>1))throw Error("A required element cannot follow an optional element. ts(1257)");if(Q.length>1&&Q.slice(1).some(l0))throw Error("An optional element cannot follow a rest element. ts(1266)")}getParser(X){let Y=this,Q=Y.elements.map((W)=>({ast:W,parser:X(W)})),J=Y.rest.map((W)=>({ast:W,parser:X(W)})),$=Q.length,[G,..._]=J,K=_.length;function H(W,D){if(D<$)return Q[D];else if(D>=W)return _[D-W];return G}return oY(function*(W,D){if(W._tag==="None")return W;let U=W.value;if(!Array.isArray(U))return yield*f(new r0(Y,W));let N=U.length,B={ast:Y,getParser:H,oinput:W,len:N,tailThreshold:Bu(N,$,K),output:new globalThis.Array(N),issues:void 0,options:D},z=dK(D?.concurrency),q=Nu(B,U,{concurrency:z?.concurrency,end:Y.rest.length===0?$:Math.max(N,$+K)});if(q)yield*q;if(Y.rest.length===0&&N>$)for(let F=$;F<=N-1;F++){let R=new S0([F],new RJ(Y,U[F]));if(D.errors==="all")if(B.issues)B.issues.push(R);else B.issues=[R];else return yield*f(new F0(Y,W,[R]))}if(B.issues)return yield*f(new F0(Y,W,B.issues));return T(B.output)})}_rebuild(X,Y,Q){let J=B9(this.elements,X),$=B9(this.rest,X);return J===this.elements&&$===this.rest&&Y===this.checks&&Q===this.encodingChecks?this:new iX(this.isMutable,J,$,this.annotations,Y,void 0,this.context,Q)}recur(X){return this._rebuild(X,this.checks,this.encodingChecks)}flip(X){return this._rebuild(X,this.encodingChecks,this.checks)}getExpected(){return"array"}}var Nu=jY()({onItem(X,Y,Q){let J=Q<X.len?T(Y):d();return X.getParser(X.tailThreshold,Q).parser(J,X.options)},step(X,Y,Q,J){if(Q._tag==="Failure")return vJ(X,X.ast,J,Q);else if(Q.value._tag==="Some")X.output[J]=Q.value.value;else{let $=X.getParser(X.tailThreshold,J);if(l0($.ast))return;let G=new S0([J],new DQ($.ast.context?.annotations));if(X.options.errors==="all")if(X.issues)X.issues.push(G);else X.issues=[G];else return IY(new F0(X.ast,X.oinput,[G]))}}});function Bu(X,Y,Q){return Math.max(Y,X-Q)}var dK=(X)=>{return X=X==="unbounded"?1/0:X??1,X>1?{concurrency:X}:void 0},vJ=(X,Y,Q,J)=>{if(J.cause.reasons.length===0)return J;let $=PJ(J.cause);if($===void 0)return m8($8(J.cause,(_)=>new F0(Y,X.oinput,[new S0([Q],_)])));let G=new S0([Q],$);if(X.options.errors==="all")if(X.issues)X.issues.push(G);else X.issues=[G];else return IY(new F0(Y,X.oinput,[G]))},bJ="[+-]?\\d*\\.?\\d+(?:[Ee][+-]?\\d+)?";function z9(X,Y,Q=G5){let J,$;function G(_){switch(_._tag){case"String":case"TemplateLiteral":return(J??=Object.keys(X)).filter((K)=>_.matchPart(K,Q)!==void 0);case"Number":return(J??=Object.keys(X)).filter((K)=>_.matchKey(K,Q)!==void 0);case"Symbol":return($??=Object.getOwnPropertySymbols(X)).filter((K)=>_.matchKey(K,Q)!==void 0);case"Union":return[...new Set(_.types.flatMap(G))];default:return[]}}return G(rK(F1(Y)))}class gJ{name;type;constructor(X,Y){this.name=X,this.type=Y}}class yJ{decode;encode;constructor(X,Y){this.decode=X,this.encode=Y}flip(){return new yJ(this.encode,this.decode)}}function xK(X){switch(X._tag){case"String":case"Number":case"Symbol":case"TemplateLiteral":return!0;case"Union":return X.types.every(xK);default:return!1}}function Vu(X){return xK(X)&&xK(F1(X))}class hJ{parameter;type;merge;constructor(X,Y,Q){if(!Vu(X))throw Error(`Invalid index signature parameter ${X._tag}`);if(this.parameter=X,this.type=Y,this.merge=Q,l0(Y)&&!AF(Y))throw Error("Cannot use `Schema.optionalKey` with index signatures, use `Schema.optional` instead.")}}class q9 extends n0{_tag="Objects";propertySignatures;indexSignatures;encodingChecks;constructor(X,Y,Q,J,$,G,_){super(Q,J,$,G);this.propertySignatures=X,this.indexSignatures=Y,this.encodingChecks=_;let K=X.map((H)=>H.name).filter((H,W,D)=>D.indexOf(H)!==W);if(K.length>0)throw Error(`Duplicate identifiers: ${JSON.stringify(K)}. ts(2300)`)}getParser(X){let Y=this,Q=[],J=new Set,$=[];for(let K of Y.propertySignatures)Q.push(K.name),J.add(K.name),$.push({ps:K,parser:X(K.type),name:K.name,type:K.type});let G=Y.indexSignatures.length;if(Y.propertySignatures.length===0&&Y.indexSignatures.length===0)return nX(Y,C7);let _=G>0?jY()({onItem:oY(function*(K,[H,W]){let U=X(rK(W.parameter))(T(H),K.options),N=E1(U)?U:yield*lY(U);if(N._tag==="Failure"){let R=vJ(K,Y,H,N);if(R)yield*R;return}let B=T(K.input[H]),q=X(W.type)(B,K.options),F=E1(q)?q:yield*lY(q);if(F._tag==="Failure"){let R=vJ(K,Y,H,F);if(R)yield*R;return}else if(N.value._tag==="Some"&&F.value._tag==="Some"){let R=N.value.value;if(J.has(H)||J.has(R))return;let C=F.value.value;if(W.merge&&W.merge.decode&&Object.hasOwn(K.out,R)){let[E,a]=W.merge.decode.combine([R,K.out[R]],[R,C]);k(K.out,E,a)}else k(K.out,R,C)}}),step:(K,H,W)=>W._tag==="Failure"?W:void 0}):void 0;return oY(function*(K,H){if(K._tag==="None")return K;let W=K.value;if(!(typeof W==="object"&&W!==null&&!Array.isArray(W)))return yield*f(new r0(Y,K));let D={},U={ast:Y,oinput:K,input:W,out:D,issues:void 0,options:H},N=H.errors==="all",B=H.onExcessProperty==="error",z=H.onExcessProperty==="preserve",q;if(Y.indexSignatures.length===0&&(B||z)){q=Reflect.ownKeys(W);for(let C=0;C<q.length;C++){let E=q[C];if(!J.has(E))if(B){let a=new S0([E],new RJ(Y,W[E]));if(N){if(U.issues)U.issues.push(a);else U.issues=[a];continue}else return yield*f(new F0(Y,K,[a]))}else k(D,E,W[E])}}let F=dK(H?.concurrency),R=zu(U,$,F);if(R)yield*R;if(_){let C=Z3();for(let a=0;a<G;a++){let L=Y.indexSignatures[a],w=z9(W,L.parameter,H);for(let A=0;A<w.length;A++){let x=w[A];C.push([x,L])}}let E=_(U,C,F);if(E)yield*E}if(U.issues)return yield*f(new F0(Y,K,U.issues));if(H.propertyOrder==="original"){let C=(q??Reflect.ownKeys(W)).concat(Q),E={};for(let a of C)if(Object.hasOwn(D,a))k(E,a,D[a]);return T(E)}return T(D)})}_rebuild(X,Y,Q,J,$){let G=B9(this.propertySignatures,(K)=>{let H=X(K.type);return H===K.type?K:new gJ(K.name,H)}),_=B9(this.indexSignatures,(K)=>{let H=Y(K.parameter),W=X(K.type),D=Q?K.merge?.flip():K.merge;return H===K.parameter&&W===K.type&&D===K.merge?K:new hJ(H,W,D)});return G===this.propertySignatures&&_===this.indexSignatures&&J===this.checks&&$===this.encodingChecks?this:new q9(G,_,this.annotations,J,void 0,this.context,$)}flip(X){return this._rebuild(X,X,!0,this.encodingChecks,this.checks)}recur(X,Y=X){return this._rebuild(X,Y,!1,this.checks,this.encodingChecks)}getExpected(){if(this.propertySignatures.length===0&&this.indexSignatures.length===0)return"object | array";return"object"}}var zu=jY()({onItem(X,Y){let Q=Object.hasOwn(X.input,Y.name)?T(X.input[Y.name]):d();return Y.parser(Q,X.options)},step(X,Y,Q){if(Q._tag==="Failure")return vJ(X,X.ast,Y.name,Q);else if(Q.value._tag==="Some")k(X.out,Y.name,Q.value.value);else if(!l0(Y.type)){let J=new S0([Y.name],new DQ(Y.type.context?.annotations));if(X.options.errors==="all"){if(X.issues)X.issues.push(J);else X.issues=[J];return}else return IY(new F0(X.ast,X.oinput,[J]))}}});function pK(X,Y){if(!X)return Y;if(!Y)return X;return[...X,...Y]}function mJ(X,Y,Q){return new q9(Reflect.ownKeys(X).map((J)=>{return new gJ(J,X[J].ast)}),[],Q,Y)}function OQ(X){return X.ast}function uK(X,Y=void 0){return new iX(!1,X.map((Q)=>Q.ast),[],void 0,Y)}function fJ(X,Y,Q){return new QX(X.map(OQ),Y,void 0,Q)}function UF(X,Y){if(X.encoding||Y.some((G)=>G.encoding))throw Error("StructWithRest does not support encodings");let{propertySignatures:Q,indexSignatures:J,checks:$}=X;for(let G of Y)Q=Q.concat(G.propertySignatures),J=J.concat(G.indexSignatures),$=pK($,G.checks);return new q9(Q,J,void 0,$)}function DF(X,Y){if(X.encoding)throw Error("TupleWithRest does not support encodings");return new iX(X.isMutable,X.elements,Y,void 0,X.checks)}function NF(X){switch(X._tag){case"Null":return["null"];case"Undefined":return["undefined"];case"String":case"TemplateLiteral":return["string"];case"Number":return["number"];case"Boolean":return["boolean"];case"Symbol":case"UniqueSymbol":return["symbol"];case"BigInt":return["bigint"];case"Arrays":return["array"];case"ObjectKeyword":return["object","array","function"];case"Objects":return X.propertySignatures.length||X.indexSignatures.length?["object"]:["string","number","boolean","symbol","bigint","object","array","function"];case"Enum":return Array.from(new Set(X.enums.map(([,Y])=>typeof Y)));case"Literal":return[typeof X.literal];case"Union":return Array.from(new Set(X.types.flatMap(NF)));default:return["null","undefined","string","number","boolean","symbol","bigint","object","array","function"]}}function TQ(X){switch(X._tag){default:return[];case"Declaration":{let Y=X.annotations?.[KQ];return Array.isArray(Y)?Y:[]}case"Objects":return X.propertySignatures.flatMap((Y)=>{let Q=Y.type;if(!l0(Q)){if(SJ(Q))return[{key:Y.name,literal:Q.literal}];if(Uu(Q))return[{key:Y.name,literal:Q.symbol}]}return[]});case"Arrays":return X.elements.flatMap((Y,Q)=>{return SJ(Y)&&!l0(Y)?[{key:Q,literal:Y.literal}]:[]});case"Suspend":return TQ(X.thunk())}}var hT=new WeakMap;function qu(X){let Y=hT.get(X);if(Y)return Y;Y={};for(let Q=0;Q<X.length;Q++){let J=X[Q],$=F1(J);if(Wu($))continue;let G=NF($),_=TQ($);Y.byType??={};for(let K of G)(Y.byType[K]??=[]).push(Q);if(_.length>0){Y.bySentinel??=new Map;for(let{key:K,literal:H}of _){let W=Y.bySentinel.get(K);if(!W)Y.bySentinel.set(K,W=new Map);let D=W.get(H);if(!D)W.set(H,D=[]);D.push(Q)}}else{Y.otherwise??={};for(let K of G)(Y.otherwise[K]??=[]).push(Q)}}return hT.set(X,Y),Y}function mT(X){return(Y)=>{let Q=F1(Y);return Q._tag==="Literal"?Q.literal===X:Q._tag==="UniqueSymbol"?Q.symbol===X:!0}}function FQ(X,Y){let Q=qu(Y),J=X===null?"null":Array.isArray(X)?"array":typeof X;if(Q.bySentinel){let $=Q.otherwise?.[J]??[];if(J==="object"||J==="array"){let G=new Set($);for(let[_,K]of Q.bySentinel)if(Object.hasOwn(X,_)){let H=K.get(X[_]);if(H)for(let W of H)G.add(W)}return Array.from(G).sort((_,K)=>_-K).map((_)=>Y[_]).filter(mT(X))}return $.map((G)=>Y[G])}return(Q.byType?.[J]??[]).map(($)=>Y[$]).filter(mT(X))}class QX extends n0{_tag="Union";types;mode;encodingChecks;constructor(X,Y,Q,J,$,G,_){super(Q,J,$,G);this.types=X,this.mode=Y,this.encodingChecks=_}getParser(X){let Y=this;return(Q,J)=>{if(Q._tag==="None")return p(Q);let $=Q.value,G=FQ($,Y.types),_={ast:Y,recur:X,oinput:Q,input:$,out:void 0,successes:[],issues:void 0,options:J},K=dK(J?.concurrency),H=Lu(_,G,K?{...K,orderedStep:!0}:void 0);if(!H)return _.out?p(_.out):f(new AJ(Y,$,_.issues??[]));return cY(H,(W)=>{return _.out?p(_.out):f(new AJ(Y,$,_.issues??[]))})}}_rebuild(X,Y,Q){let J=B9(this.types,X);return J===this.types&&Y===this.checks&&Q===this.encodingChecks?this:new QX(J,this.mode,this.annotations,Y,void 0,this.context,Q)}recur(X){return this._rebuild(X,this.checks,this.encodingChecks)}flip(X){return this._rebuild(X,this.encodingChecks,this.checks)}matchPart(X,Y){for(let Q of this.types){let J=Q.matchPart(X,Y);if(J!==void 0)return J}return}getExpected(X){let Y=this.annotations?.expected;if(typeof Y==="string")return Y;if(this.types.length===0)return"never";let Q=this.types.map((J)=>{let $=F1(J);switch($._tag){case"Arrays":{let G=$.elements.filter(SJ);if(G.length>0)return`${fT($.isMutable)}[ ${G.map((_)=>X(_)+dT(_.context?.isOptional)).join(", ")}, ... ]`;break}case"Objects":{let G=$.propertySignatures.filter((_)=>SJ(_.type));if(G.length>0)return`{ ${G.map((_)=>`${fT(_.type.context?.isMutable)}${m6(_.name)}${dT(_.type.context?.isOptional)}: ${X(_.type)}`).join(", ")}, ... }`;break}}return X($)});return Array.from(new Set(Q)).join(" | ")}}var Lu=jY()({onItem(X,Y){return X.recur(Y)(X.oinput,X.options)},step(X,Y,Q){if(Q._tag==="Failure"){let J=PJ(Q.cause);if(J===void 0)return Q;if(X.issues)X.issues.push(J);else X.issues=[J]}else{if(X.out&&X.ast.mode==="oneOf")return X.successes.push(Y),IY(new BK(X.ast,X.input,X.successes));if(X.out=Q.value,X.successes.push(Y),X.ast.mode==="anyOf")return gz}}}),BF=new QX([new DX("Infinity"),new DX("-Infinity"),new DX("NaN")],"anyOf");function fT(X){return X?"":"readonly "}function dT(X){return X?"?":""}function _5(X){let Y=!1,Q;return()=>{if(Y)return Q;return Q=X(),Y=!0,Q}}class dJ extends n0{_tag="Suspend";thunk;constructor(X,Y,Q,J,$){if(Q!==void 0)throw Error("Cannot add checks to Suspend");super(Y,void 0,J,$);this.thunk=_5(X)}getParser(X){return X(this.thunk())}recur(X){return new dJ(()=>X(this.thunk()),this.annotations,void 0,void 0,this.context)}getExpected(X){return X(this.thunk())}}class zQ extends O4{_tag="Filter";run;annotations;aborted;constructor(X,Y=void 0,Q=!1){super();this.run=X,this.annotations=Y,this.aborted=Q}annotate(X){return new zQ(this.run,{...this.annotations,...X},this.aborted)}abort(){return new zQ(this.run,this.annotations,!0)}and(X,Y){return new n8([this,X],Y)}}class n8 extends O4{_tag="FilterGroup";checks;annotations;constructor(X,Y=void 0){super();this.checks=X,this.annotations=Y}annotate(X){return new n8(this.checks,{...this.annotations,...X})}and(X,Y){return new n8([this,X],Y)}}function pJ(X,Y,Q=!1){return new zQ((J,$,G)=>fO(J,$,X(J,$,G)),Y,Q)}function uJ(X,Y){return new zQ((Q)=>X(Q)?void 0:new U0(T(Q)),Y,!0)}function cK(X){return pJ((Y)=>globalThis.Number.isFinite(Y),{expected:"a finite number",representation:{id:"effect/schema/isFinite",payload:null},toJsonSchema:()=>({type:"number"}),toCode:()=>({runtime:"Schema.isFinite()"}),arbitrary:{constraint:{noInfinity:!0,noNaN:!0}},...X})}var kJ=rX(fK,[cK()]);function RQ(X,Y){let Q=X.source;return pJ((J)=>X.test(J),{expected:`a string matching the RegExp ${Q}`,representation:{id:"effect/schema/isPattern",payload:{source:Q,flags:X.flags}},toJsonSchema:()=>({pattern:Q}),arbitrary:{constraint:{patterns:[X.source]}},...Y})}function AQ(X,Y){let Q=Object.getOwnPropertyDescriptors(X);return Y(Q),Object.create(Object.getPrototypeOf(X),Q)}function R0(X,Y){if(X.encoding===Y)return X;return AQ(X,(Q)=>{Q.encoding.value=Y})}function PQ(X,Y){if(X.context===Y)return X;return AQ(X,(Q)=>{Q.context.value=Y})}function a8(X){return X.encoding?a8(X.encoding[X.encoding.length-1].to):X}function w6(X,Y){if(X.checks){let Q=X.checks[X.checks.length-1];return cJ(X,G3(X.checks.slice(0,-1),Q.annotate(Y)))}return AQ(X,(Q)=>{Q.annotations.value={...Q.annotations.value,...Y}})}function cJ(X,Y){if(X._tag==="Suspend"&&Y!==void 0)throw Error("Cannot add checks to Suspend");if(X.checks===Y)return X;return AQ(X,(Q)=>{Q.checks.value=Y})}function rX(X,Y){return cJ(X,pK(X.checks,Y))}function t8(X,Y){let Q=Y(X.to);return Q===X.to?X:new p0(Q,X.transformation)}function VF(X,Y){let Q=X,J=Q[Q.length-1],$=t8(J,Y);return $===J?X:G3(X.slice(0,X.length-1),$)}function lK(X){return(Y)=>Y.encoding?R0(Y,VF(Y.encoding,X)):Y}function lJ(X,Y){return lK((Q)=>PQ(Q,Y))(X)}function e8(X){function Y(Q){return Q.encoding?R0(Q,VF(Q.encoding,Y)):X(Q)}return X1(Y)}function zF(X,Y){return oK(X,Y,T1(X))}function qF(X,Y){return oK(F1(X),Y,X)}function oK(X,Y,Q){let J=new p0(X,Y);return R0(Q,Q.encoding?[...Q.encoding,J]:[J])}function LF(X,Y){let Q=SO(X),J=Q?[...Q,Y]:[Y];return w6(X,{brands:J})}function B9(X,Y){let Q=!1,J=Array(X.length);for(let $=0;$<X.length;$++){let G=X[$],_=Y(G);if(_!==G)Q=!0;J[$]=_}return Q?J:X}function wQ(X,Y){let Q=X.context?new oX(X.context.isOptional,X.context.isMutable,X.context.defaultValue,{...X.context.annotations,...Y}):new oX(!1,!1,void 0,Y);return PQ(X,Q)}var Ou=lK(CQ);function CQ(X){let Y=X.context?X.context.isOptional===!1?new oX(!0,X.context.isMutable,X.context.defaultValue,X.context.annotations):X.context:new oX(!0,!1);return Ou(PQ(X,Y))}var Tu=lK(iK);function iK(X){let Y=X.context?X.context.isMutable===!1?new oX(X.context.isOptional,!0,X.context.defaultValue,X.context.annotations):X.context:new oX(!1,!0);return Tu(PQ(X,Y))}function OF(X,Y){let Q=new q0(NQ(Y),cX()),J=[new p0(Q5,Q)],$=X.context?new oX(X.context.isOptional,X.context.isMutable,J,X.context.annotations):new oX(!1,!1,J);return PQ(X,$)}function oJ(X,Y,Q){return oK(X,Q,Y)}function Fu(X){let Y=[],Q=[];function J($){switch($._tag){case"Literal":if(w7($.literal))Y.push($.literal);return;case"UniqueSymbol":Y.push($.symbol);return;case"Never":return;case"Union":for(let G=0;G<$.types.length;G++)J($.types[G]);return;default:Q.push($)}}return J(X),{literals:Y,parameters:Q}}function TF(X,Y,Q){let{literals:J,parameters:$}=Fu(X);return new q9(J.map((G)=>new gJ(G,Y)),$.map((G)=>new hJ(G,Y,Q)))}function l0(X){return X.context?.isOptional??!1}function FF(X){return X.context?.isMutable??!1}function RF(X){return X.annotations?.[XX]===!0||X._tag==="FilterGroup"&&X.checks.every(RF)}function Ru(X){function Y(J){if(RF(J))return[J];return J._tag==="FilterGroup"?J.checks.flatMap(Y):[]}let Q=X.flatMap(Y);return B6(Q)?Q:void 0}var T1=X1((X)=>{if(X.encoding)return T1(R0(X,void 0));let Y=X,Q=Y.recur?.(T1)??Y,J=Q.encodingChecks;if(J){let $=Q===X?J:qQ(Q)||bK(Q)||$5(Q)&&Q.typeParameters.length>0?Ru(J):void 0;return AQ(Q,(G)=>{G.encodingChecks.value=void 0,G.checks.value=pK(Q.checks,$)})}return Q}),F1=X1((X)=>{return T1(lX(X))});function Au(X,Y){let Q=Y,J=Q.length,$=Q[J-1],G=[new p0(lX(R0(X,void 0)),Q[0].transformation.flip())];for(let K=1;K<J;K++)G.unshift(new p0(lX(Q[K-1].to),Q[K].transformation.flip()));let _=lX($.to);if(_.encoding)return R0(_,[..._.encoding,...G]);else return R0(_,G)}var lX=X1((X)=>{if(X.encoding)return Au(X,X.encoding);let Y=X;return Y.flip?.(lX)??Y.recur?.(lX)??Y});function AF(X){switch(X._tag){case"Undefined":return!0;case"Union":return X.types.some(AF);default:return!1}}function iJ(X,Y){let Q=pY(Y);return(J)=>{if(J._tag==="None")return pX;return J.value===Y?Q:f(new r0(X,J))}}function Pu(X){let Y=pY(X);return(Q)=>Q._tag==="None"?pX:Y}function nX(X,Y){return(Q)=>{if(Q._tag==="None")return pX;return Y(Q.value)?p(Q):f(new r0(X,Q))}}function rJ(X,Y,Q){if(Q?.disableChecks||X.checks===void 0)return Y;let J=[];return L9(X.checks,Y,J,X,Q),J.length===0?Y:void 0}function pT(X,Y,Q){let J=X.map((H)=>H._tag==="Literal"?globalThis.String(H.literal):void 0);if(J.some((H)=>H!==void 0&&!Y.includes(H)))return;let $=Array(X.length+1);$[X.length]=0;for(let H=X.length-1;H>=0;H--)$[H]=$[H+1]+(J[H]?.length??0);if($[0]>Y.length)return;let G=Array(X.length),_=X.map(()=>new Set);function K(H,W){if(H===X.length)return W===Y.length;if(_[H].has(W))return!1;let D=X[H];if(H===X.length-1){let U=Y.slice(W);if(D.matchPart(U,Q)!==void 0)return G[H]=U,!0}else if(D._tag==="Literal"){let U=J[H];if(Y.startsWith(U,W)&&K(H+1,W+U.length))return G[H]=U,!0}else{let U=Y.length-$[H+1],N=J[H+1],B=N===void 0?U:Y.lastIndexOf(N,U);while(B>=W){let z=Y.slice(W,B);if(D.matchPart(z,Q)!==void 0&&K(H+1,B))return G[H]=z,!0;if(B===0)break;B=N===void 0?B-1:Y.lastIndexOf(N,B-1)}}return _[H].add(W),!1}return K(0,0)?G:void 0}var PF=X1((X)=>{return new QX(X.enums.map((Y)=>new DX(Y[1],{title:Y[0]})),"anyOf")}),rK=e8((X)=>{switch(X._tag){default:return X;case"Number":return X.toCodecStringTree();case"Union":return X.recur(rK)}}),nJ=e8((X)=>{switch(X._tag){default:return X;case"Symbol":case"UniqueSymbol":return X.toCodecStringTree();case"Union":return X.recur(nJ)}}),wF=e8((X)=>{switch(X._tag){default:return X;case"Number":case"Literal":case"BigInt":return X.toCodecStringTree();case"Union":return X.recur(wF)}}),CF="[\\s\\S]*?",SK=new globalThis.RegExp(`^${bJ}$`),wu=new globalThis.RegExp(`^(?:${bJ}|Infinity|-Infinity|NaN)$`);function nK(X){return RQ(SK,{expected:"a string representing a finite number",representation:{id:"effect/schema/isStringFinite",payload:null},toJsonSchema:()=>({pattern:SK.source}),...X})}var EF=rX(s8,[nK()]),Cu=new p0(EF,N9),Eu=new p0(new QX([EF,BF],"anyOf"),N9),Mu="-?\\d+",vK=new globalThis.RegExp(`^${Mu}$`);function sK(X){return RQ(vK,{expected:"a string representing a bigint",representation:{id:"effect/schema/isStringBigInt",payload:null},toJsonSchema:()=>({pattern:vK.source}),...X})}var aK=rX(s8,[sK({expected:"a string representing a bigint"})]),ju=new p0(aK,xJ),Iu="Symbol\\((.*)\\)",kK=new globalThis.RegExp(`^${Iu}$`),xu=rX(s8,[tK()]),MF=new p0(xu,new q0(Q0((X)=>globalThis.Symbol.for(kK.exec(X)[1])),YX((X)=>{if(globalThis.Symbol.keyFor(X)!==void 0)return p(globalThis.String(X));return f(new W9(T(X),{message:"cannot serialize to string, Symbol is not registered"}))})));function tK(X){return RQ(kK,{expected:"a string representing a symbol",representation:{id:"effect/schema/isStringSymbol",payload:null},toJsonSchema:()=>({pattern:kK.source}),...X})}function L9(X,Y,Q,J,$){for(let G=0;G<X.length;G++){let _=X[G];if(_._tag==="FilterGroup")L9(_.checks,Y,Q,J,$);else{let K=_.run(Y,J,$);if(K){if(Q.push(new FJ(Y,_,K)),_.aborted||$?.errors!=="all")return}}}}function jF(X,Y){let Q=[];if(L9(X,Y,Q,Q5,{errors:"all"}),B6(Q)){let J=new F0(Q5,T(Y),Q);return c(J)}return m(Y)}var sJ="~effect/Schema/Class";function Su(X){return X===null||typeof X==="string"||typeof X==="boolean"||typeof X==="number"&&globalThis.Number.isFinite(X)}function vu(X){return X===void 0||typeof X==="string"}function IF(X,Y){let Q=new WeakMap,J=[];X:while(!0){if(typeof X!=="object"||X===null){if(!Y(X))return!1}else{let $=X,G=Q.get($);if(G===!1)return!1;if(G===void 0){let _=Array.isArray($);if(!_){let K=Object.getPrototypeOf($);if(K!==null&&K!==Object.prototype&&Object.getPrototypeOf(K)!==null)return!1}Q.set($,!1),J.push({value:$,keys:_?$.length:Object.keys($),index:0})}}while(J.length>0){let $=J[J.length-1],G=$.keys;if(typeof G==="number"){if($.index<G){X=$.value[$.index++];continue X}}else if($.index<G.length){X=$.value[G[$.index++]];continue X}Q.set($.value,!0),J.pop()}return!0}}function O9(X){return IF(X,Su)}var V9=new Z5([],()=>(X,Y)=>O9(X)?p(X):f(new r0(Y,T(X))),{representation:{id:"effect/schema/Json",payload:null},expected:"JSON value",toCodecJson:()=>{return},toCodecStringTree:()=>XH,toArbitrary:()=>(X)=>X.jsonValue()}),xF=w6(V9,{representation:{id:"effect/schema/MutableJson",payload:null}}),eK=new p0(V9,D9()),SF=new p0(new QX([new iX(!1,[],[V9]),new q9([],[new hJ(s8,V9,void 0)])],"anyOf"),D9());function ku(X){return IF(X,vu)}var bu=new Z5([],()=>(X,Y)=>ku(X)?p(X):f(new r0(Y,T(X))),{expected:"StringTree",toCodecStringTree:()=>{return}}),XH=new p0(bu,D9());var EQ="~effect/SchemaError/SchemaError";class Y4 extends DY("SchemaError"){[EQ]=EQ;constructor(X){super({issue:X})}get message(){return this.issue.toString()}toString(){return`SchemaError(${this.message})`}}function YH(X){return j(X,EQ)&&X[EQ]===EQ}var MQ=X1((X)=>{switch(X._tag){case"Declaration":{let Y=X.annotations?.[sJ];if(l1(Y)){let Q=Y(X.typeParameters);return R0(X,[t8(Q,MQ)])}return X}case"Objects":case"Arrays":return X.recur((Y)=>{let Q=Y.context?.defaultValue;if(Q){let J=MQ(Y);return R0(J,J.encoding?[...J.encoding,...Q]:Q)}return MQ(Y)});case"Suspend":return X.recur(MQ);default:return X}});function tJ(X){let Y=MQ(T1(X.ast)),Q=F9(Y);return(J,$)=>{return Q(J,$?.disableChecks?$?.parseOptions?{...$.parseOptions,disableChecks:!0}:{disableChecks:!0}:$?.parseOptions)}}function eJ(X){let Y=tJ(X);return(Q,J)=>{let $=p8(Y(Q,J));if(M1($))return T($.value);return W8($.cause,"Option adapter can only return none for schema issues"),d()}}function vF(X){let Y=tJ(X);return(Q,J)=>{let $=p8(Y(Q,J));if(M1($))return $.value;let G=W8($.cause,"Constructor adapter can only throw schema issues");throw Error(G.toString(),{cause:G})}}function kF(X){return jQ(X.ast)}function jQ(X){let Y=K5(F9(T1(X)));return(Q)=>{let J=Y(Q,G5);if(M1(J))return!0;return W8(J.cause,"Type guard adapter can only return false for schema issues"),!1}}function bF(X){let Y=F9(X);return(Q,J)=>{let $=p8(Y(Q,J));if(M1($))return;return W8($.cause,"Issue adapter can only return schema issues")}}function gF(X,Y){let J=K5(F9(T1(X.ast)))(Y,G5);if(yz(J)){let $=W8(J.cause,"Assertion adapter can only throw schema issues");throw Error($.toString(),{cause:$})}}function a0(X,Y){let Q=F9(X.ast);return Y===void 0?Q:(J,$)=>Q(J,uF(Y,$))}var QH=a0;function yF(X,Y){return K5(a0(X,Y))}function JH(X,Y){return cF(a0(X,Y))}var hF=JH;function mF(X,Y){return lF(a0(X,Y))}function gu(X,Y){return oF(a0(X,Y))}var $H=gu;function T9(X,Y){let Q=F9(lX(X.ast));return Y===void 0?Q:(J,$)=>Q(J,uF(Y,$))}function fF(X,Y){return K5(T9(X,Y))}function GH(X,Y){return cF(T9(X,Y))}var dF=GH;function pF(X,Y){return lF(T9(X,Y))}function yu(X,Y){return oF(T9(X,Y))}var ZH=yu,uF=(X,Y)=>Y===void 0?X:{...X,...Y};function F9(X){let Y=aJ(X);return(Q,J)=>wX(Y(T(Q),J??G5),($)=>{if($._tag==="None")return f(new U0($));return p($.value)})}function K5(X){return(Y,Q)=>p8(X(Y,Q))}function cF(X){let Y=K5(X);return(Q,J)=>{let $=Y(Q,J);if(M1($))return T($.value);return W8($.cause,"Option adapter can only return none for schema issues"),d()}}function lF(X){let Y=K5(X);return(Q,J)=>{let $=Y(Q,J);if(M1($))return m($.value);return c(W8($.cause,"Result adapter can only return schema issues"))}}function oF(X){let Y=K5(X);return(Q,J)=>{let $=Y(Q,J);if(M1($))return $.value;let G=W8($.cause,"Sync adapter can only throw schema issues");throw Error(G.toString(),{cause:G})}}function hu(X,Y){return i4(X,(Q)=>o4(()=>$8(Q,Y)))}var aJ=X1((X)=>{let Y,Q=X.checks,J=X.encoding,$=J,G=$?.length??0,_=X.encodingChecks,K=(Q?Q[Q.length-1].annotations:X.annotations)?.parseOptions;if(!X.context&&!J&&!Q&&!_)return(H,W)=>{if(Y??=X.getParser(aJ),K)W={...W,...K};return Y(H,W)};return(H,W)=>{if(K)W={...W,...K};let D;if($){for(let B=G-1;B>=0;B--){let z=$[B],q=z.to,F=aJ(q);if(D=D?wX(D,(R)=>F(R,W)):F(H,W),z.transformation._tag==="Transformation"){let R=z.transformation.decode;D=wX(D,(C)=>R.run(C,W))}else D=z.transformation.decode(D,W)}D=hu(D,(B)=>new NK(X,H,B))}Y??=X.getParser(aJ);let U=(B)=>{let z=Y(B,W);if(_&&!W?.disableChecks)z=wX(z,(q)=>{if(N1(B)&&N1(q)){let F=[];if(L9(_,B.value,F,X,W),B6(F))return f(new F0(X,B,F))}return p(q)});if(Q&&!W?.disableChecks)z=wX(z,(q)=>{if(N1(q)){let F=q.value,R=[];if(L9(Q,F,R,X,W),B6(R))return f(new F0(X,q,R))}return p(q)});return z};return D?wX(D,U):U(H)}});var X$="~effect/Schema/Schema";function JX(X,Y,Q){return{id:X,payloadSchema:Y,revive:Q}}function s(X,Y,Q){return{id:X,payloadSchema:Y,revive:Q}}var mu={[X$]:X$,pipe(){return G0(this,arguments)},annotate(X){return this.rebuild(w6(this.ast,X))},annotateKey(X){return this.rebuild(wQ(this.ast,X))},check(...X){return this.rebuild(rX(this.ast,X))}};function IQ(X,Y){function Q(){}let J=Object.defineProperties(Object.setPrototypeOf(Q,mu),Object.getOwnPropertyDescriptors({...Y}));J.ast=X,J.rebuild=(G)=>IQ(G,Y);let $=tJ(J);return J.makeEffect=(G,_)=>Y$($(G,_)),J.make=vF(J),J.makeOption=eJ(J),J}function Y$(X){return i4(X,(Y)=>o4(()=>$8(Y,(Q)=>new Y4(Q))))}var lG0=globalThis.Boolean;var iF=l6((X,Y)=>X||Y,!1);var rF=V(2,(X,Y)=>{return HH(X,(Q,J)=>Y.includes(Q)?[Q,J]:void 0)}),nF=V(2,(X,Y)=>{return HH(X,(Q,J)=>!Y.includes(Q)?[Q,J]:void 0)}),sF=V(2,(X,Y)=>{return{...X,...Y}});var KH=V(2,(X,Y)=>{return HH(X,(Q,J)=>[Object.hasOwn(Y,Q)?Y[Q]:Q,J])});var j1=(X)=>X;function HH(X,Y){let Q={};for(let J of Reflect.ownKeys(X)){if(!Object.prototype.propertyIsEnumerable.call(X,J))continue;let $=Y(J,X[J]);if($){let[G,_]=$;k(Q,G,_)}}return Q}function aF(X,Y){let Q=Y?.omitKeyWhen??(()=>!1);return zN((J,$)=>{let G=Reflect.ownKeys(X),_={};for(let K of G){let H=X[K].combine(J[K],$[K]);if(Q(H))continue;k(_,K,H)}return _})}function xQ(X){return l6((Y,Q)=>{if(Y===void 0)return Q;if(Q===void 0)return Y;return X.combine(Y,Q)},void 0)}function C6(X,Y){if(Y.length>0)X+=`
  at ${v7(Y)}`;return Error(X)}var tF=new WeakMap,eF=new WeakMap,XR=[];function UR(){return{warnings:[]}}function DR(X){return{warnings:X.warnings.slice()}}function D8(X){return Error(`Unable to derive an arbitrary for ${X}`)}var YR=([X],[Y])=>o(X,Y);function uu(X,Y,Q){return Y.reduce((J,$)=>J.filter((G)=>$.run(G,X,G5)===void 0),Q)}function NR(X,Y){if(X?.minLength!==void 0&&X.maxLength!==void 0&&X.minLength>X.maxLength)throw D8(`${Y} constraints`)}function BR(X){return X===void 0||X.minLength===void 0&&X.maxLength===void 0?void 0:{...X.minLength!==void 0?{minLength:X.minLength}:{},...X.maxLength!==void 0?{maxLength:X.maxLength}:{}}}function UH(X,Y,Q,J){return J?X.uniqueArray(Y,{...Q,comparator:J}):X.array(Y,Q)}function QR(X,Y,Q,J=!1){let $=Y.constraint,G=BR($);return NR(G,"array"),UH(X,Q,J?{...G,maxLength:G?.minLength??0}:G,$?.unique?o:void 0)}function Q$(X,Y,Q,J){return Y.chain(($)=>$.length<Q?X.constant($):J.map((G)=>[...$,...G]))}function JR(X,Y){return X.chain((Q)=>Y.map((J)=>({...Object.fromEntries(J),...Q})))}var cu=xQ(Cq),lu=xQ(Eq),J$=xQ(iF),ou=xQ(lN()),iu=aF({integer:J$,maxLength:lu,minLength:cu,noInfinity:J$,noNaN:J$,patterns:ou,unique:J$},{omitKeyWhen:tD});function $R(X,Y,Q,J,$,G){if(J===void 0||Y===void 0)return J===void 0?[Y,Q]:[J,$];let _=X(Y,J);return _===G?[J,$]:_===0?[Y,Q||$]:[Y,Q]}function ru(X,Y){if(X===void 0)return Y;if(X.order!==Y.order)throw Error("Cannot merge ordered arbitrary constraints with different Order instances");let[Q,J]=$R(X.order,X.minimum,X.exclusiveMinimum,Y.minimum,Y.exclusiveMinimum,-1),[$,G]=$R(X.order,X.maximum,X.exclusiveMaximum,Y.maximum,Y.exclusiveMaximum,1);return{order:X.order,...Q!==void 0?{minimum:Q}:{},...J!==void 0?{exclusiveMinimum:J}:{},...$!==void 0?{maximum:$}:{},...G!==void 0?{exclusiveMaximum:G}:{}}}function nu(X,Y){let{ordered:Q,...J}=X??{},{ordered:$,...G}=Y,_=$===void 0?Q:ru(Q,$);return{...iu.combine(J,G),..._===void 0?{}:{ordered:_}}}function GR(X){let Y=[],Q=[];function J($){if($.annotations?.arbitrary)Q.push($.annotations.arbitrary);if($._tag!=="Filter")for(let G of $.checks)J(G);else Y.push($)}return X?.forEach(J),{filters:Y,arbitraries:Q}}function su(X){let Y=X.map(({constraint:Q})=>Q).filter(V1);return(Q)=>{let J=Y.reduce(($,G)=>nu($,G),Q.constraint);return{...Q,constraint:J}}}function SQ(X){return{...X,constraint:void 0}}function ZR(X,Y,Q){if(Y===void 0||Y.minLength===void 0&&Y.maxLength===void 0)return;if(Y.minLength!==void 0&&X.indexSignatures.length===0&&Y.minLength>X.propertySignatures.length)throw D8("object property constraints");let J={};if(Y.minLength!==void 0)J.minLength=Math.max(0,Y.minLength-Q);if(Y.maxLength!==void 0){if(J.maxLength=Y.maxLength-Q,J.maxLength<0)throw D8("object property constraints")}return NR(J,"object property"),J}function au(X,Y,Q,J,$,G){let _=J.length;if(G.maxLength!==void 0&&G.maxLength<_)throw D8("object property constraints");let K=G.minLength===void 0?0:Math.max(0,G.minLength-_),H=G.maxLength===void 0?$.length:Math.min($.length,G.maxLength-_);if(K>H)throw D8("object property constraints");let W=X.record(Y,{requiredKeys:[...J,...$]}),D=X.shuffledSubarray([...$],{minLength:K,maxLength:H});return X.tuple(W,D).map(([U,N])=>{let B=new Set([...J,...N]),z={};for(let q of Q)if(B.has(q))k(z,q,U[q]);return z})}function VR(X,Y,Q,J){let $={};if(X?.minimum!==void 0)$.min=Y(X.minimum,X.exclusiveMinimum===!0);if(X?.maximum!==void 0)$.max=Q(X.maximum,X.exclusiveMaximum===!0);if($.min!==void 0&&$.max!==void 0&&$.min>$.max)throw D8(J);return $}function tu(X){return VR(X,(Y,Q)=>Q?Math.floor(Y)+1:Math.ceil(Y),(Y,Q)=>Q?Math.ceil(Y)-1:Math.floor(Y),"integer constraints")}function eu(X,Y){let Q={...X?.noInfinity?{noDefaultInfinity:!0}:{},...X?.noNaN?{noNaN:!0}:{},...Y?.minimum!==void 0?{min:Y.minimum}:{},...Y?.exclusiveMinimum!==void 0?{minExcluded:Y.exclusiveMinimum}:{},...Y?.maximum!==void 0?{max:Y.maximum}:{},...Y?.exclusiveMaximum!==void 0?{maxExcluded:Y.exclusiveMaximum}:{}};if(Q.min!==void 0&&Q.max!==void 0&&(Q.min>Q.max||Q.min===Q.max&&(Q.minExcluded||Q.maxExcluded)))throw D8("number constraints");return Q}function Xc(X){return VR(X,(Y,Q)=>Q?Y+BigInt(1):Y,(Y,Q)=>Q?Y-BigInt(1):Y,"the ordered bigint constraints")}function R9(X,Y){let Q=(J,$,G=XR)=>X(J,$,G);return Q.terminal=(J,$,G=XR)=>Y(J,$,G),Q}function MX(X){return R9(X,X)}function _R(X,Y){let Q=eF.get(Y)??X.createDepthIdentifier();return eF.set(Y,Q),{maxDepth:2,depthIdentifier:Q}}function KR(X,Y){return Y.length===0?void 0:Y.length===1?Y[0]:X.oneof(...Y)}var Yc={noInfinity:!0,noNaN:!0};function Qc(X){return{...X,constraint:Yc}}function Jc(X,Y,Q){function J($,G){let _=$.annotations?.arbitrary,K=G||_?.constraint!==void 0||_?.candidate!==void 0;if($._tag!=="Filter")for(let H of $.checks)J(H,K);else if(!K){let H=$.annotations?.representation?.id??$.annotations?.identifier??$.annotations?.expected;X.warnings.push({_tag:"OpaqueFilter",path:Q,...H===void 0?{}:{description:H}})}}Y?.forEach(($)=>J($,!1))}function zR(X,Y){let Q=new WeakSet;function J($,G){if(Q.has($))return;switch(Q.add($),Jc(Y,$.checks,G),$._tag){case"Declaration":$.typeParameters.forEach((_)=>J(_,G));break;case"Arrays":{for(let[_,K]of[...$.elements,...$.rest].entries())J(K,[...G,_]);break}case"Objects":$.propertySignatures.forEach((_)=>J(_.type,[...G,_.name])),$.indexSignatures.forEach((_)=>{J(_.parameter,G),J(_.type,G)});break;case"Union":$.types.forEach((_)=>J(_,G));break;case"TemplateLiteral":$.parts.forEach((_,K)=>J(F1(_),[...G,K]));break;case"Suspend":J($.thunk(),G);break}Q.delete($)}J(X,[])}function $c(X,Y,Q,J){let $=J===void 0?[]:[{arbitrary:J,weight:1}];for(let{candidate:G}of Q){if(!G)continue;let _=G.make(X,Y);if(_===void 0)continue;let K=G.weight??1;if(!globalThis.Number.isInteger(K)||K<=0)throw D8("a candidate with an invalid weight");$.push({arbitrary:_,weight:K})}return $.length===0?void 0:$.length===1?$[0].arbitrary:X.oneof(...$)}function HR(X,Y,Q,J,$){let G=$c(Q,J,Y.arbitraries,$);return G===void 0?void 0:uu(X,Y.filters,G)}function Gc(X,Y){if(!(typeof X==="object"&&X!==null&&("arbitrary"in X)))return{arbitrary:X,terminal:Y?void 0:X};let Q="terminal"in X?X.terminal:Y?void 0:X.arbitrary;return{arbitrary:X.arbitrary,terminal:Q}}function Zc(X,Y,Q,J,$){return X.map((G)=>({arbitrary:$?Y.constant(null).chain(()=>G(Y,Q,J)):G(Y,Q,J),terminal:G.terminal(Y,Q,J)}))}function WR(X,Y,Q,J){let $=su(Y.arbitraries);return R9((G,_,K)=>{let H=$(_);return HR(X,Y,G,H,Q(G,_,H,K))},(G,_,K)=>{let H=$(_);return HR(X,Y,G,H,J(G,_,H,K))})}var DH=X1((X)=>jX(X,[]));function jX(X,Y){let Q=H8(X)?.toArbitrary;if(Q){let J=$5(X)?X.typeParameters.map((_)=>jX(_,Y)):[],$=GR(X.checks),G=(_)=>(K,H,W,D)=>Gc(Q(Zc(J,K,SQ(H),D,_))(K,W),J.length>0)[_?"terminal":"arbitrary"];return WR(X,$,G(!1),G(!0))}if(X.checks){let J=GR(X.checks),$=jX(cJ(X,void 0),Y);return WR(X,J,(G,_,K,H)=>$(G,K,H),(G,_,K,H)=>$.terminal(G,K,H))}return _c(X,Y)}function _c(X,Y){switch(X._tag){case"Never":case"Declaration":throw C6(`Unsupported AST ${X._tag}`,Y);case"Null":return MX((Q)=>Q.constant(null));case"Void":case"Undefined":return MX((Q)=>Q.constant(void 0));case"Unknown":case"Any":return MX((Q)=>Q.anything());case"String":return MX((Q,J)=>{let $=J.constraint,G=$?.patterns;return G?Q.oneof(...G.map((_)=>Q.stringMatching(new RegExp(_)))):Q.string(BR($))});case"Number":return MX((Q,J)=>{let $=J.constraint,G=$?.ordered?.order===L1?$.ordered:void 0;return $?.integer?Q.integer(tu(G)):Q.float(eu($,G))});case"Boolean":return MX((Q)=>Q.boolean());case"BigInt":return MX((Q,J)=>{let $=J.constraint?.ordered?.order===AX?J.constraint.ordered:void 0;return Q.bigInt(Xc($))});case"Symbol":return MX((Q)=>Q.string().map(Symbol.for));case"Literal":return MX((Q)=>Q.constant(X.literal));case"UniqueSymbol":return MX((Q)=>Q.constant(X.symbol));case"ObjectKeyword":return MX((Q)=>Q.oneof(Q.object(),Q.array(Q.anything())));case"Enum":return jX(PF(X),Y);case"TemplateLiteral":{let Q=X.parts.map((J,$)=>jX(F1(J),[...Y,$]));return MX((J,$,G)=>J.tuple(...Q.map((_)=>_(J,Qc($),G))).map((_)=>_.map((K)=>globalThis.String(K)).join("")))}case"Arrays":{let Q=X.elements.map((_,K)=>({ast:_,arbitrary:jX(_,[...Y,K])})),J=X.elements.length,$=X.rest.map((_,K)=>({ast:_,arbitrary:jX(_,[...Y,J+K])})),G=(_,K,H)=>{let W=SQ(K),D=[],U=[],N=0;for(let C of Q){let E=C.arbitrary.terminal(_,W,H);if(l0(C.ast)){U.push(E);continue}if(E===void 0)return;N++,D.push(E.map(T))}let B=K.constraint?.minLength??0,q=k8($)&&B>N+U.length?U.length:Math.max(0,B-N),F=0;for(let C of U){if(F>=q||C===void 0){D.push(_.constant(d()));continue}F++,N++,D.push(C.map(T))}if(F<q)return;let R=_.tuple(...D).map(MZ);if(k8($)){let[C,...E]=$,a=X.elements.length===0?K:W,L=Math.max(0,B-N-E.length),w=L===0?void 0:C.arbitrary.terminal(_,W,H);if(L>0&&w===void 0)return;let A=L===0?_.constant([]):QR(_,{...a,constraint:{...a.constraint,minLength:L}},w,!0);if(R=Q$(_,R,J,A),E.length>0){let x=[];for(let x0 of E){let f0=x0.arbitrary.terminal(_,W,H);if(f0===void 0)return;x.push(f0)}let n=_.tuple(...x);R=Q$(_,R,J,n)}}return R};return R9((_,K,H)=>{let W=SQ(K),D=Q.map(({ast:N,arbitrary:B})=>{let z=B(_,W,H);return l0(N)?z.chain((q)=>_.boolean().map((F)=>F?T(q):d())):z.map(T)}),U=_.tuple(...D).map(MZ);if(k8($)){let[N,...B]=$.map(({arbitrary:q})=>q(_,W,H)),z=QR(_,X.elements.length===0?K:W,N);if(U=Q$(_,U,J,z),B.length>0){let q=_.tuple(...B);U=Q$(_,U,J,q)}}if(K.recursion){let N=G(_,K,H);if(N!==void 0)return _.oneof(K.recursion,N,U)}return U},G)}case"Objects":{let Q=X.propertySignatures.map((G)=>({ps:G,arbitrary:jX(G.type,[...Y,G.name])})),J=X.indexSignatures.map((G)=>({is:G,parameter:jX(G.parameter,Y),type:jX(G.type,Y)}));return R9((G,_,K)=>{let H=SQ(_),W={},D=[],U=[],N=[];for(let{ps:F,arbitrary:R}of Q){let C=F.name;if(D.push(C),l0(F.type))N.push(C);else U.push(C);k(W,C,R(G,H,K))}let B=_.constraint;if(N.length>0&&J.length===0&&B!==void 0&&(B.minLength!==void 0||B.maxLength!==void 0))return au(G,W,D,U,N,B);let z=G.record(W,{requiredKeys:U}),q=ZR(X,_.constraint,U.length);for(let{parameter:F,type:R}of J){let C=G.tuple(F(G,H,K),R(G,H,K)),E=UH(G,C,q,YR);z=JR(z,E)}return z},(G,_,K)=>{let H=SQ(_),W={},D=[],U=[];for(let{ps:F,arbitrary:R}of Q){let C=F.name,E=R.terminal(G,H,K);if(l0(F.type)){if(E!==void 0)U.push([C,E]);continue}if(E===void 0)return;D.push(C),k(W,C,E)}let N=Math.max(0,(_.constraint?.minLength??0)-D.length);for(let[F,R]of U){if(N===0)break;N--,D.push(F),k(W,F,R)}if(N>0&&X.indexSignatures.length===0)return;let B=G.record(W,{requiredKeys:D}),z=ZR(X,_.constraint,D.length),q=z?.minLength??0;for(let{parameter:F,type:R}of J){let C;if(q===0)C=G.constant([]);else{let E=F.terminal(G,H,K),a=R.terminal(G,H,K);if(E===void 0||a===void 0)return;C=UH(G,G.tuple(E,a),{...z,maxLength:q},YR)}B=JR(B,C)}return B})}case"Union":{let Q=X.types.map(($)=>jX($,Y)),J=($,G,_)=>KR($,Q.map((K)=>K.terminal($,G,_)).filter(V1));return R9(($,G,_)=>{let K=Q.map((W)=>W($,G,_));if(G.recursion){let W=J($,G,_);if(W!==void 0)return $.oneof(G.recursion,W,...K)}let H=KR($,K);if(H===void 0)throw D8("a union with no members");return H},J)}case"Suspend":{let Q=tF.get(X);if(Q)return Q;let J=_5(()=>jX(X.thunk(),Y)),$=R9((G,_,K)=>{let H=_R(G,X),W={..._,recursion:H},D=K.includes(X)?K:[...K,X],U=J().terminal(G,W,D);if(U===void 0)throw C6("Unable to derive an arbitrary for a recursive schema without a finite generation path",Y);return G.oneof(H,U,G.constant(null).chain(()=>J()(G,W,D)))},(G,_,K)=>{if(K.includes(X))return;let H=_R(G,X);return J().terminal(G,{..._,recursion:H},[...K,X])});return tF.set(X,$),$}}}var qR=X1((X)=>{return Q4(X,[])});function Q4(X,Y){let Q=H8(X)?.toEquivalence;if(Q)return Q($5(X)?X.typeParameters.map((J)=>Q4(J,Y)):[]);switch(X._tag){case"Never":return qN();case"Declaration":case"Null":case"Undefined":case"Void":case"Unknown":case"Any":case"String":case"Number":case"Boolean":case"BigInt":case"Symbol":case"Literal":case"UniqueSymbol":case"ObjectKeyword":case"Enum":case"TemplateLiteral":return o;case"Arrays":{let J=X.elements.map((_,K)=>Q4(_,[...Y,K])),$=X.elements.length,G=X.rest.map((_,K)=>Q4(_,[...Y,$+K]));return D1((_,K)=>{if(!Array.isArray(_)||!Array.isArray(K))return!1;let H=_.length;if(H!==K.length)return!1;let W=0;for(;W<Math.min(H,X.elements.length);W++)if(!J[W](_[W],K[W]))return!1;if(G.length>0){let[D,...U]=G;for(;W<H-U.length;W++)if(!D(_[W],K[W]))return!1;for(let N=0;N<U.length;N++)if(!U[N](_[W+N],K[W+N]))return!1}return!0})}case"Objects":{if(X.propertySignatures.length===0&&X.indexSignatures.length===0)return o;let J=X.propertySignatures.map((G)=>Q4(G.type,[...Y,G.name])),$=X.indexSignatures.map((G)=>Q4(G.type,Y));return D1((G,_)=>{if(!x1(G)||!x1(_))return!1;for(let K=0;K<J.length;K++){let H=X.propertySignatures[K],W=H.name,D=Object.hasOwn(G,W),U=Object.hasOwn(_,W);if(l0(H.type)){if(D!==U)return!1}if(D&&U&&!J[K](G[W],_[W]))return!1}for(let K=0;K<$.length;K++){let H=X.indexSignatures[K],W=z9(G,H.parameter),D=z9(_,H.parameter);if(W.length!==D.length)return!1;for(let U=0;U<W.length;U++){let N=W[U];if(!Object.hasOwn(_,N)||!$[K](G[N],_[N]))return!1}}return!0})}case"Union":{let J=T1(X).types,$=new Map(J.map((G,_)=>[G,[jQ(G),Q4(X.types[_],Y)]]));return D1((G,_)=>{let K=FQ(G,J);for(let H=0;H<K.length;H++){let[W,D]=$.get(K[H]);if(W(G)&&W(_))return D(G,_)}return!1})}case"Suspend":{let J=_5(()=>Q4(X.thunk(),Y));return D1(($,G)=>J()($,G))}}}function $$(X){return X.replace(/~/g,"~0").replace(/\//g,"~1")}function LR(X){return X.replace(/~1/g,"/").replace(/~0/g,"~")}var eG0=globalThis.RegExp;var A9=(X)=>X.replace(/[/\\^$*+?.()|[\]{}]/g,"\\$&");var Wc=new Set([...vO,_Q,...xO]);function vQ(X,Y){if(X===void 0)return;let Q={},J=X.title;if(typeof J==="string")Q.title=J;let{description:$,expected:G}=X;if(typeof $==="string")Q.description=$;else if(Y?.generateDescriptions===!0&&typeof G==="string")Q.description=G;let _=X.default;if(O9(_))Q.default=_;let K=X.examples;if(Array.isArray(K)&&O9(K))Q.examples=K;let H=X.readOnly;if(typeof H==="boolean")Q.readOnly=H;let W=X.writeOnly;if(typeof W==="boolean")Q.writeOnly=W;let D=X.format;if(typeof D==="string")Q.format=D;let U=X.contentEncoding;if(typeof U==="string")Q.contentEncoding=U;let N=X.contentMediaType;if(typeof N==="string")Q.contentMediaType=N;let B=X.contentSchema;if(O9(B))Q.contentSchema=B;if(Y?.includeAnnotationKey!==void 0)for(let[z,q]of Object.entries(X)){if(Wc.has(z)||!Y.includeAnnotationKey(z))continue;if(O9(q))k(Q,z,q)}return Object.keys(Q).length===0?void 0:Q}function TR(X){let Y=X.type==="number"||X.type==="integer"?X.type:void 0,Q=X;if(Y!==void 0)Q={...X},delete Q.type;if(Array.isArray(Q.allOf)){let J=[],$=!1;for(let G of Q.allOf){let _=TR(G);if(_.type!==void 0){if($=!0,Y===void 0||_.type==="integer")Y=_.type}if(Object.keys(_.schema).length>0)J.push(_.schema)}if($){let{allOf:G,..._}=Q;Q=J.length===0?_:{..._,allOf:J}}}return{type:Y,schema:Q}}function Uc(X){return Array.isArray(X.anyOf)&&X.anyOf.length===4&&X.anyOf[0]?.type==="number"&&X.anyOf.slice(1).every((Y)=>Y.type==="string")}function G$(X,Y){if(Object.keys(X).length===0)return Y;let Q=Object.keys(Y);if(Q.length===0)return X;let J=X.type==="number"||X.type==="integer"?X.type:void 0,$=Uc(X);if(J!==void 0||$){let _=TR(Y);if(_.type!==void 0){let K=J==="integer"||_.type==="integer"?"integer":"number",H={...X,type:K};if($)delete H.anyOf;return Object.keys(_.schema).length===0?H:G$(H,_.schema)}}let G=Array.isArray(Y.allOf)&&Q.length===1?Y.allOf:[Y];if(Array.isArray(X.allOf))return{...X,allOf:[...X.allOf,...G]};if(typeof X.$ref==="string")return{allOf:[X,...G]};return{...X,allOf:G}}function Dc(X,Y,Q,J){let $={};for(let U of Object.keys(Q))k($,U,H(Q[U],["references",U]));return{dialect:"draft-2020-12",schemas:V6(X,(U,N)=>H(U,Y[N])),definitions:$};function _(U,N){return U?.schemas?.map((B,z)=>H(B,[...N,"schemas",z]))??[]}function K(U,N,B){let z=U.annotations,q=z?.toJsonSchema;if(q!==void 0){let C=_(U.representation,[...B,"representation"]),E=q({type:N,schemas:C}),a=vQ(z,J);return a===void 0?E:{...E,...a}}if(U._tag==="Filter")return;let F=U.checks.map((C,E)=>K(C,N,[...B,"checks",E])).filter((C)=>C!==void 0);if(F.length===0)return;let R=vQ(z,J);return R===void 0?{allOf:F}:{allOf:F,...R}}function H(U,N){if(U._tag==="Reference"){if(!Object.hasOwn(Q,U.$ref))throw C6(`Invalid reference ${U.$ref}`,[...N,"$ref"]);return{$ref:`#/$defs/${$$(U.$ref)}`}}let B=W(U,N),z=vQ(U.annotations,J);if(z!==void 0)B={...B,...z};for(let q=0;q<U.checks.length;q++){let F=typeof B.type==="string"&&Nc(B.type)?B.type:void 0,R=K(U.checks[q],F,[...N,"checks",q]);if(R!==void 0)B=G$(B,R)}return B}function W(U,N){switch(U._tag){case"Any":case"Unknown":return{};case"ObjectKeyword":return{anyOf:[{type:"object"},{type:"array"}]};case"Void":case"Undefined":case"Null":return{type:"null"};case"BigInt":return{type:"string",allOf:[{pattern:"^-?\\d+$"}]};case"Symbol":case"UniqueSymbol":return{type:"string",allOf:[{pattern:"^Symbol\\((.*)\\)$"}]};case"Declaration":return{};case"Suspend":return H(U.thunk,[...N,"thunk"]);case"Never":return{not:{}};case"String":return{type:"string"};case"Number":return{anyOf:[{type:"number"},{type:"string",enum:["NaN"]},{type:"string",enum:["Infinity"]},{type:"string",enum:["-Infinity"]}]};case"Boolean":return{type:"boolean"};case"Literal":{let B=U.literal;return typeof B==="bigint"?{type:"string",enum:[globalThis.String(B)]}:{type:typeof B,enum:[B]}}case"Enum":{let B=U.enums.map(([z,q])=>typeof q==="number"&&!globalThis.Number.isFinite(q)?{type:"string",enum:[globalThis.String(q)],title:z}:{type:typeof q,enum:[q],title:z});return B.length===0?{not:{}}:{anyOf:B}}case"TemplateLiteral":return{type:"string",pattern:`^${U.parts.map(Z$).join("")}$`};case"Arrays":{if(U.rest.length>1)throw C6("Invalid schema representation document",[...N,"rest"]);let B={type:"array"},z=U.elements.length,q=U.elements.map((F,R)=>{if(F.isOptional)z--;let C=H(F.type,[...N,"elements",R,"type"]),E=vQ(F.annotations,J);return E===void 0?C:G$(C,E)});if(q.length>0){if(B.prefixItems=q,B.maxItems=U.elements.length,z>0)B.minItems=z}else B.items=!1;if(U.rest.length===1){delete B.maxItems;let F=H(U.rest[0],[...N,"rest",0]);if(Object.keys(F).length>0)B.items=F;else delete B.items}return B}case"Objects":{if(U.propertySignatures.length===0&&U.indexSignatures.length===0)return{anyOf:[{type:"object"},{type:"array"}]};let B={type:"object"},z={},q=[];for(let R=0;R<U.propertySignatures.length;R++){let C=U.propertySignatures[R];if(typeof C.name!=="string")throw C6("Invalid schema representation document",[...N,"propertySignatures",R,"name"]);let E=C.name,a=H(C.type,[...N,"propertySignatures",R,"type"]),L=vQ(C.annotations,J);if(k(z,E,L===void 0?a:G$(a,L)),!C.isOptional)q.push(E)}if(U.propertySignatures.length>0)B.properties=z;if(q.length>0)B.required=q;B.additionalProperties=J?.additionalProperties??!1;let F={};for(let R=0;R<U.indexSignatures.length;R++){let C=U.indexSignatures[R],E=H(C.type,[...N,"indexSignatures",R,"type"]);if(Object.keys(E).length===1&&"not"in E)E=!1;let a=D(C.parameter,[...N,"indexSignatures",R,"parameter"],new Set);if(a.length===0)B.additionalProperties=E;else for(let L of a)k(F,L,E)}if(Object.keys(F).length>0)B.patternProperties=F,delete B.additionalProperties;if(typeof B.additionalProperties==="object"&&B.additionalProperties!==null&&Object.keys(B.additionalProperties).length===0)delete B.additionalProperties;return B}case"Union":{let B=U.types.map((z,q)=>H(z,[...N,"types",q]));if(B.length===0)return{not:{}};if(B.length>1){let z=Bc(B);if(z!==void 0)return z}return U.mode==="anyOf"?{anyOf:B}:{oneOf:B}}}}function D(U,N,B){switch(U._tag){case"Reference":{if(!Object.hasOwn(Q,U.$ref))throw C6(`Invalid reference ${U.$ref}`,[...N,"$ref"]);if(B.has(U.$ref))return[];let z=new Set(B).add(U.$ref);return D(Q[U.$ref],["references",U.$ref],z)}case"String":return FR(H(U,N));case"TemplateLiteral":return[`^${U.parts.map(Z$).join("")}$`];case"Union":return U.types.flatMap((z,q)=>D(z,[...N,"types",q],B));default:throw C6("Invalid schema representation document",N)}}}function Nc(X){return X==="string"||X==="number"||X==="boolean"||X==="array"||X==="object"||X==="null"||X==="integer"}function Bc(X){let Y=void 0,Q=[];for(let J of X){if(Object.keys(J).length!==2||J.type===void 0||!Array.isArray(J.enum)||J.enum.length===0)return;if(Y===void 0)Y=J.type;else if(J.type!==Y)return;Q.push(...J.enum)}return{type:Y,enum:Q}}function FR(X){let Y=[];if(typeof X.pattern==="string")Y.push(X.pattern);for(let Q of["allOf","anyOf","oneOf"]){let J=X[Q];if(Array.isArray(J)){for(let $ of J)if(typeof $==="object"&&$!==null&&!Array.isArray($))Y.push(...FR($))}}return Y}function Z$(X){switch(X._tag){case"Literal":return A9(globalThis.String(X.literal));case"String":return CF;case"Number":return bJ;case"TemplateLiteral":return X.parts.map(Z$).join("");case"Union":return X.types.map(Z$).join("|");default:throw C6("Invalid schema representation document",[])}}function RR(X,Y){let Q=Dc([X.representation],[["representation"]],X.references,Y);return{dialect:Q.dialect,schema:Q.schemas[0],definitions:Q.definitions}}function NH(X){let{references:Y,representations:Q}=zc([X]);return{representation:Q[0],references:Y}}function zc(X){return qc(X,[])}function sX(X){return X===void 0?void 0:{annotations:X}}function wR(X){return qQ(X)||bK(X)||LQ(X)&&X.types.some(wR)}function AR(X){let Y=r8(X);if(Y!==void 0)return{identifier:Y,isFallback:!1};let Q=LJ(X);return Q===void 0?void 0:{identifier:`${Q}JsonEncoding`,isFallback:!0}}function PR(X,Y){if(X===Y)return!0;let Q=Reflect.ownKeys(X),J=Reflect.ownKeys(Y);if(Q.length!==J.length)return!1;for(let $ of Q)if($!=="context"&&X[$]!==Y[$])return!1;return!0}function qc(X,Y){let Q={},J=new Map,$=[],G=new Map,_=new Set(Y.map((L)=>L.key)),K=new Set,H=new Set,W=new Set;for(let L of Y)G.set(L.key,L.body),J.set(L.original,L.key),J.set(L.encoded,L.key);for(let L of X)N(L);for(let L of Y)N(L.body);let D=V6(X,(L)=>z(L));for(let L of Y)k(Q,L.key,z(L.body,L.key));return{representations:D,references:Q};function U(L,w){let A=L,x=0;while(G.has(A))A=`${L}${++x}`;return G.set(A,w),A}function N(L){let w=a8(L);if(H.has(w)){if(wR(w))W.add(w);return}H.add(w);let A=AR(w);if(A!==void 0&&!A.isFallback){let x=G.get(A.identifier);if(x===void 0)G.set(A.identifier,w);else if(J.get(w)!==A.identifier&&!PR(x,w))throw Error(`Duplicate identifier: ${JSON.stringify(A.identifier)}`)}switch(B(w.checks),w._tag){case"Declaration":case"Arrays":case"Objects":case"Union":w.recur((x)=>{return N(x),x});break;case"TemplateLiteral":w.parts.forEach(N);break;case"Suspend":N(w.thunk());break}}function B(L){L?.forEach((w)=>{if(w.annotations?.representation?.schemas?.forEach((A)=>N(T1(A))),w._tag==="FilterGroup")B(w.checks)})}function z(L,w){let A=J.get(L);if(A!==void 0&&A!==w)return{_tag:"Reference",$ref:A};let x=a8(L);if(x!==L)return z(x,w);let n=w===void 0?AR(L):void 0;if(n!==void 0){let V0=q(n,L);if(J.set(L,V0),!Object.hasOwn(Q,V0)&&!_.has(V0))k(Q,V0,F(L));return{_tag:"Reference",$ref:V0}}if(w===void 0&&W.has(L)){let V0=U(`${L._tag}_`,L);return J.set(L,V0),k(Q,V0,F(L)),{_tag:"Reference",$ref:V0}}if(K.has(L)){let V0=U(`${L._tag}_`,L);return J.set(L,V0),{_tag:"Reference",$ref:V0}}K.add(L);let x0=F(L);K.delete(L);let f0=J.get(L);if(f0!==void 0&&f0!==w)return k(Q,f0,x0),{_tag:"Reference",$ref:f0};return x0}function q(L,w){if(!L.isFallback)return L.identifier;for(let[x,n]of $)if(PR(x,w))return n;let A=U(L.identifier,w);return $.push([w,A]),A}function F(L){let w=R(L.checks);switch(L._tag){case"Declaration":return{_tag:"Declaration",typeParameters:L.typeParameters.map((A)=>z(A)),checks:w,...E(L.annotations)};case"Null":case"Undefined":case"Void":case"Never":case"Unknown":case"Any":case"String":case"Boolean":case"Number":case"BigInt":case"Symbol":case"ObjectKeyword":return{_tag:L._tag,checks:w,...sX(L.annotations)};case"Literal":return{_tag:"Literal",literal:L.literal,checks:w,...sX(L.annotations)};case"UniqueSymbol":return{_tag:"UniqueSymbol",symbol:L.symbol,checks:w,...sX(L.annotations)};case"Enum":return{_tag:"Enum",enums:L.enums,checks:w,...sX(L.annotations)};case"TemplateLiteral":return{_tag:"TemplateLiteral",parts:L.parts.map((A)=>z(A)),checks:w,...sX(L.annotations)};case"Arrays":return{_tag:"Arrays",elements:L.elements.map((A)=>{let x=a8(A),n=x.context?.annotations;return{isOptional:l0(x),type:z(A),...sX(n)}}),rest:L.rest.map((A)=>z(A)),checks:w,...sX(L.annotations)};case"Objects":return{_tag:"Objects",propertySignatures:L.propertySignatures.map((A)=>{let x=a8(A.type),n=x.context?.annotations;return{name:A.name,type:z(A.type),isOptional:l0(x),isMutable:FF(x),...sX(n)}}),indexSignatures:L.indexSignatures.map((A)=>({parameter:z(A.parameter),type:z(A.type)})),checks:w,...sX(L.annotations)};case"Union":return{_tag:"Union",types:L.types.map((A)=>z(A)),mode:L.mode,checks:w,...sX(L.annotations)};case"Suspend":return{_tag:"Suspend",checks:[],thunk:z(L.thunk()),...sX(L.annotations)}}}function R(L){return L?.map(C)??[]}function C(L){switch(L._tag){case"Filter":return{_tag:"Filter",aborted:L.aborted,...a(L.annotations)};case"FilterGroup":return{_tag:"FilterGroup",checks:V6(L.checks,C),...a(L.annotations)}}}function E(L){if(L===void 0)return;let{representation:w,...A}=L;return{...w===void 0?void 0:{representation:w},...Object.keys(A).length===0?void 0:{annotations:A}}}function a(L){if(L===void 0)return;let{representation:w,...A}=L,x=w===void 0?void 0:w.schemas===void 0?w:{...w,schemas:w.schemas.map((n)=>z(T1(n)))};return{...x===void 0?void 0:{representation:x},...Object.keys(A).length===0?void 0:{annotations:A}}}}function _$(X,Y){if(Object.is(X,Y))return[];let Q=[];if(Array.isArray(X)&&Array.isArray(Y)){let J=X.length,$=Y.length,G=Math.min(J,$);for(let _=0;_<G;_++){let K=`/${_}`,H=_$(X[_],Y[_]);for(let W of H)CR(W,K),Q.push(W)}for(let _=J-1;_>=$;_--)Q.push({op:"remove",path:`/${_}`});for(let _=J;_<$;_++)Q.push({op:"add",path:`/${_}`,value:Y[_]});return Q}if(K$(X)&&K$(Y)){let J=Object.keys(X),$=Object.keys(Y),G=Array.from(new Set([...J,...$])).sort();for(let _ of G){let H=`/${$$(_)}`,W=Object.hasOwn(X,_),D=Object.hasOwn(Y,_);if(W&&D){let U=_$(X[_],Y[_]);for(let N of U)CR(N,H),Q.push(N)}else if(!W&&D)Q.push({op:"add",path:H,value:Y[_]});else if(W&&!D)Q.push({op:"remove",path:H})}return Q}return Q.push({op:"replace",path:"",value:Y}),Q}function MR(X,Y){let Q=Y;for(let J of X)switch(J.op){case"replace":{Q=J.path===""?J.value:ER(Q,J.path,J.value,"replace");break}case"add":{Q=Tc(Q,J.path,J.value);break}case"remove":{Q=ER(Q,J.path,void 0,"remove");break}}return Q}function CR(X,Y){X.path=X.path===""?Y:Y+X.path}function K$(X){return x1(X)}function Oc(X){if(X==="")return[];if(X.charCodeAt(0)!==47)throw Error(`Invalid JSON Pointer, it must start with "/": ${P(X)}`);return X.split("/").slice(1).map(LR)}function BH(X){if(!/^(0|[1-9]\d*)$/.test(X))throw Error(`Invalid array index: "${X}"`);return Number(X)}function Tc(X,Y,Q){if(Y==="")return Q;let J=jR(X,Y);if(J===null)throw Error(`Cannot add at "${Y}" (parent not found or not a container).`);let{lastToken:$,parent:G,stack:_}=J;if(Array.isArray(G)){let K=$==="-"?G.length:BH($);if(K<0||K>G.length)throw Error(`Array index out of bounds at "${Y}".`);let H=G.slice();return H.splice(K,0,Q),H$(_,H)}if(K$(G)){let K={...G};return k(K,$,Q),H$(_,K)}throw Error(`Cannot add at "${Y}" (parent not found or not a container).`)}function ER(X,Y,Q,J){if(Y===""){if(J==="remove"||Q===void 0)throw Error("Unsupported operation at the root");return Q}let $=jR(X,Y);if($===null)throw Error(`Cannot ${J} at "${Y}" (parent not found or not a container).`);let{lastToken:G,parent:_,stack:K}=$;if(Array.isArray(_)){if(G==="-")throw Error(`"-" is not valid for ${J} at "${Y}".`);let H=BH(G);if(H<0||H>=_.length)throw Error(`Array index out of bounds at "${Y}".`);let W=_.slice();if(J==="remove")W.splice(H,1);else W[H]=Q;return H$(K,W)}if(K$(_)){if(!Object.hasOwn(_,G))throw Error(`Property "${G}" does not exist at "${Y}".`);let H={..._};if(J==="remove")delete H[G];else k(H,G,Q);return H$(K,H)}throw Error(`Cannot ${J} at "${Y}" (parent not found or not a container).`)}function jR(X,Y){let Q=Oc(Y);if(Q.length===0)return null;let J=Q[Q.length-1],$=[],G=X;for(let _=0;_<Q.length-1;_++){let K=Q[_];if(G==null)return null;if(Array.isArray(G)){let H=BH(K);if(H<0||H>=G.length)return null;$.push({container:G,token:H}),G=G[H];continue}if(G&&typeof G==="object"){if(!Object.hasOwn(G,K))return null;$.push({container:G,token:K}),G=G[K];continue}return null}return{stack:$,parent:G,lastToken:J}}function H$(X,Y){let Q=Y;for(let J=X.length-1;J>=0;J--){let{container:$,token:G}=X[J];if(Array.isArray($)){let _=$.slice();_[G]=Q,Q=_}else{let _={...$};k(_,G,Q),Q=_}}return Q}var Rc=/^#\/\$defs(?=\/|$)/;function xR(X){return{dialect:"draft-07",schema:IR(X.schema),definitions:$3(X.definitions,IR)}}function IR(X){return Y(X);function Y(J){return Q(VH(J,($)=>$.replace(Rc,"#/definitions")),!0)}function Q(J,$){if(Array.isArray(J))return J.map((W)=>Q(W,!1));if(!x1(J))return J;let G=J,_={},K=void 0,H=void 0;for(let W of Object.keys(G)){let D=G[W];switch(W){case"$ref":case"type":case"required":case"enum":case"const":case"title":case"description":case"default":case"examples":case"format":case"pattern":case"minimum":case"maximum":case"exclusiveMinimum":case"exclusiveMaximum":case"minLength":case"maxLength":case"minItems":case"maxItems":case"minProperties":case"maxProperties":case"multipleOf":case"uniqueItems":_[W]=D;break;case"properties":case"patternProperties":{let U=Ac(D,Q);_[W]=U??D;break}case"additionalProperties":case"propertyNames":_[W]=Q(D,!1);break;case"allOf":case"anyOf":case"oneOf":_[W]=Array.isArray(D)?D.map((U)=>Q(U,!1)):D;break;case"prefixItems":K=D;break;case"items":H=D;break;default:break}}if(K!==void 0)if(Array.isArray(K)){if(_.items=K.map((W)=>Q(W,!1)),H!==void 0)_.additionalItems=Q(H,!1)}else _.items=Q(K,!1);else if(H!==void 0)_.items=Q(H,!1);return _}}function VH(X,Y){if(Array.isArray(X))return X.map((J)=>VH(J,Y));if(!x1(X))return X;let Q={};for(let J of Object.keys(X)){let $=X[J];if(J==="$ref")k(Q,J,typeof $==="string"?Y($):$);else if(Array.isArray($)||x1($))k(Q,J,VH($,Y));else k(Q,J,$)}return Q}function Ac(X,Y){if(!x1(X))return;let Q={};for(let J of Object.keys(X))k(Q,J,Y(X[J],!1));return Q}function vR(X,Y){return aX(new yR(X,Y))}function SR(X,Y){return aX(new qH(X,Y))}class kR{_tag="IdentityNode"}var bR=new kR;class gR{_tag="CompositionNode";nodes;constructor(X){this.nodes=X}}class yR{_tag="IsoNode";get;set;constructor(X,Y){this.get=X,this.set=Y}}class qH{_tag="LensNode";get;set;constructor(X,Y){this.get=X,this.set=Y}}class hR{_tag="PrismNode";get;set;constructor(X,Y){this.get=X,this.set=Y}}class LH{_tag="OptionalNode";get;set;constructor(X,Y){this.get=X,this.set=Y}}class OH{_tag="PathNode";path;constructor(X){this.path=X}}class U${_tag="CheckNode";checks;constructor(X){this.checks=X}}function wc(X,Y){let Q=X[X.length-1];if(Q){if(Q._tag==="PathNode"&&Y._tag==="PathNode"){X[X.length-1]=new OH([...Q.path,...Y.path]);return}if(Q._tag==="CheckNode"&&Y._tag==="CheckNode"){X[X.length-1]=new U$([...Q.checks,...Y.checks]);return}}X.push(Y)}function zH(X,Y){if(X._tag==="IdentityNode")return;if(X._tag==="CompositionNode"){for(let Q=0;Q<X.nodes.length;Q++)zH(X.nodes[Q],Y);return}wc(Y,X)}function H5(X,Y){let Q=[];switch(zH(X,Q),zH(Y,Q),Q.length){case 0:return bR;case 1:return Q[0];default:return new gR(Q)}}function Cc(X,Y){return aX(new LH(X,Y))}class kQ{node;getResult;replaceResult;constructor(X,Y,Q){this.node=X,this.getResult=Y,this.replaceResult=Q}replace(X,Y){return S8(this.replaceResult(X,Y),()=>Y)}modify(X){return(Y)=>S8(v8(this.getResult(Y),(Q)=>this.replaceResult(X(Q),Y)),()=>Y)}compose(X){return aX(H5(this.node,X.node))}key(X){return aX(H5(this.node,new OH([X])))}optionalKey(X){return aX(H5(this.node,new qH((Y)=>Y[X],(Y,Q)=>{let J=D$(Q);if(Y===void 0)if(Array.isArray(J)&&typeof X==="number")J.splice(X,1);else delete J[X];else k(J,X,Y);return J})))}check(...X){return aX(H5(this.node,new U$(X)))}refine(X,Y){return aX(H5(this.node,new U$([uJ(X,Y)])))}tag(X){return aX(H5(this.node,new hR((Y)=>Y._tag===X?m(Y):c(`Expected ${P(X)} tag, got ${P(Y._tag)}`),u)))}at(X,...Y){let Q=c(`Key ${P(X)} not found`);return aX(H5(this.node,new LH((J)=>Object.hasOwn(J,X)?m(J[X]):Q,(J,$)=>{if(Object.hasOwn($,X)){let G=D$($);return k(G,X,J),m(G)}else return Q})))}pick(X){return this.compose(SR(rF(X),(Y,Q)=>({...Q,...Y})))}omit(X){return this.compose(SR(nF(X),(Y,Q)=>({...Q,...Y})))}notUndefined(){return this.refine(V1,{expected:"a value other than `undefined`"})}forEach(X){let Y=X(N$());return Cc((Q)=>_X(this.getResult(Q),(J)=>{let $=[];for(let G=0;G<J.length;G++){let _=Y.getResult(J[G]);if(Y1(_))$.push(_.success)}return $}),(Q,J)=>v8(this.getResult(J),($)=>{let G=[];for(let K=0;K<$.length;K++)if(Y1(Y.getResult($[K])))G.push(K);if(Q.length!==G.length)return c(`each: replacement length mismatch: ${Q.length} !== ${G.length}`);let _=$.slice();for(let K=0;K<G.length;K++){let H=G[K],W=Y.replaceResult(Q[K],$[H]);if(J0(W))return c(`each: could not set element ${H}`);_[H]=W.success}return this.replaceResult(_,J)}))}modifyAll(X){return(Y)=>S8(v8(this.getResult(Y),(Q)=>this.replaceResult(Q.map(X),Y)),()=>Y)}}class mR extends kQ{get;set;constructor(X,Y,Q){super(X,(J)=>m(Y(J)),(J)=>m(Q(J)));this.get=Y,this.set=Q}replace(X,Y){return this.set(X)}modify(X){return(Y)=>this.set(X(this.get(Y)))}}class fR extends kQ{get;constructor(X,Y,Q){super(X,(J)=>m(Y(J)),(J,$)=>m(Q(J,$)));this.get=Y,this.replace=Q}modify(X){return(Y)=>this.replace(X(this.get(Y)),Y)}}class dR extends kQ{set;constructor(X,Y,Q){super(X,Y,(J,$)=>m(Q(J)));this.set=Q}replace(X,Y){return this.set(X)}modify(X){return(Y)=>S8(_X(this.getResult(Y),(Q)=>this.set(X(Q))),()=>Y)}}function aX(X){let Y=pR(X);switch(Y._tag){case"IsoNode":return new mR(X,Y.get,Y.set);case"LensNode":return new fR(X,Y.get,Y.set);case"PrismNode":return new dR(X,Y.get,Y.set);case"OptionalNode":return new kQ(X,Y.get,Y.set)}}function D$(X){if(Array.isArray(X))return X.slice();if(typeof X==="object"&&X!==null){let Y=Object.getPrototypeOf(X);if(Y!==Object.prototype&&Y!==null)throw Error("Cannot clone object with non-Object constructor or null prototype");return{...X}}return X}var pR=X1((X)=>{switch(X._tag){case"IdentityNode":return{_tag:"IsoNode",get:u,set:u};case"IsoNode":case"LensNode":case"PrismNode":case"OptionalNode":return{_tag:X._tag,get:X.get,set:X.set};case"PathNode":return{_tag:"LensNode",get:(Y)=>{let Q=X.path,J=Y;for(let $=0,G=Q.length;$<G;$++)J=J[Q[$]];return J},set:(Y,Q)=>{let J=X.path,$=D$(Q),G=$,_=0;for(;_<J.length-1;_++){let H=J[_];k(G,H,D$(G[H])),G=G[H]}let K=J[_];return k(G,K,Y),$}};case"CheckNode":return{_tag:"PrismNode",get:(Y)=>x4(jF(X.checks,Y),String),set:u};case"CompositionNode":{let Y=X.nodes.map(pR),Q=Y.reduce((J,$)=>Ec(J,$._tag),"IsoNode");return{_tag:Q,get:(J)=>{for(let $=0;$<Y.length;$++){let G=Y[$],_=G.get(J);if(W$(G._tag)){if(J0(_))return _;J=_.success}else J=_}return W$(Q)?m(J):J},set:(J,$)=>{let G=$,_=Y.length,K=Array(_+1);K[0]=$;for(let H=0;H<_;H++){let W=Y[H];if(W$(W._tag)){let D=W.get($);if(J0(D))return Q==="OptionalNode"?D:G;$=D.success}else $=W.get($);K[H+1]=$}for(let H=_-1;H>=0;H--){let W=Y[H];if(uR(W._tag))J=W.set(J);else if(W._tag==="LensNode")J=W.set(J,K[H]);else{let D=W.set(J,K[H]);if(J0(D))return D;J=D.success}}return Q==="OptionalNode"?m(J):J}}}}});function W$(X){return X==="PrismNode"||X==="OptionalNode"}function uR(X){return X==="IsoNode"||X==="PrismNode"}function Ec(X,Y){switch(X){case"IsoNode":return Y;case"LensNode":return W$(Y)?"OptionalNode":"LensNode";case"PrismNode":return uR(Y)?"PrismNode":"OptionalNode";case"OptionalNode":return"OptionalNode"}}var Mc=aX(bR);function N$(){return Mc}var m$={};k6(m$,{webUrl:()=>pt,webSegment:()=>IC,webQueryParameters:()=>SC,webPath:()=>xC,webFragments:()=>jC,webAuthority:()=>EC,uuid:()=>jt,uniqueArray:()=>B5,ulid:()=>Rt,uint8ClampedArray:()=>qC,uint8Array:()=>zC,uint32Array:()=>VC,uint16Array:()=>BC,tuple:()=>_0,toStringMethod:()=>Y6,subarray:()=>Nt,stringify:()=>s0,stringMatching:()=>je,string:()=>e0,stream:()=>_4,statistics:()=>Bi,sparseArray:()=>LC,shuffledSubarray:()=>Bt,set:()=>OC,schedulerFor:()=>Qe,scheduler:()=>Ye,scheduledModelRun:()=>et,sample:()=>Di,resetConfigureGlobal:()=>Vo,record:()=>KW,readConfigureGlobal:()=>X6,property:()=>Lo,pre:()=>cc,option:()=>z8,oneof:()=>K1,object:()=>ra,noShrink:()=>k$,noBias:()=>S$,nat:()=>G4,modelRun:()=>at,mixedCase:()=>Ca,memo:()=>Ta,maxSafeNat:()=>Bs,maxSafeInteger:()=>JC,mapToConstant:()=>S9,map:()=>HW,lorem:()=>za,limitShrink:()=>ge,letrec:()=>ZC,jsonValue:()=>AC,json:()=>ea,ipV6:()=>GC,ipV4Extended:()=>$C,ipV4:()=>gW,integer:()=>w0,int8Array:()=>NC,int32Array:()=>DC,int16Array:()=>UC,infiniteStream:()=>Qt,hash:()=>v$,hasToStringMethod:()=>OW,hasCloneMethod:()=>D5,hasAsyncToStringMethod:()=>TW,getDepthContextFor:()=>PW,gen:()=>Oi,func:()=>Ws,float64Array:()=>WC,float32Array:()=>HC,float:()=>XC,falsy:()=>ii,entityGraph:()=>Ka,emailAddress:()=>Ln,double:()=>y$,domain:()=>SW,dictionary:()=>MW,defaultReportMessage:()=>Rw,date:()=>vw,createDepthIdentifier:()=>wW,context:()=>ni,constantFrom:()=>M6,constant:()=>y0,configureGlobal:()=>Bo,compareFunc:()=>_s,compareBooleanFunc:()=>Gs,commands:()=>ot,cloneMethod:()=>H1,cloneIfNeeded:()=>M9,clone:()=>Gr,check:()=>ww,chainUntil:()=>kw,boolean:()=>iQ,bigUint64Array:()=>$e,bigInt64Array:()=>Je,bigInt:()=>K4,base64String:()=>Ht,asyncToStringMethod:()=>V8,asyncStringify:()=>FW,asyncProperty:()=>qo,asyncModelRun:()=>tt,asyncDefaultReportMessage:()=>Aw,assert:()=>Wi,array:()=>M0,anything:()=>RC,__version:()=>he,__type:()=>ye,__commitHash:()=>me,VerbosityLevel:()=>Oo,Value:()=>g,Stream:()=>K0,Random:()=>RW,PreconditionFailure:()=>H4,ExecutionStatus:()=>po,Arbitrary:()=>m0});var Ic=class X{constructor(Y){this.seed=Y}clone(){return new X(this.seed)}next(){let Y=this.seed,Q=Math.imul(Y,214013)+2531011|0,J=Math.imul(Y,-1443076087)+505908858|0,$=Math.imul(Y,1170746341)+-755606699|0;this.seed=$;let G=(Q&-2147483649)>>16,_=(J&-2147483649)>>16;return($&-2147483649)>>16|_<<15|G<<30}jump(){this.seed=Math.imul(this.seed,1994129409)+916127744&4294967295}getState(){return[this.seed]}};function cR(X){return new Ic(X)}var xc=class X{constructor(Y,Q){this.states=Y,this.index=Q}clone(){return new X(this.states.slice(),this.index)}next(){let Y=this.states[this.index];return Y^=Y>>>11,Y^=Y<<7&2636928640,Y^=Y<<15&4022730752,Y^=Y>>>18,this.index=B$(this.states,this.index),Y}getState(){return[this.index,...this.states]}jump(){let Y=this.states.slice(),Q=this.index;this.index=B$(this.states,this.index);for(let J=19932;J>0;--J){if("SUSgbA\\W`E[]KN2RUSo8XVU?HKBFRl11E\\KoWOg5B]XEWG;BE;1:oVK[`B^Z9Qd23^XTnhL>]Unda4f[X;_j9H5QD=cN<5H`3bW>9bk1mjoI2fK0obmAAINOV:>Mek_V9dd<hZ\\gC3?Fm7FEk07QH_3PLm^@?^i\\QMkgP<]oLHmFnlecg5F@7U^@4jhZ?WZS0k@GHehmM36:5^9;>Hmm`co>k:KOSkSbIINb1VFf>LXgP>GUAQTD>Ci>XMGkUflLlb?_FaFUk@?5N7i70@;1o68ah@I<HFH7R2^J:G][Gf962ITWID9GWK8ElD2G5=DcHcL]cA]P2n7A=[<bInM;IHDQnJMReRXDWbVldnGEIPij`E08Xdci3@0c:IBbD4:Nk]?lEN9j^;T`0blZX7eiWE8c`<ak7j05FZi>AjUDh?M1B?^??FAXKThf<aBOXZf7jXYGK>R<;NHk3S9YhM7STJ6`:MIE`S@7298X8W>PNK=@;lLX<i\\TXLL<W@X[X54H]in8M;;n?kkQbajgAMY=Tf9b;ZKf0QUB2FHYWfnfkDoU9YkcLd95T>lK6GM1YL\\lid:J>KYS=iJ]Y>QlF>?R5_[5QeYC=66;A32Ac>OHk_ne^0g>bK:g;KFPgbGUcPR_Z=TX3H9d03bKZ2IhEPKBo>LSGWd0iFdV8C<Y:<>T[O6lC\\blaZ>GoAYP4clf^j1IfnZJ]QeDe2X<HE[LJNWnaCg[P]Co^:IRbWPY?97UePBlZNNHY6LOBM8P>=h?Ye:_f_Sb9Ki5GDYBF4dWeMfdg^ccPllNWM7G1\\UMdoYeOOD5^e@foA22G?ADYo5:FVG[bWo96;>3kc_c1Ab30>30;1@4F8g2hY?DJ4[LOL;ZLLKo2]jo>[KMDUcR279N_kF=3WL@Dd620bMTdA\\U9k``ef2iD9JgJ8CZBHS>F^Uk;<laeaeHS<15OSeS`PcSSKBRBFY]aQ=EgUXGNg=?d56`KA@2BejY0^[_DCX`L=CGMT=BW^6S1i@2ATBVk>3_ocRA>2U:4GPQ6o>5jX2HIcV3S@On6KB<[SKB?FC_AAji9agbBFkAi\\;4I\\UJ]c36Ub@[;gQACVGY<V]SDJBUU]La\\_a@JdOO8gm2T0DJMa:8Hf7>E]noQ[1Kambn??QQ]S?1i0oMGOijb\\aGY6lQ^CJ?9bFle8<eH4UUjBINX;n8@VOA5ah^URV49B[A?ONHhHAC1J5;;h0SXYlG^0W=eJdHh^K4SGe=1HZLLam;D<Q3AOdbPcdX``82\\jo0En8jRVGC73WMCF9`d:0heS?80?C188cSn7H9<daZ]MgS4Pb^1HkA:1PU^5>^h_g[RQV@PnYBRI_]`B]Bh@Uk03eXGY`I16L76H28X`R>IROMeNVUdU[:lghLhPCQZ:4a<30YBZCYnXe[?;jc8gKI2QH2MjnWBm4nGCZW`aVU2a;P<AMI25mlW_Nm][2?b6o851X@lAm]YZ`bWRF1g<Ga:T]1NXH5Veja5P9S9>:aNg:Th1Y=5o78K>LQ8hW@5S?I83Lk5Xk;j5@I3o[d:4RjE^oS30:WP9gC\\i8aSI>QRE@4lP:7lDg8g2`Ql[2I8aBU\\BQ?B4_clL9Q]S;^e1Ob5[>3JER2`c7B=o]fPOWO<DGi;Niba1PoWPPE_Q3aX0OB0mZej\\f_M[J4Y6]1`h2MkF[GiW8Q^d3^_=<I1N2Q7]2<2j[iP7V3V821FaI]A`93bC^Z\\G=WJ;^Ih?B97_iIF@\\Dl<eK1je8SNTWo_=XFMZH<<JYLZ^YQMPgYOV45K_:]kSI8^XlO0]GY=VUfe_C_F6TOcoAlVUH:o=WhhT@K`2KFhe<3\\KXQ>W:M?S_4S5d@J^`[AGA7@3]DnGSCO`\\?E8HT75^d9\\:m\\m1egIfk8cd6bD9\\eU8\\n[Pb0Cgd^S0n9kGJHb]i5XodlKHc34Fhi9K>0U5WK`>7Ff2^KL=WC6:kc?e5C^a1T1:4:^S5flXlGNIj08AfO?Dh7T7dWO>E]NI9?ob7B7P_h[4TEP[EU;GllFTnSmg9:\\[N]<SAoKP_kPlG56A:I3T6EG8Hj=XnUE`KT5U@OQ?]7[N^MFN1_NU4KO_3::Le`8IL9[1Z1H1;V3SC\\N3]S@4U[F2mhT5dYM7[4Pg_Na0_8WTH0`bgceQS8]EG;XgD4Ib4iLTP@kE79Mn>AYRJA1U5^Blhgno:aHVYc03c3J0Vc9FjEV^M75Zfd8kVC9>iJDk`AJ[6f7DK2D^DL\\AX:6b5h31XH;RQB\\N<ZSM=J;6L[`UW^eOIFc1Y]6_dfedIe4ARh72mTXC0WND_IDHVCZRDE0eODARCEETQI5TPUQE=jEH5bS?LP[ai`F5ABRYDo2o\\@=]GT?_9;hc4Lm:\\SF9k1T<0E@fX9BG[]g0nY7k[Qmi@la8`PF0j6@Q?Ii7bLkXQ<lLHf]`:DCh@9JY5>hEVLTdhL\\b1EB0lLh<=WaO@F<;8g<d:@e:LA:cFIEdmQh7hNHfSRToW?8N4:Z1K;XEDRO;OIDh<UdVln?bjgL>?VE98[B\\K<BVjkG8LiSX;fb>jf?DUK00Aih<WY6QD6cEnHBZ8iN_fd<G8Ci`11RUW2QlW]IXV:m?;J0GXXHfGNQ>:D`=fLPbO?VOTEYLj^cNj5PM>jKB5HVjJ4U7lXaTQNL9<@\\1`m\\Ug@VQHd7>jW=ca0`miF7;N0F=GjoQ`RFchKMGTmn8cF@Oh4GGCm7m2`U9j93Tb>=kSERjE_J939F01I1;`<ijk_=_Vn=7RVAI6fnQI5KlF:C44bN<<8K=Z<2TP<1]5?<dB>^LA=ebloE2Y2:9lkh0\\<YKbHD97iE`<C5oj^1>X:??`H6BXF2hG1Q[dF0Q=>W=J?7C\\k1T?<;R44oW?1hY^G8Zm]ZKnfOf0eCFYo6?=D8?<`6HU5SXh1;=:23LmV_FSi;OJfV<^?GkIDPISeHg1LaGE:V3Y3K3H<QJfbY?=;ldZRhnhQT_mGXDLFXXhSONE6Do_0iNZagB:BPGOTH;VhHUTd6LhQm^[;dO]5Hlkg<R:F<Kn\\:I:EGojgWZ2X@SYO_dlH;G8S<>oEKabY`:oU;=JW7ig?S?EYb86b7n8ce\\]IRa]koiWY<RfO;5kUI;7lVeC?[@ZaXDiF04B8R]bg@>O<mQDoUcBLcf^f>m2kMBUloD>Ze@NN^Z11TM`inXYhE_I=kA`:ZF4d\\>`L@;ZP[`ENU5cL[BV6\\Z?Di76:jg3hE6oG6jFc8kP=[GS1;WSedYQW1:U4\\OF32GgmMC<AjO]872bdBb`bKAA?8j78b>T3VfcUB2m4J^CPRU;8dScI]LU]^bBYA5_3:Y0N5i^?200000".charCodeAt(J/6|0)-48&1<<J%6)lR(this.states,this.index,Y,Q);this.index=B$(this.states,this.index)}lR(this.states,this.index,Y,Q)}};function lR(X,Y,Q,J){let $=0;if(J>=Y){for(;$<624-J;$++)X[$+Y]^=Q[$+J];for(;$<624-Y;$++)X[$+Y]^=Q[$+J-624];for(;$<624;$++)X[$+Y-624]^=Q[$+J-624]}else{for(;$<624-Y;$++)X[$+Y]^=Q[$+J];for(;$<624-J;$++)X[$+Y-624]^=Q[$+J];for(;$<624;$++)X[$+Y-624]^=Q[$+J-624]}}function B$(X,Y){if(Y<227){let Q=X[Y]&2147483648|X[Y+1]&2147483647;return X[Y]=X[Y+397]^Q>>>1^-(Q&1)&2567483615,Y+1}else if(Y<623){let Q=X[Y]&2147483648|X[Y+1]&2147483647;return X[Y]=X[Y+397-624]^Q>>>1^-(Q&1)&2567483615,Y+1}else{let Q=X[Y]&2147483648|X[0]&2147483647;return X[Y]=X[396]^Q>>>1^-(Q&1)&2567483615,0}}function Sc(X){for(let Y=0;Y!==624;++Y)B$(X,Y)}function oR(X){let Y=[X|0];for(let Q=1;Q!==624;++Q){let J=Y[Q-1]^Y[Q-1]>>>30;Y.push(Math.imul(1812433253,J)+Q|0)}return Sc(Y),new xc(Y,0)}var vc=[1667051007,2321340297,1548169110,304075285],kc=class X{constructor(Y,Q,J,$){this.s01=Y,this.s00=Q,this.s11=J,this.s10=$}clone(){return new X(this.s01,this.s00,this.s11,this.s10)}next(){let Y=this.s00^this.s00<<23,Q=this.s01^(this.s01<<23|this.s00>>>9),J=this.s10,$=this.s11,G=this.s00+J|0;return this.s01=$,this.s00=J,this.s11=Q^$^Q>>>18^$>>>5,this.s10=Y^J^(Y>>>18|Q<<14)^(J>>>5|$<<27),G}jump(){let Y=0,Q=0,J=0,$=0,G=this.s01,_=this.s00,K=this.s11,H=this.s10;for(let W=0;W!==4;++W){let D=vc[W];for(let U=1;U;U<<=1){if(D&U)Y^=G,Q^=_,J^=K,$^=H;let N=_^_<<23,B=G^(G<<23|_>>>9);G=K,_=H,H=N^H^(N>>>18|B<<14)^(H>>>5|K<<27),K=B^K^B>>>18^K>>>5}}this.s01=Y,this.s00=Q,this.s11=J,this.s10=$}getState(){return[this.s01,this.s00,this.s11,this.s10]}};function TH(X){return new kc(-1,~X,X|0,0)}var bc=[3639956645,3750757012,1261568508,386426335],gc=class X{constructor(Y,Q,J,$){this.s01=Y,this.s00=Q,this.s11=J,this.s10=$}clone(){return new X(this.s01,this.s00,this.s11,this.s10)}next(){let Y=this.s00+this.s10|0,Q=this.s10^this.s00,J=this.s11^this.s01,$=this.s00,G=this.s01;return this.s00=$<<24^G>>>8^Q^Q<<16,this.s01=G<<24^$>>>8^J^(J<<16|Q>>>16),this.s10=J<<5^Q>>>27,this.s11=Q<<5^J>>>27,Y}jump(){let Y=0,Q=0,J=0,$=0,G=this.s01,_=this.s00,K=this.s11,H=this.s10;for(let W=0;W!==4;++W){let D=bc[W];for(let U=1;U;U<<=1){if(D&U)Y^=G,Q^=_,J^=K,$^=H;let N=H^_,B=K^G,z=_,q=G;_=z<<24^q>>>8^N^N<<16,G=q<<24^z>>>8^B^(B<<16|N>>>16),H=B<<5^N>>>27,K=N<<5^B>>>27}}this.s01=Y,this.s00=Q,this.s11=J,this.s10=$}getState(){return[this.s01,this.s00,this.s11,this.s10]}};function iR(X){return new gc(-1,~X,X|0,0)}function rR(X,Y){for(let Q=0;Q!==Y;++Q)X.next()}var nR=BigInt,yc=4294967296n;function aR(X,Y,Q){let J=Q-Y+1n,$=yc,G=1;while($<J)$<<=32n,++G;let _=sR(G,X);if(_<J)return _+Y;if(_+J<$)return _%J+Y;let K=$-$%J;while(_>=K)_=sR(G,X);return _%J+Y}function sR(X,Y){let Q=nR(Y.next()+2147483648);for(let J=1;J<X;++J){let $=Y.next();Q=(Q<<32n)+nR($+2147483648)}return Q}function bQ(X,Y){let Q=Y>2?~~(4294967296/Y)*Y:4294967296,J=X.next()+2147483648;while(J>=Q)J=X.next()+2147483648;return J%Y}function FH(X,Y){if(Y<0){let Q=-Y;X.sign=-1,X.data[0]=~~(Q/4294967296),X.data[1]=Q>>>0}else X.sign=1,X.data[0]=~~(Y/4294967296),X.data[1]=Y>>>0;return X}function hc(X,Y,Q){let J=Y.data[1],$=Y.data[0],G=Y.sign,_=Q.data[1],K=Q.data[0],H=Q.sign;if(X.sign=1,G===1&&H===-1){let q=J+_,F=$+K+(q>4294967295?1:0);return X.data[0]=F>>>0,X.data[1]=q>>>0,X}let W=J,D=$,U=_,N=K;if(G===-1)W=_,D=K,U=J,N=$;let B=0,z=W-U;if(z<0)B=1,z=z>>>0;return X.data[0]=D-N-B,X.data[1]=z,X}function mc(X,Y,Q){let J=Q[0]+1;Y[0]=bQ(X,J),Y[1]=bQ(X,4294967296);while(Y[0]>=Q[0]&&(Y[0]!==Q[0]||Y[1]>=Q[1]))Y[0]=bQ(X,J),Y[1]=bQ(X,4294967296);return Y}var fc=Number.MAX_SAFE_INTEGER,dc={sign:1,data:[0,0]},pc={sign:1,data:[0,0]},tR={sign:1,data:[0,0]},RH=[0,0];function uc(X,Y,Q,J){let $=J<=fc?FH(tR,J):hc(tR,FH(dc,Q),FH(pc,Y));if($.data[1]===4294967295)$.data[0]+=1,$.data[1]=0;else $.data[1]+=1;return mc(X,RH,$.data),RH[0]*4294967296+RH[1]+Y}function V$(X,Y,Q){let J=Q-Y;if(J<=4294967295)return bQ(X,J+1)+Y;return uc(X,Y,Q,J)}var eR=Symbol.for("fast-check/PreconditionFailure"),H4=class extends Error{constructor(X=!1){super();this.interruptExecution=X,this.footprint=eR}static isFailure(X){return X!==null&&X!==void 0&&X.footprint===eR}};function cc(X){if(!X)throw new H4}var lc=class{[Symbol.iterator](){return this}next(X){return{value:X,done:!0}}},oc=new lc;function ic(){return oc}function*rc(X,Y){for(let Q of X)yield Y(Q)}function*nc(X,Y){for(let Q of X)yield*Y(Q)}function*sc(X,Y){for(let Q of X)if(Y(Q))yield Q}function*ac(X,Y){for(let Q=0;Q<Y;++Q){let J=X.next();if(J.done)break;yield J.value}}function*tc(X,Y){let Q=X.next();while(!Q.done&&Y(Q.value))yield Q.value,Q=X.next()}function*ec(X,Y){for(let Q=X.next();!Q.done;Q=X.next())yield Q.value;for(let Q of Y)for(let J=Q.next();!J.done;J=Q.next())yield J.value}var Xl=Symbol.iterator,K0=class X{static nil(){return new X(ic())}static of(...Y){return new X(Y[Xl]())}constructor(Y){this.g=Y}next(){return this.g.next()}[Symbol.iterator](){return this.g}map(Y){return new X(rc(this.g,Y))}flatMap(Y){return new X(nc(this.g,Y))}dropWhile(Y){let Q=!1;function*J($){if(Q||!Y($))Q=!0,yield $}return this.flatMap(J)}drop(Y){if(Y<=0)return this;let Q=0;function J(){return Q++<Y}return this.dropWhile(J)}takeWhile(Y){return new X(tc(this.g,Y))}take(Y){return new X(ac(this.g,Y))}filter(Y){return new X(sc(this.g,Y))}every(Y){for(let Q of this.g)if(!Y(Q))return!1;return!0}has(Y){for(let Q of this.g)if(Y(Q))return[!0,Q];return[!1,null]}join(...Y){return new X(ec(this.g,Y))}getNthOrLast(Y){let Q=Y,J=null;for(let $ of this.g){if(Q--===0)return $;J=$}return J}};function _4(X){return new K0(X)}var H1=Symbol.for("fast-check/cloneMethod");function D5(X){return X!==null&&(typeof X==="object"||typeof X==="function")&&H1 in X&&typeof X[H1]==="function"}function M9(X){return D5(X)?X[H1]():X}var Yl=Object.defineProperty,g=class{constructor(X,Y,Q){if(this.value_=X,this.context=Y,this.hasToBeCloned=Q!==void 0||D5(X),this.readOnce=!1,this.value=X,this.hasToBeCloned)Yl(this,"value",{get:Q!==void 0?Q:this.getValue,enumerable:!1,configurable:!1})}getValue(){if(this.hasToBeCloned){if(!this.readOnce)return this.readOnce=!0,this.value_;return this.value_[H1]()}return this.value_}},m0=class{filter(X){return new $l(this,X)}map(X,Y){return new Jl(this,X,Y)}chain(X){return new Ql(this,X)}},Ql=class extends m0{constructor(X,Y){super();this.arb=X,this.chainer=Y}generate(X,Y){let Q=X.clone(),J=this.arb.generate(X,Y);return this.valueChainer(J,X,Q,Y)}canShrinkWithoutContext(X){return!1}shrink(X,Y){if(this.isSafeContext(Y))return(!Y.stoppedForOriginal?this.arb.shrink(Y.originalValue,Y.originalContext).map((Q)=>this.valueChainer(Q,Y.clonedMrng.clone(),Y.clonedMrng,Y.originalBias)):K0.nil()).join(Y.chainedArbitrary.shrink(X,Y.chainedContext).map((Q)=>{let J={...Y,chainedContext:Q.context,stoppedForOriginal:!0};return new g(Q.value_,J)}));return K0.nil()}valueChainer(X,Y,Q,J){let $=this.chainer(X.value_),G=$.generate(Y,J),_={originalBias:J,originalValue:X.value_,originalContext:X.context,stoppedForOriginal:!1,chainedArbitrary:$,chainedContext:G.context,clonedMrng:Q};return new g(G.value_,_)}isSafeContext(X){return X!==null&&X!==void 0&&typeof X==="object"&&"originalBias"in X&&"originalValue"in X&&"originalContext"in X&&"stoppedForOriginal"in X&&"chainedArbitrary"in X&&"chainedContext"in X&&"clonedMrng"in X}};function sP(X,Y){let Q=X.value,J=Y(Q);if(X.hasToBeCloned&&(typeof J==="object"&&J!==null||typeof J==="function")&&Object.isExtensible(J)&&!D5(J))Object.defineProperty(J,H1,{get:()=>()=>sP(X,Y)[0]});return[J,Q]}function XA(X,Y){let[Q,J]=sP(X,Y);return new g(Q,{originalValue:J,originalContext:X.context})}var Jl=class extends m0{constructor(X,Y,Q){super();this.arb=X,this.mapper=Y,this.unmapper=Q,this.bindValueMapper=(J)=>XA(J,Y)}generate(X,Y){let Q=this.arb.generate(X,Y);if(!Q.hasToBeCloned){let J=Q.value;return new g(this.mapper(J),{originalValue:J,originalContext:Q.context})}return XA(Q,this.mapper)}canShrinkWithoutContext(X){if(this.unmapper!==void 0)try{let Y=this.unmapper(X);return this.arb.canShrinkWithoutContext(Y)}catch{return!1}return!1}shrink(X,Y){if(this.isSafeContext(Y))return this.arb.shrink(Y.originalValue,Y.originalContext).map(this.bindValueMapper);if(this.unmapper!==void 0){let Q=this.unmapper(X);return this.arb.shrink(Q,void 0).map(this.bindValueMapper)}return K0.nil()}isSafeContext(X){return X!==null&&X!==void 0&&typeof X==="object"&&"originalValue"in X&&"originalContext"in X}},$l=class extends m0{constructor(X,Y){super();this.arb=X,this.refinement=Y,this.bindRefinementOnValue=(Q)=>this.refinementOnValue(Q)}generate(X,Y){while(!0){let Q=this.arb.generate(X,Y);if(this.refinementOnValue(Q))return Q}}canShrinkWithoutContext(X){return this.arb.canShrinkWithoutContext(X)&&this.refinement(X)}shrink(X,Y){return this.arb.shrink(X,Y).filter(this.bindRefinementOnValue)}refinementOnValue(X){return this.refinement(X.value)}};function aP(X){return typeof X==="object"&&X!==null&&"generate"in X&&"shrink"in X&&"canShrinkWithoutContext"in X}function tP(X){if(!aP(X))throw Error("Unexpected value received: not an instance of Arbitrary")}var eP=Function.prototype.apply,AH=Symbol("apply");function Gl(X){try{return X.apply}catch{return}}function Zl(X,Y,Q){let J=X;J[AH]=eP;let $=J[AH](Y,Q);return delete J[AH],$}function B0(X,Y,Q){if(Gl(X)===eP)return X.apply(Y,Q);return Zl(X,Y,Q)}var Xw=Array,b=BigInt,_l=BigInt64Array,Kl=BigUint64Array,Yw=Boolean,I$=Date,y=Error,Qw=Float32Array,Jw=Float64Array,Hl=Int8Array,Wl=Int16Array,Ul=Int32Array,N8=Number,d1=String,eX=Set,Dl=Uint8Array,Nl=Uint8ClampedArray,Bl=Uint16Array,Vl=Uint32Array,zl=encodeURIComponent,B8=Map,A$=Symbol,YA=Array.prototype.forEach,QA=Array.prototype.indexOf,JA=Array.prototype.join,$A=Array.prototype.map,GA=Array.prototype.flat,ZA=Array.prototype.filter,_A=Array.prototype.push,KA=Array.prototype.pop,HA=Array.prototype.splice,WA=Array.prototype.slice,UA=Array.prototype.sort,DA=Array.prototype.every;function ql(X){try{return X.forEach}catch{return}}function Ll(X){try{return X.indexOf}catch{return}}function Ol(X){try{return X.join}catch{return}}function Tl(X){try{return X.map}catch{return}}function Fl(X){try{return X.flat}catch{return}}function Rl(X){try{return X.filter}catch{return}}function Al(X){try{return X.push}catch{return}}function Pl(X){try{return X.pop}catch{return}}function wl(X){try{return X.splice}catch{return}}function Cl(X){try{return X.slice}catch{return}}function El(X){try{return X.sort}catch{return}}function Ml(X){try{return X.every}catch{return}}function $w(X,Y){if(ql(X)===YA)return X.forEach(Y);return B0(YA,X,[Y])}function fQ(X,...Y){if(Ll(X)===QA)return X.indexOf(...Y);return B0(QA,X,Y)}function h0(X,...Y){if(Ol(X)===JA)return X.join(...Y);return B0(JA,X,Y)}function L0(X,Y){if(Tl(X)===$A)return X.map(Y);return B0($A,X,[Y])}function jl(X,Y){if(Fl(X)===GA)return[].flat(),X.flat(Y);return B0(GA,X,[Y])}function Il(X,Y){if(Rl(X)===ZA)return X.filter(Y);return B0(ZA,X,[Y])}function I(X,...Y){if(Al(X)===_A)return X.push(...Y);return B0(_A,X,Y)}function Gw(X){if(Pl(X)===KA)return X.pop();return B0(KA,X,[])}function Zw(X,...Y){if(wl(X)===HA)return X.splice(...Y);return B0(HA,X,Y)}function _1(X,...Y){if(Cl(X)===WA)return X.slice(...Y);return B0(WA,X,Y)}function _w(X,...Y){if(El(X)===UA)return X.sort(...Y);return B0(UA,X,Y)}function Kw(X,...Y){if(Ml(X)===DA)return X.every(...Y);return B0(DA,X,Y)}var NA=Date.prototype.getTime,BA=Date.prototype.toISOString;function xl(X){try{return X.getTime}catch{return}}function Sl(X){try{return X.toISOString}catch{return}}function x$(X){if(xl(X)===NA)return X.getTime();return B0(NA,X,[])}function vl(X){if(Sl(X)===BA)return X.toISOString();return B0(BA,X,[])}var VA=Set.prototype.add,zA=Set.prototype.has;function kl(X){try{return X.add}catch{return}}function bl(X){try{return X.has}catch(Y){return}}function dQ(X,Y){if(kl(X)===VA)return X.add(Y);return B0(VA,X,[Y])}function $4(X,Y){if(bl(X)===zA)return X.has(Y);return B0(zA,X,[Y])}var qA=WeakMap.prototype.set,LA=WeakMap.prototype.get;function gl(X){try{return X.set}catch(Y){return}}function yl(X){try{return X.get}catch(Y){return}}function hl(X,Y,Q){if(gl(X)===qA)return X.set(Y,Q);return B0(qA,X,[Y,Q])}function ml(X,Y){if(yl(X)===LA)return X.get(Y);return B0(LA,X,[Y])}var OA=Map.prototype.set,TA=Map.prototype.get,FA=Map.prototype.has;function fl(X){try{return X.set}catch(Y){return}}function dl(X){try{return X.get}catch(Y){return}}function pl(X){try{return X.has}catch(Y){return}}function tX(X,Y,Q){if(fl(X)===OA)return X.set(Y,Q);return B0(OA,X,[Y,Q])}function VX(X,Y){if(dl(X)===TA)return X.get(Y);return B0(TA,X,[Y])}function ul(X,Y){if(pl(X)===FA)return X.has(Y);return B0(FA,X,[Y])}var RA=String.prototype.split,AA=String.prototype.startsWith,PA=String.prototype.endsWith,wA=String.prototype.substring,CA=String.prototype.toLowerCase,EA=String.prototype.toUpperCase,MA=String.prototype.padStart,jA=String.prototype.charCodeAt,IA=String.prototype.normalize,xA=String.prototype.replace;function cl(X){try{return X.split}catch{return}}function ll(X){try{return X.startsWith}catch{return}}function ol(X){try{return X.endsWith}catch{return}}function il(X){try{return X.substring}catch{return}}function rl(X){try{return X.toLowerCase}catch{return}}function nl(X){try{return X.toUpperCase}catch{return}}function sl(X){try{return X.padStart}catch{return}}function al(X){try{return X.charCodeAt}catch{return}}function tl(X){try{return X.normalize}catch(Y){return}}function el(X){try{return X.replace}catch{return}}function p1(X,...Y){if(cl(X)===RA)return X.split(...Y);return B0(RA,X,Y)}function Xo(X,...Y){if(ll(X)===AA)return X.startsWith(...Y);return B0(AA,X,Y)}function Yo(X,...Y){if(ol(X)===PA)return X.endsWith(...Y);return B0(PA,X,Y)}function u0(X,...Y){if(il(X)===wA)return X.substring(...Y);return B0(wA,X,Y)}function iH(X){if(rl(X)===CA)return X.toLowerCase();return B0(CA,X,[])}function VW(X){if(nl(X)===EA)return X.toUpperCase();return B0(EA,X,[])}function Qo(X,...Y){if(sl(X)===MA)return X.padStart(...Y);return B0(MA,X,Y)}function j9(X,Y){if(al(X)===jA)return X.charCodeAt(Y);return B0(jA,X,[Y])}function Jo(X,Y){if(tl(X)===IA)return X.normalize(Y);return B0(IA,X,[Y])}function $o(X,Y,Q){if(el(X)===xA)return X.replace(Y,Q);return B0(xA,X,[Y,Q])}var SA=Number.prototype.toString;function Go(X){try{return X.toString}catch{return}}function pQ(X,...Y){if(Go(X)===SA)return X.toString(...Y);return B0(SA,X,Y)}var Zo=Object.prototype.hasOwnProperty,_o=Object.prototype.toString;function Hw(X,Y){return B0(Zo,X,[Y])}function rH(X){return B0(_o,X,[])}var Ko=Error.prototype.toString;function Ho(X){return B0(Ko,X,[])}var Wo=class{constructor(X){this.producer=X}[Symbol.iterator](){if(this.it===void 0)this.it=this.producer();return this.it}next(){if(this.it===void 0)this.it=this.producer();return this.it.next()}};function Z4(X){return new Wo(X)}var Ww=Array.isArray,Uo=Object.defineProperty;function zW(X,Y,Q){return Uo(X,H1,{value:()=>{let J=[];for(let $=0;$!==Q.length;++$){let G=Q[$];if(G===void 0)G=new g(X[$],Y[$]);I(J,G.value)}return zW(J,Y,Q),J}})}function Uw(X,Y,Q){let J=[],$=Ww(Q)?Q:[];for(let G=0;G!==X.length;++G)I(J,Z4(()=>X[G].shrink(Y[G],$[G]).map((_)=>{let K=!1,H=[],W=[],D=[];for(let U=0;U!==X.length;++U){let N=U===G?_:new g(M9(Y[U]),$[U]);if(N.hasToBeCloned)K=!0,D[U]=N;I(H,N.value),I(W,N.context)}if(K)zW(H,W,D);return new g(H,W)})));return K0.nil().join(...J)}var Do=class extends m0{constructor(X){super();this.arbs=X;for(let Y=0;Y!==X.length;++Y){let Q=X[Y];if(Q===null||Q===void 0||Q.generate===null||Q.generate===void 0)throw Error(`Invalid parameter encountered at index ${Y}: expecting an Arbitrary`)}}generate(X,Y){let Q=!1,J=[],$=[],G=[];for(let _=0;_!==this.arbs.length;++_){let K=this.arbs[_].generate(X,Y);if(K.hasToBeCloned)Q=!0,G[_]=K;I(J,K.value),I($,K.context)}if(Q)zW(J,$,G);return new g(J,$)}canShrinkWithoutContext(X){if(!Ww(X)||X.length!==this.arbs.length)return!1;for(let Y=0;Y!==this.arbs.length;++Y)if(!this.arbs[Y].canShrinkWithoutContext(X[Y]))return!1;return!0}shrink(X,Y){return Uw(this.arbs,X,Y)}};function _0(...X){return new Do(X)}var No=Math.log;function Dw(X){return 2+~~(No(X+1)*0.4342944819032518)}var qW={};function Bo(X){qW=X}function X6(){return qW}function Vo(){qW={}}var uQ=Symbol("UndefinedContextPlaceholder");function I9(X){if(X.context!==void 0)return X;if(X.hasToBeCloned)return new g(X.value_,uQ,()=>X.value);return new g(X.value_,uQ)}var vA=()=>{},zo=class{constructor(X,Y){this.arb=X,this.predicate=Y;let{asyncBeforeEach:Q,asyncAfterEach:J,beforeEach:$,afterEach:G}=X6()||{};if(Q!==void 0&&$!==void 0)throw y(`Global "asyncBeforeEach" and "beforeEach" parameters can't be set at the same time when running async properties`);if(J!==void 0&&G!==void 0)throw y(`Global "asyncAfterEach" and "afterEach" parameters can't be set at the same time when running async properties`);this.beforeEachHook=Q||$||vA,this.afterEachHook=J||G||vA}isAsync(){return!0}generate(X,Y){return I9(this.arb.generate(X,Y!==void 0?Dw(Y):void 0))}shrink(X){if(X.context===void 0&&!this.arb.canShrinkWithoutContext(X.value_))return K0.nil();let Y=X.context!==uQ?X.context:void 0;return this.arb.shrink(X.value_,Y).map(I9)}async runBeforeEach(){await this.beforeEachHook()}async runAfterEach(){await this.afterEachHook()}async run(X){try{let Y=await this.predicate(X);return Y===void 0||Y===!0?null:{error:new y("Property failed by returning false")}}catch(Y){if(H4.isFailure(Y))return Y;return{error:Y}}}beforeEach(X){let Y=this.beforeEachHook;return this.beforeEachHook=()=>X(Y),this}afterEach(X){let Y=this.afterEachHook;return this.afterEachHook=()=>X(Y),this}},Nw=class extends m0{constructor(X){super();this.arb=X}generate(X,Y){return I9(this.arb.generate(X,Y))}canShrinkWithoutContext(X){return!0}shrink(X,Y){if(Y===void 0&&!this.arb.canShrinkWithoutContext(X))return K0.nil();let Q=Y!==uQ?Y:void 0;return this.arb.shrink(X,Q).map(I9)}};function qo(...X){if(X.length<2)throw Error("asyncProperty expects at least two parameters");let Y=_1(X,0,X.length-1),Q=X[X.length-1];return $w(Y,tP),new zo(_0(...L0(Y,(J)=>new Nw(J))),(J)=>Q(...J))}var kA=()=>{},Bw=class{constructor(X,Y){this.arb=X,this.predicate=Y;let{beforeEach:Q=kA,afterEach:J=kA,asyncBeforeEach:$,asyncAfterEach:G}=X6()||{};if($!==void 0)throw y(`"asyncBeforeEach" can't be set when running synchronous properties`);if(G!==void 0)throw y(`"asyncAfterEach" can't be set when running synchronous properties`);this.beforeEachHook=Q,this.afterEachHook=J}isAsync(){return!1}generate(X,Y){return I9(this.arb.generate(X,Y!==void 0?Dw(Y):void 0))}shrink(X){if(X.context===void 0&&!this.arb.canShrinkWithoutContext(X.value_))return K0.nil();let Y=X.context!==uQ?X.context:void 0;return this.arb.shrink(X.value_,Y).map(I9)}runBeforeEach(){this.beforeEachHook()}runAfterEach(){this.afterEachHook()}run(X){try{let Y=this.predicate(X);return Y===void 0||Y===!0?null:{error:new y("Property failed by returning false")}}catch(Y){if(H4.isFailure(Y))return Y;return{error:Y}}}beforeEach(X){let Y=this.beforeEachHook;return this.beforeEachHook=()=>X(Y),this}afterEach(X){let Y=this.afterEachHook;return this.afterEachHook=()=>X(Y),this}};function Lo(...X){if(X.length<2)throw Error("property expects at least two parameters");let Y=_1(X,0,X.length-1),Q=X[X.length-1];return $w(Y,tP),new Bw(_0(...L0(Y,(J)=>new Nw(J))),(J)=>Q(...J))}var Oo=function(X){return X[X.None=0]="None",X[X.Verbose=1]="Verbose",X[X.VeryVerbose=2]="VeryVerbose",X}({});function nH(X){if("unsafeNext"in X){if(X.unsafeJump===void 0)return{clone:()=>nH(X),next:()=>X.unsafeNext(),getState:()=>X.getState()};return{clone:()=>nH(X),next:()=>X.unsafeNext(),jump:()=>X.unsafeJump(),getState:()=>X.getState()}}return X}function Vw(X){if("jump"in X&&typeof X.jump==="function")return X;return{clone:()=>Vw(X),next:()=>X.next(),jump:()=>rR(X,42),getState:()=>X.getState()}}function g$(X){return Vw(nH(X))}var To=Date.now,Fo=Math.min,Ro=Math.random,Ao=class{constructor(X){let Y=X||{};this.seed=Po(Y),this.randomType=wo(Y),this.numRuns=Co(Y),this.verbose=Eo(Y),this.maxSkipsPerRun=Y.maxSkipsPerRun!==void 0?Y.maxSkipsPerRun:100,this.timeout=wH(Y.timeout),this.skipAllAfterTimeLimit=wH(Y.skipAllAfterTimeLimit),this.interruptAfterTimeLimit=wH(Y.interruptAfterTimeLimit),this.markInterruptAsFailure=Y.markInterruptAsFailure===!0,this.skipEqualValues=Y.skipEqualValues===!0,this.ignoreEqualValues=Y.ignoreEqualValues===!0,this.logger=Y.logger!==void 0?Y.logger:(Q)=>{console.log(Q)},this.path=Y.path!==void 0?Y.path:"",this.unbiased=Y.unbiased===!0,this.examples=Y.examples!==void 0?Y.examples:[],this.endOnFailure=Y.endOnFailure===!0,this.reporter=Y.reporter,this.asyncReporter=Y.asyncReporter,this.includeErrorInReport=Y.includeErrorInReport===!0}toParameters(){return{seed:this.seed,randomType:this.randomType,numRuns:this.numRuns,maxSkipsPerRun:this.maxSkipsPerRun,timeout:this.timeout,skipAllAfterTimeLimit:this.skipAllAfterTimeLimit,interruptAfterTimeLimit:this.interruptAfterTimeLimit,markInterruptAsFailure:this.markInterruptAsFailure,skipEqualValues:this.skipEqualValues,ignoreEqualValues:this.ignoreEqualValues,path:this.path,logger:this.logger,unbiased:this.unbiased,verbose:this.verbose,examples:this.examples,endOnFailure:this.endOnFailure,reporter:this.reporter,asyncReporter:this.asyncReporter,includeErrorInReport:this.includeErrorInReport}}};function PH(X){return(Y)=>{return g$(X(Y))}}function Po(X){if(X.seed===void 0)return To()^Ro()*4294967296;let Y=X.seed|0;if(X.seed===Y)return Y;return Y^(X.seed-Y)*4294967296}function wo(X){if(X.randomType===void 0)return TH;if(typeof X.randomType==="string")switch(X.randomType){case"mersenne":return PH(oR);case"congruential":case"congruential32":return PH(cR);case"xorshift128plus":return TH;case"xoroshiro128plus":return iR;default:throw Error(`Invalid random specified: '${X.randomType}'`)}let Y=X.randomType(0);if("min"in Y&&Y.min!==-2147483648)throw Error(`Invalid random number generator: min must equal -0x80000000, got ${String(Y.min)}`);if("max"in Y&&Y.max!==2147483647)throw Error(`Invalid random number generator: max must equal 0x7fffffff, got ${String(Y.max)}`);if(Y===g$(Y))return X.randomType;return PH(X.randomType)}function Co(X){if(X.numRuns!==void 0)return X.numRuns;if(X.num_runs!==void 0)return X.num_runs;return 100}function Eo(X){if(X.verbose===void 0)return 0;if(typeof X.verbose==="boolean")return X.verbose===!0?1:0;if(X.verbose<=0)return 0;if(X.verbose>=2)return 2;return X.verbose|0}function wH(X){if(X===void 0)return;return Fo(X,2147483647)}function LW(X){return new Ao(X)}function Mo(X,Y,Q){let J=null;return{clear:()=>Q(J),promise:new Promise(($)=>{J=Y(()=>{$(new H4(!0))},X)})}}var bA=class{constructor(X,Y,Q,J,$,G){this.property=X,this.getTime=Y,this.interruptExecution=J,this.setTimeoutSafe=$,this.clearTimeoutSafe=G,this.skipAfterTime=this.getTime()+Q}isAsync(){return this.property.isAsync()}generate(X,Y){return this.property.generate(X,Y)}shrink(X){return this.property.shrink(X)}run(X){let Y=this.skipAfterTime-this.getTime();if(Y<=0){let Q=new H4(this.interruptExecution);if(this.isAsync())return Promise.resolve(Q);else return Q}if(this.interruptExecution&&this.isAsync()){let Q=Mo(Y,this.setTimeoutSafe,this.clearTimeoutSafe),J=Promise.race([this.property.run(X),Q.promise]);return J.then(Q.clear,Q.clear),J}return this.property.run(X)}runBeforeEach(){return this.property.runBeforeEach()}runAfterEach(){return this.property.runAfterEach()}},jo=(X,Y,Q)=>{let J=null;return{clear:()=>Q(J),promise:new Promise(($)=>{J=Y(()=>{$({error:new y(`Property timeout: exceeded limit of ${X} milliseconds`)})},X)})}},Io=class{constructor(X,Y,Q,J){this.property=X,this.timeMs=Y,this.setTimeoutSafe=Q,this.clearTimeoutSafe=J}isAsync(){return!0}generate(X,Y){return this.property.generate(X,Y)}shrink(X){return this.property.shrink(X)}async run(X){let Y=jo(this.timeMs,this.setTimeoutSafe,this.clearTimeoutSafe),Q=Promise.race([this.property.run(X),Y.promise]);return Q.then(Y.clear,Y.clear),Q}runBeforeEach(){return Promise.resolve(this.property.runBeforeEach())}runAfterEach(){return Promise.resolve(this.property.runAfterEach())}},zw=class{constructor(X){this.property=X}isAsync(){return this.property.isAsync()}generate(X,Y){return this.property.generate(X,void 0)}shrink(X){return this.property.shrink(X)}run(X){return this.property.run(X)}runBeforeEach(){return this.property.runBeforeEach()}runAfterEach(){return this.property.runAfterEach()}},gA=Array.from,yA=typeof Buffer<"u"?Buffer.isBuffer:void 0,P9=JSON.stringify,hA=Number.isNaN,xo=Object.keys,So=Object.getOwnPropertySymbols,vo=Object.getOwnPropertyDescriptor,mA=Object.getPrototypeOf,fA=Number.NEGATIVE_INFINITY,ko=Number.POSITIVE_INFINITY,Y6=Symbol.for("fast-check/toStringMethod");function OW(X){return X!==null&&(typeof X==="object"||typeof X==="function")&&Y6 in X&&typeof X[Y6]==="function"}var V8=Symbol.for("fast-check/asyncToStringMethod");function TW(X){return X!==null&&(typeof X==="object"||typeof X==="function")&&V8 in X&&typeof X[V8]==="function"}var bo=/^Symbol\((.*)\)$/;function go(X){if(X.description!==void 0)return X.description;let Y=bo.exec(d1(X));return Y&&Y[1].length?Y[1]:null}function dA(X){switch(X){case 0:return 1/X===fA?"-0":"0";case fA:return"Number.NEGATIVE_INFINITY";case ko:return"Number.POSITIVE_INFINITY";default:return X===X?d1(X):"Number.NaN"}}function yo(X){let Y=-1;for(let Q in X){let J=Number(Q);if(J!==Y+1)return!0;Y=J}return Y+1!==X.length}function BX(X,Y,Q){let J=[...Y,X];if(typeof X==="object"){if(fQ(Y,X)!==-1)return"[cyclic]"}if(TW(X)){let $=Q(X);if($.state==="fulfilled")return $.value}if(OW(X))try{return X[Y6]()}catch{}switch(rH(X)){case"[object Array]":{let $=X;if($.length>=50&&yo($)){let _=[];for(let K in $)if(!hA(Number(K)))I(_,`${K}:${BX($[K],J,Q)}`);return _.length!==0?`Object.assign(Array(${$.length}),{${h0(_,",")}})`:`Array(${$.length})`}let G=h0(L0($,(_)=>BX(_,J,Q)),",");return $.length===0||$.length-1 in $?`[${G}]`:`[${G},]`}case"[object BigInt]":return`${X}n`;case"[object Boolean]":{let $=X==!0?"true":"false";return typeof X==="boolean"?$:`new Boolean(${$})`}case"[object Date]":{let $=X;return hA(x$($))?"new Date(NaN)":`new Date(${P9(vl($))})`}case"[object Map]":return`new Map(${BX(Array.from(X),J,Q)})`;case"[object Null]":return"null";case"[object Number]":return typeof X==="number"?dA(X):`new Number(${dA(Number(X))})`;case"[object Object]":{try{let G=X.toString;if(typeof G==="function"&&G!==Object.prototype.toString)return X.toString()}catch{return"[object Object]"}let $=(G)=>`${G==="__proto__"?'["__proto__"]':typeof G==="symbol"?`[${BX(G,J,Q)}]`:P9(G)}:${BX(X[G],J,Q)}`;return"{"+h0([...mA(X)===null?["__proto__:null"]:[],...L0(xo(X),$),...L0(Il(So(X),(G)=>{let _=vo(X,G);return _&&_.enumerable}),$)],",")+"}"}case"[object Set]":return`new Set(${BX(Array.from(X),J,Q)})`;case"[object String]":return typeof X==="string"?P9(X):`new String(${P9(X)})`;case"[object Symbol]":{let $=X;if(A$.keyFor($)!==void 0)return`Symbol.for(${P9(A$.keyFor($))})`;let G=go($);if(G===null)return"Symbol()";return $===(G.startsWith("Symbol.")&&A$[G.substring(7)])?G:`Symbol(${P9(G)})`}case"[object Promise]":{let $=Q(X);switch($.state){case"fulfilled":return`Promise.resolve(${BX($.value,J,Q)})`;case"rejected":return`Promise.reject(${BX($.value,J,Q)})`;case"pending":return"new Promise(() => {/*pending*/})";default:return"new Promise(() => {/*unknown*/})"}}case"[object Error]":if(X instanceof Error)return`new Error(${BX(X.message,J,Q)})`;break;case"[object Undefined]":return"undefined";case"[object Int8Array]":case"[object Uint8Array]":case"[object Uint8ClampedArray]":case"[object Int16Array]":case"[object Uint16Array]":case"[object Int32Array]":case"[object Uint32Array]":case"[object Float32Array]":case"[object Float64Array]":case"[object BigInt64Array]":case"[object BigUint64Array]":{if(typeof yA==="function"&&yA(X))return`Buffer.from(${X.buffer.detached?"/*detached ArrayBuffer*/":BX(gA(X.values()),J,Q)})`;let $=mA(X),G=$&&$.constructor&&$.constructor.name;if(typeof G==="string"){let _=X;if(_.buffer.detached)return`${G}.from(/*detached ArrayBuffer*/)`;let K=_.values();return`${G}.from(${BX(gA(K),J,Q)})`}break}}try{return X.toString()}catch{return rH(X)}}function s0(X){return BX(X,[],()=>({state:"unknown",value:void 0}))}function qw(X){let Y=A$(),Q=[],J=new B8;function $(){let H=null,W=()=>{if(H!==null)clearTimeout(H)};return{delay:new Promise((D)=>{H=setTimeout(()=>{H=null,D(Y)},0)}),cancel:W}}let G={state:"unknown",value:void 0},_=function(W){let D=W;if(J.has(D))return J.get(D);let U=$(),N=V8 in W?Promise.resolve().then(()=>W[V8]()):W;return N.catch(()=>{}),Q.push(Promise.race([N,U.delay]).then((B)=>{if(B===Y)J.set(D,{state:"pending",value:void 0});else J.set(D,{state:"fulfilled",value:B});U.cancel()},(B)=>{J.set(D,{state:"rejected",value:B}),U.cancel()})),J.set(D,G),G};function K(){let H=BX(X,[],_);if(Q.length===0)return H;return Promise.all(Q.splice(0)).then(K)}return K()}async function FW(X){return Promise.resolve(qw(X))}function pA(X){return X===null?new H4:X}function ho(...X){if(X[1])return X[0].then(pA);return pA(X[0])}function mo(X,Y){return ho(X,Y)}var uA=class{constructor(X,Y){this.property=X,this.skipRuns=Y,this.coveredCases=new Map}isAsync(){return this.property.isAsync()}generate(X,Y){return this.property.generate(X,Y)}shrink(X){return this.property.shrink(X)}run(X){let Y=s0(X);if(this.coveredCases.has(Y)){let J=this.coveredCases.get(Y);if(!this.skipRuns)return J;return mo(J,this.property.isAsync())}let Q=this.property.run(X);return this.coveredCases.set(Y,Q),Q}runBeforeEach(){return this.property.runBeforeEach()}runAfterEach(){return this.property.runAfterEach()}},cA=Date.now,CH=setTimeout,EH=clearTimeout;function fo(X,Y){let Q=X;if(X.isAsync()&&Y.timeout!==void 0)Q=new Io(Q,Y.timeout,CH,EH);if(Y.unbiased)Q=new zw(Q);if(Y.skipAllAfterTimeLimit!==void 0)Q=new bA(Q,cA,Y.skipAllAfterTimeLimit,!1,CH,EH);if(Y.interruptAfterTimeLimit!==void 0)Q=new bA(Q,cA,Y.interruptAfterTimeLimit,!0,CH,EH);if(Y.skipEqualValues)Q=new uA(Q,!0);if(Y.ignoreEqualValues)Q=new uA(Q,!1);return Q}var po=function(X){return X[X.Success=0]="Success",X[X.Skipped=-1]="Skipped",X[X.Failure=1]="Failure",X}({}),uo=class X{constructor(Y,Q){this.verbosity=Y,this.interruptedAsFailure=Q,this.rootExecutionTrees=[],this.currentLevelExecutionTrees=this.rootExecutionTrees,this.failure=null,this.numSkips=0,this.numSuccesses=0,this.interrupted=!1}appendExecutionTree(Y,Q){let J={status:Y,value:Q,children:[]};return this.currentLevelExecutionTrees.push(J),J}fail(Y,Q,J){if(this.verbosity>=1){let $=this.appendExecutionTree(1,Y);this.currentLevelExecutionTrees=$.children}if(this.pathToFailure===void 0)this.pathToFailure=`${Q}`;else this.pathToFailure+=`:${Q}`;this.value=Y,this.failure=J}skip(Y){if(this.verbosity>=2)this.appendExecutionTree(-1,Y);if(this.pathToFailure===void 0)++this.numSkips}success(Y){if(this.verbosity>=2)this.appendExecutionTree(0,Y);if(this.pathToFailure===void 0)++this.numSuccesses}interrupt(){this.interrupted=!0}isSuccess(){return this.pathToFailure===void 0}firstFailure(){return this.pathToFailure!==void 0?+p1(this.pathToFailure,":")[0]:-1}numShrinks(){return this.pathToFailure!==void 0?p1(this.pathToFailure,":").length-1:0}extractFailures(){if(this.isSuccess())return[];let Y=[],Q=this.rootExecutionTrees;while(Q.length>0&&Q[Q.length-1].status===1){let J=Q[Q.length-1];Y.push(J.value),Q=J.children}return Y}static mergePaths(Y,Q){if(Y.length===0)return Q;let J=Y.split(":"),$=Q.split(":"),G=+J[J.length-1]+ +$[0];return[...J.slice(0,J.length-1),`${G}`,...$.slice(1)].join(":")}toRunDetails(Y,Q,J,$){if(!this.isSuccess())return{failed:!0,interrupted:this.interrupted,numRuns:this.firstFailure()+1-this.numSkips,numSkips:this.numSkips,numShrinks:this.numShrinks(),seed:Y,counterexample:this.value,counterexamplePath:X.mergePaths(Q,this.pathToFailure),errorInstance:this.failure.error,failures:this.extractFailures(),executionSummary:this.rootExecutionTrees,verbose:this.verbosity,runConfiguration:$.toParameters()};let G=this.interruptedAsFailure||this.numSuccesses===0;return{failed:this.numSkips>J||this.interrupted&&G,interrupted:this.interrupted,numRuns:this.numSuccesses,numSkips:this.numSkips,numShrinks:0,seed:Y,counterexample:null,counterexamplePath:null,error:null,errorInstance:null,failures:[],executionSummary:this.rootExecutionTrees,verbose:this.verbosity,runConfiguration:$.toParameters()}}},Lw=class{constructor(X,Y,Q,J){this.sourceValues=X,this.shrink=Y,this.runExecution=new uo(Q,J),this.currentIdx=-1,this.nextValues=X}[Symbol.iterator](){return this}next(){let X=this.nextValues.next();if(X.done||this.runExecution.interrupted)return{done:!0,value:void 0};return this.currentValue=X.value,++this.currentIdx,{done:!1,value:X.value.value_}}handleResult(X){if(X!==null&&typeof X==="object"&&!H4.isFailure(X))this.runExecution.fail(this.currentValue.value_,this.currentIdx,X),this.currentIdx=-1,this.nextValues=this.shrink(this.currentValue);else if(X!==null)if(!X.interruptExecution)this.runExecution.skip(this.currentValue.value_),this.sourceValues.skippedOne();else this.runExecution.interrupt();else this.runExecution.success(this.currentValue.value_)}},co=class{constructor(X,Y,Q){this.initialValues=X,this.maxInitialIterations=Y,this.remainingSkips=Q}[Symbol.iterator](){return this}next(){if(--this.maxInitialIterations!==-1&&this.remainingSkips>=0){let X=this.initialValues.next();if(!X.done)return{value:X.value,done:!1}}return{value:void 0,done:!0}}skippedOne(){--this.remainingSkips,++this.maxInitialIterations}},lo=-2147483648,oo=2147483647,io=Math.pow(2,27),ro=Math.pow(2,-53),RW=class X{constructor(Y){this.internalRng=g$(Y.clone())}clone(){return new X(this.internalRng)}next(Y){return V$(this.internalRng,0,(1<<Y)-1)}nextBoolean(){return V$(this.internalRng,0,1)===1}nextInt(Y,Q){return V$(this.internalRng,Y===void 0?lo:Y,Q===void 0?oo:Q)}nextBigInt(Y,Q){return aR(this.internalRng,Y,Q)}nextDouble(){let Y=this.next(26),Q=this.next(27);return(Y*io+Q)*ro}getState(){if("getState"in this.internalRng&&typeof this.internalRng.getState==="function")return this.internalRng.getState()}};function no(X,Y,Q){return Y.jump(),X.generate(new RW(Y),Q)}function*Ow(X,Y,Q,J){for(let $=0;$!==J.length;++$)yield new g(J[$],void 0);for(let $=0,G=Q(Y);;++$)yield no(X,G,$)}function so(X,Y,Q){return()=>X.generate(new RW(Y),Q)}function*Tw(X,Y,Q,J){yield*L0(J,(_)=>()=>new g(_,void 0));let $=0,G=g$(Q(Y));for(;;)G.jump(),yield so(X,G,$++)}function lA(X){return X()}function Fw(X,Y,Q){let J=Y,$=X.split(":").map((_)=>+_);if($.length===0)return J.map(lA);if(!$.every((_)=>!Number.isNaN(_)))throw Error(`Unable to replay, got invalid path=${X}`);let G=J.drop($[0]).map(lA);for(let _ of $.slice(1)){let K=G.getNthOrLast(0);if(K===null)throw Error(`Unable to replay, got wrong path=${X}`);G=Q(K).drop(_)}return G}var ao=Object.assign;function to(X){if(X.length===1)return`Hint: ${X[0]}`;return X.map((Y,Q)=>`Hint (${Q+1}): ${Y}`).join(`
`)}function eo(X,Y){return`Encountered failures were:
- ${X.map(Y).join(`
- `)}`}function AW(X,Y){let Q=[],J=[];for(let $=X.length-1;$>=0;--$)J.push({depth:1,tree:X[$]});while(J.length!==0){let $=J.pop(),G=$.tree,_=$.depth,K=G.status===0?"\x1B[32m√\x1B[0m":G.status===1?"\x1B[31m×\x1B[0m":"\x1B[33m!\x1B[0m",H=_!==0?". ".repeat(_-1):"";Q.push(`${H}${K} ${Y(G.value)}`);for(let W=G.children.length-1;W>=0;--W)J.push({depth:_+1,tree:G.children[W]})}return`Execution summary:
${Q.join(`
`)}`}function Xi(X,Y){let Q=`Failed to run property, too many pre-condition failures encountered
{ seed: ${X.seed} }

Ran ${X.numRuns} time(s)
Skipped ${X.numSkips} time(s)`,J=null,$=["Try to reduce the number of rejected values by combining map, chain and built-in arbitraries","Increase failure tolerance by setting maxSkipsPerRun to an higher value"];if(X.verbose>=2)J=AW(X.executionSummary,Y);else I($,"Enable verbose mode at level VeryVerbose in order to check all generated values and their associated status");return{message:Q,details:J,hints:$}}function Yi(X){if(X instanceof y&&X.stack!==void 0)return X.stack;try{return d1(X)}catch(Y){}if(X instanceof y)try{return Ho(X)}catch(Y){}if(X!==null&&typeof X==="object")try{return rH(X)}catch(Y){}return"Failed to serialize errorInstance"}function Qi(X,Y){let Q=X.runConfiguration.includeErrorInReport?`
Got ${$o(Yi(X.errorInstance),/^Error: /,"error: ")}`:"",J=`Property failed after ${X.numRuns} tests
{ seed: ${X.seed}, path: "${X.counterexamplePath}", endOnFailure: true }
Counterexample: ${Y(X.counterexample)}
Shrunk ${X.numShrinks} time(s)${Q}`,$=null,G=[];if(X.verbose>=2)$=AW(X.executionSummary,Y);else if(X.verbose===1)$=eo(X.failures,Y);else I(G,"Enable verbose mode in order to have the list of all failing values encountered during the run");return{message:J,details:$,hints:G}}function Ji(X,Y){let Q=`Property interrupted after ${X.numRuns} tests
{ seed: ${X.seed} }`,J=null,$=[];if(X.verbose>=2)J=AW(X.executionSummary,Y);else I($,"Enable verbose mode at level VeryVerbose in order to check all generated values and their associated status");return{message:Q,details:J,hints:$}}function sH(X,Y){if(!X.failed)return;let{message:Q,details:J,hints:$}=X.counterexamplePath===null?X.interrupted?Ji(X,Y):Xi(X,Y):Qi(X,Y),G=Q;if(J!==null)G+=`

${J}`;if($.length>0)G+=`

${to($)}`;return G}function Rw(X){return sH(X,s0)}async function Aw(X){let Y=[];function Q(_){let K=qw(_);if(typeof K==="string")return K;return Y.push(Promise.all([_,K])),"…"}let J=sH(X,Q);if(Y.length===0)return J;let $=new B8(await Promise.all(Y));function G(_){let K=VX($,_);if(K!==void 0)return K;return s0(_)}return sH(X,G)}function Pw(X,Y){if(Y.runConfiguration.includeErrorInReport)throw new y(X);let Q=new y(X,{cause:Y.errorInstance});if(!("cause"in Q))ao(Q,{cause:Y.errorInstance});return Q}function $i(X){if(!X.failed)return;throw Pw(Rw(X),X)}async function Gi(X){if(!X.failed)return;throw Pw(await Aw(X),X)}function Zi(X){if(X.runConfiguration.asyncReporter)return X.runConfiguration.asyncReporter(X);else if(X.runConfiguration.reporter)return X.runConfiguration.reporter(X);else return $i(X)}async function _i(X){if(X.runConfiguration.asyncReporter)return X.runConfiguration.asyncReporter(X);else if(X.runConfiguration.reporter)return X.runConfiguration.reporter(X);else return Gi(X)}function Ki(X,Y,Q,J,$){let G=new Lw(Q,Y,J,$);for(let _ of G){X.runBeforeEach();let K=X.run(_);X.runAfterEach(),G.handleResult(K)}return G.runExecution}async function Hi(X,Y,Q,J,$){let G=new Lw(Q,Y,J,$);for(let _ of G){await X.runBeforeEach();let K=await X.run(_);await X.runAfterEach(),G.handleResult(K)}return G.runExecution}function ww(X,Y){if(X===null||X===void 0||X.generate===null||X.generate===void 0)throw Error("Invalid property encountered, please use a valid property");if(X.run===null||X.run===void 0)throw Error("Invalid property encountered, please use a valid property not an arbitrary");let Q=LW({...X6(),...Y});if(Q.reporter!==void 0&&Q.asyncReporter!==void 0)throw Error("Invalid parameters encountered, reporter and asyncReporter cannot be specified together");if(Q.asyncReporter!==void 0&&!X.isAsync())throw Error("Invalid parameters encountered, only asyncProperty can be used when asyncReporter specified");let J=fo(X,Q),$=Q.path.length===0||Q.path.indexOf(":")===-1?Q.numRuns:-1,G=Q.numRuns*Q.maxSkipsPerRun,_=(...W)=>J.shrink(...W),K=new co(Q.path.length===0?Ow(J,Q.seed,Q.randomType,Q.examples):Fw(Q.path,_4(Tw(J,Q.seed,Q.randomType,Q.examples)),_),$,G),H=!Q.endOnFailure?_:K0.nil;return J.isAsync()?Hi(J,H,K,Q.verbose,Q.markInterruptAsFailure).then((W)=>W.toRunDetails(Q.seed,Q.path,G,Q)):Ki(J,H,K,Q.verbose,Q.markInterruptAsFailure).toRunDetails(Q.seed,Q.path,G,Q)}function Wi(X,Y){let Q=ww(X,Y);if(X.isAsync())return Q.then(_i);else Zi(Q)}function Ui(X,Y){let Q=!Object.prototype.hasOwnProperty.call(X,"isAsync")?new Bw(X,()=>!0):X;return Y.unbiased===!0?new zw(Q):Q}function Cw(X,Y){let Q=LW(typeof Y==="number"?{...X6(),numRuns:Y}:{...X6(),...Y}),J=Ui(X,Q),$=J.shrink.bind(J);return(Q.path.length===0?_4(Ow(J,Q.seed,Q.randomType,Q.examples)):Fw(Q.path,_4(Tw(J,Q.seed,Q.randomType,Q.examples)),$)).take(Q.numRuns).map((G)=>G.value_)}function Di(X,Y){return[...Cw(X,Y)]}function Ni(X){return(Math.round(X*100)/100).toFixed(2)}function Bi(X,Y,Q){let J=LW(typeof Q==="number"?{...X6(),numRuns:Q}:{...X6(),...Q}),$={};for(let H of Cw(X,Q)){let W=Y(H),D=Array.isArray(W)?W:[W];for(let U of D)$[U]=($[U]||0)+1}let G=Object.entries($).sort((H,W)=>W[1]-H[1]).map((H)=>[H[0],`${Ni(H[1]*100/J.numRuns)}%`]),_=G.map((H)=>H[0].length).reduce((H,W)=>Math.max(H,W),0),K=G.map((H)=>H[1].length).reduce((H,W)=>Math.max(H,W),0);for(let H of G)J.logger(`${H[0].padEnd(_,".")}..${H[1].padStart(K,".")}`)}var Vi=Object.assign;function aH(X,Y,Q,J){let $=Q(),G=X.clone(),_={mrng:X.clone(),biasFactor:Y,history:[]},K=(W)=>{let D=$[_.history.length];if(D!==void 0&&D.arb===W){let N=D.value;return I(_.history,{arb:W,value:N,context:D.context,mrng:D.mrng}),G=D.mrng.clone(),N}let U=W.generate(G,Y);return I(_.history,{arb:W,value:U.value_,context:U.context,mrng:G.clone()}),U.value};return new g(Vi((W,...D)=>{return K(J(W,D))},{values(){return L0(_.history,(W)=>W.value)},[H1](){return aH(X,Y,Q,J).value},[Y6](){return s0(L0(_.history,(W)=>W.value))}}),_)}var MH=Array.isArray,oA=Object.keys,zi=Object.is;function qi(X){let Y=new B8;return function(J,$){let G=VX(Y,J);if(G===void 0){let H=J(...$);return tX(Y,J,[{args:$,value:H}]),H}let _=G;for(let H of _)if(X($,H.args))return H.value;let K=J(...$);return I(_,{args:$,value:K}),K}}function Ew(X,Y){if(X!==null&&typeof X==="object"&&Y!==null&&typeof Y==="object"){if(MH(X)){if(!MH(Y))return!1;if(X.length!==Y.length)return!1}else if(MH(Y))return!1;if(oA(X).length!==oA(Y).length)return!1;for(let Q in X){if(!(Q in Y))return!1;if(!Ew(X[Q],Y[Q]))return!1}return!0}else return zi(X,Y)}var Li=class extends m0{constructor(...X){super(...X);this.arbitraryCache=qi(Ew)}generate(X,Y){return aH(X,Y,()=>[],this.arbitraryCache)}canShrinkWithoutContext(X){return!1}shrink(X,Y){if(Y===void 0)return K0.nil();let Q=Y,J=Q.mrng,$=Q.biasFactor,G=Q.history;return Uw(G.map((_)=>_.arb),G.map((_)=>_.value),G.map((_)=>_.context)).map((_)=>{function K(){let{value:H,context:W}=_;return L0(G,(D,U)=>({arb:D.arb,value:H[U],context:W[U],mrng:D.mrng}))}return aH(J,$,K,this.arbitraryCache)})}};function Oi(){return new Li}var{floor:Ti,log:iA}=Math;function Fi(X){return Ti(iA(X)/iA(2))}function Ri(X){if(X===b(0))return b(0);return b(d1(X).length)}function Mw(X,Y,Q){if(X===Y)return[{min:X,max:Y}];if(X<0&&Y>0){let _=Q(-X),K=Q(Y);return[{min:-_,max:K},{min:Y-K,max:Y},{min:X,max:X+_}]}let J=Q(Y-X),$={min:X,max:X+J},G={min:Y-J,max:Y};return X<0?[G,$]:[$,G]}var{ceil:Ai,floor:Pi}=Math;function rA(X){return Pi(X/2)}function nA(X){return Ai(X/2)}function sA(X,Y,Q){let J=X-Y;function*$(){let _=Q?void 0:Y,K=Q?J:rA(J);for(let H=K;H>0;H=rA(H)){let W=H===J?Y:X-H;yield new g(W,_),_=W}}function*G(){let _=Q?void 0:Y,K=Q?J:nA(J);for(let H=K;H<0;H=nA(H)){let W=H===J?Y:X-H;yield new g(W,_),_=W}}return J>0?_4($()):_4(G())}var aA=Math.sign,wi=Number.isInteger,Ci=Object.is,x9=class X extends m0{constructor(Y,Q){super();this.min=Y,this.max=Q,this.ranges=Mw(Y,Q,Fi)}generate(Y,Q){if(Q===void 0||Y.nextInt(1,Q)!==1)return new g(Y.nextInt(this.min,this.max),void 0);let J=this.ranges;if(J.length===1){let _=J[0];return new g(Y.nextInt(_.min,_.max),void 0)}let $=Y.nextInt(-2*(J.length-1),J.length-2),G=$<0?J[0]:J[$+1];return new g(Y.nextInt(G.min,G.max),void 0)}canShrinkWithoutContext(Y){return typeof Y==="number"&&wi(Y)&&!Ci(Y,-0)&&this.min<=Y&&Y<=this.max}shrink(Y,Q){if(!X.isValidContext(Y,Q))return sA(Y,this.min<=0&&this.max>=0?0:this.min<0?this.max:this.min,!0);if(this.isLastChanceTry(Y,Q))return K0.of(new g(Q,void 0));return sA(Y,Q,!1)}isLastChanceTry(Y,Q){if(Y>0)return Y===Q+1&&Y>this.min;if(Y<0)return Y===Q-1&&Y<this.max;return!1}static isValidContext(Y,Q){if(Q===void 0)return!1;if(typeof Q!=="number")throw Error("Invalid context type passed to IntegerArbitrary (#1)");if(Q!==0&&aA(Y)!==aA(Q))throw Error("Invalid context value passed to IntegerArbitrary (#2)");return!0}},tA=Number.isInteger;function Ei(X){return{min:X.min!==void 0?X.min:-2147483648,max:X.max!==void 0?X.max:2147483647}}function w0(X={}){let Y=Ei(X);if(Y.min>Y.max)throw Error("fc.integer maximum value should be equal or greater than the minimum one");if(!tA(Y.min))throw Error("fc.integer minimum value should be an integer");if(!tA(Y.max))throw Error("fc.integer maximum value should be an integer");return new x9(Y.min,Y.max)}var eA=new Map;function PW(X){if(X===void 0)return{depth:0};if(typeof X!=="string")return X;let Y=VX(eA,X);if(Y!==void 0)return Y;let Q={depth:0};return tX(eA,X,Q),Q}function wW(){return{depth:0}}var Mi=class{constructor(X,Y,Q){this.arb=X,this.mrng=Y,this.biasFactor=Q}attemptExact(){}next(){return this.arb.generate(this.mrng,this.biasFactor)}},ji=Math.min,Ii=Math.max,xi=class{constructor(X,Y,Q,J){this.arb=X,this.mrng=Y,this.slices=Q,this.biasFactor=J,this.activeSliceIndex=0,this.nextIndexInSlice=0,this.lastIndexInSlice=-1}attemptExact(X){if(X!==0&&this.mrng.nextInt(1,this.biasFactor)===1){let Y=[];for(let Q=0;Q!==this.slices.length;++Q)if(this.slices[Q].length===X)I(Y,Q);if(Y.length===0)return;this.activeSliceIndex=Y[this.mrng.nextInt(0,Y.length-1)],this.nextIndexInSlice=0,this.lastIndexInSlice=X-1}}next(){if(this.nextIndexInSlice<=this.lastIndexInSlice)return new g(this.slices[this.activeSliceIndex][this.nextIndexInSlice++],void 0);if(this.mrng.nextInt(1,this.biasFactor)!==1)return this.arb.generate(this.mrng,this.biasFactor);this.activeSliceIndex=this.mrng.nextInt(0,this.slices.length-1);let X=this.slices[this.activeSliceIndex];if(this.mrng.nextInt(1,this.biasFactor)!==1)return this.nextIndexInSlice=1,this.lastIndexInSlice=X.length-1,new g(X[0],void 0);let Y=this.mrng.nextInt(0,X.length-1),Q=this.mrng.nextInt(0,X.length-1);return this.nextIndexInSlice=ji(Y,Q),this.lastIndexInSlice=Ii(Y,Q),new g(X[this.nextIndexInSlice++],void 0)}};function XP(X,Y,Q,J){if(J===void 0||Q.length===0||Y.nextInt(1,J)!==1)return new Mi(X,Y,J);return new xi(X,Y,Q,J)}var{floor:Si,log:YP}=Math,vi=Array.isArray;function ki(X,Y){if(X===Y)return X;return X+Si(YP(Y-X)/YP(2))}var jw=class X extends m0{constructor(Y,Q,J,$,G,_,K){super();this.arb=Y,this.minLength=Q,this.maxGeneratedLength=J,this.maxLength=$,this.setBuilder=_,this.customSlices=K,this.lengthArb=w0({min:Q,max:J}),this.depthContext=PW(G),this.cachedBiasedMaxLength=ki(Q,J)}preFilter(Y){if(this.setBuilder===void 0)return Y;let Q=this.setBuilder();for(let J=0;J!==Y.length;++J)Q.tryAdd(Y[J]);return Q.getData()}static makeItCloneable(Y,Q){return Y[H1]=()=>{let J=[];for(let $=0;$!==Q.length;++$)I(J,Q[$].value);return this.makeItCloneable(J,Q),J},Y}generateNItemsNoDuplicates(Y,Q,J,$){let G=0,_=Y(),K=XP(this.arb,J,this.customSlices,$);while(_.size()<Q&&G<this.maxGeneratedLength){let H=K.next();if(_.tryAdd(H))G=0;else G+=1}return _.getData()}safeGenerateNItemsNoDuplicates(Y,Q,J,$){let G=Q-this.cachedBiasedMaxLength;if(G<=0)return this.generateNItemsNoDuplicates(Y,Q,J,$);this.depthContext.depth+=G;try{return this.generateNItemsNoDuplicates(Y,Q,J,$)}finally{this.depthContext.depth-=G}}generateNItems(Y,Q,J){let $=[],G=XP(this.arb,Q,this.customSlices,J);G.attemptExact(Y);for(let _=0;_!==Y;++_)I($,G.next());return $}safeGenerateNItems(Y,Q,J){let $=Y-this.cachedBiasedMaxLength;if($<=0)return this.generateNItems(Y,Q,J);this.depthContext.depth+=$;try{return this.generateNItems(Y,Q,J)}finally{this.depthContext.depth-=$}}wrapper(Y,Q,J,$){let G=Q?this.preFilter(Y):Y,_=!1,K=[],H=[];for(let W=0;W!==G.length;++W){let D=G[W];_=_||D.hasToBeCloned,I(K,D.value),I(H,D.context)}if(_)X.makeItCloneable(K,G);return new g(K,{shrunkOnce:Q,lengthContext:Y.length===G.length&&J!==void 0?J:void 0,itemsContexts:H,startIndex:$})}generate(Y,Q){let J,$;if(Q===void 0)J=this.lengthArb.generate(Y,void 0).value;else if(this.minLength===this.maxGeneratedLength)J=this.lengthArb.generate(Y,void 0).value,$=Q;else if(Y.nextInt(1,Q)!==1)J=this.lengthArb.generate(Y,void 0).value;else if(Y.nextInt(1,Q)!==1)J=this.lengthArb.generate(Y,void 0).value,$=Q;else{let _=this.cachedBiasedMaxLength;J=w0({min:this.minLength,max:_}).generate(Y,void 0).value,$=Q}let G=this.setBuilder!==void 0?this.safeGenerateNItemsNoDuplicates(this.setBuilder,J,Y,$):this.safeGenerateNItems(J,Y,$);return this.wrapper(G,!1,void 0,0)}canShrinkWithoutContext(Y){if(!vi(Y)||this.minLength>Y.length||Y.length>this.maxLength)return!1;for(let Q=0;Q!==Y.length;++Q){if(!(Q in Y))return!1;if(!this.arb.canShrinkWithoutContext(Y[Q]))return!1}return this.preFilter(L0(Y,(Q)=>new g(Q,void 0))).length===Y.length}shrinkItemByItem(Y,Q,J){let $=[];for(let G=Q.startIndex;G<J;++G)I($,Z4(()=>this.arb.shrink(Y[G],Q.itemsContexts[G]).map((_)=>{let K=L0(_1(Y,0,G),(W,D)=>new g(M9(W),Q.itemsContexts[D])),H=L0(_1(Y,G+1),(W,D)=>new g(M9(W),Q.itemsContexts[D+G+1]));return[[...K,_,...H],void 0,G]})));return K0.nil().join(...$)}shrinkImpl(Y,Q){if(Y.length===0)return K0.nil();let J=Q!==void 0?Q:{shrunkOnce:!1,lengthContext:void 0,itemsContexts:[],startIndex:0};return this.lengthArb.shrink(Y.length,J.lengthContext).drop(J.shrunkOnce&&J.lengthContext===void 0&&Y.length>this.minLength+1?1:0).map(($)=>{let G=Y.length-$.value;return[L0(_1(Y,G),(_,K)=>new g(M9(_),J.itemsContexts[K+G])),$.context,0]}).join(Z4(()=>Y.length>this.minLength?this.shrinkItemByItem(Y,J,1):this.shrinkItemByItem(Y,J,Y.length))).join(Y.length>this.minLength?Z4(()=>{let $={shrunkOnce:!1,lengthContext:void 0,itemsContexts:_1(J.itemsContexts,1),startIndex:0};return this.shrinkImpl(_1(Y,1),$).filter((G)=>this.minLength<=G[0].length+1).map((G)=>{return[[new g(M9(Y[0]),J.itemsContexts[0]),...G[0]],void 0,0]})}):K0.nil())}shrink(Y,Q){return this.shrinkImpl(Y,Q).map((J)=>this.wrapper(J[0],!0,J[1],J[2]))}},bi=Math.floor,gi=Math.min,N5=2147483647,w9=["xsmall","small","medium","large","xlarge"],yi=["-4","-3","-2","-1","=","+1","+2","+3","+4"],CW="small";function hi(X,Y){switch(Y){case"xsmall":return bi(1.1*X)+1;case"small":return 2*X+10;case"medium":return 11*X+100;case"large":return 101*X+1000;case"xlarge":return 1001*X+1e4;default:throw Error(`Unable to compute lengths based on received size: ${Y}`)}}function oQ(X,Y){let Q=fQ(yi,X);if(Q===-1)return X;let J=fQ(w9,Y);if(J===-1)throw Error(`Unable to offset size based on the unknown defaulted one: ${Y}`);let $=J+Q-4;return $<0?w9[0]:$>=w9.length?w9[w9.length-1]:w9[$]}function cQ(X,Y,Q,J){let{baseSize:$=CW,defaultSizeToMaxWhenMaxSpecified:G}=X6()||{},_=X!==void 0?X:J&&G?"max":$;if(_==="max")return Q;let K=oQ(_,$);return gi(hi(Y,K),Q)}function mi(X,Y){if(typeof X==="number")return 1/X;let{baseSize:Q=CW,defaultSizeToMaxWhenMaxSpecified:J}=X6()||{},$=X!==void 0?X:Y&&J?"max":Q;if($==="max")return 0;switch(oQ($,Q)){case"xsmall":return 1;case"small":return 0.5;case"medium":return 0.25;case"large":return 0.125;case"xlarge":return 0.0625}}function EW(X){let{baseSize:Y=CW}=X6()||{};if(X===void 0)return Y;return oQ(X,Y)}function M0(X,Y={}){let Q=Y.size,J=Y.minLength||0,$=Y.maxLength,G=Y.depthIdentifier,_=$!==void 0?$:N5;return new jw(X,J,cQ(Q,J,_,$!==void 0),_,G,void 0,Y.experimentalCustomSlices||[])}function z$(X){return X/b(2)}function QP(X,Y,Q){let J=X-Y;function*$(){let _=Q?void 0:Y,K=Q?J:z$(J);for(let H=K;H>0;H=z$(H)){let W=X-H;yield new g(W,_),_=W}}function*G(){let _=Q?void 0:Y,K=Q?J:z$(J);for(let H=K;H<0;H=z$(H)){let W=X-H;yield new g(W,_),_=W}}return J>0?_4($()):_4(G())}var fi=class X extends m0{constructor(Y,Q){super();this.min=Y,this.max=Q}generate(Y,Q){let J=this.computeGenerateRange(Y,Q);return new g(Y.nextBigInt(J.min,J.max),void 0)}computeGenerateRange(Y,Q){if(Q===void 0||Y.nextInt(1,Q)!==1)return{min:this.min,max:this.max};let J=Mw(this.min,this.max,Ri);if(J.length===1)return J[0];let $=Y.nextInt(-2*(J.length-1),J.length-2);return $<0?J[0]:J[$+1]}canShrinkWithoutContext(Y){return typeof Y==="bigint"&&this.min<=Y&&Y<=this.max}shrink(Y,Q){if(!X.isValidContext(Y,Q))return QP(Y,this.defaultTarget(),!0);if(this.isLastChanceTry(Y,Q))return K0.of(new g(Q,void 0));return QP(Y,Q,!1)}defaultTarget(){if(this.min<=0&&this.max>=0)return b(0);return this.min<0?this.max:this.min}isLastChanceTry(Y,Q){if(Y>0)return Y===Q+b(1)&&Y>this.min;if(Y<0)return Y===Q-b(1)&&Y<this.max;return!1}static isValidContext(Y,Q){if(Q===void 0)return!1;if(typeof Q!=="bigint")throw Error("Invalid context type passed to BigIntArbitrary (#1)");let J=Y>0&&Q<0||Y<0&&Q>0;if(Q!==b(0)&&J)throw Error("Invalid context value passed to BigIntArbitrary (#2)");return!0}};function di(X){let Q=b(-1)<<b(255),J=(b(1)<<b(255))-b(1),$=X.min,G=X.max;return{min:$!==void 0?$:Q-(G!==void 0&&G<b(0)?G*G:b(0)),max:G!==void 0?G:J+($!==void 0&&$>b(0)?$*$:b(0))}}function pi(X){if(X[0]===void 0)return{};if(X[1]===void 0)return X[0];return{min:X[0],max:X[1]}}function K4(...X){let Y=di(pi(X));if(Y.min>Y.max)throw Error("fc.bigInt expects max to be greater than or equal to min");return new fi(Y.min,Y.max)}var ui=Object.getPrototypeOf,gQ=class extends m0{constructor(X){super();this.arb=X}generate(X,Y){return this.arb.generate(X,void 0)}canShrinkWithoutContext(X){return this.arb.canShrinkWithoutContext(X)}shrink(X,Y){return this.arb.shrink(X,Y)}};function S$(X){if(ui(X)===gQ.prototype&&X.generate===gQ.prototype.generate&&X.canShrinkWithoutContext===gQ.prototype.canShrinkWithoutContext&&X.shrink===gQ.prototype.shrink)return X;return new gQ(X)}function ci(X){return X===1}function li(X){if(typeof X!=="boolean")throw Error("Unsupported input type");return X===!0?1:0}function iQ(){return S$(w0({min:0,max:1}).map(ci,li))}var mQ=Object.is,oi=class{constructor(X){this.values=X,this.fastValues=new eX(this.values);let Y=!1,Q=!1;if($4(this.fastValues,0))for(let J=0;J!==this.values.length;++J){let $=this.values[J];Y=Y||mQ($,-0),Q=Q||mQ($,0)}this.hasMinusZero=Y,this.hasPlusZero=Q}has(X){if(X===0){if(mQ(X,0))return this.hasPlusZero;return this.hasMinusZero}return $4(this.fastValues,X)}},Iw=class extends m0{constructor(X){super();this.values=X}generate(X,Y){let Q=this.values.length===1?0:X.nextInt(0,this.values.length-1),J=this.values[Q];if(!D5(J))return new g(J,Q);return new g(J,Q,()=>J[H1]())}canShrinkWithoutContext(X){if(this.values.length===1)return mQ(this.values[0],X);if(this.fastValues===void 0)this.fastValues=new oi(this.values);return this.fastValues.has(X)}shrink(X,Y){if(Y===0||mQ(X,this.values[0]))return K0.nil();return K0.of(new g(this.values[0],0))}};function M6(...X){if(X.length===0)throw Error("fc.constantFrom expects at least one parameter");return new Iw(X)}function ii(X){if(!X||!X.withBigInt)return M6(!1,null,void 0,0,"",NaN);return M6(!1,null,void 0,0,"",NaN,b(0))}function y0(X){return new Iw([X])}var ri=class X{constructor(){this.receivedLogs=[]}log(Y){this.receivedLogs.push(Y)}size(){return this.receivedLogs.length}toString(){return JSON.stringify({logs:this.receivedLogs})}[H1](){return new X}};function ni(){return y0(new ri)}var si=NaN,ai=Number.isNaN;function xw(X){return new I$(X)}function Sw(X){if(!(X instanceof I$)||X.constructor!==I$)throw new y("Not a valid value for date unmapper");return x$(X)}function ti(X){return(Y)=>{return Y===X?new I$(si):xw(Y)}}function ei(X){return(Y)=>{let Q=Sw(Y);return ai(Q)?X:Q}}var JP=Number.isNaN;function vw(X={}){let Y=X.min!==void 0?x$(X.min):-8640000000000000,Q=X.max!==void 0?x$(X.max):8640000000000000,J=X.noInvalidDate;if(JP(Y))throw Error("fc.date min must be valid instance of Date");if(JP(Q))throw Error("fc.date max must be valid instance of Date");if(Y>Q)throw Error("fc.date max must be greater or equal to min");if(J)return w0({min:Y,max:Q}).map(xw,Sw);let $=Q+1;return w0({min:Y,max:Q+1}).map(ti($),ei($))}var Xr=class extends m0{constructor(X,Y){super();this.startArb=X,this.chainer=Y}generate(X,Y){let Q=[],J=X.clone(),$=this.startArb.generate(X,Y);Q.push({arbitrary:this.startArb,value:$.value_,context:$.context,clonedMrng:J});while(!0){let _=this.chainer($.value_);if(_===void 0)break;let K=X.clone();$=_.generate(X,Y),Q.push({arbitrary:_,value:$.value_,context:$.context,clonedMrng:K})}let G={biasFactor:Y,entries:Q,currentShrinkLevel:0};return new g($.value_,G)}canShrinkWithoutContext(X){return!1}shrink(X,Y){if(!this.isSafeContext(Y))return K0.nil();return new K0(this.shrinkIterator(Y))}*shrinkIterator(X){let{entries:Y,currentShrinkLevel:Q,biasFactor:J}=X;for(let $=Q;$<Y.length;++$){let G=Y[$],_=G.arbitrary.shrink(G.value,G.context);for(let K of _){let H=Y.slice(0,$);H.push({arbitrary:G.arbitrary,value:K.value_,context:K.context,clonedMrng:G.clonedMrng});let W=K,D=G.clonedMrng.clone();while(!0){let B=this.chainer(W.value_);if(B===void 0)break;let z=D.clone(),q=B.generate(D,J);H.push({arbitrary:B,value:q.value_,context:q.context,clonedMrng:z}),W=q}let U=H[H.length-1],N={biasFactor:J,entries:H,currentShrinkLevel:$};yield new g(U.value,N)}}}isSafeContext(X){return X!==null&&X!==void 0&&typeof X==="object"&&"biasFactor"in X&&"entries"in X&&"currentShrinkLevel"in X}};function kw(X,Y){return new Xr(X,Y)}var Yr=Symbol.iterator,Qr=Array.isArray,Jr=Object.is,$r=class X extends m0{constructor(Y,Q){super();this.arb=Y,this.numValues=Q}generate(Y,Q){let J=[];if(this.numValues<=0)return this.wrapper(J);for(let $=0;$!==this.numValues-1;++$)I(J,this.arb.generate(Y.clone(),Q));return I(J,this.arb.generate(Y,Q)),this.wrapper(J)}canShrinkWithoutContext(Y){if(!Qr(Y)||Y.length!==this.numValues)return!1;if(Y.length===0)return!0;for(let Q=1;Q<Y.length;++Q)if(!Jr(Y[0],Y[Q]))return!1;return this.arb.canShrinkWithoutContext(Y[0])}shrink(Y,Q){if(Y.length===0)return K0.nil();return new K0(this.shrinkImpl(Y,Q!==void 0?Q:[])).map((J)=>this.wrapper(J))}*shrinkImpl(Y,Q){let J=L0(Y,(G,_)=>this.arb.shrink(G,Q[_])[Yr]()),$=L0(J,(G)=>G.next());while(!$[0].done)yield L0($,(G)=>G.value),$=L0(J,(G)=>G.next())}static makeItCloneable(Y,Q){return Y[H1]=()=>{let J=[];for(let $=0;$!==Q.length;++$)I(J,Q[$].value);return this.makeItCloneable(J,Q),J},Y}wrapper(Y){let Q=!1,J=[],$=[];for(let G=0;G!==Y.length;++G){let _=Y[G];Q=Q||_.hasToBeCloned,I(J,_.value),I($,_.context)}if(Q)X.makeItCloneable(J,Y);return new g(J,$)}};function Gr(X,Y){return new $r(X,Y)}var $P=class{constructor(X){this.isEqual=X,this.data=[]}tryAdd(X){for(let Y=0;Y!==this.data.length;++Y)if(this.isEqual(this.data[Y],X))return!1;return I(this.data,X),!0}size(){return this.data.length}getData(){return this.data}},Zr=Number.isNaN,_r=class{constructor(X){this.selector=X,this.selectedItemsExceptNaN=new eX,this.data=[]}tryAdd(X){let Y=this.selector(X);if(Zr(Y))return I(this.data,X),!0;let Q=this.selectedItemsExceptNaN.size;if(dQ(this.selectedItemsExceptNaN,Y),Q!==this.selectedItemsExceptNaN.size)return I(this.data,X),!0;return!1}size(){return this.data.length}getData(){return this.data}},Kr=Object.is,Hr=class{constructor(X){this.selector=X,this.selectedItemsExceptMinusZero=new eX,this.data=[],this.hasMinusZero=!1}tryAdd(X){let Y=this.selector(X);if(Kr(Y,-0)){if(this.hasMinusZero)return!1;return I(this.data,X),this.hasMinusZero=!0,!0}let Q=this.selectedItemsExceptMinusZero.size;if(dQ(this.selectedItemsExceptMinusZero,Y),Q!==this.selectedItemsExceptMinusZero.size)return I(this.data,X),!0;return!1}size(){return this.data.length}getData(){return this.data}},Wr=class{constructor(X){this.selector=X,this.selectedItems=new eX,this.data=[]}tryAdd(X){let Y=this.selector(X),Q=this.selectedItems.size;if(dQ(this.selectedItems,Y),Q!==this.selectedItems.size)return I(this.data,X),!0;return!1}size(){return this.data.length}getData(){return this.data}};function Ur(X){if(typeof X.comparator==="function"){if(X.selector===void 0){let K=X.comparator,H=(W,D)=>K(W.value_,D.value_);return()=>new $P(H)}let{comparator:J,selector:$}=X,G=(K)=>$(K.value_),_=(K,H)=>J(G(K),G(H));return()=>new $P(_)}let Y=X.selector||((J)=>J),Q=(J)=>Y(J.value_);switch(X.comparator){case"IsStrictlyEqual":return()=>new _r(Q);case"SameValueZero":return()=>new Wr(Q);case"SameValue":case void 0:return()=>new Hr(Q)}}function B5(X,Y={}){let Q=Y.minLength!==void 0?Y.minLength:0,J=Y.maxLength!==void 0?Y.maxLength:N5,$=cQ(Y.size,Q,J,Y.maxLength!==void 0),G=Y.depthIdentifier,_=new jw(X,Q,$,J,G,Ur(Y),[]);if(Q===0)return _;return _.filter((K)=>K.length>=Q)}var{create:Dr,defineProperty:Nr,getOwnPropertyDescriptor:Br,getPrototypeOf:GP,prototype:Vr}=Object,zr=Reflect.ownKeys;function qr(X){let Y=X[1]?Dr(null):{},Q=X[0];for(let J=0;J!==Q.length;++J){let $=Q[J][0];if($==="__proto__")Nr(Y,$,{enumerable:!0,configurable:!0,writable:!0,value:Q[J][1]});else Y[$]=Q[J][1]}return Y}function Lr(X){return X!==void 0&&!!X.configurable&&!!X.enumerable&&!!X.writable&&X.get===void 0&&X.set===void 0}function Or(X){if(typeof X!=="object"||X===null)throw new y("Incompatible instance received: should be a non-null object");let Y=GP(X)===null,Q=GP(X)===Vr;if(!Y&&!Q)throw new y("Incompatible instance received: should be of exact type Object");let J=L0(zr(X),($)=>[$,Br(X,$)]);if(!Kw(J,([,$])=>Lr($)))throw new y("Incompatible instance received: should contain only c/e/w properties without get/set");return[L0(J,([$,G])=>[$,G.value]),Y]}function Tr(X){return X[0]}function MW(X,Y,Q={}){let J=!!Q.noNullPrototype;return _0(B5(_0(X,Y),{minLength:Q.minKeys,maxLength:Q.maxKeys,size:Q.size,selector:Tr,depthIdentifier:Q.depthIdentifier}),J?y0(!1):iQ()).map(qr,Or)}var{POSITIVE_INFINITY:Fr,MAX_SAFE_INTEGER:Rr,isInteger:Ar}=Number,Pr=Math.floor,wr=Math.pow,Cr=Math.min,tH=class X extends m0{static from(Y,Q,J){if(Y.length===0)throw Error(`${J} expects at least one weighted arbitrary`);let $=0;for(let _=0;_!==Y.length;++_){if(Y[_].arbitrary===void 0)throw Error(`${J} expects arbitraries to be specified`);let K=Y[_].weight;if($+=K,!Ar(K))throw Error(`${J} expects weights to be integer values`);if(K<0)throw Error(`${J} expects weights to be superior or equal to 0`)}if($<=0)throw Error(`${J} expects the sum of weights to be strictly superior to 0`);let G={depthBias:mi(Q.depthSize,Q.maxDepth!==void 0),maxDepth:Q.maxDepth!==void 0?Q.maxDepth:Fr,withCrossShrink:!!Q.withCrossShrink};return new X(Y,G,PW(Q.depthIdentifier))}constructor(Y,Q,J){super();this.warbs=Y,this.constraints=Q,this.context=J;let $=0;this.cumulatedWeights=[];for(let G=0;G!==Y.length;++G)$+=Y[G].weight,I(this.cumulatedWeights,$);this.totalWeight=$}generate(Y,Q){if(this.mustGenerateFirst())return this.safeGenerateForIndex(Y,0,Q);let J=Y.nextInt(this.computeNegDepthBenefit(),this.totalWeight-1);for(let $=0;$!==this.cumulatedWeights.length;++$)if(J<this.cumulatedWeights[$])return this.safeGenerateForIndex(Y,$,Q);throw Error("Unable to generate from fc.frequency")}canShrinkWithoutContext(Y){return this.canShrinkWithoutContextIndex(Y)!==-1}shrink(Y,Q){if(Q!==void 0){let $=Q,G=$.selectedIndex,_=$.originalBias,K=this.warbs[G].arbitrary.shrink(Y,$.originalContext).map((H)=>this.mapIntoValue(G,H,null,_));if($.clonedMrngForFallbackFirst!==null){if($.cachedGeneratedForFirst===void 0)$.cachedGeneratedForFirst=this.safeGenerateForIndex($.clonedMrngForFallbackFirst,0,_);let H=$.cachedGeneratedForFirst;return K0.of(H).join(K)}return K}let J=this.canShrinkWithoutContextIndex(Y);if(J===-1)return K0.nil();return this.defaultShrinkForFirst(J).join(this.warbs[J].arbitrary.shrink(Y,void 0).map(($)=>this.mapIntoValue(J,$,null,void 0)))}defaultShrinkForFirst(Y){++this.context.depth;try{if(!this.mustFallbackToFirstInShrink(Y)||this.warbs[0].fallbackValue===void 0)return K0.nil()}finally{--this.context.depth}let Q=new g(this.warbs[0].fallbackValue.default,void 0);return K0.of(this.mapIntoValue(0,Q,null,void 0))}canShrinkWithoutContextIndex(Y){if(this.mustGenerateFirst())return this.warbs[0].arbitrary.canShrinkWithoutContext(Y)?0:-1;try{++this.context.depth;for(let Q=0;Q!==this.warbs.length;++Q){let J=this.warbs[Q];if(J.weight!==0&&J.arbitrary.canShrinkWithoutContext(Y))return Q}return-1}finally{--this.context.depth}}mapIntoValue(Y,Q,J,$){let G={selectedIndex:Y,originalBias:$,originalContext:Q.context,clonedMrngForFallbackFirst:J};return new g(Q.value,G)}safeGenerateForIndex(Y,Q,J){++this.context.depth;try{let $=this.warbs[Q].arbitrary.generate(Y,J),G=this.mustFallbackToFirstInShrink(Q)?Y.clone():null;return this.mapIntoValue(Q,$,G,J)}finally{--this.context.depth}}mustGenerateFirst(){return this.constraints.maxDepth<=this.context.depth}mustFallbackToFirstInShrink(Y){return Y!==0&&this.constraints.withCrossShrink&&this.warbs[0].weight!==0}computeNegDepthBenefit(){let Y=this.constraints.depthBias;if(Y<=0||this.warbs[0].weight===0)return 0;let Q=Pr(wr(1+Y,this.context.depth))-1;return-Cr(this.totalWeight*Q,Rr)||0}};function Er(X){return X!==null&&X!==void 0&&typeof X==="object"&&!("generate"in X)&&!("arbitrary"in X)&&!("weight"in X)}function ZP(X){if(aP(X))return{arbitrary:X,weight:1};return X}function K1(...X){let Y=X[0];if(Er(Y)){let J=L0(_1(X,1),ZP);return tH.from(J,Y,"fc.oneof")}let Q=L0(X,ZP);return tH.from(Q,{},"fc.oneof")}var Mr=Number.isInteger;function G4(X){let Y=typeof X==="number"?X:X&&X.max!==void 0?X.max:2147483647;if(Y<0)throw Error("fc.nat value should be greater than or equal to 0");if(!Mr(Y))throw Error("fc.nat maximum value should be an integer");return new x9(0,Y)}var jr=Object.is;function Ir(X){let Y=0,Q=[];for(let J of X){let $=Y;Y=$+J.num;let G=Y-1;Q.push({from:$,to:G,entry:J})}return Q}function xr(X,Y){let Q=0,J=X.length;while(J-Q>1){let $=~~((Q+J)/2);if(Y<X[$].from)J=$;else Q=$}return X[Q]}function Sr(X){let Y=Ir(X);return function(J){let $=xr(Y,J);return $.entry.build(J-$.from)}}function vr(X){let Y={mapping:new B8,negativeZeroIndex:void 0},Q=0;for(let J=0;J!==X.length;++J){let $=X[J];for(let G=0;G!==$.num;++G){let _=$.build(G);if(_===0&&1/_===N8.NEGATIVE_INFINITY)Y.negativeZeroIndex=Q;else tX(Y.mapping,_,Q);++Q}}return Y}function kr(X){let Y=null;return function(J){if(Y===null)Y=vr(X);let $=jr(J,-0)?Y.negativeZeroIndex:VX(Y.mapping,J);if($===void 0)throw new y("Unknown value encountered cannot be built using this mapToConstant");return $}}function br(X){if(X.length===0)throw new y("fc.mapToConstant expects at least one option");let Y=0;for(let Q=0;Q!==X.length;++Q){if(X[Q].num<0)throw new y("fc.mapToConstant expects all options to have a number of entries greater or equal to zero");Y+=X[Q].num}if(Y===0)throw new y("fc.mapToConstant expects at least one choice among options");return Y}function S9(...X){return G4({max:br(X)-1}).map(Sr(X),kr(X))}function bw(X,Y,Q,J){if(Y.length===0){if(Q>0)return;return[]}if(J<=0)return;let $=[{endIndexChunks:0,nextStartIndex:1,chunks:[]}];while($.length>0){let G=Gw($);for(let _=G.nextStartIndex;_<=Y.length;++_){let K=u0(Y,G.endIndexChunks,_);if(X.canShrinkWithoutContext(K)){let H=[...G.chunks,K];if(_===Y.length){if(H.length<Q)break;return H}if(I($,{endIndexChunks:G.endIndexChunks,nextStartIndex:_+1,chunks:G.chunks}),H.length<J)I($,{endIndexChunks:_,nextStartIndex:_+1,chunks:H});break}}}}function gr(X){return h0(X,"")}function gw(X){return X.minLength!==void 0?X.minLength:0}function yw(X){return X.maxLength!==void 0?X.maxLength:N5}function yr(X,Y){return gw(Y)<=X.length&&X.length<=yw(Y)}function hr(X,Y){return function(J){if(typeof J!=="string")throw new y("Unsupported value");let $=bw(X,J,gw(Y),yw(Y));if($===void 0)throw new y("Unable to unmap received string");return $}}var hw=["__defineGetter__","__defineSetter__","__lookupGetter__","__lookupSetter__","__proto__","constructor","hasOwnProperty","isPrototypeOf","propertyIsEnumerable","toLocaleString","toString","valueOf","apply","arguments","bind","call","caller","length","name","prototype","key","ref"];function mr(X,Y,Q){let J;try{J=Q(X)}catch{return}for(let $ of J)if(!Y.canShrinkWithoutContext($))return;return J}function fr(X,Y){let Q=[];for(let J of hw){let $=mr(J,X,Y);if($!==void 0)I(Q,$)}return Q}var _P=new WeakMap;function dr(X){let Y=[];for(let Q of hw){let J=bw(X,Q,0,N5);if(J!==void 0)I(Y,J)}return Y}function pr(X,Y){let Q=ml(_P,X);if(Q===void 0)Q=dr(X),hl(_P,X,Q);let J=[];for(let $ of Q)if(yr($,Y))I(J,$);return J}var ur=[[0,127]],cr=[[0,55295],[57344,1114111]],lr=[[32,126],[160,172],[174,767],[880,887],[890,895],[900,906],[908],[910,929],[931,1154],[1162,1327],[1329,1366],[1369,1418],[1421,1423],[1470],[1472],[1475],[1478],[1488,1514],[1519,1524],[1542,1551],[1563],[1565,1610],[1632,1647],[1649,1749],[1758],[1765,1766],[1769],[1774,1805],[1808],[1810,1839],[1869,1957],[1969],[1984,2026],[2036,2042],[2046,2069],[2074],[2084],[2088],[2096,2110],[2112,2136],[2142],[2144,2154],[2160,2190],[2208,2249],[2308,2361],[2365],[2384],[2392,2401],[2404,2432],[2437,2444],[2447,2448],[2451,2472],[2474,2480],[2482],[2486,2489],[2493],[2510],[2524,2525],[2527,2529],[2534,2557],[2565,2570],[2575,2576],[2579,2600],[2602,2608],[2610,2611],[2613,2614],[2616,2617],[2649,2652],[2654],[2662,2671],[2674,2676],[2678],[2693,2701],[2703,2705],[2707,2728],[2730,2736],[2738,2739],[2741,2745],[2749],[2768],[2784,2785],[2790,2801],[2809],[2821,2828],[2831,2832],[2835,2856],[2858,2864],[2866,2867],[2869,2873],[2877],[2908,2909],[2911,2913],[2918,2935],[2947],[2949,2954],[2958,2960],[2962,2965],[2969,2970],[2972],[2974,2975],[2979,2980],[2984,2986],[2990,3001],[3024],[3046,3066],[3077,3084],[3086,3088],[3090,3112],[3114,3129],[3133],[3160,3162],[3165],[3168,3169],[3174,3183],[3191,3200],[3204,3212],[3214,3216],[3218,3240],[3242,3251],[3253,3257],[3261],[3293,3294],[3296,3297],[3302,3311],[3313,3314],[3332,3340],[3342,3344],[3346,3386],[3389],[3407],[3412,3414],[3416,3425],[3430,3455],[3461,3478],[3482,3505],[3507,3515],[3517],[3520,3526],[3558,3567],[3572],[3585,3632],[3634],[3647,3654],[3663,3675],[3713,3714],[3716],[3718,3722],[3724,3747],[3749],[3751,3760],[3762],[3773],[3776,3780],[3782],[3792,3801],[3804,3807],[3840,3863],[3866,3892],[3894],[3896],[3898,3901],[3904,3911],[3913,3948],[3973],[3976,3980],[4030,4037],[4039,4044],[4046,4058],[4096,4138],[4159,4181],[4186,4189],[4193],[4197,4198],[4206,4208],[4213,4225],[4238],[4240,4249],[4254,4293],[4295],[4301],[4304,4351],[4608,4680],[4682,4685],[4688,4694],[4696],[4698,4701],[4704,4744],[4746,4749],[4752,4784],[4786,4789],[4792,4798],[4800],[4802,4805],[4808,4822],[4824,4880],[4882,4885],[4888,4954],[4960,4988],[4992,5017],[5024,5109],[5112,5117],[5120,5788],[5792,5880],[5888,5905],[5919,5937],[5941,5942],[5952,5969],[5984,5996],[5998,6000],[6016,6067],[6100,6108],[6112,6121],[6128,6137],[6144,6154],[6160,6169],[6176,6264],[6272,6276],[6279,6312],[6314],[6320,6389],[6400,6430],[6464],[6468,6509],[6512,6516],[6528,6571],[6576,6601],[6608,6618],[6622,6678],[6686,6740],[6784,6793],[6800,6809],[6816,6829],[6917,6963],[6981,6988],[6992,7018],[7028,7038],[7043,7072],[7086,7141],[7164,7203],[7227,7241],[7245,7304],[7312,7354],[7357,7367],[7379],[7401,7404],[7406,7411],[7413,7414],[7418],[7424,7615],[7680,7957],[7960,7965],[7968,8005],[8008,8013],[8016,8023],[8025],[8027],[8029],[8031,8061],[8064,8116],[8118,8132],[8134,8147],[8150,8155],[8157,8175],[8178,8180],[8182,8190],[8192,8202],[8208,8233],[8239,8287],[8304,8305],[8308,8334],[8336,8348],[8352,8384],[8448,8587],[8592,9254],[9280,9290],[9312,11123],[11126,11157],[11159,11502],[11506,11507],[11513,11557],[11559],[11565],[11568,11623],[11631,11632],[11648,11670],[11680,11686],[11688,11694],[11696,11702],[11704,11710],[11712,11718],[11720,11726],[11728,11734],[11736,11742],[11776,11869],[11904,11929],[11931,12019],[12032,12245],[12272,12329],[12336,12351],[12353,12438],[12443,12543],[12549,12591],[12593,12686],[12688,12771],[12783,12830],[12832,13312],[19903,19968],[40959,42124],[42128,42182],[42192,42539],[42560,42606],[42611],[42622,42653],[42656,42735],[42738,42743],[42752,42954],[42960,42961],[42963],[42965,42969],[42994,43009],[43011,43013],[43015,43018],[43020,43042],[43048,43051],[43056,43065],[43072,43127],[43138,43187],[43214,43225],[43250,43262],[43264,43301],[43310,43334],[43359],[43396,43442],[43457,43469],[43471,43481],[43486,43492],[43494,43518],[43520,43560],[43584,43586],[43588,43595],[43600,43609],[43612,43642],[43646,43695],[43697],[43701,43702],[43705,43709],[43712],[43714],[43739,43754],[43760,43764],[43777,43782],[43785,43790],[43793,43798],[43808,43814],[43816,43822],[43824,43883],[43888,44002],[44011],[44016,44025],[44032],[55203],[63744,64109],[64112,64217],[64256,64262],[64275,64279],[64285],[64287,64310],[64312,64316],[64318],[64320,64321],[64323,64324],[64326,64450],[64467,64911],[64914,64967],[64975],[65008,65023],[65040,65049],[65072,65106],[65108,65126],[65128,65131],[65136,65140],[65142,65276],[65281,65437],[65440,65470],[65474,65479],[65482,65487],[65490,65495],[65498,65500],[65504,65510],[65512,65518],[65532,65533],[65536,65547],[65549,65574],[65576,65594],[65596,65597],[65599,65613],[65616,65629],[65664,65786],[65792,65794],[65799,65843],[65847,65934],[65936,65948],[65952],[66000,66044],[66176,66204],[66208,66256],[66273,66299],[66304,66339],[66349,66378],[66384,66421],[66432,66461],[66463,66499],[66504,66517],[66560,66717],[66720,66729],[66736,66771],[66776,66811],[66816,66855],[66864,66915],[66927,66938],[66940,66954],[66956,66962],[66964,66965],[66967,66977],[66979,66993],[66995,67001],[67003,67004],[67072,67382],[67392,67413],[67424,67431],[67456,67461],[67463,67504],[67506,67514],[67584,67589],[67592],[67594,67637],[67639,67640],[67644],[67647,67669],[67671,67742],[67751,67759],[67808,67826],[67828,67829],[67835,67867],[67871,67897],[67903],[67968,68023],[68028,68047],[68050,68096],[68112,68115],[68117,68119],[68121,68149],[68160,68168],[68176,68184],[68192,68255],[68288,68324],[68331,68342],[68352,68405],[68409,68437],[68440,68466],[68472,68497],[68505,68508],[68521,68527],[68608,68680],[68736,68786],[68800,68850],[68858,68899],[68912,68921],[69216,69246],[69248,69289],[69293],[69296,69297],[69376,69415],[69424,69445],[69457,69465],[69488,69505],[69510,69513],[69552,69579],[69600,69622],[69635,69687],[69703,69709],[69714,69743],[69745,69746],[69749],[69763,69807],[69819,69820],[69822,69825],[69840,69864],[69872,69881],[69891,69926],[69942,69956],[69959],[69968,70002],[70004,70006],[70019,70066],[70081],[70084,70088],[70093],[70096,70111],[70113,70132],[70144,70161],[70163,70187],[70200,70205],[70207,70208],[70272,70278],[70280],[70282,70285],[70287,70301],[70303,70313],[70320,70366],[70384,70393],[70405,70412],[70415,70416],[70419,70440],[70442,70448],[70450,70451],[70453,70457],[70461],[70480],[70493,70497],[70656,70708],[70727,70747],[70749],[70751,70753],[70784,70831],[70852,70855],[70864,70873],[71040,71086],[71105,71131],[71168,71215],[71233,71236],[71248,71257],[71264,71276],[71296,71338],[71352,71353],[71360,71369],[71424,71450],[71472,71494],[71680,71723],[71739],[71840,71922],[71935,71942],[71945],[71948,71955],[71957,71958],[71960,71983],[72004,72006],[72016,72025],[72096,72103],[72106,72144],[72161,72163],[72192],[72203,72242],[72255,72262],[72272],[72284,72323],[72346,72354],[72368,72440],[72448,72457],[72704,72712],[72714,72750],[72768,72773],[72784,72812],[72816,72847],[72960,72966],[72968,72969],[72971,73008],[73040,73049],[73056,73061],[73063,73064],[73066,73097],[73112],[73120,73129],[73440,73458],[73463,73464],[73476,73488],[73490,73523],[73539,73561],[73648],[73664,73713],[73727,74649],[74752,74862],[74864,74868],[74880,75075],[77712,77810],[77824,78895],[78913,78918],[82944,83526],[92160,92728],[92736,92766],[92768,92777],[92782,92862],[92864,92873],[92880,92909],[92917],[92928,92975],[92983,92997],[93008,93017],[93019,93025],[93027,93047],[93053,93071],[93760,93850],[93952,94026],[94032],[94099,94111],[94176,94179],[94208],[100343],[100352,101589],[101632],[101640],[110576,110579],[110581,110587],[110589,110590],[110592,110882],[110898],[110928,110930],[110933],[110948,110951],[110960,111355],[113664,113770],[113776,113788],[113792,113800],[113808,113817],[113820],[113823],[118608,118723],[118784,119029],[119040,119078],[119081,119140],[119146,119148],[119171,119172],[119180,119209],[119214,119274],[119296,119361],[119365],[119488,119507],[119520,119539],[119552,119638],[119648,119672],[119808,119892],[119894,119964],[119966,119967],[119970],[119973,119974],[119977,119980],[119982,119993],[119995],[119997,120003],[120005,120069],[120071,120074],[120077,120084],[120086,120092],[120094,120121],[120123,120126],[120128,120132],[120134],[120138,120144],[120146,120485],[120488,120779],[120782,121343],[121399,121402],[121453,121460],[121462,121475],[121477,121483],[122624,122654],[122661,122666],[122928,122989],[123136,123180],[123191,123197],[123200,123209],[123214,123215],[123536,123565],[123584,123627],[123632,123641],[123647],[124112,124139],[124144,124153],[124896,124902],[124904,124907],[124909,124910],[124912,124926],[124928,125124],[125127,125135],[125184,125251],[125259],[125264,125273],[125278,125279],[126065,126132],[126209,126269],[126464,126467],[126469,126495],[126497,126498],[126500],[126503],[126505,126514],[126516,126519],[126521],[126523],[126530],[126535],[126537],[126539],[126541,126543],[126545,126546],[126548],[126551],[126553],[126555],[126557],[126559],[126561,126562],[126564],[126567,126570],[126572,126578],[126580,126583],[126585,126588],[126590],[126592,126601],[126603,126619],[126625,126627],[126629,126633],[126635,126651],[126704,126705],[126976,127019],[127024,127123],[127136,127150],[127153,127167],[127169,127183],[127185,127221],[127232,127405],[127488,127490],[127504,127547],[127552,127560],[127568,127569],[127584,127589],[127744,127994],[128000,128727],[128732,128748],[128752,128764],[128768,128886],[128891,128985],[128992,129003],[129008],[129024,129035],[129040,129095],[129104,129113],[129120,129159],[129168,129197],[129200,129201],[129280,129619],[129632,129645],[129648,129660],[129664,129672],[129680,129725],[129727,129733],[129742,129755],[129760,129768],[129776,129784],[129792,129938],[129940,129994],[130032,130041],[131072],[173791],[173824],[177977],[177984],[178205],[178208],[183969],[183984],[191456],[191472],[192093],[194560,195101],[196608],[201546],[201552],[205743]],or=[[192,197],[199,207],[209,214],[217,221],[224,229],[231,239],[241,246],[249,253],[255,271],[274,293],[296,304],[308,311],[313,318],[323,328],[332,337],[340,357],[360,382],[416,417],[431,432],[461,476],[478,483],[486,496],[500,501],[504,539],[542,543],[550,563],[901,902],[904,906],[908],[910,912],[938,944],[970,974],[979,980],[1024,1025],[1027],[1031],[1036,1038],[1049],[1081],[1104,1105],[1107],[1111],[1116,1118],[1142,1143],[1217,1218],[1232,1235],[1238,1239],[1242,1247],[1250,1255],[1258,1269],[1272,1273],[1570,1574],[1728],[1730],[1747],[2345],[2353],[2356],[2392,2399],[2524,2525],[2527],[2611],[2614],[2649,2651],[2654],[2908,2909],[2964],[3907],[3917],[3922],[3927],[3932],[3945],[4134],[6918],[6920],[6922],[6924],[6926],[6930],[7680,7833],[7835],[7840,7929],[7936,7957],[7960,7965],[7968,8005],[8008,8013],[8016,8023],[8025],[8027],[8029],[8031,8048],[8050],[8052],[8054],[8056],[8058],[8060],[8064,8116],[8118,8122],[8124],[8129,8132],[8134,8136],[8138],[8140,8146],[8150,8154],[8157,8162],[8164,8170],[8172,8173],[8178,8180],[8182,8184],[8186],[8188],[8602,8603],[8622],[8653,8655],[8708],[8713],[8716],[8740],[8742],[8769],[8772],[8775],[8777],[8800],[8802],[8813,8817],[8820,8821],[8824,8825],[8832,8833],[8836,8837],[8840,8841],[8876,8879],[8928,8931],[8938,8941],[10972],[12364],[12366],[12368],[12370],[12372],[12374],[12376],[12378],[12380],[12382],[12384],[12386],[12389],[12391],[12393],[12400,12401],[12403,12404],[12406,12407],[12409,12410],[12412,12413],[12436],[12446],[12460],[12462],[12464],[12466],[12468],[12470],[12472],[12474],[12476],[12478],[12480],[12482],[12485],[12487],[12489],[12496,12497],[12499,12500],[12502,12503],[12505,12506],[12508,12509],[12532],[12535,12538],[12542],[44032],[55203],[64285],[64287],[64298,64310],[64312,64316],[64318],[64320,64321],[64323,64324],[64326,64334],[69786],[69788],[69803],[119134,119140],[119227,119232]],KP=String.fromCodePoint,ir=Math.min,rr=Math.max;function eH(X){if(X.length===1){let Q=KP(X[0]);return{num:1,build:()=>Q}}let Y=X[0];return{num:X[1]-X[0]+1,build:(Q)=>KP(Y+Q)}}function HP(X,Y){let Q=[],J=0,$=0;while(J<X.length&&$<Y.length){let G=X[J],_=G[0],K=G.length===1?G[0]:G[1],H=Y[$],W=H[0],D=H.length===1?H[0]:H[1];if(K<W)J+=1;else if(D<_)$+=1;else{let U=rr(_,W),N=ir(K,D);if(Q.length>=1){let B=Q[Q.length-1];if((B.length===1?B[0]:B[1])+1===U)U=B[0],Gw(Q)}if(I(Q,U===N?[U]:[U,N]),K<=N)J+=1;if(D<=N)$+=1}}return Q}var WP=Object.create(null);function nr(X){switch(X){case"full":return cr;case"ascii":return ur}}function sr(X,Y){let Q=`${X}:${Y}`,J=WP[Q];if(J!==void 0)return J;let $=nr(Y),G=X==="binary"?$:HP($,lr),_=[];for(let H of G)I(_,eH(H));if(X==="grapheme"){let H=HP($,or);for(let W of H){let D=eH(W);I(_,{num:D.num,build:(U)=>Jo(D.build(U),"NFD")})}}let K=S9(..._);return WP[Q]=K,K}function yQ(X,Y){return sr(X,Y)}function ar(X){if(typeof X.unit==="object")return X.unit;switch(X.unit){case"grapheme":return yQ("grapheme","full");case"grapheme-composite":return yQ("composite","full");case"grapheme-ascii":case void 0:return yQ("grapheme","ascii");case"binary":return yQ("binary","full");case"binary-ascii":return yQ("binary","ascii")}}function e0(X={}){let Y=ar(X),Q=hr(Y,X),J=pr(Y,X);return M0(Y,{...X,experimentalCustomSlices:J}).map(gr,Q)}var mw=Map,jW=String.fromCharCode,IW={num:26,build:(X)=>jW(X+97)},tr={num:26,build:(X)=>jW(X+65)},fw={num:10,build:(X)=>jW(X+48)};function er(X){let Y=zl(X);return X!==Y?Y:`%${pQ(j9(X,0),16)}`}function Xn(X){if(typeof X!=="string")throw Error("Unsupported");return decodeURIComponent(X)}var Yn=()=>e0({unit:"binary",minLength:1,maxLength:1}).map(er,Xn),jH=void 0;function Qn(){if(jH===void 0)jH=S9(IW);return jH}var q$=void 0;function XW(X){if(q$===void 0)q$=new mw;let Y=VX(q$,X);if(Y===void 0)Y=S9(IW,fw,{num:X.length,build:(Q)=>X[Q]}),tX(q$,X,Y);return Y}function Jn(X){return S9(IW,tr,fw,{num:X.length,build:(Y)=>X[Y]})}var L$=void 0;function xW(X){if(L$===void 0)L$=new mw;let Y=VX(L$,X);if(Y===void 0)Y=K1({weight:10,arbitrary:Jn(X)},{weight:1,arbitrary:Yn()}),tX(L$,X,Y);return Y}function z8(X,Y={}){let Q=Y.freq===void 0?6:Y.freq,J=Hw(Y,"nil")?Y.nil:null,$=[{arbitrary:y0(J),weight:1,fallbackValue:{default:J}},{arbitrary:X,weight:Q-1}],G={withCrossShrink:!0,depthSize:Y.depthSize,maxDepth:Y.maxDepth,depthIdentifier:Y.depthIdentifier};return tH.from($,G,"fc.option")}function $n(X){if(X.length>63)return!1;return X.length<4||X[0]!=="x"||X[1]!=="n"||X[2]!=="-"||X[3]!=="-"}var dw=Symbol("adapted-value");function Gn(X,Y){let Q=Y(X.value_);if(!Q.adapted)return X;return new g(Q.value,dw)}var Zn=class extends m0{constructor(X,Y){super();this.sourceArb=X,this.adapter=Y,this.adaptValue=(Q)=>Gn(Q,Y)}generate(X,Y){let Q=this.sourceArb.generate(X,Y);return this.adaptValue(Q)}canShrinkWithoutContext(X){return this.sourceArb.canShrinkWithoutContext(X)&&!this.adapter(X).adapted}shrink(X,Y){if(Y===dw){if(!this.sourceArb.canShrinkWithoutContext(X))return K0.nil();return this.sourceArb.shrink(X,void 0).map(this.adaptValue)}return this.sourceArb.shrink(X,Y).map(this.adaptValue)}};function pw(X,Y){return new Zn(X,Y)}function _n([X,Y]){return Y===null?X:`${X}${Y[0]}${Y[1]}`}function Kn(X){if(typeof X!=="string"||X.length===0)throw Error("Unsupported");if(X.length===1)return[X[0],null];return[X[0],[u0(X,1,X.length-1),X[X.length-1]]]}function Hn(X){let Y=XW("");return _0(Y,z8(_0(e0({unit:XW("-"),size:X,maxLength:61}),Y))).map(_n,Kn).filter($n)}function Wn(X){return`${h0(X[0],".")}.${X[1]}`}function Un(X){if(typeof X!=="string")throw Error("Unsupported type");let Y=X.lastIndexOf(".");return[p1(u0(X,0,Y),"."),u0(X,Y+1)]}function Dn(X){let[Y,Q]=X,J=Q.length;for(let $=0;$!==Y.length;++$)if(J+=1+Y[$].length,J>255)return{adapted:!0,value:[_1(Y,0,$),Q]};return{adapted:!1,value:X}}function SW(X={}){let Y=EW(X.size),Q=oQ("-1",Y),J=e0({unit:Qn(),minLength:2,maxLength:63,size:Q});return pw(_0(M0(Hn(Y),{size:Q,minLength:1,maxLength:127}),J),Dn).map(Wn,Un)}function Nn(X){let Y=X[0].length;for(let Q=1;Q!==X.length;++Q)if(Y+=1+X[Q].length,Y>64)return{adapted:!0,value:_1(X,0,Q)};return{adapted:!1,value:X}}function Bn(X){return h0(X,".")}function Vn(X){if(typeof X!=="string")throw Error("Unsupported");return p1(X,".")}function zn(X){return`${X[0]}@${X[1]}`}function qn(X){if(typeof X!=="string")throw Error("Unsupported");return p1(X,"@",2)}function Ln(X={}){return _0(pw(M0(e0({unit:XW("!#$%&'*+-/=?^_`{|}~"),minLength:1,maxLength:64,size:X.size}),{minLength:1,maxLength:32,size:X.size}),Nn).map(Bn,Vn),SW({size:X.size})).map(zn,qn)}var{NEGATIVE_INFINITY:On,POSITIVE_INFINITY:YW,EPSILON:uw}=N8,vW=b(2146435072)*b(4294967296),Tn=-vW-b(1),UP=4503599627370496,Fn=b(4503599627370495),DP=b("9007199254740992"),QW=new Float64Array(1),NP=new Uint32Array(QW.buffer,QW.byteOffset);function Rn(X){return QW[0]=X,[NP[1],NP[0]]}function An(X){let{0:Y,1:Q}=Rn(X),J=Y>>>31,$=Y>>>20&2047,G=(Y&1048575)*4294967296+Q,_=$===0?-1022:$-1023,K=$===0?0:1;return K+=G*uw,K*=J===0?1:-1,{exponent:_,significand:K}}function BP(X,Y){if(X===-1022)return b(Y*UP);return b((Y-1)*UP)+(b(X+1023)<<b(52))}function kW(X){if(X===YW)return vW;if(X===On)return Tn;let Y=An(X),Q=Y.exponent,J=Y.significand;if(X>0||X===0&&1/X===YW)return BP(Q,J);else return-BP(Q,-J)-b(1)}function JW(X){if(X<0)return-JW(-X-b(1));if(X===vW)return YW;if(X<DP)return N8(X)*0.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005;let Y=X-DP,Q=-1021+N8(Y>>b(52));return(1+N8(Y&Fn)*uw)*2**Q}var VP=Number.isInteger,zP=Object.is,IH=Number.NEGATIVE_INFINITY,xH=Number.POSITIVE_INFINITY;function cw(X,Y,Q,J){let{noDefaultInfinity:$=!1,minExcluded:G=!1,maxExcluded:_=!1,min:K=$?-Y:IH,max:H=$?Y:xH}=X,W=G?K<-Q?-J:Math.max(K,-Q):K===IH?Math.max(K,-J):Math.max(K,-Q),D=_?H>Q?J:Math.min(H,Q):H===xH?Math.min(H,J):Math.min(H,Q);return{noDefaultInfinity:!1,minExcluded:G||(K!==IH||G)&&VP(W),maxExcluded:_||(H!==xH||_)&&VP(D),min:zP(W,-0)?0:W,max:zP(D,0)?-0:D,noNaN:X.noNaN||!1}}var{NEGATIVE_INFINITY:lw,POSITIVE_INFINITY:ow,MAX_VALUE:Pn}=Number,wn=4503599627370495.5,iw=4503599627370496;function Cn(X){return cw(X,Pn,wn,iw)}function En(X){return X===4503599627370496?ow:X===-4503599627370496?lw:X}function Mn(X){if(typeof X!=="number")throw Error("Unsupported type");return X===ow?iw:X===lw?-4503599627370496:X}var{isInteger:jn,isNaN:rw,NEGATIVE_INFINITY:In,POSITIVE_INFINITY:xn,MAX_VALUE:qP}=Number,Sn=NaN;function LP(X,Y){if(rw(X))throw Error("fc.double constraints."+Y+" must be a 64-bit float");return kW(X)}function vn(X){if(typeof X!=="number")throw Error("Unsupported type");return kW(X)}function kn(X){return!jn(X)}function OP(X){let{noDefaultInfinity:Y=!1,noNaN:Q=!1,minExcluded:J=!1,maxExcluded:$=!1,min:G=Y?-qP:In,max:_=Y?qP:xn}=X,K=LP(G,"min"),H=J?K+b(1):K,W=LP(_,"max"),D=$?W-b(1):W;if(D<H)throw Error("fc.double constraints.min must be smaller or equal to constraints.max");if(Q)return K4({min:H,max:D}).map(JW,vn);let U=D>b(0),N=U?H:H-b(1),B=U?D+b(1):D;return K4({min:N,max:B}).map((z)=>{if(D<z||z<H)return Sn;else return JW(z)},(z)=>{if(typeof z!=="number")throw Error("Unsupported type");if(rw(z))return D!==B?B:N;return kW(z)})}function y$(X={}){if(!X.noInteger)return OP(X);return OP(Cn(X)).map(En,Mn).filter(kn)}var{NEGATIVE_INFINITY:bn,POSITIVE_INFINITY:$W}=Number,gn=Math.imul,GW=340282346638528860000000000000000000000,nw=2139095040,yn=-2139095041,ZW=new Float32Array(1),hn=new Uint32Array(ZW.buffer,ZW.byteOffset);function mn(X){return ZW[0]=X,hn[0]}function fn(X){let Y=mn(X),Q=Y>>>31,J=Y>>>23&255,$=Y&8388607,G=J===0?-126:J-127,_=J===0?0:1;return _+=$/8388608,_*=Q===0?1:-1,{exponent:G,significand:_}}function TP(X,Y){if(X===-126)return Y*8388608;return gn(X+127,8388608)+(Y-1)*8388608}function bW(X){if(X===$W)return nw;if(X===bn)return yn;let Y=fn(X),Q=Y.exponent,J=Y.significand;if(X>0||X===0&&1/X===$W)return TP(Q,J);else return-TP(Q,-J)-1}function _W(X){if(X<0)return-_W(-X-1);if(X===nw)return $W;if(X<16777216)return X*0.000000000000000000000000000000000000000000001401298464324817;let Y=X-16777216,Q=-125+(Y>>23);return(1+(Y&8388607)/8388608)*2**Q}var{NEGATIVE_INFINITY:sw,POSITIVE_INFINITY:aw}=Number,dn=GW,pn=8388607.5,tw=8388608;function un(X){return cw(X,dn,pn,tw)}function cn(X){return X===8388608?aw:X===-8388608?sw:X}function ln(X){if(typeof X!=="number")throw Error("Unsupported type");return X===aw?tw:X===sw?-8388608:X}var{isInteger:on,isNaN:ew}=Number,rn=Math.fround,nn=Number.NEGATIVE_INFINITY,sn=Number.POSITIVE_INFINITY,an=NaN;function FP(X,Y){let Q="fc.float constraints."+Y+" must be a 32-bit float - you can convert any double to a 32-bit float by using `Math.fround(myDouble)`";if(ew(X)||rn(X)!==X)throw Error(Q);return bW(X)}function tn(X){if(typeof X!=="number")throw Error("Unsupported type");return bW(X)}function en(X){return!on(X)}function RP(X){let{noDefaultInfinity:Y=!1,noNaN:Q=!1,minExcluded:J=!1,maxExcluded:$=!1,min:G=Y?-GW:nn,max:_=Y?GW:sn}=X,K=FP(G,"min"),H=J?K+1:K,W=FP(_,"max"),D=$?W-1:W;if(H>D)throw Error("fc.float constraints.min must be smaller or equal to constraints.max");if(Q)return w0({min:H,max:D}).map(_W,tn);let U=D>0?H:H-1,N=D>0?D+1:D;return w0({min:U,max:N}).map((B)=>{if(B>D||B<H)return an;else return _W(B)},(B)=>{if(typeof B!=="number")throw Error("Unsupported type");if(ew(B))return D!==N?N:U;return bW(B)})}function XC(X={}){if(!X.noInteger)return RP(X);return RP(un(X)).map(cn,ln).filter(en)}function Xs(X){return X.replace(/([$`\\])/g,"\\$1").replace(/\r/g,"\\r")}function YC(X){return X.replace(/\*\//g,"*\\/")}var NX=[0,1996959894,3993919788,2567524794,124634137,1886057615,3915621685,2657392035,249268274,2044508324,3772115230,2547177864,162941995,2125561021,3887607047,2428444049,498536548,1789927666,4089016648,2227061214,450548861,1843258603,4107580753,2211677639,325883990,1684777152,4251122042,2321926636,335633487,1661365465,4195302755,2366115317,997073096,1281953886,3579855332,2724688242,1006888145,1258607687,3524101629,2768942443,901097722,1119000684,3686517206,2898065728,853044451,1172266101,3705015759,2882616665,651767980,1373503546,3369554304,3218104598,565507253,1454621731,3485111705,3099436303,671266974,1594198024,3322730930,2970347812,795835527,1483230225,3244367275,3060149565,1994146192,31158534,2563907772,4023717930,1907459465,112637215,2680153253,3904427059,2013776290,251722036,2517215374,3775830040,2137656763,141376813,2439277719,3865271297,1802195444,476864866,2238001368,4066508878,1812370925,453092731,2181625025,4111451223,1706088902,314042704,2344532202,4240017532,1658658271,366619977,2362670323,4224994405,1303535960,984961486,2747007092,3569037538,1256170817,1037604311,2765210733,3554079995,1131014506,879679996,2909243462,3663771856,1141124467,855842277,2852801631,3708648649,1342533948,654459306,3188396048,3373015174,1466479909,544179635,3110523913,3462522015,1591671054,702138776,2966460450,3352799412,1504918807,783551873,3082640443,3233442989,3988292384,2596254646,62317068,1957810842,3939845945,2647816111,81470997,1943803523,3814918930,2489596804,225274430,2053790376,3826175755,2466906013,167816743,2097651377,4027552580,2265490386,503444072,1762050814,4150417245,2154129355,426522225,1852507879,4275313526,2312317920,282753626,1742555852,4189708143,2394877945,397917763,1622183637,3604390888,2714866558,953729732,1340076626,3518719985,2797360999,1068828381,1219638859,3624741850,2936675148,906185462,1090812512,3747672003,2825379669,829329135,1181335161,3412177804,3160834842,628085408,1382605366,3423369109,3138078467,570562233,1426400815,3317316542,2998733608,733239954,1555261956,3268935591,3050360625,752459403,1541320221,2607071920,3965973030,1969922972,40735498,2617837225,3943577151,1913087877,83908371,2512341634,3803740692,2075208622,213261112,2463272603,3855990285,2094854071,198958881,2262029012,4057260610,1759359992,534414190,2176718541,4139329115,1873836001,414664567,2282248934,4279200368,1711684554,285281116,2405801727,4167216745,1634467795,376229701,2685067896,3608007406,1308918612,956543938,2808555105,3495958263,1231636301,1047427035,2932959818,3654703836,1088359270,936918000,2847714899,3736837829,1202900863,817233897,3183342108,3401237130,1404277552,615818150,3134207493,3453421203,1423857449,601450431,3009837614,3294710456,1567103746,711928724,3020668471,3272380065,1510334235,755167117];function v$(X){let Y=4294967295;for(let Q=0;Q<X.length;++Q){let J=j9(X,Q);if(J<128)Y=NX[Y&255^J]^Y>>8;else if(J<2048)Y=NX[Y&255^(192|J>>6&31)]^Y>>8,Y=NX[Y&255^(128|J&63)]^Y>>8;else if(J>=55296&&J<57344){let $=j9(X,++Q);if(J>=56320||$<56320||$>57343||Number.isNaN($))Q-=1,Y=NX[Y&255^239]^Y>>8,Y=NX[Y&255^191]^Y>>8,Y=NX[Y&255^189]^Y>>8;else{let G=(J&1023)+64,_=$&1023;Y=NX[Y&255^(240|G>>8&7)]^Y>>8,Y=NX[Y&255^(128|G>>2&63)]^Y>>8,Y=NX[Y&255^(128|_>>6&15|(G&3)<<4)]^Y>>8,Y=NX[Y&255^(128|_&63)]^Y>>8}}else Y=NX[Y&255^(224|J>>12&15)]^Y>>8,Y=NX[Y&255^(128|J>>6&63)]^Y>>8,Y=NX[Y&255^(128|J&63)]^Y>>8}return(Y|0)+2147483648}var Ys=Object.getPrototypeOf,hQ=class extends m0{constructor(X){super();this.arb=X}generate(X,Y){return this.arb.generate(X,Y)}canShrinkWithoutContext(X){return this.arb.canShrinkWithoutContext(X)}shrink(X,Y){return K0.nil()}};function k$(X){if(Ys(X)===hQ.prototype&&X.generate===hQ.prototype.generate&&X.canShrinkWithoutContext===hQ.prototype.canShrinkWithoutContext&&X.shrink===hQ.prototype.shrink)return X;return new hQ(X)}var{assign:Qs,keys:Js}=Object;function QC(X){return _0(k$(w0()),k$(w0({min:1,max:4294967295}))).map(([Y,Q])=>{let J=()=>{let $={};return Qs((_,K)=>{let H=s0(_),W=s0(K),D=X(v$(`${Y}${H}`)%Q,v$(`${Y}${W}`)%Q);return $[`[${H},${W}]`]=D,D},{toString:()=>{let _=Js($).sort().map((K)=>`${K} => ${s0($[K])}`).map((K)=>`/* ${YC(K)} */`);return`function(a, b) {
  // With hash and stringify coming from fast-check${_.length!==0?`
  ${h0(_,`
  `)}`:""}
  const cmp = ${X};
  const hA = hash('${Y}' + stringify(a)) % ${Q};
  const hB = hash('${Y}' + stringify(b)) % ${Q};
  return cmp(hA, hB);
}`},[H1]:J})};return J()})}var $s=Object.assign;function Gs(){return QC($s((X,Y)=>X<Y,{toString(){return"(hA, hB) => hA < hB"}}))}var Zs=Object.assign;function _s(){return QC(Zs((X,Y)=>X-Y,{toString(){return"(hA, hB) => hA - hB"}}))}var{defineProperties:Ks,keys:Hs}=Object;function Ws(X){return _0(M0(X,{minLength:1}),k$(w0())).map(([Y,Q])=>{let J=()=>{let $={},G=(...K)=>{let H=s0(K),W=Y[v$(`${Q}${H}`)%Y.length];return $[H]=W,D5(W)?W[H1]():W};function _(K){let H=L0(L0(_w(Hs($)),(W)=>`${W} => ${s0($[W])}`),(W)=>`/* ${YC(W)} */`);return`function(...args) {
  // With hash and stringify coming from fast-check${H.length!==0?`
  ${H.join(`
  `)}`:""}
  const outs = ${K};
  return outs[hash('${Q}' + stringify(args)) % outs.length];
}`}return Ks(G,{toString:{value:()=>_(s0(Y))},[Y6]:{value:()=>_(s0(Y))},[V8]:{value:async()=>_(await FW(Y))},[H1]:{value:J,configurable:!0}})};return J()})}var{MIN_SAFE_INTEGER:Us,MAX_SAFE_INTEGER:Ds}=Number;function JC(){return new x9(Us,Ds)}var Ns=Number.MAX_SAFE_INTEGER;function Bs(){return new x9(0,Ns)}var Vs=Number.parseInt;function zs(X){let[Y,Q]=X;switch(Y){case"oct":return`0${pQ(Q,8)}`;case"hex":return`0x${pQ(Q,16)}`;default:return`${Q}`}}function P$(X,Y){let Q=Vs(X,Y);if(pQ(Q,Y)!==X)throw Error("Invalid value");return Q}function qs(X){if(typeof X!=="string")throw Error("Invalid type");if(X.length>=2&&X[0]==="0"){if(X[1]==="x")return["hex",P$(u0(X,2),16)];return["oct",P$(u0(X,1),8)]}return["dec",P$(X,10)]}function Ls(X){return h0(X,".")}function Os(X){if(typeof X!=="string")throw Error("Invalid type");return L0(p1(X,"."),(Y)=>P$(Y,10))}function gW(){return _0(G4(255),G4(255),G4(255),G4(255)).map(Ls,Os)}function E6(X){return _0(M6("dec","oct","hex"),G4(X)).map(zs,qs)}function SH(X){return h0(X,".")}function vH(X){if(typeof X!=="string")throw Error("Invalid type");return p1(X,".")}function $C(){return K1(_0(E6(255),E6(255),E6(255),E6(255)).map(SH,vH),_0(E6(255),E6(255),E6(65535)).map(SH,vH),_0(E6(255),E6(16777215)).map(SH,vH),E6(4294967295))}function yW(X){if(X.length===0)return[];else return p1(X,":")}function hW(X){let Y=p1(X,":");if(Y.length>=2&&Y[Y.length-1].length<=4)return[_1(Y,0,Y.length-2),`${Y[Y.length-2]}:${Y[Y.length-1]}`];return[_1(Y,0,Y.length-1),Y[Y.length-1]]}function Ts(X){return`${h0(X[0],":")}:${X[1]}`}function Fs(X){if(typeof X!=="string")throw Error("Invalid type");return hW(X)}function Rs(X){return`::${h0(X[0],":")}:${X[1]}`}function As(X){if(typeof X!=="string")throw Error("Invalid type");if(!Xo(X,"::"))throw Error("Invalid value");return hW(u0(X,2))}function w$(X){return`${h0(X[0],":")}::${h0(X[1],":")}:${X[2]}`}function C$(X){if(typeof X!=="string")throw Error("Invalid type");let[Y,Q]=p1(X,"::",2),[J,$]=hW(Q);return[yW(Y),J,$]}function Ps(X){return w$([X[0],[X[1]],X[2]])}function ws(X){let Y=C$(X);return[Y[0],h0(Y[1],":"),Y[2]]}function AP(X){return`${h0(X[0],":")}::${X[1]}`}function PP(X){if(typeof X!=="string")throw Error("Invalid type");let[Y,Q]=p1(X,"::",2);return[yW(Y),Q]}function Cs(X){return`${h0(X[0],":")}::`}function Es(X){if(typeof X!=="string")throw Error("Invalid type");if(!Yo(X,"::"))throw Error("Invalid value");return[yW(u0(X,0,X.length-2))]}function Ms([X,Y]){return`${X}:${Y}`}function js(X){if(typeof X!=="string")throw new y("Invalid type");if(!X.includes(":"))throw new y("Invalid value");return X.split(":",2)}var Is="0123456789abcdef",kH=void 0;function xs(){if(kH===void 0)kH=w0({min:0,max:15}).map((X)=>Is[X],(X)=>{if(typeof X!=="string")throw new y("Not a string");if(X.length!==1)throw new y("Invalid length");let Y=j9(X,0);if(Y<=57)return Y-48;if(Y<97)throw new y("Invalid character");return Y-87});return kH}function GC(){let X=e0({unit:xs(),minLength:1,maxLength:4,size:"max"}),Y=K1(_0(X,X).map(Ms,js),gW());return K1(_0(M0(X,{minLength:6,maxLength:6,size:"max"}),Y).map(Ts,Fs),_0(M0(X,{minLength:5,maxLength:5,size:"max"}),Y).map(Rs,As),_0(M0(X,{minLength:0,maxLength:1,size:"max"}),M0(X,{minLength:4,maxLength:4,size:"max"}),Y).map(w$,C$),_0(M0(X,{minLength:0,maxLength:2,size:"max"}),M0(X,{minLength:3,maxLength:3,size:"max"}),Y).map(w$,C$),_0(M0(X,{minLength:0,maxLength:3,size:"max"}),M0(X,{minLength:2,maxLength:2,size:"max"}),Y).map(w$,C$),_0(M0(X,{minLength:0,maxLength:4,size:"max"}),X,Y).map(Ps,ws),_0(M0(X,{minLength:0,maxLength:5,size:"max"}),Y).map(AP,PP),_0(M0(X,{minLength:0,maxLength:6,size:"max"}),X).map(AP,PP),_0(M0(X,{minLength:0,maxLength:7,size:"max"})).map(Cs,Es))}var Ss=class extends m0{constructor(X){super();this.name=X,this.underlying=null}generate(X,Y){if(this.underlying===null)throw Error(`Lazy arbitrary ${JSON.stringify(this.name)} not correctly initialized`);return this.underlying.generate(X,Y)}canShrinkWithoutContext(X){if(this.underlying===null)throw Error(`Lazy arbitrary ${JSON.stringify(this.name)} not correctly initialized`);return this.underlying.canShrinkWithoutContext(X)}shrink(X,Y){if(this.underlying===null)throw Error(`Lazy arbitrary ${JSON.stringify(this.name)} not correctly initialized`);return this.underlying.shrink(X,Y)}},vs=Object.getOwnPropertyNames;function ks(){let X=new B8;return(Q)=>{let J=VX(X,Q);if(J!==void 0)return J;return J=new Ss(String(Q)),tX(X,Q,J),J}}function ZC(X){let Y=ks(),Q=X(Y),J=vs(Q);for(let $ of J){let G=Y($);G.underlying=Q[$]}return Q}function bs(X,Y){for(let Q of X){let J=Y[Q]||{};if(J.maxLength===void 0||J.maxLength>0)return!0}return!1}function gs(X,Y){if(X.length===0)return y0([]);if(!bs(X,Y))throw new y("Contraints on pool must accept at least one entity, maxLength cannot sum to 0");return _0(...X.map((Q)=>M0(y0(Q),Y[Q]))).map((Q)=>jl(Q)).filter((Q)=>Q.length>0)}var{assign:wP,create:E$,defineProperty:_C,getPrototypeOf:CP,prototype:ys}=Object;function hs(X){return _C(E$(null),Y6,{configurable:!1,enumerable:!1,writable:!1,value:()=>X})}function EP(X,Y){return hs(`<${d1(X)}#${Y}>`)}function ms(X,Y){let Q=E$(ys);for(let J in X){let $=X[J],G=[];for(let _ of $){let K=wP(E$(CP(_)),_);G.push(K)}Q[J]=G}for(let J in Y){let $=Y[J];for(let G=0;G!==$.length;++G){let _=$[G],K=Q[J][G];for(let H in _){let W=_[H];K[H]=W.index===void 0?void 0:typeof W.index==="number"?Q[W.type][W.index]:L0(W.index,(D)=>Q[W.type][D])}_C(K,Y6,{configurable:!1,enumerable:!1,writable:!1,value:()=>{let H=X[J][G],W=wP(E$(CP(H)),H);for(let D in _){let U=_[D];W[D]=U.index===void 0?void 0:typeof U.index==="number"?EP(U.type,U.index):L0(U.index,(N)=>EP(U.type,N))}return s0(W)}})}}return Q}function fs(X){let Y=0,Q=new B8;for(let $ in X){let G=X[$];for(let _ in G){let K=G[_];if(K.arity!=="inverse")continue;let H=VX(Q,K.type);if(H===void 0)H=new B8,tX(Q,K.type,H);if(ul(H,K.forwardRelationship))throw new y(`Cannot declare multiple inverse relationships for the same forward relationship ${d1(K.forwardRelationship)} on type ${d1(K.type)}`);tX(H,K.forwardRelationship,{type:$,property:_}),Y+=1}}let J=new B8;if(Y===0)return J;for(let $ in X){let G=X[$],_=VX(Q,$);if(_===void 0)continue;for(let K in G){let H=G[K];if(H.arity==="inverse")continue;let W=VX(_,K);if(W===void 0)continue;if(W.type!==H.type)throw new y(`Inverse relationship ${d1(W.property)} on type ${d1(W.type)} references forward relationship ${d1(K)} but types do not match`);tX(J,H,W)}}if(J.size!==Y)throw new y("Some inverse relationships could not be matched with their corresponding forward relationships");return J}var{assign:MP,create:b$}=Object;function ds(X,Y,Q){switch(X){case"exclusive":return y0(Q);case"successor":return S$(w0({min:Y!==void 0?Y+1:0,max:Q}));case"any":return S$(w0({min:0,max:Q}))}}function ps(X,Y,Q,J,$){let G=ds(Y,Q,J);switch(X){case"0-1":return z8(G,{nil:void 0,depthIdentifier:$});case"1":return G;case"many":{let _=0;return z8(B5(G,{depthIdentifier:$,selector:(K)=>K===J?K+ ++_:K,minLength:1}),{nil:[],depthIdentifier:$}).map((K)=>{let H=0;return L0(K,(W)=>W===J?W+H++:W)})}}}function KC(X,Y){let Q=b$(null),J=X[Y];for(let $ in J){let G=J[$];if(G.arity==="inverse")Q[$]={type:G.type,index:[]}}return Q}function us(X){let Y=new eX,Q=new eX;for(let J in X){let $=X[J];for(let G in $){let _=$[G];if(_.arity==="inverse")continue;if(_.strategy==="exclusive"){if($4(Y,_.type))throw new y(`Cannot mix exclusive with other strategies for type ${d1(_.type)}`);dQ(Q,_.type)}else{if($4(Q,_.type))throw new y(`Cannot mix exclusive with other strategies for type ${d1(_.type)}`);dQ(Y,_.type)}if(_.strategy==="successor"&&_.type!==J)throw new y("Cannot mix types for the strategy successor");if(_.strategy==="successor"&&_.arity==="1")throw new y("Cannot use an arity of 1 for the strategy successor")}}}function cs(X,Y){let{producedLinks:Q,toBeProducedEntities:J}=X,$=X.nextIndex+Y,G=MP(b$(null),Q);function _(U){if(G[U]===Q[U])G[U]=_1(Q[U]);return G[U]}function K(U,N){let B=_(U);if(B[N]===Q[U][N])B[N]=MP(b$(null),Q[U][N]);return B[N]}function H(U,N,B){let z=K(U,N),q=Q[U][N];if(q!==void 0&&z[B]===q[B]){let F=z[B];z[B]={type:F.type,index:typeof F.index==="object"?_1(F.index):F.index}}return z[B]}let W=void 0,D=J[$];return{setOutboundLink:(U,N)=>{let B=K(D.type,D.indexInType);B[U]=N},enqueueNewEntity:(U,N)=>{let B=_(N),z=B.length;if(W===void 0)W=_1(J);return I(W,{type:N,indexInType:z,depth:D.depth+1}),I(B,KC(U,N)),z},appendBackReference:(U,N,B)=>{let z=H(U,N,B).index;I(z,D.indexInType)},commit:()=>({producedLinks:G,toBeProducedEntities:W!==void 0?W:J,nextIndex:$+1})}}function ls(X,Y){let Q=b$(null);for(let $ in X)Q[$]=[];let J=[];for(let $ of Y)I(J,{type:$,indexInType:Q[$].length,depth:0}),I(Q[$],KC(X,$));return{producedLinks:Q,toBeProducedEntities:J,nextIndex:0}}function os(X,Y,Q,J){let $=Q.producedLinks,G=Q.toBeProducedEntities[Q.nextIndex+J],_=X[G.type],K=wW();K.depth=G.depth;let H=[],W=[];for(let D in _){let U=_[D];if(U.arity==="inverse")continue;let N=U.type,B=$[N].length;I(H,ps(U.arity,U.strategy||"any",N===G.type?G.indexInType:void 0,B,K)),I(W,{name:D,relation:U,sentinelLinkIndex:B})}if(H.length===0)return;return _0(...H).map((D)=>{let U=cs(Q,J);for(let N=0;N!==D.length;++N){let B=D[N],{name:z,relation:q,sentinelLinkIndex:F}=W[N],R=[],C=B===void 0?[]:typeof B==="number"?[B]:B;for(let E of C){let a;if(E>=F)a=U.enqueueNewEntity(X,q.type);else a=E;I(R,a);let L=VX(Y,q);if(L!==void 0)U.appendBackReference(q.type,a,L.property)}U.setOutboundLink(z,{type:q.type,index:B===void 0?void 0:typeof B==="number"?R[0]:R})}return U.commit()})}function is(X,Y){us(X);let Q=fs(X);return kw(y0(ls(X,Y)),(J)=>{if(J.nextIndex>=J.toBeProducedEntities.length)return;let $=0,G=void 0;while(G===void 0&&J.nextIndex+$<J.toBeProducedEntities.length)G=os(X,Q,J,$),$+=1;return G}).map((J)=>{return J.producedLinks})}var{keys:rs,getOwnPropertySymbols:ns,getOwnPropertyDescriptor:ss}=Object;function as(X){let Y=rs(X),Q=ns(X);for(let J=0;J!==Q.length;++J){let $=Q[J],G=ss(X,$);if(G&&G.enumerable)Y.push($)}return Y}var{create:ts,defineProperty:es,getOwnPropertyDescriptor:Xa,getOwnPropertyNames:Ya,getOwnPropertySymbols:Qa}=Object;function Ja(X,Y){return function(J){let $=J[J.length-1]?ts(null):{};for(let G=0;G!==X.length;++G){let _=J[G];if(_!==Y){let K=X[G];if(K==="__proto__")es($,K,{value:_,configurable:!0,enumerable:!0,writable:!0});else $[K]=_}}return $}}function $a(X,Y){return function(J){if(typeof J!=="object"||J===null)throw Error("Incompatible instance received: should be a non-null object");let $=Object.getPrototypeOf(J)===null,G="constructor"in J&&J.constructor===Object;if(!$&&!G)throw Error("Incompatible instance received: should be of exact type Object");let _=0,K=[];for(let D=0;D!==X.length;++D){let U=Xa(J,X[D]);if(U!==void 0){if(!U.configurable||!U.enumerable||!U.writable)throw Error("Incompatible instance received: should contain only c/e/w properties");if(U.get!==void 0||U.set!==void 0)throw Error("Incompatible instance received: should contain only no get/set properties");++_,I(K,U.value)}else I(K,Y)}let H=Ya(J).length,W=Qa(J).length;if(_!==H+W)throw Error("Incompatible instance received: should not contain extra properties");return[...K,$]}}var bH=Symbol("no-key");function gH(X,Y,Q){let J=as(X),$=[];for(let G=0;G!==J.length;++G){let _=J[G],K=X[_];if(Y===void 0||fQ(Y,_)!==-1)I($,K);else I($,z8(K,{nil:bH}))}return _0(...$,Q?y0(!1):iQ()).map(Ja(J,bH),$a(J,bH))}function KW(X,Y){let Q=Y!==void 0&&!!Y.noNullPrototype;if(Y===void 0)return gH(X,void 0,Q);if(!(("requiredKeys"in Y)&&Y.requiredKeys!==void 0))return gH(X,void 0,Q);let J=("requiredKeys"in Y?Y.requiredKeys:void 0)||[];for(let $=0;$!==J.length;++$){let G=Object.getOwnPropertyDescriptor(X,J[$]);if(G===void 0)throw Error("requiredKeys cannot reference keys that have not been defined in recordModel");if(!G.enumerable)throw Error("requiredKeys cannot reference keys that are not enumerable in recordModel")}return gH(X,J,Q)}var Ga=Object.create;function Za(X,Y,Q,J){let $=Ga(null);for(let G in X){let _=X[G],K=KW(_,J),H=Y(G),W=Q(G),D={minLength:H,maxLength:H};$[G]=W!==void 0?B5(K,{...D,selector:W}):M0(K,D)}return KW($)}var{create:jP,keys:_a}=Object;function Ka(X,Y,Q={}){let J=_a(X),$=Q.initialPoolConstraints||jP(null),G=Q.unicityConstraints||jP(null),_={noNullPrototype:Q.noNullPrototype};return gs(J,$).chain((K)=>is(Y,K).chain((H)=>Za(X,(W)=>H[W].length,(W)=>G[W],_).map((W)=>ms(W,H))))}function Ha(X){return h0(L0(X,(Y)=>Y[Y.length-1]===","?u0(Y,0,Y.length-1):Y)," ")}function Wa(X){return function(Q){if(typeof Q!=="string")throw Error("Unsupported type");let J=[];for(let $ of p1(Q," "))if(X.canShrinkWithoutContext($))I(J,$);else if(X.canShrinkWithoutContext($+","))I(J,$+",");else throw Error("Unsupported word");return J}}function Ua(X){let Y=h0(X," ");if(Y[Y.length-1]===",")Y=u0(Y,0,Y.length-1);return VW(Y[0])+u0(Y,1)+"."}function Da(X){return function(Q){if(typeof Q!=="string")throw Error("Unsupported type");if(Q.length<2||Q[Q.length-1]!=="."||Q[Q.length-2]===","||VW(iH(Q[0]))!==Q[0])throw Error("Unsupported value");let J=iH(Q[0])+u0(Q,1,Q.length-1),$=[],G=p1(J," ");for(let _=0;_!==G.length;++_){let K=G[_];if(X.canShrinkWithoutContext(K))I($,K);else if(_===G.length-1&&X.canShrinkWithoutContext(K+","))I($,K+",");else throw Error("Unsupported word")}return $}}function Na(X){return h0(X," ")}function Ba(X){if(typeof X!=="string")throw Error("Unsupported type");let Y=p1(X,". ");for(let Q=0;Q<Y.length-1;++Q)Y[Q]+=".";return Y}var O=(X,Y)=>{return{arbitrary:y0(X),weight:Y}};function Va(){return K1(O("non",6),O("adipiscing",5),O("ligula",5),O("enim",5),O("pellentesque",5),O("in",5),O("augue",5),O("et",5),O("nulla",5),O("lorem",4),O("sit",4),O("sed",4),O("diam",4),O("fermentum",4),O("ut",4),O("eu",4),O("aliquam",4),O("mauris",4),O("vitae",4),O("felis",4),O("ipsum",3),O("dolor",3),O("amet,",3),O("elit",3),O("euismod",3),O("mi",3),O("orci",3),O("erat",3),O("praesent",3),O("egestas",3),O("leo",3),O("vel",3),O("sapien",3),O("integer",3),O("curabitur",3),O("convallis",3),O("purus",3),O("risus",2),O("suspendisse",2),O("lectus",2),O("nec,",2),O("ultricies",2),O("sed,",2),O("cras",2),O("elementum",2),O("ultrices",2),O("maecenas",2),O("massa,",2),O("varius",2),O("a,",2),O("semper",2),O("proin",2),O("nec",2),O("nisl",2),O("amet",2),O("duis",2),O("congue",2),O("libero",2),O("vestibulum",2),O("pede",2),O("blandit",2),O("sodales",2),O("ante",2),O("nibh",2),O("ac",2),O("aenean",2),O("massa",2),O("suscipit",2),O("sollicitudin",2),O("fusce",2),O("tempus",2),O("aliquam,",2),O("nunc",2),O("ullamcorper",2),O("rhoncus",2),O("metus",2),O("faucibus,",2),O("justo",2),O("magna",2),O("at",2),O("tincidunt",2),O("consectetur",1),O("tortor,",1),O("dignissim",1),O("congue,",1),O("non,",1),O("porttitor,",1),O("nonummy",1),O("molestie,",1),O("est",1),O("eleifend",1),O("mi,",1),O("arcu",1),O("scelerisque",1),O("vitae,",1),O("consequat",1),O("in,",1),O("pretium",1),O("volutpat",1),O("pharetra",1),O("tempor",1),O("bibendum",1),O("odio",1),O("dui",1),O("primis",1),O("faucibus",1),O("luctus",1),O("posuere",1),O("cubilia",1),O("curae,",1),O("hendrerit",1),O("velit",1),O("mauris,",1),O("gravida",1),O("ornare",1),O("ut,",1),O("pulvinar",1),O("varius,",1),O("turpis",1),O("nibh,",1),O("eros",1),O("id",1),O("aliquet",1),O("quis",1),O("lobortis",1),O("consectetuer",1),O("morbi",1),O("vehicula",1),O("tortor",1),O("tellus,",1),O("id,",1),O("eu,",1),O("quam",1),O("feugiat,",1),O("posuere,",1),O("iaculis",1),O("lectus,",1),O("tristique",1),O("mollis,",1),O("nisl,",1),O("vulputate",1),O("sem",1),O("vivamus",1),O("placerat",1),O("imperdiet",1),O("cursus",1),O("rutrum",1),O("iaculis,",1),O("augue,",1),O("lacus",1))}function za(X={}){let{maxCount:Y,mode:Q="words",size:J}=X;if(Y!==void 0&&Y<1)throw Error("lorem has to produce at least one word/sentence");let $=Va();if(Q==="sentences")return M0(M0($,{minLength:1,size:"small"}).map(Ua,Da($)),{minLength:1,maxLength:Y,size:J}).map(Na,Ba);else return M0($,{minLength:1,maxLength:Y,size:J}).map(Ha,Wa($))}function qa(X){return new Map(X)}function La(X){if(typeof X!=="object"||X===null)throw Error("Incompatible instance received: should be a non-null object");if(!("constructor"in X)||X.constructor!==Map)throw Error("Incompatible instance received: should be of exact type Map");return Array.from(X)}function Oa(X){return X[0]}function HW(X,Y,Q={}){return B5(_0(X,Y),{minLength:Q.minKeys,maxLength:Q.maxKeys,size:Q.size,selector:Oa,depthIdentifier:Q.depthIdentifier,comparator:"SameValueZero"}).map(qa,La)}var O$=10;function Ta(X){let Y={};return(Q)=>{let J=Q!==void 0?Q:O$;if(!Hw(Y,J)){let $=O$;O$=J-1,Y[J]=X(J),O$=$}return Y[J]}}function Fa(X){let Y=0;while(X>b(0)){if(X&b(1))++Y;X>>=b(1)}return Y}function Ra(X,Y){let Q=(b(1)<<b(Y))-b(1),J=X&Q,$=Fa(X-J),G=J;for(let _=b(1);_<=Q&&$!==0;_<<=b(1))if(!(G&_))G|=_,--$;return G}function T$(X,Y){let Q=[];for(let J=X.length-1;J!==-1;--J)if(Y(X[J])!==X[J])I(Q,J);return Q}function Aa(X,Y,Q){let J=b(0);for(let $=0,G=b(1);$!==Q.length;++$,G<<=b(1))if(X[Q[$]]!==Y[Q[$]])J|=G;return J}function yH(X,Y,Q,J){for(let $=0,G=b(1);$!==Q.length;++$,G<<=b(1))if(Y&G)X[Q[$]]=J(X[Q[$]])}var Pa=class extends m0{constructor(X,Y,Q){super();this.stringArb=X,this.toggleCase=Y,this.untoggleAll=Q}buildContextFor(X,Y){return{rawString:X.value,rawStringContext:X.context,flags:Y.value,flagsContext:Y.context}}generate(X,Y){let Q=this.stringArb.generate(X,Y),J=[...Q.value],$=T$(J,this.toggleCase),G=K4(b(0),(b(1)<<b($.length))-b(1)).generate(X,void 0);return yH(J,G.value,$,this.toggleCase),new g(h0(J,""),this.buildContextFor(Q,G))}canShrinkWithoutContext(X){if(typeof X!=="string")return!1;return this.untoggleAll!==void 0?this.stringArb.canShrinkWithoutContext(this.untoggleAll(X)):this.stringArb.canShrinkWithoutContext(X)}shrink(X,Y){let Q;if(Y!==void 0)Q=Y;else if(this.untoggleAll!==void 0){let G=this.untoggleAll(X),_=[...X],K=[...G];Q={rawString:G,rawStringContext:void 0,flags:Aa(K,_,T$(K,this.toggleCase)),flagsContext:void 0}}else Q={rawString:X,rawStringContext:void 0,flags:b(0),flagsContext:void 0};let{rawString:J,flags:$}=Q;return this.stringArb.shrink(J,Q.rawStringContext).map((G)=>{let _=[...G.value],K=T$(_,this.toggleCase),H=Ra($,K.length);return yH(_,H,K,this.toggleCase),new g(h0(_,""),this.buildContextFor(G,new g(H,void 0)))}).join(Z4(()=>{let G=[...J],_=T$(G,this.toggleCase);return K4(b(0),(b(1)<<b(_.length))-b(1)).shrink($,Q.flagsContext).map((K)=>{let H=_1(G);return yH(H,K.value,_,this.toggleCase),new g(h0(H,""),this.buildContextFor(new g(J,Q.rawStringContext),K))})}))}};function wa(X){let Y=VW(X);if(Y!==X)return Y;return iH(X)}function Ca(X,Y){return new Pa(X,Y&&Y.toggleCase||wa,Y&&Y.untoggleAll)}function Ea(X){return Qw.from(X)}function Ma(X){if(!(X instanceof Qw))throw Error("Unexpected type");return[...X]}function HC(X={}){return M0(XC(X),X).map(Ea,Ma)}function ja(X){return Jw.from(X)}function Ia(X){if(!(X instanceof Jw))throw Error("Unexpected type");return[...X]}function WC(X={}){return M0(y$(X),X).map(ja,Ia)}function q8(X,Y,Q,J,$){let G=J.name,{min:_=Y,max:K=Q,...H}=X;if(_>K)throw Error(`Invalid range passed to ${G}: min must be lower than or equal to max`);if(_<Y)throw Error(`Invalid min value passed to ${G}: min must be greater than or equal to ${Y}`);if(K>Q)throw Error(`Invalid max value passed to ${G}: max must be lower than or equal to ${Q}`);return M0($({min:_,max:K}),H).map((W)=>J.from(W),(W)=>{if(!(W instanceof J))throw Error("Invalid type");return[...W]})}function UC(X={}){return q8(X,-32768,32767,Wl,w0)}function DC(X={}){return q8(X,-2147483648,2147483647,Ul,w0)}function NC(X={}){return q8(X,-128,127,Hl,w0)}function BC(X={}){return q8(X,0,65535,Bl,w0)}function VC(X={}){return q8(X,0,4294967295,Vl,w0)}function zC(X={}){return q8(X,0,255,Dl,w0)}function qC(X={}){return q8(X,0,255,Nl,w0)}function xa(X){return X!==void 0}function IP(X){if(X.hasToBeCloned)return new g(X.value_,{generatorContext:X.context},()=>X.value);return new g(X.value_,{generatorContext:X.context})}function xP(X){if(X.hasToBeCloned)return new g(X.value_,{shrinkerContext:X.context},()=>X.value);return new g(X.value_,{shrinkerContext:X.context})}var Sa=class extends m0{constructor(X,Y){super();this.generatorArbitrary=X,this.shrinkerArbitrary=Y}generate(X,Y){return IP(this.generatorArbitrary.generate(X,Y))}canShrinkWithoutContext(X){return this.shrinkerArbitrary.canShrinkWithoutContext(X)}shrink(X,Y){if(!xa(Y))return this.shrinkerArbitrary.shrink(X,void 0).map(xP);if("generatorContext"in Y)return this.generatorArbitrary.shrink(X,Y.generatorContext).map(IP);return this.shrinkerArbitrary.shrink(X,Y.shrinkerContext).map(xP)}};function WW(X,Y,Q){let J=w0({min:X,max:Y});if(Y===Q)return J;return new Sa(J,w0({min:X,max:Q}))}var{min:va,max:UW}=Math,SP=Xw.isArray,ka=Object.entries;function ba(X){let Y=-1;for(let Q=0;Q!==X.length;++Q)Y=UW(Y,X[Q][0]);return Y}function ga(X,Y){let Q=Xw(X);for(let J=0;J!==Y.length;++J){let $=Y[J];if($[0]<X)Q[$[0]]=$[1]}return Q}function LC(X,Y={}){let{size:Q,minNumElements:J=0,maxLength:$=N5,maxNumElements:G=$,noTrailingHole:_,depthIdentifier:K}=Y,H=cQ(Q,cQ(Q,J,G,Y.maxNumElements!==void 0),$,Y.maxLength!==void 0);if(J>$)throw Error("The minimal number of non-hole elements cannot be higher than the maximal length of the array");if(J>G)throw Error("The minimal number of non-hole elements cannot be higher than the maximal number of non-holes");let W=va(G,$),D=Y.maxNumElements!==void 0||Q!==void 0?Q:"=",U=B5(_0(WW(0,UW(H-1,0),UW($-1,0)),X),{size:D,minLength:J,maxLength:W,selector:(N)=>N[0],depthIdentifier:K}).map((N)=>{return ga(ba(N)+1,N)},(N)=>{if(!SP(N))throw Error("Not supported entry type");if(_&&N.length!==0&&!(N.length-1 in N))throw Error("No trailing hole");return L0(ka(N),(B)=>[Number(B[0]),B[1]])});if(_||$===J)return U;return _0(U,WW(J,H,$)).map((N)=>{let B=N[0],z=N[1];if(B.length>=z)return B;let q=_1(B);return q.length=z,q},(N)=>{if(!SP(N))throw Error("Not supported entry type");return[N,N.length]})}function ya(X){return new Set(X)}function ha(X){if(typeof X!=="object"||X===null)throw Error("Incompatible instance received: should be a non-null object");if(!("constructor"in X)||X.constructor!==Set)throw Error("Incompatible instance received: should be of exact type Set");return Array.from(X)}function OC(X,Y={}){return B5(X,{minLength:Y.minLength,maxLength:Y.maxLength,size:Y.size,depthIdentifier:Y.depthIdentifier,comparator:"SameValueZero"}).map(ya,ha)}function ma(X,Y,Q,J,$,G){return MW(X,Y,{maxKeys:Q,noNullPrototype:!G,size:J,depthIdentifier:$})}function fa(X){return K1(NC(X),zC(X),qC(X),UC(X),BC(X),DC(X),VC(X),HC(X),WC(X))}function TC(X){let{values:Y,depthSize:Q}=X,J=wW(),$=X.maxDepth,G=X.maxKeys,_=X.size,K=K1(...Y,...X.withBigInt?[K4()]:[],...X.withDate?[vw()]:[]);return ZC((H)=>({anything:K1({maxDepth:$,depthSize:Q,depthIdentifier:J},K,H("array"),H("object"),...X.withMap?[H("map")]:[],...X.withSet?[H("set")]:[],...X.withObjectString?[H("anything").map((W)=>s0(W))]:[],...X.withTypedArray?[fa({maxLength:G,size:_})]:[],...X.withSparseArray?[LC(H("anything"),{maxNumElements:G,size:_,depthIdentifier:J})]:[]),keys:X.withObjectString?K1({arbitrary:X.key,weight:10},{arbitrary:H("anything").map((W)=>s0(W)),weight:1}):X.key,array:M0(H("anything"),{maxLength:G,size:_,depthIdentifier:J}),set:OC(H("anything"),{maxLength:G,size:_,depthIdentifier:J}),map:K1(HW(H("keys"),H("anything"),{maxKeys:G,size:_,depthIdentifier:J}),HW(H("anything"),H("anything"),{maxKeys:G,size:_,depthIdentifier:J})),object:ma(H("keys"),H("anything"),G,_,J,X.withNullPrototype)})).anything}function da(X){switch(typeof X){case"boolean":return new Yw(X);case"number":return new N8(X);case"string":return new d1(X);default:return X}}function pa(X){if(typeof X!=="object"||X===null||!("constructor"in X))return X;return X.constructor===Yw||X.constructor===N8||X.constructor===d1?X.valueOf():X}function ua(X){return X.map(da,pa)}function ca(X,Y){return[iQ(),JC(),y$(),Y(X),K1(Y(X),y0(null),y0(void 0))]}function la(X){return X.map((Y)=>ua(Y))}function oa(X,Y){return Y?la(X).concat(X):X}function FC(X={}){let Y={size:X.size,unit:"stringUnit"in X?X.stringUnit:X.withUnicodeString?"binary":void 0};return{key:X.key!==void 0?X.key:e0(Y),values:oa(X.values!==void 0?X.values:ca(Y,e0),X.withBoxedValues===!0),depthSize:X.depthSize,maxDepth:X.maxDepth,maxKeys:X.maxKeys,size:X.size,withSet:X.withSet===!0,withMap:X.withMap===!0,withObjectString:X.withObjectString===!0,withNullPrototype:X.withNullPrototype===!0,withBigInt:X.withBigInt===!0,withDate:X.withDate===!0,withTypedArray:X.withTypedArray===!0,withSparseArray:X.withSparseArray===!0}}function ia(X){return MW(X.key,TC(X),{maxKeys:X.maxKeys,noNullPrototype:!X.withNullPrototype,size:X.size})}function ra(X){return ia(FC(X))}function na(X,Y){let{depthSize:Q,maxDepth:J}=Y;return{key:X,values:[iQ(),y$({noDefaultInfinity:!0,noNaN:!0}),X,y0(null)],depthSize:Q,maxDepth:J}}function RC(X){return TC(FC(X))}function AC(X={}){let Y=X.noUnicodeString===void 0||X.noUnicodeString===!0;return RC(na("stringUnit"in X?e0({unit:X.stringUnit}):Y?e0():e0({unit:"binary"}),X))}var{stringify:sa,parse:aa}=JSON;function ta(X){if(typeof X!=="string")throw new y("Cannot unmap the passed value");return aa(X)}function ea(X={}){return AC(X).map(sa,ta)}var Xt=Object.defineProperties;function hH(X,Y){return`Stream(${Y!==void 0?`${h0(Y,",")}…`:`${X} emitted`})`}var Yt=class extends m0{constructor(X,Y){super();this.arb=X,this.history=Y}generate(X,Y){let Q=Y!==void 0&&X.nextInt(1,Y)===1?Y:void 0,J=()=>{let $=this.history?[]:null,G=0,K=new K0(function*(H,W){while(!0){let D=H.generate(W,Q).value;if(G++,$!==null)I($,D);yield D}}(this.arb,X.clone()));return Xt(K,{toString:{value:()=>hH(G,$!==null?$.map(s0):void 0)},[Y6]:{value:()=>hH(G,$!==null?$.map(s0):void 0)},[V8]:{value:async()=>hH(G,$!==null?await Promise.all($.map(FW)):void 0)},[H1]:{value:J,enumerable:!0}})};return new g(J(),void 0)}canShrinkWithoutContext(X){return!1}shrink(X,Y){return K0.nil()}};function Qt(X,Y){return new Yt(X,Y!==void 0&&typeof Y==="object"&&"noHistory"in Y?!Y.noHistory:!0)}function Jt(X){return h0(X,"")}function vP(X){if(typeof X!=="string")throw Error("Cannot unmap the passed value");return[...X]}function $t(X){switch(X.length%4){case 0:return X;case 3:return`${X}=`;case 2:return`${X}==`;default:return u0(X,1)}}function Gt(X){if(typeof X!=="string"||X.length%4!==0)throw Error("Invalid string received");let Y=X.indexOf("=");if(Y===-1)return X;if(X.length-Y>2)throw Error("Cannot unmap the passed value");return u0(X,0,Y)}var mH=String.fromCharCode;function Zt(X){if(X<26)return mH(X+65);if(X<52)return mH(X+97-26);if(X<62)return mH(X+48-52);return X===62?"+":"/"}function _t(X){if(typeof X!=="string"||X.length!==1)throw new y("Invalid entry");let Y=j9(X,0);if(Y>=65&&Y<=90)return Y-65;if(Y>=97&&Y<=122)return Y-97+26;if(Y>=48&&Y<=57)return Y-48+52;return Y===43?62:Y===47?63:-1}function Kt(){return w0({min:0,max:63}).map(Zt,_t)}function Ht(X={}){let{minLength:Y=0,maxLength:Q=N5,size:J}=X,$=Y+3-(Y+3)%4,G=Q-Q%4,_=X.maxLength===void 0&&J===void 0?"=":J;if($>G)throw new y("Minimal length should be inferior or equal to maximal length");if($%4!==0)throw new y("Minimal length of base64 strings must be a multiple of 4");if(G%4!==0)throw new y("Maximal length of base64 strings must be a multiple of 4");let K=Kt();return M0(K,{minLength:$,maxLength:G,size:_,experimentalCustomSlices:fr(K,vP)}).map(Jt,vP).map($t,Gt)}var kP=Object.is;function Wt(X,Y){let Q=new B8,J=0;for(let $ of X)if(kP($,-0))++J;else tX(Q,$,(VX(Q,$)||0)+1);for(let $=0;$!==Y.length;++$){if(!($ in Y))return!1;let G=Y[$];if(kP(G,-0)){if(J===0)return!1;--J}else{let _=VX(Q,G)||0;if(_===0)return!1;tX(Q,G,_-1)}}return!0}var{floor:Ut,log:bP}=Math,Dt=Array.isArray,PC=class extends m0{constructor(X,Y,Q,J){super();if(this.originalArray=X,this.isOrdered=Y,this.minLength=Q,this.maxLength=J,Q<0||Q>X.length)throw Error("fc.*{s|S}ubarrayOf expects the minimal length to be between 0 and the size of the original array");if(J<0||J>X.length)throw Error("fc.*{s|S}ubarrayOf expects the maximal length to be between 0 and the size of the original array");if(Q>J)throw Error("fc.*{s|S}ubarrayOf expects the minimal length to be inferior or equal to the maximal length");this.lengthArb=new x9(Q,J),this.biasedLengthArb=Q!==J?new x9(Q,Q+Ut(bP(J-Q)/bP(2))):this.lengthArb}generate(X,Y){let Q=(Y!==void 0&&X.nextInt(1,Y)===1?this.biasedLengthArb:this.lengthArb).generate(X,void 0),J=Q.value,$=L0(this.originalArray,(_,K)=>K),G=[];for(let _=0;_!==J;++_){let K=X.nextInt(0,$.length-1);I(G,$[K]),Zw($,K,1)}if(this.isOrdered)_w(G,(_,K)=>_-K);return new g(L0(G,(_)=>this.originalArray[_]),Q.context)}canShrinkWithoutContext(X){if(!Dt(X))return!1;if(!this.lengthArb.canShrinkWithoutContext(X.length))return!1;return Wt(this.originalArray,X)}shrink(X,Y){if(X.length===0)return K0.nil();return this.lengthArb.shrink(X.length,Y).map((Q)=>{return new g(_1(X,X.length-Q.value),Q.context)}).join(X.length>this.minLength?Z4(()=>this.shrink(_1(X,1),void 0).filter((Q)=>this.minLength<=Q.value.length+1).map((Q)=>new g([X[0],...Q.value],void 0))):K0.nil())}};function Nt(X,Y={}){let{minLength:Q=0,maxLength:J=X.length}=Y;return new PC(X,!0,Q,J)}function Bt(X,Y={}){let{minLength:Q=0,maxLength:J=X.length}=Y;return new PC(X,!1,Q,J)}var Vt={10:"A",11:"B",12:"C",13:"D",14:"E",15:"F",16:"G",17:"H",18:"J",19:"K",20:"M",21:"N",22:"P",23:"Q",24:"R",25:"S",26:"T",27:"V",28:"W",29:"X",30:"Y",31:"Z"},zt={"0":0,"1":1,"2":2,"3":3,"4":4,"5":5,"6":6,"7":7,"8":8,"9":9,A:10,B:11,C:12,D:13,E:14,F:15,G:16,H:17,J:18,K:19,M:20,N:21,P:22,Q:23,R:24,S:25,T:26,V:27,W:28,X:29,Y:30,Z:31};function qt(X){return X<10?d1(X):Vt[X]}function gP(X,Y){let Q="";while(X.length+Q.length<Y)Q+="0";return Q+X}function yP(X){let Y="";for(let Q=X;Q!==0;){let J=Q>>5;Y=qt(Q-(J<<5))+Y,Q=J}return Y}function Lt(X,Y){let Q=~~(X/1073741824),J=X&1073741823;return gP(yP(Q),Y-6)+gP(yP(J),6)}function wC(X){return function(Q){return Lt(Q,X)}}function fH(X){if(typeof X!=="string")throw new y("Unsupported type");let Y=0,Q=1;for(let J=X.length-1;J>=0;--J){let $=X[J],G=zt[$];if(G===void 0)throw new y("Unsupported type");Y+=G*Q,Q*=32}return Y}var Ot=wC(10),hP=wC(8);function Tt(X){return Ot(X[0])+hP(X[1])+hP(X[2])}function Ft(X){if(typeof X!=="string"||X.length!==26)throw Error("Unsupported type");return[fH(X.slice(0,10)),fH(X.slice(10,18)),fH(X.slice(18))]}function Rt(){return _0(w0({min:0,max:281474976710655}),w0({min:0,max:1099511627775}),w0({min:0,max:1099511627775})).map(Tt,Ft)}function CC(X){return Qo(pQ(X,16),8,"0")}function At(X){if(typeof X!=="string")throw Error("Unsupported type");if(X.length!==8)throw Error("Unsupported value: invalid length");let Y=parseInt(X,16);if(X!==CC(Y))throw Error("Unsupported value: invalid content");return Y}function dH(X,Y){return w0({min:X,max:Y}).map(CC,At)}function Pt(X){return`${X[0]}-${u0(X[1],4)}-${u0(X[1],0,4)}-${u0(X[2],0,4)}-${u0(X[2],4)}${X[3]}`}var wt=/^([0-9a-f]{8})-([0-9a-f]{4})-([0-9a-f]{4})-([0-9a-f]{4})-([0-9a-f]{12})$/;function Ct(X){if(typeof X!=="string")throw Error("Unsupported type");let Y=wt.exec(X);if(Y===null)throw Error("Unsupported type");return[Y[1],Y[3]+Y[2],Y[4]+u0(Y[5],0,4),u0(Y[5],4)]}var mP="0123456789abcdef";function Et(X){let Y={},Q={};for(let G=0;G!==X.length;++G){let _=mP[G],K=mP[X[G]];Y[_]=K,Q[K]=_}function J(G){return Y[G[0]]+u0(G,1)}function $(G){if(typeof G!=="string")throw new y("Cannot produce non-string values");let _=Q[G[0]];if(_===void 0)throw new y("Cannot produce strings not starting by the version in hexa code");return _+u0(G,1)}return{versionsApplierMapper:J,versionsApplierUnmapper:$}}function Mt(X){let Y={};for(let Q of X){if(Y[Q])throw new y(`Version ${Q} has been requested at least twice for uuid`);if(Y[Q]=!0,Q<1||Q>15)throw new y(`Version must be a value in [1-15] for uuid, but received ${Q}`);if(~~Q!==Q)throw new y(`Version must be an integer value for uuid, but received ${Q}`)}if(X.length===0)throw new y("Must provide at least one version for uuid")}function jt(X={}){let Y=dH(0,4294967295),Q=X.version!==void 0?typeof X.version==="number"?[X.version]:X.version:[1,2,3,4,5,6,7,8];Mt(Q);let{versionsApplierMapper:J,versionsApplierUnmapper:$}=Et(Q);return _0(Y,dH(0,268435456*Q.length-1).map(J,$),dH(2147483648,3221225471),Y).map(Pt,Ct)}function It(X){return e0({unit:xW("-._~!$&'()*+,;=:"),size:X})}function xt([X,Y,Q]){return(X===null?"":`${X}@`)+Y+(Q===null?"":`:${Q}`)}function St(X){if(typeof X!=="string")throw Error("Unsupported");let Y=X.indexOf("@"),Q=Y!==-1?X.substring(0,Y):null,J=/:(\d+)$/.exec(X),$=J!==null?Number(J[1]):null;return[Q,J!==null?X.substring(Y+1,X.length-J[1].length-1):X.substring(Y+1),$]}function vt(X){return`[${X}]`}function kt(X){if(typeof X!=="string"||X[0]!=="["||X[X.length-1]!=="]")throw Error("Unsupported");return X.substring(1,X.length-1)}function EC(X){let Y=X||{},Q=Y.size,J=[SW({size:Q}),...Y.withIPv4===!0?[gW()]:[],...Y.withIPv6===!0?[GC().map(vt,kt)]:[],...Y.withIPv4Extended===!0?[$C()]:[]];return _0(Y.withUserInfo===!0?z8(It(Q)):y0(null),K1(...J),Y.withPort===!0?z8(G4(65535)):y0(null)).map(xt,St)}function MC(X){return e0({unit:xW("-._~!$&'()*+,;=:@/?"),size:X})}function jC(X={}){return MC(X.size)}function IC(X={}){return e0({unit:xW("-._~!$&'()*+,;=:@"),size:X.size})}function bt(X){let Y="";for(let Q=0;Q!==X.length;++Q)Y+="/"+X[Q];return Y}function gt(X){if(typeof X!=="string")throw Error("Incompatible value received: type");if(X.length!==0&&X[0]!=="/")throw Error("Incompatible value received: start");return Zw(p1(X,"/"),1)}function yt(X){switch(X){case"xsmall":return["xsmall","xsmall"];case"small":return["small","xsmall"];case"medium":return["small","small"];case"large":return["medium","small"];case"xlarge":return["medium","medium"]}}function pH(X,Y){return M0(IC({size:X}),{size:Y}).map(bt,gt)}function ht(X){let[Y,Q]=yt(X);if(Y===Q)return pH(Y,Q);return K1(pH(Y,Q),pH(Q,Y))}function xC(X){return ht(EW((X||{}).size))}function SC(X={}){return MC(X.size)}function mt(X){let[Y,Q,J]=X;return`${Y}://${Q}${J}${X[3]===null?"":`?${X[3]}`}${X[4]===null?"":`#${X[4]}`}`}var ft=/^([[A-Za-z][A-Za-z0-9+.-]*):\/\/([^/?#]*)([^?#]*)(\?[A-Za-z0-9\-._~!$&'()*+,;=:@/?%]*)?(#[A-Za-z0-9\-._~!$&'()*+,;=:@/?%]*)?$/;function dt(X){if(typeof X!=="string")throw Error("Incompatible value received: type");let Y=ft.exec(X);if(Y===null)throw Error("Incompatible value received");let Q=Y[1],J=Y[2],$=Y[3],G=Y[4],_=Y[5];return[Q,J,$,G!==void 0?G.substring(1):null,_!==void 0?_.substring(1):null]}function pt(X){let Y=X||{},Q=EW(Y.size),J=Y.authoritySettings!==void 0&&Y.authoritySettings.size!==void 0?oQ(Y.authoritySettings.size,Q):Q,$={...Y.authoritySettings,size:J};return _0(M6(...Y.validSchemes||["http","https"]),EC($),xC({size:Q}),Y.withQueryParameters===!0?z8(SC({size:Q})):y0(null),Y.withFragments===!0?z8(jC({size:Q})):y0(null)).map(mt,dt)}var ut=class X{constructor(Y,Q){this.commands=Y,this.metadataForReplay=Q,this[H1]=function(){return new X(this.commands.map((J)=>J.clone()),this.metadataForReplay)}}[Symbol.iterator](){return this.commands[Symbol.iterator]()}toString(){let Y=this.commands.filter((J)=>J.hasRan).map((J)=>J.toString()).join(","),Q=this.metadataForReplay();return Q.length!==0?`${Y} /*${Q}*/`:Y}},ct=class X{constructor(Y){if(this.cmd=Y,this.hasRan=!1,OW(Y)){let Q=Y[Y6];this[Y6]=function(){return Q.call(Y)}}if(TW(Y)){let Q=Y[V8];this[V8]=function(){return Q.call(Y)}}}check(Y){return this.cmd.check(Y)}run(Y,Q){return this.hasRan=!0,this.cmd.run(Y,Q)}clone(){if(D5(this.cmd))return new X(this.cmd[H1]());return new X(this.cmd)}toString(){return this.cmd.toString()}},fP=class{static parse(X){let[Y,Q]=X.split(":"),J=this.parseCounts(Y),$=this.parseChanges(Q);return this.parseOccurences(J,$)}static stringify(X){let Y=this.countOccurences(X);return`${this.stringifyCounts(Y)}:${this.stringifyChanges(Y)}`}static intToB64(X){if(X<26)return String.fromCharCode(X+65);if(X<52)return String.fromCharCode(X+97-26);if(X<62)return String.fromCharCode(X+48-52);return String.fromCharCode(X===62?43:47)}static b64ToInt(X){if(X>="a")return X.charCodeAt(0)-97+26;if(X>="A")return X.charCodeAt(0)-65;if(X>="0")return X.charCodeAt(0)-48+52;return X==="+"?62:63}static countOccurences(X){return X.reduce((Y,Q)=>{if(Y.length===0||Y[Y.length-1].count===64||Y[Y.length-1].value!==Q)Y.push({value:Q,count:1});else Y[Y.length-1].count+=1;return Y},[])}static parseOccurences(X,Y){let Q=[];for(let J=0;J!==X.length;++J){let $=X[J],G=Y[J];for(let _=0;_!==$;++_)Q.push(G)}return Q}static stringifyChanges(X){let Y="";for(let Q=0;Q<X.length;Q+=6){let J=X.slice(Q,Q+6).reduceRight(($,G)=>($<<1)+(G.value?1:0),0);Y+=this.intToB64(J)}return Y}static parseChanges(X){let Y=X.split("").map((J)=>this.b64ToInt(J)),Q=[];for(let J=0;J!==Y.length;++J){let $=Y[J];for(let G=0;G!==6;++G,$>>=1)Q.push($%2===1)}return Q}static stringifyCounts(X){return X.map(({count:Y})=>this.intToB64(Y-1)).join("")}static parseCounts(X){return X.split("").map((Y)=>this.b64ToInt(Y)+1)}},lt=class extends m0{constructor(X,Y,Q,J,$){super();this.sourceReplayPath=J,this.disableReplayLog=$,this.oneCommandArb=K1(...X).map((G)=>new ct(G)),this.lengthArb=WW(0,Y,Q),this.replayPath=[],this.replayPathPosition=0}metadataForReplay(){return this.disableReplayLog?"":`replayPath=${JSON.stringify(fP.stringify(this.replayPath))}`}buildValueFor(X,Y){let Q=X.map(($)=>$.value_),J={shrunkOnce:Y,items:X};return new g(new ut(Q,()=>this.metadataForReplay()),J)}generate(X){let Y=this.lengthArb.generate(X,void 0).value,Q=Array(Y);for(let J=0;J!==Y;++J)Q[J]=this.oneCommandArb.generate(X,void 0);return this.replayPathPosition=0,this.buildValueFor(Q,!1)}canShrinkWithoutContext(X){return!1}filterOnExecution(X){let Y=[];for(let Q of X)if(Q.value_.hasRan)this.replayPath.push(!0),Y.push(Q);else this.replayPath.push(!1);return Y}filterOnReplay(X){return X.filter((Y,Q)=>{let J=this.replayPath[this.replayPathPosition+Q];if(J===void 0)throw Error("Too short replayPath");if(!J&&Y.value_.hasRan)throw Error("Mismatch between replayPath and real execution");return J})}filterForShrinkImpl(X){if(this.replayPathPosition===0)this.replayPath=this.sourceReplayPath!==null?fP.parse(this.sourceReplayPath):[];let Y=this.replayPathPosition<this.replayPath.length?this.filterOnReplay(X):this.filterOnExecution(X);return this.replayPathPosition+=X.length,Y}shrink(X,Y){if(Y===void 0)return K0.nil();let Q=Y,J=Q.shrunkOnce,$=Q.items,G=this.filterForShrinkImpl($);if(G.length===0)return K0.nil();let _=J?K0.nil():new K0([[]][Symbol.iterator]()),K=[];for(let H=0;H!==G.length;++H)K.push(Z4(()=>{let W=G.slice(0,H);return this.lengthArb.shrink(G.length-1-H,void 0).map((D)=>W.concat(G.slice(G.length-(D.value+1))))}));for(let H=0;H!==G.length;++H)K.push(Z4(()=>this.oneCommandArb.shrink(G[H].value_,G[H].context).map((W)=>G.slice(0,H).concat([W],G.slice(H+1)))));return _.join(...K).map((H)=>{return this.buildValueFor(H.map((W)=>new g(W.value_.clone(),W.context)),!0)})}};function ot(X,Y={}){let{size:Q,maxCommands:J=N5,disableReplayLog:$=!1,replayPath:G=null}=Y;return new lt(X,cQ(Q,0,J,Y.maxCommands!==void 0),J,G,$)}var it=class{constructor(X,Y){this.s=X,this.cmd=Y}async check(X){let Y=null,Q=!1;if((await this.s.scheduleSequence([{label:`check@${this.cmd.toString()}`,builder:async()=>{try{Q=await Promise.resolve(this.cmd.check(X))}catch(J){throw Y=J,J}}}]).task).faulty)throw Y;return Q}async run(X,Y){let Q=null;if((await this.s.scheduleSequence([{label:`run@${this.cmd.toString()}`,builder:async()=>{try{await this.cmd.run(X,Y)}catch(J){throw Q=J,J}}}]).task).faulty)throw Q}},rt=function*(X,Y){for(let Q of Y)yield new it(X,Q)},vC=(X,Y,Q,J,$)=>{return X.then((G)=>{let{model:_,real:K}=G,H=Q;for(let W of Y)H=$(H,()=>{return J(W,_,K)});return H})},nt=(X,Y)=>{return vC({then:(G)=>{G(X())}},Y,void 0,(G,_,K)=>{if(G.check(_))G.run(_,K)},(G,_)=>_())},st=(X)=>{return typeof X.then==="function"},kC=async(X,Y,Q=Promise.resolve())=>{return await vC({then:(_)=>{let K=X();if(st(K))return K.then(_);else return _(K)}},Y,Q,async(_,K,H)=>{if(await _.check(K))await _.run(K,H)},(_,K)=>_.then(K))};function at(X,Y){nt(X,Y)}async function tt(X,Y){await kC(X,Y)}async function et(X,Y,Q){let J=rt(X,Q),$=kC(Y,J,X.schedule(Promise.resolve(),"startModel"));await X.waitFor($),await X.waitAll()}var F$=(X)=>X(),bC=class X{constructor(Y,Q){this.act=Y,this.taskSelector=Q,this.lastTaskId=0,this.sourceTaskSelector=Q.clone(),this.scheduledTasks=[],this.triggeredTasks=[],this.scheduledWatchers=[],this[H1]=function(){return new X(this.act,this.sourceTaskSelector)}}static buildLog(Y){return`[task\${${Y.taskId}}] ${Y.label.length!==0?`${Y.schedulingType}::${Y.label}`:Y.schedulingType} ${Y.status}${Y.outputValue!==void 0?` with value ${Xs(Y.outputValue)}`:""}`}log(Y,Q,J,$,G,_){this.triggeredTasks.push({status:G,schedulingType:Y,taskId:Q,label:J,metadata:$,outputValue:_!==void 0?s0(_):void 0})}scheduleInternal(Y,Q,J,$,G,_){let K=++this.lastTaskId,H=void 0,W=new Promise((D,U)=>{H=()=>{let N=Promise.resolve(_!==void 0?J.then(()=>_()):J);return N.then((B)=>{this.log(Y,K,Q,$,"resolved",B),D(B)},(B)=>{this.log(Y,K,Q,$,"rejected",B),U(B)}),N}});if(this.scheduledTasks.push({original:J,trigger:H,schedulingType:Y,taskId:K,label:Q,metadata:$,customAct:G}),this.scheduledWatchers.length!==0)this.scheduledWatchers[0]();return W}schedule(Y,Q,J,$){return this.scheduleInternal("promise",Q||"",Y,J,$||F$)}scheduleFunction(Y,Q){return(...J)=>this.scheduleInternal("function",`${Y.name}(${J.map(s0).join(",")})`,Y(...J),void 0,Q||F$)}scheduleSequence(Y,Q){let J={done:!1,faulty:!1},$={then:(D)=>D()},G=()=>{},_=new Promise((D)=>{G=()=>D({done:J.done,faulty:J.faulty})}),K=()=>{J.faulty=!0,G()},H=()=>{J.done=!0,G()},W=(D,U)=>{if(D>=Y.length){U.then(H,K);return}U.then(()=>{let N=Y[D],[B,z,q]=typeof N==="function"?[N,N.name,void 0]:[N.builder,N.label,N.metadata],F=this.scheduleInternal("sequence",z,$,q,Q||F$,()=>B());W(D+1,F)},K)};return W(0,$),Object.assign(J,{task:_})}count(){return this.scheduledTasks.length}internalWaitOne(){if(this.scheduledTasks.length===0)throw Error("No task scheduled");let Y=this.taskSelector.nextTaskIndex(this.scheduledTasks),[Q]=this.scheduledTasks.splice(Y,1);return Q.customAct(()=>{return Q.trigger().catch((J)=>{})})}waitOne(Y){let Q=Y||F$;return this.act(()=>Q(()=>this.internalWaitOne()))}async waitAll(Y){while(this.scheduledTasks.length>0)await this.waitOne(Y)}async internalWaitFor(Y,Q){let J=!1,$=Q.customAct,G=Q.onWaitStart,_=Q.onWaitIdle,K=Q.launchAwaiterOnInit,H=void 0,W=void 0,D=0,U=null,N=null,B=async()=>{D=50;for(D=50;!J&&D>0;--D)await Promise.resolve();if(!J&&this.scheduledTasks.length>0){if(G!==void 0)G();return N=this.waitOne($),N.then(()=>{return N=null,B()},(R)=>{throw N=null,J=!0,W(R),R})}if(!J&&_!==void 0)_();U=null},z=()=>{if(U!==null){D=51;return}U=B().catch(()=>{})},q=()=>{let R=this.scheduledWatchers.indexOf(z);if(R!==-1)this.scheduledWatchers.splice(R,1);if(R===0&&this.scheduledWatchers.length!==0)this.scheduledWatchers[0]()},F=new Promise((R,C)=>{H=(E)=>{q(),R(E)},W=(E)=>{q(),C(E)}});if(Y.then((R)=>{if(J=!0,N===null)H(R);else N.then(()=>H(R),(C)=>W(C))},(R)=>{if(J=!0,N===null)W(R);else N.then(()=>W(R),()=>W(R))}),(this.scheduledTasks.length>0||K)&&this.scheduledWatchers.length===0)z();return this.scheduledWatchers.push(z),F}waitNext(Y,Q){let J=void 0,$=Y,G=$<=0?Promise.resolve():new Promise((_)=>{J=()=>{if(--$<=0)_()}});return this.internalWaitFor(G,{customAct:Q,onWaitStart:J,onWaitIdle:void 0,launchAwaiterOnInit:!1})}waitIdle(Y){let Q=void 0,J=new Promise(($)=>Q=$);return this.internalWaitFor(J,{customAct:Y,onWaitStart:void 0,onWaitIdle:Q,launchAwaiterOnInit:!0})}waitFor(Y,Q){return this.internalWaitFor(Y,{customAct:Q,onWaitStart:void 0,onWaitIdle:void 0,launchAwaiterOnInit:!1})}report(){return[...this.triggeredTasks,...this.scheduledTasks.map((Y)=>({status:"pending",schedulingType:Y.schedulingType,taskId:Y.taskId,label:Y.label,metadata:Y.metadata}))]}toString(){return"schedulerFor()`\n"+this.report().map(X.buildLog).map((Y)=>`-> ${Y}`).join(`
`)+"`"}};function gC(X){let Y=0;return{clone:()=>gC(X),nextTaskIndex:(Q)=>{if(X.length<=Y)throw Error("Invalid schedulerFor defined: too many tasks have been scheduled");let J=Q.findIndex(($)=>$.taskId===X[Y]);if(J===-1)throw Error("Invalid schedulerFor defined: unable to find next task");return++Y,J}}}function dP(X,Y){return new bC(X,gC(Y))}function yC(X){let Y=X.clone();return{clone:()=>yC(Y),nextTaskIndex:(Q)=>{return X.nextInt(0,Q.length-1)}}}var Xe=class extends m0{constructor(X){super();this.act=X}generate(X,Y){return new g(new bC(this.act,yC(X.clone())),void 0)}canShrinkWithoutContext(X){return!1}shrink(X,Y){return K0.nil()}};function Ye(X){let{act:Y=(Q)=>Q()}=X||{};return new Xe(Y)}function Qe(X,Y){let{act:Q=(J)=>J()}=Array.isArray(X)?Y||{}:X||{};if(Array.isArray(X))return dP(Q,X);return function(J,...$){return dP(Q,$)}}function Je(X={}){return q8(X,b("-9223372036854775808"),b("9223372036854775807"),_l,K4)}function $e(X={}){return q8(X,b(0),b("18446744073709551615"),Kl,K4)}function Ge(X,Y){return Y}var{floor:uH,min:Ze}=Math;function IX(X,Y){switch(X.type){case"Char":return{astNode:X,minLength:1};case"Repetition":switch(X.quantifier.kind){case"*":{let Q=IX(X.expression,Y);return{astNode:{type:"Repetition",quantifier:{...X.quantifier,kind:"Range",from:0,to:Y},expression:Q.astNode},minLength:0}}case"+":{let Q=IX(X.expression,Y),J=Q.minLength>1?Q.minLength:1;return{astNode:{type:"Repetition",quantifier:{...X.quantifier,kind:"Range",from:1,to:uH(Y/J)},expression:Q.astNode},minLength:Q.minLength}}case"?":{let Q=IX(X.expression,Y);if(Y<Q.minLength)return{astNode:{type:"Repetition",quantifier:{...X.quantifier,kind:"Range",from:0,to:0},expression:Q.astNode},minLength:0};return{astNode:{...X,expression:Q.astNode},minLength:0}}case"Range":{let Q=X.quantifier.from>1?uH(Y/X.quantifier.from):Y,J=IX(X.expression,Q),$=J.minLength>1?J.minLength:1;if(X.quantifier.to===void 0||X.quantifier.to*$>Y)return{astNode:{type:"Repetition",quantifier:{...X.quantifier,kind:"Range",to:uH(Y/$)},expression:J.astNode},minLength:X.quantifier.from*J.minLength};return{astNode:{...X,expression:J.astNode},minLength:X.quantifier.from*J.minLength}}default:return Ge(X.quantifier,{astNode:X,minLength:0})}case"Quantifier":return{astNode:X,minLength:0};case"Alternative":{let Q=0,J=[];for(let G=0;G!==X.expressions.length;++G){let _=Y-Q,K=IX(X.expressions[G],_);Q+=K.minLength,I(J,{value:K,allowance:_})}let $=[];for(let G=0;G!==J.length;++G){let _=J[G].value,K=J[G].allowance,H=Y-Q+_.minLength;I($,(H!==K?IX(_.astNode,H):_).astNode)}return{astNode:{...X,expressions:$},minLength:Q}}case"CharacterClass":return{astNode:X,minLength:1};case"ClassRange":return{astNode:X,minLength:1};case"Group":{let Q=IX(X.expression,Y);return{astNode:{...X,expression:Q.astNode},minLength:Q.minLength}}case"Disjunction":{if(X.left===null){if(X.right===null)return{astNode:X,minLength:0};let $=IX(X.right,Y),G=$.minLength>Y?null:$.astNode;return{astNode:{...X,left:null,right:G},minLength:0}}if(X.right===null){let $=IX(X.left,Y),G=$.minLength>Y?null:$.astNode;return{astNode:{...X,left:G,right:null},minLength:0}}let Q=IX(X.left,Y),J=IX(X.right,Y);if(Q.minLength>Y)return J;if(J.minLength>Y)return Q;return{astNode:{...X,left:Q.astNode,right:J.astNode},minLength:Ze(Q.minLength,J.minLength)}}case"Assertion":return{astNode:X,minLength:0};case"Backreference":return{astNode:X,minLength:0};case"UnicodeProperty":return{astNode:X,minLength:1}}}function _e(X,Y){return IX(X,Y).astNode}function Ke(X){return Error(`Unsupported AST node! Received: ${s0(X)}`)}function M$(X,Y,Q){if(!Y&&!Q)return X;let J={hasStart:!1,hasEnd:!1},$=hC(X,Y,Q,J),G=Y&&!J.hasStart,_=Q&&!J.hasEnd;if(!G&&!_)return $;let K=[];if(G)K.push({type:"Assertion",kind:"^"}),K.push({type:"Repetition",quantifier:{type:"Quantifier",kind:"*",greedy:!0},expression:{type:"Char",kind:"meta",symbol:".",value:".",codePoint:NaN}});if(K.push($),_)K.push({type:"Repetition",quantifier:{type:"Quantifier",kind:"*",greedy:!0},expression:{type:"Char",kind:"meta",symbol:".",value:".",codePoint:NaN}}),K.push({type:"Assertion",kind:"$"});return{type:"Group",capturing:!1,expression:{type:"Alternative",expressions:K}}}function hC(X,Y,Q,J){switch(X.type){case"Char":return X;case"Repetition":return X;case"Quantifier":throw Error("Wrongly defined AST tree, Quantifier nodes not supposed to be scanned!");case"Alternative":return J.hasStart=!0,J.hasEnd=!0,{...X,expressions:X.expressions.map(($,G)=>M$($,Y&&G===0,Q&&G===X.expressions.length-1))};case"CharacterClass":return X;case"ClassRange":return X;case"Group":return{...X,expression:hC(X.expression,Y,Q,J)};case"Disjunction":return J.hasStart=!0,J.hasEnd=!0,{...X,left:X.left!==null?M$(X.left,Y,Q):null,right:X.right!==null?M$(X.right,Y,Q):null};case"Assertion":if(X.kind==="^"||X.kind==="Lookahead")return J.hasStart=!0,X;else if(X.kind==="$"||X.kind==="Lookbehind")return J.hasEnd=!0,X;else throw Error(`Assertions of kind ${X.kind} not implemented yet!`);case"Backreference":return X;case"UnicodeProperty":return X;default:throw Ke(X)}}function He(X){return M$(X,!0,!0)}function pP(X,Y){return X[Y]>="\uD800"&&X[Y]<="\uDBFF"&&X[Y+1]>="\uDC00"&&X[Y+1]<="\uDFFF"?2:1}function t0(X){return X>="0"&&X<="9"||X>="a"&&X<="f"||X>="A"&&X<="F"}function DW(X){return X>="0"&&X<="9"}function mC(X,Y){for(let Q=Y;Q!==X.length;++Q){let J=X[Q];if(J==="\\")Q+=1;else if(J==="]")return Q}throw Error("Missing closing ']'")}function We(X,Y){let Q=0;for(let J=Y;J!==X.length;++J){let $=X[J];if($==="\\")J+=1;else if($===")"){if(Q===0)return J;Q-=1}else if($==="[")J=mC(X,J);else if($==="(")Q+=1}throw Error("Missing closing ')'")}function Ue(X,Y){let Q=!1;for(let J=Y;J!==X.length;++J){let $=X[J];if(DW($));else if(Y===J)return-1;else if($===","){if(Q)return-1;Q=!0}else if($==="}")return J;else return-1}return-1}function De(X,Y,Q,J){switch(X[Y]){case"[":if(J===1)return Y+1;return mC(X,Y+1)+1;case"{":{if(J===1)return Y+1;let $=Ue(X,Y+1);if($===-1)return Y+1;return $+1}case"(":if(J===1)return Y+1;return We(X,Y+1)+1;case"]":case"}":case")":return Y+1;case"\\":{let $=X[Y+1];switch($){case"x":if(t0(X[Y+2])&&t0(X[Y+3]))return Y+4;throw Error(`Unexpected token '${X.substring(Y,Y+4)}' found`);case"u":if(X[Y+2]==="{"){if(!Q)return Y+2;if(X[Y+4]==="}"){if(t0(X[Y+3]))return Y+5;throw Error(`Unexpected token '${X.substring(Y,Y+5)}' found`)}if(X[Y+5]==="}"){if(t0(X[Y+3])&&t0(X[Y+4]))return Y+6;throw Error(`Unexpected token '${X.substring(Y,Y+6)}' found`)}if(X[Y+6]==="}"){if(t0(X[Y+3])&&t0(X[Y+4])&&t0(X[Y+5]))return Y+7;throw Error(`Unexpected token '${X.substring(Y,Y+7)}' found`)}if(X[Y+7]==="}"){if(t0(X[Y+3])&&t0(X[Y+4])&&t0(X[Y+5])&&t0(X[Y+6]))return Y+8;throw Error(`Unexpected token '${X.substring(Y,Y+8)}' found`)}if(X[Y+8]==="}"&&t0(X[Y+3])&&t0(X[Y+4])&&t0(X[Y+5])&&t0(X[Y+6])&&t0(X[Y+7]))return Y+9;throw Error(`Unexpected token '${X.substring(Y,Y+9)}' found`)}if(t0(X[Y+2])&&t0(X[Y+3])&&t0(X[Y+4])&&t0(X[Y+5]))return Y+6;throw Error(`Unexpected token '${X.substring(Y,Y+6)}' found`);case"p":case"P":{if(!Q)return Y+2;let G=Y+2;for(;G<X.length&&X[G]!=="}";G+=X[G]==="\\"?2:1);if(X[G]!=="}")throw Error("Invalid \\P definition");return G+1}case"k":{let G=Y+2;for(;G<X.length&&X[G]!==">";++G);if(X[G]!==">"){if(!Q)return Y+2;throw Error("Invalid \\k definition")}return G+1}default:if(DW($)){let G=Q?X.length:Math.min(Y+4,X.length),_=Y+2;for(;_<G&&DW(X[_]);++_);return _}return Y+(Q?pP(X,Y+1):1)+1}}default:return Y+(Q?pP(X,Y):1)}}function R$(X,Y,Q,J){let $=De(X,Y,Q,J);return X.substring(Y,$)}var uP={gc:"General_Category",sc:"Script",scx:"Script_Extensions"},h$={ASCII:"ASCII",ASCII_Hex_Digit:"AHex",Alphabetic:"Alpha",Any:"Any",Assigned:"Assigned",Bidi_Control:"Bidi_C",Bidi_Mirrored:"Bidi_M",Case_Ignorable:"CI",Cased:"Cased",Changes_When_Casefolded:"CWCF",Changes_When_Casemapped:"CWCM",Changes_When_Lowercased:"CWL",Changes_When_NFKC_Casefolded:"CWKCF",Changes_When_Titlecased:"CWT",Changes_When_Uppercased:"CWU",Dash:"Dash",Default_Ignorable_Code_Point:"DI",Deprecated:"Dep",Diacritic:"Dia",Emoji:"Emoji",Emoji_Component:"Emoji_Component",Emoji_Modifier:"Emoji_Modifier",Emoji_Modifier_Base:"Emoji_Modifier_Base",Emoji_Presentation:"Emoji_Presentation",Extended_Pictographic:"Extended_Pictographic",Extender:"Ext",Grapheme_Base:"Gr_Base",Grapheme_Extend:"Gr_Ext",Hex_Digit:"Hex",IDS_Binary_Operator:"IDSB",IDS_Trinary_Operator:"IDST",ID_Continue:"IDC",ID_Start:"IDS",Ideographic:"Ideo",Join_Control:"Join_C",Logical_Order_Exception:"LOE",Lowercase:"Lower",Math:"Math",Noncharacter_Code_Point:"NChar",Pattern_Syntax:"Pat_Syn",Pattern_White_Space:"Pat_WS",Quotation_Mark:"QMark",Radical:"Radical",Regional_Indicator:"RI",Sentence_Terminal:"STerm",Soft_Dotted:"SD",Terminal_Punctuation:"Term",Unified_Ideograph:"UIdeo",Uppercase:"Upper",Variation_Selector:"VS",White_Space:"space",XID_Continue:"XIDC",XID_Start:"XIDS"},lQ=fW(h$),mW={Cased_Letter:"LC",Close_Punctuation:"Pe",Connector_Punctuation:"Pc",Control:["Cc","cntrl"],Currency_Symbol:"Sc",Dash_Punctuation:"Pd",Decimal_Number:["Nd","digit"],Enclosing_Mark:"Me",Final_Punctuation:"Pf",Format:"Cf",Initial_Punctuation:"Pi",Letter:"L",Letter_Number:"Nl",Line_Separator:"Zl",Lowercase_Letter:"Ll",Mark:["M","Combining_Mark"],Math_Symbol:"Sm",Modifier_Letter:"Lm",Modifier_Symbol:"Sk",Nonspacing_Mark:"Mn",Number:"N",Open_Punctuation:"Ps",Other:"C",Other_Letter:"Lo",Other_Number:"No",Other_Punctuation:"Po",Other_Symbol:"So",Paragraph_Separator:"Zp",Private_Use:"Co",Punctuation:["P","punct"],Separator:"Z",Space_Separator:"Zs",Spacing_Mark:"Mc",Surrogate:"Cs",Symbol:"S",Titlecase_Letter:"Lt",Unassigned:"Cn",Uppercase_Letter:"Lu"},NW=fW(mW),fC={Adlam:"Adlm",Ahom:"Ahom",Anatolian_Hieroglyphs:"Hluw",Arabic:"Arab",Armenian:"Armn",Avestan:"Avst",Balinese:"Bali",Bamum:"Bamu",Bassa_Vah:"Bass",Batak:"Batk",Bengali:"Beng",Bhaiksuki:"Bhks",Bopomofo:"Bopo",Brahmi:"Brah",Braille:"Brai",Buginese:"Bugi",Buhid:"Buhd",Canadian_Aboriginal:"Cans",Carian:"Cari",Caucasian_Albanian:"Aghb",Chakma:"Cakm",Cham:"Cham",Cherokee:"Cher",Common:"Zyyy",Coptic:["Copt","Qaac"],Cuneiform:"Xsux",Cypriot:"Cprt",Cyrillic:"Cyrl",Deseret:"Dsrt",Devanagari:"Deva",Dogra:"Dogr",Duployan:"Dupl",Egyptian_Hieroglyphs:"Egyp",Elbasan:"Elba",Ethiopic:"Ethi",Georgian:"Geor",Glagolitic:"Glag",Gothic:"Goth",Grantha:"Gran",Greek:"Grek",Gujarati:"Gujr",Gunjala_Gondi:"Gong",Gurmukhi:"Guru",Han:"Hani",Hangul:"Hang",Hanifi_Rohingya:"Rohg",Hanunoo:"Hano",Hatran:"Hatr",Hebrew:"Hebr",Hiragana:"Hira",Imperial_Aramaic:"Armi",Inherited:["Zinh","Qaai"],Inscriptional_Pahlavi:"Phli",Inscriptional_Parthian:"Prti",Javanese:"Java",Kaithi:"Kthi",Kannada:"Knda",Katakana:"Kana",Kayah_Li:"Kali",Kharoshthi:"Khar",Khmer:"Khmr",Khojki:"Khoj",Khudawadi:"Sind",Lao:"Laoo",Latin:"Latn",Lepcha:"Lepc",Limbu:"Limb",Linear_A:"Lina",Linear_B:"Linb",Lisu:"Lisu",Lycian:"Lyci",Lydian:"Lydi",Mahajani:"Mahj",Makasar:"Maka",Malayalam:"Mlym",Mandaic:"Mand",Manichaean:"Mani",Marchen:"Marc",Medefaidrin:"Medf",Masaram_Gondi:"Gonm",Meetei_Mayek:"Mtei",Mende_Kikakui:"Mend",Meroitic_Cursive:"Merc",Meroitic_Hieroglyphs:"Mero",Miao:"Plrd",Modi:"Modi",Mongolian:"Mong",Mro:"Mroo",Multani:"Mult",Myanmar:"Mymr",Nabataean:"Nbat",New_Tai_Lue:"Talu",Newa:"Newa",Nko:"Nkoo",Nushu:"Nshu",Ogham:"Ogam",Ol_Chiki:"Olck",Old_Hungarian:"Hung",Old_Italic:"Ital",Old_North_Arabian:"Narb",Old_Permic:"Perm",Old_Persian:"Xpeo",Old_Sogdian:"Sogo",Old_South_Arabian:"Sarb",Old_Turkic:"Orkh",Oriya:"Orya",Osage:"Osge",Osmanya:"Osma",Pahawh_Hmong:"Hmng",Palmyrene:"Palm",Pau_Cin_Hau:"Pauc",Phags_Pa:"Phag",Phoenician:"Phnx",Psalter_Pahlavi:"Phlp",Rejang:"Rjng",Runic:"Runr",Samaritan:"Samr",Saurashtra:"Saur",Sharada:"Shrd",Shavian:"Shaw",Siddham:"Sidd",SignWriting:"Sgnw",Sinhala:"Sinh",Sogdian:"Sogd",Sora_Sompeng:"Sora",Soyombo:"Soyo",Sundanese:"Sund",Syloti_Nagri:"Sylo",Syriac:"Syrc",Tagalog:"Tglg",Tagbanwa:"Tagb",Tai_Le:"Tale",Tai_Tham:"Lana",Tai_Viet:"Tavt",Takri:"Takr",Tamil:"Taml",Tangut:"Tang",Telugu:"Telu",Thaana:"Thaa",Thai:"Thai",Tibetan:"Tibt",Tifinagh:"Tfng",Tirhuta:"Tirh",Ugaritic:"Ugar",Vai:"Vaii",Warang_Citi:"Wara",Yi:"Yiii",Zanabazar_Square:"Zanb"},cP=fW(fC);function fW(X){let Y={};for(let Q of Object.keys(X)){let J=X[Q];if(Array.isArray(J))for(let $=0;$!==J.length;++$)Y[J[$]]=Q;else Y[J]=Q}return Y}function Ne(X){return X in mW||X in NW}function Be(X){return X in h$||X in lQ}function lP(X){if(X in uP)return uP[X];if(X in lQ)return lQ[X];if(X in h$||X==="General_Category"||X==="Script"||X==="Script_Extensions")return X;throw Error(`Unknown Unicode property name: ${X}`)}function oP(X){if(X in NW)return NW[X];if(X in cP)return cP[X];if(X in lQ)return lQ[X];if(X in mW||X in fC||X in h$)return X;throw Error(`Unknown Unicode property value: ${X}`)}function Ve(X,Y){let Q=X.indexOf("=");if(Q!==-1){let J=X.substring(0,Q),$=X.substring(Q+1);return{type:"UnicodeProperty",name:J,value:$,negative:Y,shorthand:!1,binary:!1,canonicalName:lP(J),canonicalValue:oP($)}}if(Ne(X))return{type:"UnicodeProperty",name:"General_Category",value:X,negative:Y,shorthand:!0,binary:!1,canonicalName:"General_Category",canonicalValue:oP(X)};if(Be(X)){let J=lP(X);return{type:"UnicodeProperty",name:X,value:X,negative:Y,shorthand:!1,binary:!0,canonicalName:J,canonicalValue:J}}throw Error(`Invalid Unicode property: ${X}`)}var cH=String.fromCodePoint;function lH(X){let Y=X.pop();if(Y===void 0)throw Error("Unable to extract token preceeding the currently parsed one");return Y}function dC(X){return X>="0"&&X<="9"}function j$(X,Y){return{type:"Char",kind:"simple",symbol:X,value:X,codePoint:X.codePointAt(0)||-1,escaped:Y}}function C9(X,Y){return{type:"Char",kind:"meta",symbol:Y,value:X,codePoint:Y.codePointAt(0)||-1}}function J4(X,Y){if(X.length>1)return{type:"Alternative",expressions:X};if(!Y&&X.length===0)throw Error("Unsupported no token");return X[0]}function oH(X){if(X[0]==="\\"){let Y=X[1];switch(Y){case"x":{let Q=X.substring(2),J=Number.parseInt(Q,16);return{type:"Char",kind:"hex",symbol:cH(J),value:X,codePoint:J}}case"u":{if(X==="\\u")return j$("u",!0);let Q=X[2]==="{"?X.substring(3,X.length-1):X.substring(2),J=Number.parseInt(Q,16);return{type:"Char",kind:"unicode",symbol:cH(J),value:X,codePoint:J}}case"0":return C9(X,"\x00");case"n":return C9(X,`
`);case"f":return C9(X,"\f");case"r":return C9(X,"\r");case"t":return C9(X,"\t");case"v":return C9(X,"\v");case"w":case"W":case"d":case"D":case"s":case"S":case"b":case"B":return{type:"Char",kind:"meta",symbol:void 0,value:X,codePoint:NaN};default:if(dC(Y)){let Q=X.substring(1),J=Number(Q);return{type:"Char",kind:"decimal",symbol:cH(J),value:X,codePoint:J}}if(X.length>2&&(Y==="p"||Y==="P")){let Q=Y==="P";return Ve(X.substring(3,X.length-1),Q)}return j$(X.substring(1),!0)}}return j$(X)}function E9(X,Y,Q,J){let $=null;for(let G=0,_=R$(Y,G,Q,0);G!==Y.length;G+=_.length,_=R$(Y,G,Q,0)){let K=_[0];switch(K){case"|":if($===null)$=[];$.push(J4(X.splice(0),!0)||null);break;case".":X.push({type:"Char",kind:"meta",symbol:_,value:_,codePoint:NaN});break;case"*":case"+":{let H=lH(X);X.push({type:"Repetition",expression:H,quantifier:{type:"Quantifier",kind:K,greedy:!0}});break}case"?":{let H=lH(X);if(H.type==="Repetition")H.quantifier.greedy=!1,X.push(H);else X.push({type:"Repetition",expression:H,quantifier:{type:"Quantifier",kind:K,greedy:!0}});break}case"{":{if(_==="{"){X.push(j$(_));break}let H=lH(X),W=_.substring(1,_.length-1).split(","),D=Number(W[0]),U=W.length===1?D:W[1].length!==0?Number(W[1]):void 0;X.push({type:"Repetition",expression:H,quantifier:{type:"Quantifier",kind:"Range",greedy:!0,from:D,to:U}});break}case"[":{let H=_.substring(1,_.length-1),W=[],D=void 0,U=!1;for(let N=0,B=R$(H,N,Q,1);N!==H.length;N+=B.length,B=R$(H,N,Q,1)){if(N===0&&B==="^"){D=!0;continue}let z=oH(B);if(B==="-")W.push(z),U=!0;else{let q=W.length>=2?W[W.length-2]:void 0;if(U&&q!==void 0&&q.type==="Char"&&z.type==="Char")W.pop(),W.pop(),W.push({type:"ClassRange",from:q,to:z});else W.push(z);U=!1}}X.push({type:"CharacterClass",expressions:W,negative:D});break}case"(":{let H=_.substring(1,_.length-1),W=[];if(H[0]==="?")if(H[1]===":")E9(W,H.substring(2),Q,J),X.push({type:"Group",capturing:!1,expression:J4(W)});else if(H[1]==="="||H[1]==="!")E9(W,H.substring(2),Q,J),X.push({type:"Assertion",kind:"Lookahead",negative:H[1]==="!"?!0:void 0,assertion:J4(W)});else if(H[1]==="<"&&(H[2]==="="||H[2]==="!"))E9(W,H.substring(3),Q,J),X.push({type:"Assertion",kind:"Lookbehind",negative:H[2]==="!"?!0:void 0,assertion:J4(W)});else{let D=H.split(">");if(D.length<2||D[0][1]!=="<")throw Error(`Unsupported regex content found at ${JSON.stringify(_)}`);let U=++J.lastIndex,N=D[0].substring(2);J.named.set(N,U),E9(W,D.slice(1).join(">"),Q,J),X.push({type:"Group",capturing:!0,nameRaw:N,name:N,number:U,expression:J4(W)})}else{let D=++J.lastIndex;E9(W,H,Q,J),X.push({type:"Group",capturing:!0,number:D,expression:J4(W)})}break}default:if(_==="^")X.push({type:"Assertion",kind:_});else if(_==="$")X.push({type:"Assertion",kind:_});else if(_[0]==="\\"&&dC(_[1])){let H=Number(_.substring(1));if(Q||H<=J.lastIndex)X.push({type:"Backreference",kind:"number",number:H,reference:H});else X.push(oH(_))}else if(_[0]==="\\"&&_[1]==="k"&&_.length!==2){let H=_.substring(3,_.length-1);X.push({type:"Backreference",kind:"name",number:J.named.get(H)||0,referenceRaw:H,reference:H})}else X.push(oH(_));break}}if($!==null){$.push(J4(X.splice(0),!0)||null);let G={type:"Disjunction",left:$[0],right:$[1]};for(let _=2;_<$.length;++_)G={type:"Disjunction",left:G,right:$[_]};X.push(G)}}function ze(X){let Y=fQ([...X.flags],"u")!==-1,Q=X.source,J=[];return E9(J,Q,Y,{lastIndex:0,named:new Map}),J4(J)}var qe=String.fromCodePoint;function Le(X){if(X.binary||X.shorthand)return X.canonicalValue;return`${X.canonicalName}=${X.canonicalValue}`}function iP(X,Y,Q,J){let $=-1;for(let G=Y;G<=Q;++G)if(X.test(qe(G))){if($===-1)$=G}else if($!==-1){let _=G-1;J.push($===_?[_]:[$,_]),$=-1}if($!==-1)J.push($===Q?[Q]:[$,Q])}function Oe(X,Y){let Q=new RegExp(`^\\${Y?"P":"p"}{${X}}$`,"u"),J=[];return iP(Q,0,55295,J),iP(Q,57344,1114111,J),J}var rP=new Map;function Te(X,Y){let Q=`${Y?"P":"p"}:${X}`,J=rP.get(Q);if(J!==void 0)return J;let $=Oe(X,Y);return rP.set(Q,$),$}function Fe(X){return S9(...L0(Te(Le(X),X.negative),(Y)=>eH(Y)))}var Re=String.fromCodePoint,pC=[..."abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"],uC=[..."0123456789"],cC=[...` 	\r
\v\f`],BW=[...`\r
`],lC=[..."\x1E\x15"],Ae=[...BW,...lC],Pe=new eX(pC),we=new eX(uC),Ce=new eX(cC),Ee=new eX(lC),Me=new eX(Ae),W5=()=>e0({unit:"grapheme-ascii",minLength:1,maxLength:1});function nP(X){return new y(`Unsupported AST node! Received: ${s0(X)}`)}function U5(X,Y,Q){switch(X.type){case"Char":if(X.kind==="meta")switch(X.value){case"\\w":return M6(...pC);case"\\W":return W5().filter((J)=>!$4(Pe,J));case"\\d":return M6(...uC);case"\\D":return W5().filter((J)=>!$4(we,J));case"\\s":return M6(...cC);case"\\S":return W5().filter((J)=>!$4(Ce,J));case"\\b":case"\\B":throw new y(`Meta character ${X.value} not implemented yet!`);case".":{let J=Q.dotAll?Ee:Me;return W5().filter(($)=>!$4(J,$))}}if(X.symbol===void 0)throw new y(`Unexpected undefined symbol received for non-meta Char! Received: ${s0(X)}`);return y0(X.symbol);case"Repetition":{let J=U5(X.expression,Y,Q);switch(X.quantifier.kind){case"*":return e0({...Y,unit:J});case"+":return e0({...Y,minLength:1,unit:J});case"?":return e0({...Y,minLength:0,maxLength:1,unit:J});case"Range":return e0({...Y,minLength:X.quantifier.from,maxLength:X.quantifier.to,unit:J});default:throw nP(X.quantifier)}}case"Quantifier":throw new y("Wrongly defined AST tree, Quantifier nodes not supposed to be scanned!");case"Alternative":{let J=[],$="";for(let G of X.expressions)if(G.type==="Char"&&G.kind!=="meta"&&G.symbol!==void 0)$+=G.symbol;else if(Q.multiline||G.type!=="Assertion"||G.kind!=="^"&&G.kind!=="$"){if($!=="")I(J,y0($)),$="";I(J,U5(G,Y,Q))}if($!=="")I(J,y0($));if(J.length===0)return y0("");if(J.length===1)return J[0];return _0(...J).map((G)=>h0(G,""))}case"CharacterClass":if(X.negative){let J=L0(X.expressions,($)=>U5($,Y,Q));return W5().filter(($)=>Kw(J,(G)=>!G.canShrinkWithoutContext($)))}return K1(...L0(X.expressions,(J)=>U5(J,Y,Q)));case"ClassRange":{let J=X.from.codePoint,$=X.to.codePoint;return w0({min:J,max:$}).map((G)=>Re(G),(G)=>{if(typeof G!=="string")throw new y("Invalid type");if([...G].length!==1)throw new y("Invalid length");return j9(G,0)})}case"Group":return U5(X.expression,Y,Q);case"Disjunction":{let J=[X.left,X.right],$=[];for(let G=0;G!==J.length;++G){let _=J[G];if(_===null)I($,y0(""));else if(_.type==="Disjunction")I(J,_.left),I(J,_.right);else I($,U5(_,Y,Q))}return K1(...$)}case"Assertion":if(X.kind==="^"||X.kind==="$"){if(Q.multiline)if(X.kind==="^")return K1(y0(""),_0(e0({unit:W5()}),M6(...BW)).map((J)=>`${J[0]}${J[1]}`,(J)=>{if(typeof J!=="string"||J.length===0)throw new y("Invalid type");return[u0(J,0,J.length-1),J[J.length-1]]}));else return K1(y0(""),_0(M6(...BW),e0({unit:W5()})).map((J)=>`${J[0]}${J[1]}`,(J)=>{if(typeof J!=="string"||J.length===0)throw new y("Invalid type");return[J[0],u0(J,1)]}));return y0("")}throw new y(`Assertions of kind ${X.kind} not implemented yet!`);case"Backreference":throw new y("Backreference nodes not implemented yet!");case"UnicodeProperty":return Fe(X);default:throw nP(X)}}function je(X,Y={}){for(let K of X.flags)if(K!=="d"&&K!=="g"&&K!=="m"&&K!=="s"&&K!=="u")throw new y(`Unable to use "stringMatching" against a regex using the flag ${K}`);let Q=Y.maxLength,J={size:Y.size,maxLength:Q},$={multiline:X.multiline,dotAll:X.dotAll},G=He(ze(X));if(Q!==void 0)G=_e(G,Q);let _=U5(G,J,$);if(Q!==void 0)return _.filter((K)=>[...K].length<=Q);return _}function Ie(X){let Y=[];for(let Q=0;Q!==X.length;++Q)Y.push(X[Q].next());return Y}function xe(X,Y){for(let Q=0;Q!==X.length;++Q)Y[Q]=X[Q].next()}function Se(X){for(let Y=0;Y!==X.length;++Y)if(X[Y].done)return!0;return!1}function*ve(...X){let Y=Ie(X);while(!Se(Y))yield Y.map((Q)=>Q.value),xe(X,Y)}function*ke(X){let Y=X;while(!0)yield Y,++Y}var be=class extends m0{constructor(X,Y){super();this.arb=X,this.maxShrinks=Y}generate(X,Y){let Q=this.arb.generate(X,Y);return this.valueMapper(Q,0)}canShrinkWithoutContext(X){return this.arb.canShrinkWithoutContext(X)}shrink(X,Y){if(this.isSafeContext(Y))return this.safeShrink(X,Y.originalContext,Y.length);return this.safeShrink(X,void 0,0)}safeShrink(X,Y,Q){let J=this.maxShrinks-Q;if(J<=0)return K0.nil();return new K0(ve(this.arb.shrink(X,Y),ke(Q+1))).take(J).map(($)=>this.valueMapper($[0],$[1]))}valueMapper(X,Y){let Q={originalContext:X.context,length:Y};return new g(X.value,Q)}isSafeContext(X){return X!==null&&X!==void 0&&typeof X==="object"&&"originalContext"in X&&"length"in X}};function ge(X,Y){return new be(X,Y)}var ye="module",he="4.9.0",me="0d3c2547dce556f72413607849377530d18ea283";var rQ=X$;function qX(){return(X,Y,Q)=>{return v(new Z5(X.map(OQ),(J)=>Y(J.map(($)=>v($))),Q))}}function SX(X,Y){return qX()([],()=>(Q,J)=>X(Q)?p(Q):f(new r0(J,T(Q))),Y)}function fe(X){return X}function de(X){return(Y)=>Y.annotate(X)}function pe(X){return(Y)=>dW(dW(Y).annotate(X))}function ue(X){return(Y)=>{return Y.rebuild(wQ(Y.ast,X))}}function ce(X){return X}function oC(X){return M1(X)?X.value:{issues:[{message:Hq(X.cause)}]}}function le(X,Y){let Q=a0(X),J={errors:"all",...Y?.parseOptions},$=uO(Y),G=(_)=>{let K=new m5,H=C_(P_(Q(_,J),{onFailure:$,onSuccess:(D)=>({value:D})}),{scheduler:K});H.currentDispatcher?.flush();let W=H.pollUnsafe();if(W)return oC(W);return new Promise((D)=>{H.addObserver((U)=>{D(oC(U))})})};if("~standard"in X){let _=X;if("validate"in _["~standard"])return _;return Object.assign(_["~standard"],{validate:G}),_}else return Object.assign(X,{"~standard":{version:1,vendor:"effect",validate:G}})}function iC(X,Y){let Q=Xj(X);if(Y==="draft-2020-12"){let J=Q.schema;if(Object.keys(Q.definitions).length>0)J.$defs=Q.definitions;return J}else if(Y==="draft-07"){let J=xR(Q),$=J.schema;if(Object.keys(J.definitions).length>0)$.definitions=J.definitions;return $}throw new globalThis.Error(`Unsupported target: ${Y}`)}function oe(X){let Y={input(Q){return iC(X,Q.target)},output(Q){return iC(u1(X),Q.target)}};if("~standard"in X){let Q=X;if("jsonSchema"in Q["~standard"])return Q;return Object.assign(Q["~standard"],{jsonSchema:Y}),Q}else return Object.assign(X,{"~standard":{version:1,vendor:"effect",jsonSchema:Y}})}var GE=kF,ie=gF;function u$(X,Y){let Q=a0(X,Y);return(J,$)=>{return Y$(Q(J,$))}}var re=u$;function ZE(X,Y){let Q;for(let J of X.reasons){if(!p3(J)||!YH(J.error))throw new globalThis.Error(Y,{cause:X});Q??=J.error}if(Q===void 0)throw new globalThis.Error(Y,{cause:X});return Q}function _E(X){return XJ(X).then((Y)=>{if(M1(Y))return Y.value;throw ZE(Y.cause,"Promise adapter can only reject schema errors")})}function KE(X){let Y=p8(X);if(M1(Y))return Y.value;throw ZE(Y.cause,"Sync adapter can only throw schema errors")}function HE(X,Y){let Q=yF(X,Y);return(J,$)=>{return WE(Q(J,$))}}function WE(X){return M1(X)?n5(X.value):m8($8(X.cause,(Y)=>new Y4(Y)))}var ne=HE,se=JH,ae=hF;function UE(X,Y){let Q=mF(X,Y);return(J,$)=>{return x4(Q(J,$),(G)=>new Y4(G))}}var te=UE;function DE(X,Y){let Q=u$(X,Y);return(J,$)=>{return _E(Q(J,$))}}var ee=DE;function NE(X,Y){let Q=u$(X,Y);return(J,$)=>{return KE(Q(J,$))}}var X00=NE;function c$(X,Y){let Q=T9(X,Y);return(J,$)=>{return Y$(Q(J,$))}}var BE=c$;function VE(X,Y){let Q=fF(X,Y);return(J,$)=>{return WE(Q(J,$))}}var Y00=VE,Q00=GH,J00=dF;function zE(X,Y){let Q=pF(X,Y);return(J,$)=>{return x4(Q(J,$),(G)=>new Y4(G))}}var $00=zE;function qE(X,Y){let Q=c$(X,Y);return(J,$)=>{return _E(Q(J,$))}}var G00=qE;function LE(X,Y){let Q=c$(X,Y);return(J,$)=>{return KE(Q(J,$))}}var Z00=LE,v=IQ;function l$(X){return j(X,rQ)&&X[rQ]===rQ}var W4=j1((X)=>v(CQ(X.ast),{schema:X})),_00=j1((X)=>X.schema),xX=j1((X)=>W4(r$(X))),K00=j1((X)=>X.schema.members[0]),H00=j1((X)=>v(iK(X.ast),{schema:X})),W00=j1((X)=>X.schema),u1=j1((X)=>v(T1(X.ast),{schema:X})),h9=j1((X)=>v(F1(X.ast),{schema:X})),nQ="~effect/Schema/flip";function U00(X){return j(X,nQ)&&X[nQ]===nQ}function dW(X){if(U00(X))return X.schema.rebuild(lX(X.ast));return v(lX(X.ast),{[nQ]:nQ,schema:X})}function c0(X){let Y=v(new DX(X),{literal:X,transform(Q){return Y.pipe(l(c0(Q),{decode:Q0(()=>Q),encode:Q0(()=>X)}))}});return Y}function OE(X){return new hK(X.map((Y)=>l$(Y)?Y.ast:new DX(Y)))}function D00(X){return v(OE(X),{parts:X})}function N00(X){return v(OE(X).asTemplateLiteralParser(),{parts:X})}function B00(X){return v(new yK(Object.keys(X).filter((Y)=>typeof X[X[Y]]!=="number").map((Y)=>[Y,X[Y]])),{enums:X})}var V00=v(sT),z00=v(tT),cW=v(Q5),T0=v(gK),lW=v(oT),r=v(s8),o$=v(fK),TE=v(ZF),FE=v(KF),j6=v(WF),q00=v(rT),L00=v(YF);function O00(X){return v(new mK(X))}function oW(X,Y){return v(X,{fields:Y,mapFields(Q,J){let $=Q(this.fields);return oW(mJ($,J?.unsafePreserveChecks?this.ast.checks:void 0),$)}})}function h(X){return oW(mJ(X,void 0),X)}function T00(X){return j1((Y)=>Y.mapFields(sF(X)))}var F00=(X)=>typeof X==="symbol"?X:globalThis.String(X);function R00(X){return function(Y){let Q={},J=Object.create(null),$=Object.create(null),G=new Set;for(let _ of Reflect.ownKeys(Y.fields)){let K=h9(Y.fields[_]),H=Object.hasOwn(X,_),W=H?X[_]:_,D=F00(W);if(G.has(D))throw new globalThis.Error(`Duplicate encoded keys: ${m6(W)}`);if(G.add(D),k(Q,W,K),H)J[_]=W,$[W]=_}return h(Q).pipe(l(Y,d0({decode:KH($),encode:KH(J)})))}}function A00(X,Y){return(Q)=>{let J=$3(Q.fields,u1),$=h({...J,...X});return Q.pipe(l($,d0({decode:(G)=>{let _={...G};for(let K in X){let H=Y[K],W=H(G);if(N1(W))k(_,K,W.value)}return _},encode:(G)=>{let _={...G};for(let K in X)delete _[K];return _}})))}}function RE(X,Y,Q){let J=Q?.keyValueCombiner?.decode||Q?.keyValueCombiner?.encode?new yJ(Q.keyValueCombiner.decode,Q.keyValueCombiner.encode):void 0;return v(TF(X.ast,Y.ast,J),{key:X,value:Y})}function P00(X,Y){return v(UF(X.ast,Y.map(OQ)),{schema:X,records:Y})}function AE(X,Y){return v(X,{elements:Y,mapElements(Q,J){let $=Q(this.elements);return AE(uK($,J?.unsafePreserveChecks?this.ast.checks:void 0),$)}})}function k9(X){return AE(uK(X),X)}function w00(X,Y){return v(DF(X.ast,Y.map(OQ)),{schema:X,rest:Y})}var Q1=j1((X)=>v(new iX(!1,[],[X.ast]),{value:X}));var C00=j1((X)=>v(new iX(!1,[X.ast],[X.ast]),{value:X}));function E00(X){return J1([X,Q1(X)]).pipe(l(Q1(u1(X)),d0({decode:cN,encode:(Y)=>Y.length===1?Y[0]:Y})))}function M00(X){return Q1(X).check(JU())}var j00=j1((X)=>{return v(new iX(!0,X.ast.elements,X.ast.rest),{schema:X})});function PE(X,Y){return v(X,{members:Y,mapMembers(Q,J){let $=Q(this.members);return PE(fJ($,this.ast.mode,J?.unsafePreserveChecks?this.ast.checks:void 0),$)}})}function J1(X,Y){return PE(fJ(X,Y?.mode??"anyOf",void 0),X)}function i$(X){let Y=X.map(c0);return v(fJ(Y,"anyOf",void 0),{literals:X,members:Y,mapMembers(Q){return J1(Q(this.members))},pick(Q){return i$(Q)},transform(Q){return J1(Y.map((J,$)=>J.transform(Q[$])))}})}var iW=j1((X)=>J1([X,T0])),r$=j1((X)=>J1([X,lW])),wE=j1((X)=>J1([X,T0,lW]));function CE(X){return v(new dJ(()=>X().ast))}function I00(...X){return(Y)=>Y.check(...X)}function x00(X,Y){return(Q)=>v(rX(Q.ast,[uJ(X,Y)]),{schema:Q})}function EE(X){return(Y)=>v(LF(Y.ast,X),{schema:Y,identifier:X})}function S00(X,Y){return(Q)=>{return(Y.checks?Q.check(...Y.checks):Q).pipe(EE(X))}}function rW(X){return(Y)=>v(zF(Y.ast,new VQ(X,u)),{schema:Y})}function ME(X){return(Y)=>v(qF(Y.ast,new VQ(u,X)),{schema:Y})}function v00(X){return jE(X)}function jE(X){return(Y)=>rW(YJ(X))(Y)}function k00(X){return IE(X)}function IE(X){return(Y)=>ME(YJ(X))(Y)}function l(X,Y){return(Q)=>{return v(oJ(Q.ast,X.ast,Y?jJ(Y):D9()),{from:Q,to:X})}}function b00(X){return(Y)=>{return l(u1(Y),X)(Y)}}function nW(X,Y){return(Q)=>{return Y?l(Q,Y)(X):l(Q)(X)}}function g00(X){return(Y)=>{return l(Y,X)(h9(Y))}}function xE(X){return(Y)=>v(OF(Y.ast,sW(X)),{schema:Y})}function sW(X){return i4(X,(Y)=>o4(()=>$8(Y,(Q)=>Q.issue)))}function aW(X,Y){let Q=Y?.encodingStrategy==="omit"?qK():cX();return(J)=>{return W4(h9(J)).pipe(l(J,{decode:NQ(sW(X)),encode:Q}))}}function y00(X,Y){return(Q)=>{return u1(Q).pipe(aW(X,Y),nW(W4(Q)))}}function SE(X,Y){let Q=Y?.encodingStrategy==="omit"?qK():cX();return(J)=>{return xX(h9(J)).pipe(l(J,{decode:NQ(sW(X)),encode:Q}))}}function h00(X,Y){return(Q)=>{return u1(Q).pipe(SE(X,Y),nW(xX(Q)))}}function V5(X){return c0(X).pipe(xE(p(X)))}function m00(X){return V5(X).pipe(aW(p(X),{encodingStrategy:"omit"}))}function n$(X,Y){return h({_tag:V5(X),...Y})}function vE(X){return(Y)=>{let Q={},J=[],$=new Set,G={},_=(W)=>(D)=>W.includes(D[X]);return K(Y),Object.assign(Y,{cases:Q,discriminants:J,isAnyOf:_,guards:G,match:H});function K(W){let D=W.ast;if(LQ(D)&&"members"in W&&globalThis.Array.isArray(W.members)&&W.members.every(l$))return W.members.forEach(K);let U=TQ(D);if(U.length>0){let N=U.find((B)=>B.key===X)?.literal;if(w7(N)){let B=typeof N==="number"?globalThis.String(N):N;if($.has(B))throw new globalThis.Error(`Duplicate discriminant: ${globalThis.String(N)}`);$.add(B),J.push(N),k(Q,N,W),k(G,N,GE(u1(W)));return}}throw new globalThis.Error("No literal or unique symbol found")}function H(){if(arguments.length===1){let B=arguments[0];return function(z){let q=z[X];return(Object.hasOwn(B,q)?B[q]:void 0)(z)}}let W=arguments[0],D=arguments[1],U=W[X];return(Object.hasOwn(D,U)?D[U]:void 0)(W)}}}function f00(X){let Y={},Q=[];for(let K of Object.keys(X)){let H=n$(K,X[K]);k(Y,K,H),Q.push(H)}let J=J1(Q),{guards:$,isAnyOf:G,match:_}=vE("_tag")(J);return v(J.ast,{cases:Y,isAnyOf:G,guards:$,match:_})}function d00(){return(X)=>{return X}}function U4(X,Y){return SX((Q)=>Q instanceof X,Y)}function v0(){return(X,Y)=>{return new p0(X.ast,jJ(Y))}}var j0=pJ;function p00(X,Y=void 0){return new n8(X,Y)}function I1(X,Y){return JX(X,T0,({annotations:Q})=>Q===void 0?Y:Y.annotate(Q))}var rC="^\\S[\\s\\S]*\\S$|^\\S$|^$";function tW(X){let Y=new globalThis.RegExp(rC);return j0((Q)=>Q.trim()===Q,{expected:"a string with no leading or trailing whitespace",representation:{id:"effect/schema/isTrimmed",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isTrimmed()"}),arbitrary:{constraint:{patterns:[rC]}},...X})}var u00=s("effect/schema/isTrimmed",T0,({annotations:X})=>tW(X));function z5(X,Y){let{source:Q,flags:J}=X,$=J===""?`new RegExp(${P(Q)})`:`new RegExp(${P(Q)}, ${P(J)})`;return RQ(X,{toCode:()=>({runtime:`Schema.isPattern(${$})`}),...Y})}var c00=h({source:r,flags:r}).check(j0((X)=>{let Y=AZ(()=>new globalThis.RegExp(X.source,X.flags));return Y1(Y)&&Y.success.source===X.source&&Y.success.flags===X.flags})),l00={id:"effect/schema/isPattern",payloadSchema:c00,revive:({annotations:X,payload:Y})=>z5(new globalThis.RegExp(Y.source,Y.flags),X)};function kE(X){return nK({toCode:()=>({runtime:"Schema.isStringFinite()"}),...X})}var o00=s("effect/schema/isStringFinite",T0,({annotations:X})=>kE(X));function bE(X){return sK({toCode:()=>({runtime:"Schema.isStringBigInt()"}),...X})}var i00=s("effect/schema/isStringBigInt",T0,({annotations:X})=>bE(X));function gE(X){return tK({toCode:()=>({runtime:"Schema.isStringSymbol()"}),...X})}var r00=s("effect/schema/isStringSymbol",T0,({annotations:X})=>gE(X)),n00=(X)=>{if(X)return new globalThis.RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${X}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`);return/^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|[fF]{8}-[fF]{4}-[fF]{4}-[fF]{4}-[fF]{12})$/};function yE(X,Y){let Q=n00(X);return z5(Q,{expected:X?`a UUID v${X}`:"a UUID",representation:{id:"effect/schema/isUUID",payload:{version:X??null}},toJsonSchema:()=>({pattern:Q.source,format:"uuid"}),toCode:()=>({runtime:X===void 0?"Schema.isUUID()":`Schema.isUUID(${X})`}),...Y})}var s00=s("effect/schema/isUUID",h({version:J1([i$([1,2,3,4,5,6,7,8]),T0])}),({annotations:X,payload:Y})=>yE(Y.version??void 0,X)),nC=/^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/;function hE(X){return z5(nC,{expected:"a GUID",representation:{id:"effect/schema/isGUID",payload:null},toJsonSchema:()=>({pattern:nC.source}),toCode:()=>({runtime:"Schema.isGUID()"}),...X})}var a00=s("effect/schema/isGUID",T0,({annotations:X})=>hE(X));function mE(X){let Y=/^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/;return z5(Y,{representation:{id:"effect/schema/isULID",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isULID()"}),...X})}var t00=s("effect/schema/isULID",T0,({annotations:X})=>mE(X));function eW(X){let Y=/^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;return z5(Y,{expected:"a base64 encoded string",representation:{id:"effect/schema/isBase64",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isBase64()"}),...X})}var e00=s("effect/schema/isBase64",T0,({annotations:X})=>eW(X));function fE(X){let Y=/^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;return z5(Y,{expected:"a base64url encoded string",representation:{id:"effect/schema/isBase64Url",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isBase64Url()"}),...X})}var X10=s("effect/schema/isBase64Url",T0,({annotations:X})=>fE(X));function dE(X,Y){let Q=JSON.stringify(X),J=new globalThis.RegExp(`^${A9(X)}`);return j0(($)=>$.startsWith(X),{expected:`a string starting with ${Q}`,representation:{id:"effect/schema/isStartsWith",payload:{startsWith:X}},toJsonSchema:()=>({pattern:J.source}),toCode:()=>({runtime:`Schema.isStartsWith(${P(X)})`}),arbitrary:{constraint:{patterns:[J.source]}},...Y})}var Y10=s("effect/schema/isStartsWith",h({startsWith:r}),({annotations:X,payload:Y})=>dE(Y.startsWith,X));function pE(X,Y){let Q=JSON.stringify(X),J=new globalThis.RegExp(`${A9(X)}$`);return j0(($)=>$.endsWith(X),{expected:`a string ending with ${Q}`,representation:{id:"effect/schema/isEndsWith",payload:{endsWith:X}},toJsonSchema:()=>({pattern:J.source}),toCode:()=>({runtime:`Schema.isEndsWith(${P(X)})`}),arbitrary:{constraint:{patterns:[J.source]}},...Y})}var Q10=s("effect/schema/isEndsWith",h({endsWith:r}),({annotations:X,payload:Y})=>pE(Y.endsWith,X));function uE(X,Y){let Q=JSON.stringify(X),J=new globalThis.RegExp(A9(X));return j0(($)=>$.includes(X),{expected:`a string including ${Q}`,representation:{id:"effect/schema/isIncludes",payload:{includes:X}},toJsonSchema:()=>({pattern:J.source}),toCode:()=>({runtime:`Schema.isIncludes(${P(X)})`}),arbitrary:{constraint:{patterns:[J.source]}},...Y})}var J10=s("effect/schema/isIncludes",h({includes:r}),({annotations:X,payload:Y})=>uE(Y.includes,X)),sC="^[^a-z]*$";function cE(X){let Y=new globalThis.RegExp(sC);return j0((Q)=>Q.toUpperCase()===Q,{expected:"a string with all characters in uppercase",representation:{id:"effect/schema/isUppercased",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isUppercased()"}),arbitrary:{constraint:{patterns:[sC]}},...X})}var $10=s("effect/schema/isUppercased",T0,({annotations:X})=>cE(X)),aC="^[^A-Z]*$";function lE(X){let Y=new globalThis.RegExp(aC);return j0((Q)=>Q.toLowerCase()===Q,{expected:"a string with all characters in lowercase",representation:{id:"effect/schema/isLowercased",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isLowercased()"}),arbitrary:{constraint:{patterns:[aC]}},...X})}var G10=s("effect/schema/isLowercased",T0,({annotations:X})=>lE(X)),tC="^[^a-z]?.*$";function oE(X){let Y=new globalThis.RegExp(tC);return j0((Q)=>Q.charAt(0).toUpperCase()===Q.charAt(0),{expected:"a string with the first character in uppercase",representation:{id:"effect/schema/isCapitalized",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isCapitalized()"}),arbitrary:{constraint:{patterns:[tC]}},...X})}var Z10=s("effect/schema/isCapitalized",T0,({annotations:X})=>oE(X)),eC="^[^A-Z]?.*$";function iE(X){let Y=new globalThis.RegExp(eC);return j0((Q)=>Q.charAt(0).toLowerCase()===Q.charAt(0),{expected:"a string with the first character in lowercase",representation:{id:"effect/schema/isUncapitalized",payload:null},toJsonSchema:()=>({pattern:Y.source}),toCode:()=>({runtime:"Schema.isUncapitalized()"}),arbitrary:{constraint:{patterns:[eC]}},...X})}var _10=s("effect/schema/isUncapitalized",T0,({annotations:X})=>iE(X)),Q6=v(kJ),rE=cK,K10=s("effect/schema/isFinite",T0,({annotations:X})=>rE(X));function sQ(X){let Y=M8(X.order),Q=X.formatter??P;return(J,$)=>{return j0((G)=>Y(G,J),{expected:`a value greater than ${Q(J)}`,arbitrary:{constraint:{ordered:{order:X.order,minimum:J,exclusiveMinimum:!0}}},...X.annotate?.(J),...$})}}function aQ(X){let Y=WY(X.order),Q=X.formatter??P;return(J,$)=>{return j0((G)=>Y(G,J),{expected:`a value greater than or equal to ${Q(J)}`,arbitrary:{constraint:{ordered:{order:X.order,minimum:J}}},...X.annotate?.(J),...$})}}function tQ(X){let Y=x5(X.order),Q=X.formatter??P;return(J,$)=>{return j0((G)=>Y(G,J),{expected:`a value less than ${Q(J)}`,arbitrary:{constraint:{ordered:{order:X.order,maximum:J,exclusiveMaximum:!0}}},...X.annotate?.(J),...$})}}function eQ(X){let Y=HY(X.order),Q=X.formatter??P;return(J,$)=>{return j0((G)=>Y(G,J),{expected:`a value less than or equal to ${Q(J)}`,arbitrary:{constraint:{ordered:{order:X.order,maximum:J}}},...X.annotate?.(J),...$})}}function X7(X){let Y=WY(X.order),Q=M8(X.order),J=HY(X.order),$=x5(X.order),G=X.formatter??P;return(_,K)=>{let H=_.exclusiveMinimum?Q:Y,W=_.exclusiveMaximum?$:J;return j0((D)=>H(D,_.minimum)&&W(D,_.maximum),{expected:`a value between ${G(_.minimum)}${_.exclusiveMinimum?" (excluded)":""} and ${G(_.maximum)}${_.exclusiveMaximum?" (excluded)":""}`,arbitrary:{constraint:{ordered:{order:X.order,minimum:_.minimum,maximum:_.maximum,..._.exclusiveMinimum&&{exclusiveMinimum:!0},..._.exclusiveMaximum&&{exclusiveMaximum:!0}}}},...X.annotate?.(_),...K})}}function nE(X){return(Y,Q)=>{let J=X.formatter??P;return j0(($)=>X.remainder($,Y)===X.zero,{expected:`a value that is a multiple of ${J(Y)}`,...X.annotate?.(Y),...Q})}}function b9(X){if(!globalThis.Number.isFinite(X))throw new globalThis.RangeError(`Expected a finite number, got ${P(X)}`);return X}var sE=sQ({order:L1,annotate:(X)=>({representation:{id:"effect/schema/isGreaterThan",payload:{exclusiveMinimum:b9(X)}},toJsonSchema:()=>({exclusiveMinimum:X}),toCode:()=>({runtime:`Schema.isGreaterThan(${P(X)})`})})}),H10=s("effect/schema/isGreaterThan",h({exclusiveMinimum:Q6}),({annotations:X,payload:Y})=>sE(Y.exclusiveMinimum,X)),XU=aQ({order:L1,annotate:(X)=>({representation:{id:"effect/schema/isGreaterThanOrEqualTo",payload:{minimum:b9(X)}},toJsonSchema:()=>({minimum:X}),toCode:()=>({runtime:`Schema.isGreaterThanOrEqualTo(${P(X)})`})})}),W10=s("effect/schema/isGreaterThanOrEqualTo",h({minimum:Q6}),({annotations:X,payload:Y})=>XU(Y.minimum,X)),aE=tQ({order:L1,annotate:(X)=>({representation:{id:"effect/schema/isLessThan",payload:{exclusiveMaximum:b9(X)}},toJsonSchema:()=>({exclusiveMaximum:X}),toCode:()=>({runtime:`Schema.isLessThan(${P(X)})`})})}),U10=s("effect/schema/isLessThan",h({exclusiveMaximum:Q6}),({annotations:X,payload:Y})=>aE(Y.exclusiveMaximum,X)),tE=eQ({order:L1,annotate:(X)=>({representation:{id:"effect/schema/isLessThanOrEqualTo",payload:{maximum:b9(X)}},toJsonSchema:()=>({maximum:X}),toCode:()=>({runtime:`Schema.isLessThanOrEqualTo(${P(X)})`})})}),D10=s("effect/schema/isLessThanOrEqualTo",h({maximum:Q6}),({annotations:X,payload:Y})=>tE(Y.maximum,X)),s$=X7({order:L1,annotate:(X)=>{let Y=X.exclusiveMinimum?!0:void 0,Q=X.exclusiveMaximum?!0:void 0;return{representation:{id:"effect/schema/isBetween",payload:{minimum:b9(X.minimum),maximum:b9(X.maximum),...Y&&{exclusiveMinimum:Y},...Q&&{exclusiveMaximum:Q}}},toJsonSchema:()=>({[Y?"exclusiveMinimum":"minimum"]:X.minimum,[Q?"exclusiveMaximum":"maximum"]:X.maximum}),toCode:()=>({runtime:`Schema.isBetween({ minimum: ${P(X.minimum)}, maximum: ${P(X.maximum)}, exclusiveMinimum: ${P(Y)}, exclusiveMaximum: ${P(Q)} })`})}}}),N10=s("effect/schema/isBetween",h({minimum:Q6,maximum:Q6,exclusiveMinimum:xX(c0(!0)),exclusiveMaximum:xX(c0(!0))}),({annotations:X,payload:Y})=>s$(Y,X)),eE=nE({remainder:wq,zero:0,annotate:(X)=>({expected:`a value that is a multiple of ${X}`,representation:{id:"effect/schema/isMultipleOf",payload:{divisor:X}},toJsonSchema:()=>({multipleOf:X}),toCode:()=>({runtime:`Schema.isMultipleOf(${P(X)})`})})}),B10=s("effect/schema/isMultipleOf",h({divisor:Q6}),({annotations:X,payload:Y})=>eE(Y.divisor,X));function Y7(X){return j0((Y)=>globalThis.Number.isSafeInteger(Y),{expected:"an integer",representation:{id:"effect/schema/isInt",payload:null},toJsonSchema:()=>({type:"integer"}),toCode:()=>({runtime:"Schema.isInt()"}),arbitrary:{constraint:{integer:!0}},...X})}var V10=s("effect/schema/isInt",T0,({annotations:X})=>Y7(X)),q5=o$.check(Y7()),zX=q5.check(XU(0));function z10(X){return new n8([Y7(),s$({minimum:-2147483648,maximum:2147483647})],{expected:"a 32-bit integer",...X})}function q10(X){return new n8([Y7(),s$({minimum:0,maximum:4294967295})],{expected:"a 32-bit unsigned integer",...X})}function g9(X){if(globalThis.Number.isNaN(X.getTime()))throw new globalThis.RangeError(`Expected a valid Date, got ${P(X)}`);return X.toISOString()}function y9(X){return`new Date(${P(X.getTime())})`}var XM=sQ({order:E4,annotate:(X)=>{return{representation:{id:"effect/schema/isGreaterThanDate",payload:{exclusiveMinimum:g9(X)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isGreaterThanDate(${y9(X)})`})}}}),YM=aQ({order:E4,annotate:(X)=>{return{representation:{id:"effect/schema/isGreaterThanOrEqualToDate",payload:{minimum:g9(X)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isGreaterThanOrEqualToDate(${y9(X)})`})}}}),QM=tQ({order:E4,annotate:(X)=>{return{representation:{id:"effect/schema/isLessThanDate",payload:{exclusiveMaximum:g9(X)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isLessThanDate(${y9(X)})`})}}}),JM=eQ({order:E4,annotate:(X)=>{return{representation:{id:"effect/schema/isLessThanOrEqualToDate",payload:{maximum:g9(X)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isLessThanOrEqualToDate(${y9(X)})`})}}}),$M=X7({order:E4,annotate:(X)=>{let Y=X.exclusiveMinimum?!0:void 0,Q=X.exclusiveMaximum?!0:void 0;return{representation:{id:"effect/schema/isBetweenDate",payload:{minimum:g9(X.minimum),maximum:g9(X.maximum),...Y&&{exclusiveMinimum:Y},...Q&&{exclusiveMaximum:Q}}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isBetweenDate({ minimum: ${y9(X.minimum)}, maximum: ${y9(X.maximum)}, exclusiveMinimum: ${P(Y)}, exclusiveMaximum: ${P(Q)} })`})}}}),GM=sQ({order:AX,annotate:(X)=>{return{representation:{id:"effect/schema/isGreaterThanBigInt",payload:{exclusiveMinimum:X.toString(10)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isGreaterThanBigInt(${P(X)})`})}}}),ZM=aQ({order:AX,annotate:(X)=>{return{representation:{id:"effect/schema/isGreaterThanOrEqualToBigInt",payload:{minimum:X.toString(10)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isGreaterThanOrEqualToBigInt(${P(X)})`})}}}),_M=tQ({order:AX,annotate:(X)=>{return{representation:{id:"effect/schema/isLessThanBigInt",payload:{exclusiveMaximum:X.toString(10)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isLessThanBigInt(${P(X)})`})}}}),KM=eQ({order:AX,annotate:(X)=>{return{representation:{id:"effect/schema/isLessThanOrEqualToBigInt",payload:{maximum:X.toString(10)}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isLessThanOrEqualToBigInt(${P(X)})`})}}}),HM=X7({order:AX,annotate:(X)=>{let Y=X.exclusiveMinimum?!0:void 0,Q=X.exclusiveMaximum?!0:void 0;return{representation:{id:"effect/schema/isBetweenBigInt",payload:{minimum:X.minimum.toString(10),maximum:X.maximum.toString(10),...Y&&{exclusiveMinimum:Y},...Q&&{exclusiveMaximum:Q}}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isBetweenBigInt({ minimum: ${P(X.minimum)}, maximum: ${P(X.maximum)}, exclusiveMinimum: ${P(Y)}, exclusiveMaximum: ${P(Q)} })`})}}}),L10=sQ({order:Z8,formatter:(X)=>A6(X)}),O10=aQ({order:Z8,formatter:(X)=>A6(X)}),T10=tQ({order:Z8,formatter:(X)=>A6(X)}),F10=eQ({order:Z8,formatter:(X)=>A6(X)}),R10=X7({order:Z8,formatter:(X)=>A6(X)});function YU(X,Y){return X=Math.max(0,Math.floor(X)),j0((Q)=>Q.length>=X,{expected:`a value with a length of at least ${X}`,representation:{id:"effect/schema/isMinLength",payload:{minLength:X}},toJsonSchema:({type:Q})=>Q==="array"?{minItems:X}:{minLength:X},toCode:()=>({runtime:`Schema.isMinLength(${X})`}),[XX]:!0,arbitrary:{constraint:{minLength:X}},...Y})}var A10=s("effect/schema/isMinLength",h({minLength:zX}),({annotations:X,payload:Y})=>YU(Y.minLength,X));function WM(X){return YU(1,X)}function UM(X,Y){return X=Math.max(0,Math.floor(X)),j0((Q)=>Q.length<=X,{expected:`a value with a length of at most ${X}`,representation:{id:"effect/schema/isMaxLength",payload:{maxLength:X}},toJsonSchema:({type:Q})=>Q==="array"?{maxItems:X}:{maxLength:X},toCode:()=>({runtime:`Schema.isMaxLength(${X})`}),[XX]:!0,arbitrary:{constraint:{maxLength:X}},...Y})}var P10=s("effect/schema/isMaxLength",h({maxLength:zX}),({annotations:X,payload:Y})=>UM(Y.maxLength,X));function QU(X,Y,Q){return X=Math.max(0,Math.floor(X)),Y=Math.max(0,Math.floor(Y)),j0((J)=>J.length>=X&&J.length<=Y,{expected:X===Y?`a value with a length of ${X}`:`a value with a length between ${X} and ${Y}`,representation:{id:"effect/schema/isLengthBetween",payload:{minimum:X,maximum:Y}},toJsonSchema:({type:J})=>J==="array"?{allOf:[{minItems:X},{maxItems:Y}]}:{allOf:[{minLength:X},{maxLength:Y}]},toCode:()=>({runtime:`Schema.isLengthBetween(${X}, ${Y})`}),[XX]:!0,arbitrary:{constraint:{minLength:X,maxLength:Y}},...Q})}var w10=s("effect/schema/isLengthBetween",h({minimum:zX,maximum:zX}),({annotations:X,payload:Y})=>QU(Y.minimum,Y.maximum,X));function DM(X,Y){return X=Math.max(0,Math.floor(X)),j0((Q)=>Q.size>=X,{expected:`a value with a size of at least ${X}`,representation:{id:"effect/schema/isMinSize",payload:{minSize:X}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isMinSize(${X})`}),[XX]:!0,arbitrary:{constraint:{minLength:X}},...Y})}var C10=s("effect/schema/isMinSize",h({minSize:zX}),({annotations:X,payload:Y})=>DM(Y.minSize,X));function NM(X,Y){return X=Math.max(0,Math.floor(X)),j0((Q)=>Q.size<=X,{expected:`a value with a size of at most ${X}`,representation:{id:"effect/schema/isMaxSize",payload:{maxSize:X}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isMaxSize(${X})`}),[XX]:!0,arbitrary:{constraint:{maxLength:X}},...Y})}var E10=s("effect/schema/isMaxSize",h({maxSize:zX}),({annotations:X,payload:Y})=>NM(Y.maxSize,X));function BM(X,Y,Q){return X=Math.max(0,Math.floor(X)),Y=Math.max(0,Math.floor(Y)),j0((J)=>J.size>=X&&J.size<=Y,{expected:X===Y?`a value with a size of ${X}`:`a value with a size between ${X} and ${Y}`,representation:{id:"effect/schema/isSizeBetween",payload:{minimum:X,maximum:Y}},toJsonSchema:()=>({}),toCode:()=>({runtime:`Schema.isSizeBetween(${X}, ${Y})`}),[XX]:!0,arbitrary:{constraint:{minLength:X,maxLength:Y}},...Q})}var M10=s("effect/schema/isSizeBetween",h({minimum:zX,maximum:zX}),({annotations:X,payload:Y})=>BM(Y.minimum,Y.maximum,X));function VM(X,Y){return X=Math.max(0,Math.floor(X)),j0((Q)=>Reflect.ownKeys(Q).length>=X,{expected:`a value with at least ${X===1?"1 entry":`${X} entries`}`,representation:{id:"effect/schema/isMinProperties",payload:{minProperties:X}},toJsonSchema:()=>({minProperties:X}),toCode:()=>({runtime:`Schema.isMinProperties(${X})`}),[XX]:!0,arbitrary:{constraint:{minLength:X}},...Y})}var j10=s("effect/schema/isMinProperties",h({minProperties:zX}),({annotations:X,payload:Y})=>VM(Y.minProperties,X));function zM(X,Y){return X=Math.max(0,Math.floor(X)),j0((Q)=>Reflect.ownKeys(Q).length<=X,{expected:`a value with at most ${X===1?"1 entry":`${X} entries`}`,representation:{id:"effect/schema/isMaxProperties",payload:{maxProperties:X}},toJsonSchema:()=>({maxProperties:X}),toCode:()=>({runtime:`Schema.isMaxProperties(${X})`}),[XX]:!0,arbitrary:{constraint:{maxLength:X}},...Y})}var I10=s("effect/schema/isMaxProperties",h({maxProperties:zX}),({annotations:X,payload:Y})=>zM(Y.maxProperties,X));function qM(X,Y,Q){return X=Math.max(0,Math.floor(X)),Y=Math.max(0,Math.floor(Y)),j0((J)=>Reflect.ownKeys(J).length>=X&&Reflect.ownKeys(J).length<=Y,{expected:X===Y?`a value with exactly ${X===1?"1 entry":`${X} entries`}`:`a value with between ${X} and ${Y} entries`,representation:{id:"effect/schema/isPropertiesLengthBetween",payload:{minimum:X,maximum:Y}},toJsonSchema:()=>({minProperties:X,maxProperties:Y}),toCode:()=>({runtime:`Schema.isPropertiesLengthBetween(${X}, ${Y})`}),[XX]:!0,arbitrary:{constraint:{minLength:X,maxLength:Y}},...Q})}var x10=s("effect/schema/isPropertiesLengthBetween",h({minimum:zX,maximum:zX}),({annotations:X,payload:Y})=>qM(Y.minimum,Y.maximum,X));function LM(X,Y){let Q=h9(X),J=bF(Q.ast);return j0(($,G,_)=>{let K=Reflect.ownKeys($),H=[];for(let W of K){let D=J(W,_);if(D!==void 0){if(H.push(new S0([W],D)),_.errors==="first")break}}if(B6(H))return new F0(G,T($),H);return!0},{expected:"an object with property names matching the schema",representation:{id:"effect/schema/isPropertyNames",payload:null,schemas:[Q.ast]},toJsonSchema:({schemas:$})=>({propertyNames:$[0]}),toCode:({schemas:$})=>({runtime:`Schema.isPropertyNames(${$[0].runtime})`}),[XX]:!0,...Y})}var S10=s("effect/schema/isPropertyNames",T0,({annotations:X,schemas:Y})=>LM(Y[0],X));function JU(X){return j0((Y)=>_3(Y).length===Y.length,{expected:"an array with unique items",representation:{id:"effect/schema/isUnique",payload:null},toJsonSchema:()=>({uniqueItems:!0}),toCode:()=>({runtime:"Schema.isUnique()"}),arbitrary:{constraint:{unique:!0}},...X})}var v10=s("effect/schema/isUnique",T0,({annotations:X})=>JU(X)),k10=r.check(WM()),b10=r.check(QU(1,1));function D4(X){let Y=qX()([X],([Q])=>(J,$,G)=>{if(r7(J)){if(P0(J))return pX;return B1(a0(Q)(J.value,G),{onSuccess:T,onFailure:(_)=>new F0($,T(J),[new S0(["value"],_)])})}return f(new r0($,T(J)))},{representation:{id:"effect/schema/Option",payload:null},toCode:({typeParameters:Q})=>({runtime:`Schema.Option(${Q[0].runtime})`,Type:`Option.Option<${Q[0].Type}>`,importDeclarations:['import * as Option from "effect/Option"']}),expected:"Option",toCodec:([Q])=>v0()(J1([h({_tag:c0("Some"),value:Q}),h({_tag:c0("None")})]),d0({decode:(J)=>J._tag==="None"?d():T(J.value),encode:(J)=>N1(J)?{_tag:"Some",value:J.value}:{_tag:"None"}})),toArbitrary:([Q])=>(J,$)=>{let G=J.constant(d()),_=J.oneof(G,Q.arbitrary.map(T));return m9(J,$,G,_)},toEquivalence:([Q])=>IN(Q),toFormatter:([Q])=>yX({onNone:()=>"none()",onSome:(J)=>`some(${Q(J)})`})});return v(Y.ast,{value:X})}var g10=JX("effect/schema/Option",T0,({annotations:X,typeParameters:Y})=>{let Q=D4(Y[0]);return X===void 0?Q:Q.annotate(X)});function y10(X){return iW(X).pipe(l(D4(u1(X)),RT()))}function h10(X){return r$(X).pipe(l(D4(u1(X)),AT()))}function m10(X,Y){return wE(X).pipe(l(D4(u1(X)),PT(Y)))}function f10(X){return W4(X).pipe(l(D4(u1(X)),wT()))}function d10(X){return xX(X).pipe(l(D4(u1(X)),CT()))}function p10(X,Y){let Q=Y===void 0?"omit":Y.onNoneEncoding,J=Q===null?null:void 0;return xX(iW(X)).pipe(l(D4(u1(X)),IJ({decode:($)=>$.pipe(k5(C7),T),encode:Q==="omit"?v5:($)=>T(n7(v5($),()=>J))})))}function OM(X,Y){let Q=qX()([X,Y],([J,$])=>(G,_,K)=>{if(!J3(G))return f(new r0(_,T(G)));switch(G._tag){case"Success":return B1(QH(J)(G.success,K),{onSuccess:m,onFailure:(H)=>new F0(_,T(G),[new S0(["success"],H)])});case"Failure":return B1(QH($)(G.failure,K),{onSuccess:c,onFailure:(H)=>new F0(_,T(G),[new S0(["failure"],H)])})}},{representation:{id:"effect/schema/Result",payload:null},toCode:({typeParameters:J})=>({runtime:`Schema.Result(${J[0].runtime}, ${J[1].runtime})`,Type:`Result.Result<${J[0].Type}, ${J[1].Type}>`,importDeclarations:['import * as Result from "effect/Result"']}),expected:"Result",toCodec:([J,$])=>v0()(J1([h({_tag:c0("Success"),success:J}),h({_tag:c0("Failure"),failure:$})]),d0({decode:(G)=>G._tag==="Success"?m(G.success):c(G.failure),encode:(G)=>Y1(G)?{_tag:"Success",success:G.success}:{_tag:"Failure",failure:G.failure}})),toArbitrary:([J,$])=>(G,_)=>{let K=IM(G,J.terminal?.map((W)=>m(W)),$.terminal?.map((W)=>c(W))),H=G.oneof(J.arbitrary.map((W)=>m(W)),$.arbitrary.map((W)=>c(W)));return m9(G,_,K,H)},toEquivalence:([J,$])=>PZ(J,$),toFormatter:([J,$])=>r1({onSuccess:(G)=>`success(${J(G)})`,onFailure:(G)=>`failure(${$(G)})`})});return v(Q.ast,{success:X,failure:Y})}var u10=JX("effect/schema/Result",T0,({annotations:X,typeParameters:Y})=>{let Q=OM(Y[0],Y[1]);return X===void 0?Q:Q.annotate(X)}),c10=SX((X)=>{if(!x1(X))return!1;let Y=globalThis.Object.keys(X);return Y.length>0&&Y.every((Q)=>{switch(Q){case"label":return typeof X[Q]==="string";case"disallowJsonEncode":return X[Q]===!0;default:return!1}})}),l10=J1([T0,c10]);function $U(X,Y){let Q=typeof Y?.label==="string"?Y.label:void 0,J=Y?.disallowJsonEncode===!0,$=Q!==void 0?J?{label:Q,disallowJsonEncode:!0}:{label:Q}:J?{disallowJsonEncode:!0}:void 0,G=Q!==void 0?a0(c0(Q)):void 0,_=qX()([X],([K])=>(H,W,D)=>{if(HK(H)){let U=G!==void 0?$9(G(H.label,D),(N)=>new S0(["label"],N)):uY;return wX(U,()=>B1(a0(K)(H9(H),D),{onSuccess:()=>H,onFailure:()=>{let N=T(H);return new F0(W,N,[new S0(["value"],new U0(N))])}}))}return f(new r0(W,T(H)))},{representation:{id:"effect/schema/Redacted",payload:$??null},toCode:({typeParameters:K})=>({runtime:$!==void 0?`Schema.Redacted(${K[0].runtime}, ${P($)})`:`Schema.Redacted(${K[0].runtime})`,Type:`Redacted.Redacted<${K[0].Type}>`,importDeclarations:['import * as Redacted from "effect/Redacted"']}),expected:"Redacted",toCodecJson:([K])=>v0()(GU(K),{decode:Q0((H)=>P6(H,{label:Q})),encode:J?VK((H)=>"Cannot serialize Redacted"+(N1(H)&&typeof H.value.label==="string"?` with label: "${H.value.label}"`:"")):Q0(H9)}),toArbitrary:([K])=>()=>({arbitrary:K.arbitrary.map((H)=>P6(H,{label:Q})),terminal:K.terminal?.map((H)=>P6(H,{label:Q}))}),toFormatter:()=>globalThis.String,toEquivalence:([K])=>gO(K)});return v(_.ast,{value:X})}var o10=JX("effect/schema/Redacted",l10,({annotations:X,payload:Y,typeParameters:Q})=>{let J=$U(Q[0],Y??void 0);return X===void 0?J:J.annotate(X)});function GU(X){return rW($9(TJ))(X)}function i10(X,Y){return GU(X).pipe(l($U(u1(X),{label:Y?.label,disallowJsonEncode:Y?.disallowEncode}),{decode:Q0((Q)=>P6(Q,{label:Y?.label})),encode:Y?.disallowEncode?VK((Q)=>"Cannot encode Redacted"+(N1(Q)&&typeof Q.value.label==="string"?` with label: "${Q.value.label}"`:"")):Q0(H9)}))}function f$(X,Y){let Q=qX()([X,Y],([J,$])=>(G,_,K)=>{if(!_q(G))return f(new r0(_,T(G)));switch(G._tag){case"Fail":return B1(a0(J)(G.error,K),{onSuccess:c3,onFailure:(H)=>new F0(_,T(G),[new S0(["error"],H)])});case"Die":return B1(a0($)(G.defect,K),{onSuccess:l3,onFailure:(H)=>new F0(_,T(G),[new S0(["defect"],H)])});case"Interrupt":return p(G)}},{representation:{id:"effect/schema/CauseReason",payload:null},toCode:({typeParameters:J})=>({runtime:`Schema.CauseReason(${J[0].runtime}, ${J[1].runtime})`,Type:`Cause.Failure<${J[0].Type}, ${J[1].Type}>`,importDeclarations:['import * as Cause from "effect/Cause"']}),expected:"Cause.Failure",toCodec:([J,$])=>v0()(J1([h({_tag:c0("Fail"),error:J}),h({_tag:c0("Die"),defect:$}),h({_tag:c0("Interrupt"),fiberId:r$(Q6)})]),d0({decode:(G)=>{switch(G._tag){case"Fail":return c3(G.error);case"Die":return l3(G.defect);case"Interrupt":return o3(G.fiberId)}},encode:u})),toArbitrary:([J,$])=>TM(J,$),toEquivalence:([J,$])=>FM(J,$),toFormatter:([J,$])=>RM(J,$)});return v(Q.ast,{error:X,defect:Y})}var r10=JX("effect/schema/CauseReason",T0,({annotations:X,typeParameters:Y})=>{let Q=f$(Y[0],Y[1]);return X===void 0?Q:Q.annotate(X)});function TM(X,Y){return(Q,J)=>{let $=Q.constant(o3()),G=Q.oneof($,Q.integer({min:1}).map(o3),X.arbitrary.map((_)=>c3(_)),Y.arbitrary.map((_)=>l3(_)));return m9(Q,J,$,G)}}function FM(X,Y){return(Q,J)=>{if(Q._tag!==J._tag)return!1;switch(Q._tag){case"Fail":return X(Q.error,J.error);case"Die":return Y(Q.defect,J.defect);case"Interrupt":return Q.fiberId===J.fiberId}}}function RM(X,Y){return(Q)=>{switch(Q._tag){case"Fail":return`Fail(${X(Q.error)})`;case"Die":return`Die(${Y(Q.defect)})`;case"Interrupt":return"Interrupt"}}}function d$(X,Y){let Q=qX()([X,Y],([J,$])=>{let G=Q1(f$(J,$));return(_,K,H)=>{if(!Zq(_))return f(new r0(K,T(_)));return B1(a0(G)(_.reasons,H),{onSuccess:u3,onFailure:(W)=>new F0(K,T(_),[new S0(["failures"],W)])})}},{representation:{id:"effect/schema/Cause",payload:null},toCode:({typeParameters:J})=>({runtime:`Schema.Cause(${J[0].runtime}, ${J[1].runtime})`,Type:`Cause.Cause<${J[0].Type}, ${J[1].Type}>`,importDeclarations:['import * as Cause from "effect/Cause"']}),expected:"Cause",toCodec:([J,$])=>v0()(Q1(f$(J,$)),d0({decode:u3,encode:({reasons:G})=>G})),toArbitrary:([J,$])=>AM(J,$),toEquivalence:([J,$])=>PM(J,$),toFormatter:([J,$])=>wM(J,$)});return v(Q.ast,{error:X,defect:Y})}var n10=JX("effect/schema/Cause",T0,({annotations:X,typeParameters:Y})=>{let Q=d$(Y[0],Y[1]);return X===void 0?Q:Q.annotate(X)});function AM(X,Y){return(Q,J)=>{let $=TM(X,Y)(Q,J),G=Q.constant(Kq),_=Q.array($.arbitrary).map(u3);return m9(Q,J,G,_)}}function PM(X,Y){let Q=LN(FM(X,Y));return(J,$)=>Q(J.reasons,$.reasons)}function wM(X,Y){let Q=RM(X,Y);return(J)=>`Cause([${J.reasons.map(Q).join(", ")}])`}var s10=SX((X)=>{if(!x1(X))return!1;let Y=globalThis.Object.keys(X);return Y.length>0&&Y.every((Q)=>(Q==="includeStack"||Q==="excludeCause")&&X[Q]===!0)}),a10=J1([T0,s10]),CM=(X)=>(X?.includeStack===!0?1:0)|(X?.excludeCause===!0?2:0),EM=(X)=>{switch(X){case 0:return;case 1:return{includeStack:!0};case 2:return{excludeCause:!0};case 3:return{includeStack:!0,excludeCause:!0}}},XE=[];function MM(X){let Y=CM(X),Q=XE[Y];if(Q!==void 0)return Q;let J=EM(Y),$=U4(globalThis.Error,{representation:{id:"effect/schema/Error",payload:J??null},toCode:()=>({runtime:J!==void 0?`Schema.Error(${P(J)})`:"Schema.Error()",Type:"globalThis.Error"}),expected:"Error",toCodecJson:()=>v0()(p60,TT(J)),toArbitrary:()=>(G)=>G.string().map((_)=>new globalThis.Error(_))});return XE[Y]=$,$}var t10=JX("effect/schema/Error",a10,({annotations:X,payload:Y})=>{let Q=MM(Y??void 0);return X===void 0?Q:Q.annotate(X)}),YE=[];function e10(X){let Y=CM(X),Q=YE[Y];if(Q!==void 0)return Q;let J=e$.pipe(l(cW,FT(EM(Y))));return YE[Y]=J,J}function jM(X,Y,Q){let J=qX()([X,Y,Q],([$,G,_])=>{let K=d$(G,_);return(H,W,D)=>{if(!bz(H))return f(new r0(W,T(H)));switch(H._tag){case"Success":return B1(a0($)(H.value,D),{onSuccess:n5,onFailure:(U)=>new F0(W,T(H),[new S0(["value"],U)])});case"Failure":return B1(a0(K)(H.cause,D),{onSuccess:m8,onFailure:(U)=>new F0(W,T(H),[new S0(["cause"],U)])})}}},{representation:{id:"effect/schema/Exit",payload:null},toCode:({typeParameters:$})=>({runtime:`Schema.Exit(${$[0].runtime}, ${$[1].runtime}, ${$[2].runtime})`,Type:`Exit.Exit<${$[0].Type}, ${$[1].Type}, ${$[2].Type}>`,importDeclarations:['import * as Exit from "effect/Exit"']}),expected:"Exit",toCodec:([$,G,_])=>v0()(J1([h({_tag:c0("Success"),value:$}),h({_tag:c0("Failure"),cause:d$(G,_)})]),d0({decode:(K)=>K._tag==="Success"?n5(K.value):m8(K.cause),encode:(K)=>M1(K)?{_tag:"Success",value:K.value}:{_tag:"Failure",cause:K.cause}})),toArbitrary:([$,G,_])=>(K,H)=>{let W=AM(G,_)(K,H),D=IM(K,$.terminal?.map((N)=>n5(N)),W.terminal?.map((N)=>m8(N))),U=K.oneof($.arbitrary.map((N)=>n5(N)),W.arbitrary.map((N)=>m8(N)));return m9(K,H,D,U)},toEquivalence:([$,G,_])=>{let K=PM(G,_);return(H,W)=>{if(H._tag!==W._tag)return!1;switch(H._tag){case"Success":return $(H.value,W.value);case"Failure":return K(H.cause,W.cause)}}},toFormatter:([$,G,_])=>{let K=wM(G,_);return(H)=>{switch(H._tag){case"Success":return`Exit.Success(${$(H.value)})`;case"Failure":return`Exit.Failure(${K(H.cause)})`}}}});return v(J.ast,{value:X,error:Y,defect:Q})}var XX0=JX("effect/schema/Exit",T0,({annotations:X,typeParameters:Y})=>{let Q=jM(Y[0],Y[1],Y[2]);return X===void 0?Q:Q.annotate(X)});function IM(X,Y,Q){return Y===void 0?Q:Q===void 0?Y:X.oneof(Y,Q)}function m9(X,Y,Q,J){return{arbitrary:Q===void 0||Y.recursion===void 0?J:X.oneof(Y.recursion,Q,J),terminal:Q}}function QE(X,Y,Q,J){return J===void 0?X.array(Y,Q):X.uniqueArray(Y,{...Q,comparator:J})}function a$(X,Y,Q,J,$,G){let _=Y.constraint,K=_===void 0||_.minLength===void 0&&_.maxLength===void 0?void 0:{..._.minLength!==void 0?{minLength:_.minLength}:{},..._.maxLength!==void 0?{maxLength:_.maxLength}:{}};if(K?.minLength!==void 0&&K.maxLength!==void 0&&K.minLength>K.maxLength)throw new globalThis.Error("Unable to derive an arbitrary for size constraints");let H=K?.minLength??0,W=H===0?X.constant([]):J===void 0?void 0:QE(X,J,{...K,maxLength:H},G),D=m9(X,Y,W,QE(X,Q,K,G));return{arbitrary:D.arbitrary.map($),terminal:D.terminal?.map($)}}function xM(X,Y,Q,J,$){return a$(X,Y,X.tuple(Q.arbitrary,J.arbitrary),Q.terminal===void 0||J.terminal===void 0?void 0:X.tuple(Q.terminal,J.terminal),$,([G],[_])=>o(G,_))}function SM(X,Y){let Q=qX()([X,Y],([J,$])=>{let G=Q1(k9([J,$]));return(_,K,H)=>{if(_ instanceof globalThis.Map)return B1(a0(G)([..._],H),{onSuccess:(W)=>new globalThis.Map(W),onFailure:(W)=>new F0(K,T(_),[new S0(["entries"],W)])});return f(new r0(K,T(_)))}},{representation:{id:"effect/schema/ReadonlyMap",payload:null},toCode:({typeParameters:J})=>({runtime:`Schema.ReadonlyMap(${J[0].runtime}, ${J[1].runtime})`,Type:`globalThis.ReadonlyMap<${J[0].Type}, ${J[1].Type}>`}),expected:"ReadonlyMap",toCodec:([J,$])=>v0()(Q1(k9([J,$])),d0({decode:(G)=>new globalThis.Map(G),encode:(G)=>[...G.entries()]})),toArbitrary:([J,$])=>(G,_)=>xM(G,_,J,$,(K)=>new globalThis.Map(K)),toEquivalence:([J,$])=>I7(J,$),toFormatter:([J,$])=>(G)=>{let _=G.size;if(_===0)return"ReadonlyMap(0) {}";let K=globalThis.Array.from(G.entries()).sort().map(([H,W])=>`${J(H)} => ${$(W)}`);return`ReadonlyMap(${_}) { ${K.join(", ")} }`}});return v(Q.ast,{key:X,value:Y})}var YX0=JX("effect/schema/ReadonlyMap",T0,({annotations:X,typeParameters:Y})=>{let Q=SM(Y[0],Y[1]);return X===void 0?Q:Q.annotate(X)});function vM(X,Y){let Q=qX()([X,Y],([J,$])=>{let G=Q1(k9([J,$]));return(_,K,H)=>{if(g_(_))return B1(a0(G)(eY(_),H),{onSuccess:tY,onFailure:(W)=>new F0(K,T(_),[new S0(["entries"],W)])});return f(new r0(K,T(_)))}},{representation:{id:"effect/schema/HashMap",payload:null},toCode:({typeParameters:J})=>({runtime:`Schema.HashMap(${J[0].runtime}, ${J[1].runtime})`,Type:`HashMap.HashMap<${J[0].Type}, ${J[1].Type}>`,importDeclarations:['import * as HashMap from "effect/HashMap"']}),expected:"HashMap",toCodec:([J,$])=>v0()(Q1(k9([J,$])),d0({decode:tY,encode:eY})),toArbitrary:([J,$])=>(G,_)=>xM(G,_,J,$,tY),toEquivalence:([J,$])=>I7(J,$),toFormatter:([J,$])=>(G)=>{let _=y_(G);if(_===0)return"HashMap(0) {}";let K=eY(G).sort().map(([H,W])=>`${J(H)} => ${$(W)}`);return`HashMap(${_}) { ${K.join(", ")} }`}});return v(Q.ast,{key:X,value:Y})}var QX0=JX("effect/schema/HashMap",T0,({annotations:X,typeParameters:Y})=>{let Q=vM(Y[0],Y[1]);return X===void 0?Q:Q.annotate(X)});function kM(X){let Y=qX()([X],([Q])=>{let J=Q1(Q);return($,G,_)=>{if($ instanceof globalThis.Set)return B1(a0(J)([...$],_),{onSuccess:(K)=>new globalThis.Set(K),onFailure:(K)=>new F0(G,T($),[new S0(["values"],K)])});return f(new r0(G,T($)))}},{representation:{id:"effect/schema/ReadonlySet",payload:null},toCode:({typeParameters:Q})=>({runtime:`Schema.ReadonlySet(${Q[0].runtime})`,Type:`globalThis.ReadonlySet<${Q[0].Type}>`}),expected:"ReadonlySet",toCodec:([Q])=>v0()(Q1(Q),d0({decode:(J)=>new globalThis.Set(J),encode:(J)=>[...J.values()]})),toArbitrary:([Q])=>(J,$)=>a$(J,$,Q.arbitrary,Q.terminal,(G)=>new globalThis.Set(G),o),toEquivalence:([Q])=>x7(Q),toFormatter:([Q])=>(J)=>{let $=J.size;if($===0)return"ReadonlySet(0) {}";let G=globalThis.Array.from(J.values()).sort().map((_)=>`${Q(_)}`);return`ReadonlySet(${$}) { ${G.join(", ")} }`}});return v(Y.ast,{value:X})}var JX0=JX("effect/schema/ReadonlySet",T0,({annotations:X,typeParameters:Y})=>{let Q=kM(Y[0]);return X===void 0?Q:Q.annotate(X)});function bM(X){let Y=qX()([X],([Q])=>{let J=Q1(Q);return($,G,_)=>{if(d_($))return B1(a0(J)(C1($),_),{onSuccess:QQ,onFailure:(K)=>new F0(G,T($),[new S0(["values"],K)])});return f(new r0(G,T($)))}},{representation:{id:"effect/schema/HashSet",payload:null},toCode:({typeParameters:Q})=>({runtime:`Schema.HashSet(${Q[0].runtime})`,Type:`HashSet.HashSet<${Q[0].Type}>`}),expected:"HashSet",toCodec:([Q])=>v0()(Q1(Q),d0({decode:QQ,encode:C1})),toArbitrary:([Q])=>(J,$)=>a$(J,$,Q.arbitrary,Q.terminal,QQ,o),toEquivalence:([Q])=>x7(Q),toFormatter:([Q])=>(J)=>{let $=p_(J);if($===0)return"HashSet(0) {}";let G=globalThis.Array.from(J).sort().map((_)=>`${Q(_)}`);return`HashSet(${$}) { ${G.join(", ")} }`}});return v(Y.ast,{value:X})}var $X0=JX("effect/schema/HashSet",T0,({annotations:X,typeParameters:Y})=>{let Q=bM(Y[0]);return X===void 0?Q:Q.annotate(X)});function gM(X){let Y=qX()([X],([Q])=>{let J=Q1(Q);return($,G,_)=>{if(WJ($))return B1(a0(J)(C1($),_),{onSuccess:UJ,onFailure:(K)=>new F0(G,T($),[new S0(["values"],K)])});return f(new r0(G,T($)))}},{representation:{id:"effect/schema/Chunk",payload:null},toCode:({typeParameters:Q})=>({runtime:`Schema.Chunk(${Q[0].runtime})`,Type:`Chunk.Chunk<${Q[0].Type}>`}),expected:"Chunk",toCodec:([Q])=>v0()(Q1(Q),d0({decode:UJ,encode:C1})),toArbitrary:([Q])=>(J,$)=>a$(J,$,Q.arbitrary,Q.terminal,UJ),toEquivalence:([Q])=>s_(Q),toFormatter:([Q])=>(J)=>{let $=ZO(J);if($===0)return"Chunk(0) {}";let G=globalThis.Array.from(J).sort().map((_)=>`${Q(_)}`);return`Chunk(${$}) { ${G.join(", ")} }`}});return v(Y.ast,{value:X})}var GX0=JX("effect/schema/Chunk",T0,({annotations:X,typeParameters:Y})=>{let Q=gM(Y[0]);return X===void 0?Q:Q.annotate(X)}),yM=U4(globalThis.RegExp,{representation:{id:"effect/schema/RegExp",payload:null},toCode:()=>({runtime:"Schema.RegExp",Type:"globalThis.RegExp"}),expected:"RegExp",toCodecJson:()=>v0()(h({source:r,flags:r}),EX({decode:(X)=>J9({try:()=>new globalThis.RegExp(X.source,X.flags),catch:(Y)=>new U0(T(Y),{message:globalThis.String(Y)})}),encode:(X)=>p({source:X.source,flags:X.flags})})),toArbitrary:()=>(X)=>X.tuple(X.constantFrom(".",".*","\\d+","\\w+","[a-z]+","[A-Z]+","[0-9]+","^[a-zA-Z0-9]+$","^\\d{4}-\\d{2}-\\d{2}$"),X.uniqueArray(X.constantFrom("g","i","m","s","u","y"),{minLength:0,maxLength:6}).map((Y)=>Y.join(""))).map(([Y,Q])=>new globalThis.RegExp(Y,Q)),toEquivalence:()=>(X,Y)=>X.source===Y.source&&X.flags===Y.flags}),ZX0=I1("effect/schema/RegExp",yM),hM=r.annotate({expected:"a string that will be decoded as a URL"}),ZU=U4(globalThis.URL,{representation:{id:"effect/schema/URL",payload:null},toCode:()=>({runtime:"Schema.URL",Type:"globalThis.URL"}),expected:"URL",toCodecJson:()=>v0()(hM,AK),toArbitrary:()=>(X)=>X.webUrl().map((Y)=>new globalThis.URL(Y)),toEquivalence:()=>(X,Y)=>X.toString()===Y.toString()}),_X0=I1("effect/schema/URL",ZU),KX0=hM.pipe(l(ZU,AK));function _U(X,Y,Q){let J={...Y};if(X?.minimum!==void 0){let $=Q===void 0?X.minimum:Q(X.minimum),G=X.exclusiveMinimum?new globalThis.Date($.getTime()+1):$;if(J.min===void 0||G.getTime()>J.min.getTime())J.min=G}if(X?.maximum!==void 0){let $=Q===void 0?X.maximum:Q(X.maximum),G=X.exclusiveMaximum?new globalThis.Date($.getTime()-1):$;if(J.max===void 0||G.getTime()<J.max.getTime())J.max=G}return J}var mM=r.annotate({expected:"a string that will be decoded as a Date"}),J6=SX((X)=>X instanceof globalThis.Date&&!globalThis.Number.isNaN(X.getTime()),{representation:{id:"effect/schema/Date",payload:null},toCode:()=>({runtime:"Schema.Date",Type:"globalThis.Date"}),expected:"a valid Date",toCodecJson:()=>v0()(mM,RK),toArbitrary:()=>(X,Y)=>X.date(_U(Y?.constraint?.ordered?.order===E4?Y.constraint.ordered:void 0,{noInvalidDate:!0}))}),HX0=I1("effect/schema/Date",J6),WX0=mM.pipe(l(J6,RK)),UX0=q5.pipe(l(J6,NT)),Q7=SX(TZ,{representation:{id:"effect/schema/Duration",payload:null},toCode:()=>({runtime:"Schema.Duration",Type:"Duration.Duration",importDeclarations:['import * as Duration from "effect/Duration"']}),expected:"Duration",toCodecJson:()=>v0()(J1([h({_tag:c0("Infinity")}),h({_tag:c0("NegativeInfinity")}),h({_tag:c0("Nanos"),value:j6}),h({_tag:c0("Millis"),value:q5})]),d0({decode:(X)=>{switch(X._tag){case"Infinity":return n6;case"NegativeInfinity":return I4;case"Nanos":return N6(X.value);case"Millis":return I8(X.value)}},encode:(X)=>{switch(X.value._tag){case"Infinity":return{_tag:"Infinity"};case"NegativeInfinity":return{_tag:"NegativeInfinity"};case"Nanos":return{_tag:"Nanos",value:X.value.nanos};case"Millis":return{_tag:"Millis",value:X.value.millis}}}})),toArbitrary:()=>(X)=>X.oneof(X.constant(n6),X.constant(I4),X.bigInt().map(N6),X.maxSafeInteger().map(I8)),toFormatter:()=>globalThis.String,toEquivalence:()=>FZ}),DX0=I1("effect/schema/Duration",Q7),NX0=r.annotate({expected:"a string that will be decoded as a Duration"}),BX0=NX0.pipe(l(Q7,BT)),VX0=j6.pipe(l(Q7,VT)),zX0=o$.pipe(l(Q7,zT)),fM=r.annotate({expected:"a string that will be decoded as a BigDecimal"}),dM=20,pM="Unable to derive an arbitrary for the ordered BigDecimal constraints";function p$(X,Y){return l8(X,Y).value}function qX0(X,Y,Q){return Q?p$(r_(X,Y),Y)+globalThis.BigInt(1):p$(i_(X,Y),Y)}function LX0(X,Y,Q){return Q?p$(i_(X,Y),Y)-globalThis.BigInt(1):p$(r_(X,Y),Y)}function OX0(X){return Math.max(dM,X.minimum?.scale??0,X.maximum?.scale??0,X.exclusiveMinimum&&X.minimum!==void 0?X.minimum.scale+1:0,X.exclusiveMaximum&&X.maximum!==void 0?X.maximum.scale+1:0)}function pW(X,Y){let Q={};if(X.minimum!==void 0)Q.min=qX0(X.minimum,Y,X.exclusiveMinimum===!0);if(X.maximum!==void 0)Q.max=LX0(X.maximum,Y,X.exclusiveMaximum===!0);if(Q.min!==void 0&&Q.max!==void 0&&Q.min>Q.max)return;return Q}function TX0(X){let Y=OX0(X);if(pW(X,Y)===void 0)throw new globalThis.Error(pM);let Q=0,J=Y;while(Q<J){let $=Q+Math.floor((J-Q)/2);if(pW(X,$)===void 0)Q=$+1;else J=$}return{min:Q,max:Y}}var KU=SX(HJ,{representation:{id:"effect/schema/BigDecimal",payload:null},toCode:()=>({runtime:"Schema.BigDecimal",Type:"BigDecimal.BigDecimal",importDeclarations:['import * as BigDecimal from "effect/BigDecimal"']}),expected:"BigDecimal",toCodecJson:()=>v0()(fM,PK),toArbitrary:()=>(X,Y)=>{let Q=Y.constraint?.ordered?.order===Z8?Y.constraint.ordered:void 0;if(Q===void 0)return X.tuple(X.bigInt(),X.integer({min:0,max:dM})).map(([J,$])=>e1(J,$));return X.integer(TX0(Q)).chain((J)=>{let $=pW(Q,J);if($===void 0)throw new globalThis.Error(pM);return X.bigInt($).map((G)=>e1(G,J))})},toFormatter:()=>(X)=>A6(X),toEquivalence:()=>l_}),FX0=I1("effect/schema/BigDecimal",KU),RX0=fM.pipe(l(KU,PK)),AX0=r.annotate({expected:"a string that will be decoded as JSON",contentMediaType:"application/json"}),PX0=uM(cW);function uM(X){return AX0.pipe(l(X,xT))}var HU=U4(globalThis.File,{representation:{id:"effect/schema/File",payload:null},toCode:()=>({runtime:"Schema.File",Type:"globalThis.File"}),expected:"File",toCodecJson:()=>v0()(h({data:r.check(eW()),type:r,name:r,lastModified:q5}),EX({decode:(X)=>r1(K9(X.data),{onFailure:(Y)=>f(new U0(T(X.data),{message:Y.message})),onSuccess:(Y)=>{let Q=new globalThis.Uint8Array(Y);return p(new globalThis.File([Q],X.name,{type:X.type,lastModified:X.lastModified}))}}),encode:(X)=>T_({try:async()=>{let Y=new globalThis.Uint8Array(await X.arrayBuffer());return{data:qJ(Y),type:X.type,name:X.name,lastModified:X.lastModified}},catch:(Y)=>new U0(T(X),{message:globalThis.String(Y)})})}))}),wX0=I1("effect/schema/File",HU),WU=U4(globalThis.FormData,{representation:{id:"effect/schema/FormData",payload:null},toCode:()=>({runtime:"Schema.FormData",Type:"globalThis.FormData"}),expected:"FormData",toCodecJson:()=>v0()(Q1(k9([r,J1([h({_tag:V5("String"),value:r}),h({_tag:V5("File"),value:HU})])])),EX({decode:(X)=>{let Y=new globalThis.FormData;for(let[Q,J]of X)Y.append(Q,J.value);return p(Y)},encode:(X)=>{return p(globalThis.Array.from(X.entries()).map(([Y,Q])=>{if(typeof Q==="string")return[Y,{_tag:"String",value:Q}];else return[Y,{_tag:"File",value:Q}]}))}}))}),CX0=I1("effect/schema/FormData",WU);function EX0(X){return WU.pipe(l(X,ST))}var UU=U4(globalThis.URLSearchParams,{representation:{id:"effect/schema/URLSearchParams",payload:null},toCode:()=>({runtime:"Schema.URLSearchParams",Type:"globalThis.URLSearchParams"}),expected:"URLSearchParams",toCodecJson:()=>v0()(r.annotate({expected:"a query string that will be decoded as URLSearchParams"}),d0({decode:(X)=>new globalThis.URLSearchParams(X),encode:(X)=>X.toString()}))}),MX0=I1("effect/schema/URLSearchParams",UU);function jX0(X){return UU.pipe(l(X,vT))}var IX0=r.annotate({expected:"a string that will be decoded as a number"}).pipe(l(o$,N9)),xX0=r.annotate({expected:"a string that will be decoded as a finite number"}).pipe(l(Q6,N9)),SX0=v(aK).pipe(l(j6,xJ)),cM=r.check(tW()),vX0=r.annotate({expected:"a string that will be decoded as a trimmed string"}).pipe(l(cM,DT())),kX0=r.annotate({expected:"a base64 encoded string that will be decoded as a UTF-8 string"}).pipe(l(r,ET)),bX0=r.annotate({expected:"a base64 (URL) encoded string that will be decoded as a UTF-8 string"}).pipe(l(r,MT)),gX0=r.annotate({expected:"a hex encoded string that will be decoded as a UTF-8 string"}).pipe(l(r,jT)),yX0=r.annotate({expected:"a URI component encoded string that will be decoded as a UTF-8 string"}).pipe(l(r,IT)),uW=J1([Q6,FE,r]),hX0=h({issues:Q1(h({message:r,path:xX(Q1(J1([uW,h({key:uW})])))}))}),mX0=i$([0,1]).pipe(l(TE,d0({decode:(X)=>X===1,encode:(X)=>X?1:0}))),lM=r.annotate({expected:"a base64 encoded string that will be decoded as Uint8Array",format:"byte",contentEncoding:"base64"}),J7=U4(globalThis.Uint8Array,{representation:{id:"effect/schema/Uint8Array",payload:null},toCode:()=>({runtime:"Schema.Uint8Array",Type:"globalThis.Uint8Array"}),expected:"Uint8Array",toCodecJson:()=>v0()(lM,wK),toArbitrary:()=>(X)=>X.uint8Array()}),fX0=I1("effect/schema/Uint8Array",J7),dX0=lM.pipe(l(J7,wK)),pX0=r.annotate({expected:"a base64 (URL) encoded string that will be decoded as a Uint8Array"}).pipe(l(J7,{decode:XT(),encode:EJ()})),uX0=r.annotate({expected:"a hex encoded string that will be decoded as a Uint8Array"}).pipe(l(J7,{decode:QT(),encode:MJ()})),$7=SX((X)=>t_(X)&&WO(X),{representation:{id:"effect/schema/DateTimeUtc",payload:null},toCode:()=>({runtime:"Schema.DateTimeUtc",Type:"DateTime.Utc",importDeclarations:['import * as DateTime from "effect/DateTime"']}),expected:"DateTime.Utc",toCodecJson:()=>v0()(r,MK),toArbitrary:()=>(X,Y)=>X.date(_U(Y?.constraint?.ordered?.order===XK?Y.constraint.ordered:void 0,{noInvalidDate:!0},BJ)).map((Q)=>DO(Q)),toFormatter:()=>(X)=>X.toString(),toEquivalence:()=>e_}),cX0=I1("effect/schema/DateTimeUtc",$7),lX0=J6.pipe(l($7,{decode:TK(),encode:Q0(BJ)})),oX0=r.annotate({expected:"a string that will be decoded as a DateTime.Utc"}).pipe(l($7,MK)),iX0=q5.pipe(l($7,{decode:TK(),encode:Q0(qO)})),oM=SX(KO,{representation:{id:"effect/schema/TimeZoneOffset",payload:null},toCode:()=>({runtime:"Schema.TimeZoneOffset",Type:"DateTime.TimeZone.Offset",importDeclarations:['import * as DateTime from "effect/DateTime"']}),expected:"DateTime.TimeZone.Offset",toCodecJson:()=>v0()(q5,kT),toArbitrary:()=>(X)=>X.integer({min:-43200000,max:50400000}).map((Y)=>GQ(Y)),toFormatter:()=>(X)=>o8(X),toEquivalence:()=>(X,Y)=>X.offset===Y.offset}),rX0=I1("effect/schema/TimeZoneOffset",oM),iM=r.annotate({expected:"an IANA time zone identifier"}),DU=SX(HO,{representation:{id:"effect/schema/TimeZoneNamed",payload:null},toCode:()=>({runtime:"Schema.TimeZoneNamed",Type:"DateTime.TimeZone.Named",importDeclarations:['import * as DateTime from "effect/DateTime"']}),expected:"DateTime.TimeZone.Named",toCodecJson:()=>v0()(iM,CK),toArbitrary:()=>(X)=>X.constantFrom(...["UTC","Europe/London","America/New_York","Asia/Tokyo","Australia/Sydney"].map(YK)),toFormatter:()=>(X)=>o8(X),toEquivalence:()=>(X,Y)=>X.id===Y.id}),nX0=I1("effect/schema/TimeZoneNamed",DU),sX0=iM.pipe(l(DU,CK)),rM=r.annotate({expected:"a time zone string (IANA identifier or offset like +03:00)"}),NU=SX(_O,{representation:{id:"effect/schema/TimeZone",payload:null},toCode:()=>({runtime:"Schema.TimeZone",Type:"DateTime.TimeZone",importDeclarations:['import * as DateTime from "effect/DateTime"']}),expected:"DateTime.TimeZone",toCodecJson:()=>v0()(rM,EK),toArbitrary:()=>(X)=>X.oneof(X.integer({min:-43200000,max:50400000}).map((Y)=>GQ(Y)),X.constantFrom(...["UTC","Europe/London","America/New_York","Asia/Tokyo","Australia/Sydney"].map(YK))),toFormatter:()=>(X)=>o8(X),toEquivalence:()=>(X,Y)=>o8(X)===o8(Y)}),aX0=I1("effect/schema/TimeZone",NU),tX0=rM.pipe(l(NU,EK)),nM=r.annotate({expected:"a zoned DateTime string (e.g. 2024-01-01T00:00:00.000+00:00[Europe/London])"}),BU=SX((X)=>t_(X)&&UO(X),{representation:{id:"effect/schema/DateTimeZoned",payload:null},toCode:()=>({runtime:"Schema.DateTimeZoned",Type:"DateTime.Zoned",importDeclarations:['import * as DateTime from "effect/DateTime"']}),expected:"DateTime.Zoned",toCodecJson:()=>v0()(nM,jK),toArbitrary:()=>(X,Y)=>X.tuple(X.date(_U(Y?.constraint?.ordered?.order===XK?Y.constraint.ordered:void 0,{max:new globalThis.Date(8639999949600000),min:new globalThis.Date(-8639999949600000),noInvalidDate:!0},BJ)),X.constantFrom("UTC","Europe/London","America/New_York","Asia/Tokyo","Australia/Sydney")).map(([Q,J])=>NO(Q,{timeZone:J})),toFormatter:()=>(X)=>VJ(X),toEquivalence:()=>e_}),eX0=I1("effect/schema/DateTimeZoned",BU),X60=nM.pipe(l(BU,jK)),Y60=globalThis.Symbol.for("immer-draftable"),JE={};function VU(X,Y,Q,J,$){let G=J60(Q,Y,J),_=sM(Y),K=class extends X{constructor(...[H,W]){let U=W?.["~payload"],N=U?.token===JE?U.value:Q.make(H??{},W);super(N,{...W,disableChecks:!0,"~payload":{token:JE,value:N}})}static[rQ]=rQ;get[_](){return _}static[Y60]=!0;static identifier=Y;static fields=Q.fields;static get ast(){return G(this).ast}static pipe(){return G0(this,arguments)}static rebuild(H){return G(this).rebuild(H)}static make(H,W){return new this(H,W)}static makeOption(H,W){return eJ(G(this))(H??{},W)}static makeEffect(H,W){return G(this).makeEffect(H??{},W)}static annotate(H){return this.rebuild(w6(this.ast,H))}static annotateKey(H){return this.rebuild(wQ(this.ast,H))}static check(...H){return this.rebuild(rX(this.ast,H))}static extend(H){return(W,D)=>{let U=G7(W)?W:h(W),N={...Q.fields,...U.fields},B=mJ(N,Q.ast.checks,{identifier:H});return VU(this,H,oW(rX(B,U.ast.checks),N),D,$)}}static mapFields(H,W){return Q.mapFields(H,W)}};if($!==void 0)Object.assign(K.prototype,$(Y));return K}function Q60(X){return new q0(Q0((Y)=>new X(Y)),cX())}function sM(X){return`~effect/Schema/Class/${X}`}function J60(X,Y,Q){let J;return($)=>{if(J!==void 0)return J;let G=Q60($),_=v(new Z5([X.ast],()=>(K,H)=>{return K instanceof $||j(K,sM(Y))?p(K):f(new r0(H,T(K)))},{identifier:Y,[sJ]:([K])=>new p0(K,G),toCodec:([K])=>new p0(K.ast,G),toArbitrary:([K])=>()=>({arbitrary:K.arbitrary.map((H)=>new $(H)),terminal:K.terminal?.map((H)=>new $(H))}),toFormatter:([K])=>(H)=>`${$.identifier}(${K(H)})`,[KQ]:TQ(X.ast),...Q}));return J=l(_,G)(X)}}function G7(X){return l$(X)}var aM=(X)=>(Y,Q)=>{let J=G7(Y)?Y:h(Y);return VU(X3,X,J,Q,($)=>({toString(){return`${$}(${P({...this})})`}}))},$60=(X)=>{return(Y,Q,J)=>{let $=G7(Q)?Q.mapFields((G)=>({_tag:V5(Y),...G}),{unsafePreserveChecks:!0}):n$(Y,Q);return aM(X??Y)($,J)}},tM=(X)=>(Y,Q)=>{let J=G7(Y)?Y:h(Y);return VU(_Y,X,J,Q,(G)=>({name:G}))},G60=(X)=>{return(Y,Q,J)=>{let $=G7(Q)?Q.mapFields((G)=>({_tag:V5(Y),...G}),{unsafePreserveChecks:!0}):n$(Y,Q);return tM(X??Y)($,J)}};function eM(X){let Y=DH(X.ast);return(Q)=>Y(Q,{})}function Z60(X,Y){if(Y?.report===!0){let Q=DH(X.ast),J=UR();return zR(X.ast,J),{value:Q(m$,{}),report:DR(J)}}return eM(X)(m$)}function _60(X){return(Y)=>{return Y.annotate({toFormatter:X})}}function K60(X,Y){return Q(X.ast);function Q($){let G=H8($)?.toFormatter;if(typeof G==="function")return G($5($)?$.typeParameters.map(Q):[]);if(Y?.onBefore){let _=Y.onBefore($,Q);if(_!==void 0)return _}return J($)}function J($){switch($._tag){default:return P;case"Never":return()=>"never";case"Void":return()=>"void";case"Arrays":{let G=$.elements.map(Q),_=$.rest.map(Q);return(K)=>{let H=[],W=0;for(;W<G.length;W++)if(K.length<W+1){if(l0($.elements[W]))continue}else H.push(G[W](K[W]));if(_.length>0){let[D,...U]=_;for(;W<K.length-U.length;W++)H.push(D(K[W]));for(let N=0;N<U.length;N++)H.push(U[N](K[W+N]))}return"["+H.join(", ")+"]"}}case"Objects":{let G=$.propertySignatures.map((K)=>Q(K.type)),_=$.indexSignatures.map((K)=>Q(K.type));if($.propertySignatures.length===0&&$.indexSignatures.length===0)return P;return(K)=>{let H=[],W=new Set;for(let D=0;D<G.length;D++){let U=$.propertySignatures[D],N=U.name;if(W.add(N),l0(U.type)&&!Object.hasOwn(K,N))continue;H.push(`${m6(N)}: ${G[D](K[N])}`)}for(let D=0;D<_.length;D++){let U=z9(K,$.indexSignatures[D].parameter);for(let N of U){if(W.has(N))continue;W.add(N),H.push(`${m6(N)}: ${_[D](K[N])}`)}}return H.length>0?"{ "+H.join(", ")+" }":"{}"}}case"Union":{let G=T1($).types,_=(H)=>FQ(H,G),K=new Map(G.map((H,W)=>[H,[jQ(H),Q($.types[W])]]));return(H)=>{let W=_(H);for(let D=0;D<W.length;D++){let[U,N]=K.get(W[D]);if(U(H))return N(H)}return P(H)}}case"Suspend":{let G=_5(()=>Q($.thunk()));return(_)=>G()(_)}}}}function H60(X){return(Y)=>Y.annotate({toEquivalence:X})}function W60(X){return qR(X.ast)}function U60(X){return NH(X.ast)}function Xj(X,Y){let Q=NH(t$(X.ast));return RR(Q,Y)}function Yj(X){return v(t$(X.ast),{schema:X})}var D60=e8((X)=>{let Y=B60(X,t$),Q=X.context;if(Y===X||Q===void 0)return Y;return lJ(Y,zU(Q))}),t$=X1((X)=>{let Y=r8(X),Q=D60(X);if(Y===void 0||Q.encoding===void 0)return Q;let J=a8(Q);if(r8(J)!==void 0||LJ(J)===Y)return Q;let $=w6(J,{[_Q]:Y});return e8(()=>$)(Q)});function zU(X){return X.defaultValue===void 0?X:new oX(X.isOptional,X.isMutable,void 0,X.annotations)}function Qj(X){if(X.propertySignatures.some((Y)=>typeof Y.name!=="string"))throw new globalThis.Error("Objects property names must be strings",{cause:X})}function Jj(X){return(Y)=>{let Q=new Map;for(let G=0;G<Y.length;G++)Q.set(F1(Y[G]),G);let J=[...Y].sort((G,_)=>{G=F1(G),_=F1(_);let K=X(G),H=X(_);if(K!==H)return K-H;return Q.get(G)-Q.get(_)});if(!J.some((G,_)=>G!==Y[_]))return Y;return J}}var N60=Jj((X)=>{switch(X._tag){case"BigInt":case"Symbol":case"UniqueSymbol":return 0;default:return 1}});function B60(X,Y){switch(X._tag){case"Declaration":{let Q=X.annotations?.toCodecJson??X.annotations?.toCodec;if(!l1(Q))return R0(X,[eK]);let J=X.typeParameters.map((G)=>IQ(F1(G))),$=Q(J);return $===void 0?X:R0(X,[t8($,Y)])}case"Unknown":return R0(X,[eK]);case"ObjectKeyword":return R0(X,[SF]);case"Undefined":case"Void":case"Literal":case"Number":return X.toCodecJson();case"UniqueSymbol":case"Symbol":case"BigInt":return X.toCodecStringTree();case"Objects":return Qj(X),X.recur(Y,nJ);case"Union":{let Q=N60(X.types);if(Q!==X.types)return new QX(Q,X.mode,X.annotations,X.checks,X.encoding,X.context,X.encodingChecks).recur(Y);return X.recur(Y)}case"Arrays":case"Suspend":return X.recur(Y)}return X}function $j(X){return v(Gj(T1(X.ast)))}var Gj=X1((X)=>{let Y=V60(X,Gj);return Y!==X&&X.context!==void 0?lJ(Y,zU(X.context)):Y});function V60(X,Y){switch(X._tag){case"Declaration":{let Q=X.annotations?.toCodecIso??X.annotations?.toCodec;if(l1(Q)){let J=Q(X.typeParameters.map(($)=>IQ($)));return R0(X,[t8(J,Y)])}return X}case"Arrays":case"Objects":case"Union":case"Suspend":return X.recur(Y)}return X}function Zj(X){return v(Hj(X.ast),{schema:X})}function z60(X){return v(Wj(X.ast))}function q60(X,Y){let Q=r8(X.ast)??KK(X.ast),J=BE(Zj(X));return($)=>J($).pipe(A_((G)=>L60(G,{rootName:Q,...Y})))}function L60(X,Y){let Q=Y.rootName??"root",J=Y.arrayItemName??"item",$=Y.pretty??!0,G=Y.indent??"  ",_=Y.sortKeys??!0,K=new Set,H=[];return D(Q,X,0),H.join($?`
`:"");function W(U,N){H.push($?G.repeat(U)+N:N)}function D(U,N,B,z){let{attrs:q,safe:F}=v9.tagInfo(U,z);if(N===void 0)W(B,`<${F}${q}/>`);else if(typeof N==="string")W(B,`<${F}${q}>${v9.escapeText(N)}</${F}>`);else if(typeof N!=="object"||N===null)W(B,`<${F}${q}>${v9.escapeText(P(N))}</${F}>`);else{if(K.has(N))throw new globalThis.Error("Cycle detected while serializing to XML.",{cause:N});K.add(N);try{if(globalThis.globalThis.Array.isArray(N)){if(N.length===0){W(B,`<${F}${q}/>`);return}W(B,`<${F}${q}>`);for(let E of N)D(J,E,B+1);W(B,`</${F}>`);return}let R=N,C=Object.keys(R);if(_)C.sort();if(C.length===0){W(B,`<${F}${q}/>`);return}W(B,`<${F}${q}>`);for(let E of C)D(v9.parseTagName(E).safe,R[E],B+1,E);W(B,`</${F}>`)}finally{K.delete(N)}}}}var v9={escapeText(X){return X.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")},escapeAttribute(X){return X.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;")},parseTagName(X){let Y=X,Q=X;if(!/^[A-Za-z_]/.test(Q))Q="_"+Q;if(Q=Q.replace(/[^A-Za-z0-9._-]/g,"_"),/^xml/i.test(Q))Q="_"+Q;return{safe:Q,changed:Q!==Y}},tagInfo(X,Y){let{changed:Q,safe:J}=v9.parseTagName(X),G=Q||Y&&Y!==X?` data-name="${v9.escapeAttribute(Y??X)}"`:"";return{safe:J,attrs:G}}},O60=Jj((X)=>{switch(X._tag){case"Null":case"Boolean":case"Number":case"BigInt":case"Symbol":case"UniqueSymbol":return 0;default:return 1}});function T60(X,Y,Q){switch(X._tag){case"Declaration":{let J=X.typeParameters.map((W)=>v(Y(F1(W)))),$=X.annotations?.toCodecStringTree;if(l1($)){let W=$(J);if(W===void 0)return X;return R0(X,[t8(W,Y)])}let G=X.annotations?.toCodecJson,_=l1(G)?G(J):void 0,K=_===void 0?X.annotations?.toCodec:void 0,H=_??(l1(K)?K(J):void 0);return H===void 0?Q(X):R0(X,[t8(H,Y)])}case"Null":return R0(X,[F60]);case"Boolean":return R0(X,[R60]);case"Unknown":case"ObjectKeyword":return R0(X,[XH]);case"Enum":case"Number":case"Literal":case"UniqueSymbol":case"Symbol":case"BigInt":return X.toCodecStringTree();case"Objects":return Qj(X),X.recur(Y,nJ);case"Union":{let J=O60(X.types);if(J!==X.types)return new QX(J,X.mode,X.annotations,X.checks,X.encoding,X.context,X.encodingChecks).recur(Y);return X.recur(Y)}case"Arrays":case"Suspend":return X.recur(Y)}return X}var F60=new p0(new DX("null"),new q0(Q0(()=>null),Q0(()=>"null"))),R60=new p0(new QX([new DX("true"),new DX("false")],"anyOf"),new q0(Q0((X)=>X==="true"),Y5())),_j="~effect/Schema/SERIALIZER_ENSURE_ARRAY",Kj=(X)=>LQ(X)&&X.annotations?.[_j]===!0,Hj=e8((X)=>{if(Kj(X))return X;let Y=T60(X,Hj,(Q)=>{throw new globalThis.Error("Missing structural codec for StringTree",{cause:Q})});if(Y!==X&&X.context!==void 0)return lJ(Y,zU(X.context));return Y}),$E=(X)=>l0(X)?CQ(Q5):Q5,A60=new q0(Q0((X)=>typeof X==="string"?[X]:X),cX()),Wj=e8((X)=>{if(Kj(X))return X;let Y=P60(X);if(qQ(Y)){let Q=oJ(new QX([new iX(Y.isMutable,Y.elements.map($E),Y.rest.map($E)),s8],"anyOf",{[_j]:!0}),Y,A60);return l0(X)?CQ(Q):Q}return Y});function P60(X){return X._tag==="Declaration"||X._tag==="Arrays"||X._tag==="Objects"||X._tag==="Union"||X._tag==="Suspend"?X.recur(Wj):X}var w60=s("effect/schema/isGreaterThanDate",h({exclusiveMinimum:J6}),({annotations:X,payload:Y})=>XM(Y.exclusiveMinimum,X)),C60=s("effect/schema/isGreaterThanOrEqualToDate",h({minimum:J6}),({annotations:X,payload:Y})=>YM(Y.minimum,X)),E60=s("effect/schema/isLessThanDate",h({exclusiveMaximum:J6}),({annotations:X,payload:Y})=>QM(Y.exclusiveMaximum,X)),M60=s("effect/schema/isLessThanOrEqualToDate",h({maximum:J6}),({annotations:X,payload:Y})=>JM(Y.maximum,X)),j60=s("effect/schema/isBetweenDate",h({minimum:J6,maximum:J6,exclusiveMinimum:xX(c0(!0)),exclusiveMaximum:xX(c0(!0))}),({annotations:X,payload:Y})=>$M(Y,X)),I60=s("effect/schema/isGreaterThanBigInt",h({exclusiveMinimum:j6}),({annotations:X,payload:Y})=>GM(Y.exclusiveMinimum,X)),x60=s("effect/schema/isGreaterThanOrEqualToBigInt",h({minimum:j6}),({annotations:X,payload:Y})=>ZM(Y.minimum,X)),S60=s("effect/schema/isLessThanBigInt",h({exclusiveMaximum:j6}),({annotations:X,payload:Y})=>_M(Y.exclusiveMaximum,X)),v60=s("effect/schema/isLessThanOrEqualToBigInt",h({maximum:j6}),({annotations:X,payload:Y})=>KM(Y.maximum,X)),k60=s("effect/schema/isBetweenBigInt",h({minimum:j6,maximum:j6,exclusiveMinimum:xX(c0(!0)),exclusiveMaximum:xX(c0(!0))}),({annotations:X,payload:Y})=>HM(Y,X));function b60(X){let Y=$j(X);return vR(ZH(Y),$H(Y))}function g60(X){return N$()}function y60(X){return N$()}function h60(X,Y){return(Q)=>{return v(w6(Q.ast,{toCodecIso:()=>new p0(X.ast,jJ(Y))}),{schema:Q})}}function m60(X){let Y=Yj(X),Q=ZH(Y),J=$H(Y);return{empty:[],diff:($,G)=>_$(Q($),Q(G)),combine:($,G)=>[...$,...G],patch:($,G)=>{let _=Q($),K=MR(G,_);return Object.is(K,_)?$:J(K)}}}function f60(X){let Y=CE(()=>Q),Q=J1([X,Q1(Y),RE(r,Y)]);return Q}var e$=v(w6(V9,{toCode:()=>({runtime:"Schema.Json",Type:"Schema.Json"})})),d60=I1("effect/schema/Json",e$),p60=h({message:r,name:W4(r),stack:W4(r),cause:W4(e$)}),Uj=v(w6(xF,{toCode:()=>({runtime:"Schema.MutableJson",Type:"Schema.MutableJson"})})),u60=I1("effect/schema/MutableJson",Uj);function c60(X){return H8(X.ast)}function l60(X){return X.ast.context?.annotations}var Z7=32,_7=8;var Dj=4096;var Nj=16384,Bj=262144;var qU=4096;var i60=new TextEncoder,Vj=(X)=>i60.encode(X).byteLength,XG=(X,Y)=>Number.isInteger(Y)&&Y>=0&&Vj(X)<=Y;var r60=/^[A-Za-z0-9][A-Za-z0-9._:-]*$/,zj=(X)=>typeof X==="string"&&X.length>0&&XG(X,256)&&r60.test(X);var n60=Z.Literals(["unauthorized","bad_request","invalid","not_found","forbidden","timeout","cancelled","resource_exhausted","unsupported_capability","unsupported_result","result_too_large","failed","runtime_down"]),s60=Z.String.pipe(Z.check(Z.makeFilter((X)=>XG(X,qU),{message:`control error exceeds ${qU} UTF-8 bytes`}))),a60=Z.Struct({_tag:n60,message:s60});var GH0=Z.Union([Z.Struct({ok:Z.Literal(!0),data:Z.Unknown}),Z.Struct({ok:Z.Literal(!1),error:a60})]);var LU=(X,Y)=>Z.String.pipe(Z.check(Z.makeFilter((Q)=>XG(Q,Y),{message:`${X} exceeds ${Y} UTF-8 bytes`}))),K7=Z.String.pipe(Z.check(Z.makeFilter(zj,{message:"sessionId must be nonempty bounded ASCII"}))),qj=Z.Struct({ref:LU("ref",Dj)}),Lj=Z.Struct({sessionId:K7,url:LU("url",Nj)}),Oj=Z.Struct({sessionId:K7,code:LU("code",Bj)}),Tj=Z.Struct({sessionId:K7}),Fj=Z.Struct({sessionId:K7}),Rj=Z.Struct({sessionId:K7}),ZH0=Z.Struct({status:Z.Literal("ok")}),_H0=Z.Struct({id:Z.String,label:Z.optionalKey(Z.String),default:Z.optionalKey(Z.Boolean)}),KH0=Z.Struct({sessionId:Z.String,ref:Z.String,nodeId:Z.String,hostId:Z.String,url:Z.String,profile:Z.String,state:Z.String,attached:Z.Boolean,title:Z.optionalKey(Z.String),lastError:Z.optionalKey(Z.String)}),HH0=Z.Struct({result:Z.Unknown}),WH0=Z.Struct({path:Z.String,bytes:Z.Number}),UH0=Z.Struct({ref:Z.String,sessionId:Z.NullOr(Z.String),canvas:Z.String,nodeId:Z.String,hostId:Z.String,url:Z.String,profile:Z.optionalKey(Z.String)});var $X=(X)=>{try{return process.env[X]==="1"}catch{return!1}},NH0=typeof __VELLUM_COMMAND_CRON_ENABLED__==="boolean"?__VELLUM_COMMAND_CRON_ENABLED__:$X("VELLUM_COMMAND_CRON"),BH0=typeof __VELLUM_COMMAND_RELAY_ENABLED__==="boolean"?__VELLUM_COMMAND_RELAY_ENABLED__:$X("VELLUM_COMMAND_RELAY"),YG=typeof __VELLUM_COMMAND_BROWSER_ENABLED__==="boolean"?__VELLUM_COMMAND_BROWSER_ENABLED__:$X("VELLUM_COMMAND_BROWSER"),VH0=typeof __VELLUM_COMMAND_FLEET_UI_ENABLED__==="boolean"?__VELLUM_COMMAND_FLEET_UI_ENABLED__:$X("VELLUM_COMMAND_FLEET_UI"),zH0=typeof __VELLUM_COMMAND_USAGE_ENABLED__==="boolean"?__VELLUM_COMMAND_USAGE_ENABLED__:$X("VELLUM_COMMAND_USAGE"),qH0=typeof __VELLUM_COMMAND_HELP_MAP_ENABLED__==="boolean"?__VELLUM_COMMAND_HELP_MAP_ENABLED__:$X("VELLUM_COMMAND_HELP_MAP"),LH0=typeof __VELLUM_COMMAND_AUDIO_ENABLED__==="boolean"?__VELLUM_COMMAND_AUDIO_ENABLED__:$X("VELLUM_COMMAND_AUDIO"),OH0=typeof __VELLUM_COMMAND_HERMES_INTEGRATION_ENABLED__==="boolean"?__VELLUM_COMMAND_HERMES_INTEGRATION_ENABLED__:$X("VELLUM_COMMAND_HERMES"),TH0=typeof __VELLUM_COMMAND_DEV_TOOLS_ENABLED__==="boolean"?__VELLUM_COMMAND_DEV_TOOLS_ENABLED__:$X("VELLUM_COMMAND_DEV_TOOLS"),FH0=typeof __VELLUM_COMMAND_HARNESS_KIMI_ENABLED__==="boolean"?__VELLUM_COMMAND_HARNESS_KIMI_ENABLED__:$X("VELLUM_COMMAND_HARNESS_KIMI"),RH0=typeof __VELLUM_COMMAND_HARNESS_MUSE_ENABLED__==="boolean"?__VELLUM_COMMAND_HARNESS_MUSE_ENABLED__:$X("VELLUM_COMMAND_HARNESS_MUSE"),AH0=typeof __VELLUM_COMMAND_HARNESS_FX_ENABLED__==="boolean"?__VELLUM_COMMAND_HARNESS_FX_ENABLED__:$X("VELLUM_COMMAND_HARNESS_FX"),PH0=typeof __VELLUM_COMMAND_HARNESS_PRIME_AGENT_ENABLED__==="boolean"?__VELLUM_COMMAND_HARNESS_PRIME_AGENT_ENABLED__:$X("VELLUM_COMMAND_HARNESS_PRIME_AGENT"),wH0=typeof __VELLUM_COMMAND_HARNESS_SETTINGS_ENABLED__==="boolean"?__VELLUM_COMMAND_HARNESS_SETTINGS_ENABLED__:$X("VELLUM_COMMAND_HARNESS_SETTINGS");var OU=Z.Literals(["claude","codex","grok","hermes","pi","prime-agent","kimi","muse","devin","cursor","agy","amp","fx"]),IH0=OU.literals;var vH0=Z.String.pipe(Z.brand("NodeId")),kH0=Z.String.pipe(Z.brand("EdgeId"));var bH0=Z.Literals(["actor","sink","scheduler","geography"]),t60=Z.Literals(["tasks.list","tasks.create","tasks.claim","tasks.update","msg.list","msg.send","request.escalate","artifact.publish","browser.automate","board.list","board.create_topic","board.post","board.mark_read","pad.read","pad.patch","relay.trigger"]);var I6=(...X)=>WX.fromIterable(X),Aj=Z.Literals(["agent"]),Pj=Z.Literals(["page","task","requests","artifacts","board","pad","terminal"]),wj=Z.Literals(["watcher","timer","cron","relay"]),gH0=Z.Union([Aj,Pj,wj]),e60=Aj.literals,X80=Pj.literals,Y80=wj.literals,Cj=[...e60,...X80,...Y80];var Q80=Z.Literals(["full","empty","subset"]);class L8 extends Z.Class("PortGrant")({mode:Q80,ports:Z.HashSet(t60)}){static empty=new L8({mode:"empty",ports:WX.empty()});static full=new L8({mode:"full",ports:WX.empty()});static subset(X){if(WX.size(X)===0)return L8.empty;return new L8({mode:"subset",ports:X})}static of(...X){return L8.subset(I6(...X))}attenuate(X){if(this.mode==="empty")return L8.empty;if(this.mode==="full")return L8.subset(X);return L8.subset(WX.intersection(this.ports,X))}allows(X,Y){if(!WX.has(Y,X))return!1;if(this.mode==="empty")return!1;if(this.mode==="full")return!0;return WX.has(this.ports,X)}isEmpty(){return this.mode==="empty"}isFull(){return this.mode==="full"}}var QG=WX.empty(),$80=["msg.list","msg.send"],G80=I6(...$80),Z80=I6("tasks.list","tasks.create","tasks.claim","tasks.update","msg.list","msg.send"),_80=I6("request.escalate","msg.list","msg.send"),K80=I6("artifact.publish"),H80=I6("browser.automate"),W80=I6("board.list","board.create_topic","board.post","board.mark_read"),U80=I6("pad.read","pad.patch"),Ej={agent:{kind:"agent",role:"actor",offers:G80},page:{kind:"page",role:"sink",offers:H80},task:{kind:"task",role:"sink",offers:Z80},requests:{kind:"requests",role:"sink",offers:_80},artifacts:{kind:"artifacts",role:"sink",offers:K80},board:{kind:"board",role:"sink",offers:W80},pad:{kind:"pad",role:"sink",offers:U80},terminal:{kind:"terminal",role:"sink",offers:QG},watcher:{kind:"watcher",role:"scheduler",offers:QG},timer:{kind:"timer",role:"scheduler",offers:QG},cron:{kind:"cron",role:"scheduler",offers:QG},relay:{kind:"relay",role:"scheduler",offers:I6("relay.trigger")}},fH0=XQ.fromIterable(Cj.map((X)=>[X,Ej[X]])),dH0=r6.taggedEnum();var Mj=Z.Literals(["blocker","parked","attention"]),jj=Z.Struct({word:Z.Literal("completes"),equals:Z.optionalKey(Z.String),itemId:Z.optionalKey(Z.String)}),Ij=Z.Struct({word:Z.Literal("flagged"),flag:Mj}),D80=Z.Union([jj,Ij]),N80=Z.Struct({word:Z.Literal("any"),any:Z.Array(D80).pipe(Z.check(Z.isMinLength(1)))}),oH0=Z.Union([jj,Ij,N80]),B80=Z.Struct({mode:Z.Literal("enqueue_task"),data:Z.Unknown}),V80=Z.Struct({mode:Z.Literal("set_flag"),flag:Mj,enabled:Z.Union([Z.Boolean,Z.Literal("mirror")])}),z80=Z.Struct({mode:Z.Literal("inject_prompt"),text:Z.optionalKey(Z.String)}),iH0=Z.Union([B80,V80,z80]),TU=Z.Literals(["messages","manages","contributes","works","escalates","publishes","participates","reads","edits","navigates","feeds","fires","announces","enqueues","wakes","flags","chains"]),q80=TU.literals;var L80=["tasks.create","tasks.update","tasks.list","msg.list","msg.send"],rH0=[...L80,"tasks.claim"];var N4=Z.String.pipe(Z.check(Z.isPattern(/^seat_[a-f0-9]{64}$/)),Z.brand("ActorSeatId"));var xj=256,Sj=256,vj=256,vX=Z.String.pipe(Z.check(Z.isMinLength(1)),Z.check(Z.isMaxLength(xj))),kj=Z.String.pipe(Z.check(Z.isMinLength(1)),Z.check(Z.isMaxLength(Sj))),bj=Z.String.pipe(Z.check(Z.isMinLength(1)),Z.check(Z.isMaxLength(vj))),JG=Z.Struct({canvasName:kj,nodeId:bj});var kX=Z.Struct({seatId:N4,canvasName:kj,nodeId:bj}),XW0=Z.decodeUnknownSync(N4)(`seat_${"c".repeat(64)}`);var gj=Z.Literals(["task","proposal","request","message","artifact","delivery","topic","post","pad"]),yj={itemId:vX,sink:JG},$G=Z.Struct({kind:gj,...yj}),FU=Z.Struct({kind:Z.Literal("task"),...yj});var H7=Z.String.pipe(Z.check(Z.isPattern(/^[a-f0-9]{64}$/)),Z.brand("ContentSha256")),W7=Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThanOrEqualTo(0)),Z.check(Z.makeFilter(Number.isSafeInteger,{message:"content byteLength must be a safe integer"})),Z.brand("ContentByteLength")),RU=Z.String.pipe(Z.check(Z.isMinLength(1)),Z.check(Z.isMaxLength(255)),Z.check(Z.isPattern(/^[^\u0000-\u001f\u007f]+$/)),Z.brand("ContentMediaType")),AU=Z.String.pipe(Z.check(Z.isMinLength(1)),Z.check(Z.isMaxLength(255)),Z.check(Z.isPattern(/^[^\u0000-\u001f\u007f]+$/)),Z.brand("ContentDisplayName")),PU=Z.Struct({sha256:H7,byteLength:W7}),LX=Z.Struct({...PU.fields,mediaType:RU,displayName:Z.optionalKey(AU)});var mj=Z.Struct({kind:Z.Literal("local-path"),ref:LX,path:Z.String.pipe(Z.check(Z.isMinLength(1)),Z.check(Z.isMaxLength(4096)),Z.check(Z.isPattern(/^[^\u0000]+$/)))});var wU=Z.String.pipe(Z.check(Z.isMinLength(1)),Z.check(Z.isMaxLength(1024)),Z.check(Z.isPattern(/^[^\u0000-\u001f\u007f]+$/)),Z.brand("ContentAvailabilityReason")),CU=Z.String.pipe(Z.check(Z.isMinLength(1)),Z.check(Z.isMaxLength(64)),Z.brand("ContentTimestamp")),EU=Z.Struct({ref:LX,state:Z.Literal("verified"),verifiedSha256:H7,verifiedByteLength:W7,verifiedAt:CU}).pipe(Z.check(Z.makeFilter(({ref:X,verifiedSha256:Y,verifiedByteLength:Q})=>X.sha256===Y&&X.byteLength===Q||"verified receipt does not match its ContentRef"))),MU=Z.Struct({ref:LX,state:Z.Literal("missing"),reason:wU}),jU=Z.Struct({ref:LX,state:Z.Literal("corrupt"),reason:wU,observedSha256:Z.optionalKey(H7),observedByteLength:Z.optionalKey(W7)}),IU=Z.Struct({ref:LX,state:Z.Literal("unavailable"),reason:wU}),fj=Z.Union([EU,MU,jU,IU]),O8=Z.Struct({kind:Z.Literal("content"),ref:LX}),dj=Z.decodeUnknownResult(O8,{onExcessProperty:"error"});var M80=Z.decodeUnknownResult(LX,{onExcessProperty:"error"});var pj=Z.Struct({kind:Z.Literal("text"),text:Z.String}),uj=Z.Struct({kind:Z.Literal("url"),url:Z.String,mediaType:Z.optionalKey(Z.String)}),cj=Z.Struct({kind:Z.Literal("data"),data:Z.Unknown}),GG=Z.Struct({kind:Z.Literal("raw"),bytesBase64:Z.String,mediaType:Z.optionalKey(Z.String)}),L5=Z.Union([pj,uj,cj,GG,O8]),lj=Z.Literals(["user","agent"]),f9=Z.Record(Z.String,Z.Unknown),T8=Z.Struct({messageId:Z.String,role:lj,parts:Z.Array(L5),taskId:Z.optionalKey(Z.String),contextId:Z.optionalKey(Z.String),referenceTaskIds:Z.optionalKey(Z.Array(Z.String)),metadata:Z.optionalKey(f9)}),d9=Z.Literals(["submitted","working","input-required","completed","canceled","failed","rejected","auth-required","archived"]),ZG=Z.Struct({description:Z.optionalKey(Z.String),artifacts:Z.optionalKey(Z.Struct({nodeId:Z.String.pipe(Z.check(Z.isMinLength(1))),instruction:Z.optionalKey(Z.String),names:Z.optionalKey(Z.Array(Z.String))})),git:Z.optionalKey(Z.Struct({minCommits:Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThanOrEqualTo(1)))}))}),oj=Z.Literals(["hard","soft"]),ij={id:Z.String.pipe(Z.check(Z.isMinLength(1))),text:Z.String.pipe(Z.check(Z.isMinLength(1))),severity:oj},_G=Z.Struct(ij),xU=Z.Struct({id:Z.String.pipe(Z.check(Z.isMinLength(1))),text:Z.String.pipe(Z.check(Z.isMinLength(1))),pinnedAt:Z.String,sourceRequestId:Z.optionalKey(Z.String)}),SU=Z.Struct({id:Z.String.pipe(Z.check(Z.isMinLength(1))),label:Z.String.pipe(Z.check(Z.isMinLength(1))),command:Z.String.pipe(Z.check(Z.isMinLength(1)))}),KG=Z.Struct({...ij,station:Z.String.pipe(Z.check(Z.isMinLength(1)))}),U7=Z.Literals(["auto","operator-gated","operator-owned"]),rj=Z.Struct({instruction:Z.optionalKey(Z.String),description:Z.optionalKey(Z.String),admission:Z.optionalKey(U7),claimableAfterMs:Z.optionalKey(Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThanOrEqualTo(0)))),checklist:Z.optionalKey(Z.Array(SU))}),nj=Z.Struct({emission:Z.optionalKey(Z.String),description:Z.optionalKey(Z.String),checklist:Z.optionalKey(Z.Array(SU))}),sj=Z.Struct({instruction:Z.optionalKey(Z.String),claims:Z.optionalKey(Z.Array(_G)),inbound:Z.optionalKey(rj),outbound:Z.optionalKey(nj)});var aj=Z.Struct({claimId:Z.String.pipe(Z.check(Z.isMinLength(1))),response:Z.String.pipe(Z.check(Z.isMinLength(1))),refs:Z.optionalKey(Z.Array(Z.String))}),tj=Z.Struct({claimId:Z.String.pipe(Z.check(Z.isMinLength(1))),reason:Z.String.pipe(Z.check(Z.isMinLength(1)))}),p9=Z.Struct({artifacts:Z.Array(Z.Struct({artifactId:Z.String.pipe(Z.check(Z.isMinLength(1))),nodeId:Z.String.pipe(Z.check(Z.isMinLength(1)))})),git:Z.optionalKey(Z.Struct({commits:Z.Array(Z.String)})),responses:Z.optionalKey(Z.Array(aj)),claimWaivers:Z.optionalKey(Z.Array(tj))}),ej=Z.Literals(["forwarded","closed","rejected-back"]),XI=Z.Struct({nodeId:Z.String.pipe(Z.check(Z.isMinLength(1))),enteredAt:Z.String,epoch:Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThanOrEqualTo(0))),claimedBy:Z.optionalKey(N4),exitedAt:Z.optionalKey(Z.String),exit:Z.optionalKey(ej),next:Z.optionalKey(Z.String),emissionNote:Z.optionalKey(Z.String)}),x80=Z.Struct({epoch:Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThanOrEqualTo(1))),target:Z.String.pipe(Z.check(Z.isMinLength(1))),at:Z.String}),YI=8192,QI=Z.Literals(["outbound","inbound"]),JI=Z.Struct({checkId:Z.String.pipe(Z.check(Z.isMinLength(1))),side:QI,label:Z.String,command:Z.String,exitCode:Z.Number.pipe(Z.check(Z.isInt())),outputTail:Z.String.pipe(Z.check(Z.isMaxLength(YI))),at:Z.String,epoch:Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThanOrEqualTo(0)))}),x6={dependsOn:Z.optionalKey(Z.Array(Z.String)),finishCriteria:Z.optionalKey(ZG),claims:Z.optionalKey(Z.Array(KG)),metadata:Z.optionalKey(f9),reason:Z.optionalKey(Z.String)},OX=Z.Struct({id:Z.String,state:d9,claimedBy:Z.optionalKey(N4),history:Z.Array(T8),artifactIds:Z.optionalKey(Z.Array(Z.String)),dependsOn:x6.dependsOn,finishCriteria:x6.finishCriteria,claims:x6.claims,completionEvidence:Z.optionalKey(p9),epoch:Z.optionalKey(Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThanOrEqualTo(0)))),journey:Z.optionalKey(Z.Array(XI)),defects:Z.optionalKey(Z.Array(x80)),holdUntil:Z.optionalKey(Z.String),boarding:Z.optionalKey(Z.Array(JI)),metadata:x6.metadata,reason:x6.reason,admission:Z.optionalKey(U7),raisedBy:Z.optionalKey(kX),response:Z.optionalKey(Z.String)}).pipe(Z.check(Z.makeFilter(({id:X,state:Y,claimedBy:Q,metadata:J,dependsOn:$,completionEvidence:G})=>{if(J!==void 0&&Object.prototype.hasOwnProperty.call(J,"claimedBy"))return"metadata.claimedBy is retired; use Task.claimedBy";if(Y==="submitted"&&Q!==void 0)return"submitted tasks must be unclaimed";if((Y==="working"||Y==="input-required"||Y==="auth-required")&&Q===void 0)return`${Y} tasks require claimedBy`;if(G!==void 0&&Y!=="completed")return"completionEvidence is only valid on completed tasks";if($!==void 0){let _=new Set;for(let K of $){if(typeof K!=="string"||K.trim().length===0)return"dependsOn entries must be non-empty task ids";if(K===X)return"dependsOn cannot include the task itself";if(_.has(K))return"dependsOn must not contain duplicates";_.add(K)}}return!0}))),S80=Z.Literals(["pending","approved","rejected"]),O5=Z.Struct({id:Z.String,state:S80,brief:T8,proposedBy:kX,approvedTaskId:Z.optionalKey(Z.String),dependsOn:x6.dependsOn,finishCriteria:x6.finishCriteria,claims:x6.claims,metadata:x6.metadata,reason:x6.reason}).pipe(Z.check(Z.makeFilter(({state:X,approvedTaskId:Y})=>X==="approved"===(Y!==void 0)||"approved proposals require approvedTaskId; other proposal states forbid it"))),D7=Z.Struct({artifactId:Z.String,name:Z.optionalKey(Z.String),parts:Z.Array(L5),task:Z.optionalKey(FU),metadata:Z.optionalKey(f9)}),vU=Z.Struct({items:Z.Array(OX),proposals:Z.optionalKey(Z.Array(O5)),stationName:Z.optionalKey(Z.String),contract:Z.optionalKey(sj)}),kU=Z.Struct({items:Z.Array(OX)}),bU=Z.Struct({items:Z.Array(D7)}),gU=Z.Struct({items:Z.Array(T8)}),v80=Z.Literals(["operator","actor"]),bX=Z.Struct({kind:v80,seatId:Z.optionalKey(N4),nodeId:Z.optionalKey(Z.String),label:Z.optionalKey(Z.String)}),$I=Z.Literals(["open","archived"]),N7=Z.Struct({postId:Z.String,topicId:Z.String,author:bX,parts:Z.Array(L5).pipe(Z.check(Z.isMinLength(1))),position:Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThanOrEqualTo(0))),createdAt:Z.String,tags:Z.optionalKey(Z.Array(Z.String.pipe(Z.check(Z.isMinLength(1)))))}),B7=Z.Struct({topicId:Z.String,title:Z.String.pipe(Z.check(Z.isMinLength(1)),Z.check(Z.isMaxLength(512))),state:$I,openedBy:bX,openedAt:Z.String,postCount:Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThanOrEqualTo(0))),lastActivityAt:Z.String,parts:Z.optionalKey(Z.Array(L5)),posts:Z.optionalKey(Z.Array(N7))}),GI=Z.Struct({topics:Z.Array(B7)}),ZI=Z.Struct({topicId:Z.String,title:Z.String,state:$I,postCount:Z.Number,lastActivityAt:Z.String,authorLabel:Z.optionalKey(Z.String)}),yU=Z.Struct({topics:Z.Array(ZI),unread:Z.optionalKey(Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThanOrEqualTo(0))))}),HG=Z.Struct({revision:Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThanOrEqualTo(0))),shapeCount:Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThanOrEqualTo(0))),unreadPinCount:Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThanOrEqualTo(0)))}),hU=vU,mU=kU,fU=bU,dU=gU,k80=Z.Struct({canvasName:Z.String,nodeId:Z.String,tasks:vU,requests:kU,messages:gU,artifacts:bU,board:GI,pad:Z.optionalKey(HG)});var HI=Z.String,_I=Z.Literals(["top","right","bottom","left"]),KI=Z.Literals(["none","arrow"]),RW0=Z.Literals(["blocks","relates"]);var b80=Z.Literals(["blocker","parked","attention"]);var g80=Z.Literals(["detach","kill-session"]),y80=Z.Literals(["shell","command","harness"]),h80=Z.Struct({kind:y80,argv:Z.optionalKey(Z.Array(Z.String)),cwd:Z.optionalKey(Z.String),env:Z.optionalKey(Z.Record(Z.String,Z.String))}),m80=Z.Struct({bindingId:Z.String,label:Z.optionalKey(Z.String),onDelete:Z.optionalKey(g80),launch:Z.optionalKey(h80),harness:Z.optionalKey(OU),sessionId:Z.optionalKey(Z.String)});var f80=Z.Literals(["detach","kill-session"]),d80=Z.Struct({profile:Z.String,onDelete:Z.optionalKey(f80)});var p80=Z.Struct({cwd:Z.String}),u80=Z.Struct({kind:Z.String,name:Z.optionalKey(Z.String)}),WI=Z.String.pipe(Z.check(Z.isMinLength(1)),Z.check(Z.isMaxLength(64)),Z.check(Z.isPattern(/^(?!-)[A-Za-z0-9][A-Za-z0-9._-]*$/))),c80=Z.Struct({url:Z.optionalKey(Z.String),profile:Z.optionalKey(Z.String),host:Z.optionalKey(WI)}),l80=Z.Record(Z.String,Z.String),o80=Z.Struct({page:Z.optionalKey(c80),paths:Z.optionalKey(l80)}),i80=Z.Struct({claims:Z.optionalKey(Z.Array(_G)),rulings:Z.optionalKey(Z.Array(xU))}),r80=Z.Struct({hold:Z.optionalKey(Z.Boolean),instruction:Z.optionalKey(Z.String),defaults:Z.optionalKey(o80),contract:Z.optionalKey(i80)}),n80=Z.Literal("stat_threshold"),s80=Z.Struct({kind:n80,source:Z.optionalKey(Z.Literal("hermes")),key:Z.optionalKey(Z.String),stat:Z.optionalKey(Z.String),op:Z.optionalKey(Z.Literals(["gt","lt","eq"])),value:Z.optionalKey(Z.Number),flagOnUnsatisfied:Z.optionalKey(Z.Boolean)}),a80=Z.Struct({everyMinutes:Z.optionalKey(Z.Number),expression:Z.optionalKey(Z.String)}),t80=Z.Struct({entity:Z.optionalKey(u80),flags:Z.optionalKey(Z.Array(b80)),region:Z.optionalKey(r80),watch:Z.optionalKey(s80),timer:Z.optionalKey(a80),tasks:Z.optionalKey(hU),requests:Z.optionalKey(mU),artifacts:Z.optionalKey(fU),messages:Z.optionalKey(dU),board:Z.optionalKey(yU),pad:Z.optionalKey(HG),terminal:Z.optionalKey(m80),browser:Z.optionalKey(d80),git:Z.optionalKey(p80),host:Z.optionalKey(WI)}),e80=Z.Struct({verb:TU});var WG={id:Z.String,x:Z.Number,y:Z.Number,width:Z.Number,height:Z.Number,color:Z.optionalKey(HI),ether:Z.optionalKey(t80)},X40=Z.Struct({type:Z.Literal("text"),text:Z.String,...WG}),Y40=Z.Struct({type:Z.Literal("file"),file:Z.String,subpath:Z.optionalKey(Z.String),...WG}),Q40=Z.Struct({type:Z.Literal("link"),url:Z.String,...WG}),J40=Z.Struct({type:Z.Literal("group"),label:Z.optionalKey(Z.String),background:Z.optionalKey(Z.String),backgroundStyle:Z.optionalKey(Z.Literals(["cover","ratio","repeat"])),...WG}),$40=Z.Union([X40,Y40,Q40,J40]),G40=Z.Struct({id:Z.String,fromNode:Z.String,fromSide:Z.optionalKey(_I),fromEnd:Z.optionalKey(KI),toNode:Z.String,toSide:Z.optionalKey(_I),toEnd:Z.optionalKey(KI),color:Z.optionalKey(HI),label:Z.optionalKey(Z.String),ether:Z.optionalKey(e80)}),UI=Z.Struct({nodes:Z.Array($40),edges:Z.Array(G40)});var AW0=Z.decodeUnknownResult(UI,{onExcessProperty:"error"}),PW0=Z.encodeResult(UI);var V4={onExcessProperty:"error"},F8=Z.Number.pipe(Z.check(Z.makeFilter(Number.isFinite,{message:"must be a finite number"}))),T5=F8.pipe(Z.check(Z.isGreaterThan(0))),V7=Z.Number.pipe(Z.check(Z.isInt())),B4=Z.String.pipe(Z.check(Z.isMinLength(1))),$6=B4.pipe(Z.check(Z.isMaxLength(256)),Z.brand("PadElementId"));var Z40=B4.pipe(Z.check(Z.isMaxLength(256)),Z.brand("PadPostId"));var _40=Z.Literals(["box","ellipse","triangle","label"]),K40=Z.Literals(["none","active","done","blocked"]),DI=Z.Literals(["top","right","bottom","left"]),IW0=Z.Literals(["image","shape","edge","ink","pin"]),H40=Z.Struct({x:F8,y:F8}),W40=Z.Struct({w:T5,h:T5}),pU=Z.Struct({id:$6,type:_40,x:F8,y:F8,w:T5,h:T5,z:V7,fill:Z.optionalKey(B4),stroke:Z.optionalKey(B4),text:Z.optionalKey(B4),status:Z.optionalKey(K40)}),uU=Z.Struct({id:$6,from:$6,to:$6,fromSide:Z.optionalKey(DI),toSide:Z.optionalKey(DI),label:Z.optionalKey(B4)}),cU=Z.Struct({id:$6,x:F8,y:F8,w:T5,h:T5,z:V7,ref:LX}),lU=Z.Struct({id:$6,z:V7,color:B4,width:T5,points:Z.Array(H40).pipe(Z.check(Z.isMinLength(2)))}),oU=Z.Struct({postId:Z40,author:bX,parts:Z.Array(L5).pipe(Z.check(Z.isMinLength(1)))}),NI=Z.Struct({id:$6,x:F8,y:F8,bounds:Z.optionalKey(W40),mentions:Z.Array(B4)}),BI=Z.Struct({...NI.fields,posts:Z.Array(oU)}),U40=(X)=>[...X.images.map((Y)=>Y.id),...X.shapes.map((Y)=>Y.id),...X.edges.map((Y)=>Y.id),...X.inks.map((Y)=>Y.id),...X.pins.map((Y)=>Y.id)],D40=(X)=>{let Y=U40(X);if(new Set(Y).size!==Y.length)return"ids must be unique within the pad";let Q=new Set(X.shapes.map((J)=>J.id));for(let J of X.edges)if(!Q.has(J.from)||!Q.has(J.to))return"edge endpoints must exist";for(let J of X.pins){let $=J.posts.map((G)=>G.postId);if(new Set($).size!==$.length)return"post ids must be unique on a pin";if(J.posts.some((G)=>N40(G.parts)))return"bytes never live in pad JSON"}return!0},N40=(X)=>X.some((Y)=>Y.kind==="raw"),B40=Z.Struct({revision:V7.pipe(Z.check(Z.isGreaterThanOrEqualTo(0))),images:Z.Array(cU),shapes:Z.Array(pU),edges:Z.Array(uU),inks:Z.Array(lU),pins:Z.Array(BI)}).pipe(Z.check(Z.makeFilter(D40))),V40=Z.Struct({op:Z.Literal("upsert"),layer:Z.Literal("shape"),shape:pU}),z40=Z.Struct({op:Z.Literal("upsert"),layer:Z.Literal("edge"),edge:uU}),q40=Z.Struct({op:Z.Literal("upsert"),layer:Z.Literal("image"),image:cU}),L40=Z.Struct({op:Z.Literal("upsert"),layer:Z.Literal("ink"),ink:lU}),O40=Z.Struct({op:Z.Literal("pin.upsert"),pin:NI}),T40=Z.Struct({op:Z.Literal("pin.reply"),pinId:$6,post:oU}),F40=Z.Struct({op:Z.Literal("delete"),id:$6}),R40=Z.Struct({op:Z.Literal("z"),id:$6,z:V7}),u9=Z.Union([V40,z40,q40,L40,O40,T40,F40,R40]),A40=Z.Literals(["invalid","duplicate_id","zero_size","dangling_edge","empty_ink","layer_mismatch","missing"]);class P40 extends Z.TaggedErrorClass()("PadError",{code:A40,message:Z.String,id:Z.optionalKey($6)}){}var xW0=Z.decodeUnknownResult(B40,V4),SW0=Z.decodeUnknownResult(u9,V4),vW0=Z.decodeUnknownResult(pU,V4),kW0=Z.decodeUnknownResult(uU,V4),bW0=Z.decodeUnknownResult(cU,V4),gW0=Z.decodeUnknownResult(lU,V4),yW0=Z.decodeUnknownResult(BI,V4),hW0=Z.decodeUnknownResult(oU,V4);var iU=Z.Literals(["ping","doctor","capabilities","onboard","preamble","tasks.list","tasks.create","tasks.claim","tasks.update","tasks.show","tasks.claims","tasks.board","rulings","content.path","content.stat","content.materialize","msg.list","msg.send","msg.read","msg.reply","msg.react","request.escalate","artifact.publish","board.list","board.create_topic","board.post","board.mark_read","board.tags","pad.read","pad.patch","relay.trigger"]),w40=Z.Literals(["ScopeError","ClaimConflict","UnknownTarget","StaleNodeRef","InvalidTransition","RuntimeDown","AuthError","InputError","ProtocolError","InternalError","Paused","Blocked"]),C40=Z.Struct({path:Z.optionalKey(Z.String),expected:Z.optionalKey(Z.Unknown),received:Z.optionalKey(Z.Unknown),hint:Z.optionalKey(Z.String),next_step:Z.optionalKey(Z.String),retryable:Z.optionalKey(Z.Boolean),from:Z.optionalKey(Z.String),to:Z.optionalKey(Z.String),holder:Z.optionalKey(Z.String),target:Z.optionalKey(Z.String),caller:Z.optionalKey(Z.String),missing:Z.optionalKey(Z.String),requestId:Z.optionalKey(Z.String),stop_directive:Z.optionalKey(Z.Unknown)}),E40=Z.Struct({type:w40,message:Z.String,details:Z.optionalKey(C40)}),M40=Z.Struct({token:Z.String,op:iU,args:Z.optionalKey(Z.Unknown),id:Z.optionalKey(Z.String)}),j40=Z.Struct({ok:Z.Literal(!0),op:iU,data:Z.Unknown,id:Z.optionalKey(Z.String),protocol_version:Z.optionalKey(Z.String)}),I40=Z.Struct({ok:Z.Literal(!1),op:Z.optionalKey(iU),error:E40,id:Z.optionalKey(Z.String),protocol_version:Z.optionalKey(Z.String)}),x40=Z.Union([j40,I40]),lW0=Z.decodeUnknownResult(M40,{onExcessProperty:"error"}),oW0=Z.decodeUnknownResult(x40,{onExcessProperty:"error"});var VI=Z.Struct({target:Z.String}),S40=7776000000,zI=Z.optionalKey(Z.Number.pipe(Z.check(Z.isGreaterThanOrEqualTo(0)),Z.check(Z.isLessThanOrEqualTo(S40)))),qI={target:Z.String,brief:Z.String,reason:Z.optionalKey(Z.String),metadata:Z.optionalKey(f9),media:Z.optionalKey(Z.Array(Z.Union([GG,O8]))),dependsOn:Z.optionalKey(Z.Array(Z.String)),finishCriteria:Z.optionalKey(ZG),claims:Z.optionalKey(Z.Array(KG)),admission:Z.optionalKey(U7)},iW0=Z.Struct({...qI,holdForMs:zI}).pipe(Z.check(Z.makeFilter((X)=>{let Y=X.metadata?.details;return typeof Y==="string"&&Y.trim().length>0||"description (metadata.details) must be non-empty"}))).annotate({parseOptions:{onExcessProperty:"error"}}),LI=Z.Struct({...qI,holdFor:Z.optionalKey(Z.Union([Z.String,Z.Number]))}).pipe(Z.check(Z.makeFilter((X)=>{let Y=X.metadata?.details;return typeof Y==="string"&&Y.trim().length>0||"description (metadata.details) must be non-empty"}))).annotate({parseOptions:{onExcessProperty:"error"}}),OI=Z.Struct({target:Z.String,task:Z.String}).annotate({parseOptions:{onExcessProperty:"error"}}),v40=Z.Struct({summary:Z.String.pipe(Z.check(Z.isMinLength(1))),refs:Z.optionalKey(Z.Array(Z.String)),target:Z.optionalKey(Z.String.pipe(Z.check(Z.isMinLength(1))))}),TI={target:Z.String,task:Z.String,state:d9,note:Z.optionalKey(Z.String),completionEvidence:Z.optionalKey(p9),next:Z.optionalKey(Z.String),defect:Z.optionalKey(v40)},rW0=Z.Struct({...TI,holdForMs:zI}).pipe(Z.check(Z.makeFilter(({state:X,completionEvidence:Y})=>Y===void 0||X==="completed"||"completionEvidence is only allowed when state is completed")),Z.check(Z.makeFilter(({state:X,next:Y})=>Y===void 0||X==="completed"||"next is only allowed when state is completed")),Z.check(Z.makeFilter(({state:X,holdForMs:Y})=>Y===void 0||X==="completed"||"holdForMs is only allowed when state is completed")),Z.check(Z.makeFilter(({state:X,defect:Y})=>Y===void 0||X==="rejected"||"defect is only allowed when state is rejected"))).annotate({parseOptions:{onExcessProperty:"error"}}),FI=Z.Struct({...TI,holdFor:Z.optionalKey(Z.Union([Z.String,Z.Number]))}).pipe(Z.check(Z.makeFilter(({state:X,completionEvidence:Y})=>Y===void 0||X==="completed"||"completionEvidence is only allowed when state is completed")),Z.check(Z.makeFilter(({state:X,next:Y})=>Y===void 0||X==="completed"||"next is only allowed when state is completed")),Z.check(Z.makeFilter(({state:X,holdFor:Y})=>Y===void 0||X==="completed"||"holdFor is only allowed when state is completed")),Z.check(Z.makeFilter(({state:X,defect:Y})=>Y===void 0||X==="rejected"||"defect is only allowed when state is rejected"))).annotate({parseOptions:{onExcessProperty:"error"}}),RI=Z.Struct({target:Z.String,task:Z.String}).annotate({parseOptions:{onExcessProperty:"error"}}),AI=Z.Struct({target:Z.String,task:Z.optionalKey(Z.String)}).annotate({parseOptions:{onExcessProperty:"error"}}),nW0=Z.Struct({target:Z.String,task:Z.String,next:Z.optionalKey(Z.String),results:Z.Array(Z.Struct({checkId:Z.String.pipe(Z.check(Z.isMinLength(1))),side:Z.Literals(["outbound","inbound"]),exitCode:Z.Number,outputTail:Z.String}))}).annotate({parseOptions:{onExcessProperty:"error"}}),PI=Z.Struct({target:Z.String,task:Z.String,next:Z.optionalKey(Z.String)}).annotate({parseOptions:{onExcessProperty:"error"}}),wI=Z.Struct({target:Z.optionalKey(Z.String)}).annotate({parseOptions:{onExcessProperty:"error"}}),k40=LX.annotate({parseOptions:{onExcessProperty:"error"}}),rU={target:Z.String.pipe(Z.check(Z.isMinLength(1))),task:Z.String.pipe(Z.check(Z.isMinLength(1))),ref:k40},CI=Z.Struct(rU).annotate({parseOptions:{onExcessProperty:"error"}}),EI=Z.Struct(rU).annotate({parseOptions:{onExcessProperty:"error"}}),MI=Z.Struct({...rU,name:Z.optionalKey(Z.String)}).annotate({parseOptions:{onExcessProperty:"error"}}),jI=Z.Struct({target:Z.optionalKey(Z.String),taskId:Z.optionalKey(Z.String)}),II=Z.Struct({target:Z.String,text:Z.String,taskId:Z.optionalKey(Z.String)}),xI=Z.Struct({target:Z.optionalKey(Z.String),messageId:Z.String}),SI=Z.Struct({target:Z.optionalKey(Z.String),messageId:Z.String,reaction:Z.optionalKey(Z.Literals(["ack"]))}),vI=Z.Struct({target:Z.String,text:Z.String,inReplyTo:Z.String}),kI=Z.Struct({text:Z.String}).annotate({parseOptions:{onExcessProperty:"error"}}),bI=Z.Struct({target:Z.String,brief:Z.String,reason:Z.optionalKey(Z.String),metadata:Z.optionalKey(Z.Record(Z.String,Z.Unknown))}).pipe(Z.check(Z.makeFilter((X)=>{if(!X.brief.trim())return"brief must be non-empty";let Q=typeof X.reason==="string"?X.reason.trim():"",J=X.metadata?.details,$=typeof J==="string"?J.trim():"";if(!Q&&!$)return"request body required: provide reason and/or metadata.details (not title-only)";return!0}))).annotate({parseOptions:{onExcessProperty:"error"}});var b40=Z.Union([Z.Struct({kind:Z.Literal("text"),text:Z.String}),Z.Struct({kind:Z.Literal("url"),url:Z.String,mediaType:Z.optionalKey(Z.String)}),Z.Struct({kind:Z.Literal("data"),data:Z.Unknown}),Z.Struct({kind:Z.Literal("raw"),bytesBase64:Z.String,mediaType:Z.optionalKey(Z.String)}),O8]),gI=Z.Struct({target:Z.String,id:Z.String}),sW0=Z.Struct({target:Z.String,name:Z.optionalKey(Z.String),artifactId:Z.optionalKey(Z.String),parts:Z.Array(b40),task:Z.optionalKey(gI),metadata:Z.optionalKey(Z.Record(Z.String,Z.Unknown))}),g40=Z.Union([Z.Struct({kind:Z.Literal("text"),text:Z.String}),Z.Struct({kind:Z.Literal("url"),url:Z.String,mediaType:Z.optionalKey(Z.String)}),Z.Struct({kind:Z.Literal("data"),data:Z.Unknown}),Z.Struct({kind:Z.Literal("raw"),bytesBase64:Z.optionalKey(Z.String),path:Z.optionalKey(Z.String),mediaType:Z.optionalKey(Z.String)}),O8]),yI=Z.Struct({target:Z.String,name:Z.optionalKey(Z.String),artifactId:Z.optionalKey(Z.String),parts:Z.Array(g40),task:Z.optionalKey(gI),metadata:Z.optionalKey(Z.Record(Z.String,Z.Unknown))}),hI=Z.Struct({}),mI=Z.Struct({target:Z.String,topicId:Z.optionalKey(Z.String)}),aW0=Z.Struct({target:Z.String,title:Z.String,body:Z.optionalKey(Z.String),notify:Z.optionalKey(Z.Boolean)}),fI=Z.Struct({target:Z.String,topicId:Z.String,text:Z.String,tags:Z.optionalKey(Z.Array(Z.String))}),dI=Z.Struct({target:Z.String,topicId:Z.optionalKey(Z.String)}),tW0=Z.Struct({target:Z.String,topicId:Z.String,upToPosition:Z.optionalKey(Z.Number)}),pI=Z.Struct({target:Z.String,pinId:Z.optionalKey(Z.String)}).annotate({parseOptions:{onExcessProperty:"error"}}),uI=Z.Struct({target:Z.String,patches:Z.Array(u9).pipe(Z.check(Z.isMinLength(1)))}).annotate({parseOptions:{onExcessProperty:"error"}}),UG=Z.Struct({target:Z.String.pipe(Z.check(Z.isMinLength(1)))}).annotate({parseOptions:{onExcessProperty:"error"}}),cI=Z.Struct({target:Z.String.pipe(Z.check(Z.isMinLength(1))),pinId:Z.String.pipe(Z.check(Z.isMinLength(1)))}).annotate({parseOptions:{onExcessProperty:"error"}}),lI=Z.Struct({target:Z.String.pipe(Z.check(Z.isMinLength(1))),id:Z.optionalKey(Z.String.pipe(Z.check(Z.isMinLength(1))))}).annotate({parseOptions:{onExcessProperty:"error"}}),eW0=Z.Struct({target:Z.String}).annotate({parseOptions:{onExcessProperty:"error"}});var S6=5;var oI={command:"tasks claim",args:["tasks","claim",'{"target":"n7","task":"t1"}'],lesson:"Claim only unclaimed tasks; the factory queue decides what is available."};var iI={command:"tasks update",args:["tasks","update",'{"target":"n7","task":"t1","state":"completed","note":"done","completionEvidence":{"artifacts":[{"artifactId":"a1","nodeId":"art1"}],"git":{"commits":["abc123"]}}}'],lesson:"completed is a factory verdict, not a self-declaration — attach evidence first, or the server rejects the transition."},rI={command:"escalate",args:["escalate",'{"target":"req1","brief":"need API key for staging","reason":"cannot continue without operator secret"}'],lesson:"Escalating blocks the seat and returns a stop directive — stop work ops until the operator answers."};var C0=["inline-json","@file","stdin"],nI={command_id:"tasks.list",command:"tasks list",schema_id:"tasks.list.input/v1",description:"List tasks on a connected task node.",schema:VI,input_modes:C0},sI={command_id:"tasks.claim",command:"tasks claim",schema_id:"tasks.claim.input/v1",description:"Assign a task to this seat (submitted → working). Op id stays tasks.claim.",schema:OI,accepts_batch:!0,input_modes:C0},DG={command_id:"tasks.create",command:"tasks create",schema_id:"tasks.create.input/v3",description:'Create one Task with a stable TaskId on a connected sink. dependsOn accepts existing TaskIds only and persists before approval. Omitted admission persists operator-gated (clamped to the sink floor); local Command Center approval promotes that same TaskId instead of minting a replacement. Station protocol 1 has no Task approval action, so effective operator-gated creation refuses a Remote home. Legacy proposal events remain immutable: reconciliation materializes pending rows as same-ID gated Tasks and never infers dependencies or auto-rewires documentary proposals. holdFor ("12h", "7d", or ms) bakes the origin arrival.',schema:LI,accepts_batch:!0,input_modes:C0},aI={command_id:"tasks.update",command:"tasks update",schema_id:"tasks.update.input/v4",description:`Transition a task to a new task state. On completed, completionEvidence supplies artifacts + git commits for finish-criteria gates and responses + claimWaivers for the station's claims; next names the forward destination and holdFor ("7d", "12h", or ms) bakes the arrival. On rejected, defect sends the task back to a visited station: defect.target picks any stop the journey already made (receipts earned strictly before it stay live), omitted means the previous station.`,schema:FI,accepts_batch:!0,input_modes:C0},tI={command_id:"tasks.show",command:"tasks show",schema_id:"tasks.show.input/v1",description:"Show one task with its journey. Prior stations appear as what they published (emission note + cited refs), never their interiors.",schema:RI,input_modes:C0},eI={command_id:"tasks.claims",command:"tasks claims",schema_id:"tasks.claims.input/v1",description:"Effective claims at a station (region stack, sink contract, station-addressed task claims) with provenance. Name a task to also get readiness: unanswered claims and per-destination ticket status.",schema:AI,input_modes:C0},Xx={command_id:"tasks.board",command:"tasks board",schema_id:"tasks.board.input/v1",description:"Run this move's boarding checks (station outbound + chosen destination inbound) in the seat's own environment and submit what happened; the work service stamps tickets from these results. Name next when the station forks.",schema:PI,input_modes:C0},Yx={command_id:"rulings",command:"rulings",schema_id:"rulings.input/v1",description:"Operator-pinned rulings across a region stack, outer to inner. No target: this seat's own stack.",schema:wI,input_modes:C0},Qx={command_id:"msg.list",command:"msg list",schema_id:"msg.list.input/v1",description:"List this seat's inbox (no target) or a connected mailbox. Own-inbox list marks listed inbound mail read and includes sent mail with readAt.",schema:jI,input_modes:C0},Jx={command_id:"msg.send",command:"msg send",schema_id:"msg.send.input/v1",description:"Append a message to a connected node.",schema:II,accepts_batch:!0,input_modes:C0},$x={command_id:"msg.read",command:"msg read",schema_id:"msg.read.input/v1",description:"Mark one mailbox message read (own seat only). Own `msg list` already does this for every listed item.",schema:xI,accepts_batch:!0,input_modes:C0},Gx={command_id:"msg.reply",command:"msg reply",schema_id:"msg.reply.input/v1",description:"Reply to factory mail: send text to target and mark inReplyTo read on own mailbox.",schema:vI,accepts_batch:!0,input_modes:C0},Zx={command_id:"msg.react",command:"msg react",schema_id:"msg.react.input/v1",description:"Acknowledge own-inbox mail without a reply (reaction defaults to ack).",schema:SI,accepts_batch:!0,input_modes:C0},_x={command_id:"preamble",command:"preamble",schema_id:"preamble.input/v1",description:"Show a short-lived thought bubble above this agent node.",schema:kI,input_modes:C0},Kx={command_id:"request.escalate",command:"escalate",schema_id:"request.escalate.input/v1",description:"Escalate to the operator: create a request, block this seat, return a stop directive. Subsequent work ops return Blocked until the request is answered.",schema:bI,input_modes:C0},Hx={command_id:"artifact.publish",command:"artifact publish",schema_id:"artifact.publish.input/v2",description:"Publish an artifact; raw parts may use path and optional task provenance names the exact task sink and id.",schema:yI,accepts_batch:!0,input_modes:C0},Wx={command_id:"content.path",command:"content path",schema_id:"content.path.input/v1",description:"Resolve an authorized task ContentRef to its verified canonical local path.",schema:CI,input_modes:C0},Ux={command_id:"content.stat",command:"content stat",schema_id:"content.stat.input/v1",description:"Read availability, identity, metadata, and local path for an authorized task ContentRef.",schema:EI,input_modes:C0},Dx={command_id:"content.materialize",command:"content materialize",schema_id:"content.materialize.input/v1",description:"Stream an authorized task ContentRef into a stable Vellum Command task-scoped workspace path.",schema:MI,input_modes:C0},y40={command_id:"board.list",command:"board list",schema_id:"board.list.input/v1",description:"List topics/posts on a connected board plus metadata of connected actors.",schema:mI,input_modes:C0},h40={command_id:"board.post",command:"board post",schema_id:"board.post.input/v1",description:"Post under a topic; optional tags (actor node ids) soft-notify tagged seats.",schema:fI,accepts_batch:!0,input_modes:C0},m40={command_id:"board.tags",command:"board tags",schema_id:"board.tags.input/v1",description:"List posts on a connected board that tag this process-bound seat.",schema:dI,input_modes:C0},Nx={command_id:"pad.read",command:"pad read",schema_id:"pad.read.input/v1",description:"Read a connected pad (grant pad.read): revision, IR, digest, SVG. Optional pinId adds look-here. Agents never write the factory canvas.",schema:pI,input_modes:C0},Bx={command_id:"pad.patch",command:"pad patch",schema_id:"pad.patch.input/v1",description:"Apply PadPatch on a connected pad (grant pad.patch). Agents may upsert shapes, edges, and pin posts. Agent ink or image upserts are refused. Mentions must be inbound actor node ids.",schema:uI,accepts_batch:!0,input_modes:C0},Vx={command_id:"pad.digest",command:"pad digest",schema_id:"pad.digest.input/v1",description:"Text IR of a connected pad (grant pad.read). Working copy for a wired seat — not the factory canvas.",schema:UG,input_modes:C0},zx={command_id:"pad.svg",command:"pad svg",schema_id:"pad.svg.input/v1",description:"SVG picture of a connected pad (grant pad.read). Agents read the page; they never write the factory canvas.",schema:UG,input_modes:C0},qx={command_id:"pad.look-here",command:"pad look-here",schema_id:"pad.look-here.input/v1",description:"Crop around a pin on a connected pad (grant pad.read). pinId required. Mentions are inbound wired actors — @ cannot name an unwired agent.",schema:cI,input_modes:C0},Lx={command_id:"pad.get",command:"pad get",schema_id:"pad.get.input/v1",description:"Compact focused items from a connected pad (grant pad.read). Optional id returns that item. Agents never write the factory canvas.",schema:lI,input_modes:C0},Ox={command_id:"pad.tagged",command:"pad tagged",schema_id:"pad.tagged.input/v1",description:"Pins that mention this process-bound seat (grant pad.read). Mention universe is inbound actor edges; unwired names are refused on pad.patch.",schema:UG,input_modes:C0},F5=(X,Y,Q,J)=>({command_id:`browser.${X}`,command:`browser ${Y}`,schema_id:`browser.${X}.input/v1`,description:Q,schema:J,input_modes:["positional"]}),Tx=F5("pages","pages","List page nodes admitted by the caller's live browser.automate edges.",hI),Fx=F5("open","open <vellum-ref>","Open or reuse a granted page session.",qj),Rx=F5("goto","goto <sessionId> <url>","Navigate an admitted browser session.",Lj),Ax=F5("eval","eval <sessionId> <code>","Evaluate JavaScript in an admitted browser session.",Oj),Px=F5("screenshot","shot <sessionId>","Capture a server-owned PNG from an admitted browser session.",Tj),wx=F5("close","close <sessionId>","Detach a browser surface while keeping its session warm.",Fj),Cx=F5("stop","stop <sessionId>","Destroy an admitted browser session.",Rj),KU0=[nI,DG,sI,aI,tI,eI,Xx,Yx,Qx,Jx,$x,Gx,Zx,_x,Kx,Hx,Wx,Ux,Dx,y40,h40,m40,Nx,Bx,Vx,zx,qx,Lx,Ox,...YG?[Tx,Fx,Rx,Ax,Px,wx,Cx]:[]],I0=[{command_id:"tasks.create",command:"tasks create",name:"create an operator-gated Task",description:"Create one stable-ID Task for local Command Center operator approval. Omitting admission persists operator-gated.",input:{target:"n7",brief:"Add keyboard navigation",metadata:{title:"Keyboard navigation",details:"Cover the task board first."}},args:["tasks","create",'{"target":"n7","brief":"Add keyboard navigation","metadata":{"title":"Keyboard navigation","details":"Cover the task board first."}}']},{command_id:"tasks.create",command:"tasks create",name:"create with TaskId dependencies and finish criteria",description:"dependsOn names existing TaskIds only. The dependency edges and this TaskId persist before approval; approval promotes the same Task.",input:{target:"n7",brief:"Ship media migration graph",reason:"needs prior content-ref work complete",dependsOn:["t_prereq"],finishCriteria:{description:"graph claimable and media uses ContentRef",git:{minCommits:1}},metadata:{title:"Media migration graph",details:"Wire ContentRef media and make the graph claimable."}},args:["tasks","create",'{"target":"n7","brief":"Ship media migration graph","reason":"needs prior content-ref work complete","dependsOn":["t_prereq"],"finishCriteria":{"description":"graph claimable and media uses ContentRef","git":{"minCommits":1}},"metadata":{"title":"Media migration graph","details":"Wire ContentRef media and make the graph claimable."}}']},{command_id:"tasks.claim",command:"tasks claim",name:"claim one",description:"Claim task t1 on target node n7.",args:oI.args,input:{target:"n7",task:"t1"}},{command_id:"tasks.claim",command:"tasks claim",name:"batch claim",description:"Claim several tasks with bounded concurrency.",args:["tasks","claim","@claims.json","--concurrency","5"],input:[{target:"n7",task:"t1"},{target:"n7",task:"t2"}]},{command_id:"tasks.update",command:"tasks update",name:"complete",input:{target:"n7",task:"t1",state:"completed",note:"done"},args:["tasks","update",'{"target":"n7","task":"t1","state":"completed","note":"done"}']},{command_id:"tasks.update",command:"tasks update",name:"complete with evidence",input:{target:"n7",task:"t1",state:"completed",note:"done",completionEvidence:{artifacts:[{artifactId:"a1",nodeId:"art1"}],git:{commits:["abc123"]}}},args:iI.args},{command_id:"tasks.update",command:"tasks update",name:"answer claims and forward",description:"Complete at this station with a response per claim, then forward to the named destination.",input:{target:"n7",task:"t1",state:"completed",note:"review passed",completionEvidence:{artifacts:[],responses:[{claimId:"c1",response:"ran the suite; all green",refs:["abc123"]}],claimWaivers:[{claimId:"c2",reason:"no schema changed in this task"}]},next:"n8",holdFor:"12h"},args:["tasks","update",'{"target":"n7","task":"t1","state":"completed","note":"review passed","completionEvidence":{"artifacts":[],"responses":[{"claimId":"c1","response":"ran the suite; all green","refs":["abc123"]}],"claimWaivers":[{"claimId":"c2","reason":"no schema changed in this task"}]},"next":"n8","holdFor":"12h"}']},{command_id:"tasks.update",command:"tasks update",name:"send back with a defect",description:"Return the task to the previous station with the reason on record.",input:{target:"n7",task:"t1",state:"rejected",defect:{summary:"the brief names an endpoint that does not exist",refs:["abc123"]}},args:["tasks","update",'{"target":"n7","task":"t1","state":"rejected","defect":{"summary":"the brief names an endpoint that does not exist","refs":["abc123"]}}']},{command_id:"tasks.show",command:"tasks show",name:"show",input:{target:"n7",task:"t1"},args:["tasks","show",'{"target":"n7","task":"t1"}']},{command_id:"tasks.claims",command:"tasks claims",name:"station law",description:"The standing claims at this station, with provenance.",input:{target:"n7"},args:["tasks","claims",'{"target":"n7"}']},{command_id:"tasks.claims",command:"tasks claims",name:"readiness for a task",description:"What is still unanswered, and which boarding tickets are green.",input:{target:"n7",task:"t1"},args:["tasks","claims",'{"target":"n7","task":"t1"}']},{command_id:"tasks.board",command:"tasks board",name:"run boarding checks",description:"Resolve and run the applicable checklists locally, then submit results; tickets are stamped from what the checks returned.",input:{target:"n7",task:"t1"},args:["tasks","board",'{"target":"n7","task":"t1"}']},{command_id:"tasks.board",command:"tasks board",name:"run boarding checks toward a destination",description:"Name the destination when the station forks; its inbound checklist joins the station's outbound checks.",input:{target:"n7",task:"t1",next:"n8"},args:["tasks","board",'{"target":"n7","task":"t1","next":"n8"}']},{command_id:"rulings",command:"rulings",name:"own region stack",input:{},args:["rulings"]},{command_id:"msg.send",command:"msg send",name:"note on task",input:{target:"n7",text:"working",taskId:"t1"},args:["msg","send",'{"target":"n7","text":"working","taskId":"t1"}']},{command_id:"msg.read",command:"msg read",name:"ack mailbox",input:{target:"seat-a",messageId:"msg_01"},args:["msg","read",'{"target":"seat-a","messageId":"msg_01"}']},{command_id:"msg.reply",command:"msg reply",name:"reply to mail",input:{target:"seat-b",text:"ack, starting",inReplyTo:"msg_01"},args:["msg","reply",'{"target":"seat-b","text":"ack, starting","inReplyTo":"msg_01"}']},{command_id:"msg.list",command:"msg list",name:"open own inbox",input:{},args:["msg","list"]},{command_id:"msg.react",command:"msg react",name:"ack without reply",input:{messageId:"msg_01"},args:["msg","react",'{"messageId":"msg_01"}']},{command_id:"preamble",command:"preamble",name:"share a brief thought",description:"Show a sentence above this agent node for about 30 seconds.",input:{text:"Inspecting the task and choosing the smallest safe change."},args:["preamble",'{"text":"Inspecting the task and choosing the smallest safe change."}']},{command_id:"request.escalate",command:"escalate",name:"block until answer",description:"File a request and block this seat. Server returns stop_directive; further work ops return Blocked.",input:{target:"req1",brief:"need API key for staging",reason:"cannot continue without operator secret"},args:rI.args},{command_id:"artifact.publish",command:"artifact publish",name:"publish file",input:{target:"art1",name:"report",parts:[{kind:"raw",path:"/abs/x.png"}],task:{target:"tasks",id:"t1"}},args:["artifact","publish",'{"target":"art1","name":"report","parts":[{"kind":"raw","path":"/abs/x.png"}],"task":{"target":"tasks","id":"t1"}}']},{command_id:"tasks.list",command:"tasks list",name:"list",input:{target:"n7"},args:["tasks","list",'{"target":"n7"}']},{command_id:"content.path",command:"content path",name:"resolve task content",description:"Resolve a ContentRef carried by task t1 on target n7.",input:{target:"n7",task:"t1",ref:{sha256:"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",byteLength:12,mediaType:"application/octet-stream"}},args:["content","path",'{"target":"n7","task":"t1","ref":{"sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","byteLength":12,"mediaType":"application/octet-stream"}}']},{command_id:"content.stat",command:"content stat",name:"inspect task content",input:{target:"n7",task:"t1",ref:{sha256:"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",byteLength:12,mediaType:"application/octet-stream"}},args:["content","stat",'{"target":"n7","task":"t1","ref":{"sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","byteLength":12,"mediaType":"application/octet-stream"}}']},{command_id:"content.materialize",command:"content materialize",name:"materialize task content",input:{target:"n7",task:"t1",name:"record.bin",ref:{sha256:"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",byteLength:12,mediaType:"application/octet-stream"}},args:["content","materialize",'{"target":"n7","task":"t1","name":"record.bin","ref":{"sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","byteLength":12,"mediaType":"application/octet-stream"}}']},{command_id:"pad.read",command:"pad read",name:"read pad",description:"Read revision, IR, digest, and SVG on a wired pad.",input:{target:"pad-1"},args:["pad","read",'{"target":"pad-1"}']},{command_id:"pad.read",command:"pad read",name:"read with look-here",description:"Read the pad and crop around pin-1.",input:{target:"pad-1",pinId:"pin-1"},args:["pad","read",'{"target":"pad-1","pinId":"pin-1"}']},{command_id:"pad.patch",command:"pad patch",name:"upsert box",description:"Upsert a named box. Agent ink/image upserts are refused; mentions must be inbound actors.",input:{target:"pad-1",patches:[{op:"upsert",layer:"shape",shape:{id:"box-1",type:"box",x:0,y:0,w:80,h:40,z:0,text:"inbox"}}]},args:["pad","patch",'{"target":"pad-1","patches":[{"op":"upsert","layer":"shape","shape":{"id":"box-1","type":"box","x":0,"y":0,"w":80,"h":40,"z":0,"text":"inbox"}}]}']},{command_id:"pad.patch",command:"pad patch",name:"pin mention",description:"Place a pin that mentions a wired inbound actor. Unwired names are refused.",input:{target:"pad-1",patches:[{op:"pin.upsert",pin:{id:"pin-1",x:16,y:16,mentions:["agent-1"]}}]},args:["pad","patch",'{"target":"pad-1","patches":[{"op":"pin.upsert","pin":{"id":"pin-1","x":16,"y":16,"mentions":["agent-1"]}}]}']},{command_id:"pad.digest",command:"pad digest",name:"text IR",input:{target:"pad-1"},args:["pad","digest",'{"target":"pad-1"}']},{command_id:"pad.svg",command:"pad svg",name:"picture",input:{target:"pad-1"},args:["pad","svg",'{"target":"pad-1"}']},{command_id:"pad.look-here",command:"pad look-here",name:"crop pin",description:"Crop the page around pin-1.",input:{target:"pad-1",pinId:"pin-1"},args:["pad","look-here",'{"target":"pad-1","pinId":"pin-1"}']},{command_id:"pad.get",command:"pad get",name:"focused items",input:{target:"pad-1"},args:["pad","get",'{"target":"pad-1"}']},{command_id:"pad.get",command:"pad get",name:"one item",input:{target:"pad-1",id:"box-1"},args:["pad","get",'{"target":"pad-1","id":"box-1"}']},{command_id:"pad.tagged",command:"pad tagged",name:"pins mentioning this seat",description:"List pins that mention the process-bound seat.",input:{target:"pad-1"},args:["pad","tagged",'{"target":"pad-1"}']},...YG?[{command_id:"browser.pages",command:"browser pages",name:"list granted pages",args:["browser","pages","--json"],input:{}},{command_id:"browser.open",command:"browser open <vellum-ref>",name:"open a granted page",args:["browser","open","vellum-command://canvas/work?node=page-1","--json"],input:{ref:"vellum-command://canvas/work?node=page-1"}}]:[]],HU0=[{command_id:"ping",command:"ping",category:"diagnostic",description:"Liveness probe against the work control socket."},{command_id:"doctor",command:"doctor",category:"diagnostic",description:"Env socket+token present, perms 0600, protocol version match."},{command_id:"capabilities",command:"capabilities",category:"discovery",description:"Live wiring from the caller's edges as a contract."},{command_id:"onboard",command:"onboard",category:"discovery",description:"Node, region, connected, co-members, capabilities from live state."},{command_id:"schema.list",command:"schema list",category:"discovery",description:"List JSON input schemas."},{command_id:"schema.show",command:"schema show",category:"discovery",description:"Show one JSON input schema."},{command_id:"examples.list",command:"examples list",category:"discovery",description:"List executable examples."},{command_id:"examples.show",command:"examples show",category:"discovery",description:"Show examples for one command."},{command_id:"tasks.list",command:"tasks list",category:"workflow",description:"List tasks on a connected target.",schemas:[nI],examples:I0.filter((X)=>X.command_id==="tasks.list")},{command_id:"tasks.create",command:"tasks create",category:"workflow",description:"Create one or more tasks on a connected sink (batch-capable).",schemas:[DG],examples:I0.filter((X)=>X.command_id==="tasks.create"),batch:{accepts_batch:!0,default_concurrency:S6,supports_concurrency_option:!0}},{command_id:"tasks.claim",command:"tasks claim",category:"workflow",description:"Claim one or more tasks (batch-capable).",schemas:[sI],examples:I0.filter((X)=>X.command_id==="tasks.claim"),batch:{accepts_batch:!0,default_concurrency:S6,supports_concurrency_option:!0}},{command_id:"tasks.update",command:"tasks update",category:"workflow",description:"Update task state (batch-capable).",schemas:[aI],examples:I0.filter((X)=>X.command_id==="tasks.update"),batch:{accepts_batch:!0,default_concurrency:S6,supports_concurrency_option:!0}},{command_id:"tasks.show",command:"tasks show",category:"workflow",description:"Show one task with its journey (onion-scoped for seats).",schemas:[tI],examples:I0.filter((X)=>X.command_id==="tasks.show")},{command_id:"tasks.claims",command:"tasks claims",category:"workflow",description:"Effective claims at a station, plus readiness for a named task.",schemas:[eI],examples:I0.filter((X)=>X.command_id==="tasks.claims")},{command_id:"tasks.board",command:"tasks board",category:"workflow",description:"Run this move's boarding checks in the seat's environment and submit the results; tickets are stamped from what came back.",schemas:[Xx],examples:I0.filter((X)=>X.command_id==="tasks.board")},{command_id:"rulings",command:"rulings",category:"workflow",description:"Operator-pinned rulings over a region stack.",schemas:[Yx],examples:I0.filter((X)=>X.command_id==="rulings")},{command_id:"msg.list",command:"msg list",category:"workflow",description:"List own inbox (marks listed mail read; includes sent with readAt) or a peer mailbox.",schemas:[Qx],examples:I0.filter((X)=>X.command_id==="msg.list")},{command_id:"msg.send",command:"msg send",category:"workflow",description:"Send a message (batch-capable).",schemas:[Jx],examples:I0.filter((X)=>X.command_id==="msg.send"),batch:{accepts_batch:!0,default_concurrency:S6,supports_concurrency_option:!0}},{command_id:"msg.read",command:"msg read",category:"workflow",description:"Mark a mailbox message read (own seat; batch-capable).",schemas:[$x],examples:I0.filter((X)=>X.command_id==="msg.read"),batch:{accepts_batch:!0,default_concurrency:S6,supports_concurrency_option:!0}},{command_id:"msg.reply",command:"msg reply",category:"workflow",description:"Reply to factory mail and mark parent read (batch-capable).",schemas:[Gx],examples:I0.filter((X)=>X.command_id==="msg.reply"),batch:{accepts_batch:!0,default_concurrency:S6,supports_concurrency_option:!0}},{command_id:"msg.react",command:"msg react",category:"workflow",description:"Acknowledge own-inbox mail without a reply (batch-capable).",schemas:[Zx],examples:I0.filter((X)=>X.command_id==="msg.react"),batch:{accepts_batch:!0,default_concurrency:S6,supports_concurrency_option:!0}},{command_id:"preamble",command:"preamble",category:"workflow",description:"Show a short-lived thought bubble above this agent node.",schemas:[_x],examples:I0.filter((X)=>X.command_id==="preamble")},{command_id:"request.escalate",command:"escalate",category:"workflow",description:"Escalate to operator: create request, block seat, return stop directive.",schemas:[Kx],examples:I0.filter((X)=>X.command_id==="request.escalate")},{command_id:"artifact.publish",command:"artifact publish",category:"workflow",description:"Publish an artifact (batch-capable).",schemas:[Hx],examples:I0.filter((X)=>X.command_id==="artifact.publish"),batch:{accepts_batch:!0,default_concurrency:S6,supports_concurrency_option:!0}},{command_id:"content.path",command:"content path",category:"workflow",description:"Resolve an authorized task ContentRef to a local path.",schemas:[Wx],examples:I0.filter((X)=>X.command_id==="content.path")},{command_id:"content.stat",command:"content stat",category:"workflow",description:"Inspect availability for an authorized task ContentRef.",schemas:[Ux],examples:I0.filter((X)=>X.command_id==="content.stat")},{command_id:"content.materialize",command:"content materialize",category:"workflow",description:"Materialize an authorized task ContentRef into the task workspace.",schemas:[Dx],examples:I0.filter((X)=>X.command_id==="content.materialize")},{command_id:"pad.read",command:"pad read",category:"workflow",description:"Read a connected pad (grant pad.read): revision, IR, digest, SVG.",schemas:[Nx],examples:I0.filter((X)=>X.command_id==="pad.read")},{command_id:"pad.patch",command:"pad patch",category:"workflow",description:"Apply PadPatch (grant pad.patch). Agent ink/image refused; mentions must be inbound actors.",schemas:[Bx],examples:I0.filter((X)=>X.command_id==="pad.patch"),batch:{accepts_batch:!0,default_concurrency:S6,supports_concurrency_option:!0}},{command_id:"pad.digest",command:"pad digest",category:"workflow",description:"Text IR of a connected pad (grant pad.read).",schemas:[Vx],examples:I0.filter((X)=>X.command_id==="pad.digest")},{command_id:"pad.svg",command:"pad svg",category:"workflow",description:"SVG picture of a connected pad (grant pad.read).",schemas:[zx],examples:I0.filter((X)=>X.command_id==="pad.svg")},{command_id:"pad.look-here",command:"pad look-here",category:"workflow",description:"Crop around a pin (grant pad.read). Mentions are inbound wired actors.",schemas:[qx],examples:I0.filter((X)=>X.command_id==="pad.look-here")},{command_id:"pad.get",command:"pad get",category:"workflow",description:"Focused items from a connected pad (grant pad.read).",schemas:[Lx],examples:I0.filter((X)=>X.command_id==="pad.get")},{command_id:"pad.tagged",command:"pad tagged",category:"workflow",description:"Pins mentioning this process-bound seat (grant pad.read).",schemas:[Ox],examples:I0.filter((X)=>X.command_id==="pad.tagged")},...YG?[{command_id:"browser.pages",command:"browser pages",category:"discovery",description:"List page nodes granted through browser.automate edges.",schemas:[Tx],examples:I0.filter((X)=>X.command_id==="browser.pages")},{command_id:"browser.open",command:"browser open",category:"workflow",description:"Open or reuse a granted page session.",schemas:[Fx],examples:I0.filter((X)=>X.command_id==="browser.open")},{command_id:"browser.goto",command:"browser goto",category:"workflow",description:"Navigate an admitted browser session.",schemas:[Rx]},{command_id:"browser.eval",command:"browser eval",category:"workflow",description:"Evaluate JavaScript in an admitted browser session.",schemas:[Ax]},{command_id:"browser.screenshot",command:"browser shot",category:"workflow",description:"Capture a server-owned page screenshot.",schemas:[Px]},{command_id:"browser.close",command:"browser close",category:"workflow",description:"Detach a browser surface while keeping its session warm.",schemas:[wx]},{command_id:"browser.stop",command:"browser stop",category:"workflow",description:"Destroy an admitted browser session.",schemas:[Cx]}]:[]];import{constants as H0}from"node:sqlite";var Ex=`
  CREATE TABLE IF NOT EXISTS browser_profiles (
    id TEXT PRIMARY KEY
      CHECK (
        length(id) BETWEEN 1 AND 63
        AND substr(id, 1, 1) GLOB '[a-z0-9]'
        AND id NOT GLOB '*[^a-z0-9-]*'
      ),
    label TEXT
      CHECK (
        label IS NULL
        OR (
          length(label) > 0
          AND length(CAST(label AS BLOB)) <= 128
        )
      ),
    created_at TEXT NOT NULL CHECK (length(created_at) > 0),
    last_used_at TEXT CHECK (last_used_at IS NULL OR length(last_used_at) > 0),
    sort_order INTEGER NOT NULL UNIQUE CHECK (sort_order >= 0)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS browser_profile_settings (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    version INTEGER NOT NULL CHECK (version = 1),
    default_profile TEXT NOT NULL
      REFERENCES browser_profiles(id) ON DELETE RESTRICT,
    max_warm_sessions INTEGER NOT NULL
      CHECK (max_warm_sessions BETWEEN 1 AND ${Z7}),
    max_visible_surfaces INTEGER NOT NULL
      CHECK (max_visible_surfaces BETWEEN 1 AND ${_7})
  ) STRICT;

  CREATE TABLE IF NOT EXISTS browser_profile_canvas_defaults (
    canvas_name TEXT PRIMARY KEY
      CHECK (
        length(canvas_name) BETWEEN 1 AND 63
        AND substr(canvas_name, 1, 1) GLOB '[a-z0-9]'
        AND canvas_name NOT GLOB '*[^a-z0-9-]*'
      ),
    profile_id TEXT NOT NULL
      REFERENCES browser_profiles(id) ON DELETE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS browser_profile_pending_wipe (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    wipe_id TEXT NOT NULL UNIQUE CHECK (length(wipe_id) = 36),
    profile_id TEXT NOT NULL UNIQUE
      REFERENCES browser_profiles(id) ON DELETE RESTRICT,
    partition TEXT NOT NULL
      CHECK (partition = 'persist:vellum-profile-' || profile_id),
    requested_at TEXT NOT NULL CHECK (length(requested_at) > 0),
    stage TEXT NOT NULL
      CHECK (stage IN ('live_clear_pending', 'restart_delete_pending')),
    storage_path TEXT NOT NULL
      CHECK (length(CAST(storage_path AS BLOB)) BETWEEN 1 AND 4096),
    user_data_path TEXT NOT NULL
      CHECK (length(CAST(user_data_path AS BLOB)) BETWEEN 1 AND 4096),
    session_data_path TEXT NOT NULL
      CHECK (length(CAST(session_data_path AS BLOB)) BETWEEN 1 AND 4096)
  ) STRICT;

  CREATE TRIGGER IF NOT EXISTS browser_profiles_limit
  BEFORE INSERT ON browser_profiles
  WHEN (SELECT count(*) FROM browser_profiles) >= 64
  BEGIN
    SELECT RAISE(ABORT, 'browser profile limit reached');
  END;

  CREATE TRIGGER IF NOT EXISTS browser_profile_canvas_defaults_limit
  BEFORE INSERT ON browser_profile_canvas_defaults
  WHEN (SELECT count(*) FROM browser_profile_canvas_defaults) >= 256
  BEGIN
    SELECT RAISE(ABORT, 'browser canvas-default limit reached');
  END;
`;var Mx=`
  CREATE TABLE IF NOT EXISTS box_resources (
    box_id TEXT PRIMARY KEY
      CHECK (
        length(box_id) = 11
        AND box_id GLOB 'bx_[23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz][23456789abcdefghjkmnpqrstuvwxyz]'
      ),
    host_id TEXT UNIQUE
      REFERENCES host_registry(id) ON DELETE RESTRICT,
    name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 255),
    machine_ip TEXT,
    machine_state TEXT NOT NULL CHECK (length(machine_state) BETWEEN 1 AND 32),
    provider_created_at TEXT CHECK (
      provider_created_at IS NULL OR length(provider_created_at) > 0
    ),
    provider_updated_at TEXT CHECK (
      provider_updated_at IS NULL OR length(provider_updated_at) > 0
    ),
    ssh_prepared_at TEXT CHECK (
      ssh_prepared_at IS NULL OR length(ssh_prepared_at) > 0
    ),
    ssh_verified_at TEXT CHECK (
      ssh_verified_at IS NULL OR length(ssh_verified_at) > 0
    ),
    enrolled_at TEXT NOT NULL CHECK (length(enrolled_at) > 0)
  ) STRICT;

  CREATE TRIGGER IF NOT EXISTS box_resources_immutable_identity
  BEFORE UPDATE OF box_id ON box_resources
  BEGIN
    SELECT RAISE(ABORT, 'Box ownership identity is immutable');
  END;
`;var NG=`
  CREATE TABLE IF NOT EXISTS canvas_entities (
    canvas_name TEXT NOT NULL
      CHECK (
        length(canvas_name) BETWEEN 1 AND 64
        AND canvas_name GLOB '[a-z0-9]*'
        AND canvas_name NOT GLOB '*[^a-z0-9_-]*'
      ),
    entity_id TEXT NOT NULL
      CHECK (length(entity_id) BETWEEN 1 AND 256),
    kind TEXT
      CHECK (kind IS NULL OR length(kind) BETWEEN 1 AND 128),
    binding_id TEXT
      CHECK (
        binding_id IS NULL
        OR length(binding_id) BETWEEN 1 AND 256
      ),
    lifecycle TEXT NOT NULL
      CHECK (lifecycle IN ('active', 'archived', 'soft_deleted')),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    archived_at TEXT
      CHECK (archived_at IS NULL OR length(archived_at) BETWEEN 1 AND 64),
    soft_deleted_at TEXT
      CHECK (
        soft_deleted_at IS NULL
        OR length(soft_deleted_at) BETWEEN 1 AND 64
      ),
    PRIMARY KEY (canvas_name, entity_id),
    CHECK (
      (lifecycle = 'active' AND archived_at IS NULL AND soft_deleted_at IS NULL)
      OR (
        lifecycle = 'archived'
        AND archived_at IS NOT NULL
        AND soft_deleted_at IS NULL
      )
      OR (
        lifecycle = 'soft_deleted'
        AND archived_at IS NOT NULL
        AND soft_deleted_at IS NOT NULL
      )
    )
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS canvas_entities_lifecycle
    ON canvas_entities(canvas_name, lifecycle, updated_at, entity_id);

  -- Only one *active* entity may hold a binding on a canvas. Archived and
  -- soft_deleted rows retain binding_id for audit without blocking re-bind.
  CREATE UNIQUE INDEX IF NOT EXISTS canvas_entities_canvas_binding
    ON canvas_entities(canvas_name, binding_id)
    WHERE binding_id IS NOT NULL AND lifecycle = 'active';
`;var jx=`
  CREATE TABLE IF NOT EXISTS host_registry (
    id TEXT PRIMARY KEY
      CHECK (
        length(id) BETWEEN 1 AND 64
        AND substr(id, 1, 1) GLOB '[A-Za-z0-9]'
        AND id NOT GLOB '*[^A-Za-z0-9._-]*'
      ),
    label TEXT NOT NULL
      CHECK (length(label) BETWEEN 1 AND 64),
    kind TEXT NOT NULL
      CHECK (kind IN ('local', 'remote')),
    ssh_endpoint TEXT UNIQUE,
    ssh_identity_file TEXT
      CHECK (
        ssh_identity_file IS NULL
        OR (
          length(ssh_identity_file) BETWEEN 1 AND 1024
          AND substr(ssh_identity_file, 1, 1) = '/'
        )
      ),
    ssh_host_key_policy TEXT
      CHECK (
        ssh_host_key_policy IS NULL
        OR ssh_host_key_policy IN ('system', 'accept-new')
      ),
    capability_mask INTEGER,
    hermes_id TEXT
      CHECK (
        hermes_id IS NULL
        OR (
          length(hermes_id) BETWEEN 1 AND 64
          AND substr(hermes_id, 1, 1) GLOB '[A-Za-z0-9]'
          AND hermes_id NOT GLOB '*[^A-Za-z0-9._-]*'
        )
      ),
    effective_hermes_id TEXT UNIQUE,
    appearance_color TEXT,
    appearance_glyph TEXT,
    sort_order INTEGER NOT NULL UNIQUE
      CHECK (sort_order >= 0),
    CHECK (
      (
        kind = 'local'
        AND id = 'local'
        AND ssh_endpoint IS NULL
        AND ssh_identity_file IS NULL
        AND ssh_host_key_policy IS NULL
        AND capability_mask IS NULL
        AND sort_order = 0
      )
      OR
      (
        kind = 'remote'
        AND id <> 'local'
        AND (
          ssh_endpoint IS NULL
          OR length(ssh_endpoint) BETWEEN 1 AND 255
        )
        AND (
          ssh_endpoint IS NOT NULL
          OR (
            ssh_identity_file IS NULL
            AND ssh_host_key_policy IS NULL
          )
        )
        AND capability_mask BETWEEN 1 AND 15
        AND sort_order > 0
      )
    ),
    CHECK (
      (
        (
          kind = 'local'
          OR (capability_mask & 8) <> 0
        )
        AND effective_hermes_id IS NOT NULL
        AND effective_hermes_id = coalesce(hermes_id, id)
      )
      OR
      (
        kind = 'remote'
        AND (capability_mask & 8) = 0
        AND effective_hermes_id IS NULL
      )
    )
  ) STRICT;

  CREATE TABLE IF NOT EXISTS host_registry_state (
    singleton INTEGER PRIMARY KEY
      CHECK (singleton = 1),
    version INTEGER NOT NULL
      CHECK (version = 1),
    initialized_at TEXT NOT NULL
      CHECK (length(initialized_at) > 0)
  ) STRICT;

  CREATE TRIGGER IF NOT EXISTS host_registry_retain_local
  BEFORE DELETE ON host_registry
  WHEN OLD.id = 'local'
  BEGIN
    SELECT RAISE(ABORT, 'the local host is immutable');
  END;
`;var Ix=`
  CREATE TABLE IF NOT EXISTS kernel_armed_regions (
    canvas_name TEXT NOT NULL
      CHECK (
        length(canvas_name) BETWEEN 1 AND 64
        AND canvas_name GLOB '[a-z0-9]*'
        AND canvas_name NOT GLOB '*[^a-z0-9_-]*'
      ),
    region_id TEXT NOT NULL CHECK (length(region_id) BETWEEN 1 AND 1024),
    armed_at TEXT NOT NULL CHECK (length(armed_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, region_id)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS kernel_debug_pulses (
    position INTEGER PRIMARY KEY CHECK (position BETWEEN 0 AND 19),
    id TEXT NOT NULL CHECK (length(id) BETWEEN 1 AND 256),
    at_epoch_ms INTEGER NOT NULL CHECK (at_epoch_ms >= 0),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 64),
    source_node_id TEXT NOT NULL
      CHECK (length(source_node_id) BETWEEN 1 AND 1024),
    region_id TEXT CHECK (
      region_id IS NULL OR length(region_id) BETWEEN 1 AND 1024
    ),
    kind TEXT NOT NULL CHECK (kind IN ('watcher', 'timer', 'manual')),
    summary TEXT NOT NULL CHECK (length(summary) BETWEEN 1 AND 4096),
    delivered_json TEXT NOT NULL
      CHECK (
        json_valid(delivered_json)
        AND json_type(delivered_json) = 'array'
        AND length(CAST(delivered_json AS BLOB)) <= 65536
      ),
    dry INTEGER NOT NULL CHECK (dry IN (0, 1)),
    recorded_at TEXT NOT NULL CHECK (length(recorded_at) BETWEEN 1 AND 64)
  ) STRICT;
`;var xx=[`
    CREATE TABLE IF NOT EXISTS license_activation (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      record_version INTEGER NOT NULL
        CHECK (record_version = 1),
      activated_license_json TEXT NOT NULL
        CHECK (
          length(CAST(activated_license_json AS BLOB)) BETWEEN 2
            AND 16384
          AND json_valid(activated_license_json)
          AND json_type(activated_license_json) = 'object'
        ),
      updated_at TEXT NOT NULL
        CHECK (length(updated_at) BETWEEN 20 AND 64)
    ) STRICT, WITHOUT ROWID
  `],BG=`${xx.join(`;
`)};
`,Sx=[`
    CREATE TABLE IF NOT EXISTS license_entitlement (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      record_version INTEGER NOT NULL
        CHECK (record_version = 2),
      activated_license_json TEXT NOT NULL
        CHECK (
          length(CAST(activated_license_json AS BLOB)) BETWEEN 2
            AND 16384
          AND json_valid(activated_license_json)
          AND json_type(activated_license_json) = 'object'
        ),
      updated_at TEXT NOT NULL
        CHECK (length(updated_at) BETWEEN 20 AND 64)
    ) STRICT, WITHOUT ROWID
  `],VG=`${Sx.join(`;
`)};
`,f40=[...xx,...Sx],qU0=`${f40.join(`;
`)};
`;var vx=`
  CREATE TABLE IF NOT EXISTS factory_pause_canvases (
    canvas_name TEXT PRIMARY KEY
      CHECK (
        length(canvas_name) BETWEEN 1 AND 64
        AND canvas_name GLOB '[a-z0-9]*'
        AND canvas_name NOT GLOB '*[^a-z0-9_-]*'
      ),
    playing INTEGER NOT NULL CHECK (playing IN (0, 1)),
    ever_played INTEGER NOT NULL CHECK (ever_played IN (0, 1)),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS factory_pause_scopes (
    canvas_name TEXT NOT NULL
      REFERENCES factory_pause_canvases(canvas_name) ON DELETE CASCADE,
    scope_kind TEXT NOT NULL CHECK (scope_kind IN ('node', 'region')),
    scope_id TEXT NOT NULL CHECK (length(scope_id) BETWEEN 1 AND 1024),
    paused_at TEXT NOT NULL CHECK (length(paused_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, scope_kind, scope_id)
  ) STRICT, WITHOUT ROWID;
`;var kx=64;var bx=/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/;var gx=["command-center","remote"];var nU=1,yx=Z.Literals(["dark","bright","system"]),hx=Z.Literals(["comfortable","compact"]),G6=(X,Y)=>Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isBetween({minimum:X,maximum:Y}))),mx=Z.Literals(["follow","agent"]),sU=Z.Struct({theme:yx,density:hx,reduceMotion:Z.Boolean,agentAppearance:Z.optionalKey(mx)}),fx=Z.String.pipe(Z.check(Z.isMaxLength(kx)),Z.check(Z.isPattern(new RegExp(`^$|${bx.source}`)))),aU=Z.Struct({defaultCanvas:fx,showMinimap:Z.Boolean,fitOnOpen:Z.Boolean}),tU=Z.Struct({pulseLogRetention:Z.optionalKey(G6(5,500)),debugVerbose:Z.Boolean}),eU=Z.Struct({maxVisibleSurfaces:G6(1,_7),maxWarmSessions:G6(1,Z7)}),XD=Z.Struct({openLastCanvas:Z.Boolean,logsExplorer:Z.optionalKey(Z.Boolean)}),c9=(X)=>Z.String.pipe(Z.check(Z.isMaxLength(X))),d40=Z.Struct({enabled:Z.optionalKey(Z.Boolean),model:Z.optionalKey(c9(200)),effort:Z.optionalKey(c9(64)),permissionMode:Z.optionalKey(c9(64))}),YD=Z.Struct({byHarness:Z.Record(Z.String,d40)}),dx=Z.Literals(["fine","balanced","coarse"]),QD=Z.Struct({ditherLevel:dx,remoteManagedInstalls:Z.Boolean}),px=Z.Literals([...gx,""]),LG=Z.String.pipe(Z.check(Z.isMinLength(1)),Z.check(Z.isMaxLength(64)),Z.check(Z.isPattern(/^(?!-)[A-Za-z0-9][A-Za-z0-9._-]*$/))),jU0=Z.Unknown.pipe(Z.check(Z.makeFilter((X)=>!(X!==null&&typeof X==="object"&&!Array.isArray(X)&&Object.prototype.hasOwnProperty.call(X,"topologyIntegrity")),{message:"topologyIntegrity is retired and must not be supplied"}))),p40=Z.Struct({role:px,hostId:LG,agentHostId:Z.optionalKey(LG),supervisedPreferred:Z.Boolean}),JD=p40,OG=Z.Number.pipe(Z.check(Z.isBetween({minimum:0,maximum:1}))),zG=Z.Struct({enabled:Z.Boolean,volume:OG}),u40=Z.Struct({blocked:zG,permission:zG,orphan:zG,cycle:zG}),$D=Z.Struct({muted:Z.Boolean,masterVolume:OG,clips:u40}),ux=Z.Literals(["block","bar","underline"]),cx=Z.Literals(["off","visual","sound"]),l9=(X,Y)=>Z.Number.pipe(Z.check(Z.isBetween({minimum:X,maximum:Y}))),k0={scrollSensitivity:{min:1,max:20},fontSize:{min:6,max:48},scrollback:{min:100,max:50000},minimumContrastRatio:{min:1,max:21},lineHeight:{min:1,max:2},letterSpacing:{min:0,max:5},fontFamily:{minLength:1,maxLength:200}},lx=Z.String.pipe(Z.check(Z.isMinLength(k0.fontFamily.minLength)),Z.check(Z.isMaxLength(k0.fontFamily.maxLength))),GD=Z.Struct({scrollSensitivity:G6(k0.scrollSensitivity.min,k0.scrollSensitivity.max),fontSize:G6(k0.fontSize.min,k0.fontSize.max),fontFamily:lx,cursorStyle:ux,scrollback:G6(k0.scrollback.min,k0.scrollback.max),cursorBlink:Z.Boolean,minimumContrastRatio:l9(k0.minimumContrastRatio.min,k0.minimumContrastRatio.max),lineHeight:l9(k0.lineHeight.min,k0.lineHeight.max),letterSpacing:l9(k0.letterSpacing.min,k0.letterSpacing.max),screenReaderMode:Z.Boolean,bell:cx});var Z6=Z.String.pipe(Z.check(Z.isMaxLength(8192))),ox=Z.Struct({apiKey:Z.optionalKey(Z6),managementApiKey:Z.optionalKey(Z6)}),ix=Z.Struct({apiKey:Z.optionalKey(Z6)}),rx=Z.Struct({authToken:Z.optionalKey(Z6),apiKey:Z.optionalKey(Z6)}),nx=Z.Struct({bearerToken:Z.optionalKey(Z6),organizationId:Z.optionalKey(Z.String.pipe(Z.check(Z.isMaxLength(256))))}),sx=Z.Struct({apiKey:Z.optionalKey(Z6)}),ax=Z.Struct({token:Z.optionalKey(Z6)}),tx=Z.Struct({sessionCookie:Z.optionalKey(Z6),apiKey:Z.optionalKey(Z6)}),ex=Z.Struct({cookieHeader:Z.optionalKey(Z6)});var ZD=Z.Struct({openrouter:Z.optionalKey(ox),synthetic:Z.optionalKey(ix),kimi:Z.optionalKey(rx),devin:Z.optionalKey(nx),opencodeGo:Z.optionalKey(sx),copilot:Z.optionalKey(ax),ollama:Z.optionalKey(tx),cursor:Z.optionalKey(ex)});var IU0=Z.Struct({version:Z.Literal(nU),appearance:sU,canvas:aU,kernel:tU,browser:eU,advanced:XD,audio:$D,station:JD,fleet:QD,harnesses:Z.optionalKey(YD),terminal:Z.optionalKey(GD),providers:Z.optionalKey(ZD)}),c40=Z.Struct({theme:Z.optionalKey(yx),density:Z.optionalKey(hx),reduceMotion:Z.optionalKey(Z.Boolean),agentAppearance:Z.optionalKey(mx)}),l40=Z.Struct({defaultCanvas:Z.optionalKey(fx),showMinimap:Z.optionalKey(Z.Boolean),fitOnOpen:Z.optionalKey(Z.Boolean)}),o40=Z.Struct({debugVerbose:Z.optionalKey(Z.Boolean)}),i40=Z.Struct({maxVisibleSurfaces:Z.optionalKey(G6(1,_7)),maxWarmSessions:Z.optionalKey(G6(1,Z7))}),r40=Z.Struct({openLastCanvas:Z.optionalKey(Z.Boolean),logsExplorer:Z.optionalKey(Z.Boolean)}),n40=Z.Struct({scrollSensitivity:Z.optionalKey(G6(k0.scrollSensitivity.min,k0.scrollSensitivity.max)),fontSize:Z.optionalKey(G6(k0.fontSize.min,k0.fontSize.max)),fontFamily:Z.optionalKey(lx),cursorStyle:Z.optionalKey(ux),scrollback:Z.optionalKey(G6(k0.scrollback.min,k0.scrollback.max)),cursorBlink:Z.optionalKey(Z.Boolean),minimumContrastRatio:Z.optionalKey(l9(k0.minimumContrastRatio.min,k0.minimumContrastRatio.max)),lineHeight:Z.optionalKey(l9(k0.lineHeight.min,k0.lineHeight.max)),letterSpacing:Z.optionalKey(l9(k0.letterSpacing.min,k0.letterSpacing.max)),screenReaderMode:Z.optionalKey(Z.Boolean),bell:Z.optionalKey(cx)}),s40=Z.Struct({openrouter:Z.optionalKey(ox),synthetic:Z.optionalKey(ix),kimi:Z.optionalKey(rx),devin:Z.optionalKey(nx),opencodeGo:Z.optionalKey(sx),copilot:Z.optionalKey(ax),ollama:Z.optionalKey(tx),cursor:Z.optionalKey(ex)}),a40=Z.Struct({enabled:Z.optionalKey(Z.Boolean),model:Z.optionalKey(c9(200)),effort:Z.optionalKey(c9(64)),permissionMode:Z.optionalKey(c9(64))}),t40=Z.Struct({byHarness:Z.optionalKey(Z.Record(Z.String,a40))}),e40=Z.Struct({ditherLevel:Z.optionalKey(dx),remoteManagedInstalls:Z.optionalKey(Z.Boolean)}),X50=Z.Struct({role:Z.optionalKey(px),hostId:Z.optionalKey(LG),agentHostId:Z.optionalKey(LG),supervisedPreferred:Z.optionalKey(Z.Boolean)}),Y50=X50,qG=Z.Struct({enabled:Z.optionalKey(Z.Boolean),volume:Z.optionalKey(OG)}),Q50=Z.Struct({blocked:Z.optionalKey(qG),permission:Z.optionalKey(qG),orphan:Z.optionalKey(qG),cycle:Z.optionalKey(qG)}),J50=Z.Struct({muted:Z.optionalKey(Z.Boolean),masterVolume:Z.optionalKey(OG),clips:Z.optionalKey(Q50)}),xU0=Z.Struct({appearance:Z.optionalKey(c40),canvas:Z.optionalKey(l40),kernel:Z.optionalKey(o40),browser:Z.optionalKey(i40),advanced:Z.optionalKey(r40),audio:Z.optionalKey(J50),station:Z.optionalKey(Y50),fleet:Z.optionalKey(e40),harnesses:Z.optionalKey(t40),terminal:Z.optionalKey(n40),providers:Z.optionalKey(s40)}),SU0=Z.Literals(["appearance","canvas","kernel","browser","advanced","audio","station","fleet","harnesses","terminal","providers"]);var $50=Z.Literals(["validation","io","corrupt","unsupported"]);class XS extends Z.TaggedErrorClass()("SettingsError",{message:Z.String,code:$50}){}var YS=`
  CREATE TABLE IF NOT EXISTS settings_preferences (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    version INTEGER NOT NULL CHECK (version = ${nU}),
    body TEXT NOT NULL
      CHECK (
        json_valid(body)
        AND json_type(body) = 'object'
        AND length(CAST(body AS BLOB)) <= 65536
      ),
    updated_at TEXT NOT NULL CHECK (length(updated_at) > 0)
  ) STRICT;

  CREATE TABLE IF NOT EXISTS settings_initialization (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    initialized_at TEXT NOT NULL CHECK (length(initialized_at) > 0)
  ) STRICT;
`,G50=Z.Struct({appearance:sU,canvas:aU,kernel:tU,browser:eU,advanced:XD,audio:$D,fleet:QD,harnesses:Z.optionalKey(YD),terminal:Z.optionalKey(GD),providers:Z.optionalKey(ZD)}),mU0=Z.decodeUnknownResult(G50,{onExcessProperty:"error"}),fU0=Z.decodeUnknownResult(JD,{onExcessProperty:"error"});var QS=`
  CREATE TABLE IF NOT EXISTS scheduler_interval_state (
    home_station TEXT NOT NULL
      CHECK (
        length(home_station) BETWEEN 1 AND 64
        AND substr(home_station, 1, 1) <> '-'
        AND home_station GLOB '[A-Za-z0-9]*'
        AND home_station NOT GLOB '*[^A-Za-z0-9._-]*'
      ),
    timer_key TEXT NOT NULL CHECK (length(timer_key) BETWEEN 1 AND 512),
    schedule_id TEXT NOT NULL CHECK (length(schedule_id) BETWEEN 1 AND 256),
    interval_milliseconds INTEGER NOT NULL
      CHECK (interval_milliseconds > 0),
    catch_up_policy TEXT NOT NULL
      CHECK (catch_up_policy = 'coalesce-latest'),
    next_due_at_epoch_ms INTEGER NOT NULL
      CHECK (next_due_at_epoch_ms >= 0),
    next_due_slot TEXT NOT NULL
      CHECK (
        length(next_due_slot) > 0
        AND next_due_slot NOT GLOB '*[^0-9]*'
        AND (
          next_due_slot = '0'
          OR substr(next_due_slot, 1, 1) <> '0'
        )
      ),
    last_fired_slot TEXT
      CHECK (
        last_fired_slot IS NULL
        OR (
          length(last_fired_slot) > 0
          AND last_fired_slot NOT GLOB '*[^0-9]*'
          AND (
            last_fired_slot = '0'
            OR substr(last_fired_slot, 1, 1) <> '0'
          )
        )
      ),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (home_station, timer_key)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS scheduler_interval_firings (
    home_station TEXT NOT NULL
      CHECK (length(home_station) BETWEEN 1 AND 64),
    timer_key TEXT NOT NULL CHECK (length(timer_key) BETWEEN 1 AND 512),
    schedule_id TEXT NOT NULL CHECK (length(schedule_id) BETWEEN 1 AND 256),
    catch_up_policy TEXT NOT NULL
      CHECK (catch_up_policy = 'coalesce-latest'),
    claim_slot TEXT NOT NULL
      CHECK (
        length(claim_slot) > 0
        AND claim_slot NOT GLOB '*[^0-9]*'
        AND (
          claim_slot = '0'
          OR substr(claim_slot, 1, 1) <> '0'
        )
      ),
    due_slot TEXT NOT NULL
      CHECK (
        length(due_slot) > 0
        AND due_slot NOT GLOB '*[^0-9]*'
        AND (
          due_slot = '0'
          OR substr(due_slot, 1, 1) <> '0'
        )
      ),
    scheduled_for_epoch_ms INTEGER NOT NULL
      CHECK (scheduled_for_epoch_ms >= 0),
    observed_at_epoch_ms INTEGER NOT NULL
      CHECK (observed_at_epoch_ms >= 0),
    coalesced_missed_slots TEXT NOT NULL
      CHECK (
        length(coalesced_missed_slots) > 0
        AND coalesced_missed_slots NOT GLOB '*[^0-9]*'
        AND (
          coalesced_missed_slots = '0'
          OR substr(coalesced_missed_slots, 1, 1) <> '0'
        )
      ),
    claimed_at TEXT NOT NULL CHECK (length(claimed_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      home_station,
      timer_key,
      schedule_id,
      claim_slot
    )
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS scheduler_interval_due
    ON scheduler_interval_state(
      home_station,
      next_due_at_epoch_ms,
      timer_key
    );
`;var Z50=[`
    CREATE TABLE IF NOT EXISTS station_known_installations (
      installation_id TEXT PRIMARY KEY
        CHECK (
          length(installation_id) BETWEEN 1 AND 128
          AND installation_id GLOB '[A-Za-z0-9]*'
          AND installation_id NOT GLOB '*[^A-Za-z0-9._:-]*'
        ),
      registered_at TEXT NOT NULL
        CHECK (length(registered_at) BETWEEN 1 AND 64)
    ) STRICT, WITHOUT ROWID
  `,`
    CREATE TABLE IF NOT EXISTS station_installation (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      installation_id TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL
        CHECK (length(created_at) BETWEEN 1 AND 64),
      FOREIGN KEY (installation_id)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT
  `,`
    CREATE TABLE IF NOT EXISTS station_pairing (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      command_center_installation_id TEXT NOT NULL,
      station_label TEXT NOT NULL
        CHECK (length(station_label) BETWEEN 1 AND 128),
      app_version TEXT NOT NULL
        CHECK (length(app_version) BETWEEN 1 AND 64),
      paired_at TEXT NOT NULL
        CHECK (length(paired_at) BETWEEN 1 AND 64),
      FOREIGN KEY (command_center_installation_id)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT
  `,`
    CREATE TABLE IF NOT EXISTS station_configuration (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      role TEXT NOT NULL
        CHECK (role IN ('command-center', 'remote')),
      host_id TEXT NOT NULL CHECK (length(host_id) BETWEEN 1 AND 64),
      agent_host_id TEXT,
      command_center_installation_id TEXT,
      supervised_preferred INTEGER NOT NULL
        CHECK (supervised_preferred IN (0, 1)),
      configured_at TEXT NOT NULL
        CHECK (length(configured_at) BETWEEN 1 AND 64),
      CHECK (
        (
          role = 'command-center'
          AND agent_host_id IS NULL
          AND command_center_installation_id IS NULL
        )
        OR
        (
          role = 'remote'
          AND agent_host_id IS NOT NULL
          AND length(agent_host_id) BETWEEN 1 AND 64
          AND command_center_installation_id IS NOT NULL
        )
      ),
      FOREIGN KEY (command_center_installation_id)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT
  `,`
    CREATE TABLE IF NOT EXISTS station_projection_versions (
      generation TEXT NOT NULL
        CHECK (
          length(generation) BETWEEN 1 AND 32
          AND generation NOT GLOB '*[^0-9]*'
          AND (generation = '0' OR substr(generation, 1, 1) <> '0')
        ),
      content_sha256 TEXT NOT NULL
        CHECK (
          length(content_sha256) = 64
          AND content_sha256 NOT GLOB '*[^a-f0-9]*'
        ),
      source_canvas_generation TEXT NOT NULL
        CHECK (
          length(source_canvas_generation) BETWEEN 1 AND 32
          AND source_canvas_generation NOT GLOB '*[^0-9]*'
          AND (
            source_canvas_generation = '0'
            OR substr(source_canvas_generation, 1, 1) <> '0'
          )
        ),
      source_intent_sha256 TEXT NOT NULL
        CHECK (
          length(source_intent_sha256) = 64
          AND source_intent_sha256 NOT GLOB '*[^a-f0-9]*'
        ),
      body TEXT NOT NULL
        CHECK (length(body) BETWEEN 1 AND 67108864),
      created_at TEXT NOT NULL
        CHECK (length(created_at) BETWEEN 1 AND 64),
      received_at TEXT NOT NULL
        CHECK (length(received_at) BETWEEN 1 AND 64),
      PRIMARY KEY (generation),
      UNIQUE (generation, content_sha256)
    ) STRICT, WITHOUT ROWID
  `,`
    CREATE TABLE IF NOT EXISTS station_projection_head (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      generation TEXT NOT NULL,
      content_sha256 TEXT NOT NULL,
      FOREIGN KEY (generation, content_sha256)
        REFERENCES station_projection_versions(
          generation,
          content_sha256
        )
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT
  `,`
    CREATE TABLE IF NOT EXISTS station_received_cursors (
      event_home TEXT NOT NULL,
      entity_home TEXT NOT NULL,
      through_sequence TEXT NOT NULL
        CHECK (
          length(through_sequence) BETWEEN 1 AND 32
          AND through_sequence NOT GLOB '*[^0-9]*'
          AND substr(through_sequence, 1, 1) <> '0'
        ),
      updated_at TEXT NOT NULL
        CHECK (length(updated_at) BETWEEN 1 AND 64),
      PRIMARY KEY (event_home, entity_home),
      FOREIGN KEY (event_home)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
      FOREIGN KEY (entity_home)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT, WITHOUT ROWID
  `,`
    CREATE TABLE IF NOT EXISTS station_peer_ack_cursors (
      peer_installation_id TEXT NOT NULL,
      event_home TEXT NOT NULL,
      entity_home TEXT NOT NULL,
      through_sequence TEXT NOT NULL
        CHECK (
          length(through_sequence) BETWEEN 1 AND 32
          AND through_sequence NOT GLOB '*[^0-9]*'
          AND substr(through_sequence, 1, 1) <> '0'
        ),
      acknowledged_at TEXT NOT NULL
        CHECK (length(acknowledged_at) BETWEEN 1 AND 64),
      PRIMARY KEY (
        peer_installation_id,
        event_home,
        entity_home
      ),
      CHECK (peer_installation_id <> event_home),
      FOREIGN KEY (peer_installation_id)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
      FOREIGN KEY (event_home)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
      FOREIGN KEY (entity_home)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT, WITHOUT ROWID
  `,`
    CREATE TABLE IF NOT EXISTS station_fleet_targets (
      host_id TEXT PRIMARY KEY
        CHECK (
          length(host_id) BETWEEN 1 AND 64
          AND substr(host_id, 1, 1) <> '-'
          AND host_id GLOB '[A-Za-z0-9]*'
          AND host_id NOT GLOB '*[^A-Za-z0-9._-]*'
        ),
      station_installation_id TEXT NOT NULL UNIQUE,
      bound_at TEXT NOT NULL
        CHECK (length(bound_at) BETWEEN 1 AND 64),
      retired_at TEXT
        CHECK (
          retired_at IS NULL
          OR length(retired_at) BETWEEN 1 AND 64
        ),
      FOREIGN KEY (station_installation_id)
        REFERENCES station_known_installations(installation_id)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
    ) STRICT, WITHOUT ROWID
  `,`
    CREATE TRIGGER IF NOT EXISTS station_known_installation_identity_immutable
    BEFORE UPDATE OF installation_id ON station_known_installations
    WHEN OLD.installation_id <> NEW.installation_id
    BEGIN
      SELECT RAISE(ABORT, 'known installation identity is immutable');
    END
  `,`
    CREATE TRIGGER IF NOT EXISTS station_local_installation_identity_immutable
    BEFORE UPDATE OF installation_id ON station_installation
    WHEN OLD.installation_id <> NEW.installation_id
    BEGIN
      SELECT RAISE(ABORT, 'local installation identity is immutable');
    END
  `,`
    CREATE TRIGGER IF NOT EXISTS station_projection_version_immutable_update
    BEFORE UPDATE ON station_projection_versions
    BEGIN
      SELECT RAISE(ABORT, 'station projection versions are immutable');
    END
  `,`
    CREATE TRIGGER IF NOT EXISTS station_projection_version_immutable_delete
    BEFORE DELETE ON station_projection_versions
    BEGIN
      SELECT RAISE(ABORT, 'station projection versions are immutable');
    END
  `],JS=`${Z50.join(`;
`)};`;var _50=[`
    CREATE TABLE IF NOT EXISTS station_status_facts (
      kind TEXT NOT NULL
        CHECK (
          kind IN (
            'kernel',
            'deployment'
          )
        ),
      host_id TEXT NOT NULL CHECK (length(host_id) <= 64),
      record_json TEXT NOT NULL
        CHECK (
          json_valid(record_json)
          AND json_type(record_json) = 'object'
        ),
      updated_at TEXT NOT NULL CHECK (length(updated_at) > 0),
      PRIMARY KEY (kind, host_id),
      CHECK (
        (kind = 'kernel' AND host_id = '')
        OR (kind = 'deployment' AND length(host_id) > 0)
      )
    ) STRICT, WITHOUT ROWID
  `],$S=`${_50.join(`;
`)};
`;var GS=`
  CREATE TABLE IF NOT EXISTS usage_state (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    snapshots_json TEXT NOT NULL
      CHECK (
        json_valid(snapshots_json)
        AND json_type(snapshots_json) = 'array'
      ),
    last_live_at TEXT NOT NULL CHECK (length(last_live_at) > 0),
    updated_at TEXT NOT NULL CHECK (length(updated_at) > 0)
  ) STRICT;
`;var TG=`
  -- Immutable verified object identity. Media type / display name live on
  -- content_refs (descriptive metadata is not part of byte identity).
  CREATE TABLE IF NOT EXISTS content_objects (
    sha256 TEXT PRIMARY KEY
      CHECK (
        length(sha256) = 64
        AND sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    byte_length INTEGER NOT NULL
      CHECK (
        typeof(byte_length) = 'integer'
        AND byte_length >= 0
      ),
    created_at TEXT NOT NULL
      CHECK (length(created_at) BETWEEN 1 AND 64),
    verified_at TEXT NOT NULL
      CHECK (length(verified_at) BETWEEN 1 AND 64)
  ) STRICT, WITHOUT ROWID;

  -- Portable references bound to durable work after the object exists.
  CREATE TABLE IF NOT EXISTS content_refs (
    ref_id TEXT PRIMARY KEY
      CHECK (length(ref_id) BETWEEN 1 AND 256),
    sha256 TEXT NOT NULL
      CHECK (
        length(sha256) = 64
        AND sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    byte_length INTEGER NOT NULL
      CHECK (
        typeof(byte_length) = 'integer'
        AND byte_length >= 0
      ),
    media_type TEXT NOT NULL
      CHECK (length(media_type) BETWEEN 1 AND 255),
    display_name TEXT
      CHECK (
        display_name IS NULL
        OR length(display_name) BETWEEN 1 AND 255
      ),
    owner_kind TEXT NOT NULL
      CHECK (
        owner_kind IN (
          'task',
          'message',
          'artifact',
          'board_topic',
          'board_post',
          'other'
        )
      ),
    owner_canvas TEXT NOT NULL
      CHECK (length(owner_canvas) BETWEEN 1 AND 256),
    owner_node TEXT NOT NULL
      CHECK (length(owner_node) BETWEEN 1 AND 256),
    owner_record_id TEXT NOT NULL
      CHECK (length(owner_record_id) BETWEEN 1 AND 256),
    created_at TEXT NOT NULL
      CHECK (length(created_at) BETWEEN 1 AND 64),
    FOREIGN KEY (sha256)
      REFERENCES content_objects(sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS content_refs_by_object
    ON content_refs(sha256, created_at, ref_id);

  CREATE INDEX IF NOT EXISTS content_refs_by_owner
    ON content_refs(owner_canvas, owner_node, owner_kind, owner_record_id);

  -- Verification receipts. Only the verified state is durable here; missing /
  -- corrupt / unavailable are computed at read time from object + file state.
  CREATE TABLE IF NOT EXISTS content_receipts (
    sha256 TEXT PRIMARY KEY
      CHECK (
        length(sha256) = 64
        AND sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    verified_sha256 TEXT NOT NULL
      CHECK (
        length(verified_sha256) = 64
        AND verified_sha256 NOT GLOB '*[^a-f0-9]*'
        AND verified_sha256 = sha256
      ),
    verified_byte_length INTEGER NOT NULL
      CHECK (
        typeof(verified_byte_length) = 'integer'
        AND verified_byte_length >= 0
      ),
    verified_at TEXT NOT NULL
      CHECK (length(verified_at) BETWEEN 1 AND 64),
    FOREIGN KEY (sha256)
      REFERENCES content_objects(sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  -- Transfer bookkeeping for a future cross-Station data plane. Local ingest
  -- does not require rows; schema exists so the next migration is not blocked.
  CREATE TABLE IF NOT EXISTS content_transfers (
    transfer_id TEXT PRIMARY KEY
      CHECK (length(transfer_id) BETWEEN 1 AND 256),
    sha256 TEXT NOT NULL
      CHECK (
        length(sha256) = 64
        AND sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    byte_length INTEGER NOT NULL
      CHECK (
        typeof(byte_length) = 'integer'
        AND byte_length >= 0
      ),
    state TEXT NOT NULL
      CHECK (
        state IN (
          'pending',
          'receiving',
          'verifying',
          'complete',
          'failed',
          'canceled'
        )
      ),
    direction TEXT NOT NULL
      CHECK (direction IN ('inbound', 'outbound')),
    peer_installation_id TEXT
      CHECK (
        peer_installation_id IS NULL
        OR length(peer_installation_id) BETWEEN 1 AND 128
      ),
    error_reason TEXT
      CHECK (
        error_reason IS NULL
        OR length(error_reason) BETWEEN 1 AND 1024
      ),
    created_at TEXT NOT NULL
      CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL
      CHECK (length(updated_at) BETWEEN 1 AND 64)
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS content_transfers_by_object
    ON content_transfers(sha256, state, updated_at);
`,FG=`
  CREATE TABLE IF NOT EXISTS content_inline_media_migration (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    status TEXT NOT NULL
      CHECK (status IN ('pending', 'complete')),
    objects_ingested INTEGER NOT NULL DEFAULT 0
      CHECK (
        typeof(objects_ingested) = 'integer'
        AND objects_ingested >= 0
      ),
    completed_at TEXT
      CHECK (
        completed_at IS NULL
        OR length(completed_at) BETWEEN 1 AND 64
      )
  ) STRICT;
`;var ZS=`
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;
`,_D=`
  CREATE TABLE IF NOT EXISTS work_event_sequences (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    last_seq TEXT NOT NULL
      CHECK (
        length(last_seq) BETWEEN 1 AND 32
        AND last_seq NOT GLOB '*[^0-9]*'
        AND (last_seq = '0' OR substr(last_seq, 1, 1) <> '0')
      ),
    PRIMARY KEY (event_home, entity_home),
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    protocol TEXT NOT NULL CHECK (protocol = 'vellum/work/v2'),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, record_type),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'command'
      CHECK (record_type = 'command'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    action_json TEXT NOT NULL
      CHECK (
        length(action_json) BETWEEN 2 AND 262144
        AND json_valid(action_json)
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home <> entity_home),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_facts (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'fact'
      CHECK (record_type = 'fact'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    result_json TEXT NOT NULL
      CHECK (
        length(result_json) BETWEEN 2 AND 262144
        AND json_valid(result_json)
      ),
    basis_kind TEXT NOT NULL
      CHECK (
        basis_kind IN (
          'authorial-intent',
          'projected-intent',
          'command'
        )
      ),
    basis_authorial_generation TEXT
      CHECK (
        basis_authorial_generation IS NULL
        OR (
          length(basis_authorial_generation) BETWEEN 1 AND 32
          AND basis_authorial_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_authorial_generation = '0'
            OR substr(basis_authorial_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_authorial_content_sha256 TEXT
      CHECK (
        basis_authorial_content_sha256 IS NULL
        OR (
          length(basis_authorial_content_sha256) = 64
          AND basis_authorial_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_projected_generation TEXT
      CHECK (
        basis_projected_generation IS NULL
        OR (
          length(basis_projected_generation) BETWEEN 1 AND 32
          AND basis_projected_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_projected_generation = '0'
            OR substr(basis_projected_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_projected_content_sha256 TEXT
      CHECK (
        basis_projected_content_sha256 IS NULL
        OR (
          length(basis_projected_content_sha256) = 64
          AND basis_projected_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_command_event_home TEXT,
    basis_command_entity_home TEXT,
    basis_command_seq TEXT
      CHECK (
        basis_command_seq IS NULL
        OR (
          length(basis_command_seq) BETWEEN 1 AND 32
          AND basis_command_seq NOT GLOB '*[^0-9]*'
          AND substr(basis_command_seq, 1, 1) <> '0'
        )
      ),
    basis_command_sha256 TEXT
      CHECK (
        basis_command_sha256 IS NULL
        OR (
          length(basis_command_sha256) = 64
          AND basis_command_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home = entity_home),
    CHECK (
      (
        basis_kind = 'authorial-intent'
        AND basis_authorial_generation IS NOT NULL
        AND basis_authorial_content_sha256 IS NOT NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'projected-intent'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NOT NULL
        AND basis_projected_content_sha256 IS NOT NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'command'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NOT NULL
        AND basis_command_entity_home IS NOT NULL
        AND basis_command_seq IS NOT NULL
        AND basis_command_sha256 IS NOT NULL
        AND basis_command_entity_home = entity_home
      )
    ),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (basis_authorial_generation)
      REFERENCES canvas_generations(generation)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_projected_generation,
      basis_projected_content_sha256
    ) REFERENCES station_projection_versions(generation, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq
    ) REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq,
      basis_command_sha256
    ) REFERENCES work_events(
      event_home,
      entity_home,
      seq,
      content_sha256
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_dispositions (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'disposition'
      CHECK (record_type = 'disposition'),
    status TEXT NOT NULL CHECK (status IN ('applied', 'rejected')),
    command_event_home TEXT NOT NULL,
    command_entity_home TEXT NOT NULL,
    command_seq TEXT NOT NULL,
    command_sha256 TEXT NOT NULL
      CHECK (
        length(command_sha256) = 64
        AND command_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT,
    fact_entity_home TEXT,
    fact_seq TEXT,
    fact_sha256 TEXT
      CHECK (
        fact_sha256 IS NULL
        OR (
          length(fact_sha256) = 64
          AND fact_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    rejection_reason TEXT
      CHECK (
        rejection_reason IS NULL
        OR rejection_reason IN (
          'authority-mismatch',
          'capability-denied',
          'causal-conflict',
          'claim-contention',
          'identity-conflict',
          'invalid-transition',
          'locality-mismatch',
          'missing-entity',
          'projection-conflict',
          'target-mismatch'
        )
      ),
    rejection_message TEXT
      CHECK (
        rejection_message IS NULL
        OR length(rejection_message) BETWEEN 1 AND 2048
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, status),
    CHECK (event_home = entity_home),
    CHECK (command_entity_home = entity_home),
    CHECK (
      (
        status = 'applied'
        AND fact_event_home IS NOT NULL
        AND fact_entity_home IS NOT NULL
        AND fact_seq IS NOT NULL
        AND fact_sha256 IS NOT NULL
        AND fact_event_home = event_home
        AND fact_entity_home = entity_home
        AND rejection_reason IS NULL
        AND rejection_message IS NULL
      )
      OR
      (
        status = 'rejected'
        AND fact_event_home IS NULL
        AND fact_entity_home IS NULL
        AND fact_seq IS NULL
        AND fact_sha256 IS NULL
        AND rejection_reason IS NOT NULL
        AND rejection_message IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (command_event_home, command_entity_home, command_seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      command_event_home,
      command_entity_home,
      command_seq,
      command_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      fact_event_home,
      fact_entity_home,
      fact_seq,
      fact_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    claim_actor_seat_id TEXT
      CHECK (
        claim_actor_seat_id IS NULL
        OR (
          length(claim_actor_seat_id) = 69
          AND substr(claim_actor_seat_id, 1, 5) = 'seat_'
          AND substr(claim_actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT
      CHECK (resolved_at IS NULL OR length(resolved_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        operation = 'task.claim'
        AND item_kind = 'task'
        AND claim_actor_seat_id IS NOT NULL
      )
      OR
      (
        operation <> 'task.claim'
        AND claim_actor_seat_id IS NULL
      )
    ),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      resolution_event_home,
      resolution_entity_home,
      resolution_seq,
      resolution_status
    ) REFERENCES work_dispositions(event_home, entity_home, seq, status)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_tasks (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    task_id TEXT NOT NULL CHECK (length(task_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, task_id),
    UNIQUE (canvas_name, node_id, task_id, entity_home),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'submitted' AND actor_seat_id IS NULL)
      OR state IN ('completed', 'canceled', 'failed', 'rejected')
      OR (
        state IN ('working', 'input-required', 'auth-required')
        AND actor_seat_id IS NOT NULL
      )
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_requests (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    request_id TEXT NOT NULL CHECK (length(request_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'input-required',
          'auth-required',
          'completed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, request_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    parent_lane TEXT NOT NULL CHECK (parent_lane IN ('task', 'request')),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    message_kind TEXT NOT NULL CHECK (message_kind IN ('brief', 'history')),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      message_id
    ),
    UNIQUE (canvas_name, node_id, parent_lane, item_id, position),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, message_id),
    UNIQUE (canvas_name, node_id, position),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_artifacts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    artifact_id TEXT NOT NULL CHECK (length(artifact_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    name TEXT,
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_canvas_name TEXT
      CHECK (
        task_canvas_name IS NULL
        OR length(task_canvas_name) BETWEEN 1 AND 256
      ),
    task_node_id TEXT
      CHECK (
        task_node_id IS NULL
        OR length(task_node_id) BETWEEN 1 AND 256
      ),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    task_entity_home TEXT,
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, artifact_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (
        task_canvas_name IS NULL
        AND task_node_id IS NULL
        AND task_id IS NULL
        AND task_entity_home IS NULL
      )
      OR
      (
        task_canvas_name IS NOT NULL
        AND task_node_id IS NOT NULL
        AND task_id IS NOT NULL
        AND task_entity_home IS NOT NULL
      )
    ),
    CHECK (
      task_entity_home IS NULL
      OR task_entity_home = entity_home
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      task_canvas_name,
      task_node_id,
      task_id,
      task_entity_home
    ) REFERENCES work_tasks(
      canvas_name,
      node_id,
      task_id,
      entity_home
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_transitions (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    lane TEXT NOT NULL CHECK (lane IN ('task', 'request')),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve'
        )
      ),
    from_state TEXT,
    to_state TEXT NOT NULL
      CHECK (
        to_state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, item_id, lane, ordinal),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (
      from_state IS NULL
      OR from_state IN (
        'submitted',
        'working',
        'input-required',
        'auth-required',
        'completed',
        'canceled',
        'failed',
        'rejected'
      )
    ),
    CHECK (
      to_state NOT IN ('working', 'input-required', 'auth-required')
      OR actor_seat_id IS NOT NULL
    ),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_delivery_receipts (
    delivery_id TEXT NOT NULL CHECK (length(delivery_id) BETWEEN 1 AND 256),
    delivered_item_kind TEXT NOT NULL
      CHECK (
        delivered_item_kind IN (
          'task',
          'request',
          'message',
          'artifact',
          'delivery'
        )
      ),
    delivered_item_id TEXT NOT NULL
      CHECK (length(delivered_item_id) BETWEEN 1 AND 256),
    delivered_canvas_name TEXT NOT NULL
      CHECK (length(delivered_canvas_name) BETWEEN 1 AND 256),
    delivered_node_id TEXT NOT NULL
      CHECK (length(delivered_node_id) BETWEEN 1 AND 256),
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    actor_canvas_name TEXT NOT NULL
      CHECK (length(actor_canvas_name) BETWEEN 1 AND 256),
    actor_node_id TEXT NOT NULL
      CHECK (length(actor_node_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    accepted_at TEXT NOT NULL CHECK (length(accepted_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      delivered_canvas_name,
      delivered_node_id,
      delivery_id
    ),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_events_route_order
    ON work_events(event_home, entity_home, length(seq), seq);
  CREATE INDEX IF NOT EXISTS work_events_item_history
    ON work_events(
      item_canvas_name,
      item_node_id,
      item_kind,
      item_id,
      entity_home,
      length(seq),
      seq
    );
  CREATE INDEX IF NOT EXISTS work_pending_commands_route
    ON work_pending_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_item
    ON work_pending_commands(
      item_canvas_name,
      item_node_id,
      item_id
    )
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_actor
    ON work_pending_commands(claim_actor_seat_id)
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE INDEX IF NOT EXISTS work_tasks_node
    ON work_tasks(canvas_name, node_id, created_at, task_id);
  CREATE UNIQUE INDEX IF NOT EXISTS work_tasks_one_active_per_actor
    ON work_tasks(actor_seat_id)
    WHERE
      actor_seat_id IS NOT NULL
      AND state IN ('working', 'input-required', 'auth-required');
  CREATE INDEX IF NOT EXISTS work_requests_node
    ON work_requests(canvas_name, node_id, created_at, request_id);
  CREATE INDEX IF NOT EXISTS work_task_messages_thread
    ON work_task_messages(
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      position
    );
  CREATE UNIQUE INDEX IF NOT EXISTS work_task_messages_sink_identity
    ON work_task_messages(canvas_name, node_id, message_id);
  CREATE INDEX IF NOT EXISTS work_messages_inbox
    ON work_messages(canvas_name, node_id, position);
  CREATE INDEX IF NOT EXISTS work_artifacts_node
    ON work_artifacts(canvas_name, node_id, artifact_id);
  CREATE INDEX IF NOT EXISTS work_delivery_receipts_actor
    ON work_delivery_receipts(
      actor_seat_id,
      accepted_at,
      delivery_id
    );

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_update
  BEFORE UPDATE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_delete
  BEFORE DELETE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_update
  BEFORE UPDATE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_delete
  BEFORE DELETE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_fact_authorial_basis_resolves
  BEFORE INSERT ON work_facts
  WHEN
    NEW.basis_kind = 'authorial-intent'
    AND NOT EXISTS (
      SELECT 1
      FROM canvas_generations AS generation
      JOIN canvas_generation_documents AS document
        ON document.generation = generation.generation
      JOIN work_events AS record
        ON record.event_home = NEW.event_home
        AND record.entity_home = NEW.entity_home
        AND record.seq = NEW.seq
      WHERE generation.generation = NEW.basis_authorial_generation
        AND generation.intent_sha256 =
          NEW.basis_authorial_content_sha256
        AND document.name = record.item_canvas_name
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'authorial fact basis must resolve its exact sink canvas generation'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_update
  BEFORE UPDATE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_delete
  BEFORE DELETE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_applied_disposition_fact_basis_matches
  BEFORE INSERT ON work_dispositions
  WHEN
    NEW.status = 'applied'
    AND NOT EXISTS (
      SELECT 1
      FROM work_facts AS fact
      WHERE fact.event_home = NEW.fact_event_home
        AND fact.entity_home = NEW.fact_entity_home
        AND fact.seq = NEW.fact_seq
        AND fact.basis_kind = 'command'
        AND fact.basis_command_event_home = NEW.command_event_home
        AND fact.basis_command_entity_home = NEW.command_entity_home
        AND fact.basis_command_seq = NEW.command_seq
        AND fact.basis_command_sha256 = NEW.command_sha256
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'applied disposition fact must carry its exact command basis'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_update
  BEFORE UPDATE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_delete
  BEFORE DELETE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_matches_record
  BEFORE INSERT ON work_pending_commands
  WHEN NOT EXISTS (
    SELECT 1
    FROM work_events AS record
    WHERE record.event_home = NEW.event_home
      AND record.entity_home = NEW.entity_home
      AND record.seq = NEW.seq
      AND record.record_type = 'command'
      AND record.operation = NEW.operation
      AND record.item_kind = NEW.item_kind
      AND record.item_canvas_name = NEW.item_canvas_name
      AND record.item_node_id = NEW.item_node_id
      AND record.item_id = NEW.item_id
  )
  BEGIN
    SELECT RAISE(ABORT, 'pending command metadata must match its Work command');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_identity_immutable
  BEFORE UPDATE OF
    event_home,
    entity_home,
    seq,
    operation,
    item_kind,
    item_canvas_name,
    item_node_id,
    item_id,
    claim_actor_seat_id
  ON work_pending_commands
  WHEN
    OLD.event_home IS NOT NEW.event_home
    OR OLD.entity_home IS NOT NEW.entity_home
    OR OLD.seq IS NOT NEW.seq
    OR OLD.operation IS NOT NEW.operation
    OR OLD.item_kind IS NOT NEW.item_kind
    OR OLD.item_canvas_name IS NOT NEW.item_canvas_name
    OR OLD.item_node_id IS NOT NEW.item_node_id
    OR OLD.item_id IS NOT NEW.item_id
    OR OLD.claim_actor_seat_id IS NOT NEW.claim_actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'pending command identity is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_initial_resolution_matches
  BEFORE INSERT ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = NEW.event_home
        AND disposition.command_entity_home = NEW.entity_home
        AND disposition.command_seq = NEW.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_matches
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = OLD.event_home
        AND disposition.command_entity_home = OLD.entity_home
        AND disposition.command_seq = OLD.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_once
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    OLD.resolution_event_home IS NOT NULL
    AND (
      OLD.resolution_status IS NOT NEW.resolution_status
      OR OLD.resolution_event_home IS NOT NEW.resolution_event_home
      OR OLD.resolution_entity_home IS NOT NEW.resolution_entity_home
      OR OLD.resolution_seq IS NOT NEW.resolution_seq
      OR OLD.resolved_at IS NOT NEW.resolved_at
    )
  BEGIN
    SELECT RAISE(ABORT, 'pending command resolution is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_home_immutable
  BEFORE UPDATE OF entity_home ON work_tasks
  WHEN
    OLD.entity_home <> NEW.entity_home
    AND NOT (
      OLD.state = 'submitted'
      AND OLD.actor_seat_id IS NULL
      AND NEW.state = 'working'
      AND NEW.actor_seat_id IS NOT NULL
      AND NEW.entity_home = NEW.fact_entity_home
      AND NEW.fact_event_home = NEW.fact_entity_home
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task home is immutable except for first claim adoption'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_tasks
  WHEN
    OLD.actor_seat_id IS NOT NULL
    AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
    AND NOT (
      NEW.actor_seat_id IS NULL
      AND NEW.state = 'submitted'
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task actor seat is immutable except for operator release'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_home_immutable
  BEFORE UPDATE OF entity_home ON work_requests
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work request home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_requests
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work request actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work task message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_require_exact_parent
  BEFORE INSERT ON work_task_messages
  WHEN NOT (
    (
      NEW.parent_lane = 'task'
      AND EXISTS (
        SELECT 1
        FROM work_tasks
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND task_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
    OR
    (
      NEW.parent_lane = 'request'
      AND EXISTS (
        SELECT 1
        FROM work_requests
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND request_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
  )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task message requires an exact same-home parent'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_require_cc_home
  BEFORE INSERT ON work_messages
  WHEN
    NOT EXISTS (
      SELECT 1
      FROM station_configuration AS configuration
      JOIN station_installation AS installation
        ON installation.singleton = configuration.singleton
      WHERE configuration.singleton = 1
        AND configuration.role = 'command-center'
        AND NEW.entity_home = installation.installation_id
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work mailbox messages must be Command Center-homed'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_messages
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work message actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_home_immutable
  BEFORE UPDATE OF entity_home ON work_artifacts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_artifacts
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work artifact actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_require_claimed_task
  BEFORE INSERT ON work_artifacts
  WHEN
    NEW.task_id IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
    )
    AND NOT EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
        AND actor_seat_id IS NOT NULL
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work artifact requires an exact claimed same-home task'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_task_reference_immutable
  BEFORE UPDATE OF
    task_canvas_name,
    task_node_id,
    task_id,
    task_entity_home
  ON work_artifacts
  WHEN
    OLD.task_canvas_name IS NOT NEW.task_canvas_name
    OR OLD.task_node_id IS NOT NEW.task_node_id
    OR OLD.task_id IS NOT NEW.task_id
    OR OLD.task_entity_home IS NOT NEW.task_entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact task reference is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_transitions_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_transitions
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work transition home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_delivery_receipts_home_immutable
  BEFORE UPDATE OF entity_home ON work_delivery_receipts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work delivery receipt home is immutable');
  END;
  
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;

`,RG=`
  CREATE TABLE IF NOT EXISTS work_task_dependencies (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    task_id TEXT NOT NULL CHECK (length(task_id) BETWEEN 1 AND 256),
    depends_on_task_id TEXT NOT NULL
      CHECK (length(depends_on_task_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    PRIMARY KEY (canvas_name, node_id, task_id, depends_on_task_id),
    FOREIGN KEY (canvas_name, node_id, task_id)
      REFERENCES work_tasks(canvas_name, node_id, task_id)
      ON DELETE CASCADE
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_dependencies_dep
    ON work_task_dependencies(canvas_name, node_id, depends_on_task_id);
`,AG=`
  CREATE TABLE IF NOT EXISTS work_task_finish (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    task_id TEXT NOT NULL CHECK (length(task_id) BETWEEN 1 AND 256),
    finish_criteria_json TEXT
      CHECK (finish_criteria_json IS NULL OR json_valid(finish_criteria_json)),
    completion_evidence_json TEXT
      CHECK (
        completion_evidence_json IS NULL
        OR json_valid(completion_evidence_json)
      ),
    PRIMARY KEY (canvas_name, node_id, task_id),
    FOREIGN KEY (canvas_name, node_id, task_id)
      REFERENCES work_tasks(canvas_name, node_id, task_id)
      ON DELETE CASCADE
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;
`,PG=`
  CREATE TABLE IF NOT EXISTS work_proposal_planning (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    depends_on_json TEXT
      CHECK (depends_on_json IS NULL OR json_valid(depends_on_json)),
    finish_criteria_json TEXT
      CHECK (finish_criteria_json IS NULL OR json_valid(finish_criteria_json)),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    FOREIGN KEY (canvas_name, node_id, proposal_id)
      REFERENCES work_task_proposals(canvas_name, node_id, proposal_id)
      ON DELETE CASCADE
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;
`,z7=`
  CREATE TABLE IF NOT EXISTS work_board_topics (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    title TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 512),
    state TEXT NOT NULL CHECK (state IN ('open', 'archived')),
    author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
    author_seat_id TEXT
      CHECK (
        author_seat_id IS NULL
        OR (
          length(author_seat_id) = 69
          AND substr(author_seat_id, 1, 5) = 'seat_'
          AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    author_node_id TEXT
      CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
    author_label TEXT
      CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    post_count INTEGER NOT NULL DEFAULT 0 CHECK (post_count >= 0),
    last_activity_at TEXT NOT NULL CHECK (length(last_activity_at) BETWEEN 1 AND 64),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_board_posts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    post_id TEXT NOT NULL CHECK (length(post_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
    author_seat_id TEXT
      CHECK (
        author_seat_id IS NULL
        OR (
          length(author_seat_id) = 69
          AND substr(author_seat_id, 1, 5) = 'seat_'
          AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    author_node_id TEXT
      CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
    author_label TEXT
      CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, post_id),
    UNIQUE (canvas_name, node_id, topic_id, position),
    FOREIGN KEY (canvas_name, node_id, topic_id)
      REFERENCES work_board_topics(canvas_name, node_id, topic_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_board_read_cursors (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    principal_key TEXT NOT NULL CHECK (length(principal_key) BETWEEN 1 AND 256),
    last_read_position INTEGER NOT NULL CHECK (last_read_position >= -1),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, principal_key)
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_board_topics_node
    ON work_board_topics(canvas_name, node_id, last_activity_at, topic_id);
  CREATE INDEX IF NOT EXISTS work_board_posts_thread
    ON work_board_posts(canvas_name, node_id, topic_id, position);
`;var _S=`
  CREATE TABLE IF NOT EXISTS work_board_topics (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    title TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 512),
    state TEXT NOT NULL CHECK (state IN ('open', 'archived')),
    author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
    author_seat_id TEXT
      CHECK (
        author_seat_id IS NULL
        OR (
          length(author_seat_id) = 69
          AND substr(author_seat_id, 1, 5) = 'seat_'
          AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    author_node_id TEXT
      CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
    author_label TEXT
      CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    post_count INTEGER NOT NULL DEFAULT 0 CHECK (post_count >= 0),
    last_activity_at TEXT NOT NULL CHECK (length(last_activity_at) BETWEEN 1 AND 64),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_board_posts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    post_id TEXT NOT NULL CHECK (length(post_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
    author_seat_id TEXT
      CHECK (
        author_seat_id IS NULL
        OR (
          length(author_seat_id) = 69
          AND substr(author_seat_id, 1, 5) = 'seat_'
          AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    author_node_id TEXT
      CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
    author_label TEXT
      CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, post_id),
    UNIQUE (canvas_name, node_id, topic_id, position),
    FOREIGN KEY (canvas_name, node_id, topic_id)
      REFERENCES work_board_topics(canvas_name, node_id, topic_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_board_read_cursors (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
    principal_key TEXT NOT NULL CHECK (length(principal_key) BETWEEN 1 AND 256),
    last_read_position INTEGER NOT NULL CHECK (last_read_position >= -1),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, principal_key)
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_board_topics_node
    ON work_board_topics(canvas_name, node_id, last_activity_at, topic_id);
  CREATE INDEX IF NOT EXISTS work_board_posts_thread
    ON work_board_posts(canvas_name, node_id, topic_id, position);
`.replace(`parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, post_id),`,`parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    tags_json TEXT
      CHECK (tags_json IS NULL OR json_valid(tags_json)),
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, topic_id, post_id),`),R5=`
  CREATE TABLE IF NOT EXISTS work_event_sequences (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    last_seq TEXT NOT NULL
      CHECK (
        length(last_seq) BETWEEN 1 AND 32
        AND last_seq NOT GLOB '*[^0-9]*'
        AND (last_seq = '0' OR substr(last_seq, 1, 1) <> '0')
      ),
    PRIMARY KEY (event_home, entity_home),
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    protocol TEXT NOT NULL CHECK (protocol = 'vellum/work/v2'),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, record_type),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'command'
      CHECK (record_type = 'command'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    action_json TEXT NOT NULL
      CHECK (
        length(action_json) BETWEEN 2 AND 262144
        AND json_valid(action_json)
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home <> entity_home),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_facts (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'fact'
      CHECK (record_type = 'fact'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    result_json TEXT NOT NULL
      CHECK (
        length(result_json) BETWEEN 2 AND 262144
        AND json_valid(result_json)
      ),
    basis_kind TEXT NOT NULL
      CHECK (
        basis_kind IN (
          'authorial-intent',
          'projected-intent',
          'command'
        )
      ),
    basis_authorial_generation TEXT
      CHECK (
        basis_authorial_generation IS NULL
        OR (
          length(basis_authorial_generation) BETWEEN 1 AND 32
          AND basis_authorial_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_authorial_generation = '0'
            OR substr(basis_authorial_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_authorial_content_sha256 TEXT
      CHECK (
        basis_authorial_content_sha256 IS NULL
        OR (
          length(basis_authorial_content_sha256) = 64
          AND basis_authorial_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_projected_generation TEXT
      CHECK (
        basis_projected_generation IS NULL
        OR (
          length(basis_projected_generation) BETWEEN 1 AND 32
          AND basis_projected_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_projected_generation = '0'
            OR substr(basis_projected_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_projected_content_sha256 TEXT
      CHECK (
        basis_projected_content_sha256 IS NULL
        OR (
          length(basis_projected_content_sha256) = 64
          AND basis_projected_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_command_event_home TEXT,
    basis_command_entity_home TEXT,
    basis_command_seq TEXT
      CHECK (
        basis_command_seq IS NULL
        OR (
          length(basis_command_seq) BETWEEN 1 AND 32
          AND basis_command_seq NOT GLOB '*[^0-9]*'
          AND substr(basis_command_seq, 1, 1) <> '0'
        )
      ),
    basis_command_sha256 TEXT
      CHECK (
        basis_command_sha256 IS NULL
        OR (
          length(basis_command_sha256) = 64
          AND basis_command_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home = entity_home),
    CHECK (
      (
        basis_kind = 'authorial-intent'
        AND basis_authorial_generation IS NOT NULL
        AND basis_authorial_content_sha256 IS NOT NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'projected-intent'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NOT NULL
        AND basis_projected_content_sha256 IS NOT NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'command'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NOT NULL
        AND basis_command_entity_home IS NOT NULL
        AND basis_command_seq IS NOT NULL
        AND basis_command_sha256 IS NOT NULL
        AND basis_command_entity_home = entity_home
      )
    ),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (basis_authorial_generation)
      REFERENCES canvas_generations(generation)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_projected_generation,
      basis_projected_content_sha256
    ) REFERENCES station_projection_versions(generation, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq
    ) REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq,
      basis_command_sha256
    ) REFERENCES work_events(
      event_home,
      entity_home,
      seq,
      content_sha256
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_dispositions (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'disposition'
      CHECK (record_type = 'disposition'),
    status TEXT NOT NULL CHECK (status IN ('applied', 'rejected')),
    command_event_home TEXT NOT NULL,
    command_entity_home TEXT NOT NULL,
    command_seq TEXT NOT NULL,
    command_sha256 TEXT NOT NULL
      CHECK (
        length(command_sha256) = 64
        AND command_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT,
    fact_entity_home TEXT,
    fact_seq TEXT,
    fact_sha256 TEXT
      CHECK (
        fact_sha256 IS NULL
        OR (
          length(fact_sha256) = 64
          AND fact_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    rejection_reason TEXT
      CHECK (
        rejection_reason IS NULL
        OR rejection_reason IN (
          'authority-mismatch',
          'capability-denied',
          'causal-conflict',
          'claim-contention',
          'identity-conflict',
          'invalid-transition',
          'locality-mismatch',
          'missing-entity',
          'projection-conflict',
          'target-mismatch'
        )
      ),
    rejection_message TEXT
      CHECK (
        rejection_message IS NULL
        OR length(rejection_message) BETWEEN 1 AND 2048
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, status),
    CHECK (event_home = entity_home),
    CHECK (command_entity_home = entity_home),
    CHECK (
      (
        status = 'applied'
        AND fact_event_home IS NOT NULL
        AND fact_entity_home IS NOT NULL
        AND fact_seq IS NOT NULL
        AND fact_sha256 IS NOT NULL
        AND fact_event_home = event_home
        AND fact_entity_home = entity_home
        AND rejection_reason IS NULL
        AND rejection_message IS NULL
      )
      OR
      (
        status = 'rejected'
        AND fact_event_home IS NULL
        AND fact_entity_home IS NULL
        AND fact_seq IS NULL
        AND fact_sha256 IS NULL
        AND rejection_reason IS NOT NULL
        AND rejection_message IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (command_event_home, command_entity_home, command_seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      command_event_home,
      command_entity_home,
      command_seq,
      command_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      fact_event_home,
      fact_entity_home,
      fact_seq,
      fact_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    claim_actor_seat_id TEXT
      CHECK (
        claim_actor_seat_id IS NULL
        OR (
          length(claim_actor_seat_id) = 69
          AND substr(claim_actor_seat_id, 1, 5) = 'seat_'
          AND substr(claim_actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT
      CHECK (resolved_at IS NULL OR length(resolved_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        operation = 'task.claim'
        AND item_kind = 'task'
        AND claim_actor_seat_id IS NOT NULL
      )
      OR
      (
        operation <> 'task.claim'
        AND claim_actor_seat_id IS NULL
      )
    ),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      resolution_event_home,
      resolution_entity_home,
      resolution_seq,
      resolution_status
    ) REFERENCES work_dispositions(event_home, entity_home, seq, status)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_tasks (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    task_id TEXT NOT NULL CHECK (length(task_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, task_id),
    UNIQUE (canvas_name, node_id, task_id, entity_home),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'submitted' AND actor_seat_id IS NULL)
      OR state IN ('completed', 'canceled', 'failed', 'rejected')
      OR (
        state IN ('working', 'input-required', 'auth-required')
        AND actor_seat_id IS NOT NULL
      )
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_requests (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    request_id TEXT NOT NULL CHECK (length(request_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'input-required',
          'auth-required',
          'completed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, request_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    parent_lane TEXT NOT NULL CHECK (parent_lane IN ('task', 'request')),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    message_kind TEXT NOT NULL CHECK (message_kind IN ('brief', 'history')),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      message_id
    ),
    UNIQUE (canvas_name, node_id, parent_lane, item_id, position),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, message_id),
    UNIQUE (canvas_name, node_id, position),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_artifacts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    artifact_id TEXT NOT NULL CHECK (length(artifact_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    name TEXT,
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_canvas_name TEXT
      CHECK (
        task_canvas_name IS NULL
        OR length(task_canvas_name) BETWEEN 1 AND 256
      ),
    task_node_id TEXT
      CHECK (
        task_node_id IS NULL
        OR length(task_node_id) BETWEEN 1 AND 256
      ),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    task_entity_home TEXT,
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, artifact_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (
        task_canvas_name IS NULL
        AND task_node_id IS NULL
        AND task_id IS NULL
        AND task_entity_home IS NULL
      )
      OR
      (
        task_canvas_name IS NOT NULL
        AND task_node_id IS NOT NULL
        AND task_id IS NOT NULL
        AND task_entity_home IS NOT NULL
      )
    ),
    CHECK (
      task_entity_home IS NULL
      OR task_entity_home = entity_home
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      task_canvas_name,
      task_node_id,
      task_id,
      task_entity_home
    ) REFERENCES work_tasks(
      canvas_name,
      node_id,
      task_id,
      entity_home
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_transitions (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    lane TEXT NOT NULL CHECK (lane IN ('task', 'request')),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve'
        )
      ),
    from_state TEXT,
    to_state TEXT NOT NULL
      CHECK (
        to_state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, item_id, lane, ordinal),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (
      from_state IS NULL
      OR from_state IN (
        'submitted',
        'working',
        'input-required',
        'auth-required',
        'completed',
        'canceled',
        'failed',
        'rejected'
      )
    ),
    CHECK (
      to_state NOT IN ('working', 'input-required', 'auth-required')
      OR actor_seat_id IS NOT NULL
    ),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_delivery_receipts (
    delivery_id TEXT NOT NULL CHECK (length(delivery_id) BETWEEN 1 AND 256),
    delivered_item_kind TEXT NOT NULL
      CHECK (
        delivered_item_kind IN (
          'task',
          'request',
          'message',
          'artifact',
          'delivery'
        )
      ),
    delivered_item_id TEXT NOT NULL
      CHECK (length(delivered_item_id) BETWEEN 1 AND 256),
    delivered_canvas_name TEXT NOT NULL
      CHECK (length(delivered_canvas_name) BETWEEN 1 AND 256),
    delivered_node_id TEXT NOT NULL
      CHECK (length(delivered_node_id) BETWEEN 1 AND 256),
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    actor_canvas_name TEXT NOT NULL
      CHECK (length(actor_canvas_name) BETWEEN 1 AND 256),
    actor_node_id TEXT NOT NULL
      CHECK (length(actor_node_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    accepted_at TEXT NOT NULL CHECK (length(accepted_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      delivered_canvas_name,
      delivered_node_id,
      delivery_id
    ),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_events_route_order
    ON work_events(event_home, entity_home, length(seq), seq);
  CREATE INDEX IF NOT EXISTS work_events_item_history
    ON work_events(
      item_canvas_name,
      item_node_id,
      item_kind,
      item_id,
      entity_home,
      length(seq),
      seq
    );
  CREATE INDEX IF NOT EXISTS work_pending_commands_route
    ON work_pending_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_item
    ON work_pending_commands(
      item_canvas_name,
      item_node_id,
      item_id
    )
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_actor
    ON work_pending_commands(claim_actor_seat_id)
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE INDEX IF NOT EXISTS work_tasks_node
    ON work_tasks(canvas_name, node_id, created_at, task_id);
  CREATE UNIQUE INDEX IF NOT EXISTS work_tasks_one_active_per_actor
    ON work_tasks(actor_seat_id)
    WHERE
      actor_seat_id IS NOT NULL
      AND state IN ('working', 'input-required', 'auth-required');
  CREATE INDEX IF NOT EXISTS work_requests_node
    ON work_requests(canvas_name, node_id, created_at, request_id);
  CREATE INDEX IF NOT EXISTS work_task_messages_thread
    ON work_task_messages(
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      position
    );
  CREATE UNIQUE INDEX IF NOT EXISTS work_task_messages_sink_identity
    ON work_task_messages(canvas_name, node_id, message_id);
  CREATE INDEX IF NOT EXISTS work_messages_inbox
    ON work_messages(canvas_name, node_id, position);
  CREATE INDEX IF NOT EXISTS work_artifacts_node
    ON work_artifacts(canvas_name, node_id, artifact_id);
  CREATE INDEX IF NOT EXISTS work_delivery_receipts_actor
    ON work_delivery_receipts(
      actor_seat_id,
      accepted_at,
      delivery_id
    );

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_update
  BEFORE UPDATE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_delete
  BEFORE DELETE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_update
  BEFORE UPDATE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_delete
  BEFORE DELETE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_fact_authorial_basis_resolves
  BEFORE INSERT ON work_facts
  WHEN
    NEW.basis_kind = 'authorial-intent'
    AND NOT EXISTS (
      SELECT 1
      FROM canvas_generations AS generation
      JOIN canvas_generation_documents AS document
        ON document.generation = generation.generation
      JOIN work_events AS record
        ON record.event_home = NEW.event_home
        AND record.entity_home = NEW.entity_home
        AND record.seq = NEW.seq
      WHERE generation.generation = NEW.basis_authorial_generation
        AND generation.intent_sha256 =
          NEW.basis_authorial_content_sha256
        AND document.name = record.item_canvas_name
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'authorial fact basis must resolve its exact sink canvas generation'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_update
  BEFORE UPDATE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_delete
  BEFORE DELETE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_applied_disposition_fact_basis_matches
  BEFORE INSERT ON work_dispositions
  WHEN
    NEW.status = 'applied'
    AND NOT EXISTS (
      SELECT 1
      FROM work_facts AS fact
      WHERE fact.event_home = NEW.fact_event_home
        AND fact.entity_home = NEW.fact_entity_home
        AND fact.seq = NEW.fact_seq
        AND fact.basis_kind = 'command'
        AND fact.basis_command_event_home = NEW.command_event_home
        AND fact.basis_command_entity_home = NEW.command_entity_home
        AND fact.basis_command_seq = NEW.command_seq
        AND fact.basis_command_sha256 = NEW.command_sha256
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'applied disposition fact must carry its exact command basis'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_update
  BEFORE UPDATE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_delete
  BEFORE DELETE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_matches_record
  BEFORE INSERT ON work_pending_commands
  WHEN NOT EXISTS (
    SELECT 1
    FROM work_events AS record
    WHERE record.event_home = NEW.event_home
      AND record.entity_home = NEW.entity_home
      AND record.seq = NEW.seq
      AND record.record_type = 'command'
      AND record.operation = NEW.operation
      AND record.item_kind = NEW.item_kind
      AND record.item_canvas_name = NEW.item_canvas_name
      AND record.item_node_id = NEW.item_node_id
      AND record.item_id = NEW.item_id
  )
  BEGIN
    SELECT RAISE(ABORT, 'pending command metadata must match its Work command');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_identity_immutable
  BEFORE UPDATE OF
    event_home,
    entity_home,
    seq,
    operation,
    item_kind,
    item_canvas_name,
    item_node_id,
    item_id,
    claim_actor_seat_id
  ON work_pending_commands
  WHEN
    OLD.event_home IS NOT NEW.event_home
    OR OLD.entity_home IS NOT NEW.entity_home
    OR OLD.seq IS NOT NEW.seq
    OR OLD.operation IS NOT NEW.operation
    OR OLD.item_kind IS NOT NEW.item_kind
    OR OLD.item_canvas_name IS NOT NEW.item_canvas_name
    OR OLD.item_node_id IS NOT NEW.item_node_id
    OR OLD.item_id IS NOT NEW.item_id
    OR OLD.claim_actor_seat_id IS NOT NEW.claim_actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'pending command identity is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_initial_resolution_matches
  BEFORE INSERT ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = NEW.event_home
        AND disposition.command_entity_home = NEW.entity_home
        AND disposition.command_seq = NEW.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_matches
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = OLD.event_home
        AND disposition.command_entity_home = OLD.entity_home
        AND disposition.command_seq = OLD.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_once
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    OLD.resolution_event_home IS NOT NULL
    AND (
      OLD.resolution_status IS NOT NEW.resolution_status
      OR OLD.resolution_event_home IS NOT NEW.resolution_event_home
      OR OLD.resolution_entity_home IS NOT NEW.resolution_entity_home
      OR OLD.resolution_seq IS NOT NEW.resolution_seq
      OR OLD.resolved_at IS NOT NEW.resolved_at
    )
  BEGIN
    SELECT RAISE(ABORT, 'pending command resolution is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_home_immutable
  BEFORE UPDATE OF entity_home ON work_tasks
  WHEN
    OLD.entity_home <> NEW.entity_home
    AND NOT (
      OLD.state = 'submitted'
      AND OLD.actor_seat_id IS NULL
      AND NEW.state = 'working'
      AND NEW.actor_seat_id IS NOT NULL
      AND NEW.entity_home = NEW.fact_entity_home
      AND NEW.fact_event_home = NEW.fact_entity_home
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task home is immutable except for first claim adoption'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_tasks
  WHEN
    OLD.actor_seat_id IS NOT NULL
    AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
    AND NOT (
      NEW.actor_seat_id IS NULL
      AND NEW.state = 'submitted'
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task actor seat is immutable except for operator release'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_home_immutable
  BEFORE UPDATE OF entity_home ON work_requests
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work request home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_requests
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work request actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work task message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_require_exact_parent
  BEFORE INSERT ON work_task_messages
  WHEN NOT (
    (
      NEW.parent_lane = 'task'
      AND EXISTS (
        SELECT 1
        FROM work_tasks
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND task_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
    OR
    (
      NEW.parent_lane = 'request'
      AND EXISTS (
        SELECT 1
        FROM work_requests
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND request_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
  )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task message requires an exact same-home parent'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_require_cc_home
  BEFORE INSERT ON work_messages
  WHEN
    NOT EXISTS (
      SELECT 1
      FROM station_configuration AS configuration
      JOIN station_installation AS installation
        ON installation.singleton = configuration.singleton
      WHERE configuration.singleton = 1
        AND configuration.role = 'command-center'
        AND NEW.entity_home = installation.installation_id
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work mailbox messages must be Command Center-homed'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_messages
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work message actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_home_immutable
  BEFORE UPDATE OF entity_home ON work_artifacts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_artifacts
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work artifact actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_require_claimed_task
  BEFORE INSERT ON work_artifacts
  WHEN
    NEW.task_id IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
    )
    AND NOT EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
        AND actor_seat_id IS NOT NULL
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work artifact requires an exact claimed same-home task'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_task_reference_immutable
  BEFORE UPDATE OF
    task_canvas_name,
    task_node_id,
    task_id,
    task_entity_home
  ON work_artifacts
  WHEN
    OLD.task_canvas_name IS NOT NEW.task_canvas_name
    OR OLD.task_node_id IS NOT NEW.task_node_id
    OR OLD.task_id IS NOT NEW.task_id
    OR OLD.task_entity_home IS NOT NEW.task_entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact task reference is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_transitions_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_transitions
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work transition home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_delivery_receipts_home_immutable
  BEFORE UPDATE OF entity_home ON work_delivery_receipts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work delivery receipt home is immutable');
  END;
  
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;

`.replaceAll("item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')","item_kind IN ('task', 'request', 'message', 'artifact', 'delivery', 'topic', 'post')").replaceAll(`'delivery.accepted'
        )`,`'delivery.accepted',
          'board.topic.create',
          'board.post.append'
        )`),KD=R5.replaceAll("operation IN ('proposal.create', 'proposal.approve')","operation IN ('proposal.create', 'proposal.approve', 'proposal.reject')"),o9=KD.replaceAll(`'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, task_id),`,`'completed',
          'canceled',
          'failed',
          'rejected',
          'archived'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, task_id),`).replaceAll("OR state IN ('completed', 'canceled', 'failed', 'rejected')","OR state IN ('completed', 'canceled', 'failed', 'rejected', 'archived')").replaceAll(`to_state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )`,`to_state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected',
          'archived'
        )`).replaceAll(`from_state IN (
        'submitted',
        'working',
        'input-required',
        'auth-required',
        'completed',
        'canceled',
        'failed',
        'rejected'
      )`,`from_state IN (
        'submitted',
        'working',
        'input-required',
        'auth-required',
        'completed',
        'canceled',
        'failed',
        'rejected',
        'archived'
      )`),KS=`
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;
`.replaceAll("operation IN ('proposal.create', 'proposal.approve')","operation IN ('proposal.create', 'proposal.approve', 'proposal.reject')"),HD=`
  CREATE TABLE IF NOT EXISTS work_event_sequences (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    last_seq TEXT NOT NULL
      CHECK (
        length(last_seq) BETWEEN 1 AND 32
        AND last_seq NOT GLOB '*[^0-9]*'
        AND (last_seq = '0' OR substr(last_seq, 1, 1) <> '0')
      ),
    PRIMARY KEY (event_home, entity_home),
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    protocol TEXT NOT NULL CHECK (protocol = 'vellum/work/v2'),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, record_type),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'command'
      CHECK (record_type = 'command'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    action_json TEXT NOT NULL
      CHECK (
        length(action_json) BETWEEN 2 AND 262144
        AND json_valid(action_json)
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home <> entity_home),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_facts (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'fact'
      CHECK (record_type = 'fact'),
    predecessor_event_home TEXT,
    predecessor_entity_home TEXT,
    predecessor_seq TEXT
      CHECK (
        predecessor_seq IS NULL
        OR (
          length(predecessor_seq) BETWEEN 1 AND 32
          AND predecessor_seq NOT GLOB '*[^0-9]*'
          AND substr(predecessor_seq, 1, 1) <> '0'
        )
      ),
    result_json TEXT NOT NULL
      CHECK (
        length(result_json) BETWEEN 2 AND 262144
        AND json_valid(result_json)
      ),
    basis_kind TEXT NOT NULL
      CHECK (
        basis_kind IN (
          'authorial-intent',
          'projected-intent',
          'command'
        )
      ),
    basis_authorial_generation TEXT
      CHECK (
        basis_authorial_generation IS NULL
        OR (
          length(basis_authorial_generation) BETWEEN 1 AND 32
          AND basis_authorial_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_authorial_generation = '0'
            OR substr(basis_authorial_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_authorial_content_sha256 TEXT
      CHECK (
        basis_authorial_content_sha256 IS NULL
        OR (
          length(basis_authorial_content_sha256) = 64
          AND basis_authorial_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_projected_generation TEXT
      CHECK (
        basis_projected_generation IS NULL
        OR (
          length(basis_projected_generation) BETWEEN 1 AND 32
          AND basis_projected_generation NOT GLOB '*[^0-9]*'
          AND (
            basis_projected_generation = '0'
            OR substr(basis_projected_generation, 1, 1) <> '0'
          )
        )
      ),
    basis_projected_content_sha256 TEXT
      CHECK (
        basis_projected_content_sha256 IS NULL
        OR (
          length(basis_projected_content_sha256) = 64
          AND basis_projected_content_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    basis_command_event_home TEXT,
    basis_command_entity_home TEXT,
    basis_command_seq TEXT
      CHECK (
        basis_command_seq IS NULL
        OR (
          length(basis_command_seq) BETWEEN 1 AND 32
          AND basis_command_seq NOT GLOB '*[^0-9]*'
          AND substr(basis_command_seq, 1, 1) <> '0'
        )
      ),
    basis_command_sha256 TEXT
      CHECK (
        basis_command_sha256 IS NULL
        OR (
          length(basis_command_sha256) = 64
          AND basis_command_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (event_home = entity_home),
    CHECK (
      (
        basis_kind = 'authorial-intent'
        AND basis_authorial_generation IS NOT NULL
        AND basis_authorial_content_sha256 IS NOT NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'projected-intent'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NOT NULL
        AND basis_projected_content_sha256 IS NOT NULL
        AND basis_command_event_home IS NULL
        AND basis_command_entity_home IS NULL
        AND basis_command_seq IS NULL
        AND basis_command_sha256 IS NULL
      )
      OR
      (
        basis_kind = 'command'
        AND basis_authorial_generation IS NULL
        AND basis_authorial_content_sha256 IS NULL
        AND basis_projected_generation IS NULL
        AND basis_projected_content_sha256 IS NULL
        AND basis_command_event_home IS NOT NULL
        AND basis_command_entity_home IS NOT NULL
        AND basis_command_seq IS NOT NULL
        AND basis_command_sha256 IS NOT NULL
        AND basis_command_entity_home = entity_home
      )
    ),
    CHECK (
      (
        predecessor_event_home IS NULL
        AND predecessor_entity_home IS NULL
        AND predecessor_seq IS NULL
      )
      OR
      (
        predecessor_event_home IS NOT NULL
        AND predecessor_entity_home IS NOT NULL
        AND predecessor_seq IS NOT NULL
        AND predecessor_entity_home = entity_home
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      predecessor_event_home,
      predecessor_entity_home,
      predecessor_seq
    ) REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (basis_authorial_generation)
      REFERENCES canvas_generations(generation)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_projected_generation,
      basis_projected_content_sha256
    ) REFERENCES station_projection_versions(generation, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq
    ) REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      basis_command_event_home,
      basis_command_entity_home,
      basis_command_seq,
      basis_command_sha256
    ) REFERENCES work_events(
      event_home,
      entity_home,
      seq,
      content_sha256
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_dispositions (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    record_type TEXT NOT NULL DEFAULT 'disposition'
      CHECK (record_type = 'disposition'),
    status TEXT NOT NULL CHECK (status IN ('applied', 'rejected')),
    command_event_home TEXT NOT NULL,
    command_entity_home TEXT NOT NULL,
    command_seq TEXT NOT NULL,
    command_sha256 TEXT NOT NULL
      CHECK (
        length(command_sha256) = 64
        AND command_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT,
    fact_entity_home TEXT,
    fact_seq TEXT,
    fact_sha256 TEXT
      CHECK (
        fact_sha256 IS NULL
        OR (
          length(fact_sha256) = 64
          AND fact_sha256 NOT GLOB '*[^a-f0-9]*'
        )
      ),
    rejection_reason TEXT
      CHECK (
        rejection_reason IS NULL
        OR rejection_reason IN (
          'authority-mismatch',
          'capability-denied',
          'causal-conflict',
          'claim-contention',
          'identity-conflict',
          'invalid-transition',
          'locality-mismatch',
          'missing-entity',
          'projection-conflict',
          'target-mismatch'
        )
      ),
    rejection_message TEXT
      CHECK (
        rejection_message IS NULL
        OR length(rejection_message) BETWEEN 1 AND 2048
      ),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, status),
    CHECK (event_home = entity_home),
    CHECK (command_entity_home = entity_home),
    CHECK (
      (
        status = 'applied'
        AND fact_event_home IS NOT NULL
        AND fact_entity_home IS NOT NULL
        AND fact_seq IS NOT NULL
        AND fact_sha256 IS NOT NULL
        AND fact_event_home = event_home
        AND fact_entity_home = entity_home
        AND rejection_reason IS NULL
        AND rejection_message IS NULL
      )
      OR
      (
        status = 'rejected'
        AND fact_event_home IS NULL
        AND fact_entity_home IS NULL
        AND fact_seq IS NULL
        AND fact_sha256 IS NULL
        AND rejection_reason IS NOT NULL
        AND rejection_message IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq, record_type)
      REFERENCES work_events(event_home, entity_home, seq, record_type)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (command_event_home, command_entity_home, command_seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      command_event_home,
      command_entity_home,
      command_seq,
      command_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      fact_event_home,
      fact_entity_home,
      fact_seq,
      fact_sha256
    ) REFERENCES work_events(event_home, entity_home, seq, content_sha256)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve',
          'message.append',
          'artifact.publish',
          'delivery.accepted'
        )
      ),
    item_kind TEXT NOT NULL
      CHECK (
        item_kind IN ('task', 'request', 'message', 'artifact', 'delivery')
      ),
    item_canvas_name TEXT NOT NULL
      CHECK (length(item_canvas_name) BETWEEN 1 AND 256),
    item_node_id TEXT NOT NULL
      CHECK (length(item_node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    claim_actor_seat_id TEXT
      CHECK (
        claim_actor_seat_id IS NULL
        OR (
          length(claim_actor_seat_id) = 69
          AND substr(claim_actor_seat_id, 1, 5) = 'seat_'
          AND substr(claim_actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT
      CHECK (resolved_at IS NULL OR length(resolved_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        operation = 'task.claim'
        AND item_kind = 'task'
        AND claim_actor_seat_id IS NOT NULL
      )
      OR
      (
        operation <> 'task.claim'
        AND claim_actor_seat_id IS NULL
      )
    ),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_commands(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      resolution_event_home,
      resolution_entity_home,
      resolution_seq,
      resolution_status
    ) REFERENCES work_dispositions(event_home, entity_home, seq, status)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_tasks (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    task_id TEXT NOT NULL CHECK (length(task_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, task_id),
    UNIQUE (canvas_name, node_id, task_id, entity_home),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'submitted' AND actor_seat_id IS NULL)
      OR state IN ('completed', 'canceled', 'failed', 'rejected')
      OR (
        state IN ('working', 'input-required', 'auth-required')
        AND actor_seat_id IS NOT NULL
      )
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_requests (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    request_id TEXT NOT NULL CHECK (length(request_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL
      CHECK (
        state IN (
          'input-required',
          'auth-required',
          'completed',
          'rejected'
        )
      ),
    brief_message_id TEXT NOT NULL
      CHECK (length(brief_message_id) BETWEEN 1 AND 256),
    artifact_ids_json TEXT
      CHECK (artifact_ids_json IS NULL OR json_valid(artifact_ids_json)),
    metadata_json TEXT
      CHECK (
        metadata_json IS NULL
        OR (
          json_valid(metadata_json)
          AND json_type(metadata_json, '$.claimedBy') IS NULL
        )
      ),
    reason TEXT,
    response TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, request_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    parent_lane TEXT NOT NULL CHECK (parent_lane IN ('task', 'request')),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    message_kind TEXT NOT NULL CHECK (message_kind IN ('brief', 'history')),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      message_id
    ),
    UNIQUE (canvas_name, node_id, parent_lane, item_id, position),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_messages (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    message_id TEXT NOT NULL CHECK (length(message_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'agent')),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    context_id TEXT,
    reference_task_ids_json TEXT
      CHECK (
        reference_task_ids_json IS NULL
        OR json_valid(reference_task_ids_json)
      ),
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, message_id),
    UNIQUE (canvas_name, node_id, position),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_artifacts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    artifact_id TEXT NOT NULL CHECK (length(artifact_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    name TEXT,
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    task_canvas_name TEXT
      CHECK (
        task_canvas_name IS NULL
        OR length(task_canvas_name) BETWEEN 1 AND 256
      ),
    task_node_id TEXT
      CHECK (
        task_node_id IS NULL
        OR length(task_node_id) BETWEEN 1 AND 256
      ),
    task_id TEXT
      CHECK (
        task_id IS NULL
        OR length(task_id) BETWEEN 1 AND 256
      ),
    task_entity_home TEXT,
    metadata_json TEXT
      CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, artifact_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (
        task_canvas_name IS NULL
        AND task_node_id IS NULL
        AND task_id IS NULL
        AND task_entity_home IS NULL
      )
      OR
      (
        task_canvas_name IS NOT NULL
        AND task_node_id IS NOT NULL
        AND task_id IS NOT NULL
        AND task_entity_home IS NOT NULL
      )
    ),
    CHECK (
      task_entity_home IS NULL
      OR task_entity_home = entity_home
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (
      task_canvas_name,
      task_node_id,
      task_id,
      task_entity_home
    ) REFERENCES work_tasks(
      canvas_name,
      node_id,
      task_id,
      entity_home
    )
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_transitions (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    item_id TEXT NOT NULL CHECK (length(item_id) BETWEEN 1 AND 256),
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    lane TEXT NOT NULL CHECK (lane IN ('task', 'request')),
    entity_home TEXT NOT NULL,
    actor_seat_id TEXT
      CHECK (
        actor_seat_id IS NULL
        OR (
          length(actor_seat_id) = 69
          AND substr(actor_seat_id, 1, 5) = 'seat_'
          AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (
        operation IN (
          'task.create',
          'task.describe',
          'task.transition',
          'task.claim',
          'request.create',
          'request.resolve'
        )
      ),
    from_state TEXT,
    to_state TEXT NOT NULL
      CHECK (
        to_state IN (
          'submitted',
          'working',
          'input-required',
          'auth-required',
          'completed',
          'canceled',
          'failed',
          'rejected'
        )
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, item_id, lane, ordinal),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (
      from_state IS NULL
      OR from_state IN (
        'submitted',
        'working',
        'input-required',
        'auth-required',
        'completed',
        'canceled',
        'failed',
        'rejected'
      )
    ),
    CHECK (
      to_state NOT IN ('working', 'input-required', 'auth-required')
      OR actor_seat_id IS NOT NULL
    ),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_delivery_receipts (
    delivery_id TEXT NOT NULL CHECK (length(delivery_id) BETWEEN 1 AND 256),
    delivered_item_kind TEXT NOT NULL
      CHECK (
        delivered_item_kind IN (
          'task',
          'request',
          'message',
          'artifact',
          'delivery'
        )
      ),
    delivered_item_id TEXT NOT NULL
      CHECK (length(delivered_item_id) BETWEEN 1 AND 256),
    delivered_canvas_name TEXT NOT NULL
      CHECK (length(delivered_canvas_name) BETWEEN 1 AND 256),
    delivered_node_id TEXT NOT NULL
      CHECK (length(delivered_node_id) BETWEEN 1 AND 256),
    actor_seat_id TEXT NOT NULL
      CHECK (
        length(actor_seat_id) = 69
        AND substr(actor_seat_id, 1, 5) = 'seat_'
        AND substr(actor_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    actor_canvas_name TEXT NOT NULL
      CHECK (length(actor_canvas_name) BETWEEN 1 AND 256),
    actor_node_id TEXT NOT NULL
      CHECK (length(actor_node_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    accepted_at TEXT NOT NULL CHECK (length(accepted_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (
      delivered_canvas_name,
      delivered_node_id,
      delivery_id
    ),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_facts(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_events_route_order
    ON work_events(event_home, entity_home, length(seq), seq);
  CREATE INDEX IF NOT EXISTS work_events_item_history
    ON work_events(
      item_canvas_name,
      item_node_id,
      item_kind,
      item_id,
      entity_home,
      length(seq),
      seq
    );
  CREATE INDEX IF NOT EXISTS work_pending_commands_route
    ON work_pending_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_item
    ON work_pending_commands(
      item_canvas_name,
      item_node_id,
      item_id
    )
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE UNIQUE INDEX IF NOT EXISTS work_pending_task_claim_actor
    ON work_pending_commands(claim_actor_seat_id)
    WHERE
      operation = 'task.claim'
      AND resolution_event_home IS NULL;
  CREATE INDEX IF NOT EXISTS work_tasks_node
    ON work_tasks(canvas_name, node_id, created_at, task_id);
  CREATE UNIQUE INDEX IF NOT EXISTS work_tasks_one_active_per_actor
    ON work_tasks(actor_seat_id)
    WHERE
      actor_seat_id IS NOT NULL
      AND state IN ('working', 'input-required', 'auth-required');
  CREATE INDEX IF NOT EXISTS work_requests_node
    ON work_requests(canvas_name, node_id, created_at, request_id);
  CREATE INDEX IF NOT EXISTS work_task_messages_thread
    ON work_task_messages(
      canvas_name,
      node_id,
      parent_lane,
      item_id,
      position
    );
  CREATE UNIQUE INDEX IF NOT EXISTS work_task_messages_sink_identity
    ON work_task_messages(canvas_name, node_id, message_id);
  CREATE INDEX IF NOT EXISTS work_messages_inbox
    ON work_messages(canvas_name, node_id, position);
  CREATE INDEX IF NOT EXISTS work_artifacts_node
    ON work_artifacts(canvas_name, node_id, artifact_id);
  CREATE INDEX IF NOT EXISTS work_delivery_receipts_actor
    ON work_delivery_receipts(
      actor_seat_id,
      accepted_at,
      delivery_id
    );

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_update
  BEFORE UPDATE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_events_immutable_delete
  BEFORE DELETE ON work_events
  BEGIN
    SELECT RAISE(ABORT, 'work records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_update
  BEFORE UPDATE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_commands_immutable_delete
  BEFORE DELETE ON work_commands
  BEGIN
    SELECT RAISE(ABORT, 'work command records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_fact_authorial_basis_resolves
  BEFORE INSERT ON work_facts
  WHEN
    NEW.basis_kind = 'authorial-intent'
    AND NOT EXISTS (
      SELECT 1
      FROM canvas_generations AS generation
      JOIN canvas_generation_documents AS document
        ON document.generation = generation.generation
      JOIN work_events AS record
        ON record.event_home = NEW.event_home
        AND record.entity_home = NEW.entity_home
        AND record.seq = NEW.seq
      WHERE generation.generation = NEW.basis_authorial_generation
        AND generation.intent_sha256 =
          NEW.basis_authorial_content_sha256
        AND document.name = record.item_canvas_name
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'authorial fact basis must resolve its exact sink canvas generation'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_update
  BEFORE UPDATE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_facts_immutable_delete
  BEFORE DELETE ON work_facts
  BEGIN
    SELECT RAISE(ABORT, 'work fact records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_applied_disposition_fact_basis_matches
  BEFORE INSERT ON work_dispositions
  WHEN
    NEW.status = 'applied'
    AND NOT EXISTS (
      SELECT 1
      FROM work_facts AS fact
      WHERE fact.event_home = NEW.fact_event_home
        AND fact.entity_home = NEW.fact_entity_home
        AND fact.seq = NEW.fact_seq
        AND fact.basis_kind = 'command'
        AND fact.basis_command_event_home = NEW.command_event_home
        AND fact.basis_command_entity_home = NEW.command_entity_home
        AND fact.basis_command_seq = NEW.command_seq
        AND fact.basis_command_sha256 = NEW.command_sha256
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'applied disposition fact must carry its exact command basis'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_update
  BEFORE UPDATE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_dispositions_immutable_delete
  BEFORE DELETE ON work_dispositions
  BEGIN
    SELECT RAISE(ABORT, 'work disposition records are immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_matches_record
  BEFORE INSERT ON work_pending_commands
  WHEN NOT EXISTS (
    SELECT 1
    FROM work_events AS record
    WHERE record.event_home = NEW.event_home
      AND record.entity_home = NEW.entity_home
      AND record.seq = NEW.seq
      AND record.record_type = 'command'
      AND record.operation = NEW.operation
      AND record.item_kind = NEW.item_kind
      AND record.item_canvas_name = NEW.item_canvas_name
      AND record.item_node_id = NEW.item_node_id
      AND record.item_id = NEW.item_id
  )
  BEGIN
    SELECT RAISE(ABORT, 'pending command metadata must match its Work command');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_identity_immutable
  BEFORE UPDATE OF
    event_home,
    entity_home,
    seq,
    operation,
    item_kind,
    item_canvas_name,
    item_node_id,
    item_id,
    claim_actor_seat_id
  ON work_pending_commands
  WHEN
    OLD.event_home IS NOT NEW.event_home
    OR OLD.entity_home IS NOT NEW.entity_home
    OR OLD.seq IS NOT NEW.seq
    OR OLD.operation IS NOT NEW.operation
    OR OLD.item_kind IS NOT NEW.item_kind
    OR OLD.item_canvas_name IS NOT NEW.item_canvas_name
    OR OLD.item_node_id IS NOT NEW.item_node_id
    OR OLD.item_id IS NOT NEW.item_id
    OR OLD.claim_actor_seat_id IS NOT NEW.claim_actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'pending command identity is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_initial_resolution_matches
  BEFORE INSERT ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = NEW.event_home
        AND disposition.command_entity_home = NEW.entity_home
        AND disposition.command_seq = NEW.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_matches
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    NEW.resolution_event_home IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM work_dispositions AS disposition
      WHERE disposition.event_home = NEW.resolution_event_home
        AND disposition.entity_home = NEW.resolution_entity_home
        AND disposition.seq = NEW.resolution_seq
        AND disposition.status = NEW.resolution_status
        AND disposition.command_event_home = OLD.event_home
        AND disposition.command_entity_home = OLD.entity_home
        AND disposition.command_seq = OLD.seq
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'pending command resolution must reference its causal disposition'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_pending_command_resolution_once
  BEFORE UPDATE OF
    resolution_status,
    resolution_event_home,
    resolution_entity_home,
    resolution_seq,
    resolved_at
  ON work_pending_commands
  WHEN
    OLD.resolution_event_home IS NOT NULL
    AND (
      OLD.resolution_status IS NOT NEW.resolution_status
      OR OLD.resolution_event_home IS NOT NEW.resolution_event_home
      OR OLD.resolution_entity_home IS NOT NEW.resolution_entity_home
      OR OLD.resolution_seq IS NOT NEW.resolution_seq
      OR OLD.resolved_at IS NOT NEW.resolved_at
    )
  BEGIN
    SELECT RAISE(ABORT, 'pending command resolution is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_home_immutable
  BEFORE UPDATE OF entity_home ON work_tasks
  WHEN
    OLD.entity_home <> NEW.entity_home
    AND NOT (
      OLD.state = 'submitted'
      AND OLD.actor_seat_id IS NULL
      AND NEW.state = 'working'
      AND NEW.actor_seat_id IS NOT NULL
      AND NEW.entity_home = NEW.fact_entity_home
      AND NEW.fact_event_home = NEW.fact_entity_home
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task home is immutable except for first claim adoption'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_tasks_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_tasks
  WHEN
    OLD.actor_seat_id IS NOT NULL
    AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
    AND NOT (
      NEW.actor_seat_id IS NULL
      AND NEW.state = 'submitted'
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task actor seat is immutable except for operator release'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_home_immutable
  BEFORE UPDATE OF entity_home ON work_requests
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work request home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_requests_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_requests
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work request actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work task message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_messages_require_exact_parent
  BEFORE INSERT ON work_task_messages
  WHEN NOT (
    (
      NEW.parent_lane = 'task'
      AND EXISTS (
        SELECT 1
        FROM work_tasks
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND task_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
    OR
    (
      NEW.parent_lane = 'request'
      AND EXISTS (
        SELECT 1
        FROM work_requests
        WHERE canvas_name = NEW.canvas_name
          AND node_id = NEW.node_id
          AND request_id = NEW.item_id
          AND entity_home = NEW.entity_home
      )
    )
  )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task message requires an exact same-home parent'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_home_immutable
  BEFORE UPDATE OF entity_home ON work_messages
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work message home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_require_cc_home
  BEFORE INSERT ON work_messages
  WHEN
    NOT EXISTS (
      SELECT 1
      FROM station_configuration AS configuration
      JOIN station_installation AS installation
        ON installation.singleton = configuration.singleton
      WHERE configuration.singleton = 1
        AND configuration.role = 'command-center'
        AND NEW.entity_home = installation.installation_id
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work mailbox messages must be Command Center-homed'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_messages_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_messages
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work message actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_home_immutable
  BEFORE UPDATE OF entity_home ON work_artifacts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_artifacts
  WHEN OLD.actor_seat_id <> NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work artifact actor seat is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_require_claimed_task
  BEFORE INSERT ON work_artifacts
  WHEN
    NEW.task_id IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
    )
    AND NOT EXISTS (
      SELECT 1
      FROM work_tasks
      WHERE canvas_name = NEW.task_canvas_name
        AND node_id = NEW.task_node_id
        AND task_id = NEW.task_id
        AND entity_home = NEW.task_entity_home
        AND actor_seat_id IS NOT NULL
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work artifact requires an exact claimed same-home task'
    );
  END;

  CREATE TRIGGER IF NOT EXISTS work_artifacts_task_reference_immutable
  BEFORE UPDATE OF
    task_canvas_name,
    task_node_id,
    task_id,
    task_entity_home
  ON work_artifacts
  WHEN
    OLD.task_canvas_name IS NOT NEW.task_canvas_name
    OR OLD.task_node_id IS NOT NEW.task_node_id
    OR OLD.task_id IS NOT NEW.task_id
    OR OLD.task_entity_home IS NOT NEW.task_entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work artifact task reference is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_task_transitions_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_transitions
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work transition home is immutable');
  END;

  CREATE TRIGGER IF NOT EXISTS work_delivery_receipts_home_immutable
  BEFORE UPDATE OF entity_home ON work_delivery_receipts
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'work delivery receipt home is immutable');
  END;
  
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;

`.replace(`  
  CREATE TABLE IF NOT EXISTS work_proposal_events (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL
      CHECK (
        length(seq) BETWEEN 1 AND 32
        AND seq NOT GLOB '*[^0-9]*'
        AND substr(seq, 1, 1) <> '0'
      ),
    record_type TEXT NOT NULL
      CHECK (record_type IN ('command', 'fact', 'disposition')),
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    content_sha256 TEXT NOT NULL
      CHECK (
        length(content_sha256) = 64
        AND content_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    record_json TEXT NOT NULL
      CHECK (
        length(record_json) BETWEEN 2 AND 262144
        AND json_valid(record_json)
      ),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (event_home, entity_home, seq),
    UNIQUE (event_home, entity_home, seq, content_sha256),
    FOREIGN KEY (event_home, entity_home)
      REFERENCES work_event_sequences(event_home, entity_home)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (event_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pending_proposal_commands (
    event_home TEXT NOT NULL,
    entity_home TEXT NOT NULL,
    seq TEXT NOT NULL,
    canvas_name TEXT NOT NULL,
    node_id TEXT NOT NULL,
    proposal_id TEXT NOT NULL,
    operation TEXT NOT NULL
      CHECK (operation IN ('proposal.create', 'proposal.approve')),
    resolution_status TEXT
      CHECK (
        resolution_status IS NULL
        OR resolution_status IN ('applied', 'rejected')
      ),
    resolution_event_home TEXT,
    resolution_entity_home TEXT,
    resolution_seq TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    resolved_at TEXT,
    PRIMARY KEY (event_home, entity_home, seq),
    CHECK (
      (
        resolution_status IS NULL
        AND resolution_event_home IS NULL
        AND resolution_entity_home IS NULL
        AND resolution_seq IS NULL
        AND resolved_at IS NULL
      )
      OR
      (
        resolution_status IS NOT NULL
        AND resolution_event_home IS NOT NULL
        AND resolution_entity_home IS NOT NULL
        AND resolution_seq IS NOT NULL
        AND resolved_at IS NOT NULL
      )
    ),
    FOREIGN KEY (event_home, entity_home, seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_task_proposals (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    proposal_id TEXT NOT NULL CHECK (length(proposal_id) BETWEEN 1 AND 256),
    entity_home TEXT NOT NULL,
    fact_event_home TEXT NOT NULL,
    fact_entity_home TEXT NOT NULL,
    fact_seq TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('pending', 'approved', 'rejected')),
    brief_json TEXT NOT NULL CHECK (json_valid(brief_json)),
    proposer_seat_id TEXT NOT NULL
      CHECK (
        length(proposer_seat_id) = 69
        AND substr(proposer_seat_id, 1, 5) = 'seat_'
        AND substr(proposer_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
      ),
    proposer_canvas_name TEXT NOT NULL
      CHECK (length(proposer_canvas_name) BETWEEN 1 AND 256),
    proposer_node_id TEXT NOT NULL
      CHECK (length(proposer_node_id) BETWEEN 1 AND 256),
    approved_task_id TEXT,
    metadata_json TEXT CHECK (metadata_json IS NULL OR json_valid(metadata_json)),
    reason TEXT,
    created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    origin_at TEXT NOT NULL CHECK (length(origin_at) BETWEEN 1 AND 64),
    received_at TEXT NOT NULL CHECK (length(received_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, proposal_id),
    UNIQUE (fact_event_home, fact_entity_home, fact_seq),
    CHECK (entity_home = fact_entity_home),
    CHECK (fact_event_home = fact_entity_home),
    CHECK (
      (state = 'approved' AND approved_task_id IS NOT NULL)
      OR (state <> 'approved' AND approved_task_id IS NULL)
    ),
    FOREIGN KEY (entity_home)
      REFERENCES station_known_installations(installation_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT,
    FOREIGN KEY (fact_event_home, fact_entity_home, fact_seq)
      REFERENCES work_proposal_events(event_home, entity_home, seq)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_task_proposals_node
    ON work_task_proposals(canvas_name, node_id, created_at, proposal_id);
  CREATE INDEX IF NOT EXISTS work_pending_proposal_commands_route
    ON work_pending_proposal_commands(
      event_home,
      entity_home,
      length(seq),
      seq
    )
    WHERE resolution_event_home IS NULL;

  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_update
  BEFORE UPDATE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_proposal_events_immutable_delete
  BEFORE DELETE ON work_proposal_events
  BEGIN
    SELECT RAISE(ABORT, 'proposal records are immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_home_immutable
  BEFORE UPDATE OF entity_home ON work_task_proposals
  WHEN OLD.entity_home <> NEW.entity_home
  BEGIN
    SELECT RAISE(ABORT, 'task proposal home is immutable');
  END;
  CREATE TRIGGER IF NOT EXISTS work_task_proposals_proposer_immutable
  BEFORE UPDATE OF proposer_seat_id, proposer_canvas_name, proposer_node_id
  ON work_task_proposals
  WHEN
    OLD.proposer_seat_id <> NEW.proposer_seat_id
    OR OLD.proposer_canvas_name <> NEW.proposer_canvas_name
    OR OLD.proposer_node_id <> NEW.proposer_node_id
  BEGIN
    SELECT RAISE(ABORT, 'task proposal author is immutable');
  END;

`,"").replace(`  CREATE TRIGGER IF NOT EXISTS work_tasks_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_tasks
  WHEN
    OLD.actor_seat_id IS NOT NULL
    AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
    AND NOT (
      NEW.actor_seat_id IS NULL
      AND NEW.state = 'submitted'
    )
  BEGIN
    SELECT RAISE(
      ABORT,
      'work task actor seat is immutable except for operator release'
    );
  END;`,`  CREATE TRIGGER IF NOT EXISTS work_tasks_actor_immutable
  BEFORE UPDATE OF actor_seat_id ON work_tasks
  WHEN
    OLD.actor_seat_id IS NOT NULL
    AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
  BEGIN
    SELECT RAISE(ABORT, 'work task actor seat is immutable after first claim');
  END;`),wG=`
  CREATE TABLE IF NOT EXISTS work_pad_meta (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    revision INTEGER NOT NULL CHECK (revision >= 0),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_images (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    element_id TEXT NOT NULL CHECK (length(element_id) BETWEEN 1 AND 256),
    x REAL NOT NULL,
    y REAL NOT NULL,
    w REAL NOT NULL CHECK (w > 0),
    h REAL NOT NULL CHECK (h > 0),
    z INTEGER NOT NULL,
    ref_json TEXT NOT NULL CHECK (json_valid(ref_json)),
    PRIMARY KEY (canvas_name, node_id, element_id),
    FOREIGN KEY (canvas_name, node_id)
      REFERENCES work_pad_meta(canvas_name, node_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_shapes (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    element_id TEXT NOT NULL CHECK (length(element_id) BETWEEN 1 AND 256),
    type TEXT NOT NULL CHECK (type IN ('box', 'ellipse', 'triangle', 'label')),
    x REAL NOT NULL,
    y REAL NOT NULL,
    w REAL NOT NULL CHECK (w > 0),
    h REAL NOT NULL CHECK (h > 0),
    z INTEGER NOT NULL,
    fill TEXT CHECK (fill IS NULL OR length(fill) BETWEEN 1 AND 256),
    stroke TEXT CHECK (stroke IS NULL OR length(stroke) BETWEEN 1 AND 256),
    text TEXT CHECK (text IS NULL OR length(text) >= 1),
    status TEXT CHECK (
      status IS NULL OR status IN ('none', 'active', 'done', 'blocked')
    ),
    PRIMARY KEY (canvas_name, node_id, element_id),
    FOREIGN KEY (canvas_name, node_id)
      REFERENCES work_pad_meta(canvas_name, node_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_edges (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    element_id TEXT NOT NULL CHECK (length(element_id) BETWEEN 1 AND 256),
    from_id TEXT NOT NULL CHECK (length(from_id) BETWEEN 1 AND 256),
    to_id TEXT NOT NULL CHECK (length(to_id) BETWEEN 1 AND 256),
    from_side TEXT CHECK (
      from_side IS NULL OR from_side IN ('top', 'right', 'bottom', 'left')
    ),
    to_side TEXT CHECK (
      to_side IS NULL OR to_side IN ('top', 'right', 'bottom', 'left')
    ),
    label TEXT CHECK (label IS NULL OR length(label) >= 1),
    PRIMARY KEY (canvas_name, node_id, element_id),
    FOREIGN KEY (canvas_name, node_id)
      REFERENCES work_pad_meta(canvas_name, node_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_inks (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    element_id TEXT NOT NULL CHECK (length(element_id) BETWEEN 1 AND 256),
    z INTEGER NOT NULL,
    color TEXT NOT NULL CHECK (length(color) BETWEEN 1 AND 256),
    width REAL NOT NULL CHECK (width > 0),
    points_json TEXT NOT NULL CHECK (json_valid(points_json)),
    PRIMARY KEY (canvas_name, node_id, element_id),
    FOREIGN KEY (canvas_name, node_id)
      REFERENCES work_pad_meta(canvas_name, node_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_pins (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    element_id TEXT NOT NULL CHECK (length(element_id) BETWEEN 1 AND 256),
    x REAL NOT NULL,
    y REAL NOT NULL,
    bounds_json TEXT CHECK (bounds_json IS NULL OR json_valid(bounds_json)),
    mentions_json TEXT NOT NULL CHECK (json_valid(mentions_json)),
    PRIMARY KEY (canvas_name, node_id, element_id),
    FOREIGN KEY (canvas_name, node_id)
      REFERENCES work_pad_meta(canvas_name, node_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS work_pad_posts (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    pin_id TEXT NOT NULL CHECK (length(pin_id) BETWEEN 1 AND 256),
    post_id TEXT NOT NULL CHECK (length(post_id) BETWEEN 1 AND 256),
    position INTEGER NOT NULL CHECK (position >= 0),
    author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
    author_seat_id TEXT
      CHECK (
        author_seat_id IS NULL
        OR (
          length(author_seat_id) = 69
          AND substr(author_seat_id, 1, 5) = 'seat_'
          AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
        )
      ),
    author_node_id TEXT
      CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
    author_label TEXT
      CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
    parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
    PRIMARY KEY (canvas_name, node_id, pin_id, post_id),
    UNIQUE (canvas_name, node_id, pin_id, position),
    FOREIGN KEY (canvas_name, node_id, pin_id)
      REFERENCES work_pad_pins(canvas_name, node_id, element_id)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
  ) STRICT, WITHOUT ROWID;

  CREATE INDEX IF NOT EXISTS work_pad_shapes_node
    ON work_pad_shapes(canvas_name, node_id, z, element_id);
  CREATE INDEX IF NOT EXISTS work_pad_posts_pin
    ON work_pad_posts(canvas_name, node_id, pin_id, position);
`,CG=`
  CREATE TABLE IF NOT EXISTS work_pad_read_cursors (
    canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
    node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
    pin_id TEXT NOT NULL CHECK (length(pin_id) BETWEEN 1 AND 256),
    principal_key TEXT NOT NULL CHECK (length(principal_key) BETWEEN 1 AND 256),
    last_read_position INTEGER NOT NULL CHECK (last_read_position >= -1),
    updated_at TEXT NOT NULL CHECK (length(updated_at) BETWEEN 1 AND 64),
    PRIMARY KEY (canvas_name, node_id, pin_id, principal_key)
  ) STRICT, WITHOUT ROWID;
`,EG=o9.replaceAll("item_kind IN ('task', 'request', 'message', 'artifact', 'delivery', 'topic', 'post')","item_kind IN ('task', 'request', 'message', 'artifact', 'delivery', 'topic', 'post', 'pad')").replaceAll(`'board.topic.create',
          'board.post.append'
        )`,`'board.topic.create',
          'board.post.append',
          'pad.patch'
        )`),MG=`
  CREATE TABLE IF NOT EXISTS work_canvas_revisions (
    canvas_name TEXT NOT NULL
      PRIMARY KEY
      CHECK (length(canvas_name) BETWEEN 1 AND 256),
    revision INTEGER NOT NULL CHECK (revision >= 0)
  ) STRICT, WITHOUT ROWID;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_events_insert
    AFTER INSERT ON work_events
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.item_canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_proposal_events_insert
    AFTER INSERT ON work_proposal_events
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_topics_insert
    AFTER INSERT ON work_board_topics
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_topics_update
    AFTER UPDATE ON work_board_topics
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_topics_delete
    AFTER DELETE ON work_board_topics
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_posts_insert
    AFTER INSERT ON work_board_posts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_posts_update
    AFTER UPDATE ON work_board_posts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_posts_delete
    AFTER DELETE ON work_board_posts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_cursors_insert
    AFTER INSERT ON work_board_read_cursors
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_cursors_update
    AFTER UPDATE ON work_board_read_cursors
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_board_cursors_delete
    AFTER DELETE ON work_board_read_cursors
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_meta_insert
    AFTER INSERT ON work_pad_meta
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_meta_update
    AFTER UPDATE ON work_pad_meta
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_meta_delete
    AFTER DELETE ON work_pad_meta
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_cursors_insert
    AFTER INSERT ON work_pad_read_cursors
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_cursors_update
    AFTER UPDATE ON work_pad_read_cursors
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_cursors_delete
    AFTER DELETE ON work_pad_read_cursors
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;
`,HS=`
  INSERT INTO work_canvas_revisions(canvas_name, revision)
  SELECT canvas_name, count(*)
  FROM (
    SELECT item_canvas_name AS canvas_name FROM work_events
    UNION ALL
    SELECT canvas_name FROM work_proposal_events
    UNION ALL
    SELECT canvas_name FROM work_board_topics
    UNION ALL
    SELECT canvas_name FROM work_board_posts
    UNION ALL
    SELECT canvas_name FROM work_board_read_cursors
    UNION ALL
    SELECT canvas_name FROM work_pad_meta
    UNION ALL
    SELECT canvas_name FROM work_pad_read_cursors
  )
  GROUP BY canvas_name
  ON CONFLICT(canvas_name) DO UPDATE
    SET revision = max(work_canvas_revisions.revision, excluded.revision);
`,jG=`

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_tasks_insert
    AFTER INSERT ON work_tasks
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_tasks_update
    AFTER UPDATE ON work_tasks
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_tasks_delete
    AFTER DELETE ON work_tasks
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_requests_insert
    AFTER INSERT ON work_requests
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_requests_update
    AFTER UPDATE ON work_requests
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_requests_delete
    AFTER DELETE ON work_requests
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_messages_insert
    AFTER INSERT ON work_messages
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_messages_update
    AFTER UPDATE ON work_messages
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_messages_delete
    AFTER DELETE ON work_messages
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_messages_insert
    AFTER INSERT ON work_task_messages
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_messages_update
    AFTER UPDATE ON work_task_messages
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_messages_delete
    AFTER DELETE ON work_task_messages
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_dependencies_insert
    AFTER INSERT ON work_task_dependencies
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_dependencies_update
    AFTER UPDATE ON work_task_dependencies
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_dependencies_delete
    AFTER DELETE ON work_task_dependencies
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_finish_insert
    AFTER INSERT ON work_task_finish
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_finish_update
    AFTER UPDATE ON work_task_finish
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_finish_delete
    AFTER DELETE ON work_task_finish
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_artifacts_insert
    AFTER INSERT ON work_artifacts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_artifacts_update
    AFTER UPDATE ON work_artifacts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_artifacts_delete
    AFTER DELETE ON work_artifacts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_delivery_receipts_insert
    AFTER INSERT ON work_delivery_receipts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.delivered_canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_delivery_receipts_update
    AFTER UPDATE ON work_delivery_receipts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.delivered_canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_delivery_receipts_delete
    AFTER DELETE ON work_delivery_receipts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.delivered_canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_proposals_insert
    AFTER INSERT ON work_task_proposals
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_proposals_update
    AFTER UPDATE ON work_task_proposals
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_task_proposals_delete
    AFTER DELETE ON work_task_proposals
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_proposal_planning_insert
    AFTER INSERT ON work_proposal_planning
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_proposal_planning_update
    AFTER UPDATE ON work_proposal_planning
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_proposal_planning_delete
    AFTER DELETE ON work_proposal_planning
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_posts_insert
    AFTER INSERT ON work_pad_posts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_posts_update
    AFTER UPDATE ON work_pad_posts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_posts_delete
    AFTER DELETE ON work_pad_posts
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_shapes_insert
    AFTER INSERT ON work_pad_shapes
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_shapes_update
    AFTER UPDATE ON work_pad_shapes
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (NEW.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;

  CREATE TRIGGER IF NOT EXISTS work_canvas_revision_pad_shapes_delete
    AFTER DELETE ON work_pad_shapes
    BEGIN
      INSERT INTO work_canvas_revisions(canvas_name, revision)
      VALUES (OLD.canvas_name, 1)
      ON CONFLICT(canvas_name) DO UPDATE
        SET revision = work_canvas_revisions.revision + 1;
    END;
`;var K50=`
  CREATE TABLE IF NOT EXISTS state_schema_identity (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    actual_schema_sha256 TEXT NOT NULL
      CHECK (
        length(actual_schema_sha256) = 64
        AND actual_schema_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    source_schema_sha256 TEXT NOT NULL
      CHECK (
        length(source_schema_sha256) = 64
        AND source_schema_sha256 NOT GLOB '*[^a-f0-9]*'
      ),
    verified_at TEXT NOT NULL
      CHECK (length(verified_at) BETWEEN 1 AND 64)
  ) STRICT;
`,H50=`
  CREATE TABLE IF NOT EXISTS canvas_generations (
    generation TEXT PRIMARY KEY
      CHECK (
        length(generation) > 0
        AND generation NOT GLOB '*[^0-9]*'
        AND (generation = '0' OR substr(generation, 1, 1) <> '0')
      ),
    created_at TEXT NOT NULL CHECK (length(created_at) > 0),
    cause TEXT NOT NULL CHECK (length(cause) > 0),
    intent_sha256 TEXT NOT NULL CHECK (length(intent_sha256) = 64),
    document_count INTEGER NOT NULL
      CHECK (document_count >= 0)
  ) STRICT;

  CREATE TABLE IF NOT EXISTS canvas_generation_documents (
    generation TEXT NOT NULL
      REFERENCES canvas_generations(generation) ON DELETE CASCADE,
    name TEXT NOT NULL CHECK (length(name) > 0),
    body TEXT NOT NULL,
    sha256 TEXT NOT NULL CHECK (length(sha256) = 64),
    modified_at TEXT NOT NULL CHECK (length(modified_at) > 0),
    PRIMARY KEY (generation, name)
  ) STRICT, WITHOUT ROWID;

  CREATE TABLE IF NOT EXISTS canvas_head (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    generation TEXT NOT NULL
      REFERENCES canvas_generations(generation) ON DELETE RESTRICT
  ) STRICT;
`,WS=[K50,H50,Ex,jx,Mx,Ix,vx,YS,QS,JS,$S,GS,HD],KD0=WS.join(`
`),US=[...WS,BG],HD0=US.join(`
`),W50=[...US,VG],DS=W50.map((X)=>X===HD?_D:X),WD0=DS.join(`
`),NS=[...DS,NG],UD0=NS.join(`
`),BS=[...NS,RG],DD0=BS.join(`
`),VS=[...BS,AG],ND0=VS.join(`
`),zS=[...VS,z7],BD0=zS.join(`
`),qS=zS.map((X)=>X===_D?R5:X),VD0=qS.join(`
`),LS=[...qS,PG],zD0=LS.join(`
`),OS=[...LS,TG],qD0=OS.join(`
`),WD=[...OS,FG],LD0=WD.join(`
`),U50=WD.map((X)=>X===R5?KD:X),OD0=U50.join(`
`),TS=WD.map((X)=>X===R5?o9:X),TD0=TS.join(`
`),FS=TS.map((X)=>X===z7?_S:X),FD0=FS.join(`
`),RS=[...FS.map((X)=>X===o9?EG:X),wG],RD0=RS.join(`
`),AS=[...RS,CG],AD0=AS.join(`
`),PS=[...AS,MG],PD0=PS.join(`
`),D50=[...PS,jG],wS=D50.join(`
`);import{createHash as N50}from"node:crypto";import{DatabaseSync as B50}from"node:sqlite";var V50="0".repeat(64),z50=(X)=>N50("sha256").update(X).digest("hex"),q50=(X)=>{let Y=[],Q=0,J=($)=>{let G=$==="["?"]":$,_=$;Q+=1;while(Q<X.length){let K=X[Q];if(_+=K,Q+=1,K!==G)continue;if(X[Q]===G){_+=G,Q+=1;continue}break}Y.push(_)};while(Q<X.length){let $=X[Q];if(/\s/u.test($)){Q+=1;continue}if($==="-"&&X[Q+1]==="-"){Q+=2;while(Q<X.length&&X[Q]!==`
`)Q+=1;continue}if($==="/"&&X[Q+1]==="*"){let H=X.indexOf("*/",Q+2);Q=H===-1?X.length:H+2;continue}if($==="'"||$==='"'||$==="`"||$==="["){J($);continue}let G=X.slice(Q,Q+3);if(G==="->>"){Y.push(G),Q+=3;continue}let _=X.slice(Q,Q+2);if(["||","<<",">>","<=",">=","==","!=","<>","->"].includes(_)){Y.push(_),Q+=2;continue}if(/[\[\]\(\),.;+\-*/%<>=!|&~]/u.test($)){Y.push($),Q+=1;continue}let K=Q;while(Q<X.length&&!/[\s'"`\[\]\(\),.;+\-*/%<>=!|&~]/u.test(X[Q]))Q+=1;Y.push(X.slice(K,Q).toLowerCase())}return JSON.stringify(Y)},xG=(X)=>X.prepare(`
          SELECT type, name, tbl_name AS table_name, sql
          FROM sqlite_schema
          WHERE type IN ('table', 'index', 'view', 'trigger')
            AND name NOT GLOB 'sqlite_*'
          ORDER BY type COLLATE BINARY, name COLLATE BINARY
        `).all().map((Y)=>({type:String(Y.type),name:String(Y.name),tableName:String(Y.table_name),sql:Y.sql===null?null:q50(String(Y.sql))})),IG=(X)=>z50(JSON.stringify(X)),UD=(X)=>IG(xG(X)),DD=(X)=>xG(X).length===0,CS=(X)=>`${X.type}:${X.name}`,L50=(X,Y)=>{let Q=new Map(X.map((K)=>[CS(K),K])),J=new Map(Y.map((K)=>[CS(K),K])),$=[...Q.keys()].filter((K)=>!J.has(K)).sort(),G=[...J.keys()].filter((K)=>!Q.has(K)).sort(),_=[...J.keys()].filter((K)=>{let H=Q.get(K),W=J.get(K);return H!==void 0&&W!==void 0&&JSON.stringify(H)!==JSON.stringify(W)}).sort();return[$.length>0?`unexpected=${$.join(",")}`:"",G.length>0?`missing=${G.join(",")}`:"",_.length>0?`changed=${_.join(",")}`:""].filter(Boolean).join("; ")},ES=(X)=>{let Y=new B50(":memory:",{open:!0,readOnly:!1,allowExtension:!1,enableForeignKeyConstraints:!0,enableDoubleQuotedStringLiterals:!1,allowBareNamedParameters:!1,allowUnknownNamedParameters:!1});try{return Y.exec(`
      PRAGMA foreign_keys = ON;
      PRAGMA trusted_schema = OFF;
    `),Y.exec(X),xG(Y)}finally{Y.close()}},MS=(X)=>({actualSchemaSha256:IG(ES(X))}),SG=(X)=>{if(X.prepare(`
        SELECT 1
        FROM sqlite_schema
        WHERE type = 'table'
          AND name = 'state_schema_identity'
      `).get()===void 0)throw Error("state schema identity table is missing");let Q=X.prepare(`
        SELECT
          actual_schema_sha256,
          verified_at
        FROM state_schema_identity
        WHERE singleton = 1
      `).get();if(Q===void 0)throw Error("state schema identity witness is missing");return{actualSchemaSha256:String(Q.actual_schema_sha256),verifiedAt:String(Q.verified_at)}},ND=(X)=>{let Y=SG(X),Q=UD(X);if(Y.actualSchemaSha256!==Q)throw Error("state schema changed after its recorded identity was stamped");return Y},BD=(X,Y)=>{X.prepare(`
        INSERT INTO state_schema_identity(
          singleton,
          actual_schema_sha256,
          source_schema_sha256,
          verified_at
        ) VALUES (1, ?, ?, ?)
        ON CONFLICT(singleton) DO UPDATE SET
          actual_schema_sha256 = excluded.actual_schema_sha256,
          source_schema_sha256 = excluded.source_schema_sha256,
          verified_at = excluded.verified_at
      `).run(Y.actualSchemaSha256,V50,new Date().toISOString())},VD=(X,Y)=>{let Q=ES(Y),J=xG(X),$=IG(Q),G=IG(J);if(G!==$){let _=L50(J,Q);throw Error(`state schema identity mismatch${_.length>0?` (${_})`:""}`)}return{actualSchemaSha256:G}},zD=(X,Y)=>{let Q=VD(X,Y);return BD(X,Q),Q};var $1="expand-only",IS={actualSchemaSha256:"376d0448e43bda8373930f74140ff2f11c315bcf9c9382daf25bd4cb7b910195"},O50={actualSchemaSha256:"c7050c73efcea27e7ccb6e7c687f213cae8d2c32e8903d1ab7c7f1e8aeb953c3"},T50={actualSchemaSha256:"4a8d0fd0545e2108c79c611fc4f56acb1ce96a1972cae13cbf7e716b241bc941"},F50={actualSchemaSha256:"8870c6e4b932ee4a2895bfc9926e2be97f0baa3c538bdfa1e9e8cca5eb354d7f"},R50={actualSchemaSha256:"4c0fd324cb37c9c609acdeade50a10325b2bffddaae40c0ee8fa464d6cfc6b6f"},A50={actualSchemaSha256:"f097722579ffcaad121b0e5eb62076a8ab70cb9c5d66a78978d572612703be53"},P50={actualSchemaSha256:"9f2aace6eaefaa20c1141304d5d4d62544a0500ff3bc7f30acda94d4099006bc"},w50={actualSchemaSha256:"8239ad37bd9fb890d585f5fedef69086890a75b1c01b5fb257bb4573c2809e71"},C50={actualSchemaSha256:"00777be6fb3361c057a799d0f58c86d364518d24a1eb2d8a08b6f32c58d7bcef"},E50={actualSchemaSha256:"7844862b7ed357a60b4e78a336ae7229aab8dd812622862f0de56c916e12269e"},M50={actualSchemaSha256:"66e16dda9d6d938b107ec25b0edd58f1a964d40192fd1d9fe35793665d03e99f"},j50={actualSchemaSha256:"a4bf3db00027fc2a52b5b73592d3d33b1f7d739c5ec7f32cdde41e3d95d5d53e"},I50={actualSchemaSha256:"fd6f5b73d474c83ed8ff93c24b60b8587f7cfe3783d2fe65274c7611ae431abf"},x50={actualSchemaSha256:"646f7b553d54bd55cbdab2562132c22508b8ea9b4f29b7f9ae31c8f93d9bf06f"},S50={actualSchemaSha256:"419206d0b4a3e52fa7d24a04c0cf07fb17f25cbf60b83e64e6d89bb32d4fb5c9"},v50={actualSchemaSha256:"68c01a84360fe399ea98c2963aa763f86cfd0c2c5262ecea9996ee984a3cb3bb"},k50={actualSchemaSha256:"5f580bc42f6e3332256ca6bfadda1489f42889616c75acd1cf4a3af1259249bb"},b50={actualSchemaSha256:"06411da7eb2843c89a7b170321ca0992e8c72b9da65e3fa702b2fce1197980e1"},g50={actualSchemaSha256:"e203c32e409f105a110bfac9a3f98b3eefaba0885d60c0ec3c25d705ec4980ab"};var i9=20,y50=[{fromVersion:1,toVersion:2,name:"add-license-activation",safety:$1,fromIdentity:IS,migrate:(X)=>{X.exec(BG)}},{fromVersion:2,toVersion:3,name:"bind-license-entitlement-to-dodo-product",safety:$1,fromIdentity:O50,migrate:(X)=>{X.exec(VG)}},{fromVersion:3,toVersion:4,name:"allow-atomic-task-release",safety:$1,fromIdentity:T50,replacesObjects:["trigger:work_tasks_actor_immutable"],migrate:(X)=>{X.exec(`
          DROP TRIGGER work_tasks_actor_immutable;
          CREATE TRIGGER work_tasks_actor_immutable
          BEFORE UPDATE OF actor_seat_id ON work_tasks
          WHEN
            OLD.actor_seat_id IS NOT NULL
            AND OLD.actor_seat_id IS NOT NEW.actor_seat_id
            AND NOT (
              NEW.actor_seat_id IS NULL
              AND NEW.state = 'submitted'
            )
          BEGIN
            SELECT RAISE(
              ABORT,
              'work task actor seat is immutable except for operator release'
            );
          END;
        `)}},{fromVersion:4,toVersion:5,name:"add-task-proposals",safety:$1,fromIdentity:F50,migrate:(X)=>{X.exec(ZS)}},{fromVersion:5,toVersion:6,name:"add-canvas-entities",safety:$1,fromIdentity:R50,migrate:(X)=>{X.exec(NG),h50(X)}},{fromVersion:6,toVersion:7,name:"add-work-task-dependencies",safety:$1,fromIdentity:A50,migrate:(X)=>{X.exec(RG)}},{fromVersion:7,toVersion:8,name:"add-work-task-finish-criteria",safety:$1,fromIdentity:P50,migrate:(X)=>{X.exec(AG)}},{fromVersion:8,toVersion:9,name:"add-work-board",safety:$1,fromIdentity:w50,migrate:(X)=>{X.exec(z7)}},{fromVersion:9,toVersion:10,name:"board-event-vocabulary",safety:$1,fromIdentity:C50,replacesTables:["work_events","work_pending_commands"],migrate:(X)=>{X.exec(`
          CREATE TABLE work_events__migrate_bak AS SELECT * FROM work_events;
          CREATE TABLE work_pending_commands__migrate_bak AS
            SELECT * FROM work_pending_commands;

          DROP TABLE work_pending_commands;
          DROP TABLE work_events;
        `),X.exec(R5),X.exec(`
          INSERT INTO work_events SELECT * FROM work_events__migrate_bak;
          INSERT INTO work_pending_commands
            SELECT * FROM work_pending_commands__migrate_bak;
          DROP TABLE work_events__migrate_bak;
          DROP TABLE work_pending_commands__migrate_bak;
        `)}},{fromVersion:10,toVersion:11,name:"add-work-proposal-planning",safety:$1,fromIdentity:E50,migrate:(X)=>{X.exec(PG)}},{fromVersion:11,toVersion:12,name:"add-content-manifest",safety:$1,fromIdentity:M50,migrate:(X)=>{X.exec(TG)}},{fromVersion:12,toVersion:13,name:"add-content-inline-media-migration-marker",safety:$1,fromIdentity:j50,migrate:(X)=>{X.exec(FG)}},{fromVersion:13,toVersion:14,name:"proposal-reject-event-vocabulary",safety:$1,fromIdentity:I50,replacesTables:["work_proposal_events","work_pending_proposal_commands"],migrate:(X)=>{X.exec(`
          CREATE TABLE work_proposal_events__migrate_bak AS
            SELECT * FROM work_proposal_events;
          CREATE TABLE work_pending_proposal_commands__migrate_bak AS
            SELECT * FROM work_pending_proposal_commands;

          DROP TABLE work_pending_proposal_commands;
          DROP TABLE work_proposal_events;
        `),X.exec(KS),X.exec(`
          INSERT INTO work_proposal_events
            SELECT * FROM work_proposal_events__migrate_bak;
          INSERT INTO work_pending_proposal_commands
            SELECT * FROM work_pending_proposal_commands__migrate_bak;
          DROP TABLE work_proposal_events__migrate_bak;
          DROP TABLE work_pending_proposal_commands__migrate_bak;
        `)}},{fromVersion:14,toVersion:15,name:"task-archived-soft-delete",safety:$1,fromIdentity:x50,replacesTables:["work_tasks","work_task_transitions"],migrate:(X)=>{X.exec(`
          CREATE TABLE work_tasks__migrate_bak AS SELECT * FROM work_tasks;
          CREATE TABLE work_task_transitions__migrate_bak AS
            SELECT * FROM work_task_transitions;

          DROP TABLE work_task_transitions;
          DROP TABLE work_tasks;
        `),X.exec(o9),X.exec(`
          INSERT INTO work_tasks SELECT * FROM work_tasks__migrate_bak;
          INSERT INTO work_task_transitions
            SELECT * FROM work_task_transitions__migrate_bak;
          DROP TABLE work_tasks__migrate_bak;
          DROP TABLE work_task_transitions__migrate_bak;
        `)}},{fromVersion:15,toVersion:16,name:"board-post-tags",safety:$1,fromIdentity:S50,replacesTables:["work_board_posts"],migrate:(X)=>{X.exec(`
          CREATE TABLE work_board_posts__migrate_bak AS
            SELECT * FROM work_board_posts;
          DROP TABLE work_board_posts;
        `),X.exec(`
          CREATE TABLE work_board_posts (
            canvas_name TEXT NOT NULL CHECK (length(canvas_name) BETWEEN 1 AND 256),
            node_id TEXT NOT NULL CHECK (length(node_id) BETWEEN 1 AND 256),
            topic_id TEXT NOT NULL CHECK (length(topic_id) BETWEEN 1 AND 256),
            post_id TEXT NOT NULL CHECK (length(post_id) BETWEEN 1 AND 256),
            position INTEGER NOT NULL CHECK (position >= 0),
            author_kind TEXT NOT NULL CHECK (author_kind IN ('operator', 'actor')),
            author_seat_id TEXT
              CHECK (
                author_seat_id IS NULL
                OR (
                  length(author_seat_id) = 69
                  AND substr(author_seat_id, 1, 5) = 'seat_'
                  AND substr(author_seat_id, 6) NOT GLOB '*[^a-f0-9]*'
                )
              ),
            author_node_id TEXT
              CHECK (author_node_id IS NULL OR length(author_node_id) BETWEEN 1 AND 256),
            author_label TEXT
              CHECK (author_label IS NULL OR length(author_label) BETWEEN 1 AND 256),
            parts_json TEXT NOT NULL CHECK (json_valid(parts_json)),
            tags_json TEXT
              CHECK (tags_json IS NULL OR json_valid(tags_json)),
            created_at TEXT NOT NULL CHECK (length(created_at) BETWEEN 1 AND 64),
            PRIMARY KEY (canvas_name, node_id, topic_id, post_id),
            UNIQUE (canvas_name, node_id, topic_id, position),
            FOREIGN KEY (canvas_name, node_id, topic_id)
              REFERENCES work_board_topics(canvas_name, node_id, topic_id)
              ON DELETE RESTRICT
              ON UPDATE RESTRICT
          ) STRICT, WITHOUT ROWID;
          CREATE INDEX IF NOT EXISTS work_board_posts_thread
            ON work_board_posts(canvas_name, node_id, topic_id, position);
        `),X.exec(`
          INSERT INTO work_board_posts(
            canvas_name, node_id, topic_id, post_id, position,
            author_kind, author_seat_id, author_node_id, author_label,
            parts_json, tags_json, created_at
          )
          SELECT
            canvas_name, node_id, topic_id, post_id, position,
            author_kind, author_seat_id, author_node_id, author_label,
            parts_json, NULL, created_at
          FROM work_board_posts__migrate_bak;
          DROP TABLE work_board_posts__migrate_bak;
        `)}},{fromVersion:16,toVersion:17,name:"add-work-pad",safety:$1,fromIdentity:v50,replacesTables:["work_events","work_pending_commands"],migrate:(X)=>{X.exec(wG),X.exec(`
          CREATE TABLE work_events__migrate_bak AS SELECT * FROM work_events;
          CREATE TABLE work_pending_commands__migrate_bak AS
            SELECT * FROM work_pending_commands;

          DROP TABLE work_pending_commands;
          DROP TABLE work_events;
        `),X.exec(EG),X.exec(`
          INSERT INTO work_events SELECT * FROM work_events__migrate_bak;
          INSERT INTO work_pending_commands
            SELECT * FROM work_pending_commands__migrate_bak;
          DROP TABLE work_events__migrate_bak;
          DROP TABLE work_pending_commands__migrate_bak;
        `)}},{fromVersion:17,toVersion:18,name:"add-work-pad-read-cursors",safety:$1,fromIdentity:k50,migrate:(X)=>{X.exec(CG)}},{fromVersion:18,toVersion:19,name:"add-work-canvas-revision-counter",safety:$1,fromIdentity:b50,migrate:(X)=>{X.exec(MG),X.exec(HS)}},{fromVersion:19,toVersion:20,name:"witness-every-projected-work-table",safety:$1,fromIdentity:g50,migrate:(X)=>{X.exec(jG)}}],h50=(X)=>{let Y=X.prepare("SELECT generation FROM canvas_head WHERE singleton = 1").get();if(Y===void 0)return;let Q=X.prepare(`
        SELECT name, body
        FROM canvas_generation_documents
        WHERE generation = ?
      `).all(Y.generation),J=new Date().toISOString(),$=X.prepare(`
      INSERT INTO canvas_entities(
        canvas_name,
        entity_id,
        kind,
        binding_id,
        lifecycle,
        created_at,
        updated_at,
        archived_at,
        soft_deleted_at
      ) VALUES (?, ?, ?, ?, 'active', ?, ?, NULL, NULL)
      ON CONFLICT(canvas_name, entity_id) DO NOTHING
    `);for(let G of Q){if(G.body.length===0)continue;let _;try{_=JSON.parse(G.body)}catch{throw Error(`canvas entity backfill: document "${G.name}" is not valid JSON`)}if(_===null||typeof _!=="object"||!("nodes"in _)||!Array.isArray(_.nodes))throw Error(`canvas entity backfill: document "${G.name}" is not a canvas body with nodes[]`);let K=new Set;for(let H of _.nodes){if(H===null||typeof H!=="object"||!("id"in H)||typeof H.id!=="string")throw Error(`canvas entity backfill: document "${G.name}" has a node without a string id`);let W=H.id;if(W.length===0||W.length>256)throw Error(`canvas entity backfill: document "${G.name}" has an out-of-range entity id`);let D=null,U=null,N=H.ether;if(N!==null&&typeof N==="object"){let B=N.entity;if(B!==null&&typeof B==="object"&&typeof B.kind==="string"){let q=B.kind;if(q.length>0&&q.length<=128)D=q}let z=N.terminal;if(z!==null&&typeof z==="object"&&typeof z.bindingId==="string"){let q=z.bindingId;if(q.length>0&&q.length<=256)U=q}}if(D===null){let B=H.type;if(typeof B==="string"&&B.length>0&&B.length<=128)D=B}if(U!==null)if(K.has(U))U=null;else K.add(U);$.run(G.name,W,D,U,J,J)}}},xS={baselineVersion:1,baselineIdentity:IS,currentVersion:i9,currentSchemaSql:wS,migrations:y50},SS=(X)=>{let Y=X.prepare("PRAGMA user_version").get(),Q=Number(Y?.user_version);if(!Number.isSafeInteger(Q)||Q<0||Q>2147483647)throw Error(`state schema user_version is invalid: ${String(Y?.user_version)}`);return Q},qD=(X,Y)=>{if(!Number.isSafeInteger(Y)||Y<0||Y>2147483647)throw Error(`refusing invalid state schema version ${Y}`);X.exec(`PRAGMA user_version = ${Y}`)},m50=(X,Y)=>X.actualSchemaSha256===Y.actualSchemaSha256,z4=(X,Y,Q)=>{if(!m50(Y,Q))throw Error(`${X} identity is not a recognized Vellum Command schema`)},f50=(X)=>{let Y=X.prepare("PRAGMA foreign_key_check").all();if(Y.length>0)throw Error(`state schema migration leaves ${Y.length} foreign-key violation(s)`)},vS=(X)=>{let Y=X.prepare(`
        SELECT type, name, sql
        FROM sqlite_schema
        WHERE type IN ('table', 'index', 'view', 'trigger')
          AND name NOT GLOB 'sqlite_*'
        ORDER BY type COLLATE BINARY, name COLLATE BINARY
      `).all(),Q=new Map,J=new Map;for(let $ of Y){let G=String($.type),_=String($.name);if(G!=="table"){J.set(`${G}:${_}`,$.sql===null?null:String($.sql));continue}let K=X.prepare(`
          SELECT
            name,
            type,
            "notnull" AS not_null,
            dflt_value AS default_value,
            pk AS primary_key,
            hidden
          FROM pragma_table_xinfo(?)
          ORDER BY cid
        `).all(_);Q.set(_,new Map(K.map((H)=>[String(H.name),{name:String(H.name),type:String(H.type),notNull:Number(H.not_null),defaultValue:H.default_value===null?null:String(H.default_value),primaryKey:Number(H.primary_key),hidden:Number(H.hidden)}])))}return{tables:Q,retainedObjects:J}},d50=(X,Y,Q,J={indexes:new Set,triggers:new Set})=>{let $=vS(Y);for(let[G,_]of X.tables){let K=$.tables.get(G);if(K===void 0)throw Error(`state schema startup migration removed table ${G}`);for(let[H,W]of _){let D=K.get(H);if(D===void 0||JSON.stringify(D)!==JSON.stringify(W))throw Error(`state schema startup migration changed durable column ${G}.${H}`)}}for(let[G,_]of X.retainedObjects){if(Q.has(G))continue;let K=G.indexOf(":");if(K>0){let H=G.slice(0,K),W=G.slice(K+1);if(H==="trigger"&&J.triggers.has(W))continue;if(H==="index"&&J.indexes.has(W))continue}if($.retainedObjects.get(G)!==_)throw Error(`state schema startup migration changed durable ${G}`)}},p50=new Set([H0.SQLITE_DELETE,H0.SQLITE_DROP_INDEX,H0.SQLITE_DROP_TABLE,H0.SQLITE_DROP_TEMP_INDEX,H0.SQLITE_DROP_TEMP_TABLE,H0.SQLITE_DROP_TEMP_TRIGGER,H0.SQLITE_DROP_TEMP_VIEW,H0.SQLITE_DROP_TRIGGER,H0.SQLITE_DROP_VIEW,H0.SQLITE_DROP_VTABLE,H0.SQLITE_ATTACH,H0.SQLITE_DETACH,H0.SQLITE_REINDEX,H0.SQLITE_ANALYZE]),u50=new Set(["application_id","journal_mode","legacy_alter_table","schema_version","user_version","writable_schema"]),jS=(X)=>{let Y=X.replace(/--[^\r\n]*/gu," ").replace(/\/\*[\s\S]*?\*\//gu," ");if(/\balter\s+table\b[\s\S]*?\b(?:rename(?:\s+(?:to|column))?|drop\s+column)\b/iu.test(Y))throw Error("state schema startup migrations may not rename or drop tables or columns");if(/\b(?:insert\s+or\s+replace|replace\s+into)\b/iu.test(Y))throw Error("state schema startup migrations may not replace existing rows")},c50=(X,Y)=>{if(Y.size===0)return{indexes:new Set,triggers:new Set};let Q=[...Y],J=Q.map(()=>"?").join(", "),$=X.prepare(`
        SELECT type, name
        FROM sqlite_schema
        WHERE type IN ('index', 'trigger')
          AND tbl_name IN (${J})
      `).all(...Q),G=new Set,_=new Set;for(let K of $)if(K.type==="index")G.add(K.name);else if(K.type==="trigger")_.add(K.name);return{indexes:G,triggers:_}},l50=(X,Y,Q,J)=>{if(Y)return!1;if(X>=Q.currentVersion)return!1;let $=X===0?Q.baselineVersion:X;if($<Q.baselineVersion)return!1;while($<Q.currentVersion){let G=J.get($);if(G===void 0)return!1;if((G.replacesTables?.length??0)>0)return!0;$=G.toVersion}return!1},o50=(X,Y)=>{let Q=vS(X),J=new Set(Y.replacesObjects??[]),$=new Set(Y.replacesTables??[]),G=c50(X,$),_={exec:(K)=>{jS(K),X.exec(K)},prepare:(K,H)=>{return jS(K),X.prepare(K,H)}};X.setAuthorizer((K,H,W)=>{let D=H===null?"":H.toLowerCase(),U=H==="sqlite_schema"||H==="sqlite_master",N=H!==null&&$.has(H),B=H!==null&&H.endsWith("__migrate_bak"),z=H!==null&&G.indexes.has(H),q=H!==null&&G.triggers.has(H);return K===H0.SQLITE_TRANSACTION||K===H0.SQLITE_SAVEPOINT||p50.has(K)&&!(K===H0.SQLITE_REINDEX&&H!==null&&(!Q.retainedObjects.has(`index:${H}`)||z))&&!(K===H0.SQLITE_DROP_TRIGGER&&H!==null&&(J.has(`trigger:${H}`)||q))&&!(K===H0.SQLITE_DELETE&&(U&&(J.size>0||$.size>0)||N||B))&&!(K===H0.SQLITE_DROP_TABLE&&(N||B))&&!(K===H0.SQLITE_DROP_INDEX&&z)||K===H0.SQLITE_INSERT&&H!==null&&Q.tables.has(H)&&!$.has(H)||K===H0.SQLITE_UPDATE&&H!==null&&W!==null&&Q.tables.get(H)?.has(W)===!0||K===H0.SQLITE_PRAGMA&&H!==null&&u50.has(D)?H0.SQLITE_DENY:H0.SQLITE_OK});try{Y.migrate(_),d50(Q,X,J,G)}finally{X.setAuthorizer(null)}if(!X.isTransaction)throw Error(`state schema migration ${Y.fromVersion} -> ${Y.toVersion} escaped its startup transaction`)},i50=(X,Y)=>{let Q,J;try{Q=SG(X)}catch(G){J=G}let $=zD(X,Y);if(Q===void 0)throw J;return z4("recorded current state schema",Q,$),Q},r50=(X,Y)=>{let Q,J;try{Q=SG(X)}catch(G){J=G}let $=VD(X,Y);if(Q===void 0)throw J;return z4("recorded current state schema",Q,$),Q},kS=(X)=>{if(!Number.isSafeInteger(X.baselineVersion)||X.baselineVersion<1||!Number.isSafeInteger(X.currentVersion)||X.currentVersion<X.baselineVersion)throw Error("state schema migration version bounds are invalid");let Y=new Map;for(let Q of X.migrations){if(!Number.isSafeInteger(Q.fromVersion)||Q.fromVersion<X.baselineVersion||Q.toVersion!==Q.fromVersion+1||Q.toVersion>X.currentVersion||Q.name.length===0||Q.safety!==$1)throw Error(`invalid state schema migration ${Q.fromVersion} -> ${Q.toVersion}`);if(Y.has(Q.fromVersion))throw Error(`duplicate state schema migration from version ${Q.fromVersion}`);Y.set(Q.fromVersion,Q)}for(let Q=X.baselineVersion;Q<X.currentVersion;Q+=1)if(!Y.has(Q))throw Error(`missing state schema migration ${Q} -> ${Q+1}`);return Y},bS=(X,Y=xS)=>{let Q=kS(Y),J=SS(X);if(J>Y.currentVersion)throw Error(`state schema version ${J} is newer than supported version ${Y.currentVersion}`);if(DD(X)){if(J!==0)throw Error(`fresh state database carries unexpected user_version ${J}`);return!1}if(J===Y.currentVersion&&J!==0)return!1;if(J===0&&Y.baselineVersion===Y.currentVersion)return r50(X,Y.currentSchemaSql),!0;let $=ND(X),G=J===0?Y.baselineVersion:J;if(J===0)z4("unversioned state schema baseline",$,Y.baselineIdentity);else if(J<Y.baselineVersion)throw Error(`state schema version ${J} predates the supported baseline ${Y.baselineVersion}`);let _=Q.get(G);if(G<Y.currentVersion&&_===void 0)throw Error(`missing state schema migration ${G} -> ${G+1}`);if(_!==void 0)z4(`state schema version ${G}`,$,_.fromIdentity);return!0},gS=(X,Y=xS)=>{let Q=kS(Y),J=SS(X);if(J>Y.currentVersion)throw Error(`state schema version ${J} is newer than supported version ${Y.currentVersion}`);let $=DD(X),G=l50(J,$,Y,Q),_=!1;try{if(G)X.exec("PRAGMA foreign_keys = OFF"),_=!0;X.exec("BEGIN IMMEDIATE");try{let K=J;if($){if(K!==0)throw Error(`fresh state database carries unexpected user_version ${K}`);X.exec(Y.currentSchemaSql),K=Y.currentVersion}else{let W=K===Y.currentVersion||K===0&&Y.baselineVersion===Y.currentVersion?i50(X,Y.currentSchemaSql):ND(X);if(K===0)z4("unversioned state schema baseline",W,Y.baselineIdentity),K=Y.baselineVersion,qD(X,K);else if(K<Y.baselineVersion)throw Error(`state schema version ${K} predates the supported baseline ${Y.baselineVersion}`);while(K<Y.currentVersion){let D=Q.get(K);if(D===void 0)throw Error(`missing state schema migration ${K} -> ${K+1}`);if(z4(`state schema version ${K}`,W,D.fromIdentity),o50(X,D),K=D.toVersion,qD(X,K),K<Y.currentVersion){let U=Q.get(K);if(U===void 0)throw Error(`missing state schema migration ${K} -> ${K+1}`);let N=UD(X);z4(`migrated state schema version ${K}`,{actualSchemaSha256:N},U.fromIdentity),BD(X,U.fromIdentity),W=U.fromIdentity}}if(J===Y.currentVersion)z4(`state schema version ${Y.currentVersion}`,W,MS(Y.currentSchemaSql))}let H=zD(X,Y.currentSchemaSql);return f50(X),qD(X,Y.currentVersion),X.exec("COMMIT"),{...H,schemaVersion:Y.currentVersion,previousVersion:J,initialized:$}}catch(K){try{X.exec("ROLLBACK")}catch{}throw K}}finally{if(_)try{X.exec("PRAGMA foreign_keys = ON")}catch{}}};import{existsSync as yY0,lstatSync as hY0}from"node:fs";import{resolve as mY0}from"node:path";import{DatabaseSync as fY0}from"node:sqlite";import{chmodSync as Wv,lstatSync as Uv,mkdirSync as EY0}from"node:fs";import{homedir as n50}from"node:os";import{isAbsolute as s50,join as fD0,resolve as a50}from"node:path";var LD,t50=(X)=>{if(X===void 0)return;let Y=X.trim();if(Y.length===0)return;if(Y.length>4096)return;if(/[\u0000-\u001f\u007f]/.test(Y))return;if(!s50(Y))return;return a50(Y)},vG=()=>{if(LD===void 0)LD=t50(process.env.VELLUM_COMMAND_HOME)??n50();return LD};import{dirname as MY0,join as jY0,resolve as Dv}from"node:path";import{DatabaseSync as IY0}from"node:sqlite";class q7 extends Z.TaggedErrorClass()("StateEngineError",{operation:Z.String,message:Z.String,cause:Z.Unknown}){}class L7 extends b1.Service()("@vellum/StateEngine"){}import{appendFileSync as N90,chmodSync as hS,mkdirSync as B90,renameSync as V90,statSync as z90}from"node:fs";import{dirname as q90,join as L90}from"node:path";import{performance as O90}from"node:perf_hooks";import{join as U90}from"node:path";var v6=Z.String.pipe(Z.check(Z.isMinLength(1)),Z.brand("BindingId")),kG=Z.String.pipe(Z.check(Z.isMinLength(1)),Z.brand("SessionEpoch")),oD0=r6.taggedEnum();class e50 extends Z.TaggedErrorClass()("TerminalSpawnError",{surface:Z.Literal("native"),message:Z.String}){}class X90 extends Z.TaggedErrorClass()("TerminalAdmitError",{message:Z.String}){}class Y90 extends Z.TaggedErrorClass()("TerminalWriteError",{surface:Z.Literal("native"),message:Z.String}){}var bG=Z.Literals(["local","remote"]),yS=Z.Struct({_tag:Z.Literal("VacantSeat"),bindingId:v6,placement:bG}),OD=Z.Struct({_tag:Z.Literal("OccupiedSeat"),bindingId:v6,epoch:kG,placement:bG}),sD0=Z.Union([yS,OD]),aD0=Z.Struct({_tag:Z.Literal("OccupyVacantSeat"),seat:yS}),tD0=Z.Struct({_tag:Z.Literal("ActivateOccupiedSeat"),seat:OD}),eD0=Z.Struct({_tag:Z.Literal("EvictOccupiedSeat"),seat:OD});class Q90 extends Z.TaggedErrorClass()("SeatAlreadyOccupiedError",{bindingId:v6,epoch:kG,message:Z.String}){}class J90 extends Z.TaggedErrorClass()("SeatVacantError",{bindingId:v6,message:Z.String}){}var $90=Z.Struct({harness:Z.String,agentKey:Z.String,canvasName:Z.String,nodeId:Z.String}),G90=Z.Struct({harness:Z.optionalKey(Z.String),agentKey:Z.optionalKey(Z.String),canvasName:Z.optionalKey(Z.String),nodeId:Z.optionalKey(Z.String)});class Z90 extends Z.TaggedErrorClass()("SeatIdentityConflictError",{bindingId:v6,expected:$90,actual:G90,message:Z.String}){}class _90 extends Z.TaggedErrorClass()("SeatGenerationConflictError",{bindingId:v6,expectedEpoch:Z.String,actualEpoch:Z.String,message:Z.String}){}class K90 extends Z.TaggedErrorClass()("SeatBindingMismatchError",{bindingId:v6,returnedBindingId:Z.String,message:Z.String}){}class H90 extends Z.TaggedErrorClass()("SeatOccupationFailedError",{bindingId:v6,epoch:Z.String,message:Z.String}){}var W90=Z.Literals(["starting","running","exited"]),XN0=Z.Struct({placement:bG,liveness:W90,resumable:Z.Boolean,sessionId:Z.optionalKey(Z.String)}),YN0=Z.decodeUnknownSync(v6),QN0=Z.decodeUnknownSync(kG),JN0=Z.decodeUnknownSync(bG);var D90=[".vellum-command","logs"];var TD=(X=vG())=>U90(X,...D90);var T90="perf.jsonl",F90=20,R90=50,A90=5000,P90=5000,w90=8388608,FD=448,C90=384,c1=(X,Y=1)=>{let Q=10**Y;return Math.round(X*Q)/Q},RD=(X,Y)=>{if(X.length===0)return 0;let Q=Math.ceil(Y*X.length),J=Math.min(X.length-1,Math.max(0,Q-1));return X[J]??0},E90=(X)=>{let Y=new Map;for(let Q of X){let J=Y.get(Q.tag);if(J===void 0)Y.set(Q.tag,[Q]);else J.push(Q)}return[...Y.entries()].map(([Q,J])=>{let $=J.map((G)=>G.ms).sort((G,_)=>G-_);return{tag:Q,calls:J.length,totalMs:c1(J.reduce((G,_)=>G+_.ms,0)),p50Ms:c1(RD($,0.5)),maxMs:c1($[$.length-1]??0),statements:J.reduce((G,_)=>G+_.statements,0),bytes:J.reduce((G,_)=>G+_.bytes,0)}}).sort((Q,J)=>J.totalMs-Q.totalMs)},M90=(X,Y)=>{let Q=X.map((G)=>G.ms).sort((G,_)=>G-_),J=Q.reduce((G,_)=>G+_,0),$=new Map;for(let G of X)for(let _ of G.attribution){let K=$.get(_.tag)??{calls:0,ms:0};$.set(_.tag,{calls:K.calls+_.calls,ms:K.ms+_.ms})}return{count:X.length,perSec:Y>0?c1(X.length*1000/Y,2):0,totalMs:c1(J),dutyPct:Y>0?c1(J/Y*100):0,minMs:c1(Q[0]??0),p50Ms:c1(RD(Q,0.5)),p90Ms:c1(RD(Q,0.9)),maxMs:c1(Q[Q.length-1]??0),byCaller:[...$.entries()].map(([G,_])=>({tag:G,calls:_.calls,ms:c1(_.ms)})).sort((G,_)=>_.ms-G.ms)}},j90=(X)=>{try{let Y=JSON.stringify(X);return Y===void 0?0:Buffer.byteLength(Y,"utf8")}catch{return 0}},I90=(X={})=>{let Y=X.now??(()=>O90.now()),Q=X.emit??v90,J=X.tickMs??F90,$=X.blockMs??R90,G=X.windowMs??A90,_=X.maxSamples??P90,K=0,H=[],W=[],D=0,U=new Map,N,B,z=0,q=(x,n)=>{if(x.length>=_)x.shift(),D+=1;x.push(n)},F=()=>{K+=1},R=(x)=>({tag:x,startedAt:Y(),statementsAt:K}),C=(x,n)=>{let x0=Y(),f0=x0-x.startedAt,V0=j90(n),n9=Y()-x0;q(H,{tag:x.tag,ms:f0,statements:K-x.statementsAt,bytes:V0,probeMs:n9});let nD=U.get(x.tag)??{calls:0,ms:0};U.set(x.tag,{calls:nD.calls+1,ms:nD.ms+f0})},E=(x)=>{q(W,{ms:x,attribution:[...U.entries()].map(([n,x0])=>({tag:n,calls:x0.calls,ms:c1(x0.ms)}))})},a=()=>{let x=Y(),n=x-z-J;if(z=x,n>=$)E(n);if(U.size>0)U=new Map},L=(x=G)=>{let n=H,x0=W,f0=D;return H=[],W=[],D=0,{kind:"perf.window",ts:new Date().toISOString(),windowMs:x,reads:{calls:n.length,perSec:x>0?c1(n.length*1000/x,2):0,totalMs:c1(n.reduce((V0,n9)=>V0+n9.ms,0)),probeMs:c1(n.reduce((V0,n9)=>V0+n9.probeMs,0)),byCaller:E90(n)},blocks:M90(x0,x),...f0>0?{dropped:f0}:{}}};return{countStatement:F,beginRead:R,endRead:C,recordBlock:E,drain:L,start:()=>{if(N!==void 0)return;z=Y(),N=setInterval(a,J),N.unref?.(),B=setInterval(()=>{Q(L())},G),B.unref?.()},stop:()=>{if(N!==void 0)clearInterval(N);if(B!==void 0)clearInterval(B);N=void 0,B=void 0}}},fS=()=>L90(TD(),T90),mS=!1,x90=()=>{let X=TD();B90(X,{recursive:!0,mode:FD}),hS(q90(X),FD),hS(X,FD)},S90=()=>{try{let X=fS();if(z90(X).size<w90)return;V90(X,`${X}.1`)}catch{}},v90=(X)=>{try{if(!mS)x90(),mS=!0;S90(),N90(fS(),`${JSON.stringify(X)}
`,{encoding:"utf8",mode:C90})}catch{}},AD=process.env.VELLUM_PERF==="1",dS=AD?I90():void 0;import{performance as pS}from"node:perf_hooks";var k90=4,b90=200,g90=()=>{let X=process.env.VELLUM_COMMAND_BUDGET?.trim().toLowerCase();if(X==="0"||X==="off"||X==="false")return{enabled:!1,strict:!1,forced:!0};if(X==="strict")return{enabled:!0,strict:!0,forced:!0};if(X==="1"||X==="on"||X==="true")return{enabled:!0,strict:!1,forced:!0};return{enabled:!0,strict:!1,forced:!1}},CD=g90(),y90=(X)=>{let Y=X.detail===void 0?"":` (${X.detail})`;console.error(`[budget] ${X.operation}${Y} held the main thread ${X.ms.toFixed(2)}ms, over the ${X.budgetMs}ms budget`)},uS=CD.enabled,h90=CD.strict,zN0=CD.forced,PD=k90,m90=y90,wD=[],f90=new Set;var d90=(X,Y,Q,J)=>{if(!uS||Y<=PD)return!1;let $={operation:X,ms:Y,budgetMs:PD,at:new Date().toISOString(),...Q===void 0?{}:{detail:Q}};if(wD.length>=b90)wD.shift();wD.push($),m90($);for(let G of f90)try{G($)}catch{}if(h90&&J)throw Error(`[budget] ${X} held the main thread ${Y.toFixed(2)}ms, over the ${PD}ms budget`);return!0},cS=(X,Y,Q)=>{if(!uS)return Y();let J=pS.now(),$=!1;try{return Y()}catch(G){throw $=!0,G}finally{d90(X,pS.now()-J,Q,!$)}};var sS=new Map([["work_events","journal"],["work_facts","journal"],["work_commands","journal"],["work_dispositions","journal"],["work_proposal_events","journal"],["work_event_sequences","allocation"],["work_tasks","projection"],["work_requests","projection"],["work_task_messages","projection"],["work_task_transitions","projection"],["work_task_dependencies","projection"],["work_task_finish","projection"],["work_task_proposals","projection"],["work_proposal_planning","projection"],["work_messages","projection"],["work_artifacts","projection"],["work_delivery_receipts","projection"],["work_board_topics","projection"],["work_board_posts","projection"],["work_pad_meta","projection"],["work_pad_images","projection"],["work_pad_shapes","projection"],["work_pad_edges","projection"],["work_pad_inks","projection"],["work_pad_pins","projection"],["work_pad_posts","projection"],["work_pending_commands","projection"],["work_pending_proposal_commands","projection"],["work_pad_read_cursors","cursor"],["work_board_read_cursors","cursor"],["work_canvas_revisions","derived"]]),LN0={"work.artifact.set_archived":{why:"Operator soft-archive / restore rewrites work_artifacts.metadata_json in place and mints no fact, so no replica learns the artifact was archived and a journal rebuild loses the flag.",retire:"Mint an artifact.archive fact and materialize it like every other operation, then delete this reason."},"work.artifact.delete":{why:"Operator delete removes the work_artifacts row outright with no tombstone record, so a journal rebuild resurrects the artifact.",retire:"Mint an artifact.retract fact carrying the tombstone, materialize it, then delete this reason."},"content.inline-media.backfill":{why:"BACKFILL_INLINE_MEDIA_V1 rewrites parts_json in six work_* projection tables to externalize inline media. It is a one-time content move, not a work transition, and must not mint facts that replicate.",retire:"Delete src/main/vellum/content/inline-media-migration.ts once the backfill has run on every install."},"test.fixture-seed":{why:"A migration/schema test seeds projection rows to pin how OLD rows survive a migration. Seeding through the repository would exercise the NEW write path and prove nothing about the old shape.",retire:"Never — but `bun run lint:single-write-seam` forbids this reason under "+"src/, so it can only ever appear in tests and fixtures."}};class O7 extends Error{name="WorkMutationSeamError";constructor(X){super(`work mutation seam: ${X}`)}}var p90=/^[\s;]*(?:--[^\n]*\n|\/\*[\s\S]*?\*\/|\s)*(insert|replace|update|delete)\b/i,u90=/\binto\s+(?:[`"[]?([A-Za-z_][\w$]*)[`"\]]?\s*\.\s*)?[`"[]?([A-Za-z_][\w$]*)/i,c90=/^[\s;]*(?:--[^\n]*\n|\/\*[\s\S]*?\*\/|\s)*update\s+(?:or\s+\w+\s+)?(?:[`"[]?([A-Za-z_][\w$]*)[`"\]]?\s*\.\s*)?[`"[]?([A-Za-z_][\w$]*)/i,l90=/\bfrom\s+(?:[`"[]?([A-Za-z_][\w$]*)[`"\]]?\s*\.\s*)?[`"[]?([A-Za-z_][\w$]*)/i,lS=new Map,ED=/\b(insert\s+(?:or\s+\w+\s+)?into|replace\s+into|update(?:\s+or\s+\w+)?|delete\s+from)\s+(?:[`"[]?([A-Za-z_][\w$]*)[`"\]]?\s*\.\s*)?[`"[]?([A-Za-z_][\w$]*)/gi,o90=(X)=>{let Y="",Q=!1;for(let J=0;J<X.length;J+=1){let $=X[J];if(Q){if(Y+=$==="'"?"'":" ",$==="'")Q=!1;continue}if($==="'"){Q=!0,Y+=" ";continue}Y+=$}return Y},i90=(X)=>{let Y=o90(X);ED.lastIndex=0;for(let Q=ED.exec(Y);Q!==null;Q=ED.exec(Y)){let J=(Q[3]??Q[2]).toLowerCase(),$=sS.get(J);if($===void 0)continue;let G=Q[1].toLowerCase();return{verb:G.startsWith("insert")?"INSERT":G.startsWith("replace")?"REPLACE":G.startsWith("update")?"UPDATE":"DELETE",table:J,role:$,sink:"unreadable"}}return null},r90=(X)=>{let Y=p90.exec(X);if(Y===null)return i90(X);let Q=Y[1].toUpperCase(),J=Q==="UPDATE"?c90.exec(X):Q==="DELETE"?l90.exec(X):u90.exec(X);if(J===null)return null;let $=(J[2]??J[1]).toLowerCase(),G=sS.get($);if(G===void 0)return null;return{verb:Q,table:$,role:G,sink:"readable"}},n90=(X)=>{let Y=lS.get(X);if(Y!==void 0)return Y;let Q=r90(X);return lS.set(X,Q),Q},T7=[],s90=()=>T7[T7.length-1],aS=(X)=>{let Y={operation:X,journaled:!1,unjournaled:void 0};T7.push(Y);let Q=!1;return()=>{if(Q)return;Q=!0;let J=T7.pop();if(J===Y)return;if(J!==void 0)T7.push(J);throw new O7(`scope for "${X}" closed out of order (top is "${J?.operation??"none"}")`)}},MD=(X)=>X.replace(/\s+/g," ").trim().slice(0,120),tS=(X,Y)=>{let Q=n90(X);if(Q===null)return;if(Q.role==="derived")throw new O7(`"${Q.table}" is maintained by SQL triggers only; no application statement may write it (${MD(X)})`);let J=s90();if(J===void 0)throw new O7(`${Q.verb} on "${Q.table}" ran outside any state transaction (${MD(X)})`);if(Q.role==="journal"){J.journaled=!0,jD(Q,X,Y);return}if(Q.role==="allocation"||Q.role==="cursor"){jD(Q,X,Y);return}if(J.journaled||J.unjournaled!==void 0){jD(Q,X,Y);return}throw new O7(`${Q.verb} on the work projection table "${Q.table}" in "${J.operation}" is not explained by any journal record in this transaction. Mint a work record and materialize it, or declare the write with unjournaledWorkMutation(...) if it deliberately mints no fact (${MD(X)})`)};var a90=new Set(["work_artifacts","work_board_posts","work_board_read_cursors","work_board_topics","work_delivery_receipts","work_events","work_messages","work_pad_meta","work_pad_posts","work_pad_read_cursors","work_pad_shapes","work_proposal_events","work_proposal_planning","work_requests","work_task_dependencies","work_task_finish","work_task_messages","work_task_proposals","work_tasks"]),t90=new Map([["work_events",["item_canvas_name","item_node_id"]],["work_proposal_events",["canvas_name","node_id"]],["work_delivery_receipts",["delivered_canvas_name","delivered_node_id"]]]),e90=["canvas_name","node_id"],XY0=(X)=>{let Y=!1;for(let Q=0;Q<X.length;Q+=1){let J=X[Q];if(Y){if(J==="'")Y=!1;continue}if(J==="'"){Y=!0;continue}if(J!=="?")continue;let $=X[Q+1];if($!==void 0&&$>="0"&&$<="9")return!0}return!1},YY0=(X)=>{let Y=Array(X.length).fill(0),Q=0,J=!1,$=-1;for(let G=0;G<X.length;G+=1){let _=X[G];if(Y[G]=Q,J){if(_==="'")J=!1;continue}if(_==="'"){J=!0;continue}if(_==="("){Q+=1;continue}if(_===")"){Q=Math.max(0,Q-1);continue}if($<0&&Q===0&&(_==="w"||_==="W")&&/^where\b/i.test(X.slice(G,G+6))&&(G===0||/\s|\)/.test(X[G-1]??" ")))$=G}return{depth:Y,whereAt:$}},eS=(X)=>{let Y=[],Q=!1;for(let J=0;J<X.length;J+=1){let $=X[J];if(Q){if($==="'")Q=!1;continue}if($==="'"){Q=!0;continue}if($==="?")Y.push(J)}return Y},oS=(X,Y)=>{let Q=0,J=!1;for(let $=Y;$<X.length;$+=1){let G=X[$];if(J){if(G==="'")J=!1;continue}if(G==="'")J=!0;else if(G==="(")Q+=1;else if(G===")"){if(Q-=1,Q===0)return{body:X.slice(Y+1,$),end:$}}}return null},iS=(X)=>{let Y=[],Q=0,J=!1,$=0;for(let G=0;G<X.length;G+=1){let _=X[G];if(J){if(_==="'")J=!1;continue}if(_==="'")J=!0;else if(_==="(")Q+=1;else if(_===")")Q-=1;else if(_===","&&Q===0)Y.push(X.slice($,G)),$=G+1}return Y.push(X.slice($)),Y},QY0=(X)=>eS(X).length,JY0=(X,Y)=>{let Q=/\binto\b/i.exec(X);if(Q===null)return null;let J=X.indexOf("(",Q.index);if(J<0)return null;let $=oS(X,J);if($===null)return null;let G=/\bvalues\b/i.exec(X.slice($.end));if(G===void 0||G===null)return null;let _=X.indexOf("(",$.end+G.index);if(_<0)return null;let K=oS(X,_);if(K===null)return null;if(X.slice(K.end+1).replace(/^[\s]+/,"").startsWith(","))return null;let W=iS($.body).map((q)=>q.trim().replace(/^["`[]|["`\]]$/g,"").toLowerCase()),D=iS(K.body);if(W.length!==D.length)return null;let U=new Map,N=0;for(let q=0;q<D.length;q+=1){let F=D[q].trim();if(F==="?"){U.set(W[q],N),N+=1;continue}N+=QY0(F)}let B=U.get(Y[0]),z=U.get(Y[1]);if(B===void 0||z===void 0)return null;return{canvas:B,node:z}},$Y0=(X,Y)=>{let Q=eS(X),J=YY0(X);if(J.whereAt<0)return null;for(let K of Y){let H=new RegExp(`\\b${K}\\s*=`,"gi");for(let W=H.exec(X);W!==null;W=H.exec(X)){if((J.depth[W.index]??0)!==0)continue;if(W.index<J.whereAt)return null}}let $=(K)=>{let H=new RegExp(`\\b${K}\\s*=\\s*\\?`,"gi"),W;for(let D=H.exec(X);D!==null;D=H.exec(X)){if((J.depth[D.index]??0)!==0)continue;if(D.index<J.whereAt)continue;if(W!==void 0)return;let U=X.indexOf("?",D.index),N=Q.indexOf(U);if(N<0)return;W=N}return W},G=$(Y[0]),_=$(Y[1]);if(G===void 0||_===void 0)return null;return{canvas:G,node:_}},rS=new Map,GY0=(X,Y)=>{let Q=rS.get(Y);if(Q!==void 0)return Q;let J=t90.get(X.table)??e90,$=X.sink==="unreadable"||XY0(Y)?null:X.verb==="INSERT"||X.verb==="REPLACE"?JY0(Y,J):$Y0(Y,J);return rS.set(Y,$),$},nS=new Set;var jD=(X,Y,Q)=>{if(nS.size===0)return;if(!a90.has(X.table))return;let J,$;if(Array.isArray(Q)){let G=GY0(X,Y);if(G!==null){let _=Q[G.canvas],K=Q[G.node];if(typeof _==="string"&&typeof K==="string")J=_,$=K}}for(let G of nS)G(J,$)};import{mkdtempDisposableSync as ZY0}from"node:fs";import{tmpdir as _Y0}from"node:os";import{join as vD}from"node:path";var ID,xD=()=>{if(ID===void 0)ID=process.argv.includes("--vellum-demo")||process.env.VELLUM_COMMAND_DEMO==="1";return ID};var r9,SD=!1,Xv=()=>{KY0()},Yv=()=>{if(r9!==void 0)return r9;return r9=ZY0(vD(_Y0(),"vellum-command-demo-runtime-")),process.once("exit",Xv),SD=!0,r9},Qv=()=>xD()?vD(Yv().path,"vellum-command.db"):void 0,KY0=()=>{if(SD)process.off("exit",Xv),SD=!1;let X=r9;r9=void 0,X?.remove()};if(xD()&&!process.env.VELLUM_COMMAND_CANVASES_DIR)process.env.VELLUM_COMMAND_CANVASES_DIR=vD(Yv().path,"projections");import{randomUUID as HY0}from"node:crypto";import{chmodSync as WY0,closeSync as bD,constants as A5,fchmodSync as UY0,fstatSync as gD,fsyncSync as Gv,linkSync as DY0,lstatSync as _6,mkdirSync as NY0,openSync as yD,readdirSync as BY0,unlinkSync as Zv}from"node:fs";import{join as yG}from"node:path";import{DatabaseSync as VY0}from"node:sqlite";var Jv=448,zY0=384,_v="backups",qY0="vellum-command-backup-",LY0=".pending",OY0=/^vellum-command-backup-[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\.db\.pending$/u,gG=(X)=>{try{let Y=_6(X);if(!Y.isFile()||Y.isSymbolicLink())throw Error(`state backup is not a regular file: ${X}`);return!0}catch(Y){if(typeof Y==="object"&&Y!==null&&"code"in Y&&Y.code==="ENOENT")return!1;throw Y}},TY0=(X)=>{let Y=yD(X,A5.O_RDONLY|A5.O_NOFOLLOW);try{let Q=gD(Y);if(!Q.isFile())throw Error(`state backup is not a regular file: ${X}`);UY0(Y,zY0);let J=_6(X);if(!J.isFile()||J.isSymbolicLink()||J.dev!==Q.dev||J.ino!==Q.ino)throw Error(`state backup path changed during creation: ${X}`);return{device:Q.dev,inode:Q.ino}}finally{bD(Y)}},FY0=(X,Y)=>{try{let Q=_6(X);if(Q.isFile()&&!Q.isSymbolicLink()&&Q.dev===Y.device&&Q.ino===Y.inode)Zv(X)}catch{}},kD=(X,Y)=>{let Q=_6(X);if(!Q.isFile()||Q.isSymbolicLink()||Q.dev!==Y.device||Q.ino!==Y.inode)throw Error(`state backup path changed before removal: ${X}`);Zv(X)},RY0=(X,Y)=>{let Q=yD(X,A5.O_RDONLY|A5.O_NOFOLLOW);try{let J=gD(Q),$=_6(X);if(!J.isFile()||!$.isFile()||$.isSymbolicLink()||J.dev!==Y.device||J.ino!==Y.inode||$.dev!==Y.device||$.ino!==Y.inode)throw Error(`state backup path changed before sync: ${X}`);Gv(Q)}finally{bD(Q)}},hG=(X)=>{let Y=yD(X,A5.O_RDONLY|A5.O_NOFOLLOW|A5.O_DIRECTORY);try{if(!gD(Y).isDirectory())throw Error(`state backup path is not a real directory: ${X}`);Gv(Y)}finally{bD(Y)}},AY0=(X)=>{let Y=yG(X,_v),Q=!1;try{NY0(Y,{mode:Jv}),Q=!0}catch($){if(typeof $!=="object"||$===null||!("code"in $)||$.code!=="EEXIST")throw $}let J=_6(Y);if(!J.isDirectory()||J.isSymbolicLink())throw Error(`state backup path is not a real directory: ${Y}`);if(WY0(Y,Jv),Q)hG(X);return Y},PY0=(X)=>{let Y=yG(X,_v),Q;try{let $=_6(Y);if(!$.isDirectory()||$.isSymbolicLink())throw Error(`state backup path is not a real directory: ${Y}`);Q=BY0(Y)}catch($){if(typeof $==="object"&&$!==null&&"code"in $&&$.code==="ENOENT")return;throw $}let J=!1;for(let $ of Q){if(!OY0.test($))continue;let G=yG(Y,$),_=_6(G);if(!_.isFile()||_.isSymbolicLink())throw Error(`pending state backup is not a regular file: ${G}`);kD(G,{device:_.dev,inode:_.ino}),J=!0}if(J)hG(Y)},wY0=(X)=>`"${X.replaceAll('"','""')}"`,$v=(X)=>{let Y=X.prepare("PRAGMA user_version").get(),Q=X.prepare(`
      SELECT actual_schema_sha256
      FROM state_schema_identity
      WHERE singleton = 1
    `).get();if(Q===void 0)throw Error("state backup source has no schema identity witness");let J=X.prepare(`
      SELECT type, name, tbl_name AS table_name, sql
      FROM sqlite_schema
      WHERE type IN ('table', 'index', 'view', 'trigger')
        AND name NOT GLOB 'sqlite_*'
      ORDER BY type COLLATE BINARY, name COLLATE BINARY
    `).all(),$=J.filter((G)=>G.type==="table");return{userVersion:Number(Y?.user_version),identity:{actualSchemaSha256:String(Q.actual_schema_sha256)},schema:J.map((G)=>({type:String(G.type),name:String(G.name),tableName:String(G.table_name),sql:G.sql===null?null:String(G.sql)})),rowCounts:$.map((G)=>{let _=String(G.name),K=X.prepare(`SELECT count(*) AS count FROM ${wY0(_)}`).get();return{tableName:_,count:Number(K?.count)}})}},CY0=(X,Y)=>{if(JSON.stringify(X)!==JSON.stringify(Y))throw Error("state backup witness does not match its live source")},hD=(X,Y)=>{let Q=$v(X);PY0(Y);let J=AY0(Y),$=HY0(),G=yG(J,`${qY0}${$}.db`),_=`${G}${LY0}`;if(gG(G))throw Error(`backup destination already exists: ${G}`);if(gG(_))throw Error(`backup destination already exists: ${_}`);try{X.prepare("VACUUM INTO ?").run(_)}catch(U){if(gG(_)){let N=_6(_);kD(_,{device:N.dev,inode:N.ino}),hG(J)}throw U}let K=_6(_);if(!K.isFile()||K.isSymbolicLink())throw Error(`state backup is not a regular file: ${_}`);let H={device:K.dev,inode:K.ino},W,D=!1;try{let U=TY0(_);if(U.device!==H.device||U.inode!==H.inode)throw Error(`state backup path changed during creation: ${_}`);W=new VY0(_,{open:!0,readOnly:!0,allowExtension:!1,enableForeignKeyConstraints:!0,enableDoubleQuotedStringLiterals:!1,allowBareNamedParameters:!1,allowUnknownNamedParameters:!1});let N=W.prepare("PRAGMA quick_check").all();if(N.length!==1||String(N[0]?.quick_check)!=="ok")throw Error("state backup quick_check failed");let B=W.prepare("PRAGMA foreign_key_check").all();if(B.length>0)throw Error(`state backup has ${B.length} foreign-key violation(s)`);if(CY0(Q,$v(W)),W.close(),W=void 0,RY0(_,H),gG(G))throw Error(`backup destination already exists: ${G}`);DY0(_,G);let z=_6(G);if(!z.isFile()||z.isSymbolicLink()||z.dev!==H.device||z.ino!==H.inode)throw Error(`state backup changed during publication: ${G}`);kD(_,H),hG(J),D=!0}finally{if(W?.close(),!D)FY0(_,H)}return{path:G,schemaSha256:Q.identity.actualSchemaSha256,schemaVersion:Q.userVersion}};var Kv=448,xY0=384,Hv=5000,SY0=64,mG=(X,Y)=>Y instanceof q7?Y:q7.make({operation:X,message:Y instanceof Error?Y.message:String(Y),cause:Y}),fD=()=>Dv(Qv()??jY0(vG(),".vellum-command","state","vellum-command.db")),vY0=(X)=>{EY0(X,{recursive:!0,mode:Kv});let Y=Uv(X);if(!Y.isDirectory()||Y.isSymbolicLink())throw Error(`state path is not a real directory: ${X}`);Wv(X,Kv)},kY0=(X)=>{try{let Y=Uv(X);if(!Y.isFile()||Y.isSymbolicLink())throw Error(`state database is not a regular file: ${X}`);return!0}catch(Y){if(typeof Y==="object"&&Y!==null&&"code"in Y&&Y.code==="ENOENT")return!1;throw Y}},mD=(X,Y,Q,J)=>{if(Y===void 0)return Q();if(Array.isArray(Y))return Q(...Y);return J({...Y})},bY0=(X)=>i0.try({try:()=>{let Y=Dv(X??fD()),Q=MY0(Y);vY0(Q),kY0(Y);let J=new IY0(Y,{open:!0,readOnly:!1,allowExtension:!1,enableForeignKeyConstraints:!0,enableDoubleQuotedStringLiterals:!1,allowBareNamedParameters:!1,allowUnknownNamedParameters:!1,timeout:Hv}),$=!1,G=new Map,_=!1,K=(()=>{try{if(Wv(Y,xY0),J.exec(`
            PRAGMA foreign_keys = ON;
            PRAGMA busy_timeout = ${Hv};
            PRAGMA trusted_schema = OFF;
          `),bS(J))hD(J,Q);let L=gS(J);return J.exec(`
            PRAGMA journal_mode = WAL;
            PRAGMA synchronous = NORMAL;
          `),L}catch(L){throw J.close(),L}})(),H=()=>{if($)throw Error("state engine is closed")},W=(L)=>{H();let w=G.get(L);if(w)return w;let A=J.prepare(L);return G.set(L,A),A},D=()=>{if(AD)dS?.countStatement()},U={get:(L,w)=>{return D(),mD(W(L),w,(...A)=>W(L).get(...A),(A)=>W(L).get(A))},all:(L,w)=>{return D(),mD(W(L),w,(...A)=>W(L).all(...A),(A)=>W(L).all(A))}},N={...U,run:(L,w)=>{return tS(L,w),D(),mD(W(L),w,(...A)=>W(L).run(...A),(A)=>W(L).run(A))}},B=(L,w)=>i0.try({try:()=>{return H(),w(U)},catch:(A)=>mG(L,A)}).pipe(i0.withSpan(`state.${L}`)),z=(L,w)=>i0.try({try:()=>cS(`state.${L}`,()=>{if(H(),_)throw Error(`nested state transaction is not allowed (${L})`);let A=aS(L);_=!0,J.exec("BEGIN IMMEDIATE");try{let x=w(N);return J.exec("COMMIT"),x}catch(x){try{J.exec("ROLLBACK")}catch{}throw x}finally{A(),_=!1}}),catch:(A)=>mG(L,A)}).pipe(i0.withSpan(`state.${L}`)),q=(L,w,A,x={})=>i0.gen(function*(){let n=Math.max(1,Math.floor(x.chunkRows??SY0));for(let x0=0;x0<w.length;x0+=n){let f0=w.slice(x0,x0+n);if(yield*z(`${L}.chunk`,(V0)=>A(V0,f0)),x0+n<w.length)yield*i0.sleep("1 millis")}}).pipe(i0.withSpan(`state.${L}`)),F=()=>i0.try({try:()=>{return H(),hD(J,Q)},catch:(L)=>mG("backup",L)}).pipe(i0.withSpan("state.backup")),R=U.get("PRAGMA journal_mode")?.journal_mode,C=U.get("PRAGMA synchronous")?.synchronous,E=U.get("PRAGMA foreign_keys")?.foreign_keys,a={path:Y,journalMode:String(R??""),synchronous:Number(C??-1),foreignKeys:Number(E??0)===1,schemaSha256:K.actualSchemaSha256,schemaVersion:K.schemaVersion};return{service:L7.of({info:a,read:B,transaction:z,chunkedWrite:q,backup:F}),close:()=>{if($)return;$=!0,G.clear(),J.close()}}},catch:(Y)=>mG("open",Y)}),gY0=(X)=>t5.effect(L7,i0.acquireRelease(bY0(X),({close:Y})=>i0.sync(Y)).pipe(i0.map(({service:Y})=>Y))),uN0=gY0();var dY0=(X)=>{try{let Y=hY0(X);return Y.isFile()&&!Y.isSymbolicLink()}catch{return!1}},dD=(X)=>{let Y=mY0(X??fD());if(!yY0(Y))return{kind:"missing"};if(!dY0(Y))return{kind:"unreadable",message:`state database path is not a regular file: ${Y}`};let Q;try{Q=new fY0(Y,{open:!0,readOnly:!0,allowExtension:!1,enableForeignKeyConstraints:!0,enableDoubleQuotedStringLiterals:!1,allowBareNamedParameters:!1,allowUnknownNamedParameters:!1,timeout:2000});let J=Q.prepare("PRAGMA user_version").get(),$=Number(J?.user_version??0);if(!Number.isSafeInteger($)||$<0)return{kind:"unreadable",message:`state schema user_version is invalid: ${String(J?.user_version)}`};return{kind:"present",userVersion:$,path:Y}}catch(J){return{kind:"unreadable",message:J instanceof Error?J.message:String(J)}}finally{try{Q?.close()}catch{}}},Nv=(X=dD(),Y=i9)=>{if(X.kind==="missing")return{ok:!0,userVersion:null};if(X.kind==="unreadable")return{ok:!0,userVersion:null};if(X.userVersion>Y)return{ok:!1,reason:"newer-than-supported",userVersion:X.userVersion,supportedVersion:Y,path:X.path};return{ok:!0,userVersion:X.userVersion}};var pY0=(X)=>X==="REMOTE STATIONS ARE RELEASED",Bv=(X,Y)=>{if(!Number.isSafeInteger(Y)||Y<1)throw TypeError(`${X} version must be a positive safe integer`);if(!pY0("REMOTE STATIONS ARE NOT RELEASED")&&Y!==1)throw TypeError(`${X} must remain at version 1 until REMOTE_STATIONS_RELEASE_STATE is "REMOTE STATIONS ARE RELEASED"`);return Y};var P5=Bv("Station protocol",1),fG=Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThan(0)),Z.check(Z.makeFilter(Number.isSafeInteger,{message:"Station protocol version must be a safe integer"}))),Vv=Z.Struct({preferred:fG,compatibleFrom:fG,warnBelow:fG}).pipe(Z.check(Z.makeFilter(({compatibleFrom:X,warnBelow:Y,preferred:Q})=>X<=Y&&Y<=Q,{message:"Station protocol support must satisfy compatibleFrom <= warnBelow <= preferred"}))),dG=Vv.make({preferred:P5,compatibleFrom:P5,warnBelow:P5}),zv=(X,Y)=>{let Q=Math.max(X.compatibleFrom,Y.compatibleFrom),J=Math.min(X.preferred,Y.preferred);if(Q>J)return{_tag:"no-common",local:X,peer:Y};let $=J<X.warnBelow,G=J<Y.warnBelow;return{_tag:"selected",selected:J,deprecatedForLocal:$,deprecatedForPeer:G,warning:$||G}},uY0=Z.NonEmptyString.pipe(Z.check(Z.isMaxLength(64))),cY0=Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThan(0)),Z.check(Z.makeFilter(Number.isSafeInteger,{message:"state schema version must be a safe integer"}))),pG="vellum-command/station-protocol-preface/v1",pD={appVersion:uY0,stateSchemaVersion:cY0,support:Vv},lY0=Z.Struct({protocol:Z.Literal(pG),frame:Z.Literal("offer"),...pD}),oY0=Z.Struct({protocol:Z.Literal(pG),frame:Z.Literal("accept"),...pD,selected:fG}),qv=Z.Struct({protocol:Z.Literal(pG),frame:Z.Literal("reject"),...pD,reason:Z.Literal("no-common-version"),retryable:Z.Literal(!1)}),iY0=Z.Union([lY0,oY0,qv]),YB0=Z.decodeUnknownResult(iY0,{onExcessProperty:"error"});var Lv=(X)=>qv.make({protocol:pG,frame:"reject",...X,reason:"no-common-version",retryable:!1}),uD=(X)=>X===P5?g0.succeed(P5):g0.fail("unsupported-station-protocol");var q4=Z.String.pipe(Z.check(Z.isMinLength(1)),Z.check(Z.isMaxLength(128)),Z.check(Z.isPattern(/^[A-Za-z0-9][A-Za-z0-9._:-]*$/)),Z.brand("InstallationId"));var cD="vellum/work/v2",Ov=262144,rY0=2048,nY0=64,Tv=Z.String.pipe(Z.check(Z.isPattern(/^[1-9][0-9]*$/)),Z.check(Z.isMaxLength(32)),Z.brand("WorkLogicalSequence")),w5=Z.String.pipe(Z.check(Z.isPattern(/^[a-f0-9]{64}$/)),Z.brand("WorkSha256")),lD=Z.String.pipe(Z.check(Z.isMinLength(1)),Z.check(Z.isMaxLength(nY0))),sY0=Z.String.pipe(Z.check(Z.isMinLength(1)),Z.check(Z.isMaxLength(rY0))),aY0=Z.Struct({eventHome:q4,entityHome:q4}),L4=Z.Struct({route:aY0,seq:Tv}),Fv=Z.String.pipe(Z.check(Z.isPattern(/^(0|[1-9][0-9]*)$/)),Z.check(Z.isMaxLength(32)),Z.brand("FactBasisGeneration")),Rv=Z.Struct({kind:Z.Literal("authorial-intent"),generation:Fv,contentSha256:w5}),Av=Z.Struct({kind:Z.Literal("projected-intent"),generation:Fv,contentSha256:w5}),tY0=Z.Struct({kind:Z.Literal("command"),command:L4,commandSha256:w5}),eY0=Z.Union([Rv,Av,tY0]),OB0=Z.Union([Rv,Av]),TB0=Z.Struct({eventHome:q4,entityHome:q4,through:Tv}),XQ0=Z.Literals(["proposal.create","proposal.approve","proposal.reject","task.create","task.describe","task.transition","task.claim","request.create","request.resolve","message.append","artifact.publish","delivery.accepted","board.topic.create","board.post.append","pad.patch"]),YQ0=Z.Struct({operation:Z.Literal("proposal.create"),proposal:O5}).pipe(Z.check(Z.makeFilter(({proposal:X})=>X.state==="pending"||"proposal.create requires a pending proposal"))),QQ0=Z.Struct({operation:Z.Literal("proposal.approve"),proposalId:vX,task:OX}).pipe(Z.check(Z.makeFilter(({task:X})=>X.state==="submitted"&&X.claimedBy===void 0||"proposal.approve requires a submitted unclaimed task"))),JQ0=Z.Struct({operation:Z.Literal("proposal.reject"),proposalId:vX}),Pv=Z.Struct({deliveryId:vX,deliveredItem:$G,actor:kX,acceptedAt:lD}),$Q0=Z.Struct({operation:Z.Literal("task.create"),task:OX}).pipe(Z.check(Z.makeFilter(({task:X})=>X.state==="submitted"&&X.claimedBy===void 0||"task.create requires a submitted task snapshot"))),GQ0=Z.Struct({operation:Z.Literal("task.describe"),taskId:vX,message:T8}),ZQ0=Z.Struct({operation:Z.Literal("task.transition"),taskId:vX,state:d9,message:Z.optionalKey(T8),completionEvidence:Z.optionalKey(p9)}).pipe(Z.check(Z.makeFilter(({state:X,completionEvidence:Y})=>Y===void 0||X==="completed"||"completionEvidence is only allowed when state is completed"))),_Q0=Z.Struct({operation:Z.Literal("task.claim"),sourceQueueHome:q4,sourcePredecessor:Z.NullOr(L4),sourceTask:OX,sink:JG,actor:kX,targetHome:q4}).pipe(Z.check(Z.makeFilter((X)=>{if(X.sourceTask.state!=="submitted")return"task.claim requires a submitted source task snapshot";if(X.sourceTask.claimedBy!==void 0)return"task.claim requires an unclaimed source task snapshot";if(X.sourceQueueHome===X.targetHome)return"task.claim command must cross authority installations";if(X.sourcePredecessor!==null&&(X.sourcePredecessor.route.eventHome!==X.sourceQueueHome||X.sourcePredecessor.route.entityHome!==X.sourceQueueHome))return"task.claim source predecessor must belong to the source queue authority lane";return!0}))),KQ0=Z.Struct({operation:Z.Literal("request.create"),request:OX,raisedBy:kX}).pipe(Z.check(Z.makeFilter(({request:X,raisedBy:Y})=>X.state==="input-required"&&X.claimedBy===Y.seatId||"request.create requires an input-required request claimed by its raiser"))),HQ0=Z.Struct({operation:Z.Literal("request.resolve"),requestId:vX,response:Z.String,disposition:Z.Literals(["completed","rejected"]),message:Z.optionalKey(T8)}),WQ0=Z.Union([Z.Struct({kind:Z.Literal("mailbox")}),Z.Struct({kind:Z.Literal("task"),itemId:vX}),Z.Struct({kind:Z.Literal("request"),itemId:vX})]),wv={message:T8,sentBy:kX,destination:WQ0},Cv=(X)=>X.destination.kind==="mailbox"||X.message.taskId===X.destination.itemId?!0:"task/request message destination must equal Message.taskId",UQ0=Z.Struct({operation:Z.Literal("message.append"),...wv}).pipe(Z.check(Z.makeFilter(Cv))),DQ0=Z.Struct({operation:Z.Literal("artifact.publish"),artifact:D7,publishedBy:kX}),NQ0=Z.Struct({operation:Z.Literal("delivery.accepted"),receipt:Pv}),BQ0=Z.Struct({operation:Z.Literal("board.topic.create"),topic:B7,createdBy:bX}),VQ0=Z.Struct({operation:Z.Literal("board.post.append"),post:N7,createdBy:bX}),zQ0=Z.Struct({operation:Z.Literal("pad.patch"),patchId:vX,patches:Z.Array(u9).pipe(Z.check(Z.isMinLength(1))),author:bX}),Ev=Z.Union([YQ0,QQ0,JQ0,$Q0,GQ0,ZQ0,_Q0,KQ0,HQ0,UQ0,DQ0,NQ0,BQ0,VQ0,zQ0]),qQ0=Z.Struct({operation:Z.Literal("proposal.create"),proposal:O5}).pipe(Z.check(Z.makeFilter(({proposal:X})=>X.state==="pending"||"proposal.create result requires a pending proposal"))),LQ0=Z.Struct({operation:Z.Literal("proposal.approve"),proposal:O5,task:OX}).pipe(Z.check(Z.makeFilter(({proposal:X,task:Y})=>X.state==="approved"&&X.approvedTaskId===Y.id&&Y.state==="submitted"&&Y.claimedBy===void 0||"proposal.approve result must bind the approved proposal to its submitted task"))),OQ0=Z.Struct({operation:Z.Literal("proposal.reject"),proposal:O5}).pipe(Z.check(Z.makeFilter(({proposal:X})=>X.state==="rejected"||"proposal.reject result requires a rejected proposal"))),TQ0=Z.Struct({operation:Z.Literal("task.create"),task:OX}).pipe(Z.check(Z.makeFilter(({task:X})=>X.state==="submitted"&&X.claimedBy===void 0||"task.create result requires a submitted unclaimed task"))),FQ0=Z.Struct({operation:Z.Literals(["task.describe","task.transition"]),task:OX}),RQ0=Z.Struct({operation:Z.Literal("task.claim"),task:OX,claimedBy:kX,previousHome:q4}).pipe(Z.check(Z.makeFilter(({task:X,claimedBy:Y})=>X.state==="working"&&X.claimedBy===Y.seatId||"task.claim result requires a working task claimed by the exact actor seat"))),AQ0=Z.Struct({operation:Z.Literals(["request.create","request.resolve"]),request:OX}).pipe(Z.check(Z.makeFilter((X)=>{if(X.operation==="request.create")return X.request.state==="input-required"&&X.request.claimedBy!==void 0||"request.create result requires an input-required request with a claimant";return(X.request.state==="completed"||X.request.state==="rejected")&&X.request.claimedBy!==void 0||"request.resolve result requires a completed or rejected request with its original claimant"}))),PQ0=Z.Struct({operation:Z.Literal("message.append"),...wv}).pipe(Z.check(Z.makeFilter(Cv))),wQ0=Z.Struct({operation:Z.Literal("artifact.publish"),artifact:D7,publishedBy:kX}),CQ0=Z.Struct({operation:Z.Literal("delivery.accepted"),receipt:Pv}),EQ0=Z.Struct({operation:Z.Literal("board.topic.create"),topic:B7,createdBy:bX}),MQ0=Z.Struct({operation:Z.Literal("board.post.append"),post:N7,createdBy:bX}),jQ0=Z.Struct({operation:Z.Literal("pad.patch"),patchId:vX,patches:Z.Array(u9).pipe(Z.check(Z.isMinLength(1))),author:bX,revision:Z.Number.pipe(Z.check(Z.isInt()),Z.check(Z.isGreaterThanOrEqualTo(0)))}),Mv=Z.Union([qQ0,LQ0,OQ0,TQ0,FQ0,RQ0,AQ0,PQ0,wQ0,CQ0,EQ0,MQ0,jQ0]),IQ0=Z.Literals(["authority-mismatch","capability-denied","causal-conflict","claim-contention","identity-conflict","invalid-transition","locality-mismatch","missing-entity","projection-conflict","target-mismatch"]),xQ0=Z.Struct({status:Z.Literal("applied"),command:L4,commandSha256:w5,fact:L4,factSha256:w5}),SQ0=Z.Struct({status:Z.Literal("rejected"),command:L4,commandSha256:w5,reason:IQ0,message:sY0}),vQ0=Z.Union([xQ0,SQ0]),oD=Z.Struct({protocol:Z.Literal(cD),id:L4,recordType:Z.Literals(["command","fact","disposition"]),item:$G,operation:XQ0,contentSha256:w5,originAt:lD}),kQ0=(X,Y)=>X.canvasName===Y.canvasName&&X.nodeId===Y.nodeId,jv=(X,Y,Q)=>X.kind==="artifact"&&X.itemId===Y.artifactId&&Q.canvasName===X.sink.canvasName&&(Y.task===void 0||Y.task.sink.canvasName===X.sink.canvasName),bQ0=(X,Y)=>{switch(Y.operation){case"proposal.create":return X.kind==="proposal"&&X.itemId===Y.proposal.id;case"proposal.approve":case"proposal.reject":return X.kind==="proposal"&&X.itemId===Y.proposalId;case"task.create":return X.kind==="task"&&X.itemId===Y.task.id;case"task.describe":case"task.transition":return X.kind==="task"&&X.itemId===Y.taskId;case"task.claim":return X.kind==="task"&&X.itemId===Y.sourceTask.id&&kQ0(X.sink,Y.sink);case"request.create":return X.kind==="request"&&X.itemId===Y.request.id;case"request.resolve":return X.kind==="request"&&X.itemId===Y.requestId;case"message.append":return X.kind==="message"&&X.itemId===Y.message.messageId;case"artifact.publish":return jv(X,Y.artifact,Y.publishedBy);case"delivery.accepted":return X.kind==="delivery"&&X.itemId===Y.receipt.deliveryId;case"board.topic.create":return X.kind==="topic"&&X.itemId===Y.topic.topicId;case"board.post.append":return X.kind==="post"&&X.itemId===Y.post.postId;case"pad.patch":return X.kind==="pad"&&X.itemId===Y.patchId}},gQ0=(X,Y)=>{switch(Y.operation){case"proposal.create":case"proposal.approve":case"proposal.reject":return X.kind==="proposal"&&X.itemId===Y.proposal.id;case"task.create":case"task.describe":case"task.transition":case"task.claim":return X.kind==="task"&&X.itemId===Y.task.id;case"request.create":case"request.resolve":return X.kind==="request"&&X.itemId===Y.request.id;case"message.append":return X.kind==="message"&&X.itemId===Y.message.messageId;case"artifact.publish":return jv(X,Y.artifact,Y.publishedBy);case"delivery.accepted":return X.kind==="delivery"&&X.itemId===Y.receipt.deliveryId;case"board.topic.create":return X.kind==="topic"&&X.itemId===Y.topic.topicId;case"board.post.append":return X.kind==="post"&&X.itemId===Y.post.postId;case"pad.patch":return X.kind==="pad"&&X.itemId===Y.patchId}},Iv=(X)=>X==="proposal.create"||X==="task.create"||X==="task.claim"||X==="request.create"||X==="message.append"||X==="artifact.publish"||X==="delivery.accepted"||X==="board.topic.create"||X==="board.post.append"||X==="pad.patch",yQ0=(X)=>{try{let Y=JSON.stringify(X);return Y===void 0?void 0:new TextEncoder().encode(Y).byteLength}catch{return}};var iD=(X)=>{let Y=yQ0(X);if(Y===void 0)return"Work record must be JSON-serializable";return Y<=Ov||`Work record exceeds ${Ov} encoded bytes`},hQ0=Z.Struct({...oD.fields,recordType:Z.Literal("command"),predecessor:Z.NullOr(L4),body:Ev}),mQ0=hQ0.pipe(Z.check(Z.makeFilter((X)=>{if(X.id.route.eventHome===X.id.route.entityHome)return"Work command event and entity homes must be different";if(X.operation!==X.body.operation)return"Work command operation must match its action";if(!bQ0(X.item,X.body))return"Work command item must match its action identity";if(X.body.operation==="task.claim"){if(X.predecessor!==null)return"Cross-home task.claim command predecessor must be null";if(X.id.route.entityHome!==X.body.targetHome)return"task.claim targetHome must match command entityHome";return!0}if(Iv(X.operation))return X.predecessor===null||"Create command predecessor must be null";return X.predecessor!==null||"Mutation command must name its predecessor"})),Z.check(Z.makeFilter(iD))),fQ0=Z.Struct({...oD.fields,recordType:Z.Literal("fact"),basis:eY0,predecessor:Z.NullOr(L4),body:Mv}),dQ0=fQ0.pipe(Z.check(Z.makeFilter((X)=>{if(X.id.route.eventHome!==X.id.route.entityHome)return"Work fact must be emitted by its entity authority home";if(X.operation!==X.body.operation)return"Work fact operation must match its result";if(!gQ0(X.item,X.body))return"Work fact item must match its result identity";if(X.basis.kind==="command"&&X.basis.command.route.entityHome!==X.id.route.entityHome)return"Command fact basis must address the fact authority lane";if(X.body.operation==="task.claim"){if(X.body.previousHome!==X.id.route.entityHome)return X.predecessor===null||"First cross-home task.claim fact predecessor must be null";return X.predecessor!==null||"Same-home task.claim fact must name its submitted predecessor"}if(Iv(X.operation))return X.predecessor===null||"Create fact predecessor must be null";return X.predecessor!==null||"Mutation fact must name its predecessor"})),Z.check(Z.makeFilter(iD))),pQ0=Z.Struct({...oD.fields,recordType:Z.Literal("disposition"),body:vQ0}),uQ0=pQ0.pipe(Z.check(Z.makeFilter((X)=>{if(X.id.route.eventHome!==X.id.route.entityHome)return"Work disposition must be emitted by its entity authority home";if(X.body.command.route.entityHome!==X.id.route.entityHome)return"Work disposition must address the command entity authority lane";if(X.body.status==="applied"&&(X.body.fact.route.eventHome!==X.id.route.eventHome||X.body.fact.route.entityHome!==X.id.route.entityHome))return"Applied disposition fact must belong to the disposition authority lane";return!0})),Z.check(Z.makeFilter(iD))),xv=Z.Union([mQ0,dQ0,uQ0]),cQ0=Z.Struct({record:xv,receivedAt:lD}),uG={onExcessProperty:"error"},FB0=Z.decodeUnknownResult(Ev,uG),RB0=Z.decodeUnknownResult(Mv,uG),rD=Z.decodeUnknownResult(xv,uG),AB0=Z.decodeUnknownResult(cQ0,uG);var Sv=(X)=>g0.isSuccess(X)?{ok:!0,value:X.success}:{ok:!1,error:String(X.failure)},vv=(X)=>{let Y=rD(X);return g0.isSuccess(Y)?{accepted:!0}:{accepted:!1,error:String(Y.failure),namesAdmission:/admission/u.test(String(Y.failure)),namesRaisedBy:/raisedBy/u.test(String(Y.failure))}},kv=()=>JSON.parse(lQ0(0,"utf8")),bv=()=>({tasksCreateSchemaId:DG.schema_id,stateSchemaVersion:i9,stationProtocolBaseline:P5,stationProtocolSupport:dG,workProtocol:cD}),oQ0=()=>Lv({appVersion:"qualification-probe",stateSchemaVersion:i9,support:dG}),gv=process.argv[2],F7;switch(gv){case"cohort":F7=bv();break;case"decode-work-record":F7=Sv(rD(kv()));break;case"matrix":{let X=kv(),Y=zv(dG,X.peer),Q=0,J=Y._tag==="no-common"?{accepted:!1,reason:"no-common-version"}:(()=>{let $=uD(Y.selected);if(g0.isFailure($))return{accepted:!1,reason:String($.failure)};return Q+=1,vv(X.guardedRecord)})();F7={cohort:bv(),records:Object.fromEntries(Object.entries(X.records).map(([$,G])=>[$,vv(G)])),negotiation:Y,localCodecForPeerPreferred:Sv(uD(X.peer.preferred)),guarded:{versionedDecoderInvocations:Q,result:J,...Y._tag==="no-common"?{rejection:oQ0()}:{}}};break}case"schema-probe":{let X=process.argv[3];if(X===void 0)throw TypeError("schema-probe requires a path");let Y=dD(X);F7={probe:Y,compatibility:Nv(Y)};break}default:throw TypeError(`unknown command: ${String(gv)}`)}process.stdout.write(`${JSON.stringify(F7)}
`);
